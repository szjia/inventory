// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a gl locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'gl';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Continuar"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("Número GST"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("É necesario MRP"),
        "OK": MessageLookupByLibrary.simpleMessage("OK"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Ph.no"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("Código SWIFT"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Aperitivos"),
        "TAX": MessageLookupByLibrary.simpleMessage("IMPOSTO"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Subindo"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("Título do usuario"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "O teu paquete expira hoxe\n\nPor favor, compra de novo"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) O sistema é proporcionado unicamente co fin de facilitar transaccións de punto de venda e actividades relacionadas no teu negocio."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) Para usar o sistema, pode que sexa necesario crear unha conta. Aceptas proporcionar información precisa, actual e completa durante o proceso de rexistro e actualizar dita información para mantela precisa e completa."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("Sobre a aplicación"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Sobre nós"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Aceptación dos termos"),
        "accountName": MessageLookupByLibrary.simpleMessage("Nome da conta"),
        "accountNumber":
            MessageLookupByLibrary.simpleMessage("Número da conta"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Rexistro de conta"),
        "acton": MessageLookupByLibrary.simpleMessage("Acción"),
        "add": MessageLookupByLibrary.simpleMessage("Engadir"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Engadir Marca"),
        "addCategory":
            MessageLookupByLibrary.simpleMessage("Engadir Categoría"),
        "addContact": MessageLookupByLibrary.simpleMessage("Engadir Contacto"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Engadir Cliente"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("Engadir Entrega"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Engadir Descrición"),
        "addDescription": MessageLookupByLibrary.simpleMessage("Engadir nota"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Engadir Desconto"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Engadir ID do Documento"),
        "addDucument":
            MessageLookupByLibrary.simpleMessage("Engadir Documento"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Engadir Gastos"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Engadir Categoría de Gastos"),
        "addItems": MessageLookupByLibrary.simpleMessage("Engadir Elementos"),
        "addNew": MessageLookupByLibrary.simpleMessage("Engadir Novo"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Engadir Novo Enderezo"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Engadir Produto"),
        "addNewTax":
            MessageLookupByLibrary.simpleMessage("Engadir Novo Imposto"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Engadir Novo Imposto con tipo de imposto único/múltiple"),
        "addNote": MessageLookupByLibrary.simpleMessage("Engadir Nota"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Engade primeiro o produto"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Engadir Código Promocional"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Engadir Compra"),
        "addSales": MessageLookupByLibrary.simpleMessage("Engadir Vendas"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Engadido con éxito"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Engadir Unidade"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Engadir rol de usuario"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Engadido con éxito"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("Engadido ao carrito"),
        "address": MessageLookupByLibrary.simpleMessage("Enderezo"),
        "admin": MessageLookupByLibrary.simpleMessage("Admin"),
        "all": MessageLookupByLibrary.simpleMessage("Todo"),
        "allBusinessSolution": MessageLookupByLibrary.simpleMessage(
            "Todas as solucións empresariais"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("Xa engadido"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Xa existe"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Xa ten contas"),
        "amount": MessageLookupByLibrary.simpleMessage("Cantidade"),
        "anEmailHasBeenSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "Envióuselle un correo electrónico. Comprobe a súa caixa de entrada."),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Soporte para aplicacións Android e iOS"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Imposto Aplicable"),
        "apply": MessageLookupByLibrary.simpleMessage("Aplicar"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Está seguro de que quere eliminar esta factura?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Está seguro de que quere eliminar esta venda?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Estás seguro de que queres eliminar este usuario?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Estás seguro de que queres eliminar este imposto?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Estás seguro de que queres eliminar este grupo de impostos?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Queres eliminar este almacén?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Está seguro de que desexa eliminar este usuario?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Sinatura autorizada"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Eres responsable de manter a confidencialidade da túa conta e contrasinal e de restrinxir o acceso á túa conta. Aceptas a responsabilidade por todas as actividades que ocorran baixo a túa conta."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Debes ter polo menos 18 anos ou a idade legal de maioría no teu xurisdición para usar o sistema."),
        "backSide": MessageLookupByLibrary.simpleMessage("Lado Traseiro"),
        "backToHome": MessageLookupByLibrary.simpleMessage("Voltar á Casa"),
        "balance": MessageLookupByLibrary.simpleMessage("Balance"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladés"),
        "bank": MessageLookupByLibrary.simpleMessage("Banco"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Moeda da Conta Bancaria"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Moeda da conta bancaria"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Información bancaria"),
        "bankName": MessageLookupByLibrary.simpleMessage("Nome do banco"),
        "bankTransfer":
            MessageLookupByLibrary.simpleMessage("Transferencia Bancaria"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Código de barras atopado"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Factura"),
        "billTo": MessageLookupByLibrary.simpleMessage("Facturar a"),
        "branchName": MessageLookupByLibrary.simpleMessage("Nome da sucursal"),
        "brand": MessageLookupByLibrary.simpleMessage("Marca"),
        "brandName": MessageLookupByLibrary.simpleMessage("Nome da Marca"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("Carga Masiva"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Categoría de Negocio"),
        "buy": MessageLookupByLibrary.simpleMessage("Comprar"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Comprar Plan Premium"),
        "buySms": MessageLookupByLibrary.simpleMessage("Comprar SMS"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Ao acceder ou usar o sistema de punto de venda (POS) (o \"sistema\") proporcionado por [Nome da túa empresa] (\"empresa\"), aceptas estar suxeito a estes termos de uso. Se non estás de acordo con estes termos de uso, non uses o sistema."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Eres responsable de asegurar que o teu acceso e uso do sistema cumpran todas as leis e regulacións aplicables."),
        "cacel": MessageLookupByLibrary.simpleMessage("Cancelar"),
        "call": MessageLookupByLibrary.simpleMessage("Chamar"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "Chame para soporte de emerxencia"),
        "camera": MessageLookupByLibrary.simpleMessage("Cámara"),
        "cancel": MessageLookupByLibrary.simpleMessage("Cancelar"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Cancelar Todos os Produtos"),
        "capacity": MessageLookupByLibrary.simpleMessage("Capacidade"),
        "card": MessageLookupByLibrary.simpleMessage("Tarxeta"),
        "cash": MessageLookupByLibrary.simpleMessage("Efectivo"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Categorías"),
        "category": MessageLookupByLibrary.simpleMessage("Categoría"),
        "categoryName":
            MessageLookupByLibrary.simpleMessage("Nome da Categoría"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "O nome da categoría xa existe"),
        "cateogryName":
            MessageLookupByLibrary.simpleMessage("Nome da Categoría"),
        "change": MessageLookupByLibrary.simpleMessage("Cambiar?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Cambiar Contrasinal"),
        "checkEmail": MessageLookupByLibrary.simpleMessage(
            "Comproba o correo electrónico"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Escoller un Cliente"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Escoller un Provedor"),
        "choseYourFeature": MessageLookupByLibrary.simpleMessage(
            "Escoller as túas características"),
        "clarence": MessageLookupByLibrary.simpleMessage("Clarificación"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Faga clic para conectar"),
        "close": MessageLookupByLibrary.simpleMessage("Pechar"),
        "color": MessageLookupByLibrary.simpleMessage("Cor"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(Combinación de múltiples impostos)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Próximamente"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Enderezo da Empresa"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Nome da Empresa e da Tenda"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("Nome da empresa e negocio"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Completar Transacción"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Confirmar Contraseña"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Confirmar devolución"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Parabéns"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Contacta Con Nós"),
        "continu": MessageLookupByLibrary.simpleMessage("Continuar"),
        "country": MessageLookupByLibrary.simpleMessage("País"),
        "create": MessageLookupByLibrary.simpleMessage("Crear"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Crear unha Conta Gratuita"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Creado e gardado"),
        "currency": MessageLookupByLibrary.simpleMessage("Moeda"),
        "currentStock": MessageLookupByLibrary.simpleMessage("Stock Actual"),
        "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
            "Personalización de marcas de facturas"),
        "customer": MessageLookupByLibrary.simpleMessage("Cliente"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Detalles do Cliente"),
        "customerGST": MessageLookupByLibrary.simpleMessage("GST do Cliente"),
        "customerName": MessageLookupByLibrary.simpleMessage("Nome do Cliente"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Transacción Diaria"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Visión xeral do taboleiro"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Datos gardados con éxito"),
        "date": MessageLookupByLibrary.simpleMessage("Data"),
        "day": MessageLookupByLibrary.simpleMessage("Día"),
        "dealer": MessageLookupByLibrary.simpleMessage("Distribuidor"),
        "dealerPrice":
            MessageLookupByLibrary.simpleMessage("Prezo do Distribuidor"),
        "defaultVATPercentage": MessageLookupByLibrary.simpleMessage(
            "Porcentaxe de IVA por defecto"),
        "delete": MessageLookupByLibrary.simpleMessage("Eliminar"),
        "deleting": MessageLookupByLibrary.simpleMessage("Eliminando"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Enderezo de Entrega"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Direccións de Entrega"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Custo de Entrega"),
        "describtion": MessageLookupByLibrary.simpleMessage("Descrición"),
        "description": MessageLookupByLibrary.simpleMessage("Descrición"),
        "descriptionCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "A descrición non pode estar baleira"),
        "details": MessageLookupByLibrary.simpleMessage("Detalles"),
        "discount": MessageLookupByLibrary.simpleMessage("Desconto"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Non Molestar"),
        "done": MessageLookupByLibrary.simpleMessage("Feito"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Descargar formato Excel"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Descargado con éxito na carpeta de descargas"),
        "due": MessageLookupByLibrary.simpleMessage("Debido"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Cantidade Devida:"),
        "dueCollection":
            MessageLookupByLibrary.simpleMessage("Recollida de Deberes"),
        "dueCollectionReports": MessageLookupByLibrary.simpleMessage(
            "Informes de recollida de débedas"),
        "dueList": MessageLookupByLibrary.simpleMessage("Lista de Deberes"),
        "dueReports": MessageLookupByLibrary.simpleMessage("Informe de Deber"),
        "duration": MessageLookupByLibrary.simpleMessage("Duración"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Duración: De"),
        "easyToUseMobilePos":
            MessageLookupByLibrary.simpleMessage("Fácil de usar POS móbil"),
        "edit": MessageLookupByLibrary.simpleMessage("Editar"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Editar Factura de Compra"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Editar Factura de Venda"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Editar Redes Sociais"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Editado correctamente"),
        "editTax": MessageLookupByLibrary.simpleMessage("Editar Imposto"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Editar Grupo de Imposto"),
        "editWarehouse": MessageLookupByLibrary.simpleMessage("Editar Almacén"),
        "email": MessageLookupByLibrary.simpleMessage("Correo electrónico"),
        "emailAddress": MessageLookupByLibrary.simpleMessage(
            "Dirección de correo electrónico"),
        "emailCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "O correo electrónico non pode estar baleiro"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "Correo electrónico enviado! Verifique a súa bandexa de entrada"),
        "endDate": MessageLookupByLibrary.simpleMessage("Data de Fin"),
        "enterAValidAmount": MessageLookupByLibrary.simpleMessage(
            "Introduce unha Cantidade válida"),
        "enterAValidDiscount": MessageLookupByLibrary.simpleMessage(
            "Introduza un desconto válido"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Introduce un número de teléfono válido"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Introduza un prezo válido"),
        "enterAValidQuantity": MessageLookupByLibrary.simpleMessage(
            "Introduza unha cantidade válida"),
        "enterAddress":
            MessageLookupByLibrary.simpleMessage("Introduza o Enderezo"),
        "enterAmount":
            MessageLookupByLibrary.simpleMessage("Introduza a Cantidade."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Introducir Nome da Marca"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Introducir Capacidade"),
        "enterCategoryName": MessageLookupByLibrary.simpleMessage(
            "Introducir Nome da Categoría"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Introducir Cor"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "Introduce o número GST do cliente"),
        "enterDealerPrice": MessageLookupByLibrary.simpleMessage(
            "Introducir Prezo do Distribuidor"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Introduza a descrición"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("Introducir Desconto."),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Introduza a Data do Gasto"),
        "enterFullAddress": MessageLookupByLibrary.simpleMessage(
            "Introduza o Enderezo Completo"),
        "enterInvoiceNumber": MessageLookupByLibrary.simpleMessage(
            "Introducir Número de Factura"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Introduza a cantidade de alerta de baixo stock"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Introducir Fabricante"),
        "enterMessageContent": MessageLookupByLibrary.simpleMessage(
            "Introducir Contido do Mensaxe"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "Introducir MRP/Prezo de Retalhista"),
        "enterName": MessageLookupByLibrary.simpleMessage("Introduza o Nome"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Introduza a Nota"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Introduza o Nome da Parte"),
        "enterPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Introduza o Número de Teléfono"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Introducir Código do Produto ou Escanear"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Introducir Nome do Produto"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Introducir Prezo de Compra."),
        "enterReferenceNumber": MessageLookupByLibrary.simpleMessage(
            "Introduza o Número de Referencia"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Introducir Tamaño"),
        "enterStocks":
            MessageLookupByLibrary.simpleMessage("Introducir Stocks."),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Introduce o tipo de imposto"),
        "enterTransactionId": MessageLookupByLibrary.simpleMessage(
            "Introducir o ID da transacción"),
        "enterType": MessageLookupByLibrary.simpleMessage("Introducir Tipo"),
        "enterUserTitle": MessageLookupByLibrary.simpleMessage(
            "Introduce o título do usuario"),
        "enterValidAmount": MessageLookupByLibrary.simpleMessage(
            "Introduce unha Cantidade Válida"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Introduce o nome do almacén"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Introducir Peso"),
        "enterWholeSalePrice": MessageLookupByLibrary.simpleMessage(
            "Introducir Prezo de Venda ao Por Maior"),
        "enterYourDescriptionHere": MessageLookupByLibrary.simpleMessage(
            "Introducir a túa descrición aquí"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "Introduce a túa dirección de correo electrónico"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "Introducir o Título do teu Feedback"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Introduce o teu número GST"),
        "enterYourMobileNumber": MessageLookupByLibrary.simpleMessage(
            "Introducir o teu número de móbil"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Introduza o Seu Nome"),
        "enterYourNumber": MessageLookupByLibrary.simpleMessage(
            "Introduce o teu número de teléfono"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Introduce a túa contrasinal"),
        "enterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Introduza o Seu Número de Teléfono"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "Introducir o ID da túa transacción"),
        "error": MessageLookupByLibrary.simpleMessage("Erro"),
        "excTax": MessageLookupByLibrary.simpleMessage("Imposto excluído"),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("Cargador de Excel"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Exclusivo"),
        "expense": MessageLookupByLibrary.simpleMessage("Gasto"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Categoría de Gastos"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Data do Gasto"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Gasto Para"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Informe de Gastos"),
        "expireDate":
            MessageLookupByLibrary.simpleMessage("Data de caducidade"),
        "expired": MessageLookupByLibrary.simpleMessage("Caducado"),
        "expiring": MessageLookupByLibrary.simpleMessage("Por caducar"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Fallou con erro"),
        "fashion": MessageLookupByLibrary.simpleMessage("Moda"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "As características son a parte importante que fai que o POS SaaS sexa diferente das solucións tradicionais."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Feedback"),
        "firstName": MessageLookupByLibrary.simpleMessage("Nome"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Síguenos en\\nFacebook"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Síguenos en\\nTwitter"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Lado Frontal"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("Para usos ilimitados"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Esqueceches a contrasinal?"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Esqueceches a contrasinal?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Desde a Data"),
        "freeDataBackup": MessageLookupByLibrary.simpleMessage(
            "Copia de seguridade de datos gratuíta"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "Actualización vitalicia gratuíta"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Paquete Gratuito"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Plan Gratuito"),
        "from": MessageLookupByLibrary.simpleMessage("(De"),
        "fullyPaid":
            MessageLookupByLibrary.simpleMessage("Completamente pagado"),
        "gallary": MessageLookupByLibrary.simpleMessage("Galería"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("Xenerando PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Obter OTP"),
        "govermentId": MessageLookupByLibrary.simpleMessage("ID do Goberno"),
        "guest": MessageLookupByLibrary.simpleMessage("Convidado"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Non tes unha conta?"),
        "history": MessageLookupByLibrary.simpleMessage("Historial"),
        "home": MessageLookupByLibrary.simpleMessage("Inicio"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Como protexemos a túa información"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Como usamos a túa información"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Verificación de Identidade"),
        "image": MessageLookupByLibrary.simpleMessage("Imaxe"),
        "inHouseCantBeDelete": MessageLookupByLibrary.simpleMessage(
            "Non se pode eliminar en casa"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("Non se pode editar en casa"),
        "inWord": MessageLookupByLibrary.simpleMessage("En palabras"),
        "incTax": MessageLookupByLibrary.simpleMessage("Imposto incluído"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Inclusivo"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("Aumentar Stock"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Instrumento"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Inv No."),
        "invoice": MessageLookupByLibrary.simpleMessage("Factura"),
        "invoiceNumber":
            MessageLookupByLibrary.simpleMessage("Número de Factura"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Configuración da Factura"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Visor de Facturas"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Elemento Engadido"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("Verificación KYC"),
        "language": MessageLookupByLibrary.simpleMessage("Lingua"),
        "lastName": MessageLookupByLibrary.simpleMessage("Apelido"),
        "ledger": MessageLookupByLibrary.simpleMessage("Libro de Contas"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Compra Vitalicia"),
        "link": MessageLookupByLibrary.simpleMessage("Ligazón"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Soporte de chat en directo"),
        "loading": MessageLookupByLibrary.simpleMessage("Cargando"),
        "logIn": MessageLookupByLibrary.simpleMessage("Iniciar Sesión"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Pechar Sesión"),
        "logOut": MessageLookupByLibrary.simpleMessage("Saír"),
        "login": MessageLookupByLibrary.simpleMessage("Iniciar sesión"),
        "logo": MessageLookupByLibrary.simpleMessage("Logotipo"),
        "loss": MessageLookupByLibrary.simpleMessage("Pérdida"),
        "lossOrProfit":
            MessageLookupByLibrary.simpleMessage("Pérdida/Ganancia"),
        "lossOrProfitDetails": MessageLookupByLibrary.simpleMessage(
            "Detalles de Pérdida/Ganancia"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Informe de perda/ beneficio"),
        "lossProfitReports": MessageLookupByLibrary.simpleMessage(
            "Informes de perda/ beneficio"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Alerta de baixo stock"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Fai unha impresión duradeira nos teus clientes con facturas de marca. A nosa actualización Ilimitada ofrece a vantaxe única de personalizar as túas facturas, engadindo un toque profesional que refuerza a identidade da túa marca e fomenta a lealdade do cliente."),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("Xestiona o teu negocio con"),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Data de fabricación"),
        "margin": MessageLookupByLibrary.simpleMessage("Margen"),
        "masterCard":
            MessageLookupByLibrary.simpleMessage("Tarxeta MasterCard"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Fabricante"),
        "message": MessageLookupByLibrary.simpleMessage("Mensaxe"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Historial de Mensaxes"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "A aplicación POS SaaS é gratuíta, fácil de usar. De feito, é un dos mellores sistemas POS do mundo."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "O POS SaaS é unha solución empresarial completa con stock, contabilidade, vendas, gastos e perda/beneficio."),
        "mobile": MessageLookupByLibrary.simpleMessage("Móbil"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("Pago Móbil"),
        "monthly": MessageLookupByLibrary.simpleMessage("Mensual"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("Máis Información"),
        "name": MessageLookupByLibrary.simpleMessage("Introduza o Seu Nome."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("O nome xa existe"),
        "nameCantBeEmpty": MessageLookupByLibrary.simpleMessage(
            "O nome non pode estar baleiro"),
        "next": MessageLookupByLibrary.simpleMessage("Siguiente"),
        "noConnection": MessageLookupByLibrary.simpleMessage("Sen conexión"),
        "noData": MessageLookupByLibrary.simpleMessage("Sen Datos"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Non hai datos dispoñibles"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Non se atoparon datos"),
        "noHistoryFound": MessageLookupByLibrary.simpleMessage(
            "¡Ningún Histórico Encontrado!"),
        "noProductFound": MessageLookupByLibrary.simpleMessage(
            "Non se atopou ningún produto"),
        "noSubTaxSelected": MessageLookupByLibrary.simpleMessage(
            "Non se seleccionou ningún subimposto"),
        "noTransactionFound": MessageLookupByLibrary.simpleMessage(
            "¡Ningunha Transacción Encontrada!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Non se atopou ningún usuario para ese correo electrónico."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "Non se atopou ningún rol de usuario"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Non é un usuario activo"),
        "notProvided":
            MessageLookupByLibrary.simpleMessage("Non proporcionado"),
        "note": MessageLookupByLibrary.simpleMessage("Nota"),
        "notes": MessageLookupByLibrary.simpleMessage("Notas"),
        "notification": MessageLookupByLibrary.simpleMessage("Notificación"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP enviado a"),
        "office": MessageLookupByLibrary.simpleMessage("Oficina"),
        "ok": MessageLookupByLibrary.simpleMessage("Ok"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS que contén unha gran cantidade de funcionalidades, incluíndo seguimento de vendas e xestión de inventario."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Este sistema axúda a mellorar as túas operacións para os teus clientes."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "O noso sistema POS debe simplificar as operacións diarias automáticamente, facilitando a navegación."),
        "openingBalance": MessageLookupByLibrary.simpleMessage("Saldo Inicial"),
        "order": MessageLookupByLibrary.simpleMessage("Pedidos"),
        "other": MessageLookupByLibrary.simpleMessage("Outro"),
        "otp": MessageLookupByLibrary.simpleMessage("Pechar"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Agotado"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Paquete"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Características do Paquete"),
        "paid": MessageLookupByLibrary.simpleMessage("Pagado"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Importe Pagado"),
        "parties": MessageLookupByLibrary.simpleMessage("Partes"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Lista de Partes"),
        "partyGST": MessageLookupByLibrary.simpleMessage("GST da Parte"),
        "partyName": MessageLookupByLibrary.simpleMessage("Nome da Parte"),
        "password": MessageLookupByLibrary.simpleMessage("Contrasinal"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "A contrasinal e a confirmación da contrasinal non coinciden"),
        "passwordCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "A contrasinal non pode estar baleira"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("A contrasinal non coincide"),
        "payCash": MessageLookupByLibrary.simpleMessage("Pagar en efectivo"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash": MessageLookupByLibrary.simpleMessage("Pagar con Bkash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Pagar con Paypal"),
        "payeeName":
            MessageLookupByLibrary.simpleMessage("Nome do Beneficiario"),
        "payeeNumber":
            MessageLookupByLibrary.simpleMessage("Número do Beneficiario"),
        "payment": MessageLookupByLibrary.simpleMessage("Pagamento"),
        "paymentAmount":
            MessageLookupByLibrary.simpleMessage("Importe do Pago"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Pagamento Completo"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Instruccións de Pago:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("Método de Pago"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Tipo de Pago"),
        "pdfView": MessageLookupByLibrary.simpleMessage("Vista PDF"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Información Persoal"),
        "phone": MessageLookupByLibrary.simpleMessage("Teléfono"),
        "phoneNumber":
            MessageLookupByLibrary.simpleMessage("Número de Teléfono"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Número de teléfono xa utilizado"),
        "phoneNumberIsNotValid": MessageLookupByLibrary.simpleMessage(
            "O número de teléfono non é válido"),
        "phoneNumberIsRequired": MessageLookupByLibrary.simpleMessage(
            "O número de teléfono é requerido"),
        "pickAndUploadFile": MessageLookupByLibrary.simpleMessage(
            "Seleccionar e cargar ficheiro"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("Escoller Data de Fin"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Escoller Data de Comezo"),
        "plan": MessageLookupByLibrary.simpleMessage("Plan"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("Por favor, engade cantidade"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Por favor, comproba a túa conectividade a Internet"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Por favor, conecta a impresora primeiro"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Por favor, conecte a súa impresora Bluetooth"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Por favor, introduce unha contrasinal máis longa"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Por favor, introduza unha Contraseña de Confirmación"),
        "pleaseEnterAPassword": MessageLookupByLibrary.simpleMessage(
            "Por favor, introduce unha contrasinal"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Por favor, introduce un correo electrónico válido"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Por favor, introduce o nome"),
        "pleaseEnterPassword": MessageLookupByLibrary.simpleMessage(
            "Por favor, introduce a contrasinal"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Por favor, introduce a túa dirección de correo electrónico a continuación para recibir o enlace de restablecemento de contrasinal."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Por favor, introduce o número de transacción"),
        "pleaseInterAmount": MessageLookupByLibrary.simpleMessage(
            "Por favor, introduce a Cantidade"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Por favor, selecciona unha categoría primeiro"),
        "pleaseSelectAPlan": MessageLookupByLibrary.simpleMessage(
            "Por favor, selecciona un plan"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Por favor, selecciona a categoría empresarial"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Por favor, usa o código de compra válido para usar a aplicación"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Desenvolvido por Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Desenvolvido por"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Soporte ao cliente premium"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Plan Premium"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Cantidades de Pago Previas"),
        "price": MessageLookupByLibrary.simpleMessage("prezo"),
        "print": MessageLookupByLibrary.simpleMessage("Imprimir"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Opcións de Impresión"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Política de privacidade"),
        "product": MessageLookupByLibrary.simpleMessage("Produto"),
        "productCode":
            MessageLookupByLibrary.simpleMessage("Código do Produto"),
        "productCodeIsRequired": MessageLookupByLibrary.simpleMessage(
            "O Código do Produto é requerido"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Código/ Nome do produto"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Descrición do produto"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Detalles do produto"),
        "productList":
            MessageLookupByLibrary.simpleMessage("Lista de Produtos"),
        "productName": MessageLookupByLibrary.simpleMessage("Nome do Produto"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "O Nome do Produto xa existe neste almacén"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "O nome do produto xa está engadido"),
        "productNameIsRequired": MessageLookupByLibrary.simpleMessage(
            "O nome do produto é requerido"),
        "products": MessageLookupByLibrary.simpleMessage("Produtos"),
        "profile": MessageLookupByLibrary.simpleMessage("Perfil"),
        "profileEdit":
            MessageLookupByLibrary.simpleMessage("Edición de perfil"),
        "profit": MessageLookupByLibrary.simpleMessage("Ganancia"),
        "promo": MessageLookupByLibrary.simpleMessage("promoción"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Código Promocional"),
        "purchase": MessageLookupByLibrary.simpleMessage("Compra"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("Alarma de Compra"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Compra Confirmada"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Detalles da Compra"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Factura de compra"),
        "purchaseList":
            MessageLookupByLibrary.simpleMessage("Lista de Compras"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Compra agora"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Comprar Plan Premium"),
        "purchasePrice":
            MessageLookupByLibrary.simpleMessage("Prezo de Compra"),
        "purchasePriceIsRequired": MessageLookupByLibrary.simpleMessage(
            "O Prezo de Compra é requerido"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("Informe de Compra"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Informe de Compras"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Informes de compras"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("Devolución de compra"),
        "purchaseReturnReport": MessageLookupByLibrary.simpleMessage(
            "Informe de devolución de compra"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Transición de compra"),
        "qty": MessageLookupByLibrary.simpleMessage("Cant."),
        "quantity": MessageLookupByLibrary.simpleMessage("Cantidade"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Transaccións Recentes"),
        "recivedThePin": MessageLookupByLibrary.simpleMessage("Recibiu o PIN"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Número de Referencia"),
        "register": MessageLookupByLibrary.simpleMessage("Rexistrar"),
        "registering": MessageLookupByLibrary.simpleMessage("Registando"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("Deber restante"),
        "remove": MessageLookupByLibrary.simpleMessage("Eliminar"),
        "reports": MessageLookupByLibrary.simpleMessage("Informes"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("A solicitude foi enviada"),
        "resendCode": MessageLookupByLibrary.simpleMessage("Reenviar código"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("Reenviar OTP: "),
        "retailer": MessageLookupByLibrary.simpleMessage("Minorista"),
        "retur": MessageLookupByLibrary.simpleMessage("Devolución"),
        "returN": MessageLookupByLibrary.simpleMessage("Devolución"),
        "returnAMount":
            MessageLookupByLibrary.simpleMessage("Devolución do Importo"),
        "returnAmount":
            MessageLookupByLibrary.simpleMessage("Cantidade de Devolución"),
        "returnQTY":
            MessageLookupByLibrary.simpleMessage("Cantidade de devolución"),
        "revenue": MessageLookupByLibrary.simpleMessage("Ingresos"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Protexe os datos do teu negocio sen esforzo. A nosa actualización Pos Saas POS Ilimitada inclúe copia de seguridade de datos gratuíta, asegurando que a túa valiosa información está protexida contra calquera evento imprevisto. Concentra a túa atención no que realmente importa: o crecemento do teu negocio."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Importe da venda"),
        "saleDetails":
            MessageLookupByLibrary.simpleMessage("Detalles da Venda"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Prezo de Venda"),
        "saleReports": MessageLookupByLibrary.simpleMessage("Informe de Venda"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Informes de vendas"),
        "saleReturn":
            MessageLookupByLibrary.simpleMessage("Devolución de vendas"),
        "saleReturnReport": MessageLookupByLibrary.simpleMessage(
            "Informe de devolución de venda"),
        "saleSetting":
            MessageLookupByLibrary.simpleMessage("Configuración de vendas"),
        "sales": MessageLookupByLibrary.simpleMessage("Vendas"),
        "salesAndPurchaseReports": MessageLookupByLibrary.simpleMessage(
            "Informes de vendas e compras"),
        "salesList": MessageLookupByLibrary.simpleMessage("Lista de Vendas"),
        "salesReturn":
            MessageLookupByLibrary.simpleMessage("Devolución de vendas"),
        "save": MessageLookupByLibrary.simpleMessage("Gardar"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Gardar e Publicar"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("Gardar Cambios"),
        "saving": MessageLookupByLibrary.simpleMessage("Gardando"),
        "scanProductQRCode": MessageLookupByLibrary.simpleMessage(
            "Escanea o código QR do produto"),
        "search": MessageLookupByLibrary.simpleMessage("Buscar"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Buscar por código ou nome do produto"),
        "seeAllPromoCode": MessageLookupByLibrary.simpleMessage(
            "Ver todos os códigos promocionais"),
        "select": MessageLookupByLibrary.simpleMessage("Seleccionar"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Selecciona un produto para a devolución"),
        "selectBrand":
            MessageLookupByLibrary.simpleMessage("Selecciona a Marca"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Selecciona a Categoría"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Seleccionar Contactos"),
        "selectProductCategory": MessageLookupByLibrary.simpleMessage(
            "Selecciona a Categoría de Produto"),
        "selectShopCategory": MessageLookupByLibrary.simpleMessage(
            "Selecciona a categoría da tenda"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Selecciona Imposto"),
        "selectTaxType": MessageLookupByLibrary.simpleMessage(
            "Selecciona o Tipo de Imposto"),
        "selectUnit":
            MessageLookupByLibrary.simpleMessage("Selecciona a Unidade"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Seleccionar Variación: "),
        "seller": MessageLookupByLibrary.simpleMessage("Vendedor"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Vendido por"),
        "send": MessageLookupByLibrary.simpleMessage("Enviar"),
        "sendEmail":
            MessageLookupByLibrary.simpleMessage("Enviar Correo Electrónico"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Enviar Mensaxe"),
        "sendResetLink": MessageLookupByLibrary.simpleMessage(
            "Enviar enlace de restablecemento"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Enviar SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Enviar SMS?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Enviar mensaxe por Whatsapp"),
        "sendYOurEmail": MessageLookupByLibrary.simpleMessage(
            "Enviar o Teu Correo Electrónico"),
        "sendingEmail":
            MessageLookupByLibrary.simpleMessage("Enviando correo electrónico"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Enviando mensaxe"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Servizo/ Envío"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Configura o teu perfil"),
        "setting": MessageLookupByLibrary.simpleMessage("Configuración"),
        "share": MessageLookupByLibrary.simpleMessage("Compartir"),
        "shopGST": MessageLookupByLibrary.simpleMessage("GST da Tenda"),
        "signIn": MessageLookupByLibrary.simpleMessage("Iniciar Sesión"),
        "signInWithEmail": MessageLookupByLibrary.simpleMessage(
            "Iniciar sesión con correo electrónico"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Sinatura do cliente"),
        "size": MessageLookupByLibrary.simpleMessage("Tamaño"),
        "skip": MessageLookupByLibrary.simpleMessage("Saltar"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Marketing Social"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Desculpa, non tes permiso para acceder a este servizo"),
        "startDate": MessageLookupByLibrary.simpleMessage("Data de Comezo"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Comezar Nova Venda"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage(
            "Comeza a escribir para buscar"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Mantente á vangarda dos avances tecnolóxicos sen custos adicionais. A nosa actualización Pos Saas POS Ilimitada garante que sempre teñas as últimas ferramentas e funcionalidades ao teu alcance, garantindo que o teu negocio permaneza á última."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("Aínda non pagado"),
        "stock": MessageLookupByLibrary.simpleMessage("Stock"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("O stock é requerido"),
        "stockList": MessageLookupByLibrary.simpleMessage("Lista de stock"),
        "stocks": MessageLookupByLibrary.simpleMessage("Stocks"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "É necesario permiso de almacenamento para crear un ficheiro Excel"),
        "subTaxList":
            MessageLookupByLibrary.simpleMessage("Lista de Subimpostos"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Subimpostos"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Subtotal"),
        "submit": MessageLookupByLibrary.simpleMessage("Enviar"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "Suscríbete ao noso\\nYoutube"),
        "subscription": MessageLookupByLibrary.simpleMessage("Subscripción"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Realizado con éxito"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Saíu correctamente"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Actualizado correctamente"),
        "supplier": MessageLookupByLibrary.simpleMessage("Provedor"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("Nome do Provedor"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("Código SWIFT"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Tomar unha foto do carné de conducir, tarxeta de identidade nacional ou pasaporte"),
        "takeaNidCardToCheckYourInformation": MessageLookupByLibrary.simpleMessage(
            "Tomar unha tarxeta de identidade para verificar a túa información"),
        "tap": MessageLookupByLibrary.simpleMessage("Toque"),
        "tax": MessageLookupByLibrary.simpleMessage("Imposto"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Grupo de Imposto"),
        "taxPercentage":
            MessageLookupByLibrary.simpleMessage("Porcentaxe do Imposto"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Tipo de Imposto"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Tipos de impostos - Xestiona os teus tipos de impostos"),
        "taxReport":
            MessageLookupByLibrary.simpleMessage("Informe de Impostos"),
        "taxType": MessageLookupByLibrary.simpleMessage("Tipo de Imposto"),
        "taxes": MessageLookupByLibrary.simpleMessage("Impostos"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Termos e Condicións"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("Termos de uso"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Termos e Privacidade"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Grazas polo seu pagamento de deber"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Grazas"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Grazas pola súa compra"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "A conta xa existe para ese correo electrónico"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "O ficheiro Excel xa foi descargado"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "O nome dilo todo. Con Pos Saas POS Ilimitado, non hai límite no teu uso. Se estás procesando un pequeno número de transaccións ou experimentando un aumento de clientes, podes operar con confianza, sabendo que non estás restrinxido por límites."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "A contrasinal proporcionada é demasiado débil"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "A venda será eliminada e todos os datos sobre esta compra serán eliminados. Está seguro de que quere eliminar isto?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "A venda será eliminada e todos os datos sobre esta venda serán eliminados. Está seguro de que quere eliminar isto?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "O usuario será eliminado e todos os datos eliminaranse da súa conta. Está seguro de que desexa eliminar isto?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "O usuario será eliminado e todos os datos eliminaranse da túa conta. Estás seguro de que queres eliminar isto?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Servizos de terceiros"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Esta categoría non se pode eliminar"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Este mes)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Este Produto xa foi engadido"),
        "title": MessageLookupByLibrary.simpleMessage("Título"),
        "titleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "O título non pode estar baleiro"),
        "to": MessageLookupByLibrary.simpleMessage("a"),
        "toDate": MessageLookupByLibrary.simpleMessage("Ata a Data"),
        "today": MessageLookupByLibrary.simpleMessage("Hoxe"),
        "total": MessageLookupByLibrary.simpleMessage("Total"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Importe Total"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Total recadado"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Total Devido"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("Gasto Total"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Pérdida Total"),
        "totalPayable": MessageLookupByLibrary.simpleMessage("Total a Pagar"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Prezo Total"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("Total de Produtos"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Beneficio Total"),
        "totalPurchase":
            MessageLookupByLibrary.simpleMessage("Total da compra"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Total da devolución"),
        "totalReturns":
            MessageLookupByLibrary.simpleMessage("Total de devolucións"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Venda Total"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Total de Stocks"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Valor total"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Total IVA"),
        "totals": MessageLookupByLibrary.simpleMessage("Total: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Transacción"),
        "transactionId":
            MessageLookupByLibrary.simpleMessage("ID da Transacción"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Inténtao de novo"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Tipo"),
        "unitName": MessageLookupByLibrary.simpleMessage("Nome da Unidade"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Prezo Unitario"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Prezo unitario"),
        "units": MessageLookupByLibrary.simpleMessage("Unidades"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Ilimitado"),
        "unlimitedUsage": MessageLookupByLibrary.simpleMessage("Uso ilimitado"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Desbloquea o potencial completo do Pos Saas POS con sesións de formación personalizadas dirixidas polo noso equipo de expertos. Desde os conceptos básicos ata técnicas avanzadas, asegurámonos de que estés ben versado na utilización de cada faceta do sistema para optimizar os teus procesos empresariais."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Non pagado"),
        "update": MessageLookupByLibrary.simpleMessage("Actualizar"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Actualizar Contacto"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Actualizar Agora"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("Actualizar Produto"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Actualiza o teu plan primeiro, a túa liña foi superada"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Actualizar o seu Perfil"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Actualiza o teu perfil para conectar co teu médico cunha mellor impresión"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Actualiza o seu perfil para conectar mellor co seu cliente"),
        "updated": MessageLookupByLibrary.simpleMessage("Actualizado"),
        "upload": MessageLookupByLibrary.simpleMessage("Cargar"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Subir documento"),
        "uploadDone":
            MessageLookupByLibrary.simpleMessage("Cargamento realizado"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Subir arquivo"),
        "upplier": MessageLookupByLibrary.simpleMessage("Provedor"),
        "usbC": MessageLookupByLibrary.simpleMessage("Usb C"),
        "use": MessageLookupByLibrary.simpleMessage("Usar"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("Usar POS SaaS"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Uso do sistema"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Usuario eliminado"),
        "userRole": MessageLookupByLibrary.simpleMessage("Rol de usuario"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("Detalles do rol de usuario"),
        "userTitle": MessageLookupByLibrary.simpleMessage("Título do usuario"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "O título do usuario non pode estar baleiro"),
        "value": MessageLookupByLibrary.simpleMessage("Valor"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("O VAT non se aplica"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("Verificando OTP"),
        "verifyPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Verificar número de teléfono"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Ver Todos"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("Ver Detalles"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Cliente Sen Cita"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Almacén"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("O almacén xa existe"),
        "warehouseList":
            MessageLookupByLibrary.simpleMessage("Lista de Almacéns"),
        "warehouseName":
            MessageLookupByLibrary.simpleMessage("Nome do Almacén"),
        "warranty": MessageLookupByLibrary.simpleMessage("Garatía"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Enviaste un correo electrónico con instrucións sobre como restablecer a contrasinal a:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Podemos utilizar servizos de terceiros para apoiar a funcionalidade da nosa aplicación, como provedores de análises e procesadores de pagamentos. Estes servizos de terceiros poden recoller información sobre ti cando usas a nosa aplicación. Por favor, ten en conta que non somos responsables das prácticas de privacidade destes servizos de terceiros."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Tomamos medidas estándar da industria para proteger a túa información persoal, incluíndo cifrado e almacenamento seguro. Tamén limitamos o acceso á túa información só ao persoal autorizado."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Entendemos a importancia das operacións sen problemas. É por iso que o noso soporte 24/7 está dispoñible para axudarche, xa sexa cunha consulta rápida ou unha preocupación máis abrangente. Conéctate connosco en calquera momento e lugar a través de chamada ou WhatsApp para experimentar un servizo ao cliente sen igual."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Usamos a túa información persoal para proporcionarcho a mellor experiencia posible na nosa aplicación, incluíndo personalizar as recomendacións de contido, conectarcho con expertos e mellorar a funcionalidade da nosa aplicación. Tamén podemos usar a túa información para comunicarnos contigo sobre actualizacións, promocións ou outra información relacionada coa nosa aplicación."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Revisaremos o pagamento e aprobaremos en 1-2 horas"),
        "weekly": MessageLookupByLibrary.simpleMessage("Semanal"),
        "weight": MessageLookupByLibrary.simpleMessage("Peso"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Novidades"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Mayorista"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Prezo de Venda ao Por Maior"),
        "wholesalePrice":
            MessageLookupByLibrary.simpleMessage("Prezo de venda ao por maior"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Xoleiro"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Engadirase pronto"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Caducará en"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Escribe a túa mensaxe aquí"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("OTP incorrecto"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Contraseña incorrecta proporcionada para ese usuario."),
        "yearly": MessageLookupByLibrary.simpleMessage("Anual"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Si, Eliminar para Sempre"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("Non es un usuario válido"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Estás usando"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Non podes pagar máis do que debes"),
        "youHaveGotAnEmail": MessageLookupByLibrary.simpleMessage(
            "Recibiches un correo electrónico"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Iniciou sesión correctamente na súa conta. Quédese con Pos Saas."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("Debes dar permiso"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Debes volver iniciar sesión na túa conta."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Necesitas verificar a túa identidade antes de comprar SMS"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("As túas mensaxes restantes"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("O teu Paquete"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "O teu paquete expirará en 5 días")
      };
}
