// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a hi locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'hi';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("बिलप्लज़"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("जारी रखें"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("जीएसटी नंबर"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("इज़ीको"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("केकेआईपे"),
        "MRP": MessageLookupByLibrary.simpleMessage("एमआरपी"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("एमआरपी आवश्यक है"),
        "OK": MessageLookupByLibrary.simpleMessage("ठीक है"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("पीओएस एसएएस"),
        "Paypal": MessageLookupByLibrary.simpleMessage("पेपल"),
        "PhNo": MessageLookupByLibrary.simpleMessage("फोन नंबर"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("रेज़ोरपे"),
        "SL": MessageLookupByLibrary.simpleMessage("एसएल"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("एसएसएलकॉमर्ज"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("स्विफ्ट कोड"),
        "Snacks": MessageLookupByLibrary.simpleMessage("नाश्ता"),
        "TAX": MessageLookupByLibrary.simpleMessage("कर"),
        "Uploading": MessageLookupByLibrary.simpleMessage("अपलोड हो रहा है"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("उपयोगकर्ता शीर्षक"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "आपका पैकेज आज समाप्त हो जाएगा\n\nकृपया फिर से खरीदें"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) सिस्टम केवल वितरण पॉइंट में बेचने और संबंधित\nगतिविधियों को सुविधा प्रदान करने के उद्देश्य\nसे प्रदान किया जाता है।"),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(ए) सिस्टम का उपयोग करने के लिए, आप हो सकते हैं\nखाता बनाना आवश्यक है. आप\nसटीक, वर्तमान और प्रदान करने के लिए सहमत हैं\nदौरान पूरी जानकारी\nपंजीकरण प्रक्रिया और अद्यतन\nइसे सटीक रखने के लिए ऐसी जानकारी\nऔर पूरा."),
        "aboutApp":
            MessageLookupByLibrary.simpleMessage("एप्लिकेशन के बारे में"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("हमारे बारे में"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("शर्तों की स्वीकृति"),
        "accountName": MessageLookupByLibrary.simpleMessage("खाता नाम"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("खाता संख्या"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("खाता पंजीकरण"),
        "acton": MessageLookupByLibrary.simpleMessage("कार्रवाई"),
        "add": MessageLookupByLibrary.simpleMessage("जोड़ें"),
        "addBrand": MessageLookupByLibrary.simpleMessage("ब्रांड जोड़ें"),
        "addCategory": MessageLookupByLibrary.simpleMessage("श्रेणी जोड़ें"),
        "addContact": MessageLookupByLibrary.simpleMessage("संपर्क जोड़ें"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("ग्राहक जोड़ें"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("वितरण जोड़ें"),
        "addDescriptioN": MessageLookupByLibrary.simpleMessage("विवरण जोड़ें"),
        "addDescription": MessageLookupByLibrary.simpleMessage("नोट जोड़ें"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("छूट जोड़ें"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("दस्तावेज़ आईडी जोड़ें"),
        "addDucument": MessageLookupByLibrary.simpleMessage("दस्तावेज़ जोड़ें"),
        "addExpense": MessageLookupByLibrary.simpleMessage("खर्च जोड़ें"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("खर्च श्रेणी जोड़ें"),
        "addItems": MessageLookupByLibrary.simpleMessage("आइटम जोड़ें"),
        "addNew": MessageLookupByLibrary.simpleMessage("नया जोड़ें"),
        "addNewAddress": MessageLookupByLibrary.simpleMessage("नया पता जोड़ें"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("नया उत्पाद जोड़ें"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("नया कर जोड़ें"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "एकल/मल्टीपल कर प्रकार के साथ नया कर जोड़ें"),
        "addNote": MessageLookupByLibrary.simpleMessage("नोट जोड़ें"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("पहले उत्पाद जोड़ें"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("प्रोमो कोड जोड़ें"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("खरीद जोड़ें"),
        "addSales": MessageLookupByLibrary.simpleMessage("बिक्री जोड़ें"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("सफलतापूर्वक जोड़ दिया गया"),
        "addUnit": MessageLookupByLibrary.simpleMessage("इकाई जोड़ें"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("उपयोगकर्ता भूमिका जोड़ें"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("सफलतापूर्वक जोड़ा गया"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("कार्ट में जोड़ा गया"),
        "address": MessageLookupByLibrary.simpleMessage("पता"),
        "admin": MessageLookupByLibrary.simpleMessage("प्रशासक"),
        "all": MessageLookupByLibrary.simpleMessage("सभी"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("सभी व्यवसाय समाधान"),
        "alreadyAdded":
            MessageLookupByLibrary.simpleMessage("पहले से जोड़ा गया"),
        "alreadyExists":
            MessageLookupByLibrary.simpleMessage("पहले से मौजूद है"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("पहले से ही खाता है"),
        "amount": MessageLookupByLibrary.simpleMessage("राशि"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "एक ईमेल भेजा गया है\\nअपना इनबॉक्स देखें"),
        "androidIOSAppSupport":
            MessageLookupByLibrary.simpleMessage("एंड्रॉइड और आईओएस ऐप सपोर्ट"),
        "applicableTax": MessageLookupByLibrary.simpleMessage("लागू कर"),
        "apply": MessageLookupByLibrary.simpleMessage("लागू करें"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "क्या आप इस चालान को हटाना चाहते हैं"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "क्या आप इस बिक्री को हटाना चाहते हैं"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "क्या आप सुनिश्चित हैं कि आप इस उपयोगकर्ता को हटाना चाहते हैं"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "क्या आप इस कर को हटाना चाहते हैं"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "क्या आप इस कर समूह को हटाना चाहते हैं"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "क्या आप इस गोदाम को हटाना चाहते हैं"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "क्या आप इस उपयोगकर्ता को हटाना चाहते हैं?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("अधिकृत हस्ताक्षर"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(बी) आप इसके लिए जिम्मेदार हैं\nआपकी गोपनीयता बनाए रखना\nखाता और पासवर्ड और प्रतिबंधित करने के लिए\nआपके खाते तक पहुंच. आप स्वीकार करते हैं\nसभी गतिविधियों के लिए जिम्मेदारी\nआपके खाते के अंतर्गत होता है."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) आपको कम से कम 18 साल की आयु या\nअपने प्राधिकृत क्षेत्र में बहुमति की कानूनी आयु होनी\nचाहिए सिस्टम का उपयोग करने के लिए।"),
        "backSide": MessageLookupByLibrary.simpleMessage("पीछे की तरफ"),
        "backToHome": MessageLookupByLibrary.simpleMessage("होम पर वापस जाएं"),
        "balance": MessageLookupByLibrary.simpleMessage("शेष राशि"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("बांग्लादेश"),
        "bank": MessageLookupByLibrary.simpleMessage("बैंक"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("बैंक खाता मुद्रा"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("बैंक खाता मुद्रा"),
        "bankInformation": MessageLookupByLibrary.simpleMessage("बैंक जानकारी"),
        "bankName": MessageLookupByLibrary.simpleMessage("बैंक का नाम"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("बैंक हस्तांतरण"),
        "barcodeFound": MessageLookupByLibrary.simpleMessage("बारकोड पाया गया"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("बिल/चालान"),
        "billTo": MessageLookupByLibrary.simpleMessage("बिल किया गया"),
        "branchName": MessageLookupByLibrary.simpleMessage("शाखा का नाम"),
        "brand": MessageLookupByLibrary.simpleMessage("ब्रांड"),
        "brandName": MessageLookupByLibrary.simpleMessage("ब्रांड का नाम"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("बल्क \nअपलोड"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("व्यवसाय श्रेणी"),
        "buy": MessageLookupByLibrary.simpleMessage("खरीदें"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("प्रीमियम प्लान खरीदें"),
        "buySms": MessageLookupByLibrary.simpleMessage("SMS खरीदें"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "वितरण और बेचने के प्वाइंट (POS) सिस्टम (\"सिस्टम\"), जो [आपकी कंपनी का नाम] (\"कंपनी\") द्वारा प्रदान किया जाता है, उपयोग करके या पहुंचकर, आप इन उपयोग की शर्तों से बंधन को स्वीकार करते हैं। यदि आप इन उपयोग की शर्तों से सहमत नहीं हैं, तो सिस्टम का उपयोग न करें।"),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) आपकी सिस्टम तक पहुंच और उपयोग\nका सुनिश्चित करने की जिम्मेदारी है कि\nआपके पास कृत्रिमनियमों और विधियों के सभी\nलागू नियमों का\nपालन करने के लिए है।"),
        "cacel": MessageLookupByLibrary.simpleMessage("रद्द करें"),
        "call": MessageLookupByLibrary.simpleMessage("कॉल"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "आपातकालीन सहायता के लिए कॉल करें"),
        "camera": MessageLookupByLibrary.simpleMessage("कैमरा"),
        "cancel": MessageLookupByLibrary.simpleMessage("रद्द करें"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("सभी उत्पाद रद्द करें"),
        "capacity": MessageLookupByLibrary.simpleMessage("क्षमता"),
        "card": MessageLookupByLibrary.simpleMessage("कार्ड"),
        "cash": MessageLookupByLibrary.simpleMessage("नकद"),
        "cashFree": MessageLookupByLibrary.simpleMessage("कैश फ्री"),
        "categories": MessageLookupByLibrary.simpleMessage("श्रेणियाँ"),
        "category": MessageLookupByLibrary.simpleMessage("श्रेणी"),
        "categoryName": MessageLookupByLibrary.simpleMessage("श्रेणी का नाम"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "श्रेणी का नाम पहले से मौजूद है"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("श्रेणी का नाम"),
        "change": MessageLookupByLibrary.simpleMessage("बदलें?"),
        "changePassword": MessageLookupByLibrary.simpleMessage("पासवर्ड बदलें"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("ईमेल देखें"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("एक ग्राहक को चुना"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("एक सप्लायर चुना"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("अपने सुविधाओं का चयन करें"),
        "clarence": MessageLookupByLibrary.simpleMessage("क्लैरेंस"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("जुड़ने के लिए क्लिक करें"),
        "close": MessageLookupByLibrary.simpleMessage("बंद करें"),
        "color": MessageLookupByLibrary.simpleMessage("रंग"),
        "combinationOfMultipleTaxes":
            MessageLookupByLibrary.simpleMessage("(कई करों का संयोजन)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("जल्द आ रहा है"),
        "companyAddress": MessageLookupByLibrary.simpleMessage("कंपनी का पता"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("कंपनी और दुकान का नाम"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("कंपनी और व्यवसाय का नाम"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("लेन-देन पूरा करें"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("पासवर्ड की पुष्टि करें"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("वापसी की पुष्टि करें"),
        "congratulations": MessageLookupByLibrary.simpleMessage("बधाई हो"),
        "contactUs": MessageLookupByLibrary.simpleMessage("हमसे संपर्क करें"),
        "country": MessageLookupByLibrary.simpleMessage("देश"),
        "create": MessageLookupByLibrary.simpleMessage("बनाएं"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("एक मुफ़्त खाता बनाएं"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("बनाया और सहेजा गया"),
        "currency": MessageLookupByLibrary.simpleMessage("मुद्रा"),
        "currentStock": MessageLookupByLibrary.simpleMessage("वर्तमान स्टॉक"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("कस्टम चालान ब्रांडिंग"),
        "customer": MessageLookupByLibrary.simpleMessage("ग्राहक"),
        "customerDetails": MessageLookupByLibrary.simpleMessage("ग्राहक विवरण"),
        "customerGST": MessageLookupByLibrary.simpleMessage("ग्राहक जीएसटी"),
        "customerName": MessageLookupByLibrary.simpleMessage("ग्राहक का नाम"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("डैशबोर्ड अवलोकन"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("डेटा सफलतापूर्वक सहेजा गया"),
        "date": MessageLookupByLibrary.simpleMessage("तारीख"),
        "day": MessageLookupByLibrary.simpleMessage("दिन"),
        "dealer": MessageLookupByLibrary.simpleMessage("डीलर"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("डीलर मूल्य"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("डिफ़ॉल्ट वैट प्रतिशत"),
        "delete": MessageLookupByLibrary.simpleMessage("हटाएं"),
        "deleting": MessageLookupByLibrary.simpleMessage("हटाया जा रहा है"),
        "deliveryAddress": MessageLookupByLibrary.simpleMessage("वितरण पता"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("डिलीवरी पते"),
        "deliveryCharge": MessageLookupByLibrary.simpleMessage("वितरण शुल्क"),
        "describtion": MessageLookupByLibrary.simpleMessage("विवरण"),
        "description": MessageLookupByLibrary.simpleMessage("विवरण"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("विवरण खाली नहीं हो सकता"),
        "details": MessageLookupByLibrary.simpleMessage("विवरण"),
        "discount": MessageLookupByLibrary.simpleMessage("छूट"),
        "done": MessageLookupByLibrary.simpleMessage("हो गया"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("एक्सेल प्रारूप डाउनलोड करें"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "डाउनलोड फ़ोल्डर में सफलतापूर्वक डाउनलोड किया गया"),
        "due": MessageLookupByLibrary.simpleMessage("बकाया"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("बकाया राशि: "),
        "dueCollection": MessageLookupByLibrary.simpleMessage("बकाया वसूली"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("बकाया जमा रिपोर्ट"),
        "dueList": MessageLookupByLibrary.simpleMessage("बकाया सूची"),
        "dueReports": MessageLookupByLibrary.simpleMessage("बकाया रिपोर्ट"),
        "duration": MessageLookupByLibrary.simpleMessage("अवधि"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("अवधि: से"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "उपयोग करने में सहज मोबाइल पॉस"),
        "edit": MessageLookupByLibrary.simpleMessage("संपादित करें"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("खरीद चालान संपादित करें"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("बिक्री चालान संपादित करें"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("सोशल मीडिया संपादित करें"),
        "editSuccessfully": MessageLookupByLibrary.simpleMessage(
            "सफलतापूर्वक संपादित किया गया"),
        "editTax": MessageLookupByLibrary.simpleMessage("कर संपादित करें"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("कर समूह संपादित करें"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("गोदाम संपादित करें"),
        "email": MessageLookupByLibrary.simpleMessage("ईमेल"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("ईमेल पता"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("ईमेल खाली नहीं हो सकता"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "ईमेल भेजा गया! अपना इनबॉक्स जांचें"),
        "endDate": MessageLookupByLibrary.simpleMessage("समाप्ति तिथि"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("एक मान्य राशि दर्ज करें"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("एक मान्य छूट दर्ज करें"),
        "enterAValidPhoneNumber":
            MessageLookupByLibrary.simpleMessage("एक मान्य फोन नंबर दर्ज करें"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("एक मान्य मूल्य दर्ज करें"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("एक मान्य मात्रा दर्ज करें"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("पता दर्ज करें"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("राशि दर्ज करें।"),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("ब्रांड का नाम दर्ज करें"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("क्षमता दर्ज करें"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("श्रेणी का नाम दर्ज करें"),
        "enterColor": MessageLookupByLibrary.simpleMessage("रंग दर्ज करें"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "ग्राहक का जीएसटी नंबर दर्ज करें"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("डीलर मूल्य दर्ज करें"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("विवरण दर्ज करें"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("डिस्काउंट दर्ज करें।"),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("खर्च की तारीख दर्ज करें"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("पूरा पता दर्ज करें"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("चालान नंबर दर्ज करें"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "कम स्टॉक चेतावनी मात्रा दर्ज करें"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("निर्माता दर्ज करें"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("संदेश की सामग्री दर्ज करें"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "एमआरपी / खुदरा मूल्य दर्ज करें"),
        "enterName": MessageLookupByLibrary.simpleMessage("नाम दर्ज करें"),
        "enterNote": MessageLookupByLibrary.simpleMessage("नोट दर्ज करें"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("पार्टी का नाम दर्ज करें"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("फ़ोन नंबर दर्ज करें"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "उत्पाद कोड दर्ज करें या स्कैन करें"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("उत्पाद का नाम दर्ज करें"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("खरीद मूल्य दर्ज करें।"),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("संदर्भ संख्या दर्ज करें"),
        "enterSize": MessageLookupByLibrary.simpleMessage("साइज दर्ज करें"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("स्टॉक दर्ज करें।"),
        "enterTaxRate": MessageLookupByLibrary.simpleMessage("कर दर दर्ज करें"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("लेन-देन आईडी दर्ज करें"),
        "enterType": MessageLookupByLibrary.simpleMessage("प्रकार दर्ज करें"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("उपयोगकर्ता शीर्षक दर्ज करें"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("एक मान्य राशि दर्ज करें"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("गोदाम का नाम दर्ज करें"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("वजन दर्ज करें"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("होलसेल मूल्य दर्ज करें"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("यहाँ अपना विवरण दर्ज करें"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("अपना ईमेल पता दर्ज करें"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("अपना जीएसटी नंबर दर्ज करें"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("अपना मोबाइल नंबर दर्ज करें"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("अपना नाम दर्ज करें"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("अपना फ़ोन नंबर दर्ज करें"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("अपना पासवर्ड दर्ज करें"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("अपना फ़ोन नंबर दर्ज करें"),
        "enterYourTransactionId":
            MessageLookupByLibrary.simpleMessage("अपनी लेन-देन आईडी दर्ज करें"),
        "error": MessageLookupByLibrary.simpleMessage("त्रुटि"),
        "excTax": MessageLookupByLibrary.simpleMessage("कर रहित"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("एक्सेल अपलोडर"),
        "exclusive": MessageLookupByLibrary.simpleMessage("विशिष्ट"),
        "expense": MessageLookupByLibrary.simpleMessage("खर्च"),
        "expenseCategory": MessageLookupByLibrary.simpleMessage("खर्च श्रेणी"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("खर्च की तारीख"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("खर्च के लिए"),
        "expenseReport": MessageLookupByLibrary.simpleMessage("खर्च रिपोर्ट"),
        "expireDate": MessageLookupByLibrary.simpleMessage("समाप्ति तिथि"),
        "expired": MessageLookupByLibrary.simpleMessage("समाप्त"),
        "expiring": MessageLookupByLibrary.simpleMessage("समाप्त हो रहा है"),
        "facebok": MessageLookupByLibrary.simpleMessage("फेसबुक"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("त्रुटि के साथ विफल"),
        "fashion": MessageLookupByLibrary.simpleMessage("फैशन"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "सुविधाएँ वो महत्वपूर्ण हिस्सा हैं जो पॉज सेआस को पारंपरिक समाधानों से अलग बनाती हैं।"),
        "feedBack": MessageLookupByLibrary.simpleMessage("प्रतिक्रिया"),
        "firstName": MessageLookupByLibrary.simpleMessage("पहला नाम"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("हमसे जुड़ें\\nफेसबुक पर"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("हमसे जुड़ें\\nट्विटर पर"),
        "fontSide": MessageLookupByLibrary.simpleMessage("फ्रंट साइड"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("असीमित उपयोग के लिए"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("पासवर्ड भूल गए"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("पासवर्ड भूल गए?"),
        "formDate": MessageLookupByLibrary.simpleMessage("तारीख से"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("निःशुल्क डेटा बैकअप"),
        "freeLifeTimeUpdate":
            MessageLookupByLibrary.simpleMessage("मुफ़्त लाइफ़टाइम अपडेट"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("मुफ्त पैकेज"),
        "freePlan": MessageLookupByLibrary.simpleMessage("मुफ्त प्लान"),
        "from": MessageLookupByLibrary.simpleMessage("से"),
        "fullyPaid":
            MessageLookupByLibrary.simpleMessage("पूरी तरह से भुगतान किया गया"),
        "gallary": MessageLookupByLibrary.simpleMessage("गैलरी"),
        "generatingPDF":
            MessageLookupByLibrary.simpleMessage("पीडीएफ उत्पन्न कर रहा है"),
        "getOtp": MessageLookupByLibrary.simpleMessage("ओटीपी प्राप्त करें"),
        "guest": MessageLookupByLibrary.simpleMessage("मेहमान"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("क्या आपका कोई खाता नहीं है?"),
        "history": MessageLookupByLibrary.simpleMessage("इतिहास"),
        "home": MessageLookupByLibrary.simpleMessage("होम"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "हम आपकी जानकारी की सुरक्षा कैसे करते हैं"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "हम आपकी सूचना का किस प्रकार प्रयोग करते हैं"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("पहचान सत्यापित करें"),
        "image": MessageLookupByLibrary.simpleMessage("छवि"),
        "inHouseCantBeDelete": MessageLookupByLibrary.simpleMessage(
            "इनहाउस को हटाया नहीं जा सकता"),
        "inHouseCantBeEdited": MessageLookupByLibrary.simpleMessage(
            "इनहाउस संपादित नहीं किया जा सकता"),
        "inWord": MessageLookupByLibrary.simpleMessage("शब्दों में"),
        "incTax": MessageLookupByLibrary.simpleMessage("कर सहित"),
        "inclusive": MessageLookupByLibrary.simpleMessage("समावेशी"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("स्टॉक बढ़ाएं"),
        "inistrument": MessageLookupByLibrary.simpleMessage("उपकरण"),
        "instragram": MessageLookupByLibrary.simpleMessage("इंस्टाग्राम"),
        "invNo": MessageLookupByLibrary.simpleMessage("चालान नंबर"),
        "invoice": MessageLookupByLibrary.simpleMessage("चालान"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("चालान नंबर"),
        "invoiceSetting": MessageLookupByLibrary.simpleMessage("चालान सेटिंग"),
        "invoiceViewer": MessageLookupByLibrary.simpleMessage("चालान दर्शक"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("आइटम जोड़ा गया"),
        "kg": MessageLookupByLibrary.simpleMessage("किलोग्राम"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("केवाईसी सत्यापन"),
        "language": MessageLookupByLibrary.simpleMessage("भाषा"),
        "lastName": MessageLookupByLibrary.simpleMessage("उपनाम"),
        "ledger": MessageLookupByLibrary.simpleMessage("लेजर"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("लाइफटाइम खरीद"),
        "link": MessageLookupByLibrary.simpleMessage("लिंक"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("लिंक्डइन"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("लाइव चैट समर्थन"),
        "loading": MessageLookupByLibrary.simpleMessage("लोड हो रहा है"),
        "logIn": MessageLookupByLibrary.simpleMessage("लॉग इन करें"),
        "logOUt": MessageLookupByLibrary.simpleMessage("लॉग आउट"),
        "logOut": MessageLookupByLibrary.simpleMessage("लॉग आउट"),
        "login": MessageLookupByLibrary.simpleMessage("लॉग इन करें"),
        "logo": MessageLookupByLibrary.simpleMessage("लोगो"),
        "loss": MessageLookupByLibrary.simpleMessage("नुकसान"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("नुकसान / लाभ"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("नुकसान / लाभ विवरण"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("हानि/लाभ रिपोर्ट"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("हानि/लाभ रिपोर्ट"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("कम स्टॉक चेतावनी"),
        "maan": MessageLookupByLibrary.simpleMessage("मान"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "ब्रांडेड चालान के साथ अपने ग्राहकों पर स्थायी प्रभाव डालें। हमारा अनलिमिटेड अपग्रेड आपके चालान को अनुकूलित करने, एक पेशेवर स्पर्श जोड़ने का अनूठा लाभ प्रदान करता है जो आपके ब्रांड की पहचान को मजबूत करता है और ग्राहक वफादारी को बढ़ावा देता है।"),
        "manageYourBussinessWith": MessageLookupByLibrary.simpleMessage(
            "अपने व्यवसाय का प्रबंधन करें "),
        "manufactureDate": MessageLookupByLibrary.simpleMessage("निर्माण तिथि"),
        "margin": MessageLookupByLibrary.simpleMessage("मार्जिन"),
        "masterCard": MessageLookupByLibrary.simpleMessage("मास्टरकार्ड"),
        "message": MessageLookupByLibrary.simpleMessage("संदेश"),
        "messageHistory": MessageLookupByLibrary.simpleMessage("संदेश इतिहास"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "स्मार्ट बिजनेस ऐप मुफ्त है, उपयोग में आसान है। यह वास्तव में दुनिया भर में सबसे अच्छा पीओएस सिस्टम में से एक है।"),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "पॉज सेआस एक पूर्ण व्यवसाय समाधान है जिसमें स्टॉक, खाता, बिक्री, व्यय और लाभ/हानि होता है।"),
        "mobile": MessageLookupByLibrary.simpleMessage("मोबाइल"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("मोबाइल भुगतान"),
        "monthly": MessageLookupByLibrary.simpleMessage("मासिक"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("अधिक जानकारी"),
        "name": MessageLookupByLibrary.simpleMessage("अपना नाम दर्ज करें।"),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("नाम पहले से मौजूद है"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("नाम खाली नहीं हो सकता"),
        "noConnection":
            MessageLookupByLibrary.simpleMessage("कोई कनेक्शन नहीं"),
        "noData": MessageLookupByLibrary.simpleMessage("कोई डेटा नहीं"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("कोई डेटा उपलब्ध नहीं है"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("कोई डेटा नहीं मिला"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("कोई इतिहास नहीं मिला!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("कोई उत्पाद नहीं मिला"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("कोई उप कर चयनित नहीं"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("कोई लेन-देन नहीं मिला!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "उस ईमेल के लिए कोई उपयोगकर्ता नहीं मिला।"),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "कोई उपयोगकर्ता भूमिका नहीं मिली"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("सक्रिय उपयोगकर्ता नहीं"),
        "notProvided":
            MessageLookupByLibrary.simpleMessage("प्रदान नहीं किया गया"),
        "note": MessageLookupByLibrary.simpleMessage("नोट"),
        "notes": MessageLookupByLibrary.simpleMessage("नोट्स"),
        "notification": MessageLookupByLibrary.simpleMessage("सूचना"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("ओटीपी भेजा गया"),
        "office": MessageLookupByLibrary.simpleMessage("कार्यालय"),
        "ok": MessageLookupByLibrary.simpleMessage("ठीक है"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "पीओएस जिसमें बिक्री ट्रैकिंग, इन्वेंट्री प्रबंधन सहित बहुत सारी कार्यक्षमता शामिल है।"),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "यह प्रणाली आपको अपने ग्राहकों के लिए अपने परिचालन को बेहतर बनाने में मदद करती है।"),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "हमारे पीओएस सिस्टम को दैनिक परिचालन को स्वचालित रूप से सरल बनाना चाहिए, जिससे नेविगेट करना आसान हो जाएगा।"),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("आरंभिक शेष राशि"),
        "order": MessageLookupByLibrary.simpleMessage("आदेश"),
        "other": MessageLookupByLibrary.simpleMessage("अन्य"),
        "otp": MessageLookupByLibrary.simpleMessage("बंद करें"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("स्टॉक से बाहर"),
        "pacakge": MessageLookupByLibrary.simpleMessage("पैकेज"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("पैकेज विशेषताएँ"),
        "paid": MessageLookupByLibrary.simpleMessage("भुगतान किया"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("भुगतान की गई राशि"),
        "parties": MessageLookupByLibrary.simpleMessage("पार्टियों"),
        "partiesList":
            MessageLookupByLibrary.simpleMessage("पार्टियों की सूची"),
        "partyGST": MessageLookupByLibrary.simpleMessage("पार्टी जीएसटी"),
        "partyName": MessageLookupByLibrary.simpleMessage("पार्टी का नाम"),
        "password": MessageLookupByLibrary.simpleMessage("पासवर्ड"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "पासवर्ड और पुष्टि पासवर्ड मेल नहीं खाते"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("पासवर्ड खाली नहीं हो सकता"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("पासवर्ड मेल नहीं खाता"),
        "payCash": MessageLookupByLibrary.simpleMessage("नकद भुगतान करें"),
        "payStack": MessageLookupByLibrary.simpleMessage("पेस्टैक"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("Bkash के साथ भुगतान करें"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("PayPal के साथ भुगतान करें"),
        "payeeName":
            MessageLookupByLibrary.simpleMessage("प्राप्तकर्ता का नाम"),
        "payeeNumber":
            MessageLookupByLibrary.simpleMessage("प्राप्तकर्ता का नंबर"),
        "payment": MessageLookupByLibrary.simpleMessage("भुगतान"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("भुगतान राशि"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("भुगतान पूरा हुआ"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("भुगतान निर्देश:"),
        "paymentMethod":
            MessageLookupByLibrary.simpleMessage("भुगतान का तरीका"),
        "paymentType": MessageLookupByLibrary.simpleMessage("भुगतान का प्रकार"),
        "pdfView": MessageLookupByLibrary.simpleMessage("पीडीएफ व्यू"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("व्यक्तिगत जानकारी"),
        "phone": MessageLookupByLibrary.simpleMessage("फोन"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("फ़ोन नंबर"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "फोन नंबर पहले से उपयोग में है"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("फोन नंबर मान्य नहीं है"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("फोन नंबर आवश्यक है"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("फ़ाइल चुनें और अपलोड करें"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("समाप्ति तिथि चुनें"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("प्रारंभ तिथि चुनें"),
        "plan": MessageLookupByLibrary.simpleMessage("योजना"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("कृपया मात्रा जोड़ें"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "कृपया अपनी इंटरनेट कनेक्टिविटी देखें"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "कृपया पहले प्रिंटर कनेक्ट करें"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "कृपया अपने ब्लूटूथ प्रिंटर को कनेक्ट करें"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "कृपया एक लंबा पासवर्ड दर्ज करें"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "कृपया पासवर्ड की पुष्टि करें"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("कृपया एक पासवर्ड दर्ज करें"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "कृपया एक मान्य ईमेल दर्ज करें"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("कृपया नाम दर्ज करें"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("कृपया पासवर्ड दर्ज करें"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "कृपया नीचे दिए गए ईमेल पते पर पासवर्ड रीसेट लिंक प्राप्त करने के लिए अपना ईमेल पता दर्ज करें।"),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "कृपया लेन-देन संख्या दर्ज करें"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("कृपया राशि दर्ज करें"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "कृपया पहले एक श्रेणी का चयन करें"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("कृपया एक योजना चुनें"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "कृपया व्यवसाय श्रेणी का चयन करें"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "ऐप का उपयोग करने के लिए कृपया मान्य खरीद कोड का उपयोग करें"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("पॉज सेआस द्वारा पॉवरड"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("द्वारा संचालित"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("प्रीमियम ग्राहक सहायता"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("प्रीमियम प्लान"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("पिछले भुगतान राशियाँ"),
        "price": MessageLookupByLibrary.simpleMessage("मूल्य"),
        "print": MessageLookupByLibrary.simpleMessage("प्रिंट करें"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("प्रिंटिंग विकल्प"),
        "privacyPolicy": MessageLookupByLibrary.simpleMessage("गोपनीयता नीति"),
        "product": MessageLookupByLibrary.simpleMessage("उत्पाद"),
        "productCode": MessageLookupByLibrary.simpleMessage("उत्पाद कोड"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("उत्पाद कोड आवश्यक है"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("उत्पाद कोड/नाम"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("उत्पाद विवरण"),
        "productDetails": MessageLookupByLibrary.simpleMessage("उत्पाद विवरण"),
        "productList": MessageLookupByLibrary.simpleMessage("उत्पाद सूची"),
        "productName": MessageLookupByLibrary.simpleMessage("उत्पाद का नाम"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "इस गोदाम में उत्पाद नाम पहले से मौजूद है"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "उत्पाद का नाम पहले से जोड़ा गया है"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("उत्पाद का नाम आवश्यक है"),
        "products": MessageLookupByLibrary.simpleMessage("उत्पाद"),
        "profile": MessageLookupByLibrary.simpleMessage("प्रोफ़ाइल"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("प्रोफ़ाइल संपादन"),
        "profit": MessageLookupByLibrary.simpleMessage("लाभ"),
        "promo": MessageLookupByLibrary.simpleMessage("प्रोमो"),
        "promoCode": MessageLookupByLibrary.simpleMessage("प्रोमो कोड"),
        "purchase": MessageLookupByLibrary.simpleMessage("खरीद"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage("खरीदी अलार्म"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("खरीदी पुष्टि हुई"),
        "purchaseDetails": MessageLookupByLibrary.simpleMessage("खरीद विवरण"),
        "purchaseInvoice": MessageLookupByLibrary.simpleMessage("खरीद चालान"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("खरीद सूची"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("अभी खरीदें"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("प्रीमियम प्लान खरीदें"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("खरीद मूल्य"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("खरीद मूल्य आवश्यक है"),
        "purchaseRepoet": MessageLookupByLibrary.simpleMessage("खरीद रिपोर्ट"),
        "purchaseReports": MessageLookupByLibrary.simpleMessage("खरीद रिपोर्ट"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("खरीद रिपोर्ट"),
        "purchaseReturn": MessageLookupByLibrary.simpleMessage("खरीद रिटर्न"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("खरीद वापसी रिपोर्ट"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("खरीद संक्रमण"),
        "qty": MessageLookupByLibrary.simpleMessage("मात्रा"),
        "quantity": MessageLookupByLibrary.simpleMessage("मात्रा"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("हाल की लेन-देन"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("पिन प्राप्त हुआ"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("संदर्भ संख्या"),
        "register": MessageLookupByLibrary.simpleMessage("रजिस्टर करें"),
        "registering":
            MessageLookupByLibrary.simpleMessage("पंजीकरण हो रहा है"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("शेष बकाया"),
        "remove": MessageLookupByLibrary.simpleMessage("हटाएं"),
        "reports": MessageLookupByLibrary.simpleMessage("रिपोर्ट्स"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("अनुरोध भेजा गया है"),
        "resendCode": MessageLookupByLibrary.simpleMessage("कोड पुनः भेजें"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("ओटीपी पुनः भेजें: "),
        "retailer": MessageLookupByLibrary.simpleMessage("खुदरावाला"),
        "retur": MessageLookupByLibrary.simpleMessage("वापसी"),
        "returN": MessageLookupByLibrary.simpleMessage("वापसी"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("वापसी राशि"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("वापसी मात्रा"),
        "revenue": MessageLookupByLibrary.simpleMessage("राजस्व"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "अपने व्यावसायिक डेटा को सहजता से सुरक्षित रखें। हमारे पॉस सास पीओएस अनलिमिटेड अपग्रेड में मुफ्त डेटा बैकअप शामिल है, यह सुनिश्चित करते हुए कि आपकी बहुमूल्य जानकारी किसी भी अप्रत्याशित घटना से सुरक्षित है। उस पर ध्यान केंद्रित करें जो वास्तव में मायने रखता है - आपके व्यवसाय की वृद्धि।"),
        "saleAmount": MessageLookupByLibrary.simpleMessage("बिक्री राशि"),
        "saleDetails":
            MessageLookupByLibrary.simpleMessage("बेची गई वस्तुओं का विवरण"),
        "salePrice": MessageLookupByLibrary.simpleMessage("बेचने की कीमत"),
        "saleReports": MessageLookupByLibrary.simpleMessage("बिक्री रिपोर्ट"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("बेची गई वस्तुओं की रिपोर्ट"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("बिक्री वापसी"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("बिक्री वापसी रिपोर्ट"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("बिक्री सेटिंग"),
        "sales": MessageLookupByLibrary.simpleMessage("बिक्री"),
        "salesAndPurchaseReports": MessageLookupByLibrary.simpleMessage(
            "बेचने और खरीदने की रिपोर्टें"),
        "salesList": MessageLookupByLibrary.simpleMessage("बिक्री सूची"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("बिक्री वापसी"),
        "save": MessageLookupByLibrary.simpleMessage("सहेजें"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("सहेजें और प्रकाशित करें"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("परिवर्तन सहेजें"),
        "saving": MessageLookupByLibrary.simpleMessage("सहेज रहा है"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("उत्पाद QR कोड स्कैन करें"),
        "search": MessageLookupByLibrary.simpleMessage("खोजें"),
        "searchByProductCodeOrName":
            MessageLookupByLibrary.simpleMessage("उत्पाद कोड या नाम से खोजें"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("सभी प्रोमो कोड देखें"),
        "select": MessageLookupByLibrary.simpleMessage("चुनें"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "वापसी के लिए एक उत्पाद चुनें"),
        "selectBrand":
            MessageLookupByLibrary.simpleMessage("ब्रांड का चयन करें"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("श्रेणी का चयन करें"),
        "selectContacts": MessageLookupByLibrary.simpleMessage("संपर्क चुनें"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("उत्पाद श्रेणी का चयन करें"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("दुकान श्रेणी का चयन करें"),
        "selectTax": MessageLookupByLibrary.simpleMessage("कर का चयन करें"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("कर प्रकार का चयन करें"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("इकाई का चयन करें"),
        "selectvariations": MessageLookupByLibrary.simpleMessage("मान चुनें: "),
        "seller": MessageLookupByLibrary.simpleMessage("विक्रेता"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("द्वारा बेची गई"),
        "send": MessageLookupByLibrary.simpleMessage("भेजें"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("ईमेल भेजें"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("संदेश भेजें"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("रीसेट लिंक भेजें"),
        "sendSms": MessageLookupByLibrary.simpleMessage("एसएमएस भेजें"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("व्हाट्सएप संदेश भेजें"),
        "sendingEmail":
            MessageLookupByLibrary.simpleMessage("ईमेल भेजा जा रहा है"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("संदेश भेजा जा रहा है"),
        "serviceShipping": MessageLookupByLibrary.simpleMessage("सेवा/शिपिंग"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("अपनी प्रोफ़ाइल सेट करें"),
        "setting": MessageLookupByLibrary.simpleMessage("सेटिंग्स"),
        "share": MessageLookupByLibrary.simpleMessage("साझा करें"),
        "shopGST": MessageLookupByLibrary.simpleMessage("दुकान जीएसटी"),
        "signIn": MessageLookupByLibrary.simpleMessage("साइन इन करें"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("ईमेल से साइन इन करें"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("ग्राहक का हस्ताक्षर"),
        "size": MessageLookupByLibrary.simpleMessage("साइज"),
        "skip": MessageLookupByLibrary.simpleMessage("छोड़ें"),
        "sms": MessageLookupByLibrary.simpleMessage("एसएमएस"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("सोशल मार्केटिंग"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "क्षमा करें, आपके पास इस सेवा का उपयोग करने की अनुमति नहीं है"),
        "startDate": MessageLookupByLibrary.simpleMessage("प्रारंभ तिथि"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("नई बिक्री शुरू करें"),
        "startTypingToSearch":
            MessageLookupByLibrary.simpleMessage("खोजने के लिए टाइप करें"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "बिना किसी अतिरिक्त लागत के तकनीकी प्रगति में सबसे आगे रहें। हमारा पॉज़ सास पीओएस अनलिमिटेड अपग्रेड यह सुनिश्चित करता है कि आपकी उंगलियों पर हमेशा नवीनतम उपकरण और सुविधाएं हों, यह गारंटी देता है कि आपका व्यवसाय अत्याधुनिक बना रहेगा।"),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("अभी भी अप्रदत्त"),
        "stock": MessageLookupByLibrary.simpleMessage("स्टॉक"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("स्टॉक आवश्यक है"),
        "stockList": MessageLookupByLibrary.simpleMessage("स्टॉक सूची"),
        "stocks": MessageLookupByLibrary.simpleMessage("स्टॉक"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "एक्सेल फ़ाइल बनाने के लिए भंडारण अनुमति आवश्यक है"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("उप कर सूची"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("उप कर"),
        "subTotal": MessageLookupByLibrary.simpleMessage("उपकुल"),
        "submit": MessageLookupByLibrary.simpleMessage("प्रस्तुत करें"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "हमारे\\nयूट्यूब चैनल की सदस्यता लें"),
        "subscription": MessageLookupByLibrary.simpleMessage("सदस्यता"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("सफलतापूर्वक पूरा हुआ"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("सफलतापूर्वक लॉगआउट"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("सफलतापूर्वक अपडेट किया गया"),
        "supplier": MessageLookupByLibrary.simpleMessage("आपूर्तिकर्ता"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("आपूर्तिकर्ता का नाम"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("स्विफ्ट कोड"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "अपनी जानकारी की जांच के लिए एक पहचान पत्र लें"),
        "tap": MessageLookupByLibrary.simpleMessage("टैप"),
        "tax": MessageLookupByLibrary.simpleMessage("कर"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("कर समूह"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("कर प्रतिशत"),
        "taxRate": MessageLookupByLibrary.simpleMessage("कर दर"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "कर दरें - अपनी कर दरें प्रबंधित करें"),
        "taxReport": MessageLookupByLibrary.simpleMessage("कर रिपोर्ट"),
        "taxType": MessageLookupByLibrary.simpleMessage("कर प्रकार"),
        "taxes": MessageLookupByLibrary.simpleMessage("कर"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("नियम और शर्तें"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("उपयोग की शर्तें"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("नियम और गोपनीयता"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "आपके बकाये के भुगतान के लिए धन्यवाद"),
        "thankYou": MessageLookupByLibrary.simpleMessage("धन्यवाद"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("आपकी खरीदारी के लिए धन्यवाद"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "उस ईमेल के लिए खाता पहले से मौजूद है"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "एक्सेल फ़ाइल पहले ही डाउनलोड हो चुकी है"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "नाम से सब कुछ पता चलता है। पॉज़ सास पीओएस अनलिमिटेड के साथ, आपके उपयोग पर कोई सीमा नहीं है। चाहे आप मुट्ठी भर लेन-देन कर रहे हों या ग्राहकों की भीड़ का अनुभव कर रहे हों, आप आत्मविश्वास के साथ काम कर सकते हैं, यह जानते हुए कि आप सीमाओं से बंधे नहीं हैं"),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "प्रदान किया गया पासवर्ड बहुत कमजोर है"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "बिक्री हटाई जाएगी और इस खरीद से संबंधित सभी डेटा हटा दिए जाएंगे। क्या आप इसे हटाना चाहते हैं?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "बिक्री हटाई जाएगी और इस बिक्री से संबंधित सभी डेटा हटा दिए जाएंगे। क्या आप इसे हटाना चाहते हैं?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "उपयोगकर्ता हटा दिया जाएगा और सभी डेटा आपके खाते से हटा दिया जाएगा। क्या आप सुनिश्चित हैं कि आप इसे हटाना चाहते हैं?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "उपयोगकर्ता और सभी डेटा आपके खाते से हटा दिए जाएंगे। क्या आप सुनिश्चित हैं कि आप इसे हटाना चाहते हैं"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("तृतीय-पक्ष सेवाएँ"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "इस श्रेणी को हटाया नहीं जा सकता"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(इस माह)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "यह उत्पाद पहले से जोड़ा गया है"),
        "title": MessageLookupByLibrary.simpleMessage("शीर्षक"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("शीर्षक खाली नहीं हो सकता"),
        "to": MessageLookupByLibrary.simpleMessage("तक"),
        "toDate": MessageLookupByLibrary.simpleMessage("तारीख तक"),
        "today": MessageLookupByLibrary.simpleMessage("आज"),
        "total": MessageLookupByLibrary.simpleMessage("कुल"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("कुल राशि"),
        "totalCollected": MessageLookupByLibrary.simpleMessage("कुल संकलित"),
        "totalDue": MessageLookupByLibrary.simpleMessage("कुल बकाया"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("कुल खर्च"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("कुल हानि"),
        "totalPayable": MessageLookupByLibrary.simpleMessage("कुल देय"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("कुल मूल्य"),
        "totalProducts": MessageLookupByLibrary.simpleMessage("कुल उत्पाद"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("कुल लाभ"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("कुल खरीद"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("कुल वापसी राशि"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("कुल वापसी"),
        "totalSale": MessageLookupByLibrary.simpleMessage("कुल बिक्री"),
        "totalStock": MessageLookupByLibrary.simpleMessage("कुल स्टॉक"),
        "totalValue": MessageLookupByLibrary.simpleMessage("कुल मूल्य"),
        "totalVat": MessageLookupByLibrary.simpleMessage("कुल वैट"),
        "totals": MessageLookupByLibrary.simpleMessage("कुल: "),
        "transaction": MessageLookupByLibrary.simpleMessage("लेन-देन"),
        "transactionId": MessageLookupByLibrary.simpleMessage("लेन-देन आईडी"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("पुनः प्रयास करें"),
        "twitter": MessageLookupByLibrary.simpleMessage("ट्विटर"),
        "type": MessageLookupByLibrary.simpleMessage("प्रकार"),
        "unitName": MessageLookupByLibrary.simpleMessage("इकाई का नाम"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("यूनिट मूल्य"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("इकाई मूल्य"),
        "units": MessageLookupByLibrary.simpleMessage("इकाइयाँ"),
        "unlimited": MessageLookupByLibrary.simpleMessage("असीमित"),
        "unlimitedUsage": MessageLookupByLibrary.simpleMessage("असीमित उपयोग"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "हमारी विशेषज्ञ टीम के नेतृत्व में व्यक्तिगत प्रशिक्षण सत्रों के साथ पॉज़ सास पीओएस की पूरी क्षमता को अनलॉक करें। बुनियादी बातों से लेकर उन्नत तकनीकों तक, हम सुनिश्चित करते हैं कि आप अपनी व्यावसायिक प्रक्रियाओं को अनुकूलित करने के लिए सिस्टम के हर पहलू का उपयोग करने में अच्छी तरह से वाकिफ हैं।"),
        "unpaid": MessageLookupByLibrary.simpleMessage("अवैतनिक"),
        "update": MessageLookupByLibrary.simpleMessage("अपडेट करें"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("संपर्क अपडेट करें"),
        "updateNow": MessageLookupByLibrary.simpleMessage("अब अपडेट करें"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("उत्पाद अपडेट करें"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "अपनी योजना पहले अपडेट करें, आपकी सीमा समाप्त हो गई है"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("अपनी प्रोफ़ाइल अपडेट करें"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "बेहतर प्रभाव से अपने डॉक्टर को जोड़ने के लिए अपनी प्रोफ़ाइल अपडेट करें"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "अपनी प्रोफ़ाइल अपडेट करें ताकि आपका ग्राहक बेहतर प्रभाव पा सके"),
        "updated": MessageLookupByLibrary.simpleMessage("अद्यतन किया गया"),
        "upload": MessageLookupByLibrary.simpleMessage("अपलोड"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("दस्तावेज़ अपलोड करें"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("अपलोड हो गया"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("फ़ाइल अपलोड करें"),
        "upplier": MessageLookupByLibrary.simpleMessage("आपूर्तिकर्ता"),
        "usbC": MessageLookupByLibrary.simpleMessage("यूएसबी सी"),
        "use": MessageLookupByLibrary.simpleMessage("उपयोग करें"),
        "useMobiPos":
            MessageLookupByLibrary.simpleMessage("पॉज सेआस का उपयोग करें"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("सिस्टम का उपयोग"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("उपयोगकर्ता हटा दिया गया है"),
        "userRole": MessageLookupByLibrary.simpleMessage("उपयोगकर्ता भूमिका"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("उपयोगकर्ता भूमिका विवरण"),
        "userTitle": MessageLookupByLibrary.simpleMessage("उपयोगकर्ता शीर्षक"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "उपयोगकर्ता का शीर्षक खाली नहीं हो सकता"),
        "value": MessageLookupByLibrary.simpleMessage("मूल्य"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("वैट लागू नहीं होता"),
        "verifyOtp":
            MessageLookupByLibrary.simpleMessage("ओटीपी सत्यापित कर रहे हैं"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("फ़ोन नंबर सत्यापित करें"),
        "viewAll": MessageLookupByLibrary.simpleMessage("सभी देखें"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("विवरण देखें"),
        "walkInCustomer": MessageLookupByLibrary.simpleMessage("वॉक-इन ग्राहक"),
        "warehouse": MessageLookupByLibrary.simpleMessage("गोदाम"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("गोदाम पहले से मौजूद है"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("गोदाम सूची"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("गोदाम का नाम"),
        "warranty": MessageLookupByLibrary.simpleMessage("वारंटी"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "हमने एक ईमेल भेजा है जिसमें निर्देश हैं कि आप पासवर्ड रीसेट कैसे कर सकते हैं:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "हम अपने ऐप की कार्यक्षमता का समर्थन करने के लिए एनालिटिक्स प्रदाताओं और भुगतान प्रोसेसर जैसी तृतीय-पक्ष सेवाओं का उपयोग कर सकते हैं। जब आप हमारे ऐप का उपयोग करते हैं तो ये तृतीय-पक्ष सेवाएँ आपके बारे में जानकारी एकत्र कर सकती हैं। कृपया ध्यान दें कि हम इन तृतीय-पक्ष सेवाओं की गोपनीयता प्रथाओं के लिए ज़िम्मेदार नहीं हैं।"),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "हम आपकी व्यक्तिगत जानकारी की सुरक्षा के लिए उद्योग-मानक उपाय करते हैं, जिसमें एन्क्रिप्शन और सुरक्षित भंडारण शामिल हैं। हम आपकी जानकारी तक पहुंच को केवल अधिकृत कर्मियों तक ही सीमित रखते हैं।"),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "हम निर्बाध संचालन के महत्व को समझते हैं। इसीलिए हमारा चौबीसों घंटे समर्थन आपकी सहायता के लिए उपलब्ध है, चाहे वह त्वरित प्रश्न हो या व्यापक चिंता। बेजोड़ ग्राहक सेवा का अनुभव लेने के लिए कभी भी, कहीं भी कॉल या व्हाट्सएप के माध्यम से हमसे जुड़ें।"),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "हम आपकी व्यक्तिगत जानकारी का उपयोग आपको हमारे ऐप पर सर्वोत्तम संभव अनुभव प्रदान करने के लिए करते हैं, जिसमें आपकी सामग्री अनुशंसाओं को वैयक्तिकृत करना, आपको विशेषज्ञों से जोड़ना और हमारे ऐप की कार्यक्षमता में सुधार करना शामिल है। हम आपकी जानकारी का उपयोग अपडेट, प्रचार, या हमारे ऐप से संबंधित अन्य जानकारी के बारे में आपसे संवाद करने के लिए भी कर सकते हैं।"),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "हम भुगतान की समीक्षा करेंगे और इसे 1-2 घंटों के भीतर अनुमोदित करेंगे"),
        "weekly": MessageLookupByLibrary.simpleMessage("साप्ताहिक"),
        "weight": MessageLookupByLibrary.simpleMessage("वजन"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("नया क्या है"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("होलसेलर"),
        "wholeSalePrice": MessageLookupByLibrary.simpleMessage("होलसेल मूल्य"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("थोक मूल्य"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("थोक विक्रेता"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("जल्द ही जोड़ा जाएगा"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("समाप्त होगा"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("अपना संदेश यहाँ लिखें"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("गलत ओटीपी"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "उस उपयोगकर्ता के लिए गलत पासवर्ड प्रदान किया गया है।"),
        "yearly": MessageLookupByLibrary.simpleMessage("वार्षिक"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("हां, स्थायी रूप से हटाएं"),
        "youAreNotAValidUser": MessageLookupByLibrary.simpleMessage(
            "आप एक मान्य उपयोगकर्ता नहीं हैं"),
        "youAreUsing":
            MessageLookupByLibrary.simpleMessage("आपका उपयोग हो रहा है"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "आप देय राशि से अधिक भुगतान नहीं कर सकते"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("आपके पास एक ईमेल है"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "आप सफलतापूर्वक अपने खाते में लॉग इन हो गए हैं। Pos Saas  के साथ रहें।"),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("आपको अनुमति देनी होगी"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "आपको अपने खाते में पुनः लॉगिन करना होगा।"),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "खरीदारी करने से पहले आपको पहचान सत्यापित करनी होगी"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("आपका संदेश बना रहता है"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("आपका पैकेज"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "आपका पैकेज 5 दिनों में समाप्त हो जाएगा")
      };
}
