// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a ta locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'ta';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("தொடர்க"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("GST எண்"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("சூதான விலை"),
        "MRPIsRequired": MessageLookupByLibrary.simpleMessage("MRP தேவை"),
        "OK": MessageLookupByLibrary.simpleMessage("சரி"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("பேபால்"),
        "PhNo": MessageLookupByLibrary.simpleMessage("தொலைபேசி எண்"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("எஸ்.எல்"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT குறியீடு"),
        "Snacks": MessageLookupByLibrary.simpleMessage("நன்கு"),
        "TAX": MessageLookupByLibrary.simpleMessage("வரி"),
        "Uploading": MessageLookupByLibrary.simpleMessage("ஏற்றுவது"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("பயனர் தலைப்பு"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "உங்கள் போட்டி இன்று காலாவதியாகும்\n\nதயவுசெய்து மீண்டும் வாங்கவும்"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) The System is provided solely for the\npurpose of facilitating point of sale\ntransactions andrelatedactivities in your\nbusiness."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) To use the System, you may be\nrequired to create an account. You\nagree to provide accurate, current, and\ncomplete information during\nthe registration process and toupdate\nsuchinformationto keep itaccurate\nand complete."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("பற்றி செய்தி"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("எங்களைப் பற்றி"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Acceptance of Terms"),
        "accountName": MessageLookupByLibrary.simpleMessage("கணக்கு பெயர்"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("கணக்கு எண்"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Account Registration"),
        "acton": MessageLookupByLibrary.simpleMessage("செயல்"),
        "add": MessageLookupByLibrary.simpleMessage("சேர்க்கவும்"),
        "addBrand": MessageLookupByLibrary.simpleMessage("பிராண்டு சேர்க்க"),
        "addCategory": MessageLookupByLibrary.simpleMessage("வகை சேர்க்க"),
        "addContact": MessageLookupByLibrary.simpleMessage("தொடர்பு சேர்க்க"),
        "addCustomer":
            MessageLookupByLibrary.simpleMessage("வாடிக்கையாளரை சேர்க்கவும்"),
        "addDelivery":
            MessageLookupByLibrary.simpleMessage("விநியோகத்தைச் சேர்க்கவும்"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("விளக்கத்தைச் சேர்க்கவும்"),
        "addDescription":
            MessageLookupByLibrary.simpleMessage("குறிப்பு சேர்க்க"),
        "addDiscount":
            MessageLookupByLibrary.simpleMessage("தள்ளுபடியைச் சேர்க்கவும்"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("ஆவண அடையாளம் சேர்க்கவும்"),
        "addDucument":
            MessageLookupByLibrary.simpleMessage("ஆவணத்தை சேர்க்கவும்"),
        "addExpense": MessageLookupByLibrary.simpleMessage("செலவை சேர்க்கவும்"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("செலவு வகையை சேர்க்கவும்"),
        "addItems": MessageLookupByLibrary.simpleMessage("பொருட்களை சேர்க்க"),
        "addNew": MessageLookupByLibrary.simpleMessage("புதியதைச் சேர்க்கவும்"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("புதிய முகவரி சேர்க்கவும்"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("புதிய பொருள் சேர்க்கவும்"),
        "addNewTax":
            MessageLookupByLibrary.simpleMessage("புதிய வரி சேர்க்கவும்"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "ஒன்றை/பல வரி வகைகளுடன் புதிய வரியைச் சேர்க்கவும்"),
        "addNote": MessageLookupByLibrary.simpleMessage("குறிப்பு சேர்க்கவும்"),
        "addProductFirst": MessageLookupByLibrary.simpleMessage(
            "முதலில் பொருளைச் சேர்க்கவும்"),
        "addPromoCode": MessageLookupByLibrary.simpleMessage(
            "ப்ரோமோ குறியீட்டைச் சேர்க்கவும்"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("வாங்கல் சேர்க்க"),
        "addSales": MessageLookupByLibrary.simpleMessage("விற்பனை சேர்க்க"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("வெற்றிகரமாக சேர்க்கப்பட்டது"),
        "addUnit": MessageLookupByLibrary.simpleMessage("யூனிட் சேர்க்க"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("பயனர் பங்கு சேர்க்க"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("வெற்றியாக சேர்க்கப்பட்டது"),
        "addedToCart": MessageLookupByLibrary.simpleMessage(
            "கார்டில் சேர்க்கப்பட்டுள்ளது"),
        "address": MessageLookupByLibrary.simpleMessage("முகவரி"),
        "admin": MessageLookupByLibrary.simpleMessage("நிர்வாகி"),
        "all": MessageLookupByLibrary.simpleMessage("அனைத்தும்"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("அனைத்து வணிக தீர்வுகளும்"),
        "alreadyAdded":
            MessageLookupByLibrary.simpleMessage("ஏற்கனவே சேர்க்கப்பட்டுள்ளது"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("ஏற்கனவே உள்ளது"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("ஏற்கனவே ஒரு கணக்கு உள்ளதா"),
        "amount": MessageLookupByLibrary.simpleMessage("தொகை"),
        "anEmailHasBeenSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "ஒரு மின்னஞ்சல் அனுப்பப்பட்டுள்ளது\nஉங்கள் காப்பகத்தில் சரிபார்க்கவும்"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "ஆன்ட்ராய்டு & iOS பயனர் ஆதரணம்"),
        "applicableTax": MessageLookupByLibrary.simpleMessage("பொருந்தும் வரி"),
        "apply": MessageLookupByLibrary.simpleMessage("பிரிக்க"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "இந்த ரசீது அழிக்க உறுதியாக இருக்கிறீர்களா"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "இந்த விற்பனையை அழிக்க உறுதியாக இருக்கிறீர்களா"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "இந்த பயனரை நீக்க விரும்புகிறீர்களா?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "இந்த வரிச் சுமையை நீக்க விரும்புகிறீர்களா?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "இந்த வரிச் சுமை குழுவை நீக்க விரும்புகிறீர்களா?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "இந்த கூடுகளை நீக்க விரும்புகிறீர்களா?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "இந்த பயனரை நீக்க உறுதியளிக்கின்றீர்களா?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("அங்கீகார கையொப்பம்"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) You are responsible for\nmaintainingthe confidentiality of your\naccount and password andfor restricting\naccess to your account. You accept\nresponsibility for all activities that\noccur under your account."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) You must be at least 18 years old or the\nlegal age of majority in your jurisdiction to\nuse the System."),
        "backSide": MessageLookupByLibrary.simpleMessage("பின்புகை"),
        "backToHome": MessageLookupByLibrary.simpleMessage("வீட்டிற்கு மீட்க"),
        "balance": MessageLookupByLibrary.simpleMessage("இருப்பு"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("பங்களாதேஷ்"),
        "bank": MessageLookupByLibrary.simpleMessage("பாங்கு"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("வங்கிக் கணக்கு நாணயம்"),
        "bankInformation": MessageLookupByLibrary.simpleMessage("வங்கி விவரம்"),
        "bankName": MessageLookupByLibrary.simpleMessage("வங்கி பெயர்"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("வங்கி மாற்றம்"),
        "barcodeFound": MessageLookupByLibrary.simpleMessage(
            "பார்கோடு கண்டுபிடிக்கப்பட்டது"),
        "billInvoice":
            MessageLookupByLibrary.simpleMessage("விலைப்பட்டியல்/ரசீது"),
        "billTo": MessageLookupByLibrary.simpleMessage("கோரிக்கை அனுப்பினர்"),
        "branchName": MessageLookupByLibrary.simpleMessage("கிளை பெயர்"),
        "brand": MessageLookupByLibrary.simpleMessage("பிராண்ட்"),
        "brandName": MessageLookupByLibrary.simpleMessage("பிராண்ட் பெயர்"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("மூன்று\nஏற்றுமதி"),
        "businessCategory": MessageLookupByLibrary.simpleMessage("வணிக வகை"),
        "buy": MessageLookupByLibrary.simpleMessage("வாங்க"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("பிரீமியம் திட்டம் வாங்குக"),
        "buySms": MessageLookupByLibrary.simpleMessage("எஸ் எம் எஸ் வாங்குக"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "By accessing or using the Point of Sale (POS) System (the \"System\") provided by [Your Company Name] (\"Company\"), you agree to be bound by these Terms of Use. If you do not agree to these Terms of Use, do not use the System."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) You are responsible for ensuring that your\naccess to and use of the System is in\ncompliance with all applicable laws and\nregulations."),
        "cacel": MessageLookupByLibrary.simpleMessage("ரத்துசெய்"),
        "call": MessageLookupByLibrary.simpleMessage("அழை"),
        "callForEmergencySupport":
            MessageLookupByLibrary.simpleMessage("அவசர உதவிக்கு அழைக்கவும்"),
        "camera": MessageLookupByLibrary.simpleMessage("கேமரா"),
        "cancel": MessageLookupByLibrary.simpleMessage("ரத்து செய்யவும்"),
        "cancelAllProduct": MessageLookupByLibrary.simpleMessage(
            "அனைத்து தயாரிப்புகளை ரத்து செய்க"),
        "capacity": MessageLookupByLibrary.simpleMessage("செய்தித்தன்மை"),
        "card": MessageLookupByLibrary.simpleMessage("கார்ட்"),
        "cash": MessageLookupByLibrary.simpleMessage("பணம்"),
        "cashFree": MessageLookupByLibrary.simpleMessage("நகையை விடுங்கள்"),
        "categories": MessageLookupByLibrary.simpleMessage("வகைகள்"),
        "category": MessageLookupByLibrary.simpleMessage("வகை"),
        "categoryName": MessageLookupByLibrary.simpleMessage("வகை பெயர்"),
        "categoryNameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("வகை பெயர் ஏற்கெனவே உள்ளது"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("வகை பெயர்"),
        "change": MessageLookupByLibrary.simpleMessage("மாற்று?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("கடவுச்சொல்லை மாற்று"),
        "checkEmail":
            MessageLookupByLibrary.simpleMessage("மின்னஞ்சல் சரிபார்க்கவும்"),
        "choseACustomer": MessageLookupByLibrary.simpleMessage(
            "ஒரு வாடிக்கையாளரைத் தேர்வு செய்க"),
        "choseASupplier": MessageLookupByLibrary.simpleMessage(
            "ஒரு விற்பனையாளரைத் தேர்வு செய்க"),
        "choseYourFeature": MessageLookupByLibrary.simpleMessage(
            "உங்கள் அம்சங்களைத் தேர்ந்தெடுக்கவும்"),
        "clarence": MessageLookupByLibrary.simpleMessage("கிளேரன்ஸ்"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("இணைக்க கிளிக் செய்க"),
        "close": MessageLookupByLibrary.simpleMessage("மூடு"),
        "color": MessageLookupByLibrary.simpleMessage("வண்ணம்"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(பல வரிச் சுமைகளை உள்ளடக்கியது)"),
        "comingSoon":
            MessageLookupByLibrary.simpleMessage("எவரும் வருகிறார்கள்"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("கம்பெனி முகவரி"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("கம்பெனி மற்றும் ஷாப் பெயர்"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("கம்பனி & வணிகப் பெயர்"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("பரிவர்த்தனையை முடிக்கவும்"),
        "confirmPassword": MessageLookupByLibrary.simpleMessage(
            "கடவுச்சொல்லை உறுதியாக்கவும்"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("திருப்பியை உறுதிசெய்க"),
        "congratulations": MessageLookupByLibrary.simpleMessage("மகிழ்ச்சி"),
        "contactUs":
            MessageLookupByLibrary.simpleMessage("எங்களை தொடர்பு கொள்ளுங்கள்"),
        "continu": MessageLookupByLibrary.simpleMessage("தொடர்க"),
        "country": MessageLookupByLibrary.simpleMessage("நாடு"),
        "create": MessageLookupByLibrary.simpleMessage("உருவாக்கு"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("இலவச கணக்கை உருவாக்கு"),
        "createdAndSaved": MessageLookupByLibrary.simpleMessage(
            "உருவாக்கப்பட்டது மற்றும் சேமிக்கப்பட்டது"),
        "currency": MessageLookupByLibrary.simpleMessage("நாணயம்"),
        "currentStock": MessageLookupByLibrary.simpleMessage("தற்போதைய பங்கு"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("கச்சாடித் தாரமைக்கு"),
        "customer": MessageLookupByLibrary.simpleMessage("வாடிக்கையாளர்"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("வாடிக்கையாளர் விவரங்கள்"),
        "customerGST":
            MessageLookupByLibrary.simpleMessage("வாடிக்கையாளர் GST"),
        "customerName":
            MessageLookupByLibrary.simpleMessage("வாடிக்கையாளர் பெயர்"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("தினசரி பரிவர்த்தனை"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Dashboard Overview"),
        "dataSavedSuccessfully": MessageLookupByLibrary.simpleMessage(
            "தரவுகள் வெற்றியாக சேமிக்கப்பட்டது"),
        "date": MessageLookupByLibrary.simpleMessage("தேதி"),
        "day": MessageLookupByLibrary.simpleMessage("நாள்"),
        "dealer": MessageLookupByLibrary.simpleMessage("வாணிகர்"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("வாணிக விலை"),
        "defaultVATPercentage": MessageLookupByLibrary.simpleMessage(
            "இயல்பான மதிப்பு சேர்க்கை சதவீதம்"),
        "delete": MessageLookupByLibrary.simpleMessage("நீக்கு"),
        "deleting": MessageLookupByLibrary.simpleMessage("அழிக்கின்றேன்"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("விநியோக முகவரி"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("விநியோக முகவரிகள்"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("விநியோக கட்டணம்"),
        "describtion": MessageLookupByLibrary.simpleMessage("விளக்கம்"),
        "description": MessageLookupByLibrary.simpleMessage("விளக்கம்"),
        "descriptionCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "விளக்கம் காலியாக இருக்க முடியாது"),
        "details": MessageLookupByLibrary.simpleMessage("விவரங்கள்"),
        "discount": MessageLookupByLibrary.simpleMessage("தள்ளுபடி"),
        "doNotDistrub":
            MessageLookupByLibrary.simpleMessage("விலக்கக்கூடியதல்லை"),
        "done": MessageLookupByLibrary.simpleMessage("முடிந்தது"),
        "downloadExcelFormat": MessageLookupByLibrary.simpleMessage(
            "Excel வடிவத்தைப் பதிவிறக்கவும்"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "பதிவிறக்கம் செய்யப்பட்டு, பதிவிறக்கம் செய்யப்பட்ட கோப்பில் வெற்றியாக பதிவிறக்கப்பட்டது"),
        "due": MessageLookupByLibrary.simpleMessage("பட்டியல்"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("கட்டண தொகை:"),
        "dueCollection":
            MessageLookupByLibrary.simpleMessage("கட்டணம் சேகரிக்கை"),
        "dueCollectionReports": MessageLookupByLibrary.simpleMessage(
            "கடவுச்சொல் சேகரிப்பு அறிக்கைகள்"),
        "dueList": MessageLookupByLibrary.simpleMessage("பட்டியல் வரிசை"),
        "dueReports": MessageLookupByLibrary.simpleMessage("கடன் அறிக்கை"),
        "duration": MessageLookupByLibrary.simpleMessage("காலம்"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("காலம்: ஆரம்பம்"),
        "edit": MessageLookupByLibrary.simpleMessage("திருத்து"),
        "editPurchaseInvoice": MessageLookupByLibrary.simpleMessage(
            "வாங்குதல் விலைப்பட்டியலை திருத்து"),
        "editSalesInvoice": MessageLookupByLibrary.simpleMessage(
            "விற்பனை விலைப்பட்டியலை திருத்து"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("சமூக மாதிரி திருத்து"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("முட்டிலும் திருத்தப்பட்டது"),
        "editTax":
            MessageLookupByLibrary.simpleMessage("வரிச் சுமையை திருத்தவும்"),
        "editTaxGroup": MessageLookupByLibrary.simpleMessage(
            "வரிச் சுமை குழுவை திருத்தவும்"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("கூடத்தைத் திருத்தவும்"),
        "email": MessageLookupByLibrary.simpleMessage("மின்னஞ்சல்"),
        "emailAddress":
            MessageLookupByLibrary.simpleMessage("மின்னஞ்சல் முகவரி"),
        "emailCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "இமெயில் காலியாக இருக்க முடியாது"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "மின்னஞ்சல் அனுப்பப்பட்டது! உங்கள் இன்பாக்ஸைப் பரிசோதிக்கவும்"),
        "endDate": MessageLookupByLibrary.simpleMessage("முடிவு தேதி"),
        "enterAValidAmount": MessageLookupByLibrary.simpleMessage(
            "செல்லுபடியாகும் தொகையை உள்ளிடவும்"),
        "enterAValidDiscount": MessageLookupByLibrary.simpleMessage(
            "சரியான தள்ளுபடியைப் பதிவு செய்க"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "செல்லுபடியாகும் தொலைபேசி எண்ணை உள்ளிடவும்"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("சரியான விலை பதிவு செய்க"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("சரியான அளவை பதிவு செய்க"),
        "enterAddress":
            MessageLookupByLibrary.simpleMessage("முகவரி உள்ளிடவும்"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("தொகை உள்ளிடவும்."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("பிராண்ட் பெயரை உள்ளிடவும்"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("செய்தித்தன்மை உள்ளிடவும்"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("வகை பெயரை உள்ளிடவும்"),
        "enterColor": MessageLookupByLibrary.simpleMessage("வண்ணம் உள்ளிடவும்"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "வாடிக்கையாளர் GST எண்ணை உள்ளிடவும்"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("வாணிக விலை உள்ளிடவும்"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("விளக்கத்தை உள்ளிடவும்"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("தள்ளுபடி உள்ளிடவும்."),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("செலவு தேதியை உள்ளிடவும்"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("முழு முகவரி உள்ளிடவும்"),
        "enterInvoiceNumber": MessageLookupByLibrary.simpleMessage(
            "விலைப்பட்டியல் எணை உள்ளிடவும்"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "குறைந்த பங்கு எச்சரிக்கை அளவை உள்ளிடவும்"),
        "enterManufacturer": MessageLookupByLibrary.simpleMessage(
            "உற்பத்தி விளக்கத்தை உள்ளிடவும்"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("செய்தி உள்ளிடு"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "சூதான விலை/விற்பனையாளர் விலை உள்ளிடவும்"),
        "enterName": MessageLookupByLibrary.simpleMessage("பெயர் உள்ளிடவும்"),
        "enterNote":
            MessageLookupByLibrary.simpleMessage("குறிப்பை உள்ளிடவும்"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("கட்சி பெயர் உள்ளிடவும்"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("தொலைபேசி எண் உள்ளிடவும்"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "பொருள் குறியீடை உள்ளிடவும் அல்லது ஸ்கேன் செய்க"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("பொருள் பெயரை உள்ளிடவும்"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("வாங்கும் விலை உள்ளிடவும்."),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("முகவர் எணை உள்ளிடவும்"),
        "enterSize": MessageLookupByLibrary.simpleMessage("அளவை உள்ளிடவும்"),
        "enterStocks":
            MessageLookupByLibrary.simpleMessage("பங்குகளை உள்ளிடவும்."),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("வரிச் சுமையை உள்ளிடவும்"),
        "enterTransactionId": MessageLookupByLibrary.simpleMessage(
            "பரிவர்த்தனை ஐடியை உள்ளிடவும்"),
        "enterType": MessageLookupByLibrary.simpleMessage("வகை உள்ளிடவும்"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("பயனர் தலைப்பை உள்ளிடுக"),
        "enterValidAmount": MessageLookupByLibrary.simpleMessage(
            "செல்லுபடியாகும் தொகையை உள்ளிடவும்"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("கூடத்தின் பெயரை உள்ளிடவும்"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("எடை உள்ளிடவும்"),
        "enterWholeSalePrice": MessageLookupByLibrary.simpleMessage(
            "மொத்த வியாபார விலை உள்ளிடவும்"),
        "enterYourDescriptionHere": MessageLookupByLibrary.simpleMessage(
            "உங்கள் விளக்கத்தை இங்கே உள்ளிடவும்"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "உங்கள் மின்னஞ்சல் முகவரியை உள்ளிடவும்"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "உங்கள் கருத்து தலைப்பை உள்ளிடவும்"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("உங்கள் GST எண்ணை உள்ளிடவும்"),
        "enterYourMobileNumber": MessageLookupByLibrary.simpleMessage(
            "உங்கள் மொபைல் எண்ணை உள்ளிடவும்"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("உங்கள் பெயரை உள்ளிடவும்"),
        "enterYourNumber": MessageLookupByLibrary.simpleMessage(
            "உங்கள் தொலைபேசி எண்ணை உள்ளிடவும்"),
        "enterYourPassword": MessageLookupByLibrary.simpleMessage(
            "உங்கள் கடவுச்சொல்லை உள்ளிடுக"),
        "enterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "உங்கள் தொலைபேசி எண்ணை உள்ளிடவும்"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "உங்கள் பரிவர்த்தனை எண்ணை உள்ளிடவும்"),
        "error": MessageLookupByLibrary.simpleMessage("தவறு"),
        "excTax": MessageLookupByLibrary.simpleMessage("விலக்கு வரி"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("Excel ஏற்றுநர்"),
        "exclusive": MessageLookupByLibrary.simpleMessage("விலக்கு"),
        "expense": MessageLookupByLibrary.simpleMessage("செலவு"),
        "expenseCategory": MessageLookupByLibrary.simpleMessage("செலவு வகை"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("செலவு தேதி"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("செலவு பகுதி"),
        "expenseReport": MessageLookupByLibrary.simpleMessage("செலவு அறிக்கை"),
        "expireDate":
            MessageLookupByLibrary.simpleMessage("காலாவதியாகும் தேதி"),
        "expired": MessageLookupByLibrary.simpleMessage("காலாவதியானது"),
        "expiring": MessageLookupByLibrary.simpleMessage("காலாவதியான"),
        "facebok": MessageLookupByLibrary.simpleMessage("பேஸ்புக்"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("வழு ஏற்பட்டது"),
        "fashion": MessageLookupByLibrary.simpleMessage("ஃபேஷன்"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "அம்சங்கள் பாரம்பரிய தீர்வுகளிலிருந்து விதைத்து வருகின்ற முக்கிய அஂஶம்."),
        "feedBack": MessageLookupByLibrary.simpleMessage("கருத்து"),
        "firstName": MessageLookupByLibrary.simpleMessage("முதல் பெயர்"),
        "followUsOnFacebook": MessageLookupByLibrary.simpleMessage(
            "எங்களை Facebook இல் பின்தொடர்க"),
        "followUsOnTwitter": MessageLookupByLibrary.simpleMessage(
            "எங்களை Twitter இல் பின்தொடர்க"),
        "fontSide": MessageLookupByLibrary.simpleMessage("முகப்பகுதி"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("மரியாதற்கான பயன்பாட்டிற்கு"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("கடவுச்சொல் மறந்தேனா?"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("கடவுச்சொல் மறந்தேனா?"),
        "formDate": MessageLookupByLibrary.simpleMessage("தேதி முதல்"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("இலவச தரவு பேக்கப்"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "இலவச வாழ்க்கை முழுப்பு புதுப்பிப்பு"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("இலவச திட்டம்"),
        "freePlan": MessageLookupByLibrary.simpleMessage("இலவச திட்டம்"),
        "from": MessageLookupByLibrary.simpleMessage("(இயல்பான"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage(
            "முழுமையாக செலுத்தப்பட்டுள்ளது"),
        "gallary": MessageLookupByLibrary.simpleMessage("கேலரி"),
        "generatingPDF":
            MessageLookupByLibrary.simpleMessage("PDF உருவாக்கப்படுகிறது"),
        "getOtp": MessageLookupByLibrary.simpleMessage("ஒடிபி பெறு"),
        "govermentId": MessageLookupByLibrary.simpleMessage("அரசு அடையாளம்"),
        "guest": MessageLookupByLibrary.simpleMessage("விருந்து"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("எந்த கணக்கும் இல்லையா?"),
        "history": MessageLookupByLibrary.simpleMessage("வரலாறு"),
        "home": MessageLookupByLibrary.simpleMessage("வீடு"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "How We Protect Your Information"),
        "howWeUseYourInformation":
            MessageLookupByLibrary.simpleMessage("How We Use Your Information"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("அடையாளம் சரிபார்ப்பு"),
        "image": MessageLookupByLibrary.simpleMessage("படம்"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("உள்ளகத்தில் நீக்க முடியாது"),
        "inHouseCantBeEdited": MessageLookupByLibrary.simpleMessage(
            "உள்ளகத்தில் திருத்த முடியாது"),
        "inWord": MessageLookupByLibrary.simpleMessage("வெறுமொழியில்"),
        "incTax": MessageLookupByLibrary.simpleMessage("உள்ளன வரி"),
        "inclusive": MessageLookupByLibrary.simpleMessage("உள்ளடக்க"),
        "increaseStock":
            MessageLookupByLibrary.simpleMessage("சந்தாவை அதிகரிக்கவும்"),
        "inistrument": MessageLookupByLibrary.simpleMessage("பயன்பாடு"),
        "instragram": MessageLookupByLibrary.simpleMessage("இன்ஸ்டகிராம்"),
        "invNo": MessageLookupByLibrary.simpleMessage("சரிபார்ப்பு எண்."),
        "invoice": MessageLookupByLibrary.simpleMessage("இன்வாய்ஸ்"),
        "invoiceNumber":
            MessageLookupByLibrary.simpleMessage("விலைப்பட்டியல் எண்"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("விலைப்பட்டிய அமைப்பு"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("இன்வாய்ஸ் பார்வையாளர்"),
        "itemAdded":
            MessageLookupByLibrary.simpleMessage("பொருள் சேர்க்கப்பட்டது"),
        "kg": MessageLookupByLibrary.simpleMessage("கிலோகிராம்"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("KYC சரிபார்ப்பு"),
        "language": MessageLookupByLibrary.simpleMessage("மொழி"),
        "lastName": MessageLookupByLibrary.simpleMessage("கடைசி பெயர்"),
        "ledger": MessageLookupByLibrary.simpleMessage("நிதி பதிகைப்பதிவு"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("வாழ்க்கைக்கு வாங்கல்"),
        "link": MessageLookupByLibrary.simpleMessage("இணைக்க"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("இணைய உள்ளகம்"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("நேரலைச் உரையாடல் ஆதரவு"),
        "loading": MessageLookupByLibrary.simpleMessage("ஏற்றுகிறேன்"),
        "logIn": MessageLookupByLibrary.simpleMessage("உள்நுழை"),
        "logOUt": MessageLookupByLibrary.simpleMessage("விடுபதியுங்கள்"),
        "logOut": MessageLookupByLibrary.simpleMessage("வெளியேறு"),
        "login": MessageLookupByLibrary.simpleMessage("உள்நுழை"),
        "logo": MessageLookupByLibrary.simpleMessage("லோகோ"),
        "loss": MessageLookupByLibrary.simpleMessage("குழப்பு"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("குழப்பு / லாபம்"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("குழப்பு / லாபம் விவரங்கள்"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("பழுதும் லாபம் அறிக்கை"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("பழுதும் லாபம் அறிக்கைகள்"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("குறைந்த பங்கு எச்சரிக்கை"),
        "maan": MessageLookupByLibrary.simpleMessage("மான்"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "பிராண்டட் இன்வாய்ஸ்கள் மூலம் உங்கள் வாடிக்கையாளர்களுக்கு நீடித்த தாக்கத்தை ஏற்படுத்துங்கள். எங்களின் வரம்பற்ற மேம்படுத்தல் உங்கள் இன்வாய்ஸ்களைத் தனிப்பயனாக்குவதன் தனித்துவமான நன்மையை வழங்குகிறது, மேலும் உங்கள் பிராண்ட் அடையாளத்தை வலுப்படுத்தும் மற்றும் வாடிக்கையாளர் விசுவாசத்தை வளர்க்கும் தொழில்முறை தொடர்பைச் சேர்க்கிறது."),
        "manageYourBussinessWith": MessageLookupByLibrary.simpleMessage(
            "உங்கள் வணிகத்தை நிர்வகிக்கவும்"),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("உற்பத்தி தேதி"),
        "margin": MessageLookupByLibrary.simpleMessage("எடுக்கப்படுகின்றது"),
        "masterCard": MessageLookupByLibrary.simpleMessage("மாஸ்டர் கார்டு"),
        "menufeturer":
            MessageLookupByLibrary.simpleMessage("உற்பத்தி விளக்கம்"),
        "message": MessageLookupByLibrary.simpleMessage("செய்தி"),
        "messageHistory": MessageLookupByLibrary.simpleMessage("செய்தி வரலாறு"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Pos Saas பயன்பாடு இலவசம், பயன்படுத்த எளிதாக உள்ளது. உலகில் அதிசிலவற்றில் ஒன்றாக இருக்கும்."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas மொத்த வணிக தீர்வாகும் - பங்கு, கணக்கு, விற்பனை, செலவு மற்றும் நஷ்ட/லாபம்."),
        "mobile": MessageLookupByLibrary.simpleMessage("மொபைல்"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("மொபைல் கட்டணம்"),
        "monthly": MessageLookupByLibrary.simpleMessage("மாதாந்திர"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("மேலும் தகவல்"),
        "name":
            MessageLookupByLibrary.simpleMessage("உங்கள் பெயர் உள்ளிடவும்."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("பெயர் ஏற்கெனவே உள்ளது"),
        "nameCantBeEmpty": MessageLookupByLibrary.simpleMessage(
            "பெயர் காலியாக இருக்க முடியாது"),
        "next": MessageLookupByLibrary.simpleMessage("அடுத்து"),
        "noConnection": MessageLookupByLibrary.simpleMessage("இணைப்பு இல்லை"),
        "noData": MessageLookupByLibrary.simpleMessage("தரவு இல்லை"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("கோப்புகள் கிடைக்கவில்லை"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("தரவுகள் கிடைக்கவில்லை"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("வரலாறு கிடைக்கவில்லை!"),
        "noProductFound": MessageLookupByLibrary.simpleMessage(
            "பொருள் எதுவும் கிடைக்கவில்லை"),
        "noSubTaxSelected": MessageLookupByLibrary.simpleMessage(
            "தேர்ந்தெடுக்கப்படாத உப வரிகள்"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("பரிவர்த்தனை கிடைக்கவில்லை!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "அந்த மின்னஞ்சலுக்கு பயனர் கிடைக்கவில்லை."),
        "noUserRoleFound":
            MessageLookupByLibrary.simpleMessage("பயனர் பங்கு காணப்படவில்லை"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("செயல்பாட்டில் இல்லாத பயனர்"),
        "notProvided": MessageLookupByLibrary.simpleMessage("வழங்கவில்லை"),
        "note": MessageLookupByLibrary.simpleMessage("குறிப்பு"),
        "notes": MessageLookupByLibrary.simpleMessage("குறிப்புகள்"),
        "notification": MessageLookupByLibrary.simpleMessage("அறிவிப்பு"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP அனுப்பப்பட்டது"),
        "office": MessageLookupByLibrary.simpleMessage("காலணி"),
        "ok": MessageLookupByLibrary.simpleMessage("சரி"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS that contains a great deal of functionality, including sales tracking, inventory management."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "This system helps you improve your operations for your customers."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Our POS system should simplify daily operations automatically, making it easy to navigate."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("திறப்பு இருப்பு"),
        "order": MessageLookupByLibrary.simpleMessage("ஆர்டர்கள்"),
        "other": MessageLookupByLibrary.simpleMessage("மற்றவை"),
        "otp": MessageLookupByLibrary.simpleMessage("மூடு"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("கையிருப்பு இல்லை"),
        "pacakge": MessageLookupByLibrary.simpleMessage("பேக்கேஜ்"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("போட்டி அம்சங்கள்"),
        "paid": MessageLookupByLibrary.simpleMessage("செலுத்தியது"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("செலுத்திய தொகை"),
        "parties": MessageLookupByLibrary.simpleMessage("கட்சிகள்"),
        "partiesList":
            MessageLookupByLibrary.simpleMessage("கட்சிகள் பட்டியல்"),
        "partyGST": MessageLookupByLibrary.simpleMessage("பார்டி GST"),
        "partyName": MessageLookupByLibrary.simpleMessage("கட்சி பெயர்"),
        "password": MessageLookupByLibrary.simpleMessage("கடவுச்சொல்"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "கடவுச்சொல் மற்றும் உறுதிப்படுத்தும் கடவுச்சொல் பொருந்தவில்லை"),
        "passwordCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "கடவுச்சொல் காலியாக இருக்க முடியாது"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("கடவுச்சொல் பொருந்தவில்லை"),
        "payCash": MessageLookupByLibrary.simpleMessage("பணம் செலுத்து"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash": MessageLookupByLibrary.simpleMessage(
            "Bkash மூலம் பணம் செலுத்தவும்"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("பேபால் மூலம் செலுத்து"),
        "payeeName":
            MessageLookupByLibrary.simpleMessage("பணம் பெறுபவர் பெயர்"),
        "payeeNumber":
            MessageLookupByLibrary.simpleMessage("பணம் பெறுபவர் எண்"),
        "payment": MessageLookupByLibrary.simpleMessage("கட்டணம்"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("கட்டண தொகை"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("கட்டணம் முடிந்தது"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("கட்டண வழிகாட்டல்:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("கட்டண முறை"),
        "paymentType": MessageLookupByLibrary.simpleMessage("கட்டண வகை"),
        "pdfView": MessageLookupByLibrary.simpleMessage("PDF காட்சி"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("தனிப்பட்ட தகவல்"),
        "phone": MessageLookupByLibrary.simpleMessage("தொலைபேசி"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("தொலைபேசி எண்"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "தொலைபேசி எண் ஏற்கனவே பயன்படுத்தப்படுகிறது"),
        "phoneNumberIsNotValid": MessageLookupByLibrary.simpleMessage(
            "தொலைபேசி எண் செல்லுபடியாகவில்லை"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("தொலைபேசி எண் தேவை"),
        "pickAndUploadFile": MessageLookupByLibrary.simpleMessage(
            "கோப்புகளைத் தேர்ந்தெடுத்து, ஏற்றவும்"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("முடிவு தேதி தேர்ந்தெடு"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("ஆரம்ப தேதி தேர்ந்தெடு"),
        "plan": MessageLookupByLibrary.simpleMessage("திட்டம்"),
        "pleaseAddQuantity": MessageLookupByLibrary.simpleMessage(
            "தயவுசெய்து அளவைச் சேர்க்கவும்"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "உங்கள் இணைப்பு இணைப்பை சரிபார்க்கவும்"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "முதலில் அச்சுப்பொறியை இணைக்கவும்"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "தயவுசெய்து உங்கள் புளூட்டூத் அச்சுக்கி இணைக்கவும்"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "மேலதிக கடவுச்சொல் உள்ளிடவும்"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "ஒரு உறுதியான கடவுச்சொல் உள்ளிடவும்"),
        "pleaseEnterAPassword": MessageLookupByLibrary.simpleMessage(
            "தயவுசெய்து ஒரு கடவுச்சொல் உள்ளிடவும்"),
        "pleaseEnterAValidEmail":
            MessageLookupByLibrary.simpleMessage("தரமான இமெயிலை உள்ளிடவும்"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("பெயரை உள்ளிடவும்"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("கடவுச்சொல்லை உள்ளிடவும்"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "கடவுச்சொல் மீட்டெடுப்பதற்காக தயவுசெய்து கீழே உங்கள் மின்னஞ்சல் முகவரியை உள்ளிடவும்."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "தயவுசெய்து பரிமாற்ற எண்களை உள்ளிடவும்"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("தொகையை உள்ளிடவும்"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "முதலில் ஒரு வகையைத் தேர்ந்தெடுக்கவும்"),
        "pleaseSelectAPlan": MessageLookupByLibrary.simpleMessage(
            "தயவுசெய்து ஒரு திட்டத்தை தேர்ந்தெடுக்கவும்"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "வணிக வகையைத் தேர்ந்தெடுக்கவும்"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "தயவுசெய்து செயலியைப் பயன்படுத்த சரியான வாங்குதல் குறியீட்டை பயன்படுத்தவும்"),
        "powerdedByMobiPos": MessageLookupByLibrary.simpleMessage(
            "Pos Saas மூலம் இயக்கப்பட்டது"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("சாதனைக்கு"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("முதுவர் வாணிக ஆதரணம்"),
        "premiumPlan":
            MessageLookupByLibrary.simpleMessage("பிரீமியம் திட்டம்"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("முந்தைய கட்டணங்கள்"),
        "price": MessageLookupByLibrary.simpleMessage("விலை"),
        "print": MessageLookupByLibrary.simpleMessage("அச்சுப்பிடு"),
        "printingOption": MessageLookupByLibrary.simpleMessage("அச்சு அமைப்பு"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("தனிப்பந்தப்பட்ட கொள்கை"),
        "product": MessageLookupByLibrary.simpleMessage("பொருள்"),
        "productCode": MessageLookupByLibrary.simpleMessage("பொருள் குறியீடு"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("தயாரிப்பு குறியீடு தேவை"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("பொருள் குறியீடு/பெயர்"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("பொருள் விளக்கம்"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("தயாரிப்பு விவரங்கள்"),
        "productList": MessageLookupByLibrary.simpleMessage("பொருள் பட்டியல்"),
        "productName": MessageLookupByLibrary.simpleMessage("பொருள் பெயர்"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "இந்த சாக்கு வாரியத்தில் தயாரிப்பு பெயர் ஏற்கனவே உள்ளது"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "பொருட் பெயர் ஏற்கனவே சேர்க்கப்பட்டுள்ளது"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("தயாரிப்பு பெயர் தேவை"),
        "products": MessageLookupByLibrary.simpleMessage("பொருட்கள்"),
        "profile": MessageLookupByLibrary.simpleMessage("சுயவிவரம்"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("சுயசரிசியை தொகு"),
        "profit": MessageLookupByLibrary.simpleMessage("லாபம்"),
        "promo": MessageLookupByLibrary.simpleMessage("விளம்பரம்"),
        "promoCode": MessageLookupByLibrary.simpleMessage("விளம்பர குறியீடு"),
        "purchase": MessageLookupByLibrary.simpleMessage("வாங்குதல்"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("வாங்குவதிற்கு அலாரம்"),
        "purchaseConfirmed": MessageLookupByLibrary.simpleMessage(
            "வாங்குவது உறுதிசெய்யப்பட்டது"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("வாங்குதல் விவரங்கள்"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("வாங்கும் ரசீது"),
        "purchaseList":
            MessageLookupByLibrary.simpleMessage("வாங்குதல் பட்டியல்"),
        "purchaseNow":
            MessageLookupByLibrary.simpleMessage("இப்போது வாங்குங்கள்"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("பிரீமியம் திட்டம் வாங்கவும்"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("வாங்கும் விலை"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("சந்தா விலை தேவை"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("வாங்குதல் அறிக்கை"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("வாங்குதல் அறிக்கை"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("வாங்குதல் அறிக்கைகள்"),
        "purchaseReturn": MessageLookupByLibrary.simpleMessage(
            "வாங்கியதை திருப்பி செலுத்துதல்"),
        "purchaseReturnReport": MessageLookupByLibrary.simpleMessage(
            "வாங்கியதை திருப்பி செலுத்தும் அறிக்கையால்"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("கூப்பன மாற்றம்"),
        "qty": MessageLookupByLibrary.simpleMessage("அளவு"),
        "quantity": MessageLookupByLibrary.simpleMessage("அளவு"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("சமீபத்திய பரிவர்த்தனைகள்"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("பின் பெறப்பட்டது"),
        "referenceNumber": MessageLookupByLibrary.simpleMessage("முகவர் எண்"),
        "register": MessageLookupByLibrary.simpleMessage("பதிவு செய்க"),
        "registering": MessageLookupByLibrary.simpleMessage("பதிவு செய்கிறேன்"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("மீதி கடன்"),
        "remove": MessageLookupByLibrary.simpleMessage("நீக்கு"),
        "reports": MessageLookupByLibrary.simpleMessage("அறிக்கைகள்"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("கோரிக்கை அனுப்பப்பட்டுள்ளது"),
        "resendCode": MessageLookupByLibrary.simpleMessage("மீட்டெடு குறியீடு"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("ஒடிபி மீட்டெடு :"),
        "retailer": MessageLookupByLibrary.simpleMessage("விற்பனையாளர்"),
        "retur": MessageLookupByLibrary.simpleMessage("திரும்பத் தொழில்"),
        "returN": MessageLookupByLibrary.simpleMessage("திருப்பி"),
        "returnAMount":
            MessageLookupByLibrary.simpleMessage("திரும்பமைக்க தொகை"),
        "returnAmount":
            MessageLookupByLibrary.simpleMessage("திரும்ப வரும் தொகை"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("திருப்பி அளவு"),
        "revenue": MessageLookupByLibrary.simpleMessage("வருமானம்"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "உங்கள் வணிகத் தரவை சிரமமின்றிப் பாதுகாக்கவும். எங்களின் Pos Saas POS அன்லிமிடெட் அப்கிரேடில் இலவச டேட்டா காப்புப்பிரதி அடங்கும், உங்கள் மதிப்புமிக்க தகவல் எதிர்பாராத நிகழ்வுகளுக்கு எதிராக பாதுகாக்கப்படுவதை உறுதி செய்கிறது. உண்மையில் முக்கியமானவற்றில் கவனம் செலுத்துங்கள் - உங்கள் வணிக வளர்ச்சி."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("விற்பனை தொகை"),
        "saleDetails":
            MessageLookupByLibrary.simpleMessage("விற்பனை விவரங்கள்"),
        "salePrice": MessageLookupByLibrary.simpleMessage("விற்பனை விலை"),
        "saleReports": MessageLookupByLibrary.simpleMessage("விற்பனை அறிக்கை"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("விற்பனை அறிக்கைகள்"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("விற்பனை திருப்பி"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("விற்பனை திருப்பி அறிக்கை"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("விற்பனை அமைப்பு"),
        "sales": MessageLookupByLibrary.simpleMessage("விற்பனை"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("Sale & Purchase Reports"),
        "salesList": MessageLookupByLibrary.simpleMessage("விற்பனை பட்டியல்"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("விற்பனை திருப்பி"),
        "save": MessageLookupByLibrary.simpleMessage("சேமி"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("சேமி மற்றும் வெளியிடு"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("மாற்றங்களை சேமி"),
        "saving": MessageLookupByLibrary.simpleMessage("சேமிக்கிறது"),
        "scanProductQRCode": MessageLookupByLibrary.simpleMessage(
            "பொருளின் QR குறியீட்டை ஸ்கேன் செய்க"),
        "search": MessageLookupByLibrary.simpleMessage("தேடு"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "பொருள் குறியீடு அல்லது பெயரால் தேடவும்"),
        "seeAllPromoCode": MessageLookupByLibrary.simpleMessage(
            "அனைத்து விளம்பர குறியீடுகளையும் காண்க"),
        "select": MessageLookupByLibrary.simpleMessage("தேர்வு"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "திருப்பிக்கு ஒரு பொருளை தேர்ந்தெடுக்கவும்"),
        "selectBrand": MessageLookupByLibrary.simpleMessage(
            "பிராண்டைத் தேர்ந்தெடுக்கவும்"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("வகையைத் தேர்ந்தெடுக்கவும்"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("தொடர்பியல் தேர்வு செய்க"),
        "selectProductCategory": MessageLookupByLibrary.simpleMessage(
            "தயாரிப்பு வகையைத் தேர்ந்தெடுக்கவும்"),
        "selectShopCategory": MessageLookupByLibrary.simpleMessage(
            "அந்தரங்க வகையைத் தேர்ந்தெடுக்கவும்"),
        "selectTax":
            MessageLookupByLibrary.simpleMessage("வரி தேர்ந்தெடுக்கவும்"),
        "selectTaxType": MessageLookupByLibrary.simpleMessage(
            "வரி வகையைத் தேர்ந்தெடுக்கவும்"),
        "selectUnit":
            MessageLookupByLibrary.simpleMessage("அலகைப் தேர்ந்தெடுக்கவும்"),
        "selectvariations": MessageLookupByLibrary.simpleMessage(
            "மாற்றங்களை தேர்ந்தெடுக்கவும்: "),
        "seller": MessageLookupByLibrary.simpleMessage("விற்பனையாளர்"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("விற்கின்றது"),
        "send": MessageLookupByLibrary.simpleMessage("அனுப்பு"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("மின்னஞ்சல் அனுப்பு"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("செய்தி அனுப்பு"),
        "sendResetLink": MessageLookupByLibrary.simpleMessage(
            "மீட்டெடுப்பதற்கான இணைப்பை அனுப்பு"),
        "sendSms": MessageLookupByLibrary.simpleMessage("எஸ் எம் எஸ் அனுப்பு"),
        "sendSmsw":
            MessageLookupByLibrary.simpleMessage("எஸ் எம் எஸ் அனுப்பவா?"),
        "sendWhatsappMessage": MessageLookupByLibrary.simpleMessage(
            "Whatsapp செய்தியை அனுப்பவும்"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("உங்கள் மின்னஞ்சலை அனுப்பு"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage(
            "மின்னஞ்சல் அனுப்பி வைத்திருக்கிறேன்"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("செய்தி அனுப்புகிறேன்"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("சேவை/அனுப்புதல்"),
        "setUpYourProfile": MessageLookupByLibrary.simpleMessage(
            "உங்கள் சுயவிவரத்தை அமைக்கவும்"),
        "setting": MessageLookupByLibrary.simpleMessage("அமைப்பு"),
        "share": MessageLookupByLibrary.simpleMessage("பகிர்"),
        "shopGST": MessageLookupByLibrary.simpleMessage("அந்தரங்க GST"),
        "signIn": MessageLookupByLibrary.simpleMessage("உள்நுழைக"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("இமெயிலுடன் உள்நுழைக"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("வாடிக்கையாளர் கையொப்பம்"),
        "size": MessageLookupByLibrary.simpleMessage("அளவு"),
        "skip": MessageLookupByLibrary.simpleMessage("விட்டு செல்"),
        "sms": MessageLookupByLibrary.simpleMessage("எஸ் எம் எஸ்"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("சமூக விளம்பரம்"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "மன்னிக்கவும், இந்த சேவைக்கு நீங்கள் அனுமதி இல்லை"),
        "startDate": MessageLookupByLibrary.simpleMessage("ஆரம்ப தேதி"),
        "startNewSale": MessageLookupByLibrary.simpleMessage(
            "புதிய விற்பனையை ஆரம்பிக்கவும்"),
        "startTypingToSearch":
            MessageLookupByLibrary.simpleMessage("தேட தட்டச்சுக்கு தொடக்கவும்"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "கூடுதல் செலவுகள் இல்லாமல் தொழில்நுட்ப முன்னேற்றங்களில் முன்னணியில் இருங்கள். எங்களின் Pos Saas POS அன்லிமிடெட் மேம்படுத்தல், சமீபத்திய கருவிகள் மற்றும் அம்சங்களை எப்போதும் உங்கள் விரல் நுனியில் வைத்திருப்பதை உறுதிசெய்கிறது, உங்கள் வணிகம் அதிநவீனமாக இருக்கும்."),
        "stillUnpaid":
            MessageLookupByLibrary.simpleMessage("இன்னும் செலுத்தப்படவில்லை"),
        "stock": MessageLookupByLibrary.simpleMessage("கையிருப்பு"),
        "stockIsRequired": MessageLookupByLibrary.simpleMessage("பங்கு தேவை"),
        "stockList": MessageLookupByLibrary.simpleMessage("பங்கு பட்டியல்"),
        "stocks": MessageLookupByLibrary.simpleMessage("பங்குகள்"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Excel கோப்பை உருவாக்க அனுமதி தேவை"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("உப வரி பட்டியல்"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("உப வரிகள்"),
        "subTotal": MessageLookupByLibrary.simpleMessage("கூட்டு விலை"),
        "submit": MessageLookupByLibrary.simpleMessage("சமர்ப்பி"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "எங்கள் YouTube சேனலுக்கு பதிவு செய்க"),
        "subscription": MessageLookupByLibrary.simpleMessage("சந்தாக்கு"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("வெற்றிகரமாக முடிந்தது"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("வெற்றிகரமாக வெளியேறியது"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("வழுமுறை மாற்றப்பட்டுள்ளது"),
        "supplier": MessageLookupByLibrary.simpleMessage("வழக்காளர்"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("விற்பனையாளர் பெயர்"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT குறியீச்சு"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "ஒரு ஓட்டுநர் அனுமதிப்பதற்கு, தேசிய அடையாள அட்டை அல்லது கீழே முதல் பதிவு செய்யுங்கள்"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "உங்கள் தகவல்களை சரிபார்க்க ஒரு தேசிய அடையாள அட்டை எடுக்கவும்"),
        "tap": MessageLookupByLibrary.simpleMessage("தட்டவும்"),
        "tax": MessageLookupByLibrary.simpleMessage("வரி"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("வரிச் சுமை குழு"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("வரி சதவீதம்"),
        "taxRate": MessageLookupByLibrary.simpleMessage("வரிச் சுமை"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "வரிச் சுமைகள் - உங்கள் வரிச் சுமைகளை நிர்வகிக்கவும்"),
        "taxReport": MessageLookupByLibrary.simpleMessage("வரிச் சுமை அறிக்கை"),
        "taxType": MessageLookupByLibrary.simpleMessage("வரி வகை"),
        "taxes": MessageLookupByLibrary.simpleMessage("வரி"),
        "termsAndConditions": MessageLookupByLibrary.simpleMessage(
            "நிபந்தனைகள் மற்றும் விதிமுறைகள்"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("பயன்பாடு விதிகள்"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("விதிமுறைகள் & தனியுரிமை"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "உங்கள் கடன் கட்டணத்துக்கு நன்றி"),
        "thankYou": MessageLookupByLibrary.simpleMessage("நன்றி"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("உங்கள் வாங்கலுக்கு நன்றி"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "அந்த மின்னஞ்சலுக்கு கணக்கு ஏற்கெனவே உள்ளது"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Excel கோப்பு ஏற்கனவே பதிவிறக்கப்பட்டுள்ளது"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "பெயர் அனைத்தையும் கூறுகிறது. Pos Saas POS அன்லிமிடெட் மூலம், உங்கள் பயன்பாட்டிற்கு எந்த வரம்பும் இல்லை. நீங்கள் ஒரு சில பரிவர்த்தனைகளைச் செய்தாலும் அல்லது வாடிக்கையாளர்களின் அவசரத்தை அனுபவித்தாலும், நீங்கள் வரம்புகளால் கட்டுப்படுத்தப்படவில்லை என்பதை அறிந்து, நம்பிக்கையுடன் செயல்படலாம்"),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "கொடுக்கும் கடவுச்சொல் மிகவும் பலவீனமாக உள்ளது"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "விற்பனை அழிக்கப்படும் மற்றும் இந்த வாங்குவிக்கும் குறித்த அனைத்து தரவுகள் அழிக்கப்படும். நீங்கள் இதனை அழிக்க உறுதியாக இருக்கிறீர்களா"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "விற்பனை அழிக்கப்படும் மற்றும் அனைத்து தரவுகள் விற்பனை குறித்த அழிக்கப்படும். நீங்கள் இதனை அழிக்க உறுதியாக இருக்கிறீர்களா"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "பயனர் நீக்கப்படும் மற்றும் அனைத்து தரவுகளும் உங்கள் கணக்கில் நீக்கப்படும். இதை நீங்கள் நிச்சயமாக நீக்க விரும்புகின்றீர்களா?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "இந்த பயனர் நீக்கப்படும் மற்றும் உங்கள் கணக்கிலிருந்து அனைத்து தரவுகளும் நீக்கப்படும். நீக்க விரும்புகிறீர்களா?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Third-Party Services"),
        "thisCategoryCannotBeDeleted":
            MessageLookupByLibrary.simpleMessage("இந்த வகையை நீக்க முடியாது"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(இந்த மாதம்)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "இந்த தயாரிப்பு ஏற்கனவே சேர்க்கப்பட்டுள்ளது"),
        "title": MessageLookupByLibrary.simpleMessage("தலைப்பு"),
        "titleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "தலைப்பு காலியாக இருக்க முடியாது"),
        "to": MessageLookupByLibrary.simpleMessage("க்கு"),
        "toDate": MessageLookupByLibrary.simpleMessage("தேதி வரை"),
        "today": MessageLookupByLibrary.simpleMessage("இன்று"),
        "total": MessageLookupByLibrary.simpleMessage("மொத்தம்"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("மொத்த தொகை"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("மொத்த சேகரிப்பு"),
        "totalDue": MessageLookupByLibrary.simpleMessage("மொத்த கடன்"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("மொத்த செலவு"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("மொத்த இழப்பு"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("மொத்த செலுத்தப்படவேண்டிய"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("மொத்த விலை"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("மொத்த தயாரிப்புகள்"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("மொத்த லாபம்"),
        "totalPurchase":
            MessageLookupByLibrary.simpleMessage("மொத்த வாங்குதல்"),
        "totalReturnAmount": MessageLookupByLibrary.simpleMessage(
            "மொத்த திருப்பி செலுத்தும் தொகை"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("மொத்த திருப்பி"),
        "totalSale": MessageLookupByLibrary.simpleMessage("மொத்த விற்பனை"),
        "totalStock": MessageLookupByLibrary.simpleMessage("மொத்த பங்குகள்"),
        "totalValue": MessageLookupByLibrary.simpleMessage("மொத்த மதிப்பு"),
        "totalVat": MessageLookupByLibrary.simpleMessage("மொத்த வாட்டு"),
        "totals": MessageLookupByLibrary.simpleMessage("மொத்தம்: "),
        "transaction": MessageLookupByLibrary.simpleMessage("பரிவர்த்தனை"),
        "transactionId":
            MessageLookupByLibrary.simpleMessage("பரிவர்த்தனை எண்"),
        "tryAgain":
            MessageLookupByLibrary.simpleMessage("மீண்டும் முயற்சிக்கவும்"),
        "twitter": MessageLookupByLibrary.simpleMessage("ட்விட்டர்"),
        "type": MessageLookupByLibrary.simpleMessage("வகை"),
        "unitName": MessageLookupByLibrary.simpleMessage("அலகு பெயர்"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("ஒருவகை விலை"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("அலகு விலை"),
        "units": MessageLookupByLibrary.simpleMessage("யூனிட்கள்"),
        "unlimited": MessageLookupByLibrary.simpleMessage("அவசர"),
        "unlimitedUsage": MessageLookupByLibrary.simpleMessage("அவசர பயன்பாடு"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "எங்கள் நிபுணர் குழு தலைமையிலான தனிப்பயனாக்கப்பட்ட பயிற்சி அமர்வுகளுடன் Pos Saas POS இன் முழு திறனையும் திறக்கவும். அடிப்படைகள் முதல் மேம்பட்ட நுட்பங்கள் வரை, உங்கள் வணிகச் செயல்முறைகளை மேம்படுத்த கணினியின் ஒவ்வொரு அம்சத்தையும் பயன்படுத்துவதில் நீங்கள் நன்கு அறிந்திருப்பதை நாங்கள் உறுதிசெய்கிறோம்."),
        "unpaid": MessageLookupByLibrary.simpleMessage("செலுத்தப்படாத"),
        "update": MessageLookupByLibrary.simpleMessage("புதுப்பி"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("தொடர்பை புதுப்பிக்கவும்"),
        "updateNow":
            MessageLookupByLibrary.simpleMessage("இப்போது புதுப்பிக்கவும்"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("பொருளை புதுப்பிக்கவும்"),
        "updateYourPlanFirstYourLimitIsOver": MessageLookupByLibrary.simpleMessage(
            "முதலில் உங்கள் திட்டத்தை புதுப்பிக்கவும், உங்கள் வரம்பு முடிந்துள்ளது"),
        "updateYourProfile": MessageLookupByLibrary.simpleMessage(
            "உங்கள் சுயவிவரத்தை புதுப்பிக்கவும்"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "உங்கள் சுயவிவரத்தை புதுப்பிக்கவும் உங்கள் மருத்துவரை சேர்க்கும் சிறப்பு கொள்கையுடன்"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "உங்கள் சுயவிவரத்தை புதுப்பித்து உங்கள் வாடிக்கையாளரை சேர்க்கவும் மிகுந்த அபிரதமத்துடன் இணைக்குதல்"),
        "updated": MessageLookupByLibrary.simpleMessage("புதுப்பிக்கப்பட்டது"),
        "upload": MessageLookupByLibrary.simpleMessage("ஏற்றவும்"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("ஆவணத்தை பதிவேற்று"),
        "uploadDone":
            MessageLookupByLibrary.simpleMessage("ஏற்றுமதி முடிந்தது"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("கோபம் பதிவேற்று"),
        "upplier": MessageLookupByLibrary.simpleMessage("வழக்காளர்"),
        "usbC": MessageLookupByLibrary.simpleMessage("யூஎஸ்பி சி"),
        "use": MessageLookupByLibrary.simpleMessage("பயன்படுத்து"),
        "useMobiPos":
            MessageLookupByLibrary.simpleMessage("Pos Saas ஐ பயன்படுத்து"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Use of the system"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("பயனர் நீக்கப்பட்டுள்ளது"),
        "userRole": MessageLookupByLibrary.simpleMessage("பயனர் பங்கு"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("பயனர் பங்கு விவரங்கள்"),
        "userTitle": MessageLookupByLibrary.simpleMessage("பயனர் தலைப்பு"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "பயனர் தலைப்பு காலியாக இருக்க முடியாது"),
        "value": MessageLookupByLibrary.simpleMessage("மதிப்பு"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("VAT பொருந்தாது"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage(
            "ஒடிபி சரிபார்க்கப்படுகின்றது"),
        "verifyPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "தொலைபேசி எண்ணை சரிபார்க்கவும்"),
        "viewAll": MessageLookupByLibrary.simpleMessage("அனைத்தையும் பார்க்க"),
        "viewDetails":
            MessageLookupByLibrary.simpleMessage("விபரங்களைக் காண்க"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("கடையில் வரும் வாடிக்கையாளர்"),
        "warehouse": MessageLookupByLibrary.simpleMessage("சாக்கு"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("கூடு ஏற்கெனவே உள்ளது"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("கூடு பட்டியல்"),
        "warehouseName":
            MessageLookupByLibrary.simpleMessage("கூடத்தின் பெயர்"),
        "warranty": MessageLookupByLibrary.simpleMessage("உறுதிப்பத்திரம்"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "நாங்கள் உங்களுக்கு கடவுச்சொல் மீட்டெடுத்து விளக்கமாக ஒரு மின்னஞ்சல் அனுப்பி உள்ளோம்:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "We may use third-party services to support our app\'s functionality, such as analytics providers and payment processors. These third-party services may collect information about you when you use our app. Please note that we are not responsible for the privacy practices of these third-party services."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "We take industry-standard measures to protect your personal information, including encryption and secure storage. We also limit access to your information to authorized personnel only."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "தடையற்ற செயல்பாடுகளின் முக்கியத்துவத்தை நாங்கள் புரிந்துகொள்கிறோம். அதனால்தான், விரைவான வினவலாக இருந்தாலும் அல்லது விரிவான அக்கறையாக இருந்தாலும் உங்களுக்கு உதவ எங்கள் முழுநேர ஆதரவும் உள்ளது. நிகரற்ற வாடிக்கையாளர் சேவையை அனுபவிக்க, எந்த நேரத்திலும், எங்கிருந்தும் அழைப்பு அல்லது WhatsApp மூலம் எங்களுடன் இணையுங்கள்."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "We use your personal information to provide you with the best possible experience on our app, including to personalize your content recomme ndations, connect you with experts, and improve our apps functionality. We may also use your information to communicate with you about updates, promotions, or other information related to our app."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "நாங்கள் கட்டணத்தைப் பரிசோதித்து 1-2 மணி நேரத்தில் ஒப்புக்கொள்வோம்"),
        "weekly": MessageLookupByLibrary.simpleMessage("வாரத்திற்கு"),
        "weight": MessageLookupByLibrary.simpleMessage("எடை"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("என்ன புதியது"),
        "wholSeller":
            MessageLookupByLibrary.simpleMessage("மொத்த விற்பனையாளர்"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("மொத்த வியாபார விலை"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("மொத்த விலையை"),
        "wholesaler":
            MessageLookupByLibrary.simpleMessage("மொத்த விற்பனையாளர்"),
        "willBeAddedSoon": MessageLookupByLibrary.simpleMessage(
            "எவ்வளவு நாள்களில் சேர்க்கப்படும்"),
        "willExpireAt":
            MessageLookupByLibrary.simpleMessage("காலாவதியாகும் நேரம்"),
        "writeYourMessageHere": MessageLookupByLibrary.simpleMessage(
            "உங்கள் செய்தி இங்கே எழுதுங்கள்"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("தவறான OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "அந்த பயனருக்கு தவறான கடவுச்சொல் வழங்கப்பட்டது."),
        "yearly": MessageLookupByLibrary.simpleMessage("வருடாந்திர"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("ஆமாம், எப்போதும் நீக்கு"),
        "youAreNotAValidUser": MessageLookupByLibrary.simpleMessage(
            "நீங்கள் செல்லுபடியாகும் பயனர் அல்ல"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage(
            "நீங்கள் பயன்படுத்துகிறீர்கள்"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "நீங்கள் கட்டணம் செலுத்த முடியாது"),
        "youHaveGotAnEmail": MessageLookupByLibrary.simpleMessage(
            "உங்கள் மின்னஞ்சல் வந்துவிட்டது"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "உங்கள் கணக்கில் வெற்றிகரமாக உள்நுழைந்துள்ளீர்கள். போஸ் சாஸுடன் இருங்கள்."),
        "youHaveToGivePermission": MessageLookupByLibrary.simpleMessage(
            "நீங்கள் அனுமதி கொடுக்க வேண்டும்"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "உங்கள் கணக்கு புன: உள்ளிட வேண்டும்"),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "வாங்குவது முன்னர் உங்கள் அடையாளம் சரிபார்ப்பு செய்ய வேண்டும்"),
        "yourMessageRemains": MessageLookupByLibrary.simpleMessage(
            "உங்கள் செய்தி இன்னும் உள்ளது"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("உங்கள் போட்டி"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "உங்கள் போட்டி 5 நாட்களில் காலாவதியாகும்")
      };
}
