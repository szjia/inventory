// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a vi locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'vi';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Tiếp tục"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("Số GST"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("Giá bán lẻ"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("Giá niêm yết là bắt buộc"),
        "OK": MessageLookupByLibrary.simpleMessage("OK"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("SĐT"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("Mã SWIFT"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Đồ ăn vặt"),
        "TAX": MessageLookupByLibrary.simpleMessage("THUẾ"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Đang tải lên"),
        "UserTitle":
            MessageLookupByLibrary.simpleMessage("Chức danh người dùng"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Gói của bạn sẽ hết hạn hôm nay\nVui lòng mua lại"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) Hệ thống chỉ được cung cấp với mục đích duy nhất là hỗ trợ các giao dịch bán hàng và các hoạt động liên quan trong doanh nghiệp của bạn."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) Để sử dụng Hệ thống, bạn có thể bắt buộc phải tạo tài khoản. Bạn đồng ý cung cấp thông tin chính xác, hiện tại và đầy đủ trong quá trình đăng ký và cập nhật thông tin để giữ cho nó chính xác và đầy đủ."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("Về ứng dụng"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Về chúng tôi"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Sự chấp nhận các Điều khoản"),
        "accountName": MessageLookupByLibrary.simpleMessage("Tên tài khoản"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("Số tài khoản"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Đăng ký tài khoản"),
        "acton": MessageLookupByLibrary.simpleMessage("Hành động"),
        "add": MessageLookupByLibrary.simpleMessage("Thêm"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Thêm thương hiệu"),
        "addCategory": MessageLookupByLibrary.simpleMessage("Thêm danh mục"),
        "addContact": MessageLookupByLibrary.simpleMessage("Thêm liên hệ"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Thêm khách hàng"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("Thêm giao hàng"),
        "addDescriptioN": MessageLookupByLibrary.simpleMessage("Thêm mô tả"),
        "addDescription": MessageLookupByLibrary.simpleMessage("Thêm ghi chú"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Thêm giảm giá"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Thêm chứng minh thư"),
        "addDucument": MessageLookupByLibrary.simpleMessage("Thêm tài liệu"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Thêm chi phí"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Thêm danh mục chi phí"),
        "addItems": MessageLookupByLibrary.simpleMessage("Thêm sản phẩm"),
        "addNew": MessageLookupByLibrary.simpleMessage("Thêm mới"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Thêm địa chỉ mới"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Thêm sản phẩm mới"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("Thêm thuế mới"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Thêm thuế mới với loại thuế đơn/đa"),
        "addNote": MessageLookupByLibrary.simpleMessage("Thêm ghi chú"),
        "addProductFirst": MessageLookupByLibrary.simpleMessage(
            "Vui lòng thêm sản phẩm trước"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Thêm mã khuyến mãi"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Thêm mua hàng"),
        "addSales": MessageLookupByLibrary.simpleMessage("Thêm bán hàng"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Thêm thành công"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Thêm đơn vị"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Thêm vai trò người dùng"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Đã thêm thành công"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("Đã thêm vào giỏ hàng"),
        "address": MessageLookupByLibrary.simpleMessage("Địa chỉ"),
        "admin": MessageLookupByLibrary.simpleMessage("Quản trị viên"),
        "all": MessageLookupByLibrary.simpleMessage("Tất cả"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("Tất cả giải pháp kinh doanh"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("Đã được thêm"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Đã tồn tại"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Đã có tài khoản?"),
        "amount": MessageLookupByLibrary.simpleMessage("Số tiền"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "Một email đã được gửi\\nKiểm tra hộp thư đến của bạn"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Hỗ trợ ứng dụng Android & iOS"),
        "applicableTax": MessageLookupByLibrary.simpleMessage("Thuế áp dụng"),
        "apply": MessageLookupByLibrary.simpleMessage("Áp dụng"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Bạn có chắc chắn muốn xóa hóa đơn này không?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Bạn có chắc chắn muốn xóa bán hàng này không?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Bạn có chắc chắn muốn xóa người dùng này không?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Bạn có chắc chắn muốn xóa thuế này không?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Bạn có chắc chắn muốn xóa nhóm thuế này không?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Bạn có muốn xóa kho này không?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Bạn có chắc muốn xóa người dùng này?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Chữ ký ủy quyền"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Bạn có trách nhiệm duy trì tính bí mật của tài khoản và mật khẩu của bạn và hạn chế quyền truy cập vào tài khoản của bạn. Bạn chấp nhận trách nhiệm cho tất cả các hoạt động xảy ra dưới tài khoản của bạn."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Bạn phải ít nhất 18 tuổi hoặc tuổi tối thiểu theo quy định của lãnh thổ của bạn để sử dụng Hệ thống."),
        "backSide": MessageLookupByLibrary.simpleMessage("Mặt sau"),
        "backToHome":
            MessageLookupByLibrary.simpleMessage("Quay lại trang chủ"),
        "balance": MessageLookupByLibrary.simpleMessage("Số dư"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladesh"),
        "bank": MessageLookupByLibrary.simpleMessage("Ngân hàng"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Tiền tệ tài khoản ngân hàng"),
        "bankAccountingCurrecny": MessageLookupByLibrary.simpleMessage(
            "Loại tiền tệ tài khoản ngân hàng"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Thông tin ngân hàng"),
        "bankName": MessageLookupByLibrary.simpleMessage("Tên ngân hàng"),
        "bankTransfer":
            MessageLookupByLibrary.simpleMessage("Chuyển khoản ngân hàng"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Đã tìm thấy mã vạch"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Hóa đơn"),
        "billTo": MessageLookupByLibrary.simpleMessage("Người nhận hóa đơn"),
        "branchName": MessageLookupByLibrary.simpleMessage("Tên chi nhánh"),
        "brand": MessageLookupByLibrary.simpleMessage("Thương hiệu"),
        "brandName": MessageLookupByLibrary.simpleMessage("Tên thương hiệu"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("Tải lên hàng loạt"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Danh mục kinh doanh"),
        "buy": MessageLookupByLibrary.simpleMessage("Mua"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Mua gói cao cấp"),
        "buySms": MessageLookupByLibrary.simpleMessage("Mua Sms"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Bằng cách truy cập hoặc sử dụng Hệ thống Quầy bán hàng (POS) (\"Hệ thống\") do [Tên Công ty của bạn] (\"Công ty\") cung cấp, bạn đồng ý tuân theo những Điều khoản Sử dụng này. Nếu bạn không đồng ý với những Điều khoản Sử dụng này, xin đừng sử dụng Hệ thống."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Bạn có trách nhiệm đảm bảo rằng việc truy cập và sử dụng Hệ thống của bạn tuân thủ tất cả các luật pháp và quy định có liên quan."),
        "cacel": MessageLookupByLibrary.simpleMessage("Hủy"),
        "call": MessageLookupByLibrary.simpleMessage("Gọi"),
        "callForEmergencySupport":
            MessageLookupByLibrary.simpleMessage("Gọi hỗ trợ khẩn cấp"),
        "camera": MessageLookupByLibrary.simpleMessage("Máy ảnh"),
        "cancel": MessageLookupByLibrary.simpleMessage("Hủy"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Hủy tất cả sản phẩm"),
        "capacity": MessageLookupByLibrary.simpleMessage("Dung tích"),
        "card": MessageLookupByLibrary.simpleMessage("Thẻ"),
        "cash": MessageLookupByLibrary.simpleMessage("Tiền mặt"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Danh mục"),
        "category": MessageLookupByLibrary.simpleMessage("Danh mục"),
        "categoryName": MessageLookupByLibrary.simpleMessage("Tên danh mục"),
        "categoryNameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Tên danh mục đã tồn tại"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("Tên danh mục"),
        "change": MessageLookupByLibrary.simpleMessage("Thay đổi?"),
        "changePassword": MessageLookupByLibrary.simpleMessage("Đổi mật khẩu"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("Kiểm tra Email"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Chọn một khách hàng"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Chọn một nhà cung cấp"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Chọn tính năng của bạn"),
        "clarence": MessageLookupByLibrary.simpleMessage("Clarence"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Nhấn để kết nối"),
        "close": MessageLookupByLibrary.simpleMessage("Đóng"),
        "color": MessageLookupByLibrary.simpleMessage("Màu sắc"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(Kết hợp của nhiều loại thuế)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Sắp ra mắt"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Địa chỉ Công ty"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Tên Công ty & Cửa hàng"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("Tên Công ty & Doanh Nghiệp"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Hoàn tất giao dịch"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Xác nhận mật khẩu"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Xác nhận trả lại"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Chúc mừng"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Liên hệ chúng tôi"),
        "continu": MessageLookupByLibrary.simpleMessage("Tiếp tục"),
        "country": MessageLookupByLibrary.simpleMessage("Quốc gia"),
        "create": MessageLookupByLibrary.simpleMessage("Tạo"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Tạo tài khoản miễn phí"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Đã tạo và lưu"),
        "currency": MessageLookupByLibrary.simpleMessage("Tiền tệ"),
        "currentStock":
            MessageLookupByLibrary.simpleMessage("Tồn kho hiện tại"),
        "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
            "Tùy chỉnh thương hiệu hóa hóa đơn"),
        "customer": MessageLookupByLibrary.simpleMessage("Khách hàng"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Chi tiết khách hàng"),
        "customerGST":
            MessageLookupByLibrary.simpleMessage("GST của khách hàng"),
        "customerName": MessageLookupByLibrary.simpleMessage("Tên khách hàng"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Giao dịch hàng ngày"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Tổng quan bảng điều khiển"),
        "dataSavedSuccessfully": MessageLookupByLibrary.simpleMessage(
            "Dữ liệu đã được lưu thành công"),
        "date": MessageLookupByLibrary.simpleMessage("Ngày"),
        "day": MessageLookupByLibrary.simpleMessage("Ngày"),
        "dealer": MessageLookupByLibrary.simpleMessage("Nhà phân phối"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("Giá đại lý"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("Tỷ lệ VAT mặc định"),
        "delete": MessageLookupByLibrary.simpleMessage("Xóa"),
        "deleting": MessageLookupByLibrary.simpleMessage("Đang xóa"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Địa chỉ giao hàng"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Địa chỉ giao hàng"),
        "deliveryCharge": MessageLookupByLibrary.simpleMessage("Phí giao hàng"),
        "describtion": MessageLookupByLibrary.simpleMessage("Mô tả"),
        "description": MessageLookupByLibrary.simpleMessage("Mô tả"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Mô tả không được để trống"),
        "details": MessageLookupByLibrary.simpleMessage("Chi tiết"),
        "discount": MessageLookupByLibrary.simpleMessage("Giảm giá"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Không làm phiền"),
        "done": MessageLookupByLibrary.simpleMessage("Hoàn tất"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Tải xuống định dạng Excel"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Tải xuống thành công trong thư mục tải xuống"),
        "due": MessageLookupByLibrary.simpleMessage("Nợ"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Số nợ: "),
        "dueCollection": MessageLookupByLibrary.simpleMessage("Thu nợ"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("Báo cáo thu tiền đúng hạn"),
        "dueList": MessageLookupByLibrary.simpleMessage("Danh sách nợ"),
        "dueReports": MessageLookupByLibrary.simpleMessage("Báo cáo nợ"),
        "duration": MessageLookupByLibrary.simpleMessage("Thời gian"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Thời gian: Từ"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "Ứng dụng Pos Saas dễ sử dụng trên điện thoại"),
        "edit": MessageLookupByLibrary.simpleMessage("Chỉnh sửa"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Chỉnh sửa hóa đơn mua hàng"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Chỉnh sửa hóa đơn bán hàng"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Chỉnh sửa mạng xã hội"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Chỉnh sửa thành công"),
        "editTax": MessageLookupByLibrary.simpleMessage("Chỉnh sửa thuế"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Chỉnh sửa nhóm thuế"),
        "editWarehouse": MessageLookupByLibrary.simpleMessage("Chỉnh sửa kho"),
        "email": MessageLookupByLibrary.simpleMessage("Email"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("Địa chỉ Email"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Email không được để trống"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "Email đã được gửi! Kiểm tra hộp thư của bạn"),
        "endDate": MessageLookupByLibrary.simpleMessage("Ngày kết thúc"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Nhập số tiền hợp lệ"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Nhập mức giảm giá hợp lệ"),
        "enterAValidPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Nhập số điện thoại hợp lệ"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Nhập giá hợp lệ"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("Nhập số lượng hợp lệ"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("Nhập địa chỉ"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("Nhập số tiền."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Nhập tên thương hiệu"),
        "enterCapacity": MessageLookupByLibrary.simpleMessage("Nhập dung tích"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Nhập tên danh mục"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Nhập màu sắc"),
        "enterCustomerGstNumber":
            MessageLookupByLibrary.simpleMessage("Nhập số GST của khách hàng"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Nhập giá đại lý"),
        "enterDescription": MessageLookupByLibrary.simpleMessage("Nhập mô tả"),
        "enterDiscount": MessageLookupByLibrary.simpleMessage("Nhập giảm giá"),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Nhập ngày chi phí"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Nhập địa chỉ đầy đủ"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Nhập số hóa đơn"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Nhập số lượng cảnh báo tồn kho thấp"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Nhập nhà sản xuất"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("Nhập nội dung tin nhắn"),
        "enterMrpOrRetailerPirce":
            MessageLookupByLibrary.simpleMessage("Nhập giá bán lẻ"),
        "enterName": MessageLookupByLibrary.simpleMessage("Nhập tên"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Nhập ghi chú"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Nhập tên bên tham gia"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Nhập số điện thoại"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Nhập mã sản phẩm hoặc quét mã"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Nhập tên sản phẩm"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Nhập giá mua"),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("Nhập số tham chiếu"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Nhập kích thước"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("Nhập tồn kho"),
        "enterTaxRate": MessageLookupByLibrary.simpleMessage("Nhập tỷ lệ thuế"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("Nhập ID giao dịch"),
        "enterType": MessageLookupByLibrary.simpleMessage("Nhập loại"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("Nhập chức danh người dùng"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Nhập số tiền hợp lệ"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Nhập tên kho"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Nhập trọng lượng"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Nhập giá sỉ"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("Nhập mô tả của bạn ở đây"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("Nhập địa chỉ email của bạn"),
        "enterYourFeedBackTitle":
            MessageLookupByLibrary.simpleMessage("Nhập tiêu đề phản hồi"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Nhập số GST của bạn"),
        "enterYourMobileNumber": MessageLookupByLibrary.simpleMessage(
            "Nhập số điện thoại di động của bạn"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Nhập tên của bạn"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("Nhập số điện thoại của bạn"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Nhập mật khẩu của bạn"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Nhập số điện thoại của bạn"),
        "enterYourTransactionId":
            MessageLookupByLibrary.simpleMessage("Nhập mã giao dịch của bạn"),
        "error": MessageLookupByLibrary.simpleMessage("Lỗi"),
        "excTax": MessageLookupByLibrary.simpleMessage("Không bao gồm thuế"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("Tải lên Excel"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Không bao gồm"),
        "expense": MessageLookupByLibrary.simpleMessage("Chi phí"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Danh mục chi phí"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Ngày chi phí"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Chi phí cho"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Báo cáo chi phí"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Ngày hết hạn"),
        "expired": MessageLookupByLibrary.simpleMessage("Đã hết hạn"),
        "expiring": MessageLookupByLibrary.simpleMessage("Sắp hết hạn"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Thất bại với lỗi"),
        "fashion": MessageLookupByLibrary.simpleMessage("Thời trang"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Các tính năng là phần quan trọng làm nên sự khác biệt của Pos Saas so với các giải pháp truyền thống."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Phản hồi"),
        "firstName": MessageLookupByLibrary.simpleMessage("Tên"),
        "followUsOnFacebook": MessageLookupByLibrary.simpleMessage(
            "Theo dõi chúng tôi trên\\nFacebook"),
        "followUsOnTwitter": MessageLookupByLibrary.simpleMessage(
            "Theo dõi chúng tôi trên\\nTwitter"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Mặt trước"),
        "forUnlimitedUses": MessageLookupByLibrary.simpleMessage(
            "Cho việc sử dụng không giới hạn"),
        "forgotPassword": MessageLookupByLibrary.simpleMessage("Quên mật khẩu"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Quên mật khẩu?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Từ ngày"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("Sao lưu dữ liệu miễn phí"),
        "freeLifeTimeUpdate":
            MessageLookupByLibrary.simpleMessage("Cập nhật trọn đời miễn phí"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Gói miễn phí"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Gói miễn phí"),
        "from": MessageLookupByLibrary.simpleMessage("(Từ"),
        "fullyPaid":
            MessageLookupByLibrary.simpleMessage("Đã thanh toán đầy đủ"),
        "gallary": MessageLookupByLibrary.simpleMessage("Thư viện"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("Đang tạo PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Nhận mã OTP"),
        "govermentId":
            MessageLookupByLibrary.simpleMessage("Chứng minh thư nhân dân"),
        "guest": MessageLookupByLibrary.simpleMessage("Khách"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Chưa có tài khoản?"),
        "history": MessageLookupByLibrary.simpleMessage("Lịch sử"),
        "home": MessageLookupByLibrary.simpleMessage("Trang chủ"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Chúng tôi bảo vệ Thông tin của bạn như thế nào"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Chúng tôi sử dụng Thông tin của bạn như thế nào"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Xác minh danh tính"),
        "image": MessageLookupByLibrary.simpleMessage("Hình ảnh"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("InHouse không thể xóa"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("InHouse không thể chỉnh sửa"),
        "inWord": MessageLookupByLibrary.simpleMessage("Bằng chữ"),
        "incTax": MessageLookupByLibrary.simpleMessage("Bao gồm thuế"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Bao gồm"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("Tăng tồn kho"),
        "inistrument":
            MessageLookupByLibrary.simpleMessage("Phương tiện thanh toán"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Số hóa đơn"),
        "invoice": MessageLookupByLibrary.simpleMessage("Hóa đơn"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("Số hóa đơn"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Cài đặt hóa đơn"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Trình xem hóa đơn"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Đã thêm sản phẩm"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification": MessageLookupByLibrary.simpleMessage("Xác minh KYC"),
        "language": MessageLookupByLibrary.simpleMessage("Ngôn ngữ"),
        "lastName": MessageLookupByLibrary.simpleMessage("Họ"),
        "ledger": MessageLookupByLibrary.simpleMessage("Sổ cái"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Mua một lần\ntrọn đời"),
        "link": MessageLookupByLibrary.simpleMessage("Liên kết"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Hỗ trợ trò chuyện trực tiếp"),
        "loading": MessageLookupByLibrary.simpleMessage("Đang tải"),
        "logIn": MessageLookupByLibrary.simpleMessage("Đăng nhập"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Đăng xuất"),
        "logOut": MessageLookupByLibrary.simpleMessage("Đăng xuất"),
        "login": MessageLookupByLibrary.simpleMessage("Đăng nhập"),
        "logo": MessageLookupByLibrary.simpleMessage("Logo"),
        "loss": MessageLookupByLibrary.simpleMessage("Lỗ"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Lỗ/Lãi"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Chi tiết lỗ/lãi"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Báo cáo lỗ/lãi"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Báo cáo lỗ/lãi"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Cảnh báo tồn kho thấp"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Tạo ấn tượng lâu dài đối với khách hàng của bạn với hóa đơn có thương hiệu riêng. Bản nâng cấp không giới hạn của chúng tôi cung cấp lợi thế duy nhất của việc tùy chỉnh hóa đơn của bạn, thêm một nét chuyên nghiệp tạo sự nhận diện thương hiệu và khuyến khích sự trung thành của khách hàng."),
        "manageYourBussinessWith": MessageLookupByLibrary.simpleMessage(
            "Quản lý doanh nghiệp của bạn với"),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Ngày sản xuất"),
        "margin": MessageLookupByLibrary.simpleMessage("Biên độ"),
        "masterCard": MessageLookupByLibrary.simpleMessage("Thẻ MasterCard"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Nhà sản xuất"),
        "message": MessageLookupByLibrary.simpleMessage("Tin nhắn"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Lịch sử tin nhắn"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Ứng dụng Pos Saas miễn phí, dễ sử dụng. Thực tế, đây là một trong những hệ thống POS tốt nhất trên thế giới."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas là một giải pháp kinh doanh hoàn chỉnh với quản lý kho, tài khoản, bán hàng, chi phí và lỗ/lãi."),
        "mobile": MessageLookupByLibrary.simpleMessage("Di động"),
        "mobilePayment":
            MessageLookupByLibrary.simpleMessage("Thanh toán di động"),
        "monthly": MessageLookupByLibrary.simpleMessage("Hàng tháng"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("Thông tin thêm"),
        "name": MessageLookupByLibrary.simpleMessage("Nhập tên của bạn."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Tên đã tồn tại"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("Tên không thể để trống"),
        "next": MessageLookupByLibrary.simpleMessage("Tiếp theo"),
        "noConnection":
            MessageLookupByLibrary.simpleMessage("Không có kết nối"),
        "noData": MessageLookupByLibrary.simpleMessage("Không có dữ liệu"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Không có dữ liệu"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Không tìm thấy dữ liệu"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("Không có lịch sử nào!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Không tìm thấy sản phẩm nào"),
        "noSubTaxSelected": MessageLookupByLibrary.simpleMessage(
            "Không có thuế phụ nào được chọn"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("Không tìm thấy giao dịch!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Không tìm thấy người dùng nào với địa chỉ email đó."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "Không tìm thấy vai trò người dùng"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Người dùng không hoạt động"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Chưa cung cấp"),
        "note": MessageLookupByLibrary.simpleMessage("Ghi chú"),
        "notes": MessageLookupByLibrary.simpleMessage("Ghi chú"),
        "notification": MessageLookupByLibrary.simpleMessage("Thông báo"),
        "oTPSentTo":
            MessageLookupByLibrary.simpleMessage("Mã OTP đã được gửi đến"),
        "office": MessageLookupByLibrary.simpleMessage("Văn phòng"),
        "ok": MessageLookupByLibrary.simpleMessage("Đồng ý"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "Hệ thống POS chứa rất nhiều tính năng, bao gồm theo dõi bán hàng và quản lý hàng tồn kho."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Hệ thống này giúp bạn cải thiện hoạt động kinh doanh cho khách hàng của bạn."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Hệ thống POS của chúng tôi nên tự động hóa các hoạt động hàng ngày, giúp dễ dàng trong việc điều hướng."),
        "openingBalance": MessageLookupByLibrary.simpleMessage("Số dư đầu kỳ"),
        "order": MessageLookupByLibrary.simpleMessage("Đơn đặt hàng"),
        "other": MessageLookupByLibrary.simpleMessage("Khác"),
        "otp": MessageLookupByLibrary.simpleMessage("Đóng"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Hết hàng"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Gói"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Tính năng của gói"),
        "paid": MessageLookupByLibrary.simpleMessage("Đã thanh toán"),
        "paidAmount":
            MessageLookupByLibrary.simpleMessage("Số tiền đã thanh toán"),
        "parties": MessageLookupByLibrary.simpleMessage("Bên tham gia"),
        "partiesList":
            MessageLookupByLibrary.simpleMessage("Danh sách bên tham gia"),
        "partyGST": MessageLookupByLibrary.simpleMessage("GST bên"),
        "partyName": MessageLookupByLibrary.simpleMessage("Tên bên tham gia"),
        "password": MessageLookupByLibrary.simpleMessage("Mật khẩu"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Mật khẩu và xác nhận mật khẩu không khớp"),
        "passwordCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Mật khẩu không được để trống"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("Mật khẩu không khớp"),
        "payCash":
            MessageLookupByLibrary.simpleMessage("Thanh toán bằng tiền mặt"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("Thanh toán bằng bkash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Thanh toán bằng Paypal"),
        "payeeName":
            MessageLookupByLibrary.simpleMessage("Tên người nhận thanh toán"),
        "payeeNumber":
            MessageLookupByLibrary.simpleMessage("Số người nhận thanh toán"),
        "payment": MessageLookupByLibrary.simpleMessage("Thanh toán"),
        "paymentAmount":
            MessageLookupByLibrary.simpleMessage("Số tiền thanh toán"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Thanh toán hoàn tất"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Hướng dẫn thanh toán:"),
        "paymentMethod":
            MessageLookupByLibrary.simpleMessage("Phương thức thanh toán"),
        "paymentType":
            MessageLookupByLibrary.simpleMessage("Hình thức thanh toán"),
        "pdfView": MessageLookupByLibrary.simpleMessage("Xem PDF"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Thông tin cá nhân"),
        "phone": MessageLookupByLibrary.simpleMessage("Điện thoại"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Số điện thoại"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Số điện thoại đã được sử dụng"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("Số điện thoại không hợp lệ"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("Số điện thoại là bắt buộc"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("Chọn và tải lên tệp"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("Chọn ngày kết thúc"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Chọn ngày bắt đầu"),
        "plan": MessageLookupByLibrary.simpleMessage("Kế hoạch"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("Vui lòng thêm số lượng"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Vui lòng kiểm tra kết nối internet của bạn"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Vui lòng kết nối máy in trước"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Vui lòng kết nối máy in Bluetooth của bạn"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Vui lòng nhập mật khẩu lớn hơn"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Vui lòng nhập xác nhận mật khẩu"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("Vui lòng nhập mật khẩu"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Vui lòng nhập một email hợp lệ"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Vui lòng nhập tên"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("Vui lòng nhập mật khẩu"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Vui lòng nhập địa chỉ email của bạn bên dưới để nhận liên kết đặt lại mật khẩu."),
        "pleaseEnterTransactionNumber":
            MessageLookupByLibrary.simpleMessage("Vui lòng nhập số giao dịch"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("Vui lòng nhập số tiền"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Vui lòng chọn một loại trước"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("Vui lòng chọn một gói"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Vui lòng chọn loại hình doanh nghiệp"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Vui lòng sử dụng mã mua hàng hợp lệ để sử dụng ứng dụng"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Được hỗ trợ bởi Pos Saas"),
        "poweredBy":
            MessageLookupByLibrary.simpleMessage("Được phát triển bởi"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Hỗ trợ khách hàng cao cấp"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Gói cao cấp"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Số tiền thanh toán trước đó"),
        "price": MessageLookupByLibrary.simpleMessage("Giá"),
        "print": MessageLookupByLibrary.simpleMessage("In"),
        "printingOption": MessageLookupByLibrary.simpleMessage("Tùy chọn in"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Chính sách bảo mật"),
        "product": MessageLookupByLibrary.simpleMessage("Sản phẩm"),
        "productCode": MessageLookupByLibrary.simpleMessage("Mã sản phẩm"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("Mã sản phẩm là bắt buộc"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Mã sản phẩm/Tên sản phẩm"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Mô tả sản phẩm"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Chi tiết sản phẩm"),
        "productList":
            MessageLookupByLibrary.simpleMessage("Danh sách sản phẩm"),
        "productName": MessageLookupByLibrary.simpleMessage("Tên sản phẩm"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Tên sản phẩm đã tồn tại trong kho này"),
        "productNameIsAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("Tên sản phẩm đã được thêm"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("Tên sản phẩm là bắt buộc"),
        "products": MessageLookupByLibrary.simpleMessage("Sản phẩm"),
        "profile": MessageLookupByLibrary.simpleMessage("Hồ sơ"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("Chỉnh sửa hồ sơ"),
        "profit": MessageLookupByLibrary.simpleMessage("Lãi"),
        "promo": MessageLookupByLibrary.simpleMessage("Khuyến mãi"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Mã khuyến mãi"),
        "purchase": MessageLookupByLibrary.simpleMessage("Mua hàng"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("Báo động mua hàng"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Xác nhận mua hàng"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Chi tiết mua hàng"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Hóa đơn mua hàng"),
        "purchaseList":
            MessageLookupByLibrary.simpleMessage("Danh sách mua hàng"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Mua ngay"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Mua gói cao cấp"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("Giá mua"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("Giá mua là bắt buộc"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("Báo cáo mua hàng"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Báo cáo mua hàng"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Báo cáo mua hàng"),
        "purchaseReturn": MessageLookupByLibrary.simpleMessage("Trả hàng mua"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("Báo cáo trả hàng mua"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Chuyển tiếp mua hàng"),
        "qty": MessageLookupByLibrary.simpleMessage("Số lượng"),
        "quantity": MessageLookupByLibrary.simpleMessage("Số lượng"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Giao dịch gần đây"),
        "recivedThePin": MessageLookupByLibrary.simpleMessage("Nhận mã PIN"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Số tham chiếu"),
        "register": MessageLookupByLibrary.simpleMessage("Đăng ký"),
        "registering": MessageLookupByLibrary.simpleMessage("Đang đăng ký"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("Nợ còn lại"),
        "remove": MessageLookupByLibrary.simpleMessage("Xóa"),
        "reports": MessageLookupByLibrary.simpleMessage("Báo cáo"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Yêu cầu đã được gửi"),
        "resendCode": MessageLookupByLibrary.simpleMessage("Gửi lại mã"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("Gửi lại mã OTP: "),
        "retailer": MessageLookupByLibrary.simpleMessage("Nhà bán lẻ"),
        "retur": MessageLookupByLibrary.simpleMessage("Trả hàng"),
        "returN": MessageLookupByLibrary.simpleMessage("Trả lại"),
        "returnAMount":
            MessageLookupByLibrary.simpleMessage("Số tiền hoàn trả"),
        "returnAmount":
            MessageLookupByLibrary.simpleMessage("Số tiền hoàn trả"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("Số lượng trả lại"),
        "revenue": MessageLookupByLibrary.simpleMessage("Doanh thu"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Bảo vệ dữ liệu kinh doanh của bạn một cách dễ dàng. Bản nâng cấp không giới hạn của Pos Saas POS bao gồm việc sao lưu dữ liệu miễn phí, đảm bảo thông tin quý báu của bạn được bảo vệ trước bất kỳ sự kiện bất ngờ nào. Tập trung vào những điều thực sự quan trọng - sự phát triển kinh doanh của bạn."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Số tiền bán hàng"),
        "saleDetails":
            MessageLookupByLibrary.simpleMessage("Chi tiết bán hàng"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Giá bán"),
        "saleReports": MessageLookupByLibrary.simpleMessage("Báo cáo bán hàng"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Báo cáo bán hàng"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("Trả lại bán hàng"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Báo cáo trả lại bán hàng"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("Cài đặt bán hàng"),
        "sales": MessageLookupByLibrary.simpleMessage("Doanh thu"),
        "salesAndPurchaseReports": MessageLookupByLibrary.simpleMessage(
            "Báo cáo Bán hàng và Mua hàng"),
        "salesList": MessageLookupByLibrary.simpleMessage("Danh sách bán hàng"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("Trả lại bán hàng"),
        "save": MessageLookupByLibrary.simpleMessage("Lưu"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Lưu và Xuất bản"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("Lưu thay đổi"),
        "saving": MessageLookupByLibrary.simpleMessage("Đang lưu"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("Quét mã QR sản phẩm"),
        "search": MessageLookupByLibrary.simpleMessage("Tìm kiếm"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Tìm kiếm theo mã sản phẩm hoặc tên"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("Xem tất cả mã khuyến mãi"),
        "select": MessageLookupByLibrary.simpleMessage("Chọn"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Chọn một sản phẩm để trả lại"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Chọn thương hiệu"),
        "selectCategory": MessageLookupByLibrary.simpleMessage("Chọn loại"),
        "selectContacts": MessageLookupByLibrary.simpleMessage("Chọn danh bạ"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("Chọn loại sản phẩm"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("Chọn loại cửa hàng"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Chọn thuế"),
        "selectTaxType": MessageLookupByLibrary.simpleMessage("Chọn loại thuế"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("Chọn đơn vị"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Chọn biến thể: "),
        "seller": MessageLookupByLibrary.simpleMessage("Người bán"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Bán bởi"),
        "send": MessageLookupByLibrary.simpleMessage("Gửi"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("Gửi email"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Gửi tin nhắn"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("Gửi liên kết đặt lại"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Gửi tin nhắn SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Gửi tin nhắn SMS?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Gửi tin nhắn WhatsApp"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Gửi email của bạn"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage("Đang gửi Email"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Đang gửi tin nhắn"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Dịch vụ/Giao hàng"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Thiết lập hồ sơ của bạn"),
        "setting": MessageLookupByLibrary.simpleMessage("Cài đặt"),
        "share": MessageLookupByLibrary.simpleMessage("Chia sẻ"),
        "shopGST": MessageLookupByLibrary.simpleMessage("GST cửa hàng"),
        "signIn": MessageLookupByLibrary.simpleMessage("Đăng Nhập"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("Đăng nhập bằng email"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Chữ ký của khách hàng"),
        "size": MessageLookupByLibrary.simpleMessage("Kích thước"),
        "skip": MessageLookupByLibrary.simpleMessage("Bỏ qua"),
        "sms": MessageLookupByLibrary.simpleMessage("Sms"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Tiếp thị xã hội"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Xin lỗi, bạn không có quyền truy cập dịch vụ này"),
        "startDate": MessageLookupByLibrary.simpleMessage("Ngày bắt đầu"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Bắt đầu bán hàng mới"),
        "startTypingToSearch":
            MessageLookupByLibrary.simpleMessage("Bắt đầu nhập để tìm kiếm"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Luôn ở phía trước của sự phát triển công nghệ mà không tốn thêm chi phí. Bản nâng cấp không giới hạn của Pos Saas POS đảm bảo bạn luôn có các công cụ và tính năng mới nhất ngay trước mắt, đảm bảo doanh nghiệp của bạn luôn ở mức đỉnh cao."),
        "stillUnpaid":
            MessageLookupByLibrary.simpleMessage("Vẫn chưa thanh toán"),
        "stock": MessageLookupByLibrary.simpleMessage("Tồn kho"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Tồn kho là bắt buộc"),
        "stockList":
            MessageLookupByLibrary.simpleMessage("Danh sách hàng tồn kho"),
        "stocks": MessageLookupByLibrary.simpleMessage("Tồn kho"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Quyền truy cập lưu trữ là bắt buộc để tạo tệp Excel"),
        "subTaxList":
            MessageLookupByLibrary.simpleMessage("Danh sách thuế phụ"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Thuế phụ"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Tổng phụ"),
        "submit": MessageLookupByLibrary.simpleMessage("Gửi"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "Đăng ký kênh\\nYoutube của chúng tôi"),
        "subscription": MessageLookupByLibrary.simpleMessage("Đăng ký"),
        "successfullyDone": MessageLookupByLibrary.simpleMessage("Thành công"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Đã đăng xuất thành công"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Cập nhật thành công"),
        "supplier": MessageLookupByLibrary.simpleMessage("Nhà cung cấp"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("Tên nhà cung cấp"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("Mã SWIFT"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Chụp hình bằng lái xe, chứng minh nhân dân hoặc hộ chiếu"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "Chụp chứng minh thư để kiểm tra thông tin của bạn"),
        "tap": MessageLookupByLibrary.simpleMessage("Nhấn"),
        "tax": MessageLookupByLibrary.simpleMessage("Thuế"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Nhóm thuế"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("Tỷ lệ thuế"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Tỷ lệ thuế"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Tỷ lệ thuế - Quản lý tỷ lệ thuế của bạn"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Báo cáo thuế"),
        "taxType": MessageLookupByLibrary.simpleMessage("Loại thuế"),
        "taxes": MessageLookupByLibrary.simpleMessage("Thuế"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Điều khoản và điều kiện"),
        "termsOfUse":
            MessageLookupByLibrary.simpleMessage("Điều khoản sử dụng"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Điều khoản & Chính sách"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Cảm ơn bạn đã thanh toán nợ của mình"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Cảm ơn bạn"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Cảm ơn bạn đã mua hàng"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "Tài khoản đã tồn tại cho email đó"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage("Tệp Excel đã được tải xuống"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Tên nói lên tất cả. Với Pos Saas POS Unlimited, không giới hạn về việc sử dụng của bạn. Cho dù bạn đang xử lý một số giao dịch hoặc đối mặt với một lượng lớn khách hàng, bạn có thể hoạt động với sự tự tin, biết rằng bạn không bị giới hạn bởi các hạn chế."),
        "thePasswordProvidedIsTooWeak":
            MessageLookupByLibrary.simpleMessage("Mật khẩu cung cấp quá yếu"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Bán hàng sẽ bị xóa và tất cả dữ liệu liên quan đến giao dịch này sẽ bị xóa. Bạn có chắc chắn muốn xóa không?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Bán hàng sẽ bị xóa và tất cả dữ liệu liên quan đến giao dịch này sẽ bị xóa. Bạn có chắc chắn muốn xóa không?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Người dùng sẽ bị xóa và tất cả dữ liệu sẽ bị xóa khỏi tài khoản của bạn. Bạn có chắc chắn muốn xóa không?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Người dùng sẽ bị xóa và tất cả dữ liệu sẽ bị xóa khỏi tài khoản của bạn. Bạn có chắc chắn muốn xóa không?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Dịch vụ của Bên thứ ba"),
        "thisCategoryCannotBeDeleted":
            MessageLookupByLibrary.simpleMessage("Danh mục này không thể xóa"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Tháng này)"),
        "thisProductAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("Sản phẩm này đã được thêm"),
        "title": MessageLookupByLibrary.simpleMessage("Tiêu đề"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Tiêu đề không được để trống"),
        "to": MessageLookupByLibrary.simpleMessage("đến"),
        "toDate": MessageLookupByLibrary.simpleMessage("Đến ngày"),
        "today": MessageLookupByLibrary.simpleMessage("Hôm nay"),
        "total": MessageLookupByLibrary.simpleMessage("Tổng cộng"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Tổng số tiền"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Tổng số tiền thu được"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Tổng nợ"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("Tổng chi phí"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Tổng lỗ"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("Tổng cần thanh toán"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Tổng giá"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("Tổng số sản phẩm"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Tổng lợi nhuận"),
        "totalPurchase":
            MessageLookupByLibrary.simpleMessage("Tổng số hàng mua"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Tổng số tiền trả lại"),
        "totalReturns":
            MessageLookupByLibrary.simpleMessage("Tổng số hàng trả lại"),
        "totalSale":
            MessageLookupByLibrary.simpleMessage("Tổng doanh số bán hàng"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Tổng tồn kho"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Tổng giá trị"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Tổng VAT"),
        "totals": MessageLookupByLibrary.simpleMessage("Tổng: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Giao dịch"),
        "transactionId": MessageLookupByLibrary.simpleMessage("Mã giao dịch"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Thử lại"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Loại"),
        "unitName": MessageLookupByLibrary.simpleMessage("Tên đơn vị"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Đơn giá"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Giá đơn vị"),
        "units": MessageLookupByLibrary.simpleMessage("Đơn vị"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Không giới hạn"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Sử dụng không giới hạn"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Mở khóa tiềm năng đầy đủ của Pos Saas POS với các buổi đào tạo cá nhân do đội ngũ chuyên gia của chúng tôi dẫn đầu. Từ cơ bản đến các kỹ thuật tiên tiến, chúng tôi đảm bảo bạn thông thạo trong việc sử dụng mọi khía cạnh của hệ thống để tối ưu hóa quy trình kinh doanh của bạn."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Chưa thanh toán"),
        "update": MessageLookupByLibrary.simpleMessage("Cập nhật"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Cập nhật liên hệ"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Cập nhật ngay"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("Cập nhật sản phẩm"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Cập nhật kế hoạch của bạn trước, giới hạn của bạn đã hết"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Cập nhật hồ sơ của bạn"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Cập nhật hồ sơ của bạn để kết nối với bác sĩ của bạn với ấn tượng tốt hơn"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Cập nhật hồ sơ để kết nối với khách hàng một cách tốt hơn"),
        "updated": MessageLookupByLibrary.simpleMessage("Đã cập nhật"),
        "upload": MessageLookupByLibrary.simpleMessage("Tải lên"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Tải tài liệu lên"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("Tải lên hoàn tất"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Tải tệp lên"),
        "usbC": MessageLookupByLibrary.simpleMessage("Usb C"),
        "use": MessageLookupByLibrary.simpleMessage("Sử dụng"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("Sử dụng Pos Saas"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Sử dụng của hệ thống"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Người dùng đã bị xóa"),
        "userRole": MessageLookupByLibrary.simpleMessage("Vai trò người dùng"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("Chi tiết vai trò người dùng"),
        "userTitle":
            MessageLookupByLibrary.simpleMessage("Chức danh người dùng"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Tiêu đề người dùng không thể để trống"),
        "value": MessageLookupByLibrary.simpleMessage("Giá trị"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("VAT không áp dụng"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("Xác minh mã OTP"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Xác minh số điện thoại"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Xem tất cả"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("Xem chi tiết"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Khách đến mua trực tiếp"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Kho"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Kho đã tồn tại"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("Danh sách kho"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("Tên kho"),
        "warranty": MessageLookupByLibrary.simpleMessage("Bảo hành"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Chúng tôi đã gửi một email với hướng dẫn về cách đặt lại mật khẩu đến:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Chúng tôi có thể sử dụng các dịch vụ của bên thứ ba để hỗ trợ tính năng của ứng dụng của chúng tôi, chẳng hạn như các nhà cung cấp phân tích và bộ xử lý thanh toán. Những dịch vụ của bên thứ ba này có thể thu thập thông tin về bạn khi bạn sử dụng ứng dụng của chúng tôi. Xin lưu ý rằng chúng tôi không chịu trách nhiệm về thực tiễn bảo mật của những dịch vụ của bên thứ ba này."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Chúng tôi thực hiện các biện pháp theo tiêu chuẩn ngành để bảo vệ thông tin cá nhân của bạn, bao gồm mã hóa và lưu trữ an toàn. Chúng tôi cũng giới hạn quyền truy cập vào thông tin của bạn chỉ cho nhân viên được ủy quyền."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Chúng tôi hiểu tầm quan trọng của việc thực hiện hoạt động mượt mà. Đó là lý do tại sao dịch vụ hỗ trợ suốt ngày đêm của chúng tôi sẵn sàng hỗ trợ bạn, cho dù đó là một câu hỏi nhanh chóng hay một vấn đề toàn diện. Kết nối với chúng tôi bất cứ lúc nào, bất kỳ nơi đâu thông qua cuộc gọi hoặc WhatsApp để trải nghiệm dịch vụ khách hàng vượt trội."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Chúng tôi sử dụng thông tin cá nhân của bạn để cung cấp cho bạn trải nghiệm tốt nhất có thể trên ứng dụng của chúng tôi, bao gồm cá nhân hóa gợi ý nội dung, kết nối bạn với các chuyên gia và cải thiện tính năng của ứng dụng của chúng tôi. Chúng tôi cũng có thể sử dụng thông tin của bạn để liên lạc với bạn về cập nhật, khuyến mãi hoặc thông tin khác liên quan đến ứng dụng của chúng tôi."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Chúng tôi sẽ xem xét thanh toán và phê duyệt trong vòng 1-2 giờ"),
        "weekly": MessageLookupByLibrary.simpleMessage("Hàng tuần"),
        "weight": MessageLookupByLibrary.simpleMessage("Trọng lượng"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Có gì mới"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Người bán sỉ"),
        "wholeSalePrice": MessageLookupByLibrary.simpleMessage("Giá sỉ"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("Giá sỉ"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Nhà bán buôn"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Sẽ được thêm sớm"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Sẽ hết hạn vào"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Viết tin nhắn của bạn ở đây"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("Mã OTP không đúng"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Mật khẩu không đúng cho người dùng đó."),
        "yearly": MessageLookupByLibrary.simpleMessage("Hàng năm"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Có, Xóa Vĩnh Viễn"),
        "youAreNotAValidUser": MessageLookupByLibrary.simpleMessage(
            "Bạn không phải là người dùng hợp lệ"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Bạn đang sử dụng"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Bạn không thể thanh toán nhiều hơn số tiền đến hạn"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Bạn đã nhận được một email"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Bạn đã đăng nhập thành công vào tài khoản của bạn. Hãy ở lại với Pos Saas ."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("Bạn phải cấp quyền"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Bạn phải ĐĂNG NHẬP lại vào tài khoản của mình."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Bạn cần xác minh danh tính trước khi mua sms"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Tin nhắn của bạn còn lại"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Gói của bạn"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Gói của bạn sẽ hết hạn trong 5 ngày")
      };
}
