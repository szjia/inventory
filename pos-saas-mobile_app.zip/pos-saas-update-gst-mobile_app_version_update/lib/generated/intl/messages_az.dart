// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a az locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'az';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Davamlama"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("GST Nömrəsi"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("MRP tələb olunur"),
        "OK": MessageLookupByLibrary.simpleMessage("Tamam"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Tel. Nömrəsi"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT Kodu"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Şirniyyat"),
        "TAX": MessageLookupByLibrary.simpleMessage("VERGİ"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Yüklənir"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("İstifadəçi Başlığı"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Paketiniz bu gün sona çatır\n\nXahiş edirik yenidən alın"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) Sistem yalnız işinizdə satış əməliyyatlarını və əlaqəli fəaliyyətlərin təmin edilməsi məqsədi ilə təqdim edilir."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) Sistemi istifadə etmək üçün hesab yaratmağınız tələb oluna bilər. Qeydiyyat prosesində düzgün, cari və tam məlumat təqdim etməyi və bu məlumatları düzgün və tam saxlamağınıza razısınız."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("Tətbiq haqqında"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Haqqımızda"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Şərtlərin Qəbulu"),
        "accountName": MessageLookupByLibrary.simpleMessage("Hesabın adı"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("Hesab nömrəsi"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Hesabın Qeydiyyatı"),
        "acton": MessageLookupByLibrary.simpleMessage("Fəaliyyət"),
        "add": MessageLookupByLibrary.simpleMessage("Əlavə et"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Marka əlavə et"),
        "addCategory":
            MessageLookupByLibrary.simpleMessage("Kateqoriya əlavə et"),
        "addContact": MessageLookupByLibrary.simpleMessage("Əlaqə əlavə et"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Müştəri əlavə et"),
        "addDelivery":
            MessageLookupByLibrary.simpleMessage("Çatdırılma əlavə et"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Təsvir əlavə et"),
        "addDescription": MessageLookupByLibrary.simpleMessage("Qeyd əlavə et"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Endirim əlavə et"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Sənəd İD əlavə edin"),
        "addDucument": MessageLookupByLibrary.simpleMessage("Sənəd əlavə et"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Xərclər əlavə et"),
        "addExpenseCategory": MessageLookupByLibrary.simpleMessage(
            "Xərclər Kateqoriyası əlavə et"),
        "addItems": MessageLookupByLibrary.simpleMessage("Məhsulları əlavə et"),
        "addNew": MessageLookupByLibrary.simpleMessage("Yeni əlavə et"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Yeni ünvan əlavə et"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Yeni Məhsul əlavə et"),
        "addNewTax":
            MessageLookupByLibrary.simpleMessage("Yeni Vergi əlavə et"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Tək/müxtəlif vergi növü ilə yeni vergi əlavə et"),
        "addNote": MessageLookupByLibrary.simpleMessage("Qeyd əlavə et"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Əvvəlcə məhsul əlavə edin"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Promo kod əlavə et"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Alış əlavə et"),
        "addSales": MessageLookupByLibrary.simpleMessage("Satış əlavə et"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Əlavə uğurlu oldu"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Vahid əlavə et"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("İstifadəçi rolunu əlavə et"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Uğurla əlavə edildi"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("Səbətə əlavə edildi"),
        "address": MessageLookupByLibrary.simpleMessage("Ünvan"),
        "admin": MessageLookupByLibrary.simpleMessage("İdarəçi"),
        "all": MessageLookupByLibrary.simpleMessage("Hamısı"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("Bütün biznes həlləri"),
        "alreadyAdded":
            MessageLookupByLibrary.simpleMessage("Artıq əlavə edilib"),
        "alreadyExists":
            MessageLookupByLibrary.simpleMessage("Artıq mövcuddur"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Artıq bir hesabınız var?"),
        "amount": MessageLookupByLibrary.simpleMessage("Məbləğ"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "Bir e-poçt göndərilib.\\nGiriş qovluğunuzu yoxlayın"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Android və iOS Tətbiq Dəstəyi"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Tətbiq olunan vergi"),
        "apply": MessageLookupByLibrary.simpleMessage("Tətbiq et"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Bu fakturanı silmək istədiyinizdən əminsiniz?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Bu satışı silmək istədiyinizdən əminsiniz?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Bu istifadəçini silmək istədiyinizə əminsiniz?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Bu vergini silmək istədiyinizə əminsinizmi?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Bu vergi qrupunu silmək istədiyinizə əminsinizmi?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Bu anbarı silmək istədiyinizə əminsinizmi?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Bu istifadəçini silməyə əminsiniz?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Səlahiyyətli İmza"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Siz, hesabınızın və parolunuzun gizliliyini qorumaq və hesabınıza girişi məhdudlaşdırmaq üçün məsulsunuz. Siz, hesabınızın altında baş verən bütün fəaliyyətlərə məsuliyət daşıyırsınız."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Siz, Sistemi istifadə etmək üçün yaşınızın 18 ildən az olmaması və ya ictimai əksərlik yaşının lazımi yaşınızdan az olmaması tələb olunur."),
        "backSide": MessageLookupByLibrary.simpleMessage("Arxa tərəf"),
        "backToHome":
            MessageLookupByLibrary.simpleMessage("Ana səhifəyə qayıt"),
        "balance": MessageLookupByLibrary.simpleMessage("Balans"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Banqladeş"),
        "bank": MessageLookupByLibrary.simpleMessage("Bank"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Bank Hesabı Valyutası"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Bank Hesabının Valyutası"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Bank Məlumatı"),
        "bankName": MessageLookupByLibrary.simpleMessage("Bankın adı"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("Bank Transferi"),
        "barcodeFound": MessageLookupByLibrary.simpleMessage("Barkod tapıldı"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Faktura"),
        "billTo": MessageLookupByLibrary.simpleMessage("Ödəniş üçün"),
        "branchName": MessageLookupByLibrary.simpleMessage("Filial adı"),
        "brand": MessageLookupByLibrary.simpleMessage("Marka"),
        "brandName": MessageLookupByLibrary.simpleMessage("Marka Adı"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("Toplu Yükləmə"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Biznes Kateqoriyası"),
        "buy": MessageLookupByLibrary.simpleMessage("Satın al"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Premium Planı al"),
        "buySms": MessageLookupByLibrary.simpleMessage("SMS al"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Şirkətin tərəfindən təqdim edilən Satış Nöqtəsi (POS) Sisteminə (\"Sistem\") giriş etməklə və ya onu istifadə etməklə, bu İstifadə Şərtlərinə əməl etməyi razılaşdığınızı qəbul edirsiniz. Əgər bu İstifadə Şərtlərinə razılaşmırsınızsa, Sistemi istifadə etməyin."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Sizin Sistəmə giriş və onun istifadəsinin bütün tətbiq edilən qanun və törəmələrə əməl etməsi üçün məsul olduğunuzdan əmin olmağınız üçün məsuldirsiz."),
        "cacel": MessageLookupByLibrary.simpleMessage("Ləğv et"),
        "call": MessageLookupByLibrary.simpleMessage("Zəng"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "Təcili Dəstək üçün zəng edin"),
        "camera": MessageLookupByLibrary.simpleMessage("Kamera"),
        "cancel": MessageLookupByLibrary.simpleMessage("İmtina et"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Bütün məhsulları ləğv et"),
        "capacity": MessageLookupByLibrary.simpleMessage("Kapasitet"),
        "card": MessageLookupByLibrary.simpleMessage("Kart"),
        "cash": MessageLookupByLibrary.simpleMessage("Nağd"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Kassasız"),
        "categories": MessageLookupByLibrary.simpleMessage("Kateqoriyalar"),
        "category": MessageLookupByLibrary.simpleMessage("Kateqoriya"),
        "categoryName": MessageLookupByLibrary.simpleMessage("Kateqoriya adı"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "Kateqoriya adı artıq mövcuddur"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("Kateqoriya Adı"),
        "change": MessageLookupByLibrary.simpleMessage("Dəyişdir?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Şifrəni Dəyişdir"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("Emaili yoxlayın"),
        "choseACustomer": MessageLookupByLibrary.simpleMessage("Müştəri seçin"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Təchizatçı seçin"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Xüsusiyyətlərinizi seçin"),
        "clarence": MessageLookupByLibrary.simpleMessage("Klarans"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Əlaqə qurmaq üçün klik edin"),
        "close": MessageLookupByLibrary.simpleMessage("Bağla"),
        "color": MessageLookupByLibrary.simpleMessage("Rəng"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(Bir neçə verginin birləşməsi)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Tezliklə"),
        "companyAddress": MessageLookupByLibrary.simpleMessage("Şirkət Ünvanı"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Şirkət və Mağaza Adı"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("Şirkət və Biznes Adı"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Əməliyyatı başa çatdır"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Şifrəni Təsdiq Edin"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Qayıtmanı təsdiqləyin"),
        "congratulations":
            MessageLookupByLibrary.simpleMessage("Təbrik edirik"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Bizimlə Əlaqə"),
        "continu": MessageLookupByLibrary.simpleMessage("Davam et"),
        "country": MessageLookupByLibrary.simpleMessage("Ölkə"),
        "create": MessageLookupByLibrary.simpleMessage("Yarat"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Pulsuz Hesab Yarat"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Yaradıldı və saxlandı"),
        "currency": MessageLookupByLibrary.simpleMessage("Valyuta"),
        "currentStock": MessageLookupByLibrary.simpleMessage("Cari Stok"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("Xüsusi Faktura Brendinqi"),
        "customer": MessageLookupByLibrary.simpleMessage("Müştəri"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Müştəri məlumatları"),
        "customerGST": MessageLookupByLibrary.simpleMessage("Müştəri GST"),
        "customerName": MessageLookupByLibrary.simpleMessage("Müştəri Adı"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Günlük əməliyyatlar"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("İdarə Paneli Baxışı"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Məlumat uğurla saxlanıldı"),
        "date": MessageLookupByLibrary.simpleMessage("Tarix"),
        "day": MessageLookupByLibrary.simpleMessage("Gün"),
        "dealer": MessageLookupByLibrary.simpleMessage("Bayi"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("Bayi Qiyməti"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("Standart ƏDV faizi"),
        "delete": MessageLookupByLibrary.simpleMessage("Sil"),
        "deleting": MessageLookupByLibrary.simpleMessage("Silinmə"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Çatdırılma ünvanı"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Çatdırılma ünvanları"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Çatdırılma Dəyəri"),
        "describtion": MessageLookupByLibrary.simpleMessage("Təsvir"),
        "description": MessageLookupByLibrary.simpleMessage("Təsvir"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Təsvir boş ola bilməz"),
        "details": MessageLookupByLibrary.simpleMessage("Detallar"),
        "discount": MessageLookupByLibrary.simpleMessage("Endirim"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Zəng etməyin"),
        "done": MessageLookupByLibrary.simpleMessage("Tamamlandı"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Excel formatını yüklə"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Yükləmə qovluğunda uğurla yükləndi"),
        "due": MessageLookupByLibrary.simpleMessage("Qalıq"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Qalıq Məbləği: "),
        "dueCollection": MessageLookupByLibrary.simpleMessage("Qalıq Toplama"),
        "dueCollectionReports": MessageLookupByLibrary.simpleMessage(
            "Gözlənilən Toplama Hesabatları"),
        "dueList": MessageLookupByLibrary.simpleMessage("Qalıq Siyahısı"),
        "dueReports": MessageLookupByLibrary.simpleMessage("Borc Hesabatları"),
        "duration": MessageLookupByLibrary.simpleMessage("Müddət"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Müddət: Dən"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "Asan istifadə edilən mobil POS"),
        "edit": MessageLookupByLibrary.simpleMessage("Düzəlt"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Alış Fakturasını düzəlt"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Satış Fakturasını düzəlt"),
        "editSocailMedia": MessageLookupByLibrary.simpleMessage(
            "Sosial Media Nişanını düzəlt"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Uğurla redaktə edildi"),
        "editTax": MessageLookupByLibrary.simpleMessage("Vergini redaktə et"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Vergi qrupunu redaktə et"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("Anbarı redaktə et"),
        "email": MessageLookupByLibrary.simpleMessage("Email"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("Email Ünvanı"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("E-poçt boş ola bilməz"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "E-poçt göndərildi! Giriş qutunuzu yoxlayın"),
        "endDate": MessageLookupByLibrary.simpleMessage("Son Tarix"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Etibarlı məbləğ daxil edin"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Keçərli endirim daxil edin"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Etibarlı telefon nömrəsi daxil edin"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Keçərli qiymət daxil edin"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("Keçərli miqdar daxil edin"),
        "enterAddress":
            MessageLookupByLibrary.simpleMessage("Ünvanı daxil edin"),
        "enterAmount":
            MessageLookupByLibrary.simpleMessage("Məbləği daxil edin"),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Marka Adını daxil edin"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Kapasiteti daxil edin"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Kateqoriya Adını daxil edin"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Rəngi daxil edin"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "Müştərinin GST nömrəsini daxil edin"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Bayi Qiymətini daxil edin"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Təsviri daxil edin"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("Endirimi daxil edin"),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Xərclər Tarixini daxil edin"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Tam Ünvanı Daxil Edin"),
        "enterInvoiceNumber": MessageLookupByLibrary.simpleMessage(
            "Faktura Nömrəsini daxil edin"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Aşağı stok xəbərdarlığı miqdarını daxil edin"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("İstehsalçını daxil edin"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("Mesaj məzmununu daxil edin"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "MRP/Dərman satan Qiymətini daxil edin"),
        "enterName": MessageLookupByLibrary.simpleMessage("Adını daxil edin"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Qeydi daxil edin"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Tərəf adını daxil edin"),
        "enterPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Telefon Nömrəsini Daxil Edin"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Məhsul Kodunu daxil edin və ya skan edin"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Məhsul Adını daxil edin"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Alış Qiymətini daxil edin"),
        "enterReferenceNumber": MessageLookupByLibrary.simpleMessage(
            "İstinad Nömrəsini daxil edin"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Ölçüyü daxil edin"),
        "enterStocks":
            MessageLookupByLibrary.simpleMessage("Stokları daxil edin"),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Vergi dərəcəsini daxil edin"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("Təhvilat İdini daxil edin"),
        "enterType": MessageLookupByLibrary.simpleMessage("Növü daxil edin"),
        "enterUserTitle": MessageLookupByLibrary.simpleMessage(
            "İstifadəçi başlığını daxil edin"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Etibarlı məbləğ daxil edin"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Anbar adını daxil edin"),
        "enterWeight":
            MessageLookupByLibrary.simpleMessage("Çəkiyi daxil edin"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Topdan Qiymətini daxil edin"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("Məzmunu buraya daxil edin"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("Email adresinizi daxil edin"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "Sizin Feedback Başlığınızı daxil edin"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("GST nömrənizi daxil edin"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("Mobil nömrənizi daxil edin"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Adınızı daxil edin"),
        "enterYourNumber": MessageLookupByLibrary.simpleMessage(
            "Telefon nömrənizi daxil edin"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Öz şifrənizi daxil edin"),
        "enterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Telefon nömrənizi daxil edin"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "Əməliyyat nömrənizi daxil edin"),
        "error": MessageLookupByLibrary.simpleMessage("Xəta"),
        "excTax": MessageLookupByLibrary.simpleMessage("Xaric edilmiş vergi"),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("Excel Yükləyici"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Xaricdir"),
        "expense": MessageLookupByLibrary.simpleMessage("Xərc"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Xərclər Kateqoriyası"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Xərclər Tarixi"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Xərclər üçün"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Xərclər Hesabatı"),
        "expireDate":
            MessageLookupByLibrary.simpleMessage("Son istifadə tarixi"),
        "expired": MessageLookupByLibrary.simpleMessage("Bitmiş"),
        "expiring": MessageLookupByLibrary.simpleMessage("Bitmə"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Xəta ilə uğursuz oldu"),
        "fashion": MessageLookupByLibrary.simpleMessage("Moda"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Xüsusiyyətlər, Pos Saas \'nı ənənəvi həlllərdən fərqləndirən əsas hissəsidir."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Feedback"),
        "firstName": MessageLookupByLibrary.simpleMessage("Adınız"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Bizi Facebook\'da izləyin"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Bizi Twitter\'da izləyin"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Ön tərəf"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("Limitsiz istifadə üçün"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Şifrəni unutmusunuz?"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Şifrəni unutmusunuz?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Başlanğıc Tarix"),
        "freeDataBackup": MessageLookupByLibrary.simpleMessage(
            "Pulsuz Məlumat Ehtiyat nüsxələri"),
        "freeLifeTimeUpdate":
            MessageLookupByLibrary.simpleMessage("Pulsuz Ömürboyu Yeniləmə"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Pulsuz Paket"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Pulsuz Plan"),
        "from": MessageLookupByLibrary.simpleMessage("(Dən"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Tam ödənilib"),
        "gallary": MessageLookupByLibrary.simpleMessage("Qalereya"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("PDF Yaradılır"),
        "getOtp": MessageLookupByLibrary.simpleMessage("OTP əldə et"),
        "govermentId": MessageLookupByLibrary.simpleMessage("Hökumət Təyinatı"),
        "guest": MessageLookupByLibrary.simpleMessage("Qonaq"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Hesabınız yoxdur?"),
        "history": MessageLookupByLibrary.simpleMessage("Tarix"),
        "home": MessageLookupByLibrary.simpleMessage("Əsas Səhifə"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Məlumatınızı necə qoruduğumuz"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Məlumatınızı necə istifadə etdiyimiz"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Şəxsiyyəti təsdiqlə"),
        "image": MessageLookupByLibrary.simpleMessage("Şəkil"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("İçəridə silinə bilməz"),
        "inHouseCantBeEdited": MessageLookupByLibrary.simpleMessage(
            "İçəridə redaktə oluna bilməz"),
        "inWord": MessageLookupByLibrary.simpleMessage("Sözlə"),
        "incTax": MessageLookupByLibrary.simpleMessage("Daxil edilmiş vergi"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Daxildir"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("Stoku artır"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Alət"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Fatura №"),
        "invoice": MessageLookupByLibrary.simpleMessage("Faktura"),
        "invoiceNumber":
            MessageLookupByLibrary.simpleMessage("Faktura Nömrəsi"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Faktura Ayarları"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Faktura görüntüləyici"),
        "itemAdded":
            MessageLookupByLibrary.simpleMessage("Məhsul əlavə edildi"),
        "kg": MessageLookupByLibrary.simpleMessage("Kq"),
        "kycVerification": MessageLookupByLibrary.simpleMessage("KYC Təsdiq"),
        "language": MessageLookupByLibrary.simpleMessage("Dil"),
        "lastName": MessageLookupByLibrary.simpleMessage("Soyadınız"),
        "ledger": MessageLookupByLibrary.simpleMessage("Cari Hesab"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Ömürboyu\nAlış"),
        "link": MessageLookupByLibrary.simpleMessage("Link"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Canlı Çat Dəstəyi"),
        "loading": MessageLookupByLibrary.simpleMessage("Yüklənir"),
        "logIn": MessageLookupByLibrary.simpleMessage("Daxil ol"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Çıxış"),
        "logOut": MessageLookupByLibrary.simpleMessage("Çıxış et"),
        "login": MessageLookupByLibrary.simpleMessage("Daxil ol"),
        "logo": MessageLookupByLibrary.simpleMessage("Logo"),
        "loss": MessageLookupByLibrary.simpleMessage("Zərər"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Zərər/Qazanc"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Zərər/Qazanc Detalları"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Ziyan/Qazanc Hesabatı"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Ziyan/Qazanc Hesabatları"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Aşağı stok xəbərdarlığı"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Müştərilərinizə brend edilmiş fakturalarla sonsuz təsir bıraxın. Bizim Sınırsız Yeniləmə, fakturalarınızı özəlləşdirmənizin unikal üstünlüyünü təklif edir və markanızın identitetini təmin edən və müştəri loyallığını artıran professional bir toxunuş əlavə edir."),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("Biznesinizi idarə edin "),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("İstehsal tarixi"),
        "margin": MessageLookupByLibrary.simpleMessage("Marja"),
        "masterCard": MessageLookupByLibrary.simpleMessage("MasterCard"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("İstehsalçı"),
        "message": MessageLookupByLibrary.simpleMessage("Mesaj"),
        "messageHistory": MessageLookupByLibrary.simpleMessage("Mesaj Tarixi"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Pos Saas tətbiqi pulsuzdur, istifadəsi asandır. Əslində, bu ən yaxşı POS sistemlərindən biridir."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas, stok, hesab, satış, xərclər və itkil/qazanç ilə tam bir biznes həllidir."),
        "mobile": MessageLookupByLibrary.simpleMessage("Mobil"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("Mobil Ödəniş"),
        "monthly": MessageLookupByLibrary.simpleMessage("Aylıq"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("Daha çox məlumat"),
        "name": MessageLookupByLibrary.simpleMessage("Adınızı daxil edin"),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Ad artıq mövcuddur"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("Ad boş ola bilməz"),
        "next": MessageLookupByLibrary.simpleMessage("Növbəti"),
        "noConnection": MessageLookupByLibrary.simpleMessage("Bağlantı yoxdur"),
        "noData": MessageLookupByLibrary.simpleMessage("Məlumat yoxdur"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Məlumat yoxdur"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Heç bir məlumat tapılmadı"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("Heç bir tarix tapılmadı!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Məhsul tapılmadı"),
        "noSubTaxSelected": MessageLookupByLibrary.simpleMessage(
            "Heç bir alt vergi seçilməyib"),
        "noTransactionFound": MessageLookupByLibrary.simpleMessage(
            "Heç bir əməliyyat tapılmadı!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Bu email ünvanı üçün istifadəçi tapılmadı."),
        "noUserRoleFound":
            MessageLookupByLibrary.simpleMessage("İstifadəçi rolu tapılmadı"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Aktiv istifadəçi deyil"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Təmin edilməyib"),
        "note": MessageLookupByLibrary.simpleMessage("Qeyd"),
        "notes": MessageLookupByLibrary.simpleMessage("Qeydlər"),
        "notification": MessageLookupByLibrary.simpleMessage("Bildiriş"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP göndərildi"),
        "office": MessageLookupByLibrary.simpleMessage("Ofis"),
        "ok": MessageLookupByLibrary.simpleMessage("Oldu"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "Böyük funksionalitet daxil olmaqla satışın izlənməsi və ehtiyatın idarə olunması əlaqəli çox sayda funksiyaları olan POS sistem."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Bu sistem sizin müştəriləriniz üçün əməliyyatlarınızı təkmilləşdirməyə kömək edir."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Bizim POS sistemi avtomatik olaraq günlük əməliyyatları sadələşdirməlidir, naviqasiya etməyi asanlaşdırmaq üçün."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("Əvvəlki Balans "),
        "order": MessageLookupByLibrary.simpleMessage("Sifarişlər"),
        "other": MessageLookupByLibrary.simpleMessage("Digər"),
        "otp": MessageLookupByLibrary.simpleMessage("Bağla"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Anbarda yoxdur"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Paket"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Paket Xüsusiyyətləri"),
        "paid": MessageLookupByLibrary.simpleMessage("Ödənilmiş"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Ödənilən Məbləğ"),
        "parties": MessageLookupByLibrary.simpleMessage("Tərəflər"),
        "partiesList":
            MessageLookupByLibrary.simpleMessage("Tərəflər Siyahısı"),
        "partyGST": MessageLookupByLibrary.simpleMessage("Tərəf GST"),
        "partyName": MessageLookupByLibrary.simpleMessage("Tərəf adı"),
        "password": MessageLookupByLibrary.simpleMessage("Şifrə"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Şifrə və təsdiq şifrəsi uyğun gəlmir"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Şifrə boş ola bilməz"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("Şifrə uyğun gəlmir"),
        "payCash": MessageLookupByLibrary.simpleMessage("Nəğd ödəniş"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("Bkash ilə ödəyin"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Paypal ilə ödəyin"),
        "payeeName": MessageLookupByLibrary.simpleMessage("Alıcı adı"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("Alıcı nömrəsi"),
        "payment": MessageLookupByLibrary.simpleMessage("Ödəniş"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("Ödəniş Məbləği"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Ödəniş Tamamlandı"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Ödəniş Təlimatları:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("Ödəniş Metodu"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Ödəniş Növü"),
        "pdfView": MessageLookupByLibrary.simpleMessage("PDF Görünüşü"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Şəxsi məlumatlar"),
        "phone": MessageLookupByLibrary.simpleMessage("Telefon"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Telefon Nömrəsi"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Telefon nömrəsi artıq istifadə olunur"),
        "phoneNumberIsNotValid": MessageLookupByLibrary.simpleMessage(
            "Telefon nömrəsi etibarsızdır"),
        "phoneNumberIsRequired": MessageLookupByLibrary.simpleMessage(
            "Telefon nömrəsi tələb olunur"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("Faylı seçin və yükləyin"),
        "pickEndDate": MessageLookupByLibrary.simpleMessage("Son Tarix Seçin"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Başlanğıc Tarixi Seçin"),
        "plan": MessageLookupByLibrary.simpleMessage("Plan"),
        "pleaseAddQuantity": MessageLookupByLibrary.simpleMessage(
            "Zəhmət olmasa, miqdar əlavə edin"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Zəhmət olmasa, internet bağlantınızı yoxlayın"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Zəhmət olmasa, əvvəlcə printeri qoşun"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Zəhmət olmasa, bluetooth printerinizi qoşun"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Zəhmət olmasa, daha uzun şifrə daxil edin"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Zəhmət olmasa, şifrəni təsdiq edin"),
        "pleaseEnterAPassword": MessageLookupByLibrary.simpleMessage(
            "Zəhmət olmasa, şifrə daxil edin"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Zəhmət olmasa, etibarlı e-poçt daxil edin"),
        "pleaseEnterName": MessageLookupByLibrary.simpleMessage(
            "Zəhmət olmasa, ad daxil edin"),
        "pleaseEnterPassword": MessageLookupByLibrary.simpleMessage(
            "Zəhmət olmasa şifrəni daxil edin"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Şifrə bərpa linkini almaq üçün email adresinizi daxil edin."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Zəhmət olmasa, əməliyyat nömrəsini daxil edin"),
        "pleaseInterAmount": MessageLookupByLibrary.simpleMessage(
            "Zəhmət olmasa, məbləği daxil edin"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Zəhmət olmasa, əvvəlcə bir kateqoriya seçin"),
        "pleaseSelectAPlan": MessageLookupByLibrary.simpleMessage(
            "Zəhmət olmasa, bir plan seçin"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Zəhmət olmasa, biznes kateqoriyasını seçin"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Zəhmət olmasa, tətbiqi istifadə etmək üçün keçərli alış kodunu istifadə edin"),
        "powerdedByMobiPos": MessageLookupByLibrary.simpleMessage(
            "Pos Saas tərəfindən təchiz edilmişdir"),
        "poweredBy":
            MessageLookupByLibrary.simpleMessage("Tərəfindən təmin edilir"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Premium Müştəri Dəstəyi"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Premium plan"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Əvvəlki Ödəniş Məbləği"),
        "price": MessageLookupByLibrary.simpleMessage("Qiymət"),
        "print": MessageLookupByLibrary.simpleMessage("Çap Et"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Çap Etma Seçimi"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Gizlilik Siyasəti"),
        "product": MessageLookupByLibrary.simpleMessage("Məhsul"),
        "productCode": MessageLookupByLibrary.simpleMessage("Məhsul Kodu"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("Məhsul kodu tələb olunur"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Məhsul kodu/Adı"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Məhsul Təsviri"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Məhsul Detalları"),
        "productList": MessageLookupByLibrary.simpleMessage("Məhsul Siyahısı"),
        "productName": MessageLookupByLibrary.simpleMessage("Məhsul Adı"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Məhsul adı artıq bu anbarada mövcuddur"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Məhsul adı artıq əlavə edilib"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("Məhsul adı tələb olunur"),
        "products": MessageLookupByLibrary.simpleMessage("Məhsullar"),
        "profile": MessageLookupByLibrary.simpleMessage("Profil"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("Profil Redaktəsi"),
        "profit": MessageLookupByLibrary.simpleMessage("Qazanc"),
        "promo": MessageLookupByLibrary.simpleMessage("Promo"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Promo Kod"),
        "purchase": MessageLookupByLibrary.simpleMessage("Alış"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage("Alış Bildirişi"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Alış Təsdiqləndi"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Alış Detalları"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Alış Fakturası"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("Alış Siyahısı"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("İndi Al"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Premium Planı alın"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("Alış Qiyməti"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("Alış qiyməti tələb olunur"),
        "purchaseRepoet": MessageLookupByLibrary.simpleMessage("Alış Hesabatı"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Alış Hesabatları"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Alış Hesabatları"),
        "purchaseReturn": MessageLookupByLibrary.simpleMessage("Alış Qayıdışı"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("Alış Qayıdışı Hesabatı"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Alış Keçidi"),
        "qty": MessageLookupByLibrary.simpleMessage("Miqdar"),
        "quantity": MessageLookupByLibrary.simpleMessage("Miqdar"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Son əməliyyatlar"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("Pin Kodu Aldınız"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("İstinad Nömrəsi"),
        "register": MessageLookupByLibrary.simpleMessage("Qeydiyyatdan keçin"),
        "registering": MessageLookupByLibrary.simpleMessage("Qeydiyyat"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("Qalıq Borc"),
        "remove": MessageLookupByLibrary.simpleMessage("Sil"),
        "reports": MessageLookupByLibrary.simpleMessage("Hesabatlar"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Sorğu göndərildi"),
        "resendCode":
            MessageLookupByLibrary.simpleMessage("Kodu yenidən göndər"),
        "resendOtp":
            MessageLookupByLibrary.simpleMessage("OTP yenidən göndər: "),
        "retailer": MessageLookupByLibrary.simpleMessage("Pul satan"),
        "retur": MessageLookupByLibrary.simpleMessage("Geri"),
        "returN": MessageLookupByLibrary.simpleMessage("Qayıdış"),
        "returnAMount":
            MessageLookupByLibrary.simpleMessage("Geriyə Ödəmə Məbləği"),
        "returnAmount":
            MessageLookupByLibrary.simpleMessage("Qaytarılma Məbləği"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("Qayıdış miqdarı"),
        "revenue": MessageLookupByLibrary.simpleMessage("Gəlir"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Sənayeniz məlumatını asandır şəkildə qoruyun. Bizim Pos Saas POS Unlimited Yeniləməsi pulsuz məlumat ehtiyat nüsxələri daxil edir, qiymətli məlumatınızın heç bir gözlənməz hadisəyə qarşı qorunmasını təmin edir. Əsl əhəmiyyəti olan şəyə fokuslanın - işinizin inkişafı."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Satış Məbləği"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("Satış Detalları"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Satış Qiyməti"),
        "saleReports":
            MessageLookupByLibrary.simpleMessage("Satış Hesabatları"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Satış Hesabatları"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("Satış qayıdışı"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Satış Qayıdışı Hesabatı"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("Satış Ayarları"),
        "sales": MessageLookupByLibrary.simpleMessage("Satışlar"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("Satış və Alış Hesabatları"),
        "salesList": MessageLookupByLibrary.simpleMessage("Satış Siyahısı"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("Satış Qayıdışı"),
        "save": MessageLookupByLibrary.simpleMessage("Saxla"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Yadda Saxla və Yayınla"),
        "saveChanges":
            MessageLookupByLibrary.simpleMessage("Dəyişiklikləri saxla"),
        "saving": MessageLookupByLibrary.simpleMessage("Saxlama"),
        "scanProductQRCode": MessageLookupByLibrary.simpleMessage(
            "Məhsulun QR kodunu skan edin"),
        "search": MessageLookupByLibrary.simpleMessage("Axtar"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Məhsul kodu və ya adla axtarın"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("Bütün promo kodları gör"),
        "select": MessageLookupByLibrary.simpleMessage("Seç"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Qayıtma üçün bir məhsul seçin"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Marka seçin"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Kateqoriyanı seçin"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Əlaqələri seçin"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("Məhsul kateqoriyasını seçin"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("Mağaza kateqoriyasını seçin"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Vergi seçin"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Vergi növünü seçin"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("Vahid seçin"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Çeşidləmə Seç: "),
        "seller": MessageLookupByLibrary.simpleMessage("Satıcı"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Satılır"),
        "send": MessageLookupByLibrary.simpleMessage("Göndər"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("Email Göndər"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Mesaj göndər"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("Bərpa Linkini Göndər"),
        "sendSms": MessageLookupByLibrary.simpleMessage("SMS Göndər"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("SMS göndərilsin?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("WhatsApp mesajı göndər"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Emailinizi göndər"),
        "sendingEmail":
            MessageLookupByLibrary.simpleMessage("E-poçt göndərilir"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Mesaj göndərilir"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Xidmət/Çatdırılma"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Profilinizi tənzimləyin"),
        "setting": MessageLookupByLibrary.simpleMessage("Tənzimləmə"),
        "share": MessageLookupByLibrary.simpleMessage("Paylaş"),
        "shopGST": MessageLookupByLibrary.simpleMessage("Mağaza GST"),
        "signIn": MessageLookupByLibrary.simpleMessage("Daxil ol"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("E-poçt ilə daxil olun"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Müştərinin İmzası"),
        "size": MessageLookupByLibrary.simpleMessage("Ölçü"),
        "skip": MessageLookupByLibrary.simpleMessage("Keç"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Sosial Marketinq"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Bağışlayın, bu xidmətə daxil olmaq üçün icazəniz yoxdur"),
        "startDate": MessageLookupByLibrary.simpleMessage("Başlanğıc Tarixi"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Yeni Satışa Başla"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage(
            "Axtarış üçün yazmaya başlayın"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Hər hansı əlavə xərclər olmadan texnologiya ən son nailiyyətlərinin əvvəlində qalın. Bizim Pos Saas POS Unlimited Yeniləməsi həmişə ən son alətlər və xüsusiyyətlərin əlçatanızda olduğundan əmin edir və işinizin ən son nailiyyətlərlə davam etdiyini təmin edir."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("Hələ ödənilməyib"),
        "stock": MessageLookupByLibrary.simpleMessage("Sahiblik"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Saxlama tələb olunur"),
        "stockList": MessageLookupByLibrary.simpleMessage("Stok Siyahısı"),
        "stocks": MessageLookupByLibrary.simpleMessage("Stoklar"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Excel faylı yaratmaq üçün saxlama icazəsi tələb olunur"),
        "subTaxList":
            MessageLookupByLibrary.simpleMessage("Alt Vergi Siyahısı"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Alt Vergilər"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Alt Cəm"),
        "submit": MessageLookupByLibrary.simpleMessage("Təsdiq et"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "Youtube kanalımıza abunə olun"),
        "subscription": MessageLookupByLibrary.simpleMessage("Abunə"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Uğurla tamamlandı"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Uğurla çıxış etdiniz"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Uğurla yeniləndi"),
        "supplier": MessageLookupByLibrary.simpleMessage("Təchizatçı"),
        "supplierName": MessageLookupByLibrary.simpleMessage("Təchizatçı Adı"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT Kodu"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Sürücü vəsiqəsi, milli şəxsiyyət vəsiqəsi və ya pasportunuzun şəklini çəkin"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "Məlumatlarınızı yoxlamaq üçün şəxsiyyət vəsiqəsini götürün"),
        "tap": MessageLookupByLibrary.simpleMessage("Toxun"),
        "tax": MessageLookupByLibrary.simpleMessage("Vergi"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Vergi qrupu"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("Vergi Faizi"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Vergi dərəcəsi"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Vergi dərəcələri - Vergi dərəcələrinizi idarə edin"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Vergi hesabatı"),
        "taxType": MessageLookupByLibrary.simpleMessage("Vergi növü"),
        "taxes": MessageLookupByLibrary.simpleMessage("Vergilər"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Şərtlər və qaydalar"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("İstifadə Şərtləri"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Şərtlər və Məlumatlar"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Borcunuzu ödədiyiniz üçün təşəkkür edirik"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Təşəkkür edirik"),
        "thankYouForYourPurchase": MessageLookupByLibrary.simpleMessage(
            "Alış-verişiniz üçün təşəkkür edirik"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "O email üçün hesab artıq mövcuddur"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Excel faylı artıq yüklənmişdir"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Adı hər şeyi deyir. Pos Saas POS Unlimited ilə istifadənizdə heç bir məhdudiyyət yoxdur. Bir neçə əməliyyatı emal etməniz və ya müştərilərin dəhşətli qovuşması varsa, məhdudiyyətlərlə məhdudlaşmadığınızı bilərək özünüzü fəaliyyət göstərə bilərsiniz."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "Təqdim olunan şifrə çox zəifdir"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Satış silinəcək və bu alışla bağlı bütün məlumatlar silinəcək. Bu satışın silinməsindən əminsiniz?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Satış silinəcək və bu satışla bağlı bütün məlumatlar silinəcək. Bu satışın silinməsindən əminsiniz?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "İstifadəçi silinəcək və bütün məlumatlar hesabınızdan silinəcək. Əminsiniz?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "İstifadəçi silinəcək və bütün məlumatlar hesabınızdan silinəcək. Bu istifadəçini silmək istədiyinizə əminsiniz?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Üçüncü Tərəf Xidmətləri"),
        "thisCategoryCannotBeDeleted":
            MessageLookupByLibrary.simpleMessage("Bu kateqoriya silinə bilməz"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Bu Ay)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Bu məhsul artıq əlavə edilib"),
        "title": MessageLookupByLibrary.simpleMessage("Başlıq"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Başlıq boş ola bilməz"),
        "to": MessageLookupByLibrary.simpleMessage("dək"),
        "toDate": MessageLookupByLibrary.simpleMessage("Son Tarix"),
        "today": MessageLookupByLibrary.simpleMessage("Bugün"),
        "total": MessageLookupByLibrary.simpleMessage("Cəmi"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Ümumi Məbləğ"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Ümumi Toplanan"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Cəmi Borc"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("Ümumi Xərclər"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Cəmi ziyan"),
        "totalPayable": MessageLookupByLibrary.simpleMessage("Cəmi Ödənilməli"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Cəmi Qiymət"),
        "totalProducts": MessageLookupByLibrary.simpleMessage("Cəmi məhsullar"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Cəmi mənfəət"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("Ümumi Alış"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Ümumi Qayıtma Məbləği"),
        "totalReturns":
            MessageLookupByLibrary.simpleMessage("Ümumi qayıtmalar"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Ümumi Satış"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Ümumi Stoqlar"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Cəmi dəyər"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Ümumi Vət"),
        "totals": MessageLookupByLibrary.simpleMessage("Cəmi: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Əməliyyat"),
        "transactionId":
            MessageLookupByLibrary.simpleMessage("Əməliyyat Nömrəsi"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Yenidən cəhd edin"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Növ"),
        "unitName": MessageLookupByLibrary.simpleMessage("Vahid Adı"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Birim Qiymət"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Birlik Qiyməti"),
        "units": MessageLookupByLibrary.simpleMessage("Vahid"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Limitsiz"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Məhdud olmayan istifadə"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Pos Saas POS\'un bütün potensialını açın, bizim ekspert komandamızın rəhbərliyindəki şəxsi təlim sessiyaları ilə. Əsaslarından başlayaraq təkmilləşmiş texnikalara qədər, sistemə dair hər tərəfin istifadəsində gözəl olacağınızı təmin edirik və iş proseslərinizi optimal etməyinizə kömək edirik."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Ödənilməmiş"),
        "update": MessageLookupByLibrary.simpleMessage("Yeniləyin"),
        "updateContact": MessageLookupByLibrary.simpleMessage("Əlaqəni yenilə"),
        "updateNow": MessageLookupByLibrary.simpleMessage("İndi Yeniləyin"),
        "updateProduct": MessageLookupByLibrary.simpleMessage("Məhsulu Yenilə"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Planınızı ilk olaraq yeniləyin, limitiniz bitib"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Profilinizi Yeniləyin"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Həkiminizi daha yaxşı təmsil etmək üçün profilinizi yeniləyin"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Profilinizi yaxşı təsir ilə müştəriyə qoşmaq üçün yeniləyin"),
        "updated": MessageLookupByLibrary.simpleMessage("Yeniləndi"),
        "upload": MessageLookupByLibrary.simpleMessage("Yüklə"),
        "uploadDocument": MessageLookupByLibrary.simpleMessage("Sənədi yüklə"),
        "uploadDone":
            MessageLookupByLibrary.simpleMessage("Yükləmə tamamlandı"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Faylı yüklə"),
        "upplier": MessageLookupByLibrary.simpleMessage("Təchizatçı"),
        "usbC": MessageLookupByLibrary.simpleMessage("USB C"),
        "use": MessageLookupByLibrary.simpleMessage("İstifadə et"),
        "useMobiPos":
            MessageLookupByLibrary.simpleMessage("Pos Saas istifadə edin"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Sistemin İstifadəsi"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("İstifadəçi silindi"),
        "userRole": MessageLookupByLibrary.simpleMessage("İstifadəçi rolu"),
        "userRoleDetails": MessageLookupByLibrary.simpleMessage(
            "İstifadəçi rolu təfərrüatları"),
        "userTitle": MessageLookupByLibrary.simpleMessage("İstifadəçi Başlığı"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "İstifadəçi başlığı boş ola bilməz"),
        "value": MessageLookupByLibrary.simpleMessage("Dəyər"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("ƏDV tətbiq olunmur"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("OTP yoxlanılır"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Telefon nömrəsini yoxlayın"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Hamısını göstər"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("Detalları bax"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Yürüyən müştəri"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Anbar"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Anbar artıq mövcuddur"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("Anbar siyahısı"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("Anbar adı"),
        "warranty": MessageLookupByLibrary.simpleMessage("Zəmanət"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Biz sizə email göndərdik və şifrəni bərpa etmək üçün təlimatları ötürdük:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Tətbiqimizin funksionalitetini dəstəkləmək üçün analitika təminatçıları və ödəniş emalatçıları kimi üçüncü tərəf xidmətlərindən istifadə edə bilərik. Bu üçüncü tərəf xidmətlər, tətbiqimizi istifadə edərkən sizin haqqınızda məlumat toplaya bilərlər. Xahiş edirik ki, bu üçüncü tərəf xidmətlərin gizlilik tərzlərinə məsul deyilik."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Şəxsi məlumatlarınızı qorumaq üçün şərq standardlarına uyğun tədbirlər götürürük, şamil olmaqla şifrləmə və təhlükəsiz saxlama. Həmçinin, məlumatlarınıza yalnız icazəli şəxslərin girişini məhdudlaşdırırıq."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Biz nəzakətsiz əməliyyatların əhəmiyyətini başa düşürük. Bu, sürətli sorğu və ya ətraflı məsələ olsa da, 24 saat ərzində dəstəyimizin mövcud olduğu bir addımdır. Bizimlə hər hansı bir zaman və yerə zəng və ya WhatsApp vasitəsilə əlaqə quraraq nəzakətsiz müştəri xidmətinin təcrübəsini yaşayın."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Sizin şəxsi məlumatlarınızı tətbiqimizdə ən yaxşı təcrübəni təmin etmək, məzmun təkliflərinizi şəxsiyyətləşdirmək, mütəxəssislərlə sizi əlaqələndirmək və tətbiqimizin funksionalitetini təkmilləşdirmək üçün istifadə edirik. Həmçinin, sizin məlumatlarınızı tətbiqimizlə əlaqəli yeniləmələr, təqdimatlar və digər məlumatlar haqqında sizinlə əlaqə saxlamaq üçün istifadə edə bilərik."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Ödənişi nəzərdən keçirəcəyik və 1-2 saat ərzində təsdiqləyəcəyik"),
        "weekly": MessageLookupByLibrary.simpleMessage("Həftəlik"),
        "weight": MessageLookupByLibrary.simpleMessage("Çəki"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Nə Yeni"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Topdan satan"),
        "wholeSalePrice": MessageLookupByLibrary.simpleMessage("Topdan Qiymət"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("Topdan qiymət"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Topdan satışçı"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Tezliklə əlavə ediləcək"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Bitmə vaxtı"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Mesajınızı buraya yazın"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("Yanlış OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Bu istifadəçi üçün səhv şifrə daxil edildi."),
        "yearly": MessageLookupByLibrary.simpleMessage("İllik"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Bəli, Həmişə sil"),
        "youAreNotAValidUser": MessageLookupByLibrary.simpleMessage(
            "Siz keçərli istifadəçi deyilsiniz"),
        "youAreUsing":
            MessageLookupByLibrary.simpleMessage("Siz istifadə edirsiniz"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Müddətindən artıq ödəyə bilməzsiniz"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Sizə bir email gəlib"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Hesabınıza uğurla daxil oldunuz. Pos Saas ilə qalın."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("İcazə verməlisiniz"),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Alış etmədən əvvəl şəxsiyyətinizi təsdiqləməlisiniz"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Sizin mesajınız qalır"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Sizin Paketiniz"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Paketiniz 5 gün sonra sona çatacaq")
      };
}
