// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a pt locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'pt';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Continue"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("GST Number"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("MRP is required"),
        "OK": MessageLookupByLibrary.simpleMessage("OK"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Tel. nº"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("Código SWIFT"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Snacks"),
        "TAX": MessageLookupByLibrary.simpleMessage("TAX"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Uploading"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("Título do usuário"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "O Seu Pacote Expirará Hoje\n\nPor favor, Compre Novamente"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) O Sistema é fornecido exclusivamente com o propósito de facilitar transações de ponto de venda e atividades relacionadas em seu negócio."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) Para usar o Sistema, você pode ser obrigado a criar uma conta. Você concorda em fornecer informações precisas, atuais e completas durante o processo de registro e em atualizar tais informações para mantê-las precisas e completas."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("Sobre o aplicativo"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("About us"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Aceitação dos Termos"),
        "accountName": MessageLookupByLibrary.simpleMessage("Nome da conta"),
        "accountNumber":
            MessageLookupByLibrary.simpleMessage("Número da conta"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Registro de Conta"),
        "acton": MessageLookupByLibrary.simpleMessage("Ação"),
        "add": MessageLookupByLibrary.simpleMessage("Adicionar"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Adicionar Marca"),
        "addCategory":
            MessageLookupByLibrary.simpleMessage("Adicionar Categoria"),
        "addContact": MessageLookupByLibrary.simpleMessage("Adicionar Contato"),
        "addCustomer":
            MessageLookupByLibrary.simpleMessage("Adicionar Cliente"),
        "addDelivery":
            MessageLookupByLibrary.simpleMessage("Adicionar Entrega"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Adicionar descrição"),
        "addDescription":
            MessageLookupByLibrary.simpleMessage("Adicionar nota"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Add Discount"),
        "addDocumentId": MessageLookupByLibrary.simpleMessage(
            "Adicionar Documento de Identidade"),
        "addDucument":
            MessageLookupByLibrary.simpleMessage("Adicionar Documento"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Adicionar Despesa"),
        "addExpenseCategory": MessageLookupByLibrary.simpleMessage(
            "Adicionar Categoria de Despesa"),
        "addItems": MessageLookupByLibrary.simpleMessage("Adicionar Itens"),
        "addNew": MessageLookupByLibrary.simpleMessage("Adicionar novo"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Adicionar Novo Endereço"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Adicionar Novo Produto"),
        "addNewTax":
            MessageLookupByLibrary.simpleMessage("Adicionar Novo Imposto"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Adicionar Novo Imposto com tipo de imposto único/múltiplo"),
        "addNote": MessageLookupByLibrary.simpleMessage("Adicionar Nota"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Adicione o produto primeiro"),
        "addPromoCode": MessageLookupByLibrary.simpleMessage("Add Promo Code"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Adicionar Compra"),
        "addSales": MessageLookupByLibrary.simpleMessage("Adicionar Vendas"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Adicionado com sucesso"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Adicionar Unidade"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Adicionar função de usuário"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Added Successfully"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("Adicionado ao Carrinho"),
        "address": MessageLookupByLibrary.simpleMessage("Endereço"),
        "admin": MessageLookupByLibrary.simpleMessage("Admin"),
        "all": MessageLookupByLibrary.simpleMessage("Todos"),
        "allBusinessSolution": MessageLookupByLibrary.simpleMessage(
            "Todas as Soluções Empresariais"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("Already added"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Já Existe"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Já possui uma conta"),
        "amount": MessageLookupByLibrary.simpleMessage("Valor"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "Um e-mail foi enviado\\nVerifique sua caixa de entrada"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Suporte para aplicativos Android e iOS"),
        "applicableTax": MessageLookupByLibrary.simpleMessage("Applicable Tax"),
        "apply": MessageLookupByLibrary.simpleMessage("Aplicar"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Você tem certeza de que deseja deletar esta fatura?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Você tem certeza de que deseja deletar esta venda?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Are you sure to delete this user?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Você tem certeza de que deseja excluir este imposto?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Você tem certeza de que deseja excluir este grupo de impostos?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Você deseja excluir este armazém?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Tem certeza de que deseja excluir este usuário?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Assinatura Autorizada"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Você é responsável por manter a confidencialidade de sua conta e senha e por restringir o acesso à sua conta. Você aceita a responsabilidade por todas as atividades que ocorrem em sua conta."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Você deve ter pelo menos 18 anos de idade ou a idade legal da maioria em sua jurisdição para usar o Sistema."),
        "backSide": MessageLookupByLibrary.simpleMessage("Verso"),
        "backToHome": MessageLookupByLibrary.simpleMessage(
            "Voltar para a Página Inicial"),
        "balance": MessageLookupByLibrary.simpleMessage("Saldo"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladesh"),
        "bank": MessageLookupByLibrary.simpleMessage("Bank"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Moeda da Conta Bancária"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Moeda da conta bancária"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Informações bancárias"),
        "bankName": MessageLookupByLibrary.simpleMessage("Nome do banco"),
        "bankTransfer":
            MessageLookupByLibrary.simpleMessage("Transferência Bancária"),
        "barcodeFound": MessageLookupByLibrary.simpleMessage("Barcode found"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Conta/Fatura"),
        "billTo": MessageLookupByLibrary.simpleMessage("Faturar para"),
        "branchName": MessageLookupByLibrary.simpleMessage("Nome da agência"),
        "brand": MessageLookupByLibrary.simpleMessage("Marca"),
        "brandName": MessageLookupByLibrary.simpleMessage("Nome da Marca"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("Bulk Upload"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Categoria Empresarial"),
        "buy": MessageLookupByLibrary.simpleMessage("Comprar"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Comprar Plano Premium"),
        "buySms": MessageLookupByLibrary.simpleMessage("Comprar SMS"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Ao acessar ou utilizar o Sistema de Pontos de Venda (POS) (o \'Sistema\') fornecido pela [Nome da Sua Empresa] (\'Empresa\'), você concorda em ficar vinculado a estes Termos de Uso. Se você não concordar com estes Termos de Uso, não utilize o Sistema."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Você é responsável por garantir que seu acesso e uso do Sistema estejam em conformidade com todas as leis e regulamentos aplicáveis."),
        "cacel": MessageLookupByLibrary.simpleMessage("Cancelar"),
        "call": MessageLookupByLibrary.simpleMessage("Chamar"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "Ligue para Suporte de Emergência"),
        "camera": MessageLookupByLibrary.simpleMessage("Câmera"),
        "cancel": MessageLookupByLibrary.simpleMessage("Cancel"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Cancel all products"),
        "capacity": MessageLookupByLibrary.simpleMessage("Capacidade"),
        "card": MessageLookupByLibrary.simpleMessage("Card"),
        "cash": MessageLookupByLibrary.simpleMessage("Dinheiro"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Categorias"),
        "category": MessageLookupByLibrary.simpleMessage("Categoria"),
        "categoryName":
            MessageLookupByLibrary.simpleMessage("Nome da categoria"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "O nome da categoria já existe"),
        "cateogryName":
            MessageLookupByLibrary.simpleMessage("Nome da Categoria"),
        "change": MessageLookupByLibrary.simpleMessage("Mudar?"),
        "changePassword": MessageLookupByLibrary.simpleMessage("Alterar Senha"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("Verificar Email"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Escolha um Cliente"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Escolha um Fornecedor"),
        "choseYourFeature": MessageLookupByLibrary.simpleMessage(
            "Escolha as suas funcionalidades"),
        "clarence": MessageLookupByLibrary.simpleMessage("Clarence"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Clique para Conectar"),
        "close": MessageLookupByLibrary.simpleMessage("Fechar"),
        "color": MessageLookupByLibrary.simpleMessage("Cor"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(Combinação de múltiplos impostos)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Em Breve"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Endereço da Empresa"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Nome da Empresa e da Loja"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("Nome da Empresa e Negócio"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Completar Transação"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Confirmar Senha"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Confirmar devolução"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Parabéns"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Entre em Contato"),
        "continu": MessageLookupByLibrary.simpleMessage("Continuar"),
        "country": MessageLookupByLibrary.simpleMessage("País"),
        "create": MessageLookupByLibrary.simpleMessage("Criar"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Criar uma Conta Gratuita"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Criado e Salvo"),
        "currency": MessageLookupByLibrary.simpleMessage("Moeda"),
        "currentStock": MessageLookupByLibrary.simpleMessage("Estoque Atual"),
        "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
            "Marcação personalizada de faturas"),
        "customer": MessageLookupByLibrary.simpleMessage("Cliente"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Detalhes do Cliente"),
        "customerGST": MessageLookupByLibrary.simpleMessage("Customer GST"),
        "customerName": MessageLookupByLibrary.simpleMessage("Nome do Cliente"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Transação Diária"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Visão Geral do Painel"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Data saved successfully"),
        "date": MessageLookupByLibrary.simpleMessage("Data"),
        "day": MessageLookupByLibrary.simpleMessage("Dia"),
        "dealer": MessageLookupByLibrary.simpleMessage("Revendedor"),
        "dealerPrice":
            MessageLookupByLibrary.simpleMessage("Preço do Revendedor"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("Percentual de IVA Padrão"),
        "delete": MessageLookupByLibrary.simpleMessage("Excluir"),
        "deleting": MessageLookupByLibrary.simpleMessage("Deletando"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Endereço de Entrega"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Delivery Addresses"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Taxa de Entrega"),
        "describtion": MessageLookupByLibrary.simpleMessage("Descrição"),
        "description": MessageLookupByLibrary.simpleMessage("Description"),
        "descriptionCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "A descrição não pode estar vazia"),
        "details": MessageLookupByLibrary.simpleMessage("Details"),
        "discount": MessageLookupByLibrary.simpleMessage("Desconto"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Não Perturbar"),
        "done": MessageLookupByLibrary.simpleMessage("Feito"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Download Excel format"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Downloaded successfully in download folder"),
        "due": MessageLookupByLibrary.simpleMessage("Vencimento"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Valor devido: "),
        "dueCollection":
            MessageLookupByLibrary.simpleMessage("Cobrança de Vencimentos"),
        "dueCollectionReports": MessageLookupByLibrary.simpleMessage(
            "Relatórios de Cobrança Pendente"),
        "dueList": MessageLookupByLibrary.simpleMessage("Lista de Vencimentos"),
        "dueReports":
            MessageLookupByLibrary.simpleMessage("Relatório de Dívidas"),
        "duration": MessageLookupByLibrary.simpleMessage("Duração"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Duração: De"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "Terminal POS Móvel Fácil de Usar"),
        "edit": MessageLookupByLibrary.simpleMessage("Editar"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Editar Fatura de Compra"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Editar Fatura de Vendas"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Editar Redes Sociais"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Editado com sucesso"),
        "editTax": MessageLookupByLibrary.simpleMessage("Editar imposto"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Editar grupo de impostos"),
        "editWarehouse": MessageLookupByLibrary.simpleMessage("Editar armazém"),
        "email": MessageLookupByLibrary.simpleMessage("Email"),
        "emailAddress":
            MessageLookupByLibrary.simpleMessage("Endereço de Email"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Email can\'t be empty"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "Email Enviado! Verifique sua Caixa de Entrada"),
        "endDate": MessageLookupByLibrary.simpleMessage("Data de Término"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Enter a valid amount"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Digite um desconto válido"),
        "enterAValidPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Enter a valid phone number"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Digite um preço válido"),
        "enterAValidQuantity": MessageLookupByLibrary.simpleMessage(
            "Digite uma quantidade válida"),
        "enterAddress":
            MessageLookupByLibrary.simpleMessage("Digite o Endereço"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("Digite o Valor."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Digite o Nome da Marca"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Digite a Capacidade"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Digite o Nome da Categoria"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Digite a Cor"),
        "enterCustomerGstNumber":
            MessageLookupByLibrary.simpleMessage("Enter customer GST number"),
        "enterDealerPrice": MessageLookupByLibrary.simpleMessage(
            "Digite o Preço do Revendedor"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Enter Description"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("Digite o Desconto."),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Digite a Data da Despesa"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Digite o Endereço Completo"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Digite o Número da Fatura"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Enter Low Stock Alert Quantity"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Digite o Fabricante"),
        "enterMessageContent": MessageLookupByLibrary.simpleMessage(
            "Insira o Conteúdo da Mensagem"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "Digite o MRP/Preço do Revendedor"),
        "enterName": MessageLookupByLibrary.simpleMessage("Digite o Nome"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Digite a Nota"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Digite o Nome da Parte"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Digite o Número de Telefone"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Digite o Código do Produto ou Escaneie"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Digite o Nome do Produto"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Digite o Preço de Compra."),
        "enterReferenceNumber": MessageLookupByLibrary.simpleMessage(
            "Digite o Número de Referência"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Digite o Tamanho"),
        "enterStocks":
            MessageLookupByLibrary.simpleMessage("Digite os Estoques."),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Digite a taxa de imposto"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("Digite o ID da transação"),
        "enterType": MessageLookupByLibrary.simpleMessage("Digite o Tipo"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("Digite o título do usuário"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Enter valid amount"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Digite o nome do armazém"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Digite o Peso"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Digite o Preço de Atacado"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("Insira a sua descrição aqui"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "Insira Seu Endereço de Email"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "Insira o Título do Seu Feedback"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Enter your GST Number"),
        "enterYourMobileNumber": MessageLookupByLibrary.simpleMessage(
            "Insira o seu número de celular"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Digite Seu Nome"),
        "enterYourNumber": MessageLookupByLibrary.simpleMessage(
            "Digite seu número de telefone"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Digite sua senha"),
        "enterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Digite Seu Número de Telefone"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "Insira o ID da sua transação"),
        "error": MessageLookupByLibrary.simpleMessage("Error"),
        "excTax": MessageLookupByLibrary.simpleMessage("Exc. Tax"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("Excel Uploader"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Exclusive"),
        "expense": MessageLookupByLibrary.simpleMessage("Despesa"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Categoria de Despesa"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Data da Despesa"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Despesa Para"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Relatório de Despesas"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Expire Date"),
        "expired": MessageLookupByLibrary.simpleMessage("Expirado"),
        "expiring": MessageLookupByLibrary.simpleMessage("Expirando"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Falha com erro"),
        "fashion": MessageLookupByLibrary.simpleMessage("Moda"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "As funcionalidades são a parte importante que torna o Pos Saas diferente das soluções tradicionais."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Feedback"),
        "firstName": MessageLookupByLibrary.simpleMessage("Primeiro Nome"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Siga-nos no\\nFacebook"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Siga-nos no\\nTwitter"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Frente"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("Para usos ilimitados"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Esqueceu a senha"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Esqueceu a Senha?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Data de Início"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("Backup de dados gratuito"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "Atualização vitalícia gratuita"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Pacote Gratuito"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Plano Gratuito"),
        "from": MessageLookupByLibrary.simpleMessage("(De"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Total Pago"),
        "gallary": MessageLookupByLibrary.simpleMessage("Galeria"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("Gerando PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Obter OTP"),
        "guest": MessageLookupByLibrary.simpleMessage("Convidado"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Não tem uma conta?"),
        "history": MessageLookupByLibrary.simpleMessage("Histórico"),
        "home": MessageLookupByLibrary.simpleMessage("Início"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Como Protegemos Suas Informações"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Como Usamos Suas Informações"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Verificação de Identidade"),
        "image": MessageLookupByLibrary.simpleMessage("Imagem"),
        "inHouseCantBeDelete": MessageLookupByLibrary.simpleMessage(
            "InHouse não pode ser excluído"),
        "inHouseCantBeEdited": MessageLookupByLibrary.simpleMessage(
            "InHouse não pode ser editado"),
        "inWord": MessageLookupByLibrary.simpleMessage("Por Extenso"),
        "incTax": MessageLookupByLibrary.simpleMessage("Inc. Tax"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Inclusive"),
        "increaseStock":
            MessageLookupByLibrary.simpleMessage("Aumentar estoque"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Instrumento"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Nº de Fatura"),
        "invoice": MessageLookupByLibrary.simpleMessage("Invoice"),
        "invoiceNumber":
            MessageLookupByLibrary.simpleMessage("Número da Fatura"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Configuração da Fatura"),
        "invoiceViewer": MessageLookupByLibrary.simpleMessage("Invoice Viewer"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Item Adicionado"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("Verificação KYC"),
        "language": MessageLookupByLibrary.simpleMessage("Idioma"),
        "lastName": MessageLookupByLibrary.simpleMessage("Sobrenome"),
        "ledger": MessageLookupByLibrary.simpleMessage("Livre"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Compra Vitalícia"),
        "link": MessageLookupByLibrary.simpleMessage("Link"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Suporte por Chat Ao Vivo"),
        "loading": MessageLookupByLibrary.simpleMessage("Loading"),
        "logIn": MessageLookupByLibrary.simpleMessage("Entrar"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Sair"),
        "logOut": MessageLookupByLibrary.simpleMessage("Sair"),
        "login": MessageLookupByLibrary.simpleMessage("Entrar"),
        "logo": MessageLookupByLibrary.simpleMessage("Logotipo"),
        "loss": MessageLookupByLibrary.simpleMessage("Prejuízo"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Prejuízo/Lucro"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Detalhes de Prejuízo/Lucro"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Relatório de Perda/Lucro"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Relatórios de Perda/Lucro"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Low Stock Alert"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Deixe uma impressão duradoura em seus clientes com faturas personalizadas. Nossa Atualização Ilimitada oferece a vantagem única de personalizar suas faturas, adicionando um toque profissional que reforça a identidade de sua marca e fomenta a fidelidade do cliente."),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("Gerencie seu negócio com "),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Manufacture Date"),
        "margin": MessageLookupByLibrary.simpleMessage("Margin"),
        "masterCard": MessageLookupByLibrary.simpleMessage("Cartão Master"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Fabricante"),
        "message": MessageLookupByLibrary.simpleMessage("Mensagem"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Histórico de Mensagens"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "O aplicativo Pos Saas é gratuito e fácil de usar. Na verdade, é um dos melhores sistemas POS do mundo."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "O Pos Saas é uma solução empresarial completa com gestão de estoque, contas, vendas, despesas e lucro/prejuízo."),
        "mobile": MessageLookupByLibrary.simpleMessage("Mobile"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("Mobile Payment"),
        "monthly": MessageLookupByLibrary.simpleMessage("Mensal"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("Mais Informações"),
        "name": MessageLookupByLibrary.simpleMessage("Digite Seu Nome."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Nome já existe"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("O nome não pode estar vazio"),
        "next": MessageLookupByLibrary.simpleMessage("Próximo"),
        "noConnection": MessageLookupByLibrary.simpleMessage("Sem Conexão"),
        "noData": MessageLookupByLibrary.simpleMessage("Sem Dados"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Nenhum dado disponível"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Nenhum dado encontrado"),
        "noHistoryFound": MessageLookupByLibrary.simpleMessage(
            "Nenhum Histórico Encontrado!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Nenhum produto encontrado"),
        "noSubTaxSelected": MessageLookupByLibrary.simpleMessage(
            "Nenhum Sub Imposto Selecionado"),
        "noTransactionFound": MessageLookupByLibrary.simpleMessage(
            "Nenhuma Transação Encontrada!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Nenhum usuário encontrado com esse email."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "Nenhuma função de usuário encontrada"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Usuário Inativo"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Not provided"),
        "note": MessageLookupByLibrary.simpleMessage("Nota"),
        "notes": MessageLookupByLibrary.simpleMessage("Notas"),
        "notification": MessageLookupByLibrary.simpleMessage("Notificação"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP sent to"),
        "office": MessageLookupByLibrary.simpleMessage("Office"),
        "ok": MessageLookupByLibrary.simpleMessage("Ok"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "O POS contém uma ampla gama de funcionalidades, incluindo rastreamento de vendas e gerenciamento de estoque."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Este sistema ajuda você a melhorar suas operações para seus clientes."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Nosso sistema POS deve simplificar automaticamente as operações diárias, facilitando a navegação."),
        "openingBalance": MessageLookupByLibrary.simpleMessage("Saldo Inicial"),
        "order": MessageLookupByLibrary.simpleMessage("Pedidos"),
        "other": MessageLookupByLibrary.simpleMessage("Other"),
        "otp": MessageLookupByLibrary.simpleMessage("Fechar"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Esgotado"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Pacote"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Funcionalidades do Pacote"),
        "paid": MessageLookupByLibrary.simpleMessage("Pago"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Valor Pago"),
        "parties": MessageLookupByLibrary.simpleMessage("Partes"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Lista de Partes"),
        "partyGST": MessageLookupByLibrary.simpleMessage("Party GST"),
        "partyName": MessageLookupByLibrary.simpleMessage("Nome da Parte"),
        "password": MessageLookupByLibrary.simpleMessage("Senha"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "A senha e a confirmação da senha não correspondem"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Password can\'t be empty"),
        "payCash": MessageLookupByLibrary.simpleMessage("Pagar em dinheiro"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash": MessageLookupByLibrary.simpleMessage("Pagar com bkash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Pagar com o Paypal"),
        "payeeName":
            MessageLookupByLibrary.simpleMessage("Nome do Beneficiário"),
        "payeeNumber":
            MessageLookupByLibrary.simpleMessage("Número do Beneficiário"),
        "payment": MessageLookupByLibrary.simpleMessage("Pagamento"),
        "paymentAmount":
            MessageLookupByLibrary.simpleMessage("Valor do Pagamento"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Pagamento Concluído"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Instruções de Pagamento:"),
        "paymentMethod":
            MessageLookupByLibrary.simpleMessage("Método de Pagamento"),
        "paymentType":
            MessageLookupByLibrary.simpleMessage("Tipo de Pagamento"),
        "pdfView": MessageLookupByLibrary.simpleMessage("Visualização em PDF"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Personal Information"),
        "phone": MessageLookupByLibrary.simpleMessage("Telefone"),
        "phoneNumber":
            MessageLookupByLibrary.simpleMessage("Número de Telefone"),
        "phoneNumberAlreadyUsed":
            MessageLookupByLibrary.simpleMessage("Phone Number Already Used"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("Phone number is not valid"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("Phone Number is required"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("Pick and upload file"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("Escolha a Data de Término"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Escolha a Data de Início"),
        "plan": MessageLookupByLibrary.simpleMessage("Plan"),
        "pleaseAddQuantity": MessageLookupByLibrary.simpleMessage(
            "Por favor, adicione a quantidade"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Por favor, verifique sua conectividade com a internet"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Please connect the printer first"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Por favor, conecte a sua impressora Bluetooth"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Please enter a bigger password"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Por favor, digite uma senha de confirmação"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("Por favor, insira uma senha"),
        "pleaseEnterAValidEmail":
            MessageLookupByLibrary.simpleMessage("Please enter a valid email"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Please enter name"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("Por favor, insira a senha"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Por favor, insira seu endereço de email abaixo para receber o link de redefinição de senha."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Por favor, insira o número da transação"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Please select a category first"),
        "pleaseSelectAPlan": MessageLookupByLibrary.simpleMessage(
            "Por favor, selecione um plano"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Please Select Business Category"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Por favor, use o código de compra válido para usar o aplicativo"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Desenvolvido por Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Desenvolvido por"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Suporte ao cliente premium"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Plano Premium"),
        "previousPayAmounts": MessageLookupByLibrary.simpleMessage(
            "Montantes de Pagamentos Anteriores"),
        "price": MessageLookupByLibrary.simpleMessage("preço"),
        "print": MessageLookupByLibrary.simpleMessage("Imprimir"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Opção de Impressão"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Política de privacidade"),
        "product": MessageLookupByLibrary.simpleMessage("Produto"),
        "productCode":
            MessageLookupByLibrary.simpleMessage("Código do Produto"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("Product code is required"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Código/Nome do Produto"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Descrição do Produto"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Product Details"),
        "productList":
            MessageLookupByLibrary.simpleMessage("Lista de Produtos"),
        "productName": MessageLookupByLibrary.simpleMessage("Nome do Produto"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Product name already exists in this warehouse"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Nome do produto já adicionado"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("Product name is required"),
        "products": MessageLookupByLibrary.simpleMessage("Produtos"),
        "profile": MessageLookupByLibrary.simpleMessage("Perfil"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("Editar perfil"),
        "profit": MessageLookupByLibrary.simpleMessage("Lucro"),
        "promo": MessageLookupByLibrary.simpleMessage("promoção"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Código Promocional"),
        "purchase": MessageLookupByLibrary.simpleMessage("Compra"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("Alerta de Compra"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Compra Confirmada"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Detalhes da Compra"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Fatura de Compra"),
        "purchaseList":
            MessageLookupByLibrary.simpleMessage("Lista de Compras"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Comprar Agora"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Comprar Plano Premium"),
        "purchasePrice":
            MessageLookupByLibrary.simpleMessage("Preço de Compra"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("Purchase price is required"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("Relatório de Compras"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Relatórios de Compras"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Relatórios de Compras"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("Devolução de Compra"),
        "purchaseReturnReport": MessageLookupByLibrary.simpleMessage(
            "Relatório de Devolução de Compra"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Transação de Compra"),
        "qty": MessageLookupByLibrary.simpleMessage("Qtde"),
        "quantity": MessageLookupByLibrary.simpleMessage("Quantidade"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Transações Recentes"),
        "recivedThePin": MessageLookupByLibrary.simpleMessage("Recebeu o PIN"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Número de Referência"),
        "register": MessageLookupByLibrary.simpleMessage("Registrar"),
        "registering": MessageLookupByLibrary.simpleMessage("Registrando"),
        "remainingDue":
            MessageLookupByLibrary.simpleMessage("Valor Restante a Pagar"),
        "remove": MessageLookupByLibrary.simpleMessage("Remove"),
        "reports": MessageLookupByLibrary.simpleMessage("Relatórios"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Solicitação foi enviada"),
        "resendCode": MessageLookupByLibrary.simpleMessage("Reenviar Código"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("Reenviar OTP: "),
        "retailer": MessageLookupByLibrary.simpleMessage("Varejista"),
        "retur": MessageLookupByLibrary.simpleMessage("Devolução"),
        "returN": MessageLookupByLibrary.simpleMessage("Devolução"),
        "returnAMount":
            MessageLookupByLibrary.simpleMessage("Valor de Devolução"),
        "returnAmount":
            MessageLookupByLibrary.simpleMessage("Valor de Devolução"),
        "returnQTY":
            MessageLookupByLibrary.simpleMessage("Quantidade de Devolução"),
        "revenue": MessageLookupByLibrary.simpleMessage("Receita"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Proteja seus dados comerciais sem esforço. Nossa Atualização Ilimitada do Pos Saas POS inclui backup de dados gratuito, garantindo que suas informações valiosas estejam protegidas contra eventos imprevistos. Concentre-se no que realmente importa - o crescimento de seu negócio."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Valor da Venda"),
        "saleDetails":
            MessageLookupByLibrary.simpleMessage("Detalhes de Venda"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Preço de Venda"),
        "saleReports":
            MessageLookupByLibrary.simpleMessage("Relatório de Vendas"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Relatórios de Vendas"),
        "saleReturn":
            MessageLookupByLibrary.simpleMessage("Devolução de Venda"),
        "saleReturnReport": MessageLookupByLibrary.simpleMessage(
            "Relatório de Devolução de Venda"),
        "saleSetting":
            MessageLookupByLibrary.simpleMessage("Configuração de Venda"),
        "sales": MessageLookupByLibrary.simpleMessage("Vendas"),
        "salesAndPurchaseReports": MessageLookupByLibrary.simpleMessage(
            "Relatórios de Vendas e Compras"),
        "salesList": MessageLookupByLibrary.simpleMessage("Lista de Vendas"),
        "salesReturn":
            MessageLookupByLibrary.simpleMessage("Devolução de Vendas"),
        "save": MessageLookupByLibrary.simpleMessage("Salvar"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Salvar e Publicar"),
        "saveChanges":
            MessageLookupByLibrary.simpleMessage("Salvar Alterações"),
        "saving": MessageLookupByLibrary.simpleMessage("Salvando"),
        "scanProductQRCode": MessageLookupByLibrary.simpleMessage(
            "Escanear código QR do produto"),
        "search": MessageLookupByLibrary.simpleMessage("Pesquisar"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Pesquisar por código ou nome do produto"),
        "seeAllPromoCode": MessageLookupByLibrary.simpleMessage(
            "Ver todos os códigos promocionais"),
        "select": MessageLookupByLibrary.simpleMessage("Selecionar"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Selecione um produto para devolução"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Select Brand"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Select Category"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Selecionar Contatos"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("Select Product Category"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("Select Shop Category"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Select Tax"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Select Tax Type"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("Select Unit"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Selecione a Variação:"),
        "seller": MessageLookupByLibrary.simpleMessage("Seller"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Vendas por"),
        "send": MessageLookupByLibrary.simpleMessage("Enviar"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("Enviar Email"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Enviar Mensagem"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("Enviar Link de Redefinição"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Enviar SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Enviar SMS?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Send WhatsApp message"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Enviar Seu Email"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage("Enviando Email"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Sending message"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Serviço/Envio"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Configurar Seu Perfil"),
        "setting": MessageLookupByLibrary.simpleMessage("Configuração"),
        "share": MessageLookupByLibrary.simpleMessage("Compartilhar"),
        "shopGST": MessageLookupByLibrary.simpleMessage("Shop GST"),
        "signIn": MessageLookupByLibrary.simpleMessage("Sign In"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("Sign in with email"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Assinatura do Cliente"),
        "size": MessageLookupByLibrary.simpleMessage("Tamanho"),
        "skip": MessageLookupByLibrary.simpleMessage("Saltar"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Marketing Social"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Sorry, you have no permission to access this service"),
        "startDate": MessageLookupByLibrary.simpleMessage("Data de Início"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Iniciar Nova Venda"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage(
            "Comece a digitar para pesquisar"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Permaneça na vanguarda das inovações tecnológicas sem custos adicionais. Nossa Atualização Ilimitada do Pos Saas POS garante que você sempre tenha as ferramentas e recursos mais recentes ao seu alcance, garantindo que seu negócio permaneça na vanguarda."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("Ainda Não Pago"),
        "stock": MessageLookupByLibrary.simpleMessage("Estoque"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Stock is required"),
        "stockList": MessageLookupByLibrary.simpleMessage("Lista de Estoque"),
        "stocks": MessageLookupByLibrary.simpleMessage("Estoques"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Storage permission is required to create Excel file"),
        "subTaxList":
            MessageLookupByLibrary.simpleMessage("Lista de Sub Impostos"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Sub Impostos"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Subtotal"),
        "submit": MessageLookupByLibrary.simpleMessage("Enviar"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "Inscreva-se em nosso\\nYoutube"),
        "subscription": MessageLookupByLibrary.simpleMessage("Assinatura"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Feito com Sucesso"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Desconectado com Sucesso"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Atualizado com sucesso"),
        "supplier": MessageLookupByLibrary.simpleMessage("Fornecedor"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("Nome do Fornecedor"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("Código SWIFT"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Apresente uma carteira de motorista, cartão de identidade nacional ou passaporte"),
        "takeaNidCardToCheckYourInformation": MessageLookupByLibrary.simpleMessage(
            "Apresente um cartão de identidade para verificar as suas informações"),
        "tap": MessageLookupByLibrary.simpleMessage("Toque"),
        "tax": MessageLookupByLibrary.simpleMessage("Imposto"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Grupo de imposto"),
        "taxPercentage":
            MessageLookupByLibrary.simpleMessage("Porcentagem do Imposto"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Taxa de imposto"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Taxas de imposto - Gerenciar suas taxas de imposto"),
        "taxReport":
            MessageLookupByLibrary.simpleMessage("Relatório de impostos"),
        "taxType": MessageLookupByLibrary.simpleMessage("Tax Type"),
        "taxes": MessageLookupByLibrary.simpleMessage("Impostos"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Termos e Condições"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("Termos de uso"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Termos e Privacidade"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Obrigado pelo seu Pagamento Pendente"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Obrigado"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Obrigado pela sua compra"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "A conta já existe para esse e-mail"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "The Excel file has already been downloaded"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "O nome diz tudo. Com o Pos Saas POS Unlimited, não há limite para o seu uso. Esteja você processando algumas transações ou lidando com um grande número de clientes, você pode operar com confiança, sabendo que não está limitado por restrições."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "A senha fornecida é muito fraca"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "A venda será deletada e todos os dados sobre esta compra serão deletados. Você tem certeza de que deseja deletar isto?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "A venda será deletada e todos os dados sobre esta venda serão deletados. Você tem certeza de que deseja deletar isto?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "O usuário será excluído e todos os dados serão removidos da sua conta. Tem certeza de que deseja excluir isso?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "The user will be deleted and all the data will be deleted from your account. Are you sure to delete this?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Serviços de Terceiros"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Esta categoria não pode ser excluída"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Este Mês)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "This product is already added"),
        "title": MessageLookupByLibrary.simpleMessage("Título"),
        "titleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "O título não pode estar vazio"),
        "to": MessageLookupByLibrary.simpleMessage("para"),
        "toDate": MessageLookupByLibrary.simpleMessage("Data Final"),
        "today": MessageLookupByLibrary.simpleMessage("Today"),
        "total": MessageLookupByLibrary.simpleMessage("Total"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Valor Total"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Total Coletado"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Total a Pagar"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("Despesa Total"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Total Loss"),
        "totalPayable": MessageLookupByLibrary.simpleMessage("Total a Pagar"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Preço Total"),
        "totalProducts": MessageLookupByLibrary.simpleMessage("Total Products"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Total Profit"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("Compra Total"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Valor Total da Devolução"),
        "totalReturns":
            MessageLookupByLibrary.simpleMessage("Total de Devoluções"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Venda Total"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Estoque Total"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Valor total"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Total de IVA"),
        "totals": MessageLookupByLibrary.simpleMessage("Total: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Transação"),
        "transactionId":
            MessageLookupByLibrary.simpleMessage("ID da Transação"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Tentar Novamente"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Tipo"),
        "unitName": MessageLookupByLibrary.simpleMessage("Nome da Unidade"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Preço Unitário"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Preço Unitário"),
        "units": MessageLookupByLibrary.simpleMessage("Unidades"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Ilimitado"),
        "unlimitedUsage": MessageLookupByLibrary.simpleMessage("Uso ilimitado"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Desbloqueie todo o potencial do Pos Saas POS com sessões de treinamento personalizadas lideradas por nossa equipe de especialistas. Desde o básico até técnicas avançadas, garantimos que você esteja bem versado em utilizar todos os aspectos do sistema para otimizar seus processos de negócios."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Unpaid"),
        "update": MessageLookupByLibrary.simpleMessage("Atualizar"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Atualizar Contato"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Atualize Agora"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("Atualizar Produto"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Update your plan first, your limit is over"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Atualize Seu Perfil"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Atualize seu perfil para conectar-se com seu médico com uma melhor impressão"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Atualize seu perfil para se conectar ao seu cliente com uma melhor impressão"),
        "updated": MessageLookupByLibrary.simpleMessage("Atualizado"),
        "upload": MessageLookupByLibrary.simpleMessage("Upload"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Enviar documento"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("Upload done"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Enviar arquivo"),
        "usbC": MessageLookupByLibrary.simpleMessage("Usb C"),
        "use": MessageLookupByLibrary.simpleMessage("Usar"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("Usar o Pos Saas"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Uso do sistema"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("User is deleted"),
        "userRole": MessageLookupByLibrary.simpleMessage("Função do usuário"),
        "userRoleDetails": MessageLookupByLibrary.simpleMessage(
            "Detalhes da função de usuário"),
        "userTitle": MessageLookupByLibrary.simpleMessage("Título do usuário"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "O título do usuário não pode estar vazio"),
        "value": MessageLookupByLibrary.simpleMessage("Valor"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("VAT doesn\'t apply"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("Verificando OTP"),
        "verifyPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Verificar Número de Telefone"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Ver Todos"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("Ver Detalhes"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Cliente sem Cadastro"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Warehouse"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Armazém já existe"),
        "warehouseList":
            MessageLookupByLibrary.simpleMessage("Lista de armazéns"),
        "warehouseName":
            MessageLookupByLibrary.simpleMessage("Nome do armazém"),
        "warranty": MessageLookupByLibrary.simpleMessage("Garantia"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Nós Enviamos Um Email com instruções sobre como redefinir a senha para:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Podemos usar serviços de terceiros para apoiar a funcionalidade de nosso aplicativo, como provedores de análises e processadores de pagamento. Esses serviços de terceiros podem coletar informações sobre você quando você utiliza nosso aplicativo. Observe que não somos responsáveis pelas práticas de privacidade desses serviços de terceiros."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Adotamos medidas padrão da indústria para proteger suas informações pessoais, incluindo criptografia e armazenamento seguro. Também limitamos o acesso às suas informações apenas a pessoal autorizado."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Nós entendemos a importância de operações contínuas. É por isso que nosso suporte 24 horas está disponível para ajudá-lo, seja para uma consulta rápida ou uma preocupação abrangente. Conecte-se conosco a qualquer momento, em qualquer lugar, por telefone ou WhatsApp, para vivenciar um atendimento ao cliente incomparável."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Usamos suas informações pessoais para fornecer a você a melhor experiência possível em nosso aplicativo, incluindo a personalização de recomendações de conteúdo, a conexão com especialistas e a melhoria da funcionalidade de nossos aplicativos. Também podemos usar suas informações para comunicar atualizações, promoções ou outras informações relacionadas ao nosso aplicativo."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Nós revisaremos o pagamento e o aprovaremos dentro de 1-2 horas"),
        "weekly": MessageLookupByLibrary.simpleMessage("Weekly"),
        "weight": MessageLookupByLibrary.simpleMessage("Peso"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Novidades"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Atacadista"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Preço de Atacado"),
        "wholesalePrice":
            MessageLookupByLibrary.simpleMessage("Wholesale price"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Wholesaler"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Será adicionado em breve"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Vai Expirar em"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Escreva a sua mensagem aqui"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("Wrong OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Senha incorreta fornecida para esse usuário."),
        "yearly": MessageLookupByLibrary.simpleMessage("Anual"),
        "yesDeleteForever": MessageLookupByLibrary.simpleMessage(
            "Sim, Excluir Permanentemente"),
        "youAreNotAValidUser": MessageLookupByLibrary.simpleMessage(
            "Você não é um usuário válido"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Você está usando"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Você Recebeu Um Email"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Você fez login com sucesso na sua conta. Fique com o Pos Saas ."),
        "youHaveToGivePermission": MessageLookupByLibrary.simpleMessage(
            "Você precisa conceder permissão"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Você precisa FAZER LOGIN novamente na sua conta."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Você precisa verificar a sua identidade antes de comprar"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("A sua mensagem permanece"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("O Seu Pacote"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "O Seu Pacote Expirará em 5 Dias")
      };
}
