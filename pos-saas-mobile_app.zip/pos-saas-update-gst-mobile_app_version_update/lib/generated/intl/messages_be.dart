// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a be locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'be';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Працягнуць"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("Нумар GST"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired": MessageLookupByLibrary.simpleMessage("MRP неабходны"),
        "OK": MessageLookupByLibrary.simpleMessage("Добра"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Тэлефонны нумар"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("Нумар"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT код"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Закуска"),
        "TAX": MessageLookupByLibrary.simpleMessage("ПАДАТКІ"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Загрузка"),
        "UserTitle":
            MessageLookupByLibrary.simpleMessage("Загаловак карыстальніка"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Ваш пакет скончыцца сёння\n\nКалі ласка, купіце зноў"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) Сістэма прадастаўляецца выключна для\nспрыяння здзелкам крэдытавання\nі звязаным дзейнасцям у вашым\nбізнэсе."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) Для выкарыстання сістэмы вам можа быць\nнеабходна стварыць акаўнт. Вы\nзгаджаецеся прадаставіць дакладную, актуальную і\nпоўную інфармацыю падчас\nпрацэсу рэгістрацыі і абнаўляць\nгэтую інфармацыю, каб яна была дакладнай\nі поўнай."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("Пра прыкладанне"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Пра нас"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Прыняцце ўмоў"),
        "accountName": MessageLookupByLibrary.simpleMessage("Назва рахунку"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("Номер рахунку"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Рэгістрацыя акаўнта"),
        "acton": MessageLookupByLibrary.simpleMessage("Дзеянне"),
        "add": MessageLookupByLibrary.simpleMessage("Дадаць"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Дадаць брэнд"),
        "addCategory": MessageLookupByLibrary.simpleMessage("Дадаць катэгорыю"),
        "addContact": MessageLookupByLibrary.simpleMessage("Дадаць Кантакт"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Дадаць Кліента"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("Дадаць Дастаўку"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Дадаць апісанне"),
        "addDescription":
            MessageLookupByLibrary.simpleMessage("Дадаць Заўвагу"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Дадаць скідку"),
        "addDocumentId": MessageLookupByLibrary.simpleMessage(
            "Дадаць ідэнтыфікатар дакумента"),
        "addDucument": MessageLookupByLibrary.simpleMessage("Дадаць дакумент"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Дадаць Выдатак"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Дадаць Катэгорыю Выдаткаў"),
        "addItems": MessageLookupByLibrary.simpleMessage("Дадаць тавары"),
        "addNew": MessageLookupByLibrary.simpleMessage("Дадаць новае"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Дадаць Новы Адрас"),
        "addNewProduct": MessageLookupByLibrary.simpleMessage("Дадаць тавар"),
        "addNewTax":
            MessageLookupByLibrary.simpleMessage("Дадаць новы падатак"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Дадаць новы падатак з адзіночным/мноства тыпамі падатку"),
        "addNote": MessageLookupByLibrary.simpleMessage("Дадаць Заўвагу"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Спачатку дадайце прадукт"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Дадаць прома-код"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Дадаць пакупку"),
        "addSales": MessageLookupByLibrary.simpleMessage("Дадаць продажы"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Успяхова дададзена"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Дадаць адзінку"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Дадаць ролю карыстальніка"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Успяхова дададзена"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("Дададзена ў кошык"),
        "address": MessageLookupByLibrary.simpleMessage("Адрас"),
        "admin": MessageLookupByLibrary.simpleMessage("Адміністратар"),
        "all": MessageLookupByLibrary.simpleMessage("Усё"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("Усе бізнес рашэнні"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("Ужо дададзена"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Ужо існуе"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("У вас ужо ёсць акаўнты"),
        "amount": MessageLookupByLibrary.simpleMessage("Сума"),
        "anEmailHasBeenSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "На ваш электронны адрас было адпраўлена паведамленне\\nПраверце ваш ўбудаваны ящик"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Падтрымка прыкладанняў для Android і iOS"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Прымяняльны падатак"),
        "apply": MessageLookupByLibrary.simpleMessage("Прымяніць"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Вы ўпэўненыя, што хочаце выдаліць гэты рахунак?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Вы ўпэўнены, што хочаце выдаліць гэты продаж?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Вы сапраўды хочаце выдаліць гэтага карыстальніка?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Вы ўпэўнены, што хочаце выдаліць гэты падатак?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Вы ўпэўнены, што хочаце выдаліць гэтую групу падаткаў?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Вы хочаце выдаліць гэты склад?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Вы ўпэўненыя, што хочаце выдаліць гэтага карыстальніка?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Упаўнаважаны подпіс"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Вы адказваеце за\nзахаванне канфідэнцыйнасці вашага\nакаунта і пароля, а таксама за абмежаванне\nдоступу да вашага акаўнта. Вы прымаеце\nадказнасць за ўсе дзеянні, якія\nадбываюцца пад вашым акаўнтам."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Вы павінны быць не маладзей за 18 гадоў або\nзаконнага ўзросту паўнацэннасці ў вашай юрысдыкцыі, каб\nвыкарыстоўваць сістэму."),
        "backSide": MessageLookupByLibrary.simpleMessage("Задняя бок"),
        "backToHome": MessageLookupByLibrary.simpleMessage("Назад на галоўную"),
        "balance": MessageLookupByLibrary.simpleMessage("Баланс"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Бангладэш"),
        "bank": MessageLookupByLibrary.simpleMessage("Банк"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Валюта банкаўскага рахунку"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Валюта банкаўскага рахунку"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Банкаўская інфармацыя"),
        "bankName": MessageLookupByLibrary.simpleMessage("Назва банка"),
        "bankTransfer":
            MessageLookupByLibrary.simpleMessage("Банкаўскі пераклад"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Штрых-код знойдзены"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Рахунак/Инвойс"),
        "billTo": MessageLookupByLibrary.simpleMessage("Рахунак Для"),
        "branchName": MessageLookupByLibrary.simpleMessage("Назва філіяла"),
        "brand": MessageLookupByLibrary.simpleMessage("Брэнд"),
        "brandName": MessageLookupByLibrary.simpleMessage("Назва брэнда"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("Масавая\nЗагрузка"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Бізнес Катэгорыя"),
        "buy": MessageLookupByLibrary.simpleMessage("Купіць"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Купіць преміум план"),
        "buySms": MessageLookupByLibrary.simpleMessage("Купіць SMS"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Доступам або выкарыстаннем сістэмы крэдытавання (POS), прадастаўленай [Назва Вашай Кампаніі] (\"Кампанія\"), вы згаджаецеся з гэтымі ўмовамі выкарыстання. Калі вы не згаджаецеся з гэтымі ўмовамі выкарыстання, не выкарыстоўвайце сістэму."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Вы нясеце адказнасць за забеспячэнне таго, каб ваш\nдоступ і выкарыстанне сістэмы адпавядалі\nусім прымяняемым законам і\nнормам."),
        "cacel": MessageLookupByLibrary.simpleMessage("Скасаваць"),
        "call": MessageLookupByLibrary.simpleMessage("Тэлефанаваць"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "Тэлефон для экстравай падтрымкі"),
        "camera": MessageLookupByLibrary.simpleMessage("Камера"),
        "cancel": MessageLookupByLibrary.simpleMessage("Скасаваць"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Скасаваць усе прадукты"),
        "capacity": MessageLookupByLibrary.simpleMessage("Ёмістасць"),
        "card": MessageLookupByLibrary.simpleMessage("Картка"),
        "cash": MessageLookupByLibrary.simpleMessage("Грошы"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Катэгорыі"),
        "category": MessageLookupByLibrary.simpleMessage("Катэгорыя"),
        "categoryName": MessageLookupByLibrary.simpleMessage("Назва катэгорыі"),
        "categoryNameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Назва катэгорыі ўжо існуе"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("Назва Катэгорыі"),
        "change": MessageLookupByLibrary.simpleMessage("Змяніць?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Змяніць пароль"),
        "checkEmail":
            MessageLookupByLibrary.simpleMessage("Праверце электронную пошту"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Выберыце кліента"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Выберыце пастаўшчыка"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Выберыце вашыя функцыі"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Націсніце, каб падключыцца"),
        "close": MessageLookupByLibrary.simpleMessage("Закрыць"),
        "color": MessageLookupByLibrary.simpleMessage("Колер"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(Камбінізацыя некалькіх падаткаў)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Скоро"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Адрас Кампаніі"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Назва Кампаніі і Крамы"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("Назва кампаніі і бізнесу"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Завяршыць транзакцыю"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Пацвердзіце Пароль"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Пацвердзіць вяртанне"),
        "congratulations":
            MessageLookupByLibrary.simpleMessage("Сардэчна Віншуем"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Кантактуйце з намі"),
        "continu": MessageLookupByLibrary.simpleMessage("Працягваць"),
        "country": MessageLookupByLibrary.simpleMessage("Краіна"),
        "create": MessageLookupByLibrary.simpleMessage("Стварыць"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Стварыць Бясплатны Акаўнт"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Створана і захавана"),
        "currency": MessageLookupByLibrary.simpleMessage("Валюта"),
        "currentStock": MessageLookupByLibrary.simpleMessage("Бягучы запас"),
        "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
            "Кастомізаваная брэндаванне рахункаў"),
        "customer": MessageLookupByLibrary.simpleMessage("Кліент"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Дэталі Кліента"),
        "customerGST": MessageLookupByLibrary.simpleMessage("GST кліента"),
        "customerName": MessageLookupByLibrary.simpleMessage("Імя Кліента"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Агляд панэлі"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Даныя паспяхова захаваны"),
        "date": MessageLookupByLibrary.simpleMessage("Дата"),
        "day": MessageLookupByLibrary.simpleMessage("Дзень"),
        "dealer": MessageLookupByLibrary.simpleMessage("Дылер"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("Цана для дылера"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("Стандартны працэнт ПДВ"),
        "delete": MessageLookupByLibrary.simpleMessage("Выдаліць"),
        "deleting": MessageLookupByLibrary.simpleMessage("Выдаленне"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Адрас Дастаўкі"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Адрасы дастаўкі"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Плата за дастаўку"),
        "describtion": MessageLookupByLibrary.simpleMessage("Апісанне"),
        "description": MessageLookupByLibrary.simpleMessage("Апісанне"),
        "descriptionCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Апісанне не можа быць пустым"),
        "details": MessageLookupByLibrary.simpleMessage("Дэталі"),
        "discount": MessageLookupByLibrary.simpleMessage("Скідка"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Не турбаваць"),
        "done": MessageLookupByLibrary.simpleMessage("Гатова"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Спампаваць фармат Excel"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Успешна загружана ў тэчку загрузак"),
        "due": MessageLookupByLibrary.simpleMessage("Да"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Сума Пазыкі: "),
        "dueCollection": MessageLookupByLibrary.simpleMessage("Збор Пазык"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("Даклады па зборах"),
        "dueList": MessageLookupByLibrary.simpleMessage("Список Пазык"),
        "dueReports":
            MessageLookupByLibrary.simpleMessage("Даклад аб запазычанасці"),
        "duration": MessageLookupByLibrary.simpleMessage("Тэрмін"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Перыяд: З"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "Лёгкі у выкарыстанні мабільны POS"),
        "edit": MessageLookupByLibrary.simpleMessage("Рэдагаваць"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Рэдагаваць рахунак пакупкі"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Рэдагаваць рахунку продажу"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Успешна адрэдагавана"),
        "editTax": MessageLookupByLibrary.simpleMessage("Рэдагаваць падатак"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Рэдагаваць групу падаткаў"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("Рэдагаваць склад"),
        "email": MessageLookupByLibrary.simpleMessage("Электронная пошта"),
        "emailAddress":
            MessageLookupByLibrary.simpleMessage("Адрас электроннай пошты"),
        "emailCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Электронная пошта не можа быць пустой"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "Электронная пошта адпраўлена! Праверце свой паштовы скрыню"),
        "endDate": MessageLookupByLibrary.simpleMessage("Дата заканчэння"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Увядзіце сапраўдную суму"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Увядзіце сапраўдны зніжка"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Увядзіце сапраўдны нумар тэлефона"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Увядзіце сапраўдную цану"),
        "enterAValidQuantity": MessageLookupByLibrary.simpleMessage(
            "Увядзіце сапраўдную колькасць"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("Увядзіце Адрас"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("Увядзіце Суму."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Увядзіце назву брэнда"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Увядзіце ёмістасць"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Увядзіце назву катэгорыі"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Увядзіце колер"),
        "enterCustomerGstNumber":
            MessageLookupByLibrary.simpleMessage("Увядзіце нумар GST кліента"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Увядзіце цану для дылера"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Увядзіце апісанне"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("Увядзіце скідку."),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Увядзіце Дату Выдаткаў"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Увядзіце Поўны Адрас"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Увядзіце нумар рахунку"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Увядзіце колькасць для сігналу нізкага запасу"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Увядзіце вытворцу"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("Увядзіце змест паведамлення"),
        "enterName": MessageLookupByLibrary.simpleMessage("Увядзіце Імя"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Увядзіце Заўвагу"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Увядзіце Назву Бака"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Увядзіце Нумар Тэлефона"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Увядзіце код тавару або скануйце"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Увядзіце назву тавару"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Увядзіце кошт пакупкі."),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("Увядзіце Нумар Спасылкі"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Увядзіце памер"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("Увядзіце запасы."),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Увядзіце ставку падатку"),
        "enterTransactionId": MessageLookupByLibrary.simpleMessage(
            "Увядзіце ідэнтыфікатар транзакцыі"),
        "enterType": MessageLookupByLibrary.simpleMessage("Увядзіце тып"),
        "enterUserTitle": MessageLookupByLibrary.simpleMessage(
            "Увядзіце загаловак карыстальніка"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Увядзіце правільную суму"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Увядзіце назву склада"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Увядзіце вагу"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Увядзіце аптовую цану"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("Увядзіце тут ваш апісанне"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "Увядзіце ваш адрас электроннай пошты"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "Увядзіце загаловак вашай зваротнай сувязі"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Увядзіце свой нумар GST"),
        "enterYourMobileNumber": MessageLookupByLibrary.simpleMessage(
            "Увядзіце свой нумар мабільнага"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Увядзіце Ваша Імя"),
        "enterYourNumber": MessageLookupByLibrary.simpleMessage(
            "Увядзіце свой нумар тэлефона"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Увядзіце ваш пароль"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Увядзіце Ваш Нумар Тэлефона"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "Увядзіце нумар вашай транзакцыі"),
        "error": MessageLookupByLibrary.simpleMessage("Памылка"),
        "excTax": MessageLookupByLibrary.simpleMessage("Выключ. падатак"),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("Загрузчык Excel"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Выключна"),
        "expense": MessageLookupByLibrary.simpleMessage("Выдатак"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Катэгорыя Выдаткаў"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Дата Выдаткаў"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Выдатак Для"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Даклад аб Выдатках"),
        "expireDate": MessageLookupByLibrary.simpleMessage(
            "Дата заканчэння тэрміну дзеяння"),
        "expired": MessageLookupByLibrary.simpleMessage("Скончыўся"),
        "expiring":
            MessageLookupByLibrary.simpleMessage("Тэрмін дзеяння сканчаецца"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Збой з памылкай"),
        "fashion": MessageLookupByLibrary.simpleMessage("Мода"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Функцыі з\'яўляюцца важнай часткай, якая адрознівае Pos SaaS ад традыцыйных рашэнняў."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Зваротная сувязь"),
        "firstName": MessageLookupByLibrary.simpleMessage("Імя"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Сачыце за намі ў\\nFacebook"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Сачыце за намі ў\\nTwitter"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Фронтальная бок"),
        "forUnlimitedUses": MessageLookupByLibrary.simpleMessage(
            "Для неабароненых выкарыстанняў"),
        "forgotPassword": MessageLookupByLibrary.simpleMessage("Забылі пароль"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Забылі пароль?"),
        "formDate": MessageLookupByLibrary.simpleMessage("З Даты"),
        "freeDataBackup": MessageLookupByLibrary.simpleMessage(
            "Бясплатная рэзервовая копія дадзеных"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "Бясплатнае абнаўленне на працягу ўсяго жыцця"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Бясплатны пакет"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Бясплатны план"),
        "from": MessageLookupByLibrary.simpleMessage("(З"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Поўна аплачана"),
        "gallary": MessageLookupByLibrary.simpleMessage("Галерэя"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("Генерацыя PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Атрымаць OTP"),
        "govermentId": MessageLookupByLibrary.simpleMessage("Урадовы дакумент"),
        "guest": MessageLookupByLibrary.simpleMessage("Госць"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Не маеце ўліковага запісу?"),
        "history": MessageLookupByLibrary.simpleMessage("Гісторыя"),
        "home": MessageLookupByLibrary.simpleMessage("Галоўная"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Як мы абараняем вашу інфармацыю"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Як мы выкарыстоўваем вашу інфармацыю"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Праверка асобы"),
        "image": MessageLookupByLibrary.simpleMessage("Выява"),
        "inHouseCantBeDelete": MessageLookupByLibrary.simpleMessage(
            "Унутраны не можа быць выдалены"),
        "inHouseCantBeEdited": MessageLookupByLibrary.simpleMessage(
            "Унутраны не можа быць адрэдагаваны"),
        "inWord": MessageLookupByLibrary.simpleMessage("Словамі"),
        "incTax": MessageLookupByLibrary.simpleMessage("Уключ. падатак"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Уключна"),
        "increaseStock":
            MessageLookupByLibrary.simpleMessage("Павялічыць запас"),
        "invNo": MessageLookupByLibrary.simpleMessage("Нумар рахунку."),
        "invoice": MessageLookupByLibrary.simpleMessage("Рахунак"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("Нумар рахунку"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Налады рахунка"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Прагляд рахункаў"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Тавар дададзены"),
        "kg": MessageLookupByLibrary.simpleMessage("Кг"),
        "kycVerification": MessageLookupByLibrary.simpleMessage("Праверка KYC"),
        "language": MessageLookupByLibrary.simpleMessage("Мова"),
        "lastName": MessageLookupByLibrary.simpleMessage("Прозвішча"),
        "ledger": MessageLookupByLibrary.simpleMessage("Гісторыя"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Пакупка на ўсё жыццё"),
        "link": MessageLookupByLibrary.simpleMessage("Спасылка"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport": MessageLookupByLibrary.simpleMessage(
            "Падтрымка ў рэжыме жывога чата"),
        "loading": MessageLookupByLibrary.simpleMessage("Загрузка"),
        "logIn": MessageLookupByLibrary.simpleMessage("Увайсці"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Выйсці"),
        "logOut": MessageLookupByLibrary.simpleMessage("Выйсці"),
        "login": MessageLookupByLibrary.simpleMessage("Увайсці"),
        "logo": MessageLookupByLibrary.simpleMessage("Лагатып"),
        "loss": MessageLookupByLibrary.simpleMessage("Страта"),
        "lossOrProfit":
            MessageLookupByLibrary.simpleMessage("Страт / Прыбытак"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Дэталі страт/прыбыткаў"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Аналіз страт і прыбыткаў"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Аналіз страт і прыбыткаў"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Сигнал нізкага запасу"),
        "maan": MessageLookupByLibrary.simpleMessage("Ман"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Зрабіце lasting уражанне на вашых кліентаў з дапамогай брэндаваных рахункаў. Наша Unlimited Upgrade прапануе унікальную перавагу кастомізацыі вашых рахункаў, дадаючы прафесійны дотык, які ўмацоўвае вашу брэнд-ідэнтычнасць і спрыяе лаяльнасці кліентаў."),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("Кіруйце сваім бізнесам з"),
        "manufactureDate": MessageLookupByLibrary.simpleMessage("Дата вырабу"),
        "margin": MessageLookupByLibrary.simpleMessage("Маржа"),
        "masterCard": MessageLookupByLibrary.simpleMessage("MasterCard"),
        "message": MessageLookupByLibrary.simpleMessage("Паведамленне"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Гісторыя паведамленняў"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Прыкладанне Pos SaaS бясплатнае і лёгкае ў выкарыстанні. На самай справе, гэта адна з лепшых POS-сістэм у свеце."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos SaaS - гэта поўнае бізнес-рашэнне з запасамі, улікам, продажамі, выдаткамі і стратамі/прыбыткам."),
        "mobile": MessageLookupByLibrary.simpleMessage("Мабільны"),
        "mobilePayment":
            MessageLookupByLibrary.simpleMessage("Мабільны плацёж"),
        "monthly": MessageLookupByLibrary.simpleMessage("Штомесяцна"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("Больш Інфармацыі"),
        "name": MessageLookupByLibrary.simpleMessage("Увядзіце Ваша Імя."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Назва ўжо існуе"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("Назва не можа быць пустой"),
        "next": MessageLookupByLibrary.simpleMessage("Далей"),
        "noConnection": MessageLookupByLibrary.simpleMessage("Няма злучэння"),
        "noData": MessageLookupByLibrary.simpleMessage("Няма даных"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Дадзеныя адсутнічаюць"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Дадзеныя не знойдзены"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("Гісторыя не знойдзена!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Прадукт не знойдзены"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("Не выбраны падатак"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("Транзакцыя не знойдзена!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Карыстальнік не знойдзены для гэтага адрасу электроннай пошты."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "Роля карыстальніка не знойдзена"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Неактыўны карыстальнік"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Не ўказана"),
        "note": MessageLookupByLibrary.simpleMessage("Заўвага"),
        "notes": MessageLookupByLibrary.simpleMessage("Заўвагі"),
        "notification": MessageLookupByLibrary.simpleMessage("Уведамленне"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP адпраўлена на"),
        "office": MessageLookupByLibrary.simpleMessage("Офіс"),
        "ok": MessageLookupByLibrary.simpleMessage("ОК"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS, які ўключае вялікую колькасць функцый, у тым ліку адсочванне продажаў і кіраванне запасамі."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Гэтая сістэма дапамагае вам палепшыць вашы аперацыі для вашых кліентаў."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Наша сістэма POS павінна спрасціць штодзённыя аперацыі аўтаматычна, робячы навігацыю лёгкай."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("Пачатковы Баланс"),
        "order": MessageLookupByLibrary.simpleMessage("Заказы"),
        "other": MessageLookupByLibrary.simpleMessage("Іншае"),
        "otp": MessageLookupByLibrary.simpleMessage("Закрыць"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Няма ў наяўнасці"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Пакет"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Функцыі пакета"),
        "paid": MessageLookupByLibrary.simpleMessage("Аплачана"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Аднашаная Сума"),
        "parties": MessageLookupByLibrary.simpleMessage("Стороны"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Спіс Бакаў"),
        "partyGST": MessageLookupByLibrary.simpleMessage("GST боку"),
        "partyName": MessageLookupByLibrary.simpleMessage("Назва Бака"),
        "password": MessageLookupByLibrary.simpleMessage("Пароль"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Пароль і пацверджанне пароля не супадаюць"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Пароль не можа быць пустым"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("Пароль не супадае"),
        "payCash": MessageLookupByLibrary.simpleMessage("Агульная аплата"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("Арабіце з дапамогай bKash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Аплаціць праз Paypal"),
        "payeeName": MessageLookupByLibrary.simpleMessage("Імя атрымальніка"),
        "payeeNumber":
            MessageLookupByLibrary.simpleMessage("Нумар атрымальніка"),
        "payment": MessageLookupByLibrary.simpleMessage("Аплата"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("Сума Аплаты"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Аплата завершана"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Інструкцыі па плацяжах:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("Спосаб аплаты"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Тып Аплаты"),
        "pdfView": MessageLookupByLibrary.simpleMessage("Прагляд PDF"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Персанальная інфармацыя"),
        "phone": MessageLookupByLibrary.simpleMessage("Тэлефон"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Нумар Тэлефона"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Нумар тэлефона ўжо выкарыстоўваецца"),
        "phoneNumberIsNotValid": MessageLookupByLibrary.simpleMessage(
            "Нумар тэлефона не з\'яўляецца сапраўдным"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("Нумар тэлефона абавязковы"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("Выберыце і загрузіце файл"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("Выберыце дату заканчэння"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Выберыце дату пачатку"),
        "plan": MessageLookupByLibrary.simpleMessage("План"),
        "pleaseAddQuantity": MessageLookupByLibrary.simpleMessage(
            "Калі ласка, дадайце колькасць"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Калі ласка, праверце вашу інтэрнэт-сувязь"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Калі ласка, спачатку падключыце прынтар"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Калі ласка, падключыце ваш Bluetooth-прынтэр"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Калі ласка, увядзіце большы пароль"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Калі ласка, увядзіце пацверджаны пароль"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("Калі ласка, увядзіце пароль"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Калі ласка, увядзіце правільную электронную пошту"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Калі ласка, увядзіце імя"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("Калі ласка, увядзіце пароль"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Калі ласка, увядзіце ваш адрас электроннай пошты ніжэй, каб атрымаць спасылку для скідання пароля."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Калі ласка, увядзіце нумар транзакцыі"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("Калі ласка, увядзіце суму"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Калі ласка, спачатку выберыце катэгорыю"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("Калі ласка, выберыце план"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Калі ласка, выберыце катэгорыю бізнесу"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Калі ласка, выкарыстоўвайце сапраўдны код пакупкі, каб выкарыстоўваць прыкладанне"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Распрацавана Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Размешчана"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Прэміум падтрымка кліентаў"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Преміум план"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Папярэднія сумы плацяжоў"),
        "price": MessageLookupByLibrary.simpleMessage("Цана"),
        "print": MessageLookupByLibrary.simpleMessage("Друк"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Варыянты друку"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Палітыка канфідэнцыяльнасці"),
        "product": MessageLookupByLibrary.simpleMessage("Тавар"),
        "productCode": MessageLookupByLibrary.simpleMessage("Код тавару"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("Код прадукта абавязковы"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Код/Назва прадукту"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Апісанне прадукту"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Дэталі прадукту"),
        "productList": MessageLookupByLibrary.simpleMessage("Спіс тавараў"),
        "productName": MessageLookupByLibrary.simpleMessage("Назва тавару"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Імя прадукта ўжо існуе на гэтым складзе"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Назва прадукту ўжо дададзена"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("Імя прадукта абавязкова"),
        "products": MessageLookupByLibrary.simpleMessage("Тавары"),
        "profile": MessageLookupByLibrary.simpleMessage("Профіль"),
        "profileEdit":
            MessageLookupByLibrary.simpleMessage("Рэдагаванне профілю"),
        "profit": MessageLookupByLibrary.simpleMessage("Прыбытак"),
        "promo": MessageLookupByLibrary.simpleMessage("Прома"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Прома-код"),
        "purchase": MessageLookupByLibrary.simpleMessage("Пакупка"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("Сигнал аб куплі"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Купля пацверджана"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Дэталі пакупкі"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Рахунак пакупкі"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("Спіс пакупак"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Купіць зараз"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Купіць преміум план"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("Кошт пакупкі"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("Кошт пакупкі абавязковы"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("Даклад пакупкі"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Даклад пакупкі"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Даклады па пакупках"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("Поверка пакупкі"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("Аналіз вяртання пакупак"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Пераход на пакупку"),
        "qty": MessageLookupByLibrary.simpleMessage("Колькасць"),
        "quantity": MessageLookupByLibrary.simpleMessage("Колькасць"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Апошнія Транзакцыі"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Нумар Спасылкі"),
        "register": MessageLookupByLibrary.simpleMessage("Зарэгістравацца"),
        "registering": MessageLookupByLibrary.simpleMessage("Рэгістрацыя"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("Астатак Пазыкі"),
        "remove": MessageLookupByLibrary.simpleMessage("Выдаліць"),
        "reports": MessageLookupByLibrary.simpleMessage("Даклады"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Запыт быў адпраўлены"),
        "resendCode":
            MessageLookupByLibrary.simpleMessage("Адправіць код паўторна"),
        "resendOtp":
            MessageLookupByLibrary.simpleMessage("Адправіць OTP паўторна: "),
        "retailer": MessageLookupByLibrary.simpleMessage("Рознічны Гандляр"),
        "returN": MessageLookupByLibrary.simpleMessage("Вяртанне"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("Сума вяртання"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("Колькасць вяртання"),
        "revenue": MessageLookupByLibrary.simpleMessage("Даход"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Абароніце вашыя бізнес-даныя лёгка. Наш Pos Saas POS Unlimited Upgrade ўключае бясплатную рэзервовую копію дадзеных, гарантуючы, што ваша каштоўная інфармацыя абаронена ад любых непрадбачаных падзей. Сконцэнтруйцеся на тым, што сапраўды важна - на развіцці вашага бізнесу."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Сума продажу"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("Дэталі продажу"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Цана продажу"),
        "saleReports": MessageLookupByLibrary.simpleMessage("Даклад продажу"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Даклады па продажах"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("Вяртанне продажу"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Аналіз вяртання продажу"),
        "saleSetting":
            MessageLookupByLibrary.simpleMessage("Настройка продажаў"),
        "sales": MessageLookupByLibrary.simpleMessage("Прадавец"),
        "salesAndPurchaseReports": MessageLookupByLibrary.simpleMessage(
            "Справаздачы па продажах і пакупках"),
        "salesList": MessageLookupByLibrary.simpleMessage("Спіс продажаў"),
        "salesReturn":
            MessageLookupByLibrary.simpleMessage("Вяртанне продажаў"),
        "save": MessageLookupByLibrary.simpleMessage("Захаваць"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Захаваць і апублікаваць"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("Захаваць змены"),
        "saving": MessageLookupByLibrary.simpleMessage("Захаванне"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("Скануйце QR-код прадукту"),
        "search": MessageLookupByLibrary.simpleMessage("Пошук"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Пошук па коду або назве прадукту"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("Паглядзець усе прома-коды"),
        "select": MessageLookupByLibrary.simpleMessage("Выбраць"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Выберыце прадукт для вяртання"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Выберыце брэнд"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Выберыце катэгорыю"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Выберыце кантакты"),
        "selectProductCategory": MessageLookupByLibrary.simpleMessage(
            "Выберыце катэгорыю прадуктаў"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("Выберыце катэгорыю крамы"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Выберыце падатак"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Выберыце тып падатку"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("Выберыце адзінку"),
        "seller": MessageLookupByLibrary.simpleMessage("Прадажнік"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Продаецца"),
        "send": MessageLookupByLibrary.simpleMessage("Адправіць"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("Адправіць Email"),
        "sendMessage":
            MessageLookupByLibrary.simpleMessage("Адправіць паведамленне"),
        "sendResetLink": MessageLookupByLibrary.simpleMessage(
            "Адправіць спасылку для скідання"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Адправіць SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Адправіць SMS?"),
        "sendWhatsappMessage": MessageLookupByLibrary.simpleMessage(
            "Адправіць паведамленне праз WhatsApp"),
        "sendYOurEmail": MessageLookupByLibrary.simpleMessage(
            "Адправіць ваш адрас электроннай пошты"),
        "sendingEmail":
            MessageLookupByLibrary.simpleMessage("Адпраўка электроннай пошты"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Адпраўка паведамлення"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Служба/Дастаўка"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Настройце свой профіль"),
        "setting": MessageLookupByLibrary.simpleMessage("Налады"),
        "share": MessageLookupByLibrary.simpleMessage("Падзяліцца"),
        "shopGST": MessageLookupByLibrary.simpleMessage("GST крамы"),
        "signIn": MessageLookupByLibrary.simpleMessage("Увайсці"),
        "signInWithEmail": MessageLookupByLibrary.simpleMessage(
            "Увайсці з дапамогай электроннай пошты"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Подпіс кліента"),
        "size": MessageLookupByLibrary.simpleMessage("Памер"),
        "skip": MessageLookupByLibrary.simpleMessage("Праігнараваць"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Прабачце, у вас няма дазволу на доступ да гэтай паслугі"),
        "startDate": MessageLookupByLibrary.simpleMessage("Дата пачатку"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Пачаць новую продаж"),
        "startTypingToSearch":
            MessageLookupByLibrary.simpleMessage("Пачніце ўводзіць для пошуку"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Будзьце на пярэднім краі тэхналагічных дасягненняў без любых дадатковых выдаткаў. Наш Pos Saas POS Unlimited Upgrade гарантуе, што вы заўсёды будзеце мець апошнія інструменты і функцыі пад рукой, гарантуючы, што ваш бізнес застаецца сучасным."),
        "stillUnpaid":
            MessageLookupByLibrary.simpleMessage("Па-ранейшаму неплацежнае"),
        "stock": MessageLookupByLibrary.simpleMessage("Запас"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Запасы абавязковыя"),
        "stockList": MessageLookupByLibrary.simpleMessage("Спіс запасаў"),
        "stocks": MessageLookupByLibrary.simpleMessage("Запасы"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Для стварэння файла Excel патрабуецца дазвол на захоўванне"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("Список падаткаў"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Падаткі"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Падсумма"),
        "submit": MessageLookupByLibrary.simpleMessage("Адправіць"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "Падпішыцеся на наш\\nYoutube"),
        "subscription": MessageLookupByLibrary.simpleMessage("Падпіска"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Успешна завершана"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Успешны выхад"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Успешна абноўлена"),
        "supplier": MessageLookupByLibrary.simpleMessage("Пастаўшчык"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("Назва пастаўшчыка"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT код"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Зрабіце фота пасведчання кіроўцы, нацыянальнага ідэнтыфікацыйнага картачкі або пашпарта"),
        "takeaNidCardToCheckYourInformation": MessageLookupByLibrary.simpleMessage(
            "Зрабіце фота ідэнтыфікацыйнай карты для праверкі вашай інфармацыі"),
        "tap": MessageLookupByLibrary.simpleMessage("Націсніце"),
        "tax": MessageLookupByLibrary.simpleMessage("Падатак"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Група падаткаў"),
        "taxPercentage":
            MessageLookupByLibrary.simpleMessage("Адсотак падатку"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Ставка падатку"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Ставкі падаткаў - кіруйце сваімі стаўкамі падаткаў"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Даклад па падатках"),
        "taxType": MessageLookupByLibrary.simpleMessage("Тып падатку"),
        "taxes": MessageLookupByLibrary.simpleMessage("Падаткі"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Умовы і палажэнні"),
        "termsOfUse":
            MessageLookupByLibrary.simpleMessage("Умовы выкарыстання"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Умовы і канфідэнцыяльнасць"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Дзякуй за вашу аплату пазыкі"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Дзякуй"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Дзякуй за вашу пакупку"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "Уліковы запіс ужо існуе для гэтага адрасу электроннай пошты"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage("Файл Excel ужо загружаны"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Назва кажа сама за сябе. З Pos Saas POS Unlimited няма абмежаванняў на вашае выкарыстанне. Незалежна ад таго, ці вы апрацоўваеце некалькі здзелак ці сутыкаецеся з наплывам кліентаў, вы можаце працаваць з упэўненасцю, ведаючы, што вы не абмежаваныя."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "Падзелены пароль занадта слабы"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Прадажа будзе выдалена, і ўсе дадзеныя аб гэтай пакупцы будуць выдалены. Вы ўпэўненыя, што хочаце гэта зрабіць?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Прадажа будзе выдалена, і ўсе дадзеныя аб гэтым продажы будуць выдалены. Вы ўпэўненыя, што хочаце гэта зрабіць?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Карыстальнік будзе выдалены, і ўсе дадзеныя будуць выдалены з вашага акаўнта. Вы ўпэўненыя, што хочаце гэта зрабіць?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Карыстальнік будзе выдалены, і ўсе даныя будуць выдалены з вашага акаўнта. Вы сапраўды хочаце гэта зрабіць?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Сэрвісы трэціх бакоў"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Гэту катэгорыю нельга выдаліць"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(У гэтым месяцы)"),
        "thisProductAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("Гэты прадукт ужо дададзены"),
        "title": MessageLookupByLibrary.simpleMessage("Назва"),
        "titleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Загаловак не можа быць пустым"),
        "to": MessageLookupByLibrary.simpleMessage("да"),
        "toDate": MessageLookupByLibrary.simpleMessage("Да Даты"),
        "today": MessageLookupByLibrary.simpleMessage("Сёння"),
        "total": MessageLookupByLibrary.simpleMessage("Агульны"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Агульная Сума"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Агульная сума сабрана"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Агульная Пазыка"),
        "totalExpense":
            MessageLookupByLibrary.simpleMessage("Агульныя Выдаткі"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Агульныя страты"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("Агульная сума да аплаты"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Агульная сума"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("Усяго прадуктаў"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Агульны прыбытак"),
        "totalPurchase":
            MessageLookupByLibrary.simpleMessage("Агульная пакупка"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Агульная сума вяртання"),
        "totalReturns": MessageLookupByLibrary.simpleMessage(
            "Агульная колькасць вяртанняў"),
        "totalSale":
            MessageLookupByLibrary.simpleMessage("Агульны аб\'ём продажаў"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Усяго запасаў"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Агульная вартасць"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Агульны ПДВ"),
        "totals": MessageLookupByLibrary.simpleMessage("Усяго: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Транзакцыя"),
        "transactionId":
            MessageLookupByLibrary.simpleMessage("Нумар транзакцыі"),
        "tryAgain":
            MessageLookupByLibrary.simpleMessage("Паспрабуйце яшчэ раз"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Тып"),
        "unitName": MessageLookupByLibrary.simpleMessage("Назва адзінкі"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Цана за адзінку"),
        "units": MessageLookupByLibrary.simpleMessage("Адзінкі"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Безлімітны"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Бясмежнае выкарыстанне"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Атрымаеце поўны патэнцыял Pos Saas POS з персаналізаванымі навучальнымі сесіямі пад кіраўніцтвам нашай экспертнай каманды. Ад асноваў да прасунутых тэхнік мы забяспечым, каб вы былі добра знаёмыя з выкарыстаннем кожнага аспекту сістэмы для аптымізацыі вашых бізнес-працэсаў."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Неплацеж"),
        "update": MessageLookupByLibrary.simpleMessage("Абнавіць"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Абнавіць Кантакт"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Абнавіць зараз"),
        "updateProduct": MessageLookupByLibrary.simpleMessage("Абнавіць тавар"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Абнавіце свой план, ваш ліміт скончыўся"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Абнавіць ваш профіль"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Абнавіце свой профіль, каб звязацца з вашым лекарам з лепшым уражаннем"),
        "updated": MessageLookupByLibrary.simpleMessage("Абноўлена"),
        "upload": MessageLookupByLibrary.simpleMessage("Загрузіць"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Загрузіць дакумент"),
        "uploadDone":
            MessageLookupByLibrary.simpleMessage("Загрузка завершана"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Загрузіць файл"),
        "upplier": MessageLookupByLibrary.simpleMessage("Пастаўшчык"),
        "usbC": MessageLookupByLibrary.simpleMessage("Usb C"),
        "use": MessageLookupByLibrary.simpleMessage("Выкарыстоўвайце"),
        "useMobiPos":
            MessageLookupByLibrary.simpleMessage("Выкарыстоўвайце Pos SaaS"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Выкарыстанне сістэмы"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Карыстальнік выдалены"),
        "userRole": MessageLookupByLibrary.simpleMessage("Роля карыстальніка"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("Дэталі ролі карыстальніка"),
        "userTitle":
            MessageLookupByLibrary.simpleMessage("Загаловак карыстальніка"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Загаловак карыстальніка не можа быць пустым"),
        "value": MessageLookupByLibrary.simpleMessage("Вартасць"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("ПДВ не прымяняецца"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("Правяраем OTP"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Праверце нумар тэлефона"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Праглядзець Усё"),
        "viewDetails":
            MessageLookupByLibrary.simpleMessage("Паглядзець дэталі"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Кліент без запісу"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Склад"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Склад ужо існуе"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("Спіс складаў"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("Назва склада"),
        "warranty": MessageLookupByLibrary.simpleMessage("Гарантыя"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Мы адправілі электронны ліст з інструкцыямі па скіданні пароля на:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Мы можам выкарыстоўваць сэрвісы трэціх бакоў для падтрымкі функцыянальнасці нашай праграмы, такія як пастаўшчыкі аналітыкі і аплатныя працэсары. Гэтыя сэрвісы трэціх бакоў могуць збіраць інфармацыю пра вас, калі вы карыстаецеся нашай праграмай. Звярніце ўвагу, што мы не нясем адказнасці за палітыку прыватнасці гэтых сэрвісаў трэціх бакоў."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Мы прымяняем стандартныя меры для абароны вашай асабістай інфармацыі, уключаючы шыфраванне і бяспечнае захоўванне. Мы таксама абмяжуем доступ да вашай інфармацыі толькі аўтарызаваным асобам."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            " Мы разумеем важнасць бесперашкодных аперацый. Таму наша падтрымка даступна кругласутачна, каб дапамагчы вам, незалежна ад таго, ці гэта хуткае пытанне або комплексная праблема. Звяжыцеся з намі ў любы час, у любым месцы па тэлефоне або WhatsApp, каб адчуць беспрэцэдэнтны сэрвіс кліентаў."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Мы выкарыстоўваем вашу асабістую інфармацыю, каб забяспечыць вам лепшы вопыт выкарыстання нашай праграмы, уключаючы персаналізацыю вашых рэкамендацый па зместу, сувязь з экспертамі і паляпшэнне функцыянальнасці нашай праграмы. Мы таксама можам выкарыстоўваць вашу інфармацыю для зносін з вамі наконт абнаўленняў, акцый або іншай інфармацыі, звязанай з нашай праграмай."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Мы праверым плацеж і зацвердзім яго на працягу 1-2 гадзін"),
        "weekly": MessageLookupByLibrary.simpleMessage("Штотыдня"),
        "weight": MessageLookupByLibrary.simpleMessage("Вага"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Што Новага"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Аптовік"),
        "wholeSalePrice": MessageLookupByLibrary.simpleMessage("Аптовая цана"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("Оптовая цана"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Аптовік"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Скоро будзе дададзена"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Скончыцца ў"),
        "writeYourMessageHere": MessageLookupByLibrary.simpleMessage(
            "Напішыце ваша паведамленне тут"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("Неправільны OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Няправільны пароль для гэтага карыстальніка."),
        "yearly": MessageLookupByLibrary.simpleMessage("Гадовы"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Так, Выдаліць Назаўжды"),
        "youAreNotAValidUser": MessageLookupByLibrary.simpleMessage(
            "Вы не з\'яўляецеся сапраўдным карыстальнікам"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Вы карыстаецеся"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Вы не можаце заплаціць больш, чым запазычанасць"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Вы атрымалі электронны ліст"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Вы паспяхова ўвайшлі ў свой акаўнт. Заставайцеся з Pos SaaS."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("Вы павінны даць дазвол"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Вам трэба пераўвайсці ў свой акаўнт."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Вы павінны правесці праверку асобы перад пакупкай SMS"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Вашы паведамленні застаюцца"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Ваш пакет"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Ваш пакет скончыцца праз 5 дзён")
      };
}
