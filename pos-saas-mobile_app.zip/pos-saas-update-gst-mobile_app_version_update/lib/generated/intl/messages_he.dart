// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a he locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'he';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("המשך"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("מספר מע\"מ"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("מחיר קמעונאי"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("דרוש מחיר מומלץ"),
        "OK": MessageLookupByLibrary.simpleMessage("אוקיי"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("פייפאל"),
        "PhNo": MessageLookupByLibrary.simpleMessage("מספר טלפון"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("מספר סידורי"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("קוד SWIFT"),
        "Snacks": MessageLookupByLibrary.simpleMessage("נשנושים"),
        "TAX": MessageLookupByLibrary.simpleMessage("מס"),
        "Uploading": MessageLookupByLibrary.simpleMessage("מעלה"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("כותרת המשתמש"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "החבילה שלך תפוג היום\n\nנא לרכוש שוב"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(א) המערכת מסופקת רק למטרת הקל facilitation של העסקאות בנקודות המכירה ובפעילויות קשורות בעסק שלך."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(א) כדי להשתמש במערכת, עשויים לדרוש לך ליצור חשבון. אתה מסכים לספק מידע מדוייק, עדכני ושלם במהלך תהליך ההרשמה ולעדכן מידע זה כלפי על מעמדו כדי לשמור על דיוקו ושלמותו."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("אודות האפליקציה"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("אודותינו"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("הסכמה לתנאים"),
        "accountName": MessageLookupByLibrary.simpleMessage("שם החשבון"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("מספר החשבון"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("הרשמת חשבון"),
        "acton": MessageLookupByLibrary.simpleMessage("פעולה"),
        "add": MessageLookupByLibrary.simpleMessage("הוסף"),
        "addBrand": MessageLookupByLibrary.simpleMessage("הוסף מותג"),
        "addCategory": MessageLookupByLibrary.simpleMessage("הוסף קטגוריה"),
        "addContact": MessageLookupByLibrary.simpleMessage("הוסף איש קשר"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("הוסף לקוח"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("הוסף משלוח"),
        "addDescriptioN": MessageLookupByLibrary.simpleMessage("הוסף תיאור"),
        "addDescription": MessageLookupByLibrary.simpleMessage("הוסף הערה"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("הוסף הנחה"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("הוסף מספר תעודה"),
        "addExpense": MessageLookupByLibrary.simpleMessage("הוסף הוצאה"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("הוסף קטגוריית הוצאה"),
        "addItems": MessageLookupByLibrary.simpleMessage("הוסף פריטים"),
        "addNew": MessageLookupByLibrary.simpleMessage("הוסף חדש"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("הוסף כתובת חדשה"),
        "addNewProduct": MessageLookupByLibrary.simpleMessage("הוסף מוצר חדש"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("הוסף מס חדש"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "הוסף מס חדש עם סוג מס יחיד/מרובה"),
        "addNote": MessageLookupByLibrary.simpleMessage("הוסף הערה"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("הוסף מוצר תחילה"),
        "addPromoCode": MessageLookupByLibrary.simpleMessage("הוסף קוד קידום"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("הוסף רכישה"),
        "addSales": MessageLookupByLibrary.simpleMessage("הוסף מכירה"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("הוספה בוצעה בהצלחה"),
        "addUnit": MessageLookupByLibrary.simpleMessage("הוסף יחידה"),
        "addUserRole": MessageLookupByLibrary.simpleMessage("הוסף תפקיד משתמש"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("נוסף בהצלחה"),
        "addedToCart": MessageLookupByLibrary.simpleMessage("נוסף לעגלה"),
        "address": MessageLookupByLibrary.simpleMessage("כתובת"),
        "admin": MessageLookupByLibrary.simpleMessage("מנהל"),
        "all": MessageLookupByLibrary.simpleMessage("הכל"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("כל הפתרונות לעסקים"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("כבר נוסף"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("כבר קיים"),
        "amount": MessageLookupByLibrary.simpleMessage("סכום"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "אימייל נשלח. בדוק את תיבת הדואר שלך"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "תמיכה באפליקציות ל-Android ו- iOS"),
        "applicableTax": MessageLookupByLibrary.simpleMessage("מס חל"),
        "apply": MessageLookupByLibrary.simpleMessage("החל"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "האם אתה בטוח שברצונך למחוק את החשבונית הזו?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "האם אתה בטוח שברצונך למחוק את המכירה הזו?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "האם אתה בטוח שברצונך למחוק את המשתמש הזה?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "האם אתה בטוח שברצונך למחוק את המס הזה"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "האם אתה בטוח שברצונך למחוק את קבוצת המס הזו"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "האם ברצונך למחוק את המחסן הזה"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "האם אתה בטוח שברצונך למחוק משתמש זה?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("חתימה מוסמכת"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(ב) אתה אחראי על שמירה על סודיות החשבון והסיסמה שלך ועל הגבלת גישה לחשבונך. אתה מתימך באחריות לפעילויות שקורות בחשבונך."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(ב) אתה חייב להיות בגיל של 18 שנים לפחות או בגיל המיעוט החוקי במשפך שלך כדי להשתמש במערכת."),
        "backSide": MessageLookupByLibrary.simpleMessage("צד אחורי"),
        "backToHome": MessageLookupByLibrary.simpleMessage("חזור לדף הבית"),
        "balance": MessageLookupByLibrary.simpleMessage("יתרה"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("בנגלדש"),
        "bank": MessageLookupByLibrary.simpleMessage("בנק"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("מטבע חשבון בנק"),
        "bankInformation": MessageLookupByLibrary.simpleMessage("מידע בנקאי"),
        "bankName": MessageLookupByLibrary.simpleMessage("שם הבנק"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("העברה בנקאית"),
        "barcodeFound": MessageLookupByLibrary.simpleMessage("ברקוד נמצא"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("חשבונית/קבלה"),
        "billTo": MessageLookupByLibrary.simpleMessage("לחשבון של"),
        "branchName": MessageLookupByLibrary.simpleMessage("שם הסניף"),
        "brand": MessageLookupByLibrary.simpleMessage("מותג"),
        "brandName": MessageLookupByLibrary.simpleMessage("שם המותג"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("העלאה בכמויות"),
        "businessCategory": MessageLookupByLibrary.simpleMessage("קטגורית עסק"),
        "buy": MessageLookupByLibrary.simpleMessage("רכוש"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("קנה תוכנית מעלות"),
        "buySms": MessageLookupByLibrary.simpleMessage("קנה הודעות SMS"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "בכניסה או בשימוש במערכת נקודת המכירה (POS) (ה\"מערכת\") שנספקת על ידי [שם החברה שלך] (\"החברה\"), אתה מסכים להיות מחויב לתנאי השימוש אלו. אם אינך מסכים לתנאי השימוש הללו, אל תשתמש במערכת."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(ג) אתה אחראי להבטיח שהגישתך ושימושך במערכת עומד בכל החוקים והתקנים הרלוונטיים."),
        "call": MessageLookupByLibrary.simpleMessage("טלפון"),
        "callForEmergencySupport":
            MessageLookupByLibrary.simpleMessage("התקשר לתמיכה חירום"),
        "camera": MessageLookupByLibrary.simpleMessage("מצלמה"),
        "cancel": MessageLookupByLibrary.simpleMessage("ביטול"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("ביטול כל המוצרים"),
        "capacity": MessageLookupByLibrary.simpleMessage("נפח"),
        "card": MessageLookupByLibrary.simpleMessage("כרטיס"),
        "cash": MessageLookupByLibrary.simpleMessage("מזומן"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("קטגוריות"),
        "category": MessageLookupByLibrary.simpleMessage("קטגוריה"),
        "categoryName": MessageLookupByLibrary.simpleMessage("שם קטגוריה"),
        "categoryNameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("שם הקטגוריה כבר קיים"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("שם הקטגוריה"),
        "change": MessageLookupByLibrary.simpleMessage("לשנות?"),
        "changePassword": MessageLookupByLibrary.simpleMessage("שנה סיסמה"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("בדוק דוא\"ל"),
        "choseACustomer": MessageLookupByLibrary.simpleMessage("בחר לקוח"),
        "choseASupplier": MessageLookupByLibrary.simpleMessage("בחר ספק"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("בחר את התכונות שלך"),
        "clarence": MessageLookupByLibrary.simpleMessage("קלרנס"),
        "clickToConnect": MessageLookupByLibrary.simpleMessage("לחץ להתחברות"),
        "close": MessageLookupByLibrary.simpleMessage("סגור"),
        "color": MessageLookupByLibrary.simpleMessage("צבע"),
        "combinationOfMultipleTaxes":
            MessageLookupByLibrary.simpleMessage("(שילוב של מספר מסים)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("בקרוב"),
        "companyAddress": MessageLookupByLibrary.simpleMessage("כתובת החברה"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("שם חברה וחנות"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("שם החברה/עסק"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("השלם עסקה"),
        "confirmPassword": MessageLookupByLibrary.simpleMessage("אשר סיסמה"),
        "confirmReturn": MessageLookupByLibrary.simpleMessage("אשר החזרה"),
        "congratulations": MessageLookupByLibrary.simpleMessage("מזל טוב"),
        "contactUs": MessageLookupByLibrary.simpleMessage("צור קשר"),
        "continu": MessageLookupByLibrary.simpleMessage("המשך"),
        "country": MessageLookupByLibrary.simpleMessage("מדינה"),
        "create": MessageLookupByLibrary.simpleMessage("צור"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("צור חשבון חינם"),
        "createdAndSaved": MessageLookupByLibrary.simpleMessage("נוצר ונשמר"),
        "currency": MessageLookupByLibrary.simpleMessage("מטבע"),
        "currentStock": MessageLookupByLibrary.simpleMessage("מלאי נוכחי"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("התאמה אישית של חשבוניות"),
        "customer": MessageLookupByLibrary.simpleMessage("לקוח"),
        "customerDetails": MessageLookupByLibrary.simpleMessage("פרטי לקוח"),
        "customerGST": MessageLookupByLibrary.simpleMessage("מע\"מ לקוח"),
        "customerName": MessageLookupByLibrary.simpleMessage("שם הלקוח"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("סקירת לוח המחוונים"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("הנתונים נשמרו בהצלחה"),
        "date": MessageLookupByLibrary.simpleMessage("תאריך"),
        "day": MessageLookupByLibrary.simpleMessage("יום"),
        "dealer": MessageLookupByLibrary.simpleMessage("סוחר"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("מחיר סוחר"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("אחוז מע\"מ ברירת מחדל"),
        "delete": MessageLookupByLibrary.simpleMessage("מחק"),
        "deleting": MessageLookupByLibrary.simpleMessage("מוחק"),
        "deliveryAddress": MessageLookupByLibrary.simpleMessage("כתובת משלוח"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("כתובות משלוח"),
        "deliveryCharge": MessageLookupByLibrary.simpleMessage("דמי משלוח"),
        "description": MessageLookupByLibrary.simpleMessage("תיאור"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("התיאור לא יכול להיות ריק"),
        "details": MessageLookupByLibrary.simpleMessage("פרטים"),
        "discount": MessageLookupByLibrary.simpleMessage("הנחה"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("אל תפריע"),
        "done": MessageLookupByLibrary.simpleMessage("בוצע"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("הורד פורמט Excel"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage("הורד בהצלחה בתיקיית ההורדות"),
        "due": MessageLookupByLibrary.simpleMessage("חוב"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("סכום החוב:"),
        "dueCollection": MessageLookupByLibrary.simpleMessage("אספקת חובות"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("דוחות איסוף בהקדם"),
        "dueList": MessageLookupByLibrary.simpleMessage("רשימת חובות"),
        "dueReports": MessageLookupByLibrary.simpleMessage("דוח חובות"),
        "duration": MessageLookupByLibrary.simpleMessage("משך"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("משך: מ-"),
        "easyToUseMobilePos":
            MessageLookupByLibrary.simpleMessage("POS נייד קל לשימוש"),
        "edit": MessageLookupByLibrary.simpleMessage("עריכה"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("ערוך חשבונית רכישה"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("ערוך חשבונית מכירה"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("ערוך מדיה חברתית"),
        "editSuccessfully": MessageLookupByLibrary.simpleMessage("נערך בהצלחה"),
        "editTax": MessageLookupByLibrary.simpleMessage("ערוך מס"),
        "editTaxGroup": MessageLookupByLibrary.simpleMessage("ערוך קבוצת מס"),
        "editWarehouse": MessageLookupByLibrary.simpleMessage("ערוך מחסן"),
        "email": MessageLookupByLibrary.simpleMessage("דוא\"ל"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("כתובת דוא\"ל"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("הדוא\"ל לא יכול להיות ריק"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "האימייל נשלח! בדוק את תיבת הדואר שלך"),
        "endDate": MessageLookupByLibrary.simpleMessage("תאריך סיום"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("הכנס סכום תקף"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("הזן הנחה תקינה"),
        "enterAValidPhoneNumber":
            MessageLookupByLibrary.simpleMessage("אנא הכנס מספר טלפון תקף"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("הזן מחיר תקין"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("הזן כמות תקינה"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("הזן כתובת"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("הזן סכום"),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("הזן את שם המותג"),
        "enterCapacity": MessageLookupByLibrary.simpleMessage("הזן נפח"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("הזן את שם הקטגוריה"),
        "enterColor": MessageLookupByLibrary.simpleMessage("הזן צבע"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "הכנס את מספר המע\"מ של הלקוח"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("הזן מחיר סוחר"),
        "enterDescription": MessageLookupByLibrary.simpleMessage("הכנס תיאור"),
        "enterDiscount": MessageLookupByLibrary.simpleMessage("הזן הנחה"),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("הזן תאריך הוצאה"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("הזן כתובת מלאה"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("הזן מספר חשבונית"),
        "enterLowStockAlertQuantity":
            MessageLookupByLibrary.simpleMessage("הכנס כמות התראת מלאי נמוך"),
        "enterManufacturer": MessageLookupByLibrary.simpleMessage("הזן יצרן"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("הזן תוכן הודעה"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "הזן מחיר קמעונאי / מחיר קמעונאי לקמעונאי"),
        "enterName": MessageLookupByLibrary.simpleMessage("הזן שם"),
        "enterNote": MessageLookupByLibrary.simpleMessage("הזן הערה"),
        "enterPartyName": MessageLookupByLibrary.simpleMessage("הזן את שם הצד"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("הזן מספר טלפון"),
        "enterProductCodeOrScan":
            MessageLookupByLibrary.simpleMessage("הזן קוד מוצר או סרוק"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("הזן את שם המוצר"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("הזן מחיר רכישה"),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("הזן מספר פניה"),
        "enterSize": MessageLookupByLibrary.simpleMessage("הזן גודל"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("הזן את המלאי"),
        "enterTaxRate": MessageLookupByLibrary.simpleMessage("הזן שיעור מס"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("הזן מזהה עסקה"),
        "enterType": MessageLookupByLibrary.simpleMessage("הזן סוג"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("הזן כותרת משתמש"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("הכנס סכום תקף"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("הזן שם מחסן"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("הזן משקל"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("הזן מחיר סיטונאי"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("הזן את התיאור שלך כאן"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("הזן את כתובת הדוא\"ל שלך"),
        "enterYourFeedBackTitle":
            MessageLookupByLibrary.simpleMessage("הזן את כותרת המשוב שלך"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("אנא הכנס את מספר המע\"מ שלך"),
        "enterYourMobileNumber": MessageLookupByLibrary.simpleMessage(
            "הזן את מספר הטלפון הנייד שלך"),
        "enterYourName": MessageLookupByLibrary.simpleMessage("הזן את שמך"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("הזן את מספר הטלפון שלך"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("הזן את הסיסמה שלך"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("הזן את מספר הטלפון שלך"),
        "enterYourTransactionId":
            MessageLookupByLibrary.simpleMessage("הזן את מזהה העסקה שלך"),
        "error": MessageLookupByLibrary.simpleMessage("שגיאה"),
        "excTax": MessageLookupByLibrary.simpleMessage("לא כולל מס"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("מעלה Excel"),
        "exclusive": MessageLookupByLibrary.simpleMessage("בלתי כולל"),
        "expense": MessageLookupByLibrary.simpleMessage("הוצאה"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("קטגוריית הוצאה"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("תאריך הוצאה"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("הוצאה עבור"),
        "expenseReport": MessageLookupByLibrary.simpleMessage("דוח הוצאות"),
        "expireDate": MessageLookupByLibrary.simpleMessage("תאריך תפוגה"),
        "expired": MessageLookupByLibrary.simpleMessage("פג תוקף"),
        "expiring": MessageLookupByLibrary.simpleMessage("פג תוקף"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("נכשל עם שגיאה"),
        "fashion": MessageLookupByLibrary.simpleMessage("אופנה"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "תכונות הן החלק החשוב שהופך את Pos Saas לשונה מהפתרונות המסורתיים."),
        "feedBack": MessageLookupByLibrary.simpleMessage("משוב"),
        "firstName": MessageLookupByLibrary.simpleMessage("שם פרטי"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("עקוב אחרינו ב-\\nFacebook"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("עקוב אחרינו ב-\\nTwitter"),
        "fontSide": MessageLookupByLibrary.simpleMessage("צד קדמי"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("לשימושים בלתי מוגבלים"),
        "forgotPassword": MessageLookupByLibrary.simpleMessage("שכחת סיסמה"),
        "forgotPasswords": MessageLookupByLibrary.simpleMessage("שכחת סיסמה?"),
        "formDate": MessageLookupByLibrary.simpleMessage("מתאריך"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("גיבוי נתונים בחינם"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("חבילה חינמית"),
        "freePlan": MessageLookupByLibrary.simpleMessage("תוכנית חינמית"),
        "from": MessageLookupByLibrary.simpleMessage("מ-"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("שולם במלואו"),
        "gallary": MessageLookupByLibrary.simpleMessage("גלריה"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("יוצר PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("קבל OTP"),
        "guest": MessageLookupByLibrary.simpleMessage("אורח"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("אין לך חשבון?"),
        "history": MessageLookupByLibrary.simpleMessage("היסטוריה"),
        "home": MessageLookupByLibrary.simpleMessage("בית"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "איך אנחנו מגנים על המידע שלך"),
        "howWeUseYourInformation":
            MessageLookupByLibrary.simpleMessage("איך אנחנו משתמשים במידע שלך"),
        "identityVerify": MessageLookupByLibrary.simpleMessage("אימות זהות"),
        "image": MessageLookupByLibrary.simpleMessage("תמונה"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("לא ניתן למחוק את InHouse"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("לא ניתן לערוך את InHouse"),
        "inWord": MessageLookupByLibrary.simpleMessage("במילים"),
        "incTax": MessageLookupByLibrary.simpleMessage("כולל מס"),
        "inclusive": MessageLookupByLibrary.simpleMessage("כולל"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("הגדל מלאי"),
        "invNo": MessageLookupByLibrary.simpleMessage("מס\' חשבונית"),
        "invoice": MessageLookupByLibrary.simpleMessage("חשבונית"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("מספר חשבונית"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("הגדרות חשבונית"),
        "invoiceViewer": MessageLookupByLibrary.simpleMessage("צופה חשבונית"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("הפריט נוסף"),
        "kg": MessageLookupByLibrary.simpleMessage("ק\"ג"),
        "kycVerification": MessageLookupByLibrary.simpleMessage("אימות KYC"),
        "language": MessageLookupByLibrary.simpleMessage("שפה"),
        "lastName": MessageLookupByLibrary.simpleMessage("שם משפחה"),
        "ledger": MessageLookupByLibrary.simpleMessage("רשומות"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("רכישה לטווח הארוך"),
        "link": MessageLookupByLibrary.simpleMessage("קישור"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("לינקדאין"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("תמיכה בצ\'אט חי"),
        "loading": MessageLookupByLibrary.simpleMessage("טוען"),
        "logIn": MessageLookupByLibrary.simpleMessage("התחברות"),
        "logOut": MessageLookupByLibrary.simpleMessage("התנתק"),
        "login": MessageLookupByLibrary.simpleMessage("התחברות"),
        "logo": MessageLookupByLibrary.simpleMessage("לוגו"),
        "loss": MessageLookupByLibrary.simpleMessage("הפסד"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("הפסד / רווח"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("פרטי הפסד / רווח"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("דו\"ח רווח/הפסד"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("דו\"חות רווח/הפסד"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("התראת מלאי נמוך"),
        "maan": MessageLookupByLibrary.simpleMessage("מע\"ן"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "השאר הדפסה אחרונה על הלקוחות שלך עם חשבוניות ממותגות. שדרג את הגרסה הבלתי מוגבלת שלנו שמאפשרת לך להתאים אישית את החשבוניות שלך, הוסף מגע מקצועי שמחזק את זהות המותג שלך ומעודד אמיתים נאמנות של הלקוחות."),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("נהל את העסק שלך באמצעות"),
        "manufactureDate": MessageLookupByLibrary.simpleMessage("תאריך ייצור"),
        "margin": MessageLookupByLibrary.simpleMessage("רווח"),
        "masterCard": MessageLookupByLibrary.simpleMessage("כרטיס אשראי"),
        "message": MessageLookupByLibrary.simpleMessage("הודעה"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("היסטורית הודעות"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "אפליקציית Pos Saas היא חינמית וקלה לשימוש. למעשה, זו אחת ממערכות ה-POS הטובות ביותר בעולם."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas היא פתרון עסקי מושלם עם מלאי, חשבונות, מכירות, הוצאות והפסד/רווח."),
        "mobile": MessageLookupByLibrary.simpleMessage("נייד"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("תשלום נייד"),
        "monthly": MessageLookupByLibrary.simpleMessage("חודשי"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("מידע נוסף"),
        "name": MessageLookupByLibrary.simpleMessage("הזן את שמך"),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("השם כבר קיים"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("שם לא יכול להיות ריק"),
        "next": MessageLookupByLibrary.simpleMessage("הבא"),
        "noConnection": MessageLookupByLibrary.simpleMessage("אין חיבור"),
        "noData": MessageLookupByLibrary.simpleMessage("אין נתונים"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("אין נתונים זמינים"),
        "noDataFound": MessageLookupByLibrary.simpleMessage("לא נמצאו נתונים"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("לא נמצאה היסטוריה!"),
        "noProductFound": MessageLookupByLibrary.simpleMessage("לא נמצא מוצר"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("לא נבחר תת מס"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("לא נמצאה עסקה!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "לא נמצא משתמש עבור כתובת הדוא\"ל הזו."),
        "noUserRoleFound":
            MessageLookupByLibrary.simpleMessage("לא נמצא תפקיד משתמש"),
        "notActiveUser": MessageLookupByLibrary.simpleMessage("משתמש לא פעיל"),
        "notProvided": MessageLookupByLibrary.simpleMessage("לא סופק"),
        "note": MessageLookupByLibrary.simpleMessage("הערה"),
        "notes": MessageLookupByLibrary.simpleMessage("הערות"),
        "notification": MessageLookupByLibrary.simpleMessage("הודעה"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("ה-OTP נשלח ל"),
        "office": MessageLookupByLibrary.simpleMessage("משרד"),
        "ok": MessageLookupByLibrary.simpleMessage("אישור"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "מערכת POS המכילה המון פונקציונליות, כולל מעקב אחר מכירות וניהול מלאי."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "מערכת זו מסייעת לך לשפר את הפעולות שלך למענה ללקוחות שלך."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "מערכת הPOS שלנו צריכה לפשט אוטומטית את הפעולות היומיות, ולהפוך אותן לקלות לניווט."),
        "openingBalance": MessageLookupByLibrary.simpleMessage("יתרת התחלה"),
        "order": MessageLookupByLibrary.simpleMessage("הזמנות"),
        "other": MessageLookupByLibrary.simpleMessage("אחר"),
        "otp": MessageLookupByLibrary.simpleMessage("סגור"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("חסר במלאי"),
        "pacakge": MessageLookupByLibrary.simpleMessage("חבילה"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("תכונות החבילה"),
        "paid": MessageLookupByLibrary.simpleMessage("שולם"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("סכום ששולם"),
        "parties": MessageLookupByLibrary.simpleMessage("צדדים"),
        "partiesList": MessageLookupByLibrary.simpleMessage("רשימת צדדים"),
        "partyGST": MessageLookupByLibrary.simpleMessage("מע\"מ צד שלישי"),
        "partyName": MessageLookupByLibrary.simpleMessage("שם הצד"),
        "password": MessageLookupByLibrary.simpleMessage("סיסמה"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "הסיסמה ואישור הסיסמה אינם תואמים"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("הסיסמה לא יכולה להיות ריקה"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("הסיסמה לא תואמת"),
        "payCash": MessageLookupByLibrary.simpleMessage("שלם במזומן"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("שלם באמצעות Bkash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("שלם באמצעות Paypal"),
        "payeeName": MessageLookupByLibrary.simpleMessage("שם המקבל תשלום"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("מספר המקבל תשלום"),
        "payment": MessageLookupByLibrary.simpleMessage("תשלום"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("סכום התשלום"),
        "paymentComplete": MessageLookupByLibrary.simpleMessage("התשלום הושלם"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("הוראות תשלום:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("שיטת תשלום"),
        "paymentType": MessageLookupByLibrary.simpleMessage("סוג תשלום"),
        "pdfView": MessageLookupByLibrary.simpleMessage("תצוגת PDF"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("מידע אישי"),
        "phone": MessageLookupByLibrary.simpleMessage("טלפון"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("מספר טלפון"),
        "phoneNumberAlreadyUsed":
            MessageLookupByLibrary.simpleMessage("מספר הטלפון כבר בשימוש"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("מספר הטלפון אינו תקף"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("מספר טלפון נדרש"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("בחר והעלה קובץ"),
        "pickEndDate": MessageLookupByLibrary.simpleMessage("בחר תאריך סיום"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("בחר תאריך התחלה"),
        "plan": MessageLookupByLibrary.simpleMessage("תוכנית"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("נא להוסיף כמות"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "אנא בדוק את חיבור האינטרנט שלך"),
        "pleaseConnectThePrinterFirst":
            MessageLookupByLibrary.simpleMessage("אנא חבר את המדפסת קודם"),
        "pleaseEnterABiggerPassword":
            MessageLookupByLibrary.simpleMessage("אנא הכנס סיסמה ארוכה יותר"),
        "pleaseEnterAConfirmPassword":
            MessageLookupByLibrary.simpleMessage("אנא הזן אישור סיסמה"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("אנא הזן סיסמה"),
        "pleaseEnterAValidEmail":
            MessageLookupByLibrary.simpleMessage("אנא הכנס דוא\"ל תקף"),
        "pleaseEnterName": MessageLookupByLibrary.simpleMessage("אנא הכנס שם"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("אנא הזן סיסמה"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "אנא הזן את כתובת הדוא\"ל שלך למעלה כדי לקבל קישור לאיפוס הסיסמה."),
        "pleaseEnterTransactionNumber":
            MessageLookupByLibrary.simpleMessage("נא להזין מספר עסקה"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("אנא הכנס סכום"),
        "pleaseSelectACategoryFirst":
            MessageLookupByLibrary.simpleMessage("אנא בחר קטגוריה קודם"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("נא לבחור תוכנית"),
        "pleaseSelectBusinessCategory":
            MessageLookupByLibrary.simpleMessage("אנא בחר קטגוריית עסקים"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "נא להשתמש בקוד רכישה תקף כדי להשתמש באפליקציה"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("מופעל על ידי Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("מופעל על ידי"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("תמיכת לקוחות משוכללת"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("תוכנית מעלות"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("סכומי תשלום קודמים"),
        "price": MessageLookupByLibrary.simpleMessage("מחיר"),
        "print": MessageLookupByLibrary.simpleMessage("הדפסה"),
        "printingOption": MessageLookupByLibrary.simpleMessage("אפשרות הדפסה"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("מדיניות הפרטיות"),
        "product": MessageLookupByLibrary.simpleMessage("מוצר"),
        "productCode": MessageLookupByLibrary.simpleMessage("קוד המוצר"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("דרוש קוד מוצר"),
        "productCodeName": MessageLookupByLibrary.simpleMessage("קוד מוצר/שם"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("תיאור מוצר"),
        "productDetails": MessageLookupByLibrary.simpleMessage("פרטי מוצר"),
        "productList": MessageLookupByLibrary.simpleMessage("רשימת מוצרים"),
        "productName": MessageLookupByLibrary.simpleMessage("שם המוצר"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage("שם המוצר כבר קיים במחסן הזה"),
        "productNameIsAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("שם המוצר כבר נוסף"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("דרוש שם מוצר"),
        "products": MessageLookupByLibrary.simpleMessage("מוצרים"),
        "profile": MessageLookupByLibrary.simpleMessage("פרופיל"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("עריכת פרופיל"),
        "profit": MessageLookupByLibrary.simpleMessage("רווח"),
        "promo": MessageLookupByLibrary.simpleMessage("מבצע"),
        "promoCode": MessageLookupByLibrary.simpleMessage("קוד מבצע"),
        "purchase": MessageLookupByLibrary.simpleMessage("רכישה"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage("התראת רכישה"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("רכישה אושרה"),
        "purchaseDetails": MessageLookupByLibrary.simpleMessage("פרטי רכישה"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("חשבונית רכישה"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("רשימת רכישות"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("רכוש עכשיו"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("רכוש תוכנית מעלות"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("מחיר רכישה"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("דרוש מחיר רכישה"),
        "purchaseRepoet": MessageLookupByLibrary.simpleMessage("דוח רכישות"),
        "purchaseReports": MessageLookupByLibrary.simpleMessage("דוחות רכישה"),
        "purchaseReportss": MessageLookupByLibrary.simpleMessage("דוחות רכישה"),
        "purchaseReturn": MessageLookupByLibrary.simpleMessage("החזרת רכישה"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("דו\"ח החזרת רכישה"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("מעבר רכישה"),
        "qty": MessageLookupByLibrary.simpleMessage("כמות"),
        "quantity": MessageLookupByLibrary.simpleMessage("כמות"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("עסקאות אחרונות"),
        "referenceNumber": MessageLookupByLibrary.simpleMessage("מספר הפניה"),
        "register": MessageLookupByLibrary.simpleMessage("הרשמה"),
        "registering": MessageLookupByLibrary.simpleMessage("רישום"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("חוב נותר"),
        "remove": MessageLookupByLibrary.simpleMessage("הסר"),
        "reports": MessageLookupByLibrary.simpleMessage("דוחות"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("הבקשה נשלחה"),
        "resendCode": MessageLookupByLibrary.simpleMessage("שלח מחדש קוד"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("שלח מחדש OTP: "),
        "retailer": MessageLookupByLibrary.simpleMessage("קמעונאי"),
        "returN": MessageLookupByLibrary.simpleMessage("החזר"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("סכום החזרה"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("כמות החזרה"),
        "revenue": MessageLookupByLibrary.simpleMessage("רווח"),
        "saleAmount": MessageLookupByLibrary.simpleMessage("סכום מכירה"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("פרטי מכירה"),
        "salePrice": MessageLookupByLibrary.simpleMessage("מחיר מכירה"),
        "saleReports": MessageLookupByLibrary.simpleMessage("דוחות מכירות"),
        "saleReportss": MessageLookupByLibrary.simpleMessage("דוחות מכירה"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("החזרת מכירה"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("דו\"ח החזרת מכירות"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("הגדרת מכירה"),
        "sales": MessageLookupByLibrary.simpleMessage("מכירות"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("דוחות מכירות ורכישות"),
        "salesList": MessageLookupByLibrary.simpleMessage("רשימת מכירות"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("החזרת מכירות"),
        "save": MessageLookupByLibrary.simpleMessage("שמור"),
        "saveAndPublish": MessageLookupByLibrary.simpleMessage("שמור ופרסם"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("שמור שינויים"),
        "saving": MessageLookupByLibrary.simpleMessage("שומר"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("סרוק קוד QR של המוצר"),
        "search": MessageLookupByLibrary.simpleMessage("חיפוש"),
        "searchByProductCodeOrName":
            MessageLookupByLibrary.simpleMessage("חפש לפי קוד מוצר או שם"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("ראה את כל קודי המבצע"),
        "select": MessageLookupByLibrary.simpleMessage("בחר"),
        "selectAProductForReturn":
            MessageLookupByLibrary.simpleMessage("בחר מוצר להחזרה"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("בחר מותג"),
        "selectCategory": MessageLookupByLibrary.simpleMessage("בחר קטגוריה"),
        "selectContacts": MessageLookupByLibrary.simpleMessage("בחר אנשי קשר"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("בחר קטגוריית מוצר"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("בחר קטגוריית חנות"),
        "selectTax": MessageLookupByLibrary.simpleMessage("בחר מס"),
        "selectTaxType": MessageLookupByLibrary.simpleMessage("בחר סוג מס"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("בחר יחידה"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("בחר וריאציה: "),
        "seller": MessageLookupByLibrary.simpleMessage("מוכר"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("נמכר על ידי"),
        "send": MessageLookupByLibrary.simpleMessage("שלח"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("שלח אימייל"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("שלח הודעה"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("שלח קישור לאיפוס"),
        "sendSms": MessageLookupByLibrary.simpleMessage("שלח SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("שלח הודעת SMS?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("שלח הודעת וואטסאפ"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage("שולח אימייל"),
        "sendingMessage": MessageLookupByLibrary.simpleMessage("שולח הודעה"),
        "serviceShipping": MessageLookupByLibrary.simpleMessage("שירות/משלוח"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("הגדר את הפרופיל שלך"),
        "setting": MessageLookupByLibrary.simpleMessage("הגדרות"),
        "share": MessageLookupByLibrary.simpleMessage("שיתוף"),
        "shopGST": MessageLookupByLibrary.simpleMessage("מע\"מ חנות"),
        "signIn": MessageLookupByLibrary.simpleMessage("התחברות"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("התחבר עם דוא\"ל"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("חתימת לקוח"),
        "size": MessageLookupByLibrary.simpleMessage("גודל"),
        "skip": MessageLookupByLibrary.simpleMessage("דלג"),
        "sms": MessageLookupByLibrary.simpleMessage("הודעות SMS"),
        "socailMarketing": MessageLookupByLibrary.simpleMessage("שיווק חברתי"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "סליחה, אין לך הרשאה לגשת לשירות הזה"),
        "startDate": MessageLookupByLibrary.simpleMessage("תאריך התחלה"),
        "startNewSale": MessageLookupByLibrary.simpleMessage("התחל מכירה חדשה"),
        "startTypingToSearch":
            MessageLookupByLibrary.simpleMessage("התחל להקליד לחיפוש"),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("עדיין לא שולם"),
        "stock": MessageLookupByLibrary.simpleMessage("מלאי"),
        "stockIsRequired": MessageLookupByLibrary.simpleMessage("דרוש מלאי"),
        "stockList": MessageLookupByLibrary.simpleMessage("רשימת מלאי"),
        "stocks": MessageLookupByLibrary.simpleMessage("מלאי"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "דרושה הרשאת אחסון ליצירת קובץ Excel"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("רשימת תת מסים"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("תת מיסים"),
        "subTotal": MessageLookupByLibrary.simpleMessage("סיכום חלקי"),
        "submit": MessageLookupByLibrary.simpleMessage("שלח"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "הירשם לערוץ שלנו ב-\\nYouTube"),
        "subscription": MessageLookupByLibrary.simpleMessage("מנוי"),
        "successfullyDone": MessageLookupByLibrary.simpleMessage("בוצע בהצלחה"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("התנתקת בהצלחה"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("עודכן בהצלחה"),
        "supplier": MessageLookupByLibrary.simpleMessage("ספק"),
        "supplierName": MessageLookupByLibrary.simpleMessage("שם ספק"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("קוד SWIFT"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "צלם תמונה של רשיון נהיגה, תעודת זהות לאומית או דרכון"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "קח כרטיס זהות כדי לבדוק את המידע שלך"),
        "tap": MessageLookupByLibrary.simpleMessage("Tap"),
        "tax": MessageLookupByLibrary.simpleMessage("מס"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("קבוצת מס"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("אחוז מס"),
        "taxRate": MessageLookupByLibrary.simpleMessage("שיעור מס"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "שיעורי מס - ניהול שיעורי המס שלך"),
        "taxReport": MessageLookupByLibrary.simpleMessage("דו\"ח מס"),
        "taxType": MessageLookupByLibrary.simpleMessage("סוג מס"),
        "taxes": MessageLookupByLibrary.simpleMessage("מיסים"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("תנאים והגבלות"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("תנאי השימוש"),
        "termsPrivacy": MessageLookupByLibrary.simpleMessage("תנאים ופרטיות"),
        "thankYOuForYourDuePayment":
            MessageLookupByLibrary.simpleMessage("תודה על התשלום שלך"),
        "thankYou": MessageLookupByLibrary.simpleMessage("תודה"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("תודה על הרכישה שלך"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "החשבון כבר קיים עבור האימייל הזה"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage("קובץ Excel כבר הורד"),
        "thePasswordProvidedIsTooWeak":
            MessageLookupByLibrary.simpleMessage("הסיסמה שסופקה חלשה מדי"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "המכירה תימחק וכל הנתונים הקשורים לרכישה זו יימחקו. האם אתה בטוח שברצונך למחוק זאת?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "המכירה תימחק וכל הנתונים הקשורים למכירה זו יימחקו. האם אתה בטוח שברצונך למחוק זאת?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "המשתמש יימחק וכל הנתונים יימחקו מהחשבון שלך. האם אתה בטוח שברצונך למחוק זאת?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "המשתמש יימחק וכל הנתונים יימחקו מהחשבון שלך. האם אתה בטוח שברצונך למחוק את זה?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("שירותי צד שלישי"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "לא ניתן למחוק את הקטגוריה הזו"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(חודש זה)"),
        "thisProductAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("המוצר הזה כבר נוסף"),
        "title": MessageLookupByLibrary.simpleMessage("כותרת"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("הכותרת לא יכולה להיות ריקה"),
        "to": MessageLookupByLibrary.simpleMessage("עד"),
        "toDate": MessageLookupByLibrary.simpleMessage("עד תאריך"),
        "today": MessageLookupByLibrary.simpleMessage("היום"),
        "total": MessageLookupByLibrary.simpleMessage("סה\"כ"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("סכום כולל"),
        "totalCollected": MessageLookupByLibrary.simpleMessage("סך כל הנגבה"),
        "totalDue": MessageLookupByLibrary.simpleMessage("סה\"כ חוב"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("סה\"כ הוצאות"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("סה\"כ הפסד"),
        "totalPayable": MessageLookupByLibrary.simpleMessage("סה\"כ לתשלום"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("מחיר כולל"),
        "totalProducts": MessageLookupByLibrary.simpleMessage("סה\"כ מוצרים"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("סה\"כ רווח"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("סך כל הרכישות"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("סכום החזרה כולל"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("סך כל ההחזרות"),
        "totalSale": MessageLookupByLibrary.simpleMessage("סה\"כ מכירות"),
        "totalStock": MessageLookupByLibrary.simpleMessage("סה\"כ מלאי"),
        "totalValue": MessageLookupByLibrary.simpleMessage("ערך כולל"),
        "totalVat": MessageLookupByLibrary.simpleMessage("סה\"כ מע\"מ"),
        "totals": MessageLookupByLibrary.simpleMessage("סה\"כ:"),
        "transaction": MessageLookupByLibrary.simpleMessage("עסקה"),
        "transactionId": MessageLookupByLibrary.simpleMessage("מזהה עסקה"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("נסה שוב"),
        "twitter": MessageLookupByLibrary.simpleMessage("טוויטר"),
        "type": MessageLookupByLibrary.simpleMessage("סוג"),
        "unitName": MessageLookupByLibrary.simpleMessage("שם היחידה"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("מחיר ליחידה"),
        "units": MessageLookupByLibrary.simpleMessage("יחידות"),
        "unlimited": MessageLookupByLibrary.simpleMessage("ללא הגבלה"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("שימוש בלתי מוגבל"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "פתח את הפוטנציאל המלא של Pos Saas POS עם ישיבות אימון אישיות מובילות של צוות המומחים שלנו. מיסודות המערכת ועד טכניקות מתקדמות, אנו מבטיחים שתהיה מומחה בשימוש בכל פרט של המערכת למיטוב התהליכים בעסק שלך."),
        "unpaid": MessageLookupByLibrary.simpleMessage("לא שולם"),
        "update": MessageLookupByLibrary.simpleMessage("עדכן"),
        "updateContact": MessageLookupByLibrary.simpleMessage("עדכן איש קשר"),
        "updateNow": MessageLookupByLibrary.simpleMessage("עדכן עכשיו"),
        "updateProduct": MessageLookupByLibrary.simpleMessage("עדכן מוצר"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "עדכן את התוכנית שלך קודם,\\nהמגבלה שלך עברה"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("עדכן את הפרופיל שלך"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "עדכן את הפרופיל שלך כדי להתחבר לרופא שלך עם הרופא טוב יותר"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "עדכן את הפרופיל שלך כדי להתחבר ללקוחות שלך עם השפעה טובה יותר"),
        "updated": MessageLookupByLibrary.simpleMessage("עודכן"),
        "upload": MessageLookupByLibrary.simpleMessage("העלה"),
        "uploadDocument": MessageLookupByLibrary.simpleMessage("העלה מסמך"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("ההעלאה הושלמה"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("העלה קובץ"),
        "usbC": MessageLookupByLibrary.simpleMessage("Usb C"),
        "use": MessageLookupByLibrary.simpleMessage("השתמש"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("השתמש ב-Pos Saas"),
        "useOfTheSystem": MessageLookupByLibrary.simpleMessage("שימוש במערכת"),
        "userIsDeleted": MessageLookupByLibrary.simpleMessage("המשתמש נמחק"),
        "userRole": MessageLookupByLibrary.simpleMessage("תפקיד המשתמש"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("פרטי תפקיד משתמש"),
        "userTitle": MessageLookupByLibrary.simpleMessage("כותרת המשתמש"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "כותרת המשתמש לא יכולה להיות ריקה"),
        "value": MessageLookupByLibrary.simpleMessage("ערך"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("מס ערך מוסף לא חל"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("אימות OTP"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("אמת מספר טלפון"),
        "viewAll": MessageLookupByLibrary.simpleMessage("הצג הכל"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("צפה בפרטים"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("לקוח חד משתמשי"),
        "warehouse": MessageLookupByLibrary.simpleMessage("מחסן"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("המחסן כבר קיים"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("רשימת מחסנים"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("שם מחסן"),
        "warranty": MessageLookupByLibrary.simpleMessage("אחריות"),
        "weHaveSendAnEmailwithInstructions":
            MessageLookupByLibrary.simpleMessage(
                "שלחנו הודעת דוא\"ל עם הוראות לאיפוס הסיסמה אל:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "אנחנו עשויים להשתמש בשירותי צד שלישי כדי לתמוך בפונקציונליות של האפליקציה שלנו, כמו ספקי נתונים ומעבדי תשלומים. שירותים אלו עשויים לאסוף מידע עליך בעת השימוש באפליקציה שלנו. יש לשים לב שאנחנו אינו אחראיים לפרקטיקות הפרטיות של שירותי הצד השלישי הללו."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "אנחנו מבצעים אמצעים סטנדרטיים בתעשייה כדי להגן על מידע האישי שלך, כולל הצפנה ואחסון בטוח. אנחנו גם מגבילים את הגישה למידע שלך רק לאנשי מוקד מורשים."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "אנחנו משתמשים במידע האישי שלך כדי לספק לך את החוויה הטובה ביותר באפליקציה שלנו, כולל התאמת ההמלצות לתוכן שלך, התחברות למומחים ושיפור פונקציונליות האפליקציה שלנו. אנו יכולים גם להשתמש במידע שלך ליצירת קשר איתך לגבי עדכונים, מבצעים או מידע אחר הנמצא בקשר לאפליקציה שלנו."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "נא לעיין בתשלום ולאשר אותו תוך 1-2 שעות"),
        "weekly": MessageLookupByLibrary.simpleMessage("שבועי"),
        "weight": MessageLookupByLibrary.simpleMessage("משקל"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("מה חדש"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("סיטונאי"),
        "wholeSalePrice": MessageLookupByLibrary.simpleMessage("מחיר סיטונאי"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("מחיר סיטונאי"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("סיטונאי"),
        "willBeAddedSoon": MessageLookupByLibrary.simpleMessage("יתווסף בקרוב"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("פג תוקף ב-"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("כתוב את ההודעה שלך כאן"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("OTP שגוי"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "סיסמה שגויה סופקה עבור משתמש זה."),
        "yearly": MessageLookupByLibrary.simpleMessage("שנתי"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("כן, מחק לצמיתות"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("אתה לא משתמש תקף"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("אתה משתמש ב-"),
        "youCanNotPayMoreThenDue":
            MessageLookupByLibrary.simpleMessage("לא ניתן לשלם יותר מהחוב"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("יש לך הודעת דוא\"ל"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "התחברת בהצלחה לחשבונך. נשאר עם Pos Saas ."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("עליך לתת הרשאה"),
        "youHaveToReLogin":
            MessageLookupByLibrary.simpleMessage("עליך להתחבר מחדש לחשבונך."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "עליך לאמת את הזהות שלך לפני שתרכוש באמצעות SMS"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("ההודעה שלך נשארת"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("החבילה שלך"),
        "yourPackageWillExpireinDay":
            MessageLookupByLibrary.simpleMessage("החבילה שלך תפוג בעוד 5 ימים")
      };
}
