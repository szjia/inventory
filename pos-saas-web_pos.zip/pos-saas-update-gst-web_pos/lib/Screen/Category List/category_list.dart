// ignore_for_file: unused_result, use_build_context_synchronously

import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:salespro_admin/Provider/product_provider.dart';
import 'package:salespro_admin/generated/l10n.dart' as lang;
import 'package:salespro_admin/model/category_model.dart';

import '../../const.dart';
import '../Widgets/Constant Data/constant.dart';
import '../Widgets/Constant Data/export_button.dart';
import '../Widgets/Footer/footer.dart';
import '../Widgets/Sidebar/sidebar_widget.dart';
import '../Widgets/TopBar/top_bar_widget.dart';

class CategoryList extends StatefulWidget {
  const CategoryList({super.key});

  static const String route = '/categoryList';

  @override
  State<CategoryList> createState() => _CategoryListState();
}

class _CategoryListState extends State<CategoryList> {
  int selectedItem = 10;
  int itemCount = 10;
  TextEditingController itemCategoryController = TextEditingController();
  ScrollController mainScroll = ScrollController();
  String searchItem = '';
  bool isSize = false;
  bool isColor = false;
  bool isWeight = false;
  bool isCapacity = false;
  bool isType = false;
  bool isWarranty = false;
  GlobalKey<FormState> categoryNameKey = GlobalKey<FormState>();

  bool categoryValidateAndSave() {
    final form = categoryNameKey.currentState;
    if (form!.validate()) {
      form.save();
      return true;
    }
    return false;
  }

  @override
  void initState() {
    super.initState();
    checkCurrentUserAndRestartApp();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          backgroundColor: kDarkWhite,
          body: Scrollbar(
            controller: mainScroll,
            child: SingleChildScrollView(
              controller: mainScroll,
              scrollDirection: Axis.horizontal,
              child: Consumer(builder: (_, ref, watch) {
                AsyncValue<List<CategoryModel>> categories =
                    ref.watch(categoryProvider);
                return categories.when(data: (list) {
                  List<CategoryModel> categoryLists = [];
                  List<CategoryModel> showAbleCategories = [];
                  List<String> categoryNames = [];
                  for (var element in list) {
                    if (element.categoryName
                        .removeAllWhiteSpace()
                        .toLowerCase()
                        .contains(searchItem.toLowerCase())) {
                      showAbleCategories.add(element);
                    } else if (searchItem == '') {
                      showAbleCategories.add(element);
                      categoryNames.add(element.categoryName
                          .removeAllWhiteSpace()
                          .toLowerCase());
                    }
                  }
                  return Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(
                        width: 240,
                        child: SideBarWidget(
                          index: 3,
                          isTab: false,
                        ),
                      ),
                      Container(
                        // width: context.width() < 1080 ? 1080 - 240 : MediaQuery.of(context).size.width - 240,
                        width: MediaQuery.of(context).size.width < 1275
                            ? 1275 - 240
                            : MediaQuery.of(context).size.width - 240,
                        decoration: const BoxDecoration(color: kDarkWhite),
                        child: SingleChildScrollView(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              //_______________________________top_bar____________________________
                              const TopBar(),
                              Padding(
                                padding: const EdgeInsets.all(20.0),
                                child: Container(
                                  padding: const EdgeInsets.only(
                                      left: 20.0,
                                      right: 20.0,
                                      top: 10.0,
                                      bottom: 10.0),
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(20.0),
                                      color: kWhite),
                                  child: Column(
                                    children: [
                                      Row(
                                        children: [
                                          Text(
                                            lang.S.of(context).customerList,
                                            style: kTextStyle.copyWith(
                                                color: kTitleColor,
                                                fontWeight: FontWeight.bold,
                                                fontSize: 18.0),
                                          ),
                                          const Spacer(),

                                          ///___________search________________________________________________-
                                          Container(
                                            height: 40.0,
                                            width: 300,
                                            decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(30.0),
                                                border: Border.all(
                                                    color: kGreyTextColor
                                                        .withOpacity(0.1))),
                                            child: AppTextField(
                                              showCursor: true,
                                              cursorColor: kTitleColor,
                                              onChanged: (value) {
                                                setState(() {
                                                  searchItem = value;
                                                });
                                              },
                                              textFieldType: TextFieldType.NAME,
                                              decoration:
                                                  kInputDecoration.copyWith(
                                                contentPadding:
                                                    const EdgeInsets.all(10.0),
                                                hintText: (lang.S
                                                    .of(context)
                                                    .searchByNameOrPhone),
                                                hintStyle: kTextStyle.copyWith(
                                                    color: kGreyTextColor),
                                                border: InputBorder.none,
                                                enabledBorder:
                                                    const OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.all(
                                                          Radius.circular(
                                                              30.0)),
                                                  borderSide: BorderSide(
                                                      color:
                                                          kBorderColorTextField,
                                                      width: 1),
                                                ),
                                                focusedBorder:
                                                    const OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.all(
                                                          Radius.circular(
                                                              30.0)),
                                                  borderSide: BorderSide(
                                                      color:
                                                          kBorderColorTextField,
                                                      width: 1),
                                                ),
                                                suffixIcon: Padding(
                                                  padding:
                                                      const EdgeInsets.all(4.0),
                                                  child: Container(
                                                      padding:
                                                          const EdgeInsets.all(
                                                              2.0),
                                                      decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(30.0),
                                                        color: kGreyTextColor
                                                            .withOpacity(0.1),
                                                      ),
                                                      child: const Icon(
                                                        FeatherIcons.search,
                                                        color: kTitleColor,
                                                      )),
                                                ),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(width: 20),
                                          Container(
                                            padding: const EdgeInsets.all(10.0),
                                            decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(5.0),
                                                color: kBlueTextColor),
                                            child: Row(
                                              children: [
                                                const Icon(FeatherIcons.plus,
                                                    color: kWhite, size: 18.0),
                                                const SizedBox(width: 5.0),
                                                Text(
                                                  "Add New Category",
                                                  style: kTextStyle.copyWith(
                                                      color: kWhite),
                                                ),
                                              ],
                                            ),
                                          ).onTap(() async {
                                            showDialog(
                                                barrierDismissible: false,
                                                context: context,
                                                builder:
                                                    (BuildContext context) {
                                                  return StatefulBuilder(
                                                      builder:
                                                          (context, setState1) {
                                                    return Dialog(
                                                      surfaceTintColor: kWhite,
                                                      shape:
                                                          RoundedRectangleBorder(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          10.0)),
                                                      child: SizedBox(
                                                        width: 600,
                                                        child: Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                  .all(20.0),
                                                          child: Column(
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .min,
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            children: [
                                                              Row(
                                                                children: [
                                                                  Container(
                                                                    padding:
                                                                        const EdgeInsets
                                                                            .all(
                                                                            4.0),
                                                                    decoration:
                                                                        const BoxDecoration(
                                                                            shape:
                                                                                BoxShape.rectangle),
                                                                    child:
                                                                        const Icon(
                                                                      FeatherIcons
                                                                          .plus,
                                                                      color:
                                                                          kTitleColor,
                                                                    ),
                                                                  ),
                                                                  const SizedBox(
                                                                      width:
                                                                          4.0),
                                                                  Text(
                                                                    lang.S
                                                                        .of(context)
                                                                        .addItemCategory,
                                                                    style: kTextStyle.copyWith(
                                                                        color:
                                                                            kTitleColor,
                                                                        fontSize:
                                                                            18.0,
                                                                        fontWeight:
                                                                            FontWeight.bold),
                                                                  ),
                                                                  const Spacer(),
                                                                  const Icon(
                                                                    FeatherIcons
                                                                        .x,
                                                                    color:
                                                                        kTitleColor,
                                                                    size: 21.0,
                                                                  ).onTap(() {
                                                                    itemCategoryController
                                                                        .clear();
                                                                    isSize =
                                                                        false;
                                                                    isColor =
                                                                        false;
                                                                    isWeight =
                                                                        false;
                                                                    isCapacity =
                                                                        false;
                                                                    isType =
                                                                        false;
                                                                    isWarranty =
                                                                        false;
                                                                    finish(
                                                                        context);
                                                                  })
                                                                ],
                                                              ),
                                                              const SizedBox(
                                                                  height: 20.0),
                                                              Divider(
                                                                thickness: 1.0,
                                                                color: kGreyTextColor
                                                                    .withOpacity(
                                                                        0.2),
                                                              ),
                                                              const SizedBox(
                                                                  height: 10.0),
                                                              Row(
                                                                children: [
                                                                  Text(
                                                                    lang.S
                                                                        .of(context)
                                                                        .categoryName,
                                                                    style: kTextStyle.copyWith(
                                                                        color:
                                                                            kTitleColor,
                                                                        fontSize:
                                                                            18.0),
                                                                  ),
                                                                  const SizedBox(
                                                                      width:
                                                                          20),
                                                                  Form(
                                                                    key:
                                                                        categoryNameKey,
                                                                    child:
                                                                        SizedBox(
                                                                      width:
                                                                          400,
                                                                      child:
                                                                          TextFormField(
                                                                        controller:
                                                                            itemCategoryController,
                                                                        validator:
                                                                            (value) {
                                                                          if (value
                                                                              .isEmptyOrNull) {
                                                                            //return 'Category name is required.';
                                                                            return '${lang.S.of(context).categoryNameIsRequired}.';
                                                                          } else if (categoryNames.contains(value
                                                                              .removeAllWhiteSpace()
                                                                              .toLowerCase())) {
                                                                            //return 'Category name is already exist.';
                                                                            return '${lang.S.of(context).categoryNameIsAlreadyExist}.';
                                                                          } else {
                                                                            return null;
                                                                          }
                                                                        },
                                                                        showCursor:
                                                                            true,
                                                                        cursorColor:
                                                                            kTitleColor,
                                                                        decoration:
                                                                            kInputDecoration.copyWith(
                                                                          errorBorder:
                                                                              const OutlineInputBorder(borderSide: BorderSide(color: Colors.red)),
                                                                          labelText: lang
                                                                              .S
                                                                              .of(context)
                                                                              .categoryName,
                                                                          hintText: lang
                                                                              .S
                                                                              .of(context)
                                                                              .enterCategoryName,
                                                                          hintStyle:
                                                                              kTextStyle.copyWith(color: kGreyTextColor),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                              const SizedBox(
                                                                  height: 30.0),
                                                              Text(
                                                                lang.S
                                                                    .of(context)
                                                                    .selectVariations,
                                                                style: kTextStyle.copyWith(
                                                                    color:
                                                                        kTitleColor,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .bold,
                                                                    fontSize:
                                                                        18.0),
                                                              ),
                                                              Row(
                                                                children: [
                                                                  Expanded(
                                                                    child:
                                                                        ListTile(
                                                                      leading:
                                                                          Checkbox(
                                                                        activeColor:
                                                                            kMainColor,
                                                                        shape:
                                                                            RoundedRectangleBorder(
                                                                          borderRadius:
                                                                              BorderRadius.circular(30.0),
                                                                        ),
                                                                        value:
                                                                            isSize,
                                                                        onChanged:
                                                                            (val) {
                                                                          setState1(
                                                                            () {
                                                                              isSize = val!;
                                                                            },
                                                                          );
                                                                        },
                                                                      ),
                                                                      title: Text(lang
                                                                          .S
                                                                          .of(context)
                                                                          .size),
                                                                    ),
                                                                  ),
                                                                  Expanded(
                                                                    child:
                                                                        ListTile(
                                                                      leading:
                                                                          Checkbox(
                                                                        activeColor:
                                                                            kMainColor,
                                                                        shape:
                                                                            RoundedRectangleBorder(
                                                                          borderRadius:
                                                                              BorderRadius.circular(30.0),
                                                                        ),
                                                                        value:
                                                                            isColor,
                                                                        onChanged:
                                                                            (val) {
                                                                          setState1(
                                                                              () {
                                                                            isColor =
                                                                                val!;
                                                                          });
                                                                        },
                                                                      ),
                                                                      title: Text(lang
                                                                          .S
                                                                          .of(context)
                                                                          .color),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                              Row(
                                                                children: [
                                                                  Expanded(
                                                                    child:
                                                                        ListTile(
                                                                      leading:
                                                                          Checkbox(
                                                                        activeColor:
                                                                            kMainColor,
                                                                        shape:
                                                                            RoundedRectangleBorder(
                                                                          borderRadius:
                                                                              BorderRadius.circular(30.0),
                                                                        ),
                                                                        value:
                                                                            isWeight,
                                                                        onChanged:
                                                                            (val) {
                                                                          setState1(
                                                                              () {
                                                                            isWeight =
                                                                                val!;
                                                                          });
                                                                        },
                                                                      ),
                                                                      title: Text(lang
                                                                          .S
                                                                          .of(context)
                                                                          .wight),
                                                                    ),
                                                                  ),
                                                                  Expanded(
                                                                    child:
                                                                        ListTile(
                                                                      leading:
                                                                          Checkbox(
                                                                        activeColor:
                                                                            kMainColor,
                                                                        shape:
                                                                            RoundedRectangleBorder(
                                                                          borderRadius:
                                                                              BorderRadius.circular(30.0),
                                                                        ),
                                                                        value:
                                                                            isCapacity,
                                                                        onChanged:
                                                                            (val) {
                                                                          setState1(
                                                                            () {
                                                                              isCapacity = val!;
                                                                            },
                                                                          );
                                                                        },
                                                                      ),
                                                                      title: Text(lang
                                                                          .S
                                                                          .of(context)
                                                                          .capacity),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                              Row(
                                                                children: [
                                                                  Expanded(
                                                                    child:
                                                                        ListTile(
                                                                      leading:
                                                                          Checkbox(
                                                                        activeColor:
                                                                            kMainColor,
                                                                        shape:
                                                                            RoundedRectangleBorder(
                                                                          borderRadius:
                                                                              BorderRadius.circular(30.0),
                                                                        ),
                                                                        value:
                                                                            isType,
                                                                        onChanged:
                                                                            (val) {
                                                                          setState1(
                                                                            () {
                                                                              isType = val!;
                                                                            },
                                                                          );
                                                                        },
                                                                      ),
                                                                      title: Text(lang
                                                                          .S
                                                                          .of(context)
                                                                          .type),
                                                                    ),
                                                                  ),
                                                                  Expanded(
                                                                    child:
                                                                        ListTile(
                                                                      leading:
                                                                          Checkbox(
                                                                        activeColor:
                                                                            kMainColor,
                                                                        shape:
                                                                            RoundedRectangleBorder(
                                                                          borderRadius:
                                                                              BorderRadius.circular(30.0),
                                                                        ),
                                                                        value:
                                                                            isWarranty,
                                                                        onChanged:
                                                                            (val) {
                                                                          setState1(
                                                                            () {
                                                                              isWarranty = val!;
                                                                            },
                                                                          );
                                                                        },
                                                                      ),
                                                                      title: Text(lang
                                                                          .S
                                                                          .of(context)
                                                                          .warranty),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                              const SizedBox(
                                                                  height: 5.0),
                                                              Divider(
                                                                thickness: 1.0,
                                                                color: kGreyTextColor
                                                                    .withOpacity(
                                                                        0.2),
                                                              ),
                                                              const SizedBox(
                                                                  height: 5.0),
                                                              Row(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .end,
                                                                children: [
                                                                  Container(
                                                                    padding:
                                                                        const EdgeInsets
                                                                            .all(
                                                                            10.0),
                                                                    decoration: BoxDecoration(
                                                                        borderRadius:
                                                                            BorderRadius.circular(
                                                                                5.0),
                                                                        color:
                                                                            kRedTextColor),
                                                                    child: Text(
                                                                      lang.S
                                                                          .of(context)
                                                                          .cancel,
                                                                      style: kTextStyle.copyWith(
                                                                          color:
                                                                              kWhite),
                                                                    ),
                                                                  ).onTap(() {
                                                                    itemCategoryController
                                                                        .clear();
                                                                    isSize =
                                                                        false;
                                                                    isColor =
                                                                        false;
                                                                    isWeight =
                                                                        false;
                                                                    isCapacity =
                                                                        false;
                                                                    isType =
                                                                        false;
                                                                    isWarranty =
                                                                        false;

                                                                    finish(
                                                                        context);
                                                                  }),
                                                                  const SizedBox(
                                                                      width:
                                                                          5.0),
                                                                  Container(
                                                                    padding:
                                                                        const EdgeInsets
                                                                            .all(
                                                                            10.0),
                                                                    decoration: BoxDecoration(
                                                                        borderRadius:
                                                                            BorderRadius.circular(
                                                                                5.0),
                                                                        color:
                                                                            kGreenTextColor),
                                                                    child: Text(
                                                                      lang.S
                                                                          .of(context)
                                                                          .submit,
                                                                      style: kTextStyle.copyWith(
                                                                          color:
                                                                              kWhite),
                                                                    ),
                                                                  ).onTap(
                                                                      () async {
                                                                    if (categoryValidateAndSave()) {
                                                                      EasyLoading.show(
                                                                          status: lang
                                                                              .S
                                                                              .of(context)
                                                                              .addingCategory);
                                                                      try {
                                                                        final DatabaseReference categoryInformationRef = FirebaseDatabase
                                                                            .instance
                                                                            .ref()
                                                                            .child(await getUserID())
                                                                            .child('Categories');
                                                                        CategoryModel
                                                                            categoryModel =
                                                                            CategoryModel(
                                                                          categoryName:
                                                                              itemCategoryController.text,
                                                                          size:
                                                                              isSize,
                                                                          color:
                                                                              isColor,
                                                                          capacity:
                                                                              isCapacity,
                                                                          type:
                                                                              isType,
                                                                          weight:
                                                                              isWeight,
                                                                          warranty:
                                                                              isWarranty,
                                                                        );

                                                                        await categoryInformationRef
                                                                            .push()
                                                                            .set(categoryModel.toJson());
                                                                        ref.refresh(
                                                                            categoryProvider);
                                                                        itemCategoryController
                                                                            .clear();
                                                                        isSize =
                                                                            false;
                                                                        isColor =
                                                                            false;
                                                                        isWeight =
                                                                            false;
                                                                        isCapacity =
                                                                            false;
                                                                        isType =
                                                                            false;
                                                                        isWarranty =
                                                                            false;
                                                                        //EasyLoading.showSuccess("Successfully Added");
                                                                        EasyLoading.showSuccess(lang
                                                                            .S
                                                                            .of(context)
                                                                            .successfullyAdded);

                                                                        finish(
                                                                            context);
                                                                      } catch (e) {
                                                                        EasyLoading.showError(lang
                                                                            .S
                                                                            .of(context)
                                                                            .error);
                                                                      }
                                                                    }
                                                                  })
                                                                ],
                                                              )
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    );
                                                  });
                                                });
                                            // else {
                                            //   EasyLoading.showError('Update your plan first\nAdd Customer limit is over.');
                                            // }
                                          })
                                        ],
                                      ),
                                      const SizedBox(height: 5.0),
                                      Divider(
                                        thickness: 1.0,
                                        color: kGreyTextColor.withOpacity(0.2),
                                      ),

                                      ///__________Customer_List________________________________________________

                                      const SizedBox(height: 20.0),
                                      showAbleCategories.isNotEmpty
                                          ? Column(
                                              children: [
                                                Container(
                                                  padding:
                                                      const EdgeInsets.all(15),
                                                  decoration:
                                                      const BoxDecoration(
                                                          color: kbgColor),
                                                  child: Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceBetween,
                                                    children: [
                                                      const SizedBox(
                                                          width: 50,
                                                          child: Text('S.L')),
                                                      SizedBox(
                                                          width: 230,
                                                          child: Text(
                                                              "Category Name")),
                                                      SizedBox(
                                                          width: 75,
                                                          child: Text("Type")),
                                                      SizedBox(
                                                          width: 100,
                                                          child: Text("Size")),
                                                      SizedBox(
                                                          width: 150,
                                                          child: Text("Color")),
                                                      SizedBox(
                                                          width: 70,
                                                          child:
                                                              Text("Capacity")),
                                                      const SizedBox(
                                                          width: 30,
                                                          child: Icon(
                                                              FeatherIcons
                                                                  .settings)),
                                                    ],
                                                  ),
                                                ),
                                                SizedBox(
                                                  height: (MediaQuery.of(
                                                                      context)
                                                                  .size
                                                                  .height -
                                                              315)
                                                          .isNegative
                                                      ? 0
                                                      : MediaQuery.of(context)
                                                              .size
                                                              .height -
                                                          315,
                                                  child: ListView.builder(
                                                    shrinkWrap: true,
                                                    physics:
                                                        const AlwaysScrollableScrollPhysics(),
                                                    itemCount:
                                                        showAbleCategories
                                                            .length,
                                                    itemBuilder:
                                                        (BuildContext context,
                                                            int index) {
                                                      return Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .only(
                                                                bottom: 5),
                                                        child: Column(
                                                          children: [
                                                            Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                      .all(
                                                                      15.0),
                                                              child: Row(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .spaceBetween,
                                                                children: [
                                                                  ///______________S.L__________________________________________________
                                                                  SizedBox(
                                                                    width: 50,
                                                                    child: Text(
                                                                        (index +
                                                                                1)
                                                                            .toString(),
                                                                        style: kTextStyle.copyWith(
                                                                            color:
                                                                                kGreyTextColor)),
                                                                  ),

                                                                  ///______________name__________________________________________________
                                                                  SizedBox(
                                                                    width: 230,
                                                                    child: Text(
                                                                      showAbleCategories[
                                                                              index]
                                                                          .categoryName,
                                                                      maxLines:
                                                                          2,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      style: kTextStyle.copyWith(
                                                                          color:
                                                                              kTitleColor,
                                                                          fontWeight:
                                                                              FontWeight.bold),
                                                                    ),
                                                                  ),

                                                                  ///____________type_________________________________________________
                                                                  SizedBox(
                                                                    width: 75,
                                                                    child: Text(
                                                                      showAbleCategories[
                                                                              index]
                                                                          .type
                                                                          .toString(),
                                                                      maxLines:
                                                                          2,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      style: kTextStyle.copyWith(
                                                                          color:
                                                                              kGreyTextColor),
                                                                    ),
                                                                  ),

                                                                  ///______Phone___________________________________________________________
                                                                  SizedBox(
                                                                    width: 100,
                                                                    child: Text(
                                                                      showAbleCategories[
                                                                              index]
                                                                          .size
                                                                          .toString(),
                                                                      style: kTextStyle.copyWith(
                                                                          color:
                                                                              kGreyTextColor),
                                                                      maxLines:
                                                                          2,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                    ),
                                                                  ),

                                                                  ///___________Email____________________________________________________
                                                                  SizedBox(
                                                                    width: 150,
                                                                    child: Text(
                                                                      showAbleCategories[
                                                                              index]
                                                                          .color
                                                                          .toString(),
                                                                      style: kTextStyle.copyWith(
                                                                          color:
                                                                              kGreyTextColor),
                                                                      maxLines:
                                                                          2,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                    ),
                                                                  ),

                                                                  ///___________Due____________________________________________________

                                                                  SizedBox(
                                                                    width: 70,
                                                                    child: Text(
                                                                      showAbleCategories[
                                                                              index]
                                                                          .capacity
                                                                          .toString(),
                                                                      style: kTextStyle.copyWith(
                                                                          color:
                                                                              kGreyTextColor),
                                                                      maxLines:
                                                                          2,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                    ),
                                                                  ),

                                                                  ///_______________actions_________________________________________________
                                                                  SizedBox(
                                                                    width: 30,
                                                                    child:
                                                                        Theme(
                                                                      data: ThemeData(
                                                                          highlightColor:
                                                                              dropdownItemColor,
                                                                          focusColor:
                                                                              dropdownItemColor,
                                                                          hoverColor:
                                                                              dropdownItemColor),
                                                                      child:
                                                                          PopupMenuButton(
                                                                        surfaceTintColor:
                                                                            Colors.white,
                                                                        padding:
                                                                            EdgeInsets.zero,
                                                                        itemBuilder:
                                                                            (BuildContext bc) =>
                                                                                [
                                                                          ///____________Edit____________________________________________________
                                                                          PopupMenuItem(
                                                                            child:
                                                                                Row(
                                                                              children: [
                                                                                const Icon(FeatherIcons.edit3, size: 18.0, color: kTitleColor),
                                                                                const SizedBox(width: 4.0),
                                                                                Text(
                                                                                  lang.S.of(context).edit,
                                                                                  style: kTextStyle.copyWith(color: kGreyTextColor),
                                                                                ),
                                                                              ],
                                                                            ).onTap(() {
                                                                              itemCategoryController.text = showAbleCategories[index].categoryName;
                                                                              setState(() {
                                                                                isSize = showAbleCategories[index].size;
                                                                                isColor = showAbleCategories[index].color;
                                                                                isWeight = showAbleCategories[index].weight;
                                                                                isCapacity = showAbleCategories[index].capacity;
                                                                                isType = showAbleCategories[index].type;
                                                                                isWarranty = showAbleCategories[index].warranty;
                                                                              });

                                                                              showDialog(
                                                                                  barrierDismissible: false,
                                                                                  context: context,
                                                                                  builder: (BuildContext dialogContext) {
                                                                                    return StatefulBuilder(builder: (context, setState1) {
                                                                                      return Dialog(
                                                                                        surfaceTintColor: kWhite,
                                                                                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
                                                                                        child: SizedBox(
                                                                                          width: 600,
                                                                                          child: Padding(
                                                                                            padding: const EdgeInsets.all(20.0),
                                                                                            child: Column(
                                                                                              mainAxisSize: MainAxisSize.min,
                                                                                              crossAxisAlignment: CrossAxisAlignment.start,
                                                                                              children: [
                                                                                                Row(
                                                                                                  children: [
                                                                                                    Container(
                                                                                                      padding: const EdgeInsets.all(4.0),
                                                                                                      decoration: const BoxDecoration(shape: BoxShape.rectangle),
                                                                                                      child: const Icon(
                                                                                                        FeatherIcons.plus,
                                                                                                        color: kTitleColor,
                                                                                                      ),
                                                                                                    ),
                                                                                                    const SizedBox(width: 4.0),
                                                                                                    Text(
                                                                                                      "Edit Category",
                                                                                                      style: kTextStyle.copyWith(color: kTitleColor, fontSize: 18.0, fontWeight: FontWeight.bold),
                                                                                                    ),
                                                                                                    const Spacer(),
                                                                                                    const Icon(
                                                                                                      FeatherIcons.x,
                                                                                                      color: kTitleColor,
                                                                                                      size: 21.0,
                                                                                                    ).onTap(() {
                                                                                                      itemCategoryController.clear();
                                                                                                      isSize = false;
                                                                                                      isColor = false;
                                                                                                      isWeight = false;
                                                                                                      isCapacity = false;
                                                                                                      isType = false;
                                                                                                      isWarranty = false;
                                                                                                      finish(context);
                                                                                                    })
                                                                                                  ],
                                                                                                ),
                                                                                                const SizedBox(height: 20.0),
                                                                                                Divider(
                                                                                                  thickness: 1.0,
                                                                                                  color: kGreyTextColor.withOpacity(0.2),
                                                                                                ),
                                                                                                const SizedBox(height: 10.0),
                                                                                                Row(
                                                                                                  children: [
                                                                                                    Text(
                                                                                                      lang.S.of(context).categoryName,
                                                                                                      style: kTextStyle.copyWith(color: kTitleColor, fontSize: 18.0),
                                                                                                    ),
                                                                                                    const SizedBox(width: 20),
                                                                                                    Form(
                                                                                                      key: categoryNameKey,
                                                                                                      child: SizedBox(
                                                                                                        width: 400,
                                                                                                        child: TextFormField(
                                                                                                          controller: itemCategoryController,
                                                                                                          validator: (value) {
                                                                                                            if (value.isEmptyOrNull) {
                                                                                                              //return 'Category name is required.';
                                                                                                              return '${lang.S.of(context).categoryNameIsRequired}.';
                                                                                                            } else if (categoryNames.contains(value.removeAllWhiteSpace().toLowerCase())) {
                                                                                                              //return 'Category name is already exist.';
                                                                                                              return '${lang.S.of(context).categoryNameIsAlreadyExist}.';
                                                                                                            } else {
                                                                                                              return null;
                                                                                                            }
                                                                                                          },
                                                                                                          showCursor: true,
                                                                                                          cursorColor: kTitleColor,
                                                                                                          decoration: kInputDecoration.copyWith(
                                                                                                            errorBorder: const OutlineInputBorder(borderSide: BorderSide(color: Colors.red)),
                                                                                                            labelText: lang.S.of(context).categoryName,
                                                                                                            hintText: lang.S.of(context).enterCategoryName,
                                                                                                            hintStyle: kTextStyle.copyWith(color: kGreyTextColor),
                                                                                                          ),
                                                                                                        ),
                                                                                                      ),
                                                                                                    ),
                                                                                                  ],
                                                                                                ),
                                                                                                const SizedBox(height: 30.0),
                                                                                                Text(
                                                                                                  lang.S.of(context).selectVariations,
                                                                                                  style: kTextStyle.copyWith(color: kTitleColor, fontWeight: FontWeight.bold, fontSize: 18.0),
                                                                                                ),
                                                                                                Row(
                                                                                                  children: [
                                                                                                    Expanded(
                                                                                                      child: ListTile(
                                                                                                        leading: Checkbox(
                                                                                                          activeColor: kMainColor,
                                                                                                          shape: RoundedRectangleBorder(
                                                                                                            borderRadius: BorderRadius.circular(30.0),
                                                                                                          ),
                                                                                                          value: isSize,
                                                                                                          onChanged: (val) {
                                                                                                            setState1(
                                                                                                              () {
                                                                                                                isSize = val!;
                                                                                                              },
                                                                                                            );
                                                                                                          },
                                                                                                        ),
                                                                                                        title: Text(lang.S.of(context).size),
                                                                                                      ),
                                                                                                    ),
                                                                                                    Expanded(
                                                                                                      child: ListTile(
                                                                                                        leading: Checkbox(
                                                                                                          activeColor: kMainColor,
                                                                                                          shape: RoundedRectangleBorder(
                                                                                                            borderRadius: BorderRadius.circular(30.0),
                                                                                                          ),
                                                                                                          value: isColor,
                                                                                                          onChanged: (val) {
                                                                                                            setState1(() {
                                                                                                              isColor = val!;
                                                                                                            });
                                                                                                          },
                                                                                                        ),
                                                                                                        title: Text(lang.S.of(context).color),
                                                                                                      ),
                                                                                                    ),
                                                                                                  ],
                                                                                                ),
                                                                                                Row(
                                                                                                  children: [
                                                                                                    Expanded(
                                                                                                      child: ListTile(
                                                                                                        leading: Checkbox(
                                                                                                          activeColor: kMainColor,
                                                                                                          shape: RoundedRectangleBorder(
                                                                                                            borderRadius: BorderRadius.circular(30.0),
                                                                                                          ),
                                                                                                          value: isWeight,
                                                                                                          onChanged: (val) {
                                                                                                            setState1(() {
                                                                                                              isWeight = val!;
                                                                                                            });
                                                                                                          },
                                                                                                        ),
                                                                                                        title: Text(lang.S.of(context).wight),
                                                                                                      ),
                                                                                                    ),
                                                                                                    Expanded(
                                                                                                      child: ListTile(
                                                                                                        leading: Checkbox(
                                                                                                          activeColor: kMainColor,
                                                                                                          shape: RoundedRectangleBorder(
                                                                                                            borderRadius: BorderRadius.circular(30.0),
                                                                                                          ),
                                                                                                          value: isCapacity,
                                                                                                          onChanged: (val) {
                                                                                                            setState1(
                                                                                                              () {
                                                                                                                isCapacity = val!;
                                                                                                              },
                                                                                                            );
                                                                                                          },
                                                                                                        ),
                                                                                                        title: Text(lang.S.of(context).capacity),
                                                                                                      ),
                                                                                                    ),
                                                                                                  ],
                                                                                                ),
                                                                                                Row(
                                                                                                  children: [
                                                                                                    Expanded(
                                                                                                      child: ListTile(
                                                                                                        leading: Checkbox(
                                                                                                          activeColor: kMainColor,
                                                                                                          shape: RoundedRectangleBorder(
                                                                                                            borderRadius: BorderRadius.circular(30.0),
                                                                                                          ),
                                                                                                          value: isType,
                                                                                                          onChanged: (val) {
                                                                                                            setState1(
                                                                                                              () {
                                                                                                                isType = val!;
                                                                                                              },
                                                                                                            );
                                                                                                          },
                                                                                                        ),
                                                                                                        title: Text(lang.S.of(context).type),
                                                                                                      ),
                                                                                                    ),
                                                                                                    Expanded(
                                                                                                      child: ListTile(
                                                                                                        leading: Checkbox(
                                                                                                          activeColor: kMainColor,
                                                                                                          shape: RoundedRectangleBorder(
                                                                                                            borderRadius: BorderRadius.circular(30.0),
                                                                                                          ),
                                                                                                          value: isWarranty,
                                                                                                          onChanged: (val) {
                                                                                                            setState1(
                                                                                                              () {
                                                                                                                isWarranty = val!;
                                                                                                              },
                                                                                                            );
                                                                                                          },
                                                                                                        ),
                                                                                                        title: Text(lang.S.of(context).warranty),
                                                                                                      ),
                                                                                                    ),
                                                                                                  ],
                                                                                                ),
                                                                                                const SizedBox(height: 5.0),
                                                                                                Divider(
                                                                                                  thickness: 1.0,
                                                                                                  color: kGreyTextColor.withOpacity(0.2),
                                                                                                ),
                                                                                                const SizedBox(height: 5.0),
                                                                                                Row(
                                                                                                  mainAxisAlignment: MainAxisAlignment.end,
                                                                                                  children: [
                                                                                                    Container(
                                                                                                      padding: const EdgeInsets.all(10.0),
                                                                                                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(5.0), color: kRedTextColor),
                                                                                                      child: Text(
                                                                                                        lang.S.of(context).cancel,
                                                                                                        style: kTextStyle.copyWith(color: kWhite),
                                                                                                      ),
                                                                                                    ).onTap(() {
                                                                                                      itemCategoryController.clear();
                                                                                                      isSize = false;
                                                                                                      isColor = false;
                                                                                                      isWeight = false;
                                                                                                      isCapacity = false;
                                                                                                      isType = false;
                                                                                                      isWarranty = false;

                                                                                                      finish(context);
                                                                                                    }),
                                                                                                    const SizedBox(width: 5.0),
                                                                                                    Container(
                                                                                                      padding: const EdgeInsets.all(10.0),
                                                                                                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(5.0), color: kGreenTextColor),
                                                                                                      child: Text(
                                                                                                        lang.S.of(context).submit,
                                                                                                        style: kTextStyle.copyWith(color: kWhite),
                                                                                                      ),
                                                                                                    ).onTap(() async {
                                                                                                      if (categoryValidateAndSave()) {
                                                                                                        EasyLoading.show(status: lang.S.of(context).addingCategory);
                                                                                                        try {
                                                                                                          FirebaseDatabase.instance.ref().child(await getUserID()).child('Categories').orderByChild('categoryName').once().then((DatabaseEvent event) {
                                                                                                            if (event.snapshot.value != null) {
                                                                                                              Map<dynamic, dynamic> values = event.snapshot.value as Map<dynamic, dynamic>;
                                                                                                              values.forEach((key, value) async {
                                                                                                                if (value['categoryName'] == showAbleCategories[index].categoryName) {
                                                                                                                  FirebaseDatabase.instance.ref().child(await getUserID()).child('Categories').child(key).update({
                                                                                                                    'categoryName': itemCategoryController.text,
                                                                                                                    'variationSize': isSize,
                                                                                                                    'variationColor': isColor,
                                                                                                                    'variationWeight': isWeight,
                                                                                                                    'variationCapacity': isCapacity,
                                                                                                                    'variationType': isType,
                                                                                                                  });
                                                                                                                }
                                                                                                              });
                                                                                                            }
                                                                                                          });

                                                                                                          ref.refresh(categoryProvider);
                                                                                                          EasyLoading.showSuccess('Updated Successfully');
                                                                                                          Navigator.pop(dialogContext);
                                                                                                          Navigator.pop(bc);
                                                                                                          Navigator.popAndPushNamed(context, CategoryList.route);

                                                                                                        } catch (e) {
                                                                                                          EasyLoading.showError(lang.S.of(context).error);
                                                                                                        }
                                                                                                      }
                                                                                                    })
                                                                                                  ],
                                                                                                )
                                                                                              ],
                                                                                            ),
                                                                                          ),
                                                                                        ),
                                                                                      );
                                                                                    });
                                                                                  });
                                                                            }),
                                                                          ),

                                                                          ///____________delete___________________________________________________
                                                                          PopupMenuItem(
                                                                            child:
                                                                                Row(
                                                                              children: [
                                                                                const Icon(Icons.delete_outline, size: 18.0, color: kTitleColor),
                                                                                const SizedBox(width: 4.0),
                                                                                Text(
                                                                                  lang.S.of(context).delete,
                                                                                  style: kTextStyle.copyWith(color: kGreyTextColor),
                                                                                ),
                                                                              ],
                                                                            ).onTap(() {
                                                                              if (true) {
                                                                                showDialog(
                                                                                    barrierDismissible: false,
                                                                                    context: context,
                                                                                    builder: (BuildContext dialogContext) {
                                                                                      return Center(
                                                                                        child: Container(
                                                                                          decoration: const BoxDecoration(
                                                                                            color: Colors.white,
                                                                                            borderRadius: BorderRadius.all(
                                                                                              Radius.circular(15),
                                                                                            ),
                                                                                          ),
                                                                                          child: Padding(
                                                                                            padding: const EdgeInsets.all(20.0),
                                                                                            child: Column(
                                                                                              mainAxisSize: MainAxisSize.min,
                                                                                              crossAxisAlignment: CrossAxisAlignment.center,
                                                                                              mainAxisAlignment: MainAxisAlignment.center,
                                                                                              children: [
                                                                                                Text(
                                                                                                  lang.S.of(context).areYouWantToDeleteThisCustomer,
                                                                                                  style: const TextStyle(fontSize: 22),
                                                                                                ),
                                                                                                const SizedBox(height: 30),
                                                                                                Row(
                                                                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                                                                  mainAxisSize: MainAxisSize.min,
                                                                                                  children: [
                                                                                                    GestureDetector(
                                                                                                      child: Container(
                                                                                                        width: 130,
                                                                                                        height: 50,
                                                                                                        decoration: const BoxDecoration(
                                                                                                          color: Colors.green,
                                                                                                          borderRadius: BorderRadius.all(
                                                                                                            Radius.circular(15),
                                                                                                          ),
                                                                                                        ),
                                                                                                        child: Center(
                                                                                                          child: Text(
                                                                                                            lang.S.of(context).cancel,
                                                                                                            style: const TextStyle(color: Colors.white),
                                                                                                          ),
                                                                                                        ),
                                                                                                      ),
                                                                                                      onTap: () {
                                                                                                        Navigator.pop(dialogContext);
                                                                                                        Navigator.pop(bc);
                                                                                                      },
                                                                                                    ),
                                                                                                    const SizedBox(width: 30),
                                                                                                    GestureDetector(
                                                                                                      child: Container(
                                                                                                        width: 130,
                                                                                                        height: 50,
                                                                                                        decoration: const BoxDecoration(
                                                                                                          color: Colors.red,
                                                                                                          borderRadius: BorderRadius.all(
                                                                                                            Radius.circular(15),
                                                                                                          ),
                                                                                                        ),
                                                                                                        child: Center(
                                                                                                          child: Text(
                                                                                                            lang.S.of(context).delete,
                                                                                                            style: const TextStyle(color: Colors.white),
                                                                                                          ),
                                                                                                        ),
                                                                                                      ),
                                                                                                      onTap: () async {
                                                                                                        if (!isDemo) {
                                                                                                          //Delete the category from Firebase Database by getting the key,I don't have the key in the list
                                                                                                          //Check if any product is using this category
                                                                                                          // ignore: deprecated_member_use
                                                                                                          FirebaseDatabase.instance.ref().child(await getUserID()).child('Categories').orderByChild('categoryName').once().then((DatabaseEvent event) {
                                                                                                            if (event.snapshot.value != null) {
                                                                                                              Map<dynamic, dynamic> values = event.snapshot.value as Map<dynamic, dynamic>;
                                                                                                              values.forEach((key, value) async {
                                                                                                                if (value['categoryName'] == showAbleCategories[index].categoryName) {
                                                                                                                  FirebaseDatabase.instance.ref().child(await getUserID()).child('Categories').child(key).remove();
                                                                                                                }
                                                                                                              });
                                                                                                            }
                                                                                                          });ref.refresh(categoryProvider);
                                                                                                          EasyLoading.showSuccess('Deleted Successfully');
                                                                                                          Navigator.pop(dialogContext);
                                                                                                          Navigator.pop(bc);
                                                                                                          Navigator.popAndPushNamed(context, CategoryList.route);
                                                                                                        } else {
                                                                                                          EasyLoading.showInfo(demoText);
                                                                                                        }
                                                                                                      },
                                                                                                    ),
                                                                                                  ],
                                                                                                )
                                                                                              ],
                                                                                            ),
                                                                                          ),
                                                                                        ),
                                                                                      );
                                                                                    });
                                                                              }
                                                                            }),
                                                                          ),
                                                                        ],
                                                                        onSelected:
                                                                            (value) {
                                                                          Navigator.pushNamed(
                                                                              context,
                                                                              '$value');
                                                                        },
                                                                        child:
                                                                            Center(
                                                                          child: Container(
                                                                              height: 18,
                                                                              width: 18,
                                                                              alignment: Alignment.centerRight,
                                                                              child: const Icon(
                                                                                Icons.more_vert_sharp,
                                                                                size: 18,
                                                                              )),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            Container(
                                                              width: double
                                                                  .infinity,
                                                              height: 1,
                                                              color: kGreyTextColor
                                                                  .withOpacity(
                                                                      0.2),
                                                            )
                                                          ],
                                                        ),
                                                      );
                                                    },
                                                  ),
                                                )
                                              ],
                                            )
                                          : EmptyWidget(
                                              title: lang.S
                                                  .of(context)
                                                  .noCustomerFound)
                                    ],
                                  ),
                                ),
                              ),
                              Visibility(
                                  visible:
                                      MediaQuery.of(context).size.height != 0,
                                  child: const Footer()),
                            ],
                          ),
                        ),
                      )
                    ],
                  );
                }, error: (e, stack) {
                  return Center(
                    child: Text(e.toString()),
                  );
                }, loading: () {
                  return const Center(
                    child: CircularProgressIndicator(),
                  );
                });
              }),
            ),
          )),
    );
  }
}
