// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a ko locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'ko';

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "ADDSALE": MessageLookupByLibrary.simpleMessage("매출 추가"),
        "AnExcelFilePicked":
            MessageLookupByLibrary.simpleMessage("엑셀 파일이 선택되었습니다"),
        "CATEGORY": MessageLookupByLibrary.simpleMessage("카테고리"),
        "INVOICE": MessageLookupByLibrary.simpleMessage("송장"),
        "MOBIPOS": MessageLookupByLibrary.simpleMessage("Pos Saas"),
        "OF": MessageLookupByLibrary.simpleMessage("중"),
        "Of": MessageLookupByLibrary.simpleMessage("의"),
        "Ok": MessageLookupByLibrary.simpleMessage("확인"),
        "POSSale": MessageLookupByLibrary.simpleMessage("POS 판매"),
        "PRICE": MessageLookupByLibrary.simpleMessage("가격"),
        "PRODUCTNAME": MessageLookupByLibrary.simpleMessage("제품 이름"),
        "PosSaasLoginPanel":
            MessageLookupByLibrary.simpleMessage("Pos Saas 로그인 패널"),
        "QTY": MessageLookupByLibrary.simpleMessage("수량"),
        "Quantity": MessageLookupByLibrary.simpleMessage("수량*"),
        "SL": MessageLookupByLibrary.simpleMessage("순번"),
        "STATUS": MessageLookupByLibrary.simpleMessage("상태"),
        "ShopGST": MessageLookupByLibrary.simpleMessage("상점 GST"),
        "TOTALVALUE": MessageLookupByLibrary.simpleMessage("총 가치"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("사용자 제목"),
        "aboutApp": MessageLookupByLibrary.simpleMessage("앱 정보"),
        "accountName": MessageLookupByLibrary.simpleMessage("계좌 이름"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("계좌 번호"),
        "action": MessageLookupByLibrary.simpleMessage("작업"),
        "add": MessageLookupByLibrary.simpleMessage("추가"),
        "addBrand": MessageLookupByLibrary.simpleMessage("브랜드 추가"),
        "addCategory": MessageLookupByLibrary.simpleMessage("카테고리 추가"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("고객 추가"),
        "addDescription": MessageLookupByLibrary.simpleMessage("설명 추가..."),
        "addDesignation": MessageLookupByLibrary.simpleMessage("직책 추가"),
        "addDucument": MessageLookupByLibrary.simpleMessage("문서 추가"),
        "addItem": MessageLookupByLibrary.simpleMessage("항목 추가"),
        "addItemCategory": MessageLookupByLibrary.simpleMessage("항목 카테고리 추가"),
        "addNew": MessageLookupByLibrary.simpleMessage("새로 추가"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("새로운 세금 추가"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage("단일/다중 세금 유형으로 새로운 세금 추가"),
        "addNewUser": MessageLookupByLibrary.simpleMessage("새 사용자 추가"),
        "addNewWareHouse": MessageLookupByLibrary.simpleMessage("새 창고 추가"),
        "addProduct": MessageLookupByLibrary.simpleMessage("상품 추가"),
        "addProductFirst": MessageLookupByLibrary.simpleMessage("먼저 제품을 추가하세요"),
        "addSuccessful": MessageLookupByLibrary.simpleMessage("추가 성공"),
        "addSupplier": MessageLookupByLibrary.simpleMessage("공급업체 추가"),
        "addUnit": MessageLookupByLibrary.simpleMessage("단위 추가"),
        "addUpdateExpenseList":
            MessageLookupByLibrary.simpleMessage("지출 목록 추가/수정"),
        "addUpdateIncomeList":
            MessageLookupByLibrary.simpleMessage("수입 목록 추가/수정"),
        "addUserRole": MessageLookupByLibrary.simpleMessage("사용자 역할 추가"),
        "addWareHouse": MessageLookupByLibrary.simpleMessage("창고 추가"),
        "addedSuccessfully": MessageLookupByLibrary.simpleMessage("성공적으로 추가됨"),
        "addingBrand": MessageLookupByLibrary.simpleMessage("브랜드 추가 중"),
        "addingCategory": MessageLookupByLibrary.simpleMessage("카테고리 추가 중"),
        "addingSerialNumber": MessageLookupByLibrary.simpleMessage("일련 번호 추가?"),
        "addingUnits": MessageLookupByLibrary.simpleMessage("단위 추가 중"),
        "address": MessageLookupByLibrary.simpleMessage("주소"),
        "addressCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("주소는 비어 있을 수 없습니다"),
        "admin": MessageLookupByLibrary.simpleMessage("관리자"),
        "all": MessageLookupByLibrary.simpleMessage("전체"),
        "allBasicFeatures": MessageLookupByLibrary.simpleMessage("모든 기본 기능"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("이미 추가됨"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("이미 존재함"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("이미 계정이 있습니까?"),
        "amount": MessageLookupByLibrary.simpleMessage("금액"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage("이메일이 전송되었습니다\n받은 편지함을 확인하세요"),
        "androidIOSAppSupport":
            MessageLookupByLibrary.simpleMessage("안드로이드 및 iOS 앱 지원"),
        "applicableTax": MessageLookupByLibrary.simpleMessage("적용 세금"),
        "april": MessageLookupByLibrary.simpleMessage("4월"),
        "areYouSureToDeleteThisPurchase":
            MessageLookupByLibrary.simpleMessage("이 구매를 삭제하시겠습니까?"),
        "areYouSureToDeleteThisSale":
            MessageLookupByLibrary.simpleMessage("이 판매를 삭제하시겠습니까?"),
        "areYouSureWantToDeleteThisTax":
            MessageLookupByLibrary.simpleMessage("이 세금을 삭제하시겠습니까?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage("이 세금 그룹을 삭제하시겠습니까?"),
        "areYouWantToCreateThisQuation":
            MessageLookupByLibrary.simpleMessage("이 견적서를 생성하시겠습니까?"),
        "areYouWantToDeleteThisCustomer":
            MessageLookupByLibrary.simpleMessage("이 고객을 삭제하시겠습니까?"),
        "areYouWantToDeleteThisProduct":
            MessageLookupByLibrary.simpleMessage("이 제품을 삭제하시겠습니까"),
        "areYouWantToDeleteThisQuotion":
            MessageLookupByLibrary.simpleMessage("이 견적을 삭제하시겠습니까?"),
        "areYouWantToReturnThisSale":
            MessageLookupByLibrary.simpleMessage("이 매출을 반품하시겠습니까?"),
        "balance": MessageLookupByLibrary.simpleMessage("잔액"),
        "bank": MessageLookupByLibrary.simpleMessage("은행"),
        "bankAccounts": MessageLookupByLibrary.simpleMessage("은행 계좌"),
        "bankInformation": MessageLookupByLibrary.simpleMessage("은행 정보"),
        "bankName": MessageLookupByLibrary.simpleMessage("은행 이름"),
        "barcodeGenerate": MessageLookupByLibrary.simpleMessage("바코드 생성"),
        "between": MessageLookupByLibrary.simpleMessage("사이"),
        "billTo": MessageLookupByLibrary.simpleMessage("청구서:"),
        "branchName": MessageLookupByLibrary.simpleMessage("지점 이름"),
        "brand": MessageLookupByLibrary.simpleMessage("브랜드"),
        "brandName": MessageLookupByLibrary.simpleMessage("브랜드 이름"),
        "brandNameIsAlreadyExist":
            MessageLookupByLibrary.simpleMessage("브랜드 이름이 이미 존재합니다"),
        "brandNameIsRequired":
            MessageLookupByLibrary.simpleMessage("브랜드 이름이 필요합니다"),
        "bulkProductUpload": MessageLookupByLibrary.simpleMessage("대량 제품 업로드"),
        "bulkTemplate": MessageLookupByLibrary.simpleMessage("대량 템플릿"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("대량 업로드"),
        "businessCategory": MessageLookupByLibrary.simpleMessage("사업 카테고리"),
        "buy": MessageLookupByLibrary.simpleMessage("구매"),
        "buyPremiumPlan": MessageLookupByLibrary.simpleMessage("프리미엄 플랜 구매"),
        "buySms": MessageLookupByLibrary.simpleMessage("SMS 구매"),
        "calculator": MessageLookupByLibrary.simpleMessage("계산기:"),
        "camera": MessageLookupByLibrary.simpleMessage("카메라"),
        "cancel": MessageLookupByLibrary.simpleMessage("취소"),
        "capacity": MessageLookupByLibrary.simpleMessage("용량"),
        "card": MessageLookupByLibrary.simpleMessage("카드"),
        "cash": MessageLookupByLibrary.simpleMessage("현금"),
        "cashAndBank": MessageLookupByLibrary.simpleMessage("현금 및 은행"),
        "cashInHand": MessageLookupByLibrary.simpleMessage("현금 보유"),
        "categories": MessageLookupByLibrary.simpleMessage("카테고리"),
        "category": MessageLookupByLibrary.simpleMessage("카테고리"),
        "categoryName": MessageLookupByLibrary.simpleMessage("카테고리 이름"),
        "categoryNameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("카테고리 이름이 이미 존재합니다"),
        "categoryNameIsAlreadyExist":
            MessageLookupByLibrary.simpleMessage("카테고리 이름이 이미 존재합니다"),
        "categoryNameIsRequired":
            MessageLookupByLibrary.simpleMessage("카테고리 이름이 필요합니다"),
        "changeAmount": MessageLookupByLibrary.simpleMessage("잔액"),
        "changeReturn": MessageLookupByLibrary.simpleMessage("거스름돈"),
        "changeableAmount": MessageLookupByLibrary.simpleMessage("변경 가능한 금액"),
        "checkWarranty": MessageLookupByLibrary.simpleMessage("보증 확인"),
        "choseAplan": MessageLookupByLibrary.simpleMessage("요금제 선택"),
        "code": MessageLookupByLibrary.simpleMessage("코드"),
        "collectDue": MessageLookupByLibrary.simpleMessage("미수금 수금 >"),
        "color": MessageLookupByLibrary.simpleMessage("색상"),
        "comapnyName": MessageLookupByLibrary.simpleMessage("회사 이름"),
        "combinationOfMultipleTaxes":
            MessageLookupByLibrary.simpleMessage("여러 세금의 조합"),
        "companyAddress": MessageLookupByLibrary.simpleMessage("회사 주소"),
        "companyDescription": MessageLookupByLibrary.simpleMessage("회사 설명"),
        "companyEmailAddress":
            MessageLookupByLibrary.simpleMessage("회사 이메일 주소"),
        "companyName": MessageLookupByLibrary.simpleMessage("회사 이름"),
        "companyNameCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("회사 이름은 비어 있을 수 없습니다"),
        "companyPhoneNumber": MessageLookupByLibrary.simpleMessage("회사 전화번호"),
        "companyWebsiteUrl":
            MessageLookupByLibrary.simpleMessage("회사 웹사이트 URL"),
        "components": MessageLookupByLibrary.simpleMessage("구성 요소"),
        "confirmPassword": MessageLookupByLibrary.simpleMessage("비밀번호 확인"),
        "conformReturn": MessageLookupByLibrary.simpleMessage("반품 확인"),
        "continu": MessageLookupByLibrary.simpleMessage("계속"),
        "convertToSale": MessageLookupByLibrary.simpleMessage("판매로 전환"),
        "create": MessageLookupByLibrary.simpleMessage("만들기"),
        "createPayment": MessageLookupByLibrary.simpleMessage("결제 생성"),
        "createdBy": MessageLookupByLibrary.simpleMessage("작성자"),
        "creativeHub": MessageLookupByLibrary.simpleMessage("크리에이티브 허브"),
        "currency": MessageLookupByLibrary.simpleMessage("통화"),
        "currentPlan": MessageLookupByLibrary.simpleMessage("현재 요금제"),
        "currentStock": MessageLookupByLibrary.simpleMessage("현재 재고"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("맞춤형 송장 브랜딩"),
        "customer": MessageLookupByLibrary.simpleMessage("고객"),
        "customerDue": MessageLookupByLibrary.simpleMessage("고객 미결제금액"),
        "customerGST": MessageLookupByLibrary.simpleMessage("고객 GST"),
        "customerInvoices": MessageLookupByLibrary.simpleMessage("고객 송장"),
        "customerList": MessageLookupByLibrary.simpleMessage("고객 목록"),
        "customerName": MessageLookupByLibrary.simpleMessage("고객 이름"),
        "customerNameIsRequired":
            MessageLookupByLibrary.simpleMessage("고객 이름은 필수입니다"),
        "customerOfTheMonth": MessageLookupByLibrary.simpleMessage("이달의 고객"),
        "customerPhone": MessageLookupByLibrary.simpleMessage("고객 이름"),
        "customerType": MessageLookupByLibrary.simpleMessage("고객 유형"),
        "customerWalkIncostomer":
            MessageLookupByLibrary.simpleMessage("고객: 방문 고객"),
        "customers": MessageLookupByLibrary.simpleMessage("고객"),
        "dailyCollection": MessageLookupByLibrary.simpleMessage("일일 수금"),
        "dailySales": MessageLookupByLibrary.simpleMessage("일일 매출"),
        "dailyTransaction": MessageLookupByLibrary.simpleMessage("일일 거래"),
        "dashBoard": MessageLookupByLibrary.simpleMessage("대시보드"),
        "date": MessageLookupByLibrary.simpleMessage("날짜"),
        "dateTime": MessageLookupByLibrary.simpleMessage("날짜 시간"),
        "day": MessageLookupByLibrary.simpleMessage("일"),
        "dealer": MessageLookupByLibrary.simpleMessage("딜러"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("딜러 가격"),
        "delete": MessageLookupByLibrary.simpleMessage("삭제"),
        "deleteSuccessful": MessageLookupByLibrary.simpleMessage("삭제 성공"),
        "deleting": MessageLookupByLibrary.simpleMessage("삭제 중"),
        "deliveryCharge": MessageLookupByLibrary.simpleMessage("배송비"),
        "description": MessageLookupByLibrary.simpleMessage("설명"),
        "designation": MessageLookupByLibrary.simpleMessage("직책"),
        "designationList": MessageLookupByLibrary.simpleMessage("직책 목록"),
        "designationNameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("직책 이름이 이미 존재합니다"),
        "details": MessageLookupByLibrary.simpleMessage(">세부 정보"),
        "discount": MessageLookupByLibrary.simpleMessage("할인"),
        "discountPrice": MessageLookupByLibrary.simpleMessage("할인 가격"),
        "done": MessageLookupByLibrary.simpleMessage("완료"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("엑셀 형식 다운로드"),
        "downloadPDF": MessageLookupByLibrary.simpleMessage("PDF 다운로드"),
        "due": MessageLookupByLibrary.simpleMessage("잔액"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("미수금"),
        "dueAmountWillShowHere":
            MessageLookupByLibrary.simpleMessage("잔액이 있으면 여기에 표시됩니다."),
        "dueCollection": MessageLookupByLibrary.simpleMessage("미결제금 수금"),
        "dueDate": MessageLookupByLibrary.simpleMessage("만기일"),
        "dueIsNotAvailableForGuest":
            MessageLookupByLibrary.simpleMessage("게스트에게는 미지급 금액이 제공되지 않습니다"),
        "dueIsNotForGuestCustomer":
            MessageLookupByLibrary.simpleMessage("게스트 고객에게는 미납이 없습니다"),
        "dueList": MessageLookupByLibrary.simpleMessage("미결제 목록"),
        "dueListCustomer": MessageLookupByLibrary.simpleMessage("미납 목록 (고객)"),
        "dueListSupplier": MessageLookupByLibrary.simpleMessage("미납 목록 (공급업체)"),
        "dueTemplate": MessageLookupByLibrary.simpleMessage("미납 템플릿"),
        "dueTransaction": MessageLookupByLibrary.simpleMessage("미결 거래"),
        "duration": MessageLookupByLibrary.simpleMessage("기간"),
        "edit": MessageLookupByLibrary.simpleMessage("편집"),
        "editOrAddSerial": MessageLookupByLibrary.simpleMessage("일련 번호 편집/추가:"),
        "editSuccessfully": MessageLookupByLibrary.simpleMessage("성공적으로 수정됨"),
        "editTax": MessageLookupByLibrary.simpleMessage("세금 수정"),
        "editYourProfile": MessageLookupByLibrary.simpleMessage("프로필 편집"),
        "email": MessageLookupByLibrary.simpleMessage("이메일"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("이메일은 비어 있을 수 없습니다"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("유효한 금액을 입력하십시오"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("유효한 할인율을 입력하세요"),
        "enterAValidPhoneNumber":
            MessageLookupByLibrary.simpleMessage("유효한 전화번호를 입력하십시오"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("유효한 가격을 입력하세요"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("주소를 입력하세요"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("금액 입력"),
        "enterBrandName": MessageLookupByLibrary.simpleMessage("브랜드 이름 입력"),
        "enterBulkSMSTemplate":
            MessageLookupByLibrary.simpleMessage("대량 SMS 템플릿을 입력하세요"),
        "enterCategoryName": MessageLookupByLibrary.simpleMessage("카테고리 이름 입력"),
        "enterChangeReturn":
            MessageLookupByLibrary.simpleMessage("거스름돈을 입력하세요"),
        "enterCompanyDesciption":
            MessageLookupByLibrary.simpleMessage("회사 설명을 입력하세요"),
        "enterCompanyEmailAddress":
            MessageLookupByLibrary.simpleMessage("회사 이메일 주소를 입력하세요"),
        "enterCompanyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("회사 전화번호를 입력하세요"),
        "enterCompanyWebsiteUrl":
            MessageLookupByLibrary.simpleMessage("회사 웹사이트 URL을 입력하세요"),
        "enterCustomerGSTNumber":
            MessageLookupByLibrary.simpleMessage("고객 GST 번호를 입력하십시오"),
        "enterCustomerName":
            MessageLookupByLibrary.simpleMessage("고객 이름을 입력하세요"),
        "enterDate": MessageLookupByLibrary.simpleMessage("날짜를 입력하세요"),
        "enterDealePrice": MessageLookupByLibrary.simpleMessage("딜러 가격 입력"),
        "enterDescription": MessageLookupByLibrary.simpleMessage("설명 입력"),
        "enterDesignationName":
            MessageLookupByLibrary.simpleMessage("직책 이름을 입력하십시오"),
        "enterDiscountPrice":
            MessageLookupByLibrary.simpleMessage("할인 가격을 입력하세요"),
        "enterDueAmount": MessageLookupByLibrary.simpleMessage("미지급 금액을 입력하세요"),
        "enterDueTemplate":
            MessageLookupByLibrary.simpleMessage("미납 템플릿을 입력하세요"),
        "enterEmailAddress":
            MessageLookupByLibrary.simpleMessage("이메일 주소를 입력하세요"),
        "enterExpanseCategory":
            MessageLookupByLibrary.simpleMessage("지출 카테고리 입력"),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("지출 날짜를 입력하세요"),
        "enterIncomeCategory":
            MessageLookupByLibrary.simpleMessage("수입 카테고리 입력"),
        "enterIncomeDate": MessageLookupByLibrary.simpleMessage("수입 날짜 입력"),
        "enterLowStockAlertQuantity":
            MessageLookupByLibrary.simpleMessage("재고 부족 알림 수량을 입력하세요"),
        "enterManufacturerName":
            MessageLookupByLibrary.simpleMessage("제조업체 이름 입력"),
        "enterName": MessageLookupByLibrary.simpleMessage("이름을 입력하세요"),
        "enterNames": MessageLookupByLibrary.simpleMessage("이름 입력"),
        "enterNote": MessageLookupByLibrary.simpleMessage("메모를 입력하세요"),
        "enterOpeningBalance":
            MessageLookupByLibrary.simpleMessage("개시 잔고를 입력하세요"),
        "enterPaidAmount": MessageLookupByLibrary.simpleMessage("지불 금액을 입력하세요"),
        "enterPassword": MessageLookupByLibrary.simpleMessage("비밀번호 입력"),
        "enterPayingAmount": MessageLookupByLibrary.simpleMessage("지불 금액 입력"),
        "enterPrice": MessageLookupByLibrary.simpleMessage("가격 입력"),
        "enterPriceInNumber":
            MessageLookupByLibrary.simpleMessage("가격을 숫자로 입력하세요"),
        "enterProductCapacity":
            MessageLookupByLibrary.simpleMessage("제품 용량 입력"),
        "enterProductCode": MessageLookupByLibrary.simpleMessage("상품 코드 입력"),
        "enterProductColor": MessageLookupByLibrary.simpleMessage("제품 색상 입력"),
        "enterProductName": MessageLookupByLibrary.simpleMessage("상품명 입력"),
        "enterProductQuantity":
            MessageLookupByLibrary.simpleMessage("상품 수량 입력"),
        "enterProductSize": MessageLookupByLibrary.simpleMessage("제품 크기 입력"),
        "enterProductType": MessageLookupByLibrary.simpleMessage("상품 유형 입력"),
        "enterProductUnit": MessageLookupByLibrary.simpleMessage("제품 단위 입력"),
        "enterProductWeight": MessageLookupByLibrary.simpleMessage("제품 무게 입력"),
        "enterPurchasePrice": MessageLookupByLibrary.simpleMessage("구매 가격 입력"),
        "enterPurchaseReturnTemplate":
            MessageLookupByLibrary.simpleMessage("구매 반품 템플릿을 입력하세요"),
        "enterPurchaseTemplate":
            MessageLookupByLibrary.simpleMessage("구매 템플릿을 입력하세요"),
        "enterQuantity": MessageLookupByLibrary.simpleMessage("수량을 입력하세요"),
        "enterQuantityInNumber":
            MessageLookupByLibrary.simpleMessage("수량을 숫자로 입력하세요"),
        "enterQuotationTemplate":
            MessageLookupByLibrary.simpleMessage("견적 템플릿을 입력하세요"),
        "enterReceivedAmount":
            MessageLookupByLibrary.simpleMessage("수령 금액을 입력하세요"),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("참조 번호를 입력하세요"),
        "enterSalePrice": MessageLookupByLibrary.simpleMessage("판매 가격 입력"),
        "enterSalesReturnTemplate":
            MessageLookupByLibrary.simpleMessage("판매 반품 템플릿을 입력하세요"),
        "enterSalesTemplate":
            MessageLookupByLibrary.simpleMessage("판매 템플릿을 입력하세요"),
        "enterSerialNumber": MessageLookupByLibrary.simpleMessage("일련 번호 입력"),
        "enterSmsContent":
            MessageLookupByLibrary.simpleMessage("메시지 내용을 입력하세요"),
        "enterStockAmount":
            MessageLookupByLibrary.simpleMessage("재고 수량을 입력하세요"),
        "enterStockInNumber":
            MessageLookupByLibrary.simpleMessage("재고를 숫자로 입력하세요"),
        "enterStockNumber":
            MessageLookupByLibrary.simpleMessage("재고 번호를 입력하세요"),
        "enterTaxRate": MessageLookupByLibrary.simpleMessage("세율을 입력하세요"),
        "enterTransactionId": MessageLookupByLibrary.simpleMessage("거래 ID 입력"),
        "enterUnitName": MessageLookupByLibrary.simpleMessage("단위 이름 입력"),
        "enterUserRole": MessageLookupByLibrary.simpleMessage("사용자 역할을 입력하세요"),
        "enterUserRoleName":
            MessageLookupByLibrary.simpleMessage("사용자 역할 이름 입력"),
        "enterUserTitle": MessageLookupByLibrary.simpleMessage("사용자 제목 입력"),
        "enterValidNumber":
            MessageLookupByLibrary.simpleMessage("유효한 숫자를 입력하세요"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("창고 이름을 입력하세요"),
        "enterWarranty": MessageLookupByLibrary.simpleMessage("보증 입력"),
        "enterWholeSalePrice": MessageLookupByLibrary.simpleMessage("도매 가격 입력"),
        "enterYOurAmount": MessageLookupByLibrary.simpleMessage("금액을 입력하세요"),
        "enterYourAddress": MessageLookupByLibrary.simpleMessage("주소를 입력하세요"),
        "enterYourCompanyAddress":
            MessageLookupByLibrary.simpleMessage("회사 주소를 입력하세요"),
        "enterYourCompanyName":
            MessageLookupByLibrary.simpleMessage("회사 이름을 입력하세요"),
        "enterYourCompanyNames":
            MessageLookupByLibrary.simpleMessage("회사 이름을 입력하세요"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("이메일 주소를 입력하세요"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("비밀번호를 입력하세요"),
        "enterYourPasswordAgain":
            MessageLookupByLibrary.simpleMessage("비밀번호를 다시 입력하세요"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("전화 번호를 입력하세요"),
        "enterYourShopAddress":
            MessageLookupByLibrary.simpleMessage("상점 주소를 입력하십시오"),
        "enterYourShopGSTNumber":
            MessageLookupByLibrary.simpleMessage("상점 GST 번호를 입력하십시오"),
        "enterYourShopName":
            MessageLookupByLibrary.simpleMessage("상점 이름을 입력하세요"),
        "enterYourUserTitle":
            MessageLookupByLibrary.simpleMessage("사용자 제목을 입력하세요"),
        "entercategoryName":
            MessageLookupByLibrary.simpleMessage("카테고리 이름을 입력하세요"),
        "entries": MessageLookupByLibrary.simpleMessage("항목"),
        "error": MessageLookupByLibrary.simpleMessage("오류"),
        "excTax": MessageLookupByLibrary.simpleMessage("세금 제외"),
        "exclusive": MessageLookupByLibrary.simpleMessage("제외"),
        "expense": MessageLookupByLibrary.simpleMessage("비용"),
        "expenseCategory": MessageLookupByLibrary.simpleMessage("비용 카테고리"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("지출 날짜"),
        "expenseDetails": MessageLookupByLibrary.simpleMessage("지출 세부 정보"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("지출 목적"),
        "expensecategoryList":
            MessageLookupByLibrary.simpleMessage("지출 카테고리 목록"),
        "expenses": MessageLookupByLibrary.simpleMessage("비용"),
        "expensesList": MessageLookupByLibrary.simpleMessage("비용 목록"),
        "expireDate": MessageLookupByLibrary.simpleMessage("만료일"),
        "expired": MessageLookupByLibrary.simpleMessage("만료됨"),
        "expiredList": MessageLookupByLibrary.simpleMessage("만료 목록"),
        "failedWithError": MessageLookupByLibrary.simpleMessage("오류로 실패"),
        "february": MessageLookupByLibrary.simpleMessage("2월"),
        "fieldToPickImage": MessageLookupByLibrary.simpleMessage("이미지를 선택할 필드"),
        "fillAllRequiredField":
            MessageLookupByLibrary.simpleMessage("모든 필수 필드를 채워주세요"),
        "fivePurchase":
            MessageLookupByLibrary.simpleMessage("이번 달 최다 판매 상품 5개"),
        "forUnlimitedUses": MessageLookupByLibrary.simpleMessage("무제한 사용을 위해"),
        "forgetPassword": MessageLookupByLibrary.simpleMessage("비밀번호를 잊으셨나요?"),
        "forgotPassword": MessageLookupByLibrary.simpleMessage("비밀번호를 잊으셨나요?"),
        "freeDataBackup": MessageLookupByLibrary.simpleMessage("무료 데이터 백업"),
        "freeLifeTimeUpdate":
            MessageLookupByLibrary.simpleMessage("무료 평생 업데이트"),
        "freePackage": MessageLookupByLibrary.simpleMessage("무료 패키지"),
        "freePlan": MessageLookupByLibrary.simpleMessage("무료 플랜"),
        "generate": MessageLookupByLibrary.simpleMessage("생성"),
        "getStarted": MessageLookupByLibrary.simpleMessage("시작하기"),
        "govermentId": MessageLookupByLibrary.simpleMessage("정부 ID"),
        "grandTotal": MessageLookupByLibrary.simpleMessage("총합계"),
        "guest": MessageLookupByLibrary.simpleMessage("게스트"),
        "high": MessageLookupByLibrary.simpleMessage("높음"),
        "hold": MessageLookupByLibrary.simpleMessage("보류"),
        "holdNumber": MessageLookupByLibrary.simpleMessage("보류 번호"),
        "identityVerify": MessageLookupByLibrary.simpleMessage("신원 인증"),
        "image": MessageLookupByLibrary.simpleMessage("이미지"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("InHouse는 삭제할 수 없습니다"),
        "inHouseCantBeEdit":
            MessageLookupByLibrary.simpleMessage("InHouse는 수정할 수 없습니다"),
        "inc": MessageLookupByLibrary.simpleMessage("수입"),
        "incTax": MessageLookupByLibrary.simpleMessage("세금 포함"),
        "inclusive": MessageLookupByLibrary.simpleMessage("포함"),
        "income": MessageLookupByLibrary.simpleMessage("수입"),
        "incomeCategory": MessageLookupByLibrary.simpleMessage("수입 카테고리"),
        "incomeCategoryList":
            MessageLookupByLibrary.simpleMessage("수입 카테고리 목록"),
        "incomeDate": MessageLookupByLibrary.simpleMessage("수입 날짜"),
        "incomeDetails": MessageLookupByLibrary.simpleMessage("수입 세부 정보"),
        "incomeFor": MessageLookupByLibrary.simpleMessage("수입 대상"),
        "incomeList": MessageLookupByLibrary.simpleMessage("수입 목록"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("재고 증가"),
        "instantPrivacy": MessageLookupByLibrary.simpleMessage("즉시 비공개"),
        "invoice": MessageLookupByLibrary.simpleMessage("송장"),
        "invoiceCo": MessageLookupByLibrary.simpleMessage("송장:"),
        "invoiceHint": MessageLookupByLibrary.simpleMessage("송장 번호..."),
        "invoiceNo": MessageLookupByLibrary.simpleMessage("송장 번호"),
        "item": MessageLookupByLibrary.simpleMessage("항목"),
        "itemName": MessageLookupByLibrary.simpleMessage("품목명"),
        "items": MessageLookupByLibrary.simpleMessage("항목"),
        "january": MessageLookupByLibrary.simpleMessage("1월"),
        "july": MessageLookupByLibrary.simpleMessage("7월"),
        "june": MessageLookupByLibrary.simpleMessage("6월"),
        "kycVerification": MessageLookupByLibrary.simpleMessage("KYC 인증"),
        "last6Month": MessageLookupByLibrary.simpleMessage("지난 6개월"),
        "lastMonth": MessageLookupByLibrary.simpleMessage("지난 달"),
        "ledgeDetails": MessageLookupByLibrary.simpleMessage("원장 세부 정보"),
        "ledger": MessageLookupByLibrary.simpleMessage("원장"),
        "ledgerDetails": MessageLookupByLibrary.simpleMessage("원장 세부 사항"),
        "left": MessageLookupByLibrary.simpleMessage("왼쪽"),
        "loading": MessageLookupByLibrary.simpleMessage("로딩 중"),
        "loanAccounts": MessageLookupByLibrary.simpleMessage("대출 계좌"),
        "logOut": MessageLookupByLibrary.simpleMessage("로그 아웃"),
        "login": MessageLookupByLibrary.simpleMessage("로그인"),
        "loginPanel": MessageLookupByLibrary.simpleMessage("로그인 패널"),
        "logoPositionInInvoice":
            MessageLookupByLibrary.simpleMessage("송장 로고 위치"),
        "loss": MessageLookupByLibrary.simpleMessage("손실"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("손익"),
        "lossProfit": MessageLookupByLibrary.simpleMessage("손익"),
        "lossProfitReport": MessageLookupByLibrary.simpleMessage("손익 보고서"),
        "lossminus": MessageLookupByLibrary.simpleMessage("손실(-)"),
        "low": MessageLookupByLibrary.simpleMessage("낮음"),
        "lowStock": MessageLookupByLibrary.simpleMessage("낮은 재고"),
        "lowStockAlert": MessageLookupByLibrary.simpleMessage("재고 부족 알림"),
        "lowStocks": MessageLookupByLibrary.simpleMessage("낮은 재고"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "고객에게 브랜드 송장으로 오랜 인상을 남기세요. 우리의 무제한 업그레이드는 송장을 맞춤 설정하여 브랜드 정체성을 강화하고 고객 충성을 유발하는 전문적인 터치를 추가하는 독특한 이점을 제공합니다."),
        "manufactureDate": MessageLookupByLibrary.simpleMessage("제조일"),
        "manufacturer": MessageLookupByLibrary.simpleMessage("제조업체"),
        "march": MessageLookupByLibrary.simpleMessage("3월"),
        "margin": MessageLookupByLibrary.simpleMessage("마진"),
        "may": MessageLookupByLibrary.simpleMessage("5월"),
        "mobiPosLoginPanel":
            MessageLookupByLibrary.simpleMessage("Pos Saas 로그인 패널"),
        "mobiPosSignUpPane":
            MessageLookupByLibrary.simpleMessage("Pos Saas 가입 패널"),
        "mobilePay": MessageLookupByLibrary.simpleMessage("모바일 결제"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("모바일 결제"),
        "mobilePlusDesktop":
            MessageLookupByLibrary.simpleMessage("모바일 앱\n+\n데스크탑"),
        "moneyReciept": MessageLookupByLibrary.simpleMessage("수표 영수증"),
        "nam": MessageLookupByLibrary.simpleMessage("이름*"),
        "name": MessageLookupByLibrary.simpleMessage("이름"),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("이름이 이미 존재합니다"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("이름은 비어 있을 수 없습니다"),
        "nameCodeOrCateogry":
            MessageLookupByLibrary.simpleMessage("이름, 코드, 또는 카테고리"),
        "newCusotmers": MessageLookupByLibrary.simpleMessage("신규 고객"),
        "newCustomers": MessageLookupByLibrary.simpleMessage("신규 고객"),
        "newExpenses": MessageLookupByLibrary.simpleMessage("새 비용"),
        "newIncome": MessageLookupByLibrary.simpleMessage("새 수입"),
        "next": MessageLookupByLibrary.simpleMessage("다음"),
        "no": MessageLookupByLibrary.simpleMessage("아니요"),
        "noConnection": MessageLookupByLibrary.simpleMessage("연결 없음"),
        "noCustomerFound": MessageLookupByLibrary.simpleMessage("고객이 없습니다"),
        "noDataFound": MessageLookupByLibrary.simpleMessage("데이터가 없습니다"),
        "noDueTransantionFound":
            MessageLookupByLibrary.simpleMessage("미수 거래가 없습니다."),
        "noExpenseCategoryFound":
            MessageLookupByLibrary.simpleMessage("지출 카테고리가 없습니다."),
        "noExpenseFound": MessageLookupByLibrary.simpleMessage("비용이 없습니다"),
        "noGroupFound": MessageLookupByLibrary.simpleMessage("그룹을 찾을 수 없습니다"),
        "noIncomeCategoryFound":
            MessageLookupByLibrary.simpleMessage("수입 카테고리 없음"),
        "noIncomeFound": MessageLookupByLibrary.simpleMessage("수입 없음"),
        "noInvoiceFound": MessageLookupByLibrary.simpleMessage("송장이 없습니다"),
        "noProductFound": MessageLookupByLibrary.simpleMessage("제품이 없습니다."),
        "noPurchaseTransactionFound":
            MessageLookupByLibrary.simpleMessage("구매 거래가 없습니다."),
        "noQuotionFound": MessageLookupByLibrary.simpleMessage("견적이 없습니다."),
        "noReportFound": MessageLookupByLibrary.simpleMessage("보고서가 없습니다."),
        "noSaleTransaactionFound":
            MessageLookupByLibrary.simpleMessage("매출 거래가 없습니다"),
        "noSerialNumberFound":
            MessageLookupByLibrary.simpleMessage("일련 번호가 없습니다."),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("선택된 하위 세금이 없습니다"),
        "noSupplierFound": MessageLookupByLibrary.simpleMessage("공급업체가 없습니다"),
        "noTransactionFound": MessageLookupByLibrary.simpleMessage("거래 없음"),
        "noUserFound": MessageLookupByLibrary.simpleMessage("사용자를 찾을 수 없음"),
        "noUserFoundForThatEmail":
            MessageLookupByLibrary.simpleMessage("해당 이메일로 등록된 사용자가 없습니다"),
        "noUserRoleFound":
            MessageLookupByLibrary.simpleMessage("사용자 역할을 찾을 수 없음"),
        "nosSerialNumberFound":
            MessageLookupByLibrary.simpleMessage("일련 번호가 없습니다."),
        "notActiveUser": MessageLookupByLibrary.simpleMessage("활성화되지 않은 사용자"),
        "notFound": MessageLookupByLibrary.simpleMessage("찾을 수 없음"),
        "note": MessageLookupByLibrary.simpleMessage("메모"),
        "oK": MessageLookupByLibrary.simpleMessage("확인"),
        "ok": MessageLookupByLibrary.simpleMessage("확인"),
        "openCheques": MessageLookupByLibrary.simpleMessage("오픈 수표"),
        "openingBalance": MessageLookupByLibrary.simpleMessage("개시 잔고"),
        "openingBalanceCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("개시 잔액은 비어 있을 수 없습니다"),
        "orDragAndDropPng":
            MessageLookupByLibrary.simpleMessage("또는 PNG, JPG를 드래그 앤 드롭하세요"),
        "orDragdropXlsx":
            MessageLookupByLibrary.simpleMessage("또는 .xlsx 파일을 드래그 앤 드롭하세요"),
        "orders": MessageLookupByLibrary.simpleMessage("주문"),
        "other": MessageLookupByLibrary.simpleMessage("기타"),
        "otherIncome": MessageLookupByLibrary.simpleMessage("기타 수입"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("재고 없음"),
        "packageFeature": MessageLookupByLibrary.simpleMessage("패키지 기능"),
        "paid": MessageLookupByLibrary.simpleMessage("지불됨"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("지불 금액"),
        "party": MessageLookupByLibrary.simpleMessage("파티"),
        "partyName": MessageLookupByLibrary.simpleMessage("거래처 이름"),
        "partyType": MessageLookupByLibrary.simpleMessage("거래처 유형"),
        "password": MessageLookupByLibrary.simpleMessage("비밀번호"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage("비밀번호와 확인 비밀번호가 일치하지 않습니다"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("비밀번호는 비어 있을 수 없습니다"),
        "passwordNotMach": MessageLookupByLibrary.simpleMessage("비밀번호 불일치"),
        "payCash": MessageLookupByLibrary.simpleMessage("현금 결제"),
        "payable": MessageLookupByLibrary.simpleMessage("지불 가능"),
        "payingAmount": MessageLookupByLibrary.simpleMessage("지불 금액"),
        "payment": MessageLookupByLibrary.simpleMessage("지불"),
        "paymentIn": MessageLookupByLibrary.simpleMessage("수입"),
        "paymentOut": MessageLookupByLibrary.simpleMessage("지출"),
        "paymentType": MessageLookupByLibrary.simpleMessage("결제 유형"),
        "paymentTypes": MessageLookupByLibrary.simpleMessage("결제 유형"),
        "phone": MessageLookupByLibrary.simpleMessage("전화번호"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("전화 번호"),
        "phoneNumberAlreadyExists":
            MessageLookupByLibrary.simpleMessage("전화번호가 이미 존재합니다"),
        "phoneNumberAlreadyUsed":
            MessageLookupByLibrary.simpleMessage("이미 사용된 전화번호입니다"),
        "phoneNumberCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("전화번호는 비어 있을 수 없습니다"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("전화번호는 필수입니다"),
        "phoneVerification": MessageLookupByLibrary.simpleMessage("전화 인증"),
        "plan": MessageLookupByLibrary.simpleMessage("계획"),
        "pleaseAddAProductCode":
            MessageLookupByLibrary.simpleMessage("제품 코드를 추가하세요"),
        "pleaseAddAProductName":
            MessageLookupByLibrary.simpleMessage("제품 이름을 추가하세요"),
        "pleaseAddASale": MessageLookupByLibrary.simpleMessage("판매를 추가하세요."),
        "pleaseAddCustomer": MessageLookupByLibrary.simpleMessage("고객을 추가하세요"),
        "pleaseAddPurchasePrice":
            MessageLookupByLibrary.simpleMessage("구매 가격을 추가하세요"),
        "pleaseAddSalePrice":
            MessageLookupByLibrary.simpleMessage("판매 가격을 추가하세요"),
        "pleaseAddSomeProductFirst":
            MessageLookupByLibrary.simpleMessage("먼저 제품을 추가하세요"),
        "pleaseCheckYourInbox":
            MessageLookupByLibrary.simpleMessage("받은 편지함을 확인하십시오"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage("인터넷 연결을 확인하세요"),
        "pleaseDownloadOurMobileApp": MessageLookupByLibrary.simpleMessage(
            "모바일 앱을 다운로드하고 데스크톱 버전을 사용하려면 패키지를 구독하세요"),
        "pleaseEnterABiggerPassword":
            MessageLookupByLibrary.simpleMessage("더 긴 비밀번호를 입력하십시오"),
        "pleaseEnterACompanyName":
            MessageLookupByLibrary.simpleMessage("회사 이름을 입력하십시오"),
        "pleaseEnterAPhoneNumber":
            MessageLookupByLibrary.simpleMessage("전화번호를 입력하십시오"),
        "pleaseEnterAValidEmail":
            MessageLookupByLibrary.simpleMessage("유효한 이메일을 입력하십시오"),
        "pleaseEnterAmount": MessageLookupByLibrary.simpleMessage("금액을 입력하십시오"),
        "pleaseEnterDesignation":
            MessageLookupByLibrary.simpleMessage("직책을 입력하십시오"),
        "pleaseEnterName": MessageLookupByLibrary.simpleMessage("이름을 입력하십시오"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("비밀번호를 입력하세요"),
        "pleaseEnterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("전화번호를 입력하십시오"),
        "pleaseEnterProductStock":
            MessageLookupByLibrary.simpleMessage("제품 재고를 입력하세요"),
        "pleaseEnterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("구매 가격을 입력하세요"),
        "pleaseEnterSalePrice":
            MessageLookupByLibrary.simpleMessage("판매 가격을 입력하세요"),
        "pleaseEnterStock": MessageLookupByLibrary.simpleMessage("재고를 입력하세요"),
        "pleaseEnterTransactionNumber":
            MessageLookupByLibrary.simpleMessage("거래 번호를 입력하세요"),
        "pleaseEnterValidBalance":
            MessageLookupByLibrary.simpleMessage("유효한 잔액을 입력하십시오"),
        "pleaseEnterValidData":
            MessageLookupByLibrary.simpleMessage("유효한 데이터를 입력하세요"),
        "pleaseEnterValidPhoneNumber":
            MessageLookupByLibrary.simpleMessage("유효한 전화번호를 입력하십시오"),
        "pleaseEnterYourAddress":
            MessageLookupByLibrary.simpleMessage("주소를 입력하십시오"),
        "pleaseInterAmount": MessageLookupByLibrary.simpleMessage("금액을 입력하십시오"),
        "pleaseSelectABrand":
            MessageLookupByLibrary.simpleMessage("브랜드를 선택하세요"),
        "pleaseSelectACategory":
            MessageLookupByLibrary.simpleMessage("카테고리를 선택하십시오"),
        "pleaseSelectACustomer":
            MessageLookupByLibrary.simpleMessage("고객을 선택하세요."),
        "pleaseSelectAPlan": MessageLookupByLibrary.simpleMessage("계획을 선택하세요"),
        "pleaseSelectAProductCategory":
            MessageLookupByLibrary.simpleMessage("제품 카테고리를 선택하세요"),
        "pleaseSelectBusinessCategory":
            MessageLookupByLibrary.simpleMessage("비즈니스 카테고리를 선택하십시오"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage("앱을 사용하려면 유효한 구매 코드를 사용하십시오"),
        "pleaseentervaliddata":
            MessageLookupByLibrary.simpleMessage("유효한 데이터를 입력하세요"),
        "posSaasSingUpPanel":
            MessageLookupByLibrary.simpleMessage("Pos Saas 가입 패널"),
        "practies": MessageLookupByLibrary.simpleMessage("연습"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("프리미엄 고객 지원"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("프리미엄 플랜"),
        "preview": MessageLookupByLibrary.simpleMessage("미리보기"),
        "previous": MessageLookupByLibrary.simpleMessage("이전"),
        "previousDue": MessageLookupByLibrary.simpleMessage("이전 due:"),
        "price": MessageLookupByLibrary.simpleMessage("가격"),
        "print": MessageLookupByLibrary.simpleMessage("인쇄"),
        "printInvoice": MessageLookupByLibrary.simpleMessage("송장 인쇄"),
        "printPdf": MessageLookupByLibrary.simpleMessage("PDF 인쇄"),
        "privacyPolicy": MessageLookupByLibrary.simpleMessage("개인 정보 정책"),
        "product": MessageLookupByLibrary.simpleMessage("상품"),
        "productBarcode": MessageLookupByLibrary.simpleMessage("제품 바코드"),
        "productCategory": MessageLookupByLibrary.simpleMessage("제품 카테고리"),
        "productCod": MessageLookupByLibrary.simpleMessage("상품 코드*"),
        "productCode": MessageLookupByLibrary.simpleMessage("제품 코드"),
        "productCodeAlreadyExist":
            MessageLookupByLibrary.simpleMessage("제품 코드가 이미 존재합니다"),
        "productColor": MessageLookupByLibrary.simpleMessage("제품 색상"),
        "productList": MessageLookupByLibrary.simpleMessage("상품 목록"),
        "productNam": MessageLookupByLibrary.simpleMessage("상품명*"),
        "productName": MessageLookupByLibrary.simpleMessage("제품 이름"),
        "productNameAlreadyExist":
            MessageLookupByLibrary.simpleMessage("제품 이름이 이미 존재합니다"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage("이 창고에 이미 제품 이름이 존재합니다"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("제품 이름이 필요합니다"),
        "productNameWithCode":
            MessageLookupByLibrary.simpleMessage("제품 이름과 코드"),
        "productOutOfStock": MessageLookupByLibrary.simpleMessage("제품 재고 없음"),
        "productPrice": MessageLookupByLibrary.simpleMessage("제품 가격"),
        "productPurchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("제품 구매 가격이 필요합니다"),
        "productQuantityIsRequired":
            MessageLookupByLibrary.simpleMessage("제품 수량이 필요합니다"),
        "productSalePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("제품 판매 가격이 필요합니다"),
        "productSize": MessageLookupByLibrary.simpleMessage("제품 크기"),
        "productStock": MessageLookupByLibrary.simpleMessage("제품 재고"),
        "productType": MessageLookupByLibrary.simpleMessage("상품 유형"),
        "productUnit": MessageLookupByLibrary.simpleMessage("상품 단위"),
        "productWaranty": MessageLookupByLibrary.simpleMessage("상품 보증"),
        "productWeight": MessageLookupByLibrary.simpleMessage("제품 무게"),
        "productcapacity": MessageLookupByLibrary.simpleMessage("제품 용량"),
        "prof": MessageLookupByLibrary.simpleMessage("프로필"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("프로필 편집"),
        "profit": MessageLookupByLibrary.simpleMessage("이익"),
        "profitMinus": MessageLookupByLibrary.simpleMessage("이익(-)"),
        "profitPlus": MessageLookupByLibrary.simpleMessage("이익(+)"),
        "purchase": MessageLookupByLibrary.simpleMessage("구매"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("구매 목록"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("프리미엄 플랜 구매"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("구매 가격"),
        "purchaseReturn": MessageLookupByLibrary.simpleMessage("구매 반품"),
        "purchaseReturnTemplate":
            MessageLookupByLibrary.simpleMessage("구매 반품 템플릿"),
        "purchaseTemplate": MessageLookupByLibrary.simpleMessage("구매 템플릿"),
        "purchaseTransaction": MessageLookupByLibrary.simpleMessage("구매 거래"),
        "quantity": MessageLookupByLibrary.simpleMessage("수량"),
        "quantityIsRequired": MessageLookupByLibrary.simpleMessage("수량이 필요합니다"),
        "quotation": MessageLookupByLibrary.simpleMessage("견적서"),
        "quotationList": MessageLookupByLibrary.simpleMessage("견적 목록"),
        "quotationSaleHistory":
            MessageLookupByLibrary.simpleMessage("견적 판매 기록"),
        "quotationTemplate": MessageLookupByLibrary.simpleMessage("견적 템플릿"),
        "receiveWhatsappUpdates":
            MessageLookupByLibrary.simpleMessage("WhatsApp 업데이트 받기"),
        "receivedAmount": MessageLookupByLibrary.simpleMessage("수령 금액"),
        "recentSale": MessageLookupByLibrary.simpleMessage("최근 판매"),
        "recivedAmount": MessageLookupByLibrary.simpleMessage("받은 금액"),
        "referenceNo": MessageLookupByLibrary.simpleMessage("참조 번호"),
        "referenceNumber": MessageLookupByLibrary.simpleMessage("참조 번호"),
        "registering": MessageLookupByLibrary.simpleMessage("등록 중"),
        "registration": MessageLookupByLibrary.simpleMessage("등록"),
        "remaining": MessageLookupByLibrary.simpleMessage("남은 것: "),
        "remainingBalance": MessageLookupByLibrary.simpleMessage("잔여 잔액"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("잔여 미결제금액"),
        "remove": MessageLookupByLibrary.simpleMessage("제거"),
        "reports": MessageLookupByLibrary.simpleMessage("보고서"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("요청이 전송되었습니다"),
        "reset": MessageLookupByLibrary.simpleMessage("초기화"),
        "resetYourPassword": MessageLookupByLibrary.simpleMessage("비밀번호 재설정"),
        "result": MessageLookupByLibrary.simpleMessage("결과"),
        "retailer": MessageLookupByLibrary.simpleMessage("소매점"),
        "returnQuantity": MessageLookupByLibrary.simpleMessage("반품 수량"),
        "revenue": MessageLookupByLibrary.simpleMessage("수익"),
        "right": MessageLookupByLibrary.simpleMessage("오른쪽"),
        "sAmount": MessageLookupByLibrary.simpleMessage("판매 금액"),
        "sale": MessageLookupByLibrary.simpleMessage("판매"),
        "saleAmount": MessageLookupByLibrary.simpleMessage("판매 금액"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("판매 세부 정보"),
        "saleList": MessageLookupByLibrary.simpleMessage("매출 목록"),
        "salePrice": MessageLookupByLibrary.simpleMessage("판매 가격"),
        "salePrices": MessageLookupByLibrary.simpleMessage("판매 가격*"),
        "saleQuantity": MessageLookupByLibrary.simpleMessage("판매 수량"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("매출 반품"),
        "saleSuccessfullyDone":
            MessageLookupByLibrary.simpleMessage("판매가 성공적으로 완료되었습니다"),
        "saleTransaction": MessageLookupByLibrary.simpleMessage("매출 거래"),
        "saleTransactionQuatationHistory":
            MessageLookupByLibrary.simpleMessage("매출 거래 (견적 판매 내역)"),
        "sales": MessageLookupByLibrary.simpleMessage("매출"),
        "salesList": MessageLookupByLibrary.simpleMessage("판매 목록"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("판매 반품"),
        "salesReturnTemplate":
            MessageLookupByLibrary.simpleMessage("판매 반품 템플릿"),
        "salesTemplate": MessageLookupByLibrary.simpleMessage("판매 템플릿"),
        "save": MessageLookupByLibrary.simpleMessage("저장"),
        "saveAndPublish": MessageLookupByLibrary.simpleMessage("저장 및 게시"),
        "saveAndPublished": MessageLookupByLibrary.simpleMessage("저장 및 게시"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("변경 사항 저장"),
        "search": MessageLookupByLibrary.simpleMessage("검색......."),
        "searchAnyThing": MessageLookupByLibrary.simpleMessage("무엇이든 검색..."),
        "searchByInvoice": MessageLookupByLibrary.simpleMessage("송장으로 검색..."),
        "searchByInvoiceOrName":
            MessageLookupByLibrary.simpleMessage("송장 또는 이름으로 검색"),
        "searchByName": MessageLookupByLibrary.simpleMessage("이름으로 검색"),
        "searchByNameOrPhone":
            MessageLookupByLibrary.simpleMessage("이름 또는 전화로 검색..."),
        "searchProductNameOrCode":
            MessageLookupByLibrary.simpleMessage("제품 이름 또는 코드를 검색하세요"),
        "searchSerialNumber": MessageLookupByLibrary.simpleMessage("일련 번호 검색"),
        "searchWithName": MessageLookupByLibrary.simpleMessage("이름으로 검색"),
        "searchWithProductName":
            MessageLookupByLibrary.simpleMessage("제품 이름으로 검색"),
        "selectACategory": MessageLookupByLibrary.simpleMessage("카테고리 선택"),
        "selectAInvoice": MessageLookupByLibrary.simpleMessage("송장 선택"),
        "selectAProductForReturn":
            MessageLookupByLibrary.simpleMessage("반품할 제품을 선택하세요"),
        "selectCategory": MessageLookupByLibrary.simpleMessage("카테고리 선택"),
        "selectExpenseCategory":
            MessageLookupByLibrary.simpleMessage("비용 카테고리 선택"),
        "selectParties": MessageLookupByLibrary.simpleMessage("당사자 선택"),
        "selectPractise": MessageLookupByLibrary.simpleMessage("연습을 선택하세요"),
        "selectProduct": MessageLookupByLibrary.simpleMessage("제품을 선택하세요"),
        "selectProductBrand": MessageLookupByLibrary.simpleMessage("상품 브랜드 선택"),
        "selectSerialNumber": MessageLookupByLibrary.simpleMessage("일련 번호 선택"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("상점 카테고리 선택"),
        "selectTax": MessageLookupByLibrary.simpleMessage("세금 선택"),
        "selectTaxType": MessageLookupByLibrary.simpleMessage("세금 유형 선택"),
        "selectUnitType": MessageLookupByLibrary.simpleMessage("단위 유형을 선택하세요"),
        "selectVariations": MessageLookupByLibrary.simpleMessage("변경 사항 선택:"),
        "selectWarrantyTime": MessageLookupByLibrary.simpleMessage("보증 기간 선택"),
        "selectYourLanguage": MessageLookupByLibrary.simpleMessage("언어 선택"),
        "seller": MessageLookupByLibrary.simpleMessage("판매자"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("메시지 보내기"),
        "sendingResetEmail":
            MessageLookupByLibrary.simpleMessage("비밀번호 재설정 이메일 전송 중"),
        "serial": MessageLookupByLibrary.simpleMessage("일련번호"),
        "serialNumber": MessageLookupByLibrary.simpleMessage("일련 번호"),
        "serialNumberAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("일련 번호가 이미 추가되었습니다"),
        "serialNumbers": MessageLookupByLibrary.simpleMessage("일련 번호"),
        "serviceCharge": MessageLookupByLibrary.simpleMessage("서비스 요금"),
        "setting": MessageLookupByLibrary.simpleMessage("설정"),
        "share": MessageLookupByLibrary.simpleMessage("공유"),
        "shipingOrOther": MessageLookupByLibrary.simpleMessage("배송/기타"),
        "shopName": MessageLookupByLibrary.simpleMessage("상점 이름"),
        "shopOpeningBalance": MessageLookupByLibrary.simpleMessage("매장 개장 잔고"),
        "shortcodes": MessageLookupByLibrary.simpleMessage("단축 코드"),
        "show": MessageLookupByLibrary.simpleMessage(">보여주기"),
        "showLogoInInvoice": MessageLookupByLibrary.simpleMessage("송장에 로고 표시?"),
        "showing": MessageLookupByLibrary.simpleMessage("표시 중"),
        "shpingOrServices": MessageLookupByLibrary.simpleMessage("배송/서비스"),
        "signUpPanel": MessageLookupByLibrary.simpleMessage("가입 패널"),
        "siteName": MessageLookupByLibrary.simpleMessage("사이트 이름"),
        "size": MessageLookupByLibrary.simpleMessage("크기"),
        "snacks": MessageLookupByLibrary.simpleMessage("스낵"),
        "statistic": MessageLookupByLibrary.simpleMessage("통계"),
        "status": MessageLookupByLibrary.simpleMessage("상태"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "추가 비용 없이 최첨단 기술 개발 최전선에 머물러 있습니다. 우리의 Pos Saas POS 무제한 업그레이드는 항상 최신 도구와 기능을 손끝에 갖고 있도록 보장하여 비즈니스가 최첨단 유지됩니다."),
        "stayAtTheForeFrontOfTechnological": MessageLookupByLibrary.simpleMessage(
            "추가 비용 없이 기술 발전의 최전선에 머물러 있습니다. 우리의 Pos Sass POS 무제한 업그레이드는 항상 최신 도구와 기능을 손끝에 갖고 있도록 보장하여 비즈니스가 최전선에 남는다."),
        "stock": MessageLookupByLibrary.simpleMessage("재고"),
        "stockInventory": MessageLookupByLibrary.simpleMessage("재고 목록"),
        "stockIsMoreThenLowLimit":
            MessageLookupByLibrary.simpleMessage("재고가 낮은 한도를 초과했습니다"),
        "stockQuantity": MessageLookupByLibrary.simpleMessage("재고 수량"),
        "stockReport": MessageLookupByLibrary.simpleMessage("재고 보고서"),
        "stockValue": MessageLookupByLibrary.simpleMessage("재고 가치"),
        "stockValues": MessageLookupByLibrary.simpleMessage("재고 가치"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("하위 세금"),
        "subTotal": MessageLookupByLibrary.simpleMessage("소계"),
        "subciption": MessageLookupByLibrary.simpleMessage("구독"),
        "submit": MessageLookupByLibrary.simpleMessage("제출"),
        "successfull": MessageLookupByLibrary.simpleMessage("성공"),
        "successfullyAdded":
            MessageLookupByLibrary.simpleMessage("성공적으로 추가되었습니다"),
        "successfullyDeleted":
            MessageLookupByLibrary.simpleMessage("성공적으로 삭제되었습니다"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("성공적으로 완료되었습니다"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("성공적으로 업데이트되었습니다"),
        "supplier": MessageLookupByLibrary.simpleMessage("공급업체"),
        "supplierDue": MessageLookupByLibrary.simpleMessage("공급업체 미결제금액"),
        "supplierInvoice": MessageLookupByLibrary.simpleMessage("공급업체 송장"),
        "supplierList": MessageLookupByLibrary.simpleMessage("공급업체 목록"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT 코드"),
        "tSale": MessageLookupByLibrary.simpleMessage("총 판매"),
        "takeADriveLisense": MessageLookupByLibrary.simpleMessage(
            "운전 면허증, 주민등록증 또는 여권 사진을 찍으세요"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("세금 그룹"),
        "taxRate": MessageLookupByLibrary.simpleMessage("세율"),
        "taxRatesManageYourTaxRates":
            MessageLookupByLibrary.simpleMessage("세율 - 세율 관리"),
        "taxType": MessageLookupByLibrary.simpleMessage("세금 유형"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("사용 조건"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage("해당 이메일에 대한 계정이 이미 존재합니다"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "이름이 모든 것을 말합니다. Pos Saas POS 무제한으로 사용량 제한이 없습니다. 소수 거래를 처리하든 고객 폭주를 경험하든 한계에 제약받지 않고 자신감을 가지고 작동할 수 있습니다."),
        "thePasswordProvidedIsTooWeak":
            MessageLookupByLibrary.simpleMessage("제공된 비밀번호가 너무 약합니다"),
        "theSaleWillBeDeletedAndAllTheDataWillBeDeletedAboutThisPurchaseAreYouSureToDeleteThis":
            MessageLookupByLibrary.simpleMessage(
                "이 판매는 삭제되며 해당 구매에 대한 모든 데이터가 삭제됩니다. 삭제하시겠습니까?"),
        "theSaleWillBeDeletedAndAllTheDataWillBeDeletedAboutThisSaleAreYouSureToDeleteThis":
            MessageLookupByLibrary.simpleMessage(
                "판매가 삭제되며 이 판매에 대한 모든 데이터가 삭제됩니다. 정말로 삭제하시겠습니까?"),
        "thisCategoryCannotBeDeleted":
            MessageLookupByLibrary.simpleMessage("이 카테고리는 삭제할 수 없습니다"),
        "thisCustmerHasNoDue":
            MessageLookupByLibrary.simpleMessage("이 고객은 미결제금이 없습니다."),
        "thisCustomerHavePreviousDue":
            MessageLookupByLibrary.simpleMessage("이 고객은 이전 미납이 있습니다"),
        "thisCustomerHavepreviousDue":
            MessageLookupByLibrary.simpleMessage("이 고객은 이전에 미결제금액이 있습니다"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("이번 달"),
        "thisYear": MessageLookupByLibrary.simpleMessage("이번 해"),
        "to": MessageLookupByLibrary.simpleMessage("에"),
        "topSellingProduct": MessageLookupByLibrary.simpleMessage("최고 판매 제품"),
        "total": MessageLookupByLibrary.simpleMessage("합계"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("총 금액"),
        "totalDiscount": MessageLookupByLibrary.simpleMessage("총 할인"),
        "totalDue": MessageLookupByLibrary.simpleMessage("총 미수금"),
        "totalDues": MessageLookupByLibrary.simpleMessage("총 미결제금액"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("총 지출"),
        "totalIncome": MessageLookupByLibrary.simpleMessage("총 수입"),
        "totalItem": MessageLookupByLibrary.simpleMessage("총 항목"),
        "totalItem2": MessageLookupByLibrary.simpleMessage("총 품목: 2"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("총 손실"),
        "totalPaid": MessageLookupByLibrary.simpleMessage("총 지불"),
        "totalPayable": MessageLookupByLibrary.simpleMessage("총 지불 금액"),
        "totalPaymentOut": MessageLookupByLibrary.simpleMessage("총 지출"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("총 금액"),
        "totalProduct": MessageLookupByLibrary.simpleMessage("총 상품"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("총 이익"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("총 구매"),
        "totalReturnAmount": MessageLookupByLibrary.simpleMessage("총 반품 금액"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("총 반품"),
        "totalSale": MessageLookupByLibrary.simpleMessage("총 매출"),
        "totalSales": MessageLookupByLibrary.simpleMessage("총 매출"),
        "totalValue": MessageLookupByLibrary.simpleMessage("총 가치"),
        "totalVat": MessageLookupByLibrary.simpleMessage("총 부가가치세"),
        "totalpaymentIn": MessageLookupByLibrary.simpleMessage("총 수입"),
        "transaction": MessageLookupByLibrary.simpleMessage("거래"),
        "transactionId": MessageLookupByLibrary.simpleMessage("거래 ID"),
        "transactionReport": MessageLookupByLibrary.simpleMessage("거래 보고서"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("다시 시도"),
        "type": MessageLookupByLibrary.simpleMessage("유형"),
        "unPaid": MessageLookupByLibrary.simpleMessage("미지불"),
        "unit": MessageLookupByLibrary.simpleMessage("단위"),
        "unitName": MessageLookupByLibrary.simpleMessage("단위 이름"),
        "unitNameIsAlreadyExist":
            MessageLookupByLibrary.simpleMessage("단위 이름이 이미 존재합니다"),
        "unitNameIsRequired":
            MessageLookupByLibrary.simpleMessage("단위 이름이 필요합니다"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("단가"),
        "unlimited": MessageLookupByLibrary.simpleMessage("무제한"),
        "unlimitedInvoice": MessageLookupByLibrary.simpleMessage("무제한 송장"),
        "unlimitedUsage": MessageLookupByLibrary.simpleMessage("무제한 사용"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "우리의 전문 팀이 이끄는 맞춤 교육 세션으로 Pos Saas POS의 최대 잠재력을 끄집어내보세요. 기초부터 고급 기술까지 모든 측면을 활용하여 비즈니스 프로세스를 최적화하도록 보장합니다."),
        "unpaid": MessageLookupByLibrary.simpleMessage("미납"),
        "update": MessageLookupByLibrary.simpleMessage("업데이트"),
        "updateNow": MessageLookupByLibrary.simpleMessage("지금 업데이트"),
        "updateTemplate": MessageLookupByLibrary.simpleMessage("템플릿 업데이트"),
        "updateYourPlanFirst": MessageLookupByLibrary.simpleMessage(
            "먼저 요금제를 업데이트하세요.\n판매 한도가 초과되었습니다."),
        "updateYourPlanFirstAddCustomerLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "먼저 계획을 업데이트하십시오, 고객 추가 한도가 초과되었습니다"),
        "updateYourPlanFirstDueCollectionLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "먼저 계획을 업데이트하십시오, 미납 수집 한도가 초과되었습니다"),
        "updateYourPlanFirstPurchaseLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "먼저 계획을 업데이트하세요\\n구매 한도가 초과되었습니다"),
        "updateYourPlanFirstSaleLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "먼저 계획을 업데이트하세요\\n판매 한도가 초과되었습니다"),
        "updatingTemplate": MessageLookupByLibrary.simpleMessage("템플릿 업데이트 중"),
        "upgradeOnMobileApp":
            MessageLookupByLibrary.simpleMessage("모바일 앱에서 업그레이드"),
        "upload": MessageLookupByLibrary.simpleMessage("업로드"),
        "uploadAImage": MessageLookupByLibrary.simpleMessage("이미지 업로드"),
        "uploadAnExcel": MessageLookupByLibrary.simpleMessage("엑셀 파일 업로드"),
        "uploadAnInvoiceLogo":
            MessageLookupByLibrary.simpleMessage("송장 로고 업로드"),
        "uploadDocument": MessageLookupByLibrary.simpleMessage("문서 업로드"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("업로드 완료"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("파일 업로드"),
        "uploadSuccessful": MessageLookupByLibrary.simpleMessage("업로드 성공"),
        "uploading": MessageLookupByLibrary.simpleMessage("업로드 중"),
        "userName": MessageLookupByLibrary.simpleMessage("사용자 이름"),
        "userRole": MessageLookupByLibrary.simpleMessage("사용자 역할"),
        "userRoleDetails": MessageLookupByLibrary.simpleMessage("사용자 역할 세부사항"),
        "userRoleName": MessageLookupByLibrary.simpleMessage("사용자 역할 이름"),
        "userTitle": MessageLookupByLibrary.simpleMessage("사용자 제목"),
        "userTitleCanBeEmpty":
            MessageLookupByLibrary.simpleMessage("사용자 제목은 비어 있을 수 없습니다"),
        "vatOrgst": MessageLookupByLibrary.simpleMessage("부가가치세/GST"),
        "verifyPhoneNumber": MessageLookupByLibrary.simpleMessage("전화번호 인증"),
        "view": MessageLookupByLibrary.simpleMessage("보기"),
        "viewAll": MessageLookupByLibrary.simpleMessage("모두 보기"),
        "walkInCustomer": MessageLookupByLibrary.simpleMessage("방문 고객"),
        "warehouse": MessageLookupByLibrary.simpleMessage("창고"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("창고가 이미 존재합니다"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("창고 목록"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("창고 이름"),
        "warranty": MessageLookupByLibrary.simpleMessage("보증"),
        "warrantys": MessageLookupByLibrary.simpleMessage("보증"),
        "weNeedToRegisterYourPhone":
            MessageLookupByLibrary.simpleMessage("시작하기 전에 휴대폰을 등록해야 합니다!"),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "우리는 원활한 운영의 중요성을 이해합니다. 그래서 연중무휴 지원팀이 빠른 문의든 포괄적인 문제든 도와 드릴 준비가 되어 있습니다. 언제 어디서나 전화 또는 WhatsApp을 통해 우리와 연락하여 탁월한 고객 서비스를 경험하세요."),
        "welcome": MessageLookupByLibrary.simpleMessage("환영합니다"),
        "whatsappMarketingEnabled":
            MessageLookupByLibrary.simpleMessage("WhatsApp 마케팅 활성화됨"),
        "whatsappMarketingIsNotEnabledInYourCurrentSubscriptionPlan":
            MessageLookupByLibrary.simpleMessage(
                "현재 구독 계획에서 WhatsApp 마케팅이 활성화되지 않았습니다"),
        "whatsappMarketingSMSTemplate":
            MessageLookupByLibrary.simpleMessage("WhatsApp 마케팅 SMS 템플릿"),
        "wholeSaleprice": MessageLookupByLibrary.simpleMessage("도매 가격"),
        "wholeSeller": MessageLookupByLibrary.simpleMessage("도매업자"),
        "wholesale": MessageLookupByLibrary.simpleMessage("도매"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("도매상"),
        "wight": MessageLookupByLibrary.simpleMessage("무게"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("만료 예정일"),
        "wrongPassword": MessageLookupByLibrary.simpleMessage("잘못된 비밀번호"),
        "wrongPasswordProvidedForThatUser":
            MessageLookupByLibrary.simpleMessage(
                "해당 사용자에 대해 잘못된 비밀번호가 제공되었습니다"),
        "yearly": MessageLookupByLibrary.simpleMessage("연간"),
        "yesDeleteForever": MessageLookupByLibrary.simpleMessage("예, 영구적으로 삭제"),
        "yesReturn": MessageLookupByLibrary.simpleMessage("예, 반품"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("유효한 사용자가 아닙니다"),
        "youDonNotHavePermissionToAddCustomer":
            MessageLookupByLibrary.simpleMessage("고객 추가 권한이 없습니다"),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("권한을 부여해야 합니다"),
        "youHaveToRELOGINOnYourAccount":
            MessageLookupByLibrary.simpleMessage("계정에 다시 로그인해야 합니다"),
        "youHaveToRelogin":
            MessageLookupByLibrary.simpleMessage("계정을 다시 로그인해야 합니다."),
        "youNeedToIdentityVerifySms":
            MessageLookupByLibrary.simpleMessage("메시지를 구매하기 전에 신원 인증이 필요합니다"),
        "yourAllSaleList": MessageLookupByLibrary.simpleMessage("전체 판매 목록"),
        "yourAllSales": MessageLookupByLibrary.simpleMessage("전체 매출"),
        "yourAreUsing": MessageLookupByLibrary.simpleMessage("당신은 사용 중입니다"),
        "yourDueSales": MessageLookupByLibrary.simpleMessage("미결제 매출"),
        "yourNeedToIdentityVerify":
            MessageLookupByLibrary.simpleMessage("메시지를 구매하기 전에 신원 인증이 필요합니다"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("귀하의 패키지"),
        "yourPaymentIsCancelled":
            MessageLookupByLibrary.simpleMessage("결제가 취소되었습니다."),
        "yourPaymentIsSuccessfully":
            MessageLookupByLibrary.simpleMessage("결제가 성공적으로 완료되었습니다."),
        "yourPaymentIscancelled":
            MessageLookupByLibrary.simpleMessage("결제가 취소되었습니다.")
      };
}
