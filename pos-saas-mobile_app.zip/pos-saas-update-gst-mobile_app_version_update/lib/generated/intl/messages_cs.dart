// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a cs locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'cs';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Nastavi"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("Broj GST"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("MRP je obavezan"),
        "OK": MessageLookupByLibrary.simpleMessage("OK"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Br. tel."),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("Br."),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT Kod"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Grickalice"),
        "TAX": MessageLookupByLibrary.simpleMessage("POREZ"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Učitavanje"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("Název uživatele"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Váš balíček vyprší dnes.\n\nProsím, zakupte si ho znovu."),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) Systém je poskytován výhradně za účelem usnadnění transakcí na místech prodeje a souvisejících činností ve vašem podnikání."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) K použití Systému může být vyžadováno vytvoření účtu. Souhlasíte s poskytováním přesných, aktuálních a kompletních informací během procesu registrace a s aktualizací těchto informací, aby zůstaly přesné a kompletní."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("O aplikaci"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("O nama"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Přijetí podmínek"),
        "accountName": MessageLookupByLibrary.simpleMessage("Název účtu"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("Číslo účtu"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Registrace účtu"),
        "acton": MessageLookupByLibrary.simpleMessage("Akcija"),
        "add": MessageLookupByLibrary.simpleMessage("Dodaj"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Přidat značku"),
        "addCategory": MessageLookupByLibrary.simpleMessage("Přidat kategorii"),
        "addContact": MessageLookupByLibrary.simpleMessage("Přidat kontakt"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Přidat zákazníka"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("Přidat doručení"),
        "addDescriptioN": MessageLookupByLibrary.simpleMessage("Dodaj opis"),
        "addDescription":
            MessageLookupByLibrary.simpleMessage("Přidat poznámku"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Dodaj popust"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Přidat ID dokumentu"),
        "addDucument": MessageLookupByLibrary.simpleMessage("Přidat dokument"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Přidat výdaj"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Přidat kategorii výdajů"),
        "addItems": MessageLookupByLibrary.simpleMessage("Přidat položky"),
        "addNew": MessageLookupByLibrary.simpleMessage("Dodaj novo"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Přidat novou adresu"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Přidat nový produkt"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("Dodajte novi porez"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Dodajte novi porez s jednostrukim/višestrukim tipom poreza"),
        "addNote": MessageLookupByLibrary.simpleMessage("Přidat poznámku"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Prvo dodajte proizvod"),
        "addPromoCode": MessageLookupByLibrary.simpleMessage("Dodaj promo kod"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Přidat nákup"),
        "addSales": MessageLookupByLibrary.simpleMessage("Přidat prodeje"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Přidáno úspěšně"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Přidat jednotku"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Přidat uživatelskou roli"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Uspješno dodano"),
        "addedToCart": MessageLookupByLibrary.simpleMessage("Dodano u korpu"),
        "address": MessageLookupByLibrary.simpleMessage("Adresa"),
        "admin": MessageLookupByLibrary.simpleMessage("Admin"),
        "all": MessageLookupByLibrary.simpleMessage("Vše"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("Všechna obchodní řešení"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("Već dodano"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Već postoji"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Již máte účet"),
        "amount": MessageLookupByLibrary.simpleMessage("Částka"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "Email je poslan\\nProvjerite svoj inbox"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Podpora aplikací pro Android a iOS"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Primjenjivi porez"),
        "apply": MessageLookupByLibrary.simpleMessage("Použít"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Jeste li sigurni da želite obrisati ovu fakturu"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Jeste li sigurni da želite obrisati ovu prodaju"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Jeste li sigurni da želite izbrisati ovog korisnika"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Da li ste sigurni da želite obrisati ovaj porez"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Da li ste sigurni da želite obrisati ovu poresku grupu"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Da li želite obrisati ovo skladište"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Jste si jistí, že chcete tohoto uživatele smazat?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Ovlašteni potpis"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Jste zodpovědní za udržení důvěrnosti vašeho účtu a hesla a omezení přístupu k vašemu účtu. Přijímáte odpovědnost za všechny aktivity, které probíhají pod vaším účtem."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Musíte být nejméně 18 let starý nebo dosáhnout zákonného věku pro použití Systému ve vaší jurisdikci."),
        "backSide": MessageLookupByLibrary.simpleMessage("Zadní strana"),
        "backToHome": MessageLookupByLibrary.simpleMessage("Zpět domů"),
        "balance": MessageLookupByLibrary.simpleMessage("Zůstatek"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladéš"),
        "bank": MessageLookupByLibrary.simpleMessage("Banka"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Valuta bankovnog računa"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Měna bankovního účtu"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Bankovní informace"),
        "bankName": MessageLookupByLibrary.simpleMessage("Název banky"),
        "bankTransfer":
            MessageLookupByLibrary.simpleMessage("Bankovni transfer"),
        "barcodeFound": MessageLookupByLibrary.simpleMessage("Barkod pronađen"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Račun / Faktura"),
        "billTo": MessageLookupByLibrary.simpleMessage("Fakturovat"),
        "branchName": MessageLookupByLibrary.simpleMessage("Název pobočky"),
        "brand": MessageLookupByLibrary.simpleMessage("Značka"),
        "brandName": MessageLookupByLibrary.simpleMessage("Název značky"),
        "bulkUpload":
            MessageLookupByLibrary.simpleMessage("Masovno učitavanje"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Kategorie podnikání"),
        "buy": MessageLookupByLibrary.simpleMessage("Koupit"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Koupit prémiový plán"),
        "buySms": MessageLookupByLibrary.simpleMessage("Koupit SMS"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Přístupem nebo použitím Systému bodu prodeje (POS) (\"Systém\") poskytovaného společností [Název vaší společnosti] (\"Společnost\") souhlasíte s tím, že budete vázáni těmito Podmínkami použití. Pokud s těmito Podmínkami použití nesouhlasíte, nepoužívejte Systém."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Jste zodpovědní za zajistění toho, aby váš přístup a používání Systému bylo v souladu se všemi příslušnými zákony a předpisy."),
        "cacel": MessageLookupByLibrary.simpleMessage("Zrušit"),
        "call": MessageLookupByLibrary.simpleMessage("Volat"),
        "callForEmergencySupport":
            MessageLookupByLibrary.simpleMessage("Pozovite za hitnu podršku"),
        "camera": MessageLookupByLibrary.simpleMessage("Fotoaparát"),
        "cancel": MessageLookupByLibrary.simpleMessage("Otkaži"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Otkaži sve proizvode"),
        "capacity": MessageLookupByLibrary.simpleMessage("Kapacita"),
        "card": MessageLookupByLibrary.simpleMessage("Kartica"),
        "cash": MessageLookupByLibrary.simpleMessage("Hotovost"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Kategorie"),
        "category": MessageLookupByLibrary.simpleMessage("Kategorie"),
        "categoryName":
            MessageLookupByLibrary.simpleMessage("Naziv kategorije"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "Naziv kategorije već postoji"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("Název kategorie"),
        "change": MessageLookupByLibrary.simpleMessage("Změnit?"),
        "changePassword": MessageLookupByLibrary.simpleMessage("Změnit heslo"),
        "checkEmail":
            MessageLookupByLibrary.simpleMessage("Zkontrolovat e-mail"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Vyberte zákazníka"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Vyberte dodavatele"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Vyberte si své funkce"),
        "clarence": MessageLookupByLibrary.simpleMessage("Clarence"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Klikněte pro spojení"),
        "close": MessageLookupByLibrary.simpleMessage("Zavřít"),
        "color": MessageLookupByLibrary.simpleMessage("Barva"),
        "combinationOfMultipleTaxes":
            MessageLookupByLibrary.simpleMessage("(Kombinacija više poreza)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Uskoro"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Adresa společnosti"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Název společnosti a obchodu"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("Ime kompanije i poslovanja"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Dokončit transakci"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Potvrzení hesla"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Potvrdite povrat"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Gratulujeme"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Kontaktujte nás"),
        "continu": MessageLookupByLibrary.simpleMessage("Pokračovat"),
        "country": MessageLookupByLibrary.simpleMessage("Země"),
        "create": MessageLookupByLibrary.simpleMessage("Vytvořit"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Vytvořte si zdarma účet"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Kreirano i sačuvano"),
        "currency": MessageLookupByLibrary.simpleMessage("Měna"),
        "currentStock":
            MessageLookupByLibrary.simpleMessage("Aktuální stav zásob"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("Vlastní značkování faktur"),
        "customer": MessageLookupByLibrary.simpleMessage("Zákazník"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Detaily zákazníka"),
        "customerGST": MessageLookupByLibrary.simpleMessage("Kupčev GST"),
        "customerName": MessageLookupByLibrary.simpleMessage("Jméno zákazníka"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Denní transakce"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Přehled Dashboardu"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Podaci uspješno sačuvani"),
        "date": MessageLookupByLibrary.simpleMessage("Datum"),
        "day": MessageLookupByLibrary.simpleMessage("Dan"),
        "dealer": MessageLookupByLibrary.simpleMessage("Distributor"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("Prodejní cena"),
        "defaultVATPercentage": MessageLookupByLibrary.simpleMessage(
            "Podrazumijevani PDV postotak"),
        "delete": MessageLookupByLibrary.simpleMessage("Smazat"),
        "deleting": MessageLookupByLibrary.simpleMessage("Brisanje"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Dodací adresa"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Adrese za dostavu"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Dodací poplatek"),
        "describtion": MessageLookupByLibrary.simpleMessage("Popis"),
        "description": MessageLookupByLibrary.simpleMessage("Opis"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Opis ne može biti prazan"),
        "details": MessageLookupByLibrary.simpleMessage("Detalji"),
        "discount": MessageLookupByLibrary.simpleMessage("Sleva"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Nerušit"),
        "done": MessageLookupByLibrary.simpleMessage("Završeno"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Preuzmi Excel format"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Uspješno preuzet u folder za preuzimanje"),
        "due": MessageLookupByLibrary.simpleMessage("Dluh"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Částka dluhu: "),
        "dueCollection": MessageLookupByLibrary.simpleMessage("Inkaso dluhů"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("Zprávy o splatnosti inkasa"),
        "dueList": MessageLookupByLibrary.simpleMessage("Seznam dluhů"),
        "dueReports":
            MessageLookupByLibrary.simpleMessage("Zprávy o splatnosti"),
        "duration": MessageLookupByLibrary.simpleMessage("Trajanje"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Trajanje: Od"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "Snadno použitelné mobilní POS"),
        "edit": MessageLookupByLibrary.simpleMessage("Upravit"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Upravit nákupní fakturu"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Upravit prodejní fakturu"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Upravit sociální média"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Uspješno uređeno"),
        "editTax": MessageLookupByLibrary.simpleMessage("Uredi porez"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Uredi poresku grupu"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("Uredi skladište"),
        "email": MessageLookupByLibrary.simpleMessage("E-mail"),
        "emailAddress":
            MessageLookupByLibrary.simpleMessage("E-mailová adresa"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Email ne može biti prazan"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "E-pošta je poslana! Provjerite pristiglu poštu"),
        "endDate": MessageLookupByLibrary.simpleMessage("Konečné datum"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Unesite važeći iznos"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Unesite ispravan popust"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Unesite važeći broj telefona"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Unesite ispravnu cijenu"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("Unesite ispravnu količinu"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("Zadejte adresu"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("Zadejte částku."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Zadejte název značky"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Zadejte kapacitu"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Zadejte název kategorie"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Zadejte barvu"),
        "enterCustomerGstNumber":
            MessageLookupByLibrary.simpleMessage("Unesite GST broj kupca"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Zadejte prodejní cenu"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Unesite opis"),
        "enterDiscount": MessageLookupByLibrary.simpleMessage("Zadejte slevu."),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Zadejte datum výdaje"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Zadejte plnou adresu"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Zadejte číslo faktury"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Unesite količinu za upozorenje na nisku zalihu"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Zadejte výrobce"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("Zadejte obsah zprávy"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "Zadejte MRP / Maloobchodní cenu"),
        "enterName": MessageLookupByLibrary.simpleMessage("Zadejte jméno"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Zadejte poznámku"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Zadejte název strany"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Zadejte telefonní číslo"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Zadejte kód produktu nebo naskenujte"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Zadejte název produktu"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Zadejte nákupní cenu."),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("Zadejte referenční číslo"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Zadejte velikost"),
        "enterStocks":
            MessageLookupByLibrary.simpleMessage("Zadejte skladové zásoby."),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Unesite poresku stopu"),
        "enterTransactionId": MessageLookupByLibrary.simpleMessage(
            "Zadejte identifikátor transakce"),
        "enterType": MessageLookupByLibrary.simpleMessage("Zadejte typ"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("Zadejte název uživatele"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Unesite važeći iznos"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Unesite naziv skladišta"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Zadejte váhu"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Zadejte velkoobchodní cenu"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("Zde zadejte popis"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "Zadejte svou e-mailovou adresu"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "Zadejte název vaší zpětné vazby"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Unesite svoj GST broj"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("Zadejte své mobilní číslo"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Zadejte své jméno"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("Zadejte své telefonní číslo"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Zadejte své heslo"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Zadejte své telefonní číslo"),
        "enterYourTransactionId":
            MessageLookupByLibrary.simpleMessage("Zadejte ID vaší transakce"),
        "error": MessageLookupByLibrary.simpleMessage("Greška"),
        "excTax": MessageLookupByLibrary.simpleMessage("Isključen porez"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("Excel Uploader"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Isključeno"),
        "expense": MessageLookupByLibrary.simpleMessage("Výdaje"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Kategorie výdajů"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Datum výdaje"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Výdaj pro"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Zpráva o výdajích"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Datum isteka"),
        "expired": MessageLookupByLibrary.simpleMessage("Isteklo"),
        "expiring": MessageLookupByLibrary.simpleMessage("Ističe"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Neuspješno sa greškom"),
        "fashion": MessageLookupByLibrary.simpleMessage("Móda"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Funkce jsou důležitou součástí, která činí Pos Saas odlišným od tradičních řešení."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Zpětná vazba"),
        "firstName": MessageLookupByLibrary.simpleMessage("Křestní jméno"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Pratite nas na\\nFacebook-u"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Pratite nas na\\nTwitter-u"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Přední strana"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("Pro neomezené použití"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Zapomenuté heslo"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Zapomenuté heslo?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Od data"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("Zdarma záloha dat"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "Zdarma doživotní aktualizace"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Zdarma balíček"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Zdarma plán"),
        "from": MessageLookupByLibrary.simpleMessage("Od"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Potpuno plaćeno"),
        "gallary": MessageLookupByLibrary.simpleMessage("Galerie"),
        "generatingPDF":
            MessageLookupByLibrary.simpleMessage("Generisanje PDF-a"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Získat kód OTP"),
        "govermentId":
            MessageLookupByLibrary.simpleMessage("Identifikační doklad"),
        "guest": MessageLookupByLibrary.simpleMessage("Host"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Nemáte účet?"),
        "history": MessageLookupByLibrary.simpleMessage("Historie"),
        "home": MessageLookupByLibrary.simpleMessage("Domů"),
        "howWeProtectYourInformation":
            MessageLookupByLibrary.simpleMessage("Jak chráníme vaše informace"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Jak používáme vaše informace"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Ověření totožnosti"),
        "image": MessageLookupByLibrary.simpleMessage("Obrázek"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("InHouse se ne može obrisati"),
        "inHouseCantBeEdited": MessageLookupByLibrary.simpleMessage(
            "InHouse se ne može uređivati"),
        "inWord": MessageLookupByLibrary.simpleMessage("U riječima"),
        "incTax": MessageLookupByLibrary.simpleMessage("Uključen porez"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Uključeno"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("Povećaj zalihu"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Nástroj"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Č. faktury"),
        "invoice": MessageLookupByLibrary.simpleMessage("Faktura"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("Číslo faktury"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Nastavení faktury"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Pregled fakture"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Položka přidána"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("KYC Verifikace"),
        "language": MessageLookupByLibrary.simpleMessage("Jazyk"),
        "lastName": MessageLookupByLibrary.simpleMessage("Příjmení"),
        "ledger": MessageLookupByLibrary.simpleMessage("Účetnictví"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Doživotní\nkoupě"),
        "link": MessageLookupByLibrary.simpleMessage("Odkaz"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Podrška putem chat-a uživo"),
        "loading": MessageLookupByLibrary.simpleMessage("Učitavanje"),
        "logIn": MessageLookupByLibrary.simpleMessage("Přihlásit se"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Odhlásit se"),
        "logOut": MessageLookupByLibrary.simpleMessage("Odjava"),
        "login": MessageLookupByLibrary.simpleMessage("Přihlásit se"),
        "logo": MessageLookupByLibrary.simpleMessage("Logo"),
        "loss": MessageLookupByLibrary.simpleMessage("Ztráta"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Ztráta/Zisk"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Podrobnosti o ztrátě/zisku"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Izvještaj o gubicima/dobiti"),
        "lossProfitReports": MessageLookupByLibrary.simpleMessage(
            "Izvještaji o gubicima/dobiti"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Upozorenje na nisku zalihu"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Udělejte trvalý dojem na své zákazníky s značkovými fakturami. Naše Unlimited Upgrade nabízí jedinečnou výhodu přizpůsobení faktur, přidává profesionální dotek, který posiluje vaši značku a podporuje věrnost zákazníků."),
        "manageYourBussinessWith": MessageLookupByLibrary.simpleMessage(
            "Spravujte svůj podnik s pomocí"),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Datum proizvodnje"),
        "margin": MessageLookupByLibrary.simpleMessage("Marža"),
        "masterCard": MessageLookupByLibrary.simpleMessage("MasterCard"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Výrobce"),
        "message": MessageLookupByLibrary.simpleMessage("Zpráva"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Historie zpráv"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Pos Saas aplikace je zdarma a snadno použitelná. Ve skutečnosti se jedná o jednu z nejlepších POS systémů na světě."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas je kompletní obchodní řešení s funkcemi pro sklad, účty, prodej, výdaje a ztráty / zisky."),
        "mobile": MessageLookupByLibrary.simpleMessage("Mobilni"),
        "mobilePayment":
            MessageLookupByLibrary.simpleMessage("Mobilno plaćanje"),
        "monthly": MessageLookupByLibrary.simpleMessage("Měsíční"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("Více informací"),
        "name": MessageLookupByLibrary.simpleMessage("Zadejte své jméno."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Ime već postoji"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("Ime ne može biti prazno"),
        "next": MessageLookupByLibrary.simpleMessage("Další"),
        "noConnection": MessageLookupByLibrary.simpleMessage("Žádné připojení"),
        "noData": MessageLookupByLibrary.simpleMessage("Žádná data"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Žádná dostupná data"),
        "noDataFound": MessageLookupByLibrary.simpleMessage("Nema podataka"),
        "noHistoryFound": MessageLookupByLibrary.simpleMessage(
            "Nebyla nalezena žádná historie!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Nije pronađen proizvod"),
        "noSubTaxSelected": MessageLookupByLibrary.simpleMessage(
            "Nijedan pod-porez nije odabran"),
        "noTransactionFound": MessageLookupByLibrary.simpleMessage(
            "Nebyla nalezena žádná transakce!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Pro tuto e-mailovou adresu nebyl nalezen žádný uživatel."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "Nenalezena žádná uživatelská role"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Niste aktivan korisnik"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Nije navedeno"),
        "note": MessageLookupByLibrary.simpleMessage("Poznámka"),
        "notes": MessageLookupByLibrary.simpleMessage("Bilješke"),
        "notification": MessageLookupByLibrary.simpleMessage("Oznámení"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP poslan na"),
        "office": MessageLookupByLibrary.simpleMessage("Ured"),
        "ok": MessageLookupByLibrary.simpleMessage("Ok"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "Pokladna obsahující velké množství funkcí, včetně sledování prodejů a správy skladu."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Tento systém vám pomáhá zlepšit vaše operace pro vaše zákazníky."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Náš systém pro pokladny by měl automaticky zjednodušit každodenní provoz a usnadnit jeho ovládání."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("Počáteční zůstatek"),
        "order": MessageLookupByLibrary.simpleMessage("Objednávky"),
        "other": MessageLookupByLibrary.simpleMessage("Ostalo"),
        "otp": MessageLookupByLibrary.simpleMessage("Zavřít"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Nema na zalihi"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Balení"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Funkce balíčku"),
        "paid": MessageLookupByLibrary.simpleMessage("Zaplaceno"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Zaplacená částka"),
        "parties": MessageLookupByLibrary.simpleMessage("Strany"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Seznam stran"),
        "partyGST": MessageLookupByLibrary.simpleMessage("Strana GST"),
        "partyName": MessageLookupByLibrary.simpleMessage("Název strany"),
        "password": MessageLookupByLibrary.simpleMessage("Heslo"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Lozinka i potvrda lozinke se ne podudaraju"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Lozinka ne može biti prazna"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("Lozinka se ne poklapa"),
        "payCash": MessageLookupByLibrary.simpleMessage("Zaplacení hotově"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("Zaplatit pomocí bkash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Zaplatit pomocí Paypal"),
        "payeeName": MessageLookupByLibrary.simpleMessage("Jméno příjemce"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("Číslo příjemce"),
        "payment": MessageLookupByLibrary.simpleMessage("Platba"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("Částka platby"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Platba dokončena"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Instrukce k platbě:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("Način plaćanja"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Typ platby"),
        "pdfView": MessageLookupByLibrary.simpleMessage("PDF pregled"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Lični podaci"),
        "phone": MessageLookupByLibrary.simpleMessage("Telefon"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Telefonní číslo"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Broj telefona već u upotrebi"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("Broj telefona nije važeći"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("Broj telefona je obavezan"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("Izaberi i učitaj fajl"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("Vybrat konečné datum"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Vybrat počáteční datum"),
        "plan": MessageLookupByLibrary.simpleMessage("Plan"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("Molimo dodajte količinu"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Zkontrolujte své připojení k internetu"),
        "pleaseConnectThePrinterFirst":
            MessageLookupByLibrary.simpleMessage("Prvo povežite štampač"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Prosím, připojte váš bluetooth tiskárnu"),
        "pleaseEnterABiggerPassword":
            MessageLookupByLibrary.simpleMessage("Molimo unesite dužu lozinku"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Prosím, zadejte potvrzení hesla"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("Zadejte prosím heslo"),
        "pleaseEnterAValidEmail":
            MessageLookupByLibrary.simpleMessage("Molimo unesite važeći email"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Molimo unesite ime"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("Unesite lozinku"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Zadejte prosím svou e-mailovou adresu níže, abyste obdrželi odkaz na obnovení hesla."),
        "pleaseEnterTransactionNumber":
            MessageLookupByLibrary.simpleMessage("Unesite broj transakcije"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("Molimo unesite iznos"),
        "pleaseSelectACategoryFirst":
            MessageLookupByLibrary.simpleMessage("Prvo izaberite kategoriju"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("Molimo odaberite plan"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Molimo izaberite poslovnu kategoriju"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Molimo koristite ispravan kod za kupovinu kako biste koristili aplikaciju"),
        "powerdedByMobiPos": MessageLookupByLibrary.simpleMessage(
            "Vytvořeno společností Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Pokreće"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Prémiová zákaznická podpora"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Prémiový plán"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Předchozí platby"),
        "price": MessageLookupByLibrary.simpleMessage("Cena"),
        "print": MessageLookupByLibrary.simpleMessage("Tisk"),
        "printingOption": MessageLookupByLibrary.simpleMessage("Možnost tisku"),
        "privacyPolicy": MessageLookupByLibrary.simpleMessage(
            "Zásady ochrany osobních údajů"),
        "product": MessageLookupByLibrary.simpleMessage("Produkt"),
        "productCode": MessageLookupByLibrary.simpleMessage("Kód produktu"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("Šifra proizvoda je obavezna"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Šifra proizvoda / Naziv"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Opis proizvoda"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Detalji proizvoda"),
        "productList": MessageLookupByLibrary.simpleMessage("Seznam produktů"),
        "productName": MessageLookupByLibrary.simpleMessage("Název produktu"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Naziv proizvoda već postoji u ovom skladištu"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Naziv proizvoda je već dodan"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("Naziv proizvoda je obavezan"),
        "products": MessageLookupByLibrary.simpleMessage("Proizvodi"),
        "profile": MessageLookupByLibrary.simpleMessage("Profil"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("Úprava profilu"),
        "profit": MessageLookupByLibrary.simpleMessage("Zisk"),
        "promo": MessageLookupByLibrary.simpleMessage("promo"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Slevový kód"),
        "purchase": MessageLookupByLibrary.simpleMessage("Nákup"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("Oznámení o nákupu"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Nákup potvrzen"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Podrobnosti o nákupu"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Faktura kupovine"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("Seznam nákupů"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Kupite sada"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Koupit prémiový plán"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("Nákupní cena"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("Nabavna cijena je obavezna"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("Zpráva o nákupu"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Zprávy o nákupu"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Zprávy o nákupu"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("Povrat kupovine"),
        "purchaseReturnReport": MessageLookupByLibrary.simpleMessage(
            "Izvještaj o povratu kupovine"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Kupovna tranzicija"),
        "qty": MessageLookupByLibrary.simpleMessage("Množství"),
        "quantity": MessageLookupByLibrary.simpleMessage("Množství"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Nedávné transakce"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("Byl obdržen PIN"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Referenční číslo"),
        "register": MessageLookupByLibrary.simpleMessage("Registrovat se"),
        "registering": MessageLookupByLibrary.simpleMessage("Registracija"),
        "remainingDue":
            MessageLookupByLibrary.simpleMessage("Zbývající dlužná částka"),
        "remove": MessageLookupByLibrary.simpleMessage("Ukloni"),
        "reports": MessageLookupByLibrary.simpleMessage("Zprávy"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Zahtjev je poslan"),
        "resendCode": MessageLookupByLibrary.simpleMessage("Znovu odeslat kód"),
        "resendOtp":
            MessageLookupByLibrary.simpleMessage("Znovu odeslat kód OTP: "),
        "retailer": MessageLookupByLibrary.simpleMessage("Malý prodejce"),
        "retur": MessageLookupByLibrary.simpleMessage("Vrácení"),
        "returN": MessageLookupByLibrary.simpleMessage("Povratak"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("Vrácení částky"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("Vrácení částky"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("Količina povrata"),
        "revenue": MessageLookupByLibrary.simpleMessage("Příjmy"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Snadno ochraňujte data svého podnikání. Naše Pos Saas POS Unlimited Upgrade zahrnuje bezplatnou zálohu dat, což zajišťuje ochranu vašich cenných informací před neočekávanými událostmi. Zaměřte se na to, co je skutečně důležité - růst vašeho podnikání."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Iznos prodaje"),
        "saleDetails":
            MessageLookupByLibrary.simpleMessage("Podrobnosti o prodeji"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Prodejní cena"),
        "saleReports": MessageLookupByLibrary.simpleMessage("Zprávy o prodeji"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Zprávy o prodeji"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("Povrat prodaje"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Izvještaj o povratu prodaje"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("Postavke prodaje"),
        "sales": MessageLookupByLibrary.simpleMessage("Prodej"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("Zprávy o prodeji a nákupu"),
        "salesList": MessageLookupByLibrary.simpleMessage("Seznam prodejů"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("Povrat prodaje"),
        "save": MessageLookupByLibrary.simpleMessage("Uložit"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Uložit a publikovat"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("Uložit změny"),
        "saving": MessageLookupByLibrary.simpleMessage("Spremanje"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("Skenirajte QR kod proizvoda"),
        "search": MessageLookupByLibrary.simpleMessage("Hledat"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Pretražite po šifri ili nazivu proizvoda"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("Zobrazit všechny promo kódy"),
        "select": MessageLookupByLibrary.simpleMessage("Vybrat"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Odaberite proizvod za povrat"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Izaberite brend"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Izaberite kategoriju"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Vybrat kontakty"),
        "selectProductCategory": MessageLookupByLibrary.simpleMessage(
            "Izaberite kategoriju proizvoda"),
        "selectShopCategory": MessageLookupByLibrary.simpleMessage(
            "Izaberite kategoriju prodavnice"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Izaberite porez"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Izaberite tip poreza"),
        "selectUnit":
            MessageLookupByLibrary.simpleMessage("Izaberite jedinicu"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Vybrat variantu: "),
        "seller": MessageLookupByLibrary.simpleMessage("Prodavač"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Prodaje"),
        "send": MessageLookupByLibrary.simpleMessage("Odeslat"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("Odeslat e-mail"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Odeslat zprávu"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("Odeslat odkaz na obnovení"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Odeslat SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Poslat SMS?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Pošalji WhatsApp poruku"),
        "sendYOurEmail": MessageLookupByLibrary.simpleMessage(
            "Odeslat vaši e-mailovou adresu"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage("Slanje e-pošte"),
        "sendingMessage": MessageLookupByLibrary.simpleMessage("Slanje poruke"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Usluga / Dostava"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Nastavte si svůj profil"),
        "setting": MessageLookupByLibrary.simpleMessage("Nastavení"),
        "share": MessageLookupByLibrary.simpleMessage("Sdílet"),
        "shopGST": MessageLookupByLibrary.simpleMessage("Shop GST"),
        "signIn": MessageLookupByLibrary.simpleMessage("Prijavi se"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("Prijavi se putem emaila"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Potpis kupca"),
        "size": MessageLookupByLibrary.simpleMessage("Velikost"),
        "skip": MessageLookupByLibrary.simpleMessage("Přeskočit"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Sociální marketing"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Nažalost, nemate dozvolu za pristup ovoj usluzi"),
        "startDate": MessageLookupByLibrary.simpleMessage("Počáteční datum"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Začít nový prodej"),
        "startTypingToSearch":
            MessageLookupByLibrary.simpleMessage("Začněte psát pro hledání"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Zůstaňte v čele technologického pokroku bez dalších nákladů. Naše Pos Saas POS Unlimited Upgrade zajistí, že budete mít vždy nejnovější nástroje a funkce na dosah ruky, což zaručuje, že vaše podnikání zůstane na ostří technologie."),
        "stillUnpaid":
            MessageLookupByLibrary.simpleMessage("Još uvijek neplaćeno"),
        "stock": MessageLookupByLibrary.simpleMessage("Zaliha"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Zaliha je obavezna"),
        "stockList": MessageLookupByLibrary.simpleMessage("Seznam zásob"),
        "stocks": MessageLookupByLibrary.simpleMessage("Sklady"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Potrebna je dozvola za pohranu za kreiranje Excel fajla"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("Lista pod-poreza"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Pod-porezi"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Mezisoučet"),
        "submit": MessageLookupByLibrary.simpleMessage("Odeslat"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "Pretplatite se na naš\\nYouTube"),
        "subscription": MessageLookupByLibrary.simpleMessage("Předplatné"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Uspješno završeno"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Uspješno ste se odjavili"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Uspješno ažurirano"),
        "supplier": MessageLookupByLibrary.simpleMessage("Dodavatel"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("Název dodavatele"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT kód"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Připojte řidičský průkaz, občanský průkaz nebo pasovou fotografii"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "Vezměte si občanský průkaz pro ověření vašich informací"),
        "tap": MessageLookupByLibrary.simpleMessage("Tap"),
        "tax": MessageLookupByLibrary.simpleMessage("Porez"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Poreska grupa"),
        "taxPercentage":
            MessageLookupByLibrary.simpleMessage("Postotak poreza"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Poreska stopa"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Poreske stope - Upravljajte svojim poreskim stopama"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Poreski izvještaj"),
        "taxType": MessageLookupByLibrary.simpleMessage("Tip poreza"),
        "taxes": MessageLookupByLibrary.simpleMessage("Porezi"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Uslovi i odredbe"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("Podmínky použití"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Uvjeti i privatnost"),
        "thankYOuForYourDuePayment":
            MessageLookupByLibrary.simpleMessage("Děkujeme za platbu"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Hvala"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Děkujeme za nákup"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "Račun već postoji za taj email"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage("Excel fajl je već preuzet"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Jméno říká vše. S Pos Saas POS Unlimited neexistuje žádný limit pro vaše použití. Ať už zpracováváte pouze pár transakcí nebo máte nápor zákazníků, můžete provozovat s jistotou, že nejste omezeni limity."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "Unesena lozinka je previše slaba"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Prodaja će biti obrisana, a svi podaci o ovoj kupovini će biti obrisani. Jeste li sigurni da želite obrisati?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Prodaja će biti obrisana, a svi podaci o ovoj prodaji će biti obrisani. Jeste li sigurni da želite obrisati?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Uživatel bude smazán a všechna data budou z vašeho účtu odstraněna. Jste si jistí, že chcete toto smazání provést?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Korisnik će biti izbrisan i svi podaci će biti obrisani sa vašeg računa. Jeste li sigurni da želite izbrisati"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Služby třetích stran"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Ova kategorija se ne može obrisati"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Ovaj mjesec)"),
        "thisProductAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("Ovaj proizvod je već dodan"),
        "title": MessageLookupByLibrary.simpleMessage("Titulek"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Naslov ne može biti prazan"),
        "to": MessageLookupByLibrary.simpleMessage("do"),
        "toDate": MessageLookupByLibrary.simpleMessage("Do data"),
        "today": MessageLookupByLibrary.simpleMessage("Danas"),
        "total": MessageLookupByLibrary.simpleMessage("Celkem"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Celková částka"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Ukupno prikupljeno"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Celkem dlužno"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("Celkový výdaj"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Ukupni gubitak"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("Celkově k zaplacení"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Celková cena"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("Ukupno proizvoda"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Ukupni profit"),
        "totalPurchase":
            MessageLookupByLibrary.simpleMessage("Ukupna kupovina"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Ukupan iznos povrata"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("Ukupni povrati"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Celkový prodej"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Celkové zásoby"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Ukupna vrijednost"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Celková DPH"),
        "totals": MessageLookupByLibrary.simpleMessage("Celkem: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Transakce"),
        "transactionId": MessageLookupByLibrary.simpleMessage("ID transakce"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Zkusit znovu"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Typ"),
        "unitName": MessageLookupByLibrary.simpleMessage("Název jednotky"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Jednotková cena"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Jedinična cijena"),
        "units": MessageLookupByLibrary.simpleMessage("Jednotky"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Neograničeno"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Neomezené použití"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Odemkněte plný potenciál Pos Saas POS s personalizovanými školicími sezeními vedenými naším odborným týmem. Od základů po pokročilé techniky se postaráme o to, abyste se dobře orientovali v každém aspektu systému a optimalizovali tak své podnikové procesy."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Neplaćeno"),
        "update": MessageLookupByLibrary.simpleMessage("Aktualizovat"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Aktualizovat kontakt"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Aktualizovat nyní"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("Aktualizovat produkt"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Ažurirajte svoj plan prvo,\\nvaš limit je premašen"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Aktualizujte svůj profil"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Aktualizujte svůj profil, abyste se lépe spojili se svým doktorem"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Aktualizujte svůj profil, abyste lépe propojili zákazníka s lepším dojmem"),
        "updated": MessageLookupByLibrary.simpleMessage("Ažurirano"),
        "upload": MessageLookupByLibrary.simpleMessage("Učitaj"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Nahrát dokument"),
        "uploadDone":
            MessageLookupByLibrary.simpleMessage("Učitavanje završeno"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Nahrát soubor"),
        "upplier": MessageLookupByLibrary.simpleMessage("Dodavatel"),
        "usbC": MessageLookupByLibrary.simpleMessage("USB C"),
        "use": MessageLookupByLibrary.simpleMessage("Koristi"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("Použít Pos Saas"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Použití systému"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Korisnik je izbrisan"),
        "userRole": MessageLookupByLibrary.simpleMessage("Uživatelská role"),
        "userRoleDetails": MessageLookupByLibrary.simpleMessage(
            "Podrobnosti o uživatelské roli"),
        "userTitle": MessageLookupByLibrary.simpleMessage("Název uživatele"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Korisnički naslov ne može biti prazan"),
        "value": MessageLookupByLibrary.simpleMessage("Vrijednost"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("PDV se ne primjenjuje"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("Ověřování kódu OTP"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Ověření telefonního čísla"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Zobrazit vše"),
        "viewDetails":
            MessageLookupByLibrary.simpleMessage("Zobrazit podrobnosti"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Zákazník na místě"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Skladište"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Skladište već postoji"),
        "warehouseList":
            MessageLookupByLibrary.simpleMessage("Lista skladišta"),
        "warehouseName":
            MessageLookupByLibrary.simpleMessage("Naziv skladišta"),
        "warranty": MessageLookupByLibrary.simpleMessage("Garancija"),
        "weHaveSendAnEmailwithInstructions":
            MessageLookupByLibrary.simpleMessage(
                "Poslali jsme vám e-mail s pokyny k resetování hesla na:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Pro podporu funkcionality naší aplikace můžeme využívat služby třetích stran, jako jsou poskytovatelé analytiky a platební procesory. Tyto služby třetích stran mohou shromažďovat informace o vás při používání naší aplikace. Upozorňujeme, že nejsme zodpovědní za zásady ochrany osobních údajů těchto služeb třetích stran."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Používáme průmyslově standardní opatření k ochraně vašich osobních údajů, včetně šifrování a zabezpečeného uložení. Přístup k vašim údajům má pouze oprávněný personál."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Rozumíme důležitosti bezproblémového provozu. Proto je naše nepřetržitá podpora k dispozici, aby vám pomohla, ať už jde o rychlý dotaz nebo komplexní problém. Kdykoliv a kdekoli se s námi můžete spojit pomocí hovoru nebo WhatsApp, abyste zažili nepřekonatelnou zákaznickou službu."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Používáme vaše osobní informace k poskytování nejlepší možné zkušenosti ve naší aplikaci, včetně personalizace doporučení obsahu, propojení s odborníky a zlepšení funkcionality našich aplikací. Můžeme také použít vaše informace k komunikaci s vámi ohledně aktualizací, akcí nebo jiných informací týkajících se naší aplikace."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Pregledat ćemo uplatu i odobriti je u roku od 1-2 sata"),
        "weekly": MessageLookupByLibrary.simpleMessage("Sedmično"),
        "weight": MessageLookupByLibrary.simpleMessage("Váha"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Co je nového"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Velkoobchodník"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Velkoobchodní cena"),
        "wholesalePrice":
            MessageLookupByLibrary.simpleMessage("Veleprodajna cijena"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Veletrgovac"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Uskoro će biti dodano"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Istek će biti"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Napište svou zprávu zde"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("Pogrešan OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Bylo zadáno nesprávné heslo pro tohoto uživatele."),
        "yearly": MessageLookupByLibrary.simpleMessage("Roční"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Ano, smazat natrvalo"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("Niste važeći korisnik"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Používáte"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Ne možete platiti više od dospjelog iznosa"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Obdrželi jste e-mail"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Úspěšně jste se přihlásili do svého účtu. Zůstaňte s aplikací Pos Saas."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("Morate dati dozvolu"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Musíte se znovu přihlásit do svého účtu."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Před nákupem musíte ověřit svoji totožnost"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Vaše zpráva zůstává"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Váš balíček"),
        "yourPackageWillExpireinDay":
            MessageLookupByLibrary.simpleMessage("Váš balíček vyprší za 5 dní")
      };
}
