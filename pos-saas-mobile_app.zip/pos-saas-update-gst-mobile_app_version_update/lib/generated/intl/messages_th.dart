// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a th locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'th';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("ดำเนินการต่อ"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("หมายเลข GST"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("ราคาขายปลีกแนะนำ"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("ราคาขายปลีกเป็นสิ่งจำเป็น"),
        "OK": MessageLookupByLibrary.simpleMessage("ตกลง"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("หมายเลขโทรศัพท์"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("รหัส SWIFT"),
        "Snacks": MessageLookupByLibrary.simpleMessage("ของว่าง"),
        "TAX": MessageLookupByLibrary.simpleMessage("ภาษี"),
        "Uploading": MessageLookupByLibrary.simpleMessage("กำลังอัปโหลด"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("ชื่อผู้ใช้"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "แพคเกจของคุณจะหมดอายุวันนี้\n\nโปรดซื้ออีกครั้ง"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) ระบบให้ไว้เพื่อการให้บริการเฉพาะเพื่อการจัดการธุรกรรมจุดขายและกิจกรรมที่เกี่ยวข้องในธุรกิจของคุณ"),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) เพื่อใช้ระบบ คุณอาจจะต้องสร้างบัญชี คุณตกลงที่จะให้ข้อมูลที่ถูกต้อง ปัจจุบัน และครบถ้วนระหว่างกระบวนการลงทะเบียนและให้การปรับปรุงข้อมูลเหล่านี้เพื่อรักษารายละเอียดและครบถ้วน"),
        "aboutApp": MessageLookupByLibrary.simpleMessage("เกี่ยวกับแอป"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("เกี่ยวกับเรา"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("การยอมรับข้อกำหนด"),
        "accountName": MessageLookupByLibrary.simpleMessage("ชื่อบัญชี"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("หมายเลขบัญชี"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("การลงทะเบียนบัญชี"),
        "acton": MessageLookupByLibrary.simpleMessage("การดำเนินการ"),
        "add": MessageLookupByLibrary.simpleMessage("เพิ่ม"),
        "addBrand": MessageLookupByLibrary.simpleMessage("เพิ่มแบรนด์"),
        "addCategory": MessageLookupByLibrary.simpleMessage("เพิ่มหมวดหมู่"),
        "addContact": MessageLookupByLibrary.simpleMessage("เพิ่มผู้ติดต่อ"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("เพิ่มลูกค้า"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("เพิ่มการจัดส่ง"),
        "addDescriptioN": MessageLookupByLibrary.simpleMessage("เพิ่มคำอธิบาย"),
        "addDescription": MessageLookupByLibrary.simpleMessage("เพิ่มบันทึก"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("เพิ่มส่วนลด"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("เพิ่มรหัสเอกสาร"),
        "addDucument": MessageLookupByLibrary.simpleMessage("เพิ่มเอกสาร"),
        "addExpense": MessageLookupByLibrary.simpleMessage("เพิ่มค่าใช้จ่าย"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("เพิ่มหมวดค่าใช้จ่าย"),
        "addItems": MessageLookupByLibrary.simpleMessage("เพิ่มสินค้า"),
        "addNew": MessageLookupByLibrary.simpleMessage("เพิ่มใหม่"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("เพิ่มที่อยู่ใหม่"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("เพิ่มผลิตภัณฑ์ใหม่"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("เพิ่มภาษีใหม่"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "เพิ่มภาษีใหม่ด้วยประเภทภาษีเดี่ยว/หลายประเภท"),
        "addNote": MessageLookupByLibrary.simpleMessage("เพิ่มบันทึก"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("กรุณาเพิ่มผลิตภัณฑ์ก่อน"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("เพิ่มรหัสโปรโมชั่น"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("เพิ่มการซื้อ"),
        "addSales": MessageLookupByLibrary.simpleMessage("เพิ่มการขาย"),
        "addSuccessful": MessageLookupByLibrary.simpleMessage("เพิ่มสำเร็จ"),
        "addUnit": MessageLookupByLibrary.simpleMessage("เพิ่มหน่วย"),
        "addUserRole": MessageLookupByLibrary.simpleMessage("เพิ่มบทบาทผู้ใช้"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("เพิ่มเรียบร้อยแล้ว"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("เพิ่มในตะกร้าแล้ว"),
        "address": MessageLookupByLibrary.simpleMessage("ที่อยู่"),
        "admin": MessageLookupByLibrary.simpleMessage("ผู้ดูแลระบบ"),
        "all": MessageLookupByLibrary.simpleMessage("ทั้งหมด"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("ทุกโซลูชั่นธุรกิจ"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("เพิ่มแล้ว"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("มีอยู่แล้ว"),
        "amount": MessageLookupByLibrary.simpleMessage("จำนวนเงิน"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "มีอีเมลถูกส่งไปแล้ว\\nตรวจสอบกล่องจดหมายของคุณ"),
        "androidIOSAppSupport":
            MessageLookupByLibrary.simpleMessage("รองรับแอป Android และ iOS"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("ภาษีที่ใช้บังคับ"),
        "apply": MessageLookupByLibrary.simpleMessage("นำไปใช้"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "คุณแน่ใจที่จะลบใบแจ้งหนี้นี้หรือไม่"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "คุณแน่ใจที่จะลบการขายนี้หรือไม่"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "คุณแน่ใจที่จะลบผู้ใช้คนนี้หรือไม่"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "คุณแน่ใจหรือว่าต้องการลบภาษีนี้"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "คุณแน่ใจหรือว่าต้องการลบกลุ่มภาษีนี้"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "คุณต้องการลบคลังสินค้านี้หรือไม่"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "คุณแน่ใจหรือไม่ที่จะลบผู้ใช้รายนี้?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("ลายเซ็นที่ได้รับอนุญาต"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) คุณรับผิดชอบในการรักษารับประกันความลับของบัญชีและรหัสผ่านของคุณและการจำกัดการเข้าถึงบัญชีของคุณ คุณยอมรับความรับผิดชอบสำหรับกิจกรรมทั้งหมดที่เกิดขึ้นภายใต้บัญชีของคุณ"),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) คุณต้องมีอายุอย่างน้อย 18 ปีหรืออายุที่กฎหมายเป็นอย่างน้อยในเขตอำนาจของคุณเพื่อใช้ระบบ"),
        "backSide": MessageLookupByLibrary.simpleMessage("ด้านหลัง"),
        "backToHome": MessageLookupByLibrary.simpleMessage("กลับสู่หน้าหลัก"),
        "balance": MessageLookupByLibrary.simpleMessage("ยอดคงเหลือ"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("บังคลาเทศ"),
        "bank": MessageLookupByLibrary.simpleMessage("ธนาคาร"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("สกุลเงินบัญชีธนาคาร"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("สกุลเงินบัญชีธนาคาร"),
        "bankInformation": MessageLookupByLibrary.simpleMessage("ข้อมูลธนาคาร"),
        "bankName": MessageLookupByLibrary.simpleMessage("ชื่อธนาคาร"),
        "bankTransfer":
            MessageLookupByLibrary.simpleMessage("การโอนเงินผ่านธนาคาร"),
        "barcodeFound": MessageLookupByLibrary.simpleMessage("พบบาร์โค้ด"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("ใบแจ้งหนี้"),
        "billTo": MessageLookupByLibrary.simpleMessage("ส่งบิลไปยัง"),
        "branchName": MessageLookupByLibrary.simpleMessage("ชื่อสาขา"),
        "brand": MessageLookupByLibrary.simpleMessage("แบรนด์"),
        "brandName": MessageLookupByLibrary.simpleMessage("ชื่อแบรนด์"),
        "bulkUpload":
            MessageLookupByLibrary.simpleMessage("อัปโหลดแบบจำนวนมาก"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("หมวดหมู่ธุรกิจ"),
        "buy": MessageLookupByLibrary.simpleMessage("ซื้อ"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("ซื้อแผนพรีเมียม"),
        "buySms": MessageLookupByLibrary.simpleMessage("ซื้อ SMS"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "โดยการเข้าถึงหรือใช้ระบบจุดขาย (POS) (ระบบ) ที่ให้โดย [ชื่อบริษัทของคุณ] (บริษัท) คุณตกลงที่จะถูกผูกพันด้วยข้อกำหนดการใช้งานเหล่านี้ หากคุณไม่ยินยอมตามข้อกำหนดการใช้งานเหล่านี้ กรุณาอย่าใช้ระบบ"),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) คุณมีหน้าที่ในการรับผิดชอบในการตรวจสอบว่าการเข้าถึงและการใช้ระบบของคุณเป็นไปตามกฎหมายและระเบียบที่มีผูกพันไว้ทั้งหมด"),
        "call": MessageLookupByLibrary.simpleMessage("โทร"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "โทรหาสำหรับการสนับสนุนฉุกเฉิน"),
        "camera": MessageLookupByLibrary.simpleMessage("กล้อง"),
        "cancel": MessageLookupByLibrary.simpleMessage("ยกเลิก"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("ยกเลิกผลิตภัณฑ์ทั้งหมด"),
        "capacity": MessageLookupByLibrary.simpleMessage("ความจุ"),
        "card": MessageLookupByLibrary.simpleMessage("บัตร"),
        "cash": MessageLookupByLibrary.simpleMessage("เงินสด"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("หมวดหมู่"),
        "category": MessageLookupByLibrary.simpleMessage("หมวดหมู่"),
        "categoryName": MessageLookupByLibrary.simpleMessage("ชื่อหมวดหมู่"),
        "categoryNameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("ชื่อหมวดหมู่มีอยู่แล้ว"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("ชื่อหมวดหมู่"),
        "change": MessageLookupByLibrary.simpleMessage("เปลี่ยน?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("เปลี่ยนรหัสผ่าน"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("ตรวจสอบอีเมล"),
        "choseACustomer": MessageLookupByLibrary.simpleMessage("เลือกลูกค้า"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("เลือกผู้จัดจำหน่าย"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("เลือกคุณสมบัติของคุณ"),
        "clarence": MessageLookupByLibrary.simpleMessage("คลีแอร์เรนซ์"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("คลิกเพื่อเชื่อมต่อ"),
        "close": MessageLookupByLibrary.simpleMessage("ปิด"),
        "color": MessageLookupByLibrary.simpleMessage("สี"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(การรวมกันของภาษีหลายรายการ)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("เร็วๆ นี้"),
        "companyAddress": MessageLookupByLibrary.simpleMessage("ที่อยู่บริษัท"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("ชื่อบริษัทและร้านค้า"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("ชื่อบริษัทและธุรกิจ"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("ทำธุรกรรมเสร็จสิ้น"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("ยืนยันรหัสผ่าน"),
        "confirmReturn": MessageLookupByLibrary.simpleMessage("ยืนยันการคืน"),
        "congratulations":
            MessageLookupByLibrary.simpleMessage("ขอแสดงความยินดี"),
        "contactUs": MessageLookupByLibrary.simpleMessage("ติดต่อเรา"),
        "continu": MessageLookupByLibrary.simpleMessage("ดำเนินการต่อ"),
        "country": MessageLookupByLibrary.simpleMessage("ประเทศ"),
        "create": MessageLookupByLibrary.simpleMessage("สร้าง"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("สร้างบัญชีฟรี"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("สร้างและบันทึก"),
        "currency": MessageLookupByLibrary.simpleMessage("สกุลเงิน"),
        "currentStock": MessageLookupByLibrary.simpleMessage("สต็อกปัจจุบัน"),
        "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
            "การติดตั้งสกรีนอินวอยซ์แบบกำหนดเอง"),
        "customer": MessageLookupByLibrary.simpleMessage("ลูกค้า"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("รายละเอียดลูกค้า"),
        "customerGST": MessageLookupByLibrary.simpleMessage("GST ของลูกค้า"),
        "customerName": MessageLookupByLibrary.simpleMessage("ชื่อลูกค้า"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("ธุรกรรมรายวัน"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("ภาพรวมแดชบอร์ด"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("บันทึกข้อมูลเรียบร้อยแล้ว"),
        "date": MessageLookupByLibrary.simpleMessage("วันที่"),
        "day": MessageLookupByLibrary.simpleMessage("วัน"),
        "dealer": MessageLookupByLibrary.simpleMessage("ผู้จัดจำหน่าย"),
        "dealerPrice":
            MessageLookupByLibrary.simpleMessage("ราคาตัวแทนจำหน่าย"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("เปอร์เซ็นต์ VAT เริ่มต้น"),
        "delete": MessageLookupByLibrary.simpleMessage("ลบ"),
        "deleting": MessageLookupByLibrary.simpleMessage("กำลังลบ"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("ที่อยู่จัดส่ง"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("ที่อยู่การจัดส่ง"),
        "deliveryCharge": MessageLookupByLibrary.simpleMessage("ค่าจัดส่ง"),
        "description": MessageLookupByLibrary.simpleMessage("คำอธิบาย"),
        "descriptionCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "คำบรรยายไม่สามารถเป็นค่าว่าง"),
        "details": MessageLookupByLibrary.simpleMessage("รายละเอียด"),
        "discount": MessageLookupByLibrary.simpleMessage("ส่วนลด"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("ไม่รบกวน"),
        "done": MessageLookupByLibrary.simpleMessage("เสร็จสิ้น"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("ดาวน์โหลดรูปแบบ Excel"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "ดาวน์โหลดเรียบร้อยแล้วในโฟลเดอร์ดาวน์โหลด"),
        "due": MessageLookupByLibrary.simpleMessage("ค้างชำระ"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("ยอดค้างชำระ: "),
        "dueCollection":
            MessageLookupByLibrary.simpleMessage("การรับชำระค้างชำระ"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("รายงานการรับชำระค่า"),
        "dueList": MessageLookupByLibrary.simpleMessage("รายการค้างชำระ"),
        "dueReports": MessageLookupByLibrary.simpleMessage("รายงานยอดค้าง"),
        "duration": MessageLookupByLibrary.simpleMessage("ระยะเวลา"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("ระยะเวลา: จาก"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "โปรแกรมรับชำระผ่านมือถือที่ใช้งานง่าย"),
        "edit": MessageLookupByLibrary.simpleMessage("แก้ไข"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("แก้ไขใบแจ้งหนี้การซื้อ"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("แก้ไขใบแจ้งหนี้การขาย"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("แก้ไขโซเชียลมีเดีย"),
        "editSuccessfully": MessageLookupByLibrary.simpleMessage("แก้ไขสำเร็จ"),
        "editTax": MessageLookupByLibrary.simpleMessage("แก้ไขภาษี"),
        "editTaxGroup": MessageLookupByLibrary.simpleMessage("แก้ไขกลุ่มภาษี"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("แก้ไขคลังสินค้า"),
        "email": MessageLookupByLibrary.simpleMessage("อีเมล"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("ที่อยู่อีเมล"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("อีเมลไม่สามารถเว้นว่างได้"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "ส่งอีเมลแล้ว! กรุณาตรวจสอบกล่องจดหมายของคุณ"),
        "endDate": MessageLookupByLibrary.simpleMessage("วันที่สิ้นสุด"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("กรุณาใส่จำนวนเงินที่ถูกต้อง"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("กรุณาใส่ส่วนลดที่ถูกต้อง"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "กรุณาใส่หมายเลขโทรศัพท์ที่ถูกต้อง"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("กรุณาใส่ราคาที่ถูกต้อง"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("กรุณาใส่จำนวนที่ถูกต้อง"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("ป้อนที่อยู่"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("ใส่จำนวนเงิน"),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("ป้อนชื่อแบรนด์"),
        "enterCapacity": MessageLookupByLibrary.simpleMessage("ป้อนความจุ"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("ป้อนชื่อหมวดหมู่"),
        "enterColor": MessageLookupByLibrary.simpleMessage("ป้อนสี"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "กรุณาใส่หมายเลข GST ของลูกค้า"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("ป้อนราคาตัวแทนจำหน่าย"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("กรุณาใส่คำอธิบาย"),
        "enterDiscount": MessageLookupByLibrary.simpleMessage("ป้อนส่วนลด"),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("ป้อนวันที่ค่าใช้จ่าย"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("ใส่ที่อยู่เต็ม"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("ป้อนหมายเลขใบแจ้งหนี้"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "กรุณาใส่จำนวนแจ้งเตือนสต็อกต่ำ"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("ป้อนผู้ผลิต"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("ป้อนเนื้อหาข้อความ"),
        "enterMrpOrRetailerPirce":
            MessageLookupByLibrary.simpleMessage("ป้อนราคาขายปลีกแนะนำ"),
        "enterName": MessageLookupByLibrary.simpleMessage("ป้อนชื่อ"),
        "enterNote": MessageLookupByLibrary.simpleMessage("ป้อนบันทึก"),
        "enterPartyName": MessageLookupByLibrary.simpleMessage("ป้อนชื่อบุคคล"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("ใส่หมายเลขโทรศัพท์"),
        "enterProductCodeOrScan":
            MessageLookupByLibrary.simpleMessage("ป้อนรหัสสินค้าหรือสแกน"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("ป้อนชื่อผลิตภัณฑ์"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("ป้อนราคาซื้อ"),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("ป้อนหมายเลขอ้างอิง"),
        "enterSize": MessageLookupByLibrary.simpleMessage("ป้อนขนาด"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("ป้อนสต็อก"),
        "enterTaxRate": MessageLookupByLibrary.simpleMessage("กรอกอัตราภาษี"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("ป้อนรหัสธุรกรรม"),
        "enterType": MessageLookupByLibrary.simpleMessage("ป้อนประเภท"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("ป้อนชื่อผู้ใช้"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("กรุณาใส่จำนวนเงินที่ถูกต้อง"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("กรอกชื่อคลังสินค้า"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("ป้อนน้ำหนัก"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("ป้อนราคาขายส่ง"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("ป้อนคำอธิบายของคุณที่นี่"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("ใส่ที่อยู่อีเมลของคุณ"),
        "enterYourFeedBackTitle":
            MessageLookupByLibrary.simpleMessage("ป้อนหัวข้อข้อเสนอแนะของคุณ"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("กรุณาใส่หมายเลข GST ของคุณ"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("ป้อนหมายเลขมือถือของคุณ"),
        "enterYourName": MessageLookupByLibrary.simpleMessage("ป้อนชื่อของคุณ"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("ใส่หมายเลขโทรศัพท์ของคุณ"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("ป้อนรหัสผ่านของคุณ"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("ใส่หมายเลขโทรศัพท์ของคุณ"),
        "enterYourTransactionId":
            MessageLookupByLibrary.simpleMessage("ป้อนรหัสธุรกรรมของคุณ"),
        "error": MessageLookupByLibrary.simpleMessage("ข้อผิดพลาด"),
        "excTax": MessageLookupByLibrary.simpleMessage("ไม่รวมภาษี"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("อัปโหลด Excel"),
        "exclusive": MessageLookupByLibrary.simpleMessage("ไม่รวมภาษี"),
        "expense": MessageLookupByLibrary.simpleMessage("ค่าใช้จ่าย"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("หมวดค่าใช้จ่าย"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("วันที่ค่าใช้จ่าย"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("ค่าใช้จ่ายสำหรับ"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("รายงานค่าใช้จ่าย"),
        "expireDate": MessageLookupByLibrary.simpleMessage("วันหมดอายุ"),
        "expired": MessageLookupByLibrary.simpleMessage("หมดอายุ"),
        "expiring": MessageLookupByLibrary.simpleMessage("กำลังจะหมดอายุ"),
        "facebok": MessageLookupByLibrary.simpleMessage("เฟสบุ๊ค"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("ล้มเหลวพร้อมข้อผิดพลาด"),
        "fashion": MessageLookupByLibrary.simpleMessage("แฟชั่น"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "คุณสมบัติเป็นส่วนสำคัญที่ทำให้ Pos Saas แตกต่างจากการแก้ไขด้วยวิธีเดิม"),
        "feedBack": MessageLookupByLibrary.simpleMessage("ข้อเสนอแนะ"),
        "firstName": MessageLookupByLibrary.simpleMessage("ชื่อ"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("ติดตามเราบน\nFacebook"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("ติดตามเราบน\nTwitter"),
        "fontSide": MessageLookupByLibrary.simpleMessage("ด้านหน้า"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("สำหรับการใช้งานไม่จำกัด"),
        "forgotPassword": MessageLookupByLibrary.simpleMessage("ลืมรหัสผ่าน"),
        "forgotPasswords": MessageLookupByLibrary.simpleMessage("ลืมรหัสผ่าน?"),
        "formDate": MessageLookupByLibrary.simpleMessage("จากวันที่"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("การสำรองข้อมูลฟรี"),
        "freeLifeTimeUpdate":
            MessageLookupByLibrary.simpleMessage("อัปเดตฟรีตลอดชีพ"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("แพคเกจฟรี"),
        "freePlan": MessageLookupByLibrary.simpleMessage("แผนฟรี"),
        "from": MessageLookupByLibrary.simpleMessage("(จาก"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("ชำระเงินเต็มจำนวน"),
        "gallary": MessageLookupByLibrary.simpleMessage("แกลลอรี"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("กำลังสร้าง PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("รับรหัส OTP"),
        "govermentId":
            MessageLookupByLibrary.simpleMessage("รหัสประจำตัวประชาชน"),
        "guest": MessageLookupByLibrary.simpleMessage("ผู้มาเยือน"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("ยังไม่มีบัญชีใช่ไหม?"),
        "history": MessageLookupByLibrary.simpleMessage("ประวัติ"),
        "home": MessageLookupByLibrary.simpleMessage("หน้าหลัก"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "เราคุ้มครองข้อมูลของคุณอย่างไร"),
        "howWeUseYourInformation":
            MessageLookupByLibrary.simpleMessage("เราใช้ข้อมูลของคุณอย่างไร"),
        "identityVerify": MessageLookupByLibrary.simpleMessage("ตรวจสอบตัวตน"),
        "image": MessageLookupByLibrary.simpleMessage("รูปภาพ"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("ในบ้านไม่สามารถลบได้"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("ในบ้านไม่สามารถแก้ไขได้"),
        "inWord": MessageLookupByLibrary.simpleMessage("เป็นคำ"),
        "incTax": MessageLookupByLibrary.simpleMessage("รวมภาษี"),
        "inclusive": MessageLookupByLibrary.simpleMessage("รวมภาษี"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("เพิ่มสต็อก"),
        "inistrument": MessageLookupByLibrary.simpleMessage("เครื่องดนตรี"),
        "instragram": MessageLookupByLibrary.simpleMessage("อินสตาแกรม"),
        "invNo": MessageLookupByLibrary.simpleMessage("หมายเลขใบส่งของ"),
        "invoice": MessageLookupByLibrary.simpleMessage("ใบแจ้งหนี้"),
        "invoiceNumber":
            MessageLookupByLibrary.simpleMessage("หมายเลขใบแจ้งหนี้"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("การตั้งค่าใบแจ้งหนี้"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("ผู้ดูใบแจ้งหนี้"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("เพิ่มสินค้าแล้ว"),
        "kg": MessageLookupByLibrary.simpleMessage("กิโลกรัม"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("การตรวจสอบ KYC"),
        "language": MessageLookupByLibrary.simpleMessage("ภาษา"),
        "lastName": MessageLookupByLibrary.simpleMessage("นามสกุล"),
        "ledger": MessageLookupByLibrary.simpleMessage("สมุดบัญชี"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("ซื้อเป็นเวลา"),
        "link": MessageLookupByLibrary.simpleMessage("ลิงก์"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("ลิงค์อิน"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("สนับสนุนแชทสด"),
        "loading": MessageLookupByLibrary.simpleMessage("กำลังโหลด"),
        "logIn": MessageLookupByLibrary.simpleMessage("เข้าสู่ระบบ"),
        "logOUt": MessageLookupByLibrary.simpleMessage("ออกจากระบบ"),
        "logOut": MessageLookupByLibrary.simpleMessage("ออกจากระบบ"),
        "login": MessageLookupByLibrary.simpleMessage("เข้าสู่ระบบ"),
        "logo": MessageLookupByLibrary.simpleMessage("โลโก้"),
        "loss": MessageLookupByLibrary.simpleMessage("ขาดทุน"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("ขาดทุน/กำไร"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("รายละเอียดขาดทุน/กำไร"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("รายงานขาดทุน/กำไร"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("รายงานขาดทุน/กำไร"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("แจ้งเตือนสต็อกต่ำ"),
        "maan": MessageLookupByLibrary.simpleMessage("มาน"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "สร้างความประทับใจอันยืนยาวในลูกค้าของคุณด้วยใบแจ้งหนี้ที่มีแบรนด์ของคุณเอง การอัปเกรดไม่จำกัดของเราให้คุณมีข้อได้เปรียบที่ไม่ซ้ำหน้าใครในการปรับแต่งใบแจ้งหนี้ของคุณ การเพิ่มราคามืออาชีพที่เสริมความเป็นแบรนด์ของคุณและสนับสนุนความลุลินของลูกค้า."),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("จัดการธุรกิจของคุณด้วย"),
        "manufactureDate": MessageLookupByLibrary.simpleMessage("วันที่ผลิต"),
        "margin": MessageLookupByLibrary.simpleMessage("มาร์จิ้น"),
        "masterCard": MessageLookupByLibrary.simpleMessage("บัตร MasterCard"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("ผู้ผลิต"),
        "message": MessageLookupByLibrary.simpleMessage("ข้อความ"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("ประวัติข้อความ"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "แอปพลิเคชัน Pos Saas ฟรี ใช้งานง่าย และเป็นหนึ่งในระบบจุดขายที่ดีที่สุดทั่วโลก"),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas เป็นโซลูชั่นธุรกิจที่ครอบคลุมด้านสินค้าคงคลัง บัญชี การขาย ค่าใช้จ่าย และขาดทุน/กำไร"),
        "mobile": MessageLookupByLibrary.simpleMessage("มือถือ"),
        "mobilePayment":
            MessageLookupByLibrary.simpleMessage("การชำระเงินผ่านมือถือ"),
        "monthly": MessageLookupByLibrary.simpleMessage("รายเดือน"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("ข้อมูลเพิ่มเติม"),
        "name": MessageLookupByLibrary.simpleMessage("ใส่ชื่อของคุณ"),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("ชื่อมีอยู่แล้ว"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("ชื่อไม่สามารถว่างเปล่าได้"),
        "next": MessageLookupByLibrary.simpleMessage("ถัดไป"),
        "noConnection":
            MessageLookupByLibrary.simpleMessage("ไม่มีการเชื่อมต่อ"),
        "noData": MessageLookupByLibrary.simpleMessage("ไม่มีข้อมูล"),
        "noDataAvailable": MessageLookupByLibrary.simpleMessage("ไม่มีข้อมูล"),
        "noDataFound": MessageLookupByLibrary.simpleMessage("ไม่พบข้อมูล"),
        "noHistoryFound": MessageLookupByLibrary.simpleMessage("ไม่พบประวัติ"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("ไม่พบผลิตภัณฑ์"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("ไม่มีภาษีย่อยที่เลือก"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("ไม่พบธุรกรรม"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "ไม่พบผู้ใช้สำหรับอีเมลดังกล่าว"),
        "noUserRoleFound":
            MessageLookupByLibrary.simpleMessage("ไม่พบบทบาทผู้ใช้"),
        "notActiveUser": MessageLookupByLibrary.simpleMessage("ผู้ใช้ไม่ทำงาน"),
        "notProvided": MessageLookupByLibrary.simpleMessage("ไม่ได้ให้"),
        "note": MessageLookupByLibrary.simpleMessage("บันทึก"),
        "notes": MessageLookupByLibrary.simpleMessage("หมายเหตุ"),
        "notification": MessageLookupByLibrary.simpleMessage("การแจ้งเตือน"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP ถูกส่งไปที่"),
        "office": MessageLookupByLibrary.simpleMessage("สำนักงาน"),
        "ok": MessageLookupByLibrary.simpleMessage("ตกลง"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS ที่มีความสามารถมากมายรวมถึงการติดตามยอดขายและการจัดการสินค้าคงคลัง"),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "ระบบนี้ช่วยให้คุณมีโอกาสในการดำเนินการเพื่อลูกค้าของคุณ"),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "ระบบ POS ของเราควรทำให้การดำเนินการประจำวันง่ายขึ้นโดยอัตโนมัติ ทำให้การนำทางเป็นเรื่องง่าย"),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("ยอดเงินเริ่มต้น"),
        "order": MessageLookupByLibrary.simpleMessage("คำสั่ง"),
        "other": MessageLookupByLibrary.simpleMessage("อื่นๆ"),
        "otp": MessageLookupByLibrary.simpleMessage("ปิด"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("สินค้าหมด"),
        "pacakge": MessageLookupByLibrary.simpleMessage("แพคเกจ"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("คุณสมบัติของแพคเกจ"),
        "paid": MessageLookupByLibrary.simpleMessage("จ่ายแล้ว"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("ยอดชำระแล้ว"),
        "parties": MessageLookupByLibrary.simpleMessage("บุคคล"),
        "partiesList": MessageLookupByLibrary.simpleMessage("รายชื่อบุคคล"),
        "partyGST": MessageLookupByLibrary.simpleMessage("GST ของคู่ค้า"),
        "partyName": MessageLookupByLibrary.simpleMessage("ชื่อบุคคล"),
        "password": MessageLookupByLibrary.simpleMessage("รหัสผ่าน"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "รหัสผ่านและยืนยันรหัสผ่านไม่ตรงกัน"),
        "passwordCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "รหัสผ่านไม่สามารถเว้นว่างได้"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("รหัสผ่านไม่ตรงกัน"),
        "payCash": MessageLookupByLibrary.simpleMessage("ชำระด้วยเงินสด"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash": MessageLookupByLibrary.simpleMessage("ชำระด้วย bKash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("ชำระเงินด้วย Paypal"),
        "payeeName": MessageLookupByLibrary.simpleMessage("ชื่อผู้รับเงิน"),
        "payeeNumber":
            MessageLookupByLibrary.simpleMessage("หมายเลขผู้รับเงิน"),
        "payment": MessageLookupByLibrary.simpleMessage("การชำระเงิน"),
        "paymentAmount":
            MessageLookupByLibrary.simpleMessage("จำนวนเงินที่ชำระ"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("การชำระเงินเสร็จสิ้น"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("คำแนะนำการชำระเงิน:"),
        "paymentMethod":
            MessageLookupByLibrary.simpleMessage("วิธีการชำระเงิน"),
        "paymentType":
            MessageLookupByLibrary.simpleMessage("ประเภทการชำระเงิน"),
        "pdfView": MessageLookupByLibrary.simpleMessage("มุมมอง PDF"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("ข้อมูลส่วนบุคคล"),
        "phone": MessageLookupByLibrary.simpleMessage("โทรศัพท์"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("หมายเลขโทรศัพท์"),
        "phoneNumberAlreadyUsed":
            MessageLookupByLibrary.simpleMessage("หมายเลขโทรศัพท์ถูกใช้แล้ว"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("หมายเลขโทรศัพท์ไม่ถูกต้อง"),
        "phoneNumberIsRequired": MessageLookupByLibrary.simpleMessage(
            "หมายเลขโทรศัพท์เป็นสิ่งจำเป็น"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("เลือกและอัปโหลดไฟล์"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("เลือกวันที่สิ้นสุด"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("เลือกวันที่เริ่มต้น"),
        "plan": MessageLookupByLibrary.simpleMessage("แผน"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("กรุณาเพิ่มจำนวน"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "โปรดตรวจสอบการเชื่อมต่ออินเทอร์เน็ตของคุณ"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "กรุณาเชื่อมต่อเครื่องพิมพ์ก่อน"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "โปรดเชื่อมต่อเครื่องพิมพ์บลูทูธของคุณ"),
        "pleaseEnterABiggerPassword":
            MessageLookupByLibrary.simpleMessage("กรุณาใส่รหัสผ่านที่ยาวขึ้น"),
        "pleaseEnterAConfirmPassword":
            MessageLookupByLibrary.simpleMessage("โปรดป้อนรหัสผ่านยืนยัน"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("โปรดป้อนรหัสผ่าน"),
        "pleaseEnterAValidEmail":
            MessageLookupByLibrary.simpleMessage("กรุณาใส่อีเมลที่ถูกต้อง"),
        "pleaseEnterName": MessageLookupByLibrary.simpleMessage("กรุณาใส่ชื่อ"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("กรุณากรอกรหัสผ่าน"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "โปรดป้อนที่อยู่อีเมลของคุณด้านล่างเพื่อรับลิงค์การรีเซ็ตรหัสผ่าน"),
        "pleaseEnterTransactionNumber":
            MessageLookupByLibrary.simpleMessage("กรุณาใส่หมายเลขธุรกรรม"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("กรุณาใส่จำนวนเงิน"),
        "pleaseSelectACategoryFirst":
            MessageLookupByLibrary.simpleMessage("กรุณาเลือกหมวดหมู่ก่อน"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("กรุณาเลือกแผน"),
        "pleaseSelectBusinessCategory":
            MessageLookupByLibrary.simpleMessage("กรุณาเลือกหมวดหมู่ธุรกิจ"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "กรุณาใช้รหัสซื้อที่ถูกต้องเพื่อใช้แอป"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("ขับเคลื่อนโดย Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("พัฒนาโดย"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("บริการลูกค้าพรีเมี่ยม"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("แผนพรีเมียม"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("ยอดชำระเงินก่อนหน้า"),
        "price": MessageLookupByLibrary.simpleMessage("ราคา"),
        "print": MessageLookupByLibrary.simpleMessage("พิมพ์"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("ตัวเลือกการพิมพ์"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("นโยบายความเป็นส่วนตัว"),
        "product": MessageLookupByLibrary.simpleMessage("สินค้า"),
        "productCode": MessageLookupByLibrary.simpleMessage("รหัสสินค้า"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("รหัสผลิตภัณฑ์เป็นสิ่งจำเป็น"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("รหัส/ชื่อผลิตภัณฑ์"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("รายละเอียดผลิตภัณฑ์"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("รายละเอียดผลิตภัณฑ์"),
        "productList": MessageLookupByLibrary.simpleMessage("รายการสินค้า"),
        "productName": MessageLookupByLibrary.simpleMessage("ชื่อผลิตภัณฑ์"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "ชื่อผลิตภัณฑ์มีอยู่แล้วในคลังสินค้า"),
        "productNameIsAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("ชื่อผลิตภัณฑ์ถูกเพิ่มแล้ว"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("ชื่อผลิตภัณฑ์เป็นสิ่งจำเป็น"),
        "products": MessageLookupByLibrary.simpleMessage("ผลิตภัณฑ์"),
        "profile": MessageLookupByLibrary.simpleMessage("โปรไฟล์"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("แก้ไขโปรไฟล์"),
        "profit": MessageLookupByLibrary.simpleMessage("กำไร"),
        "promo": MessageLookupByLibrary.simpleMessage("โปรโมชั่น"),
        "promoCode": MessageLookupByLibrary.simpleMessage("โค้ดโปรโมชั่น"),
        "purchase": MessageLookupByLibrary.simpleMessage("การซื้อ"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("แจ้งเตือนการซื้อ"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("ยืนยันการซื้อ"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("รายละเอียดการซื้อ"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("ใบแจ้งหนี้การซื้อ"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("รายการซื้อ"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("ซื้อเดี๋ยวนี้"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("ซื้อแผนพรีเมียม"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("ราคาซื้อ"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("ราคาซื้อเป็นสิ่งจำเป็น"),
        "purchaseRepoet": MessageLookupByLibrary.simpleMessage("รายงานการซื้อ"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("รายงานการซื้อ"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("รายงานการซื้อ"),
        "purchaseReturn": MessageLookupByLibrary.simpleMessage("การคืนสินค้า"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("รายงานการคืนสินค้า"),
        "purchaseTransition": MessageLookupByLibrary.simpleMessage("การซื้อ"),
        "qty": MessageLookupByLibrary.simpleMessage("จำนวน"),
        "quantity": MessageLookupByLibrary.simpleMessage("ปริมาณ"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("ธุรกรรมล่าสุด"),
        "recivedThePin": MessageLookupByLibrary.simpleMessage("ได้รับรหัส PIN"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("หมายเลขอ้างอิง"),
        "register": MessageLookupByLibrary.simpleMessage("ลงทะเบียน"),
        "registering": MessageLookupByLibrary.simpleMessage("กำลังลงทะเบียน"),
        "remainingDue":
            MessageLookupByLibrary.simpleMessage("ยอดคงค้างคงเหลือ"),
        "remove": MessageLookupByLibrary.simpleMessage("ลบ"),
        "reports": MessageLookupByLibrary.simpleMessage("รายงาน"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("คำขอได้ถูกส่งแล้ว"),
        "resendCode": MessageLookupByLibrary.simpleMessage("ส่งรหัสอีกครั้ง"),
        "resendOtp":
            MessageLookupByLibrary.simpleMessage("ส่งรหัส OTP อีกครั้ง: "),
        "retailer": MessageLookupByLibrary.simpleMessage("ร้านค้าปลีก"),
        "retur": MessageLookupByLibrary.simpleMessage("คืน"),
        "returN": MessageLookupByLibrary.simpleMessage("คืน"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("ยอดเงินคืน"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("ยอดเงินคืน"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("จำนวนที่คืน"),
        "revenue": MessageLookupByLibrary.simpleMessage("รายได้"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "ป้องกันข้อมูลธุรกิจของคุณอย่างง่ายดาย การอัปเดตไม่จำกัดของ Pos Saas POS ของเรารวมถึงการสำรองข้อมูลฟรีเพื่อให้คุณมั่นใจว่าข้อมูลคุณมีค่าจะได้รับความคุ้มครองจากเหตุการณ์ที่ไม่คาดคิด ให้ความสำคัญกับสิ่งที่สำคัญจริง ซึ่งคือการเติบโตของธุรกิจของคุณ"),
        "saleAmount": MessageLookupByLibrary.simpleMessage("จำนวนการขาย"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("รายละเอียดการขาย"),
        "salePrice": MessageLookupByLibrary.simpleMessage("ราคาขาย"),
        "saleReports": MessageLookupByLibrary.simpleMessage("รายงานการขาย"),
        "saleReportss": MessageLookupByLibrary.simpleMessage("รายงานการขาย"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("การคืนขาย"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("รายงานการคืนขาย"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("การตั้งค่าการขาย"),
        "sales": MessageLookupByLibrary.simpleMessage("การขาย"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("รายงานการขายและการซื้อ"),
        "salesList": MessageLookupByLibrary.simpleMessage("รายการการขาย"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("การคืนขาย"),
        "save": MessageLookupByLibrary.simpleMessage("บันทึก"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("บันทึกและเผยแพร่"),
        "saveChanges":
            MessageLookupByLibrary.simpleMessage("บันทึกการเปลี่ยนแปลง"),
        "saving": MessageLookupByLibrary.simpleMessage("กำลังบันทึก"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("สแกนรหัส QR ของผลิตภัณฑ์"),
        "search": MessageLookupByLibrary.simpleMessage("ค้นหา"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "ค้นหาด้วยรหัสผลิตภัณฑ์หรือชื่อ"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("ดูโค้ดโปรโมชั่นทั้งหมด"),
        "select": MessageLookupByLibrary.simpleMessage("เลือก"),
        "selectAProductForReturn":
            MessageLookupByLibrary.simpleMessage("เลือกผลิตภัณฑ์สำหรับการคืน"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("เลือกแบรนด์"),
        "selectCategory": MessageLookupByLibrary.simpleMessage("เลือกหมวดหมู่"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("เลือกผู้ติดต่อ"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("เลือกหมวดหมู่ผลิตภัณฑ์"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("เลือกหมวดหมู่ร้านค้า"),
        "selectTax": MessageLookupByLibrary.simpleMessage("เลือกภาษี"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("เลือกประเภทภาษี"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("เลือกหน่วย"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("เลือกความหลากหลาย: "),
        "seller": MessageLookupByLibrary.simpleMessage("ผู้ขาย"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("ขายโดย"),
        "send": MessageLookupByLibrary.simpleMessage("ส่ง"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("ส่งอีเมล"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("ส่งข้อความ"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("ส่งลิงค์การรีเซ็ต"),
        "sendSms": MessageLookupByLibrary.simpleMessage("ส่งข้อความ SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("ส่ง SMS?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("ส่งข้อความ WhatsApp"),
        "sendYOurEmail": MessageLookupByLibrary.simpleMessage("ส่งอีเมลของคุณ"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage("กำลังส่งอีเมล"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("กำลังส่งข้อความ"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("บริการ/การจัดส่ง"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("ตั้งค่าโปรไฟล์ของคุณ"),
        "setting": MessageLookupByLibrary.simpleMessage("ตั้งค่า"),
        "share": MessageLookupByLibrary.simpleMessage("แชร์"),
        "shopGST": MessageLookupByLibrary.simpleMessage("GST ของร้านค้า"),
        "signIn": MessageLookupByLibrary.simpleMessage("เข้าสู่ระบบ"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("เข้าสู่ระบบด้วยอีเมล"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("ลายเซ็นของลูกค้า"),
        "size": MessageLookupByLibrary.simpleMessage("ขนาด"),
        "skip": MessageLookupByLibrary.simpleMessage("ข้าม"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("การตลาดผ่านสื่อโซเชียล"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "ขอโทษ, คุณไม่มีสิทธิ์เข้าถึงบริการนี้"),
        "startDate": MessageLookupByLibrary.simpleMessage("วันที่เริ่มต้น"),
        "startNewSale": MessageLookupByLibrary.simpleMessage("เริ่มขายใหม่"),
        "startTypingToSearch":
            MessageLookupByLibrary.simpleMessage("เริ่มพิมพ์เพื่อค้นหา"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "อยู่ริมแรมของความล้ำค่าด้านเทคโนโลยีโดยไม่มีค่าใช้จ่ายเพิ่มเติม อัปเดตไม่จำกัดของ Pos Saas POS ของเรา รับรองว่าคุณจะมีเครื่องมือและคุณสมบัติล่าสุดเสมอที่ปลายนิ้วคุณ รับรองว่าธุรกิจของคุณจะคงอยู่ในจุดขอบตัดต่อ."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("ยังไม่ชำระ"),
        "stock": MessageLookupByLibrary.simpleMessage("สต็อก"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("สต็อกเป็นสิ่งจำเป็น"),
        "stockList": MessageLookupByLibrary.simpleMessage("รายการสินค้าคงคลัง"),
        "stocks": MessageLookupByLibrary.simpleMessage("สต็อก"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "ต้องการสิทธิ์การเข้าถึงที่จัดเก็บเพื่อสร้างไฟล์ Excel"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("รายการภาษีย่อย"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("ภาษีย่อย"),
        "subTotal": MessageLookupByLibrary.simpleMessage("ยอดรวมย่อย"),
        "submit": MessageLookupByLibrary.simpleMessage("ส่ง"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "สมัครสมาชิกช่องของเรา\nYoutube"),
        "subscription": MessageLookupByLibrary.simpleMessage("การสมัครสมาชิก"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("เสร็จสมบูรณ์"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("ออกจากระบบสำเร็จ"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("อัปเดตสำเร็จ"),
        "supplier": MessageLookupByLibrary.simpleMessage("ผู้จัดจำหน่าย"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("ชื่อผู้จัดจำหน่าย"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("รหัส SWIFT"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "เอกสารรับรองความถูกต้องเช่นใบขับขี่ บัตรประจำตัวประชาชนหรือหนังสือเดินทาง"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "นำบัตรประชาชนเพื่อตรวจสอบข้อมูลของคุณ"),
        "tap": MessageLookupByLibrary.simpleMessage("แตะ"),
        "tax": MessageLookupByLibrary.simpleMessage("ภาษี"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("กลุ่มภาษี"),
        "taxPercentage":
            MessageLookupByLibrary.simpleMessage("เปอร์เซ็นต์ภาษี"),
        "taxRate": MessageLookupByLibrary.simpleMessage("อัตราภาษี"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "อัตราภาษี - จัดการอัตราภาษีของคุณ"),
        "taxReport": MessageLookupByLibrary.simpleMessage("รายงานภาษี"),
        "taxType": MessageLookupByLibrary.simpleMessage("ประเภทภาษี"),
        "taxes": MessageLookupByLibrary.simpleMessage("ภาษี"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("ข้อกำหนดและเงื่อนไข"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("ข้อกำหนดการใช้งาน"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("ข้อกำหนดและความเป็นส่วนตัว"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "ขอบคุณสำหรับการชำระค่าใช้จ่ายคงค้างของคุณ"),
        "thankYou": MessageLookupByLibrary.simpleMessage("ขอบคุณ"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("ขอบคุณสำหรับการซื้อของคุณ"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "บัญชีผู้ใช้มีอยู่แล้วสำหรับอีเมลนี้"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "ไฟล์ Excel ได้ถูกดาวน์โหลดแล้ว"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "ชื่อบอกทุกสิ่ง ด้วย Pos Saas POS Unlimited ไม่มีข้อจำกัดในการใช้งานของคุณ ไม่ว่าคุณจะประมวลผลรายการไม่กี่รายการหรือประสบการณ์การมีลูกค้ามากมาย คุณสามารถดำเนินการอย่างมั่นใจโดยรู้ว่าคุณไม่ถูกจำกัดด้วยขีดจำกัด"),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "รหัสผ่านที่ให้มามีความอ่อนแอเกินไป"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "การขายจะถูกลบและข้อมูลทั้งหมดจะถูกลบเกี่ยวกับการซื้อครั้งนี้ คุณแน่ใจที่จะลบหรือไม่"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "การขายจะถูกลบและข้อมูลทั้งหมดจะถูกลบเกี่ยวกับการขายนี้ คุณแน่ใจที่จะลบหรือไม่"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "ผู้ใช้จะถูกลบและข้อมูลทั้งหมดจะถูกลบออกจากบัญชีของคุณ คุณแน่ใจหรือไม่ที่จะลบ?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "ผู้ใช้จะถูกลบและข้อมูลทั้งหมดจะถูกลบจากบัญชีของคุณ คุณแน่ใจหรือไม่ที่จะลบสิ่งนี้"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("บริการจากบุคคลที่สาม"),
        "thisCategoryCannotBeDeleted":
            MessageLookupByLibrary.simpleMessage("ไม่สามารถลบหมวดหมู่นี้ได้"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(เดือนนี้)"),
        "thisProductAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("ผลิตภัณฑ์นี้ถูกเพิ่มแล้ว"),
        "title": MessageLookupByLibrary.simpleMessage("หัวข้อ"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("ชื่อไม่สามารถเป็นค่าว่าง"),
        "to": MessageLookupByLibrary.simpleMessage("ถึง"),
        "toDate": MessageLookupByLibrary.simpleMessage("ถึงวันที่"),
        "today": MessageLookupByLibrary.simpleMessage("วันนี้"),
        "total": MessageLookupByLibrary.simpleMessage("รวม"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("ยอดรวม"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("ยอดรวมที่เก็บได้"),
        "totalDue": MessageLookupByLibrary.simpleMessage("ยอดคงค้างทั้งหมด"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("รวมค่าใช้จ่าย"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("ขาดทุนรวม"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("ยอดชำระรวมทั้งหมด"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("ราคารวม"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("ผลิตภัณฑ์ทั้งหมด"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("กำไรทั้งหมด"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("ยอดรวมการซื้อ"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("จำนวนเงินรวมที่คืน"),
        "totalReturns":
            MessageLookupByLibrary.simpleMessage("จำนวนการคืนทั้งหมด"),
        "totalSale": MessageLookupByLibrary.simpleMessage("ยอดขายรวม"),
        "totalStock": MessageLookupByLibrary.simpleMessage("ยอดสต็อกทั้งหมด"),
        "totalValue": MessageLookupByLibrary.simpleMessage("มูลค่ารวม"),
        "totalVat": MessageLookupByLibrary.simpleMessage("ภาษีมูลค่าเพิ่มรวม"),
        "totals": MessageLookupByLibrary.simpleMessage("รวม: "),
        "transaction": MessageLookupByLibrary.simpleMessage("ธุรกรรม"),
        "transactionId": MessageLookupByLibrary.simpleMessage("รหัสธุรกรรม"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("ลองอีกครั้ง"),
        "twitter": MessageLookupByLibrary.simpleMessage("ทวิตเตอร์"),
        "type": MessageLookupByLibrary.simpleMessage("ประเภท"),
        "unitName": MessageLookupByLibrary.simpleMessage("ชื่อหน่วย"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("ราคาต่อหน่วย"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("ราคาต่อหน่วย"),
        "units": MessageLookupByLibrary.simpleMessage("หน่วย"),
        "unlimited": MessageLookupByLibrary.simpleMessage("ไม่จำกัด"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("การใช้งานไม่จำกัด"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "ปลดล็อคศักยภาพที่เต็มรูปแบบของ Pos Saas POS ด้วยการฝึกอบรมที่กำหนดเองซึ่งนำโดยทีมผู้เชี่ยวชาญของเรา จากเรื่องพื้นฐานถึงเทคนิคขั้นสูง เรารับรองว่าคุณจะมีความรู้เพียงพอในการใช้ทุกด้านของระบบเพื่อเพิ่มประสิทธิภาพของธุรกิจของคุณ."),
        "unpaid": MessageLookupByLibrary.simpleMessage("ยังไม่ได้ชำระ"),
        "update": MessageLookupByLibrary.simpleMessage("อัปเดต"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("อัปเดตการติดต่อ"),
        "updateNow": MessageLookupByLibrary.simpleMessage("อัปเดตตอนนี้"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("อัปเดตผลิตภัณฑ์"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "อัปเดตแผนของคุณก่อน กำหนดของคุณหมดแล้ว"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("อัปเดตโปรไฟล์ของคุณ"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "อัปเดตโปรไฟล์ของคุณเพื่อเชื่อมต่อกับแพทย์ของคุณให้ได้รับความประทับใจที่ดีขึ้น"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "อัปเดตโปรไฟล์เพื่อเชื่อมต่อกับลูกค้าของคุณด้วยความประทับใจที่ดีขึ้น"),
        "updated": MessageLookupByLibrary.simpleMessage("อัปเดตแล้ว"),
        "upload": MessageLookupByLibrary.simpleMessage("อัปโหลด"),
        "uploadDocument": MessageLookupByLibrary.simpleMessage("อัปโหลดเอกสาร"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("อัปโหลดเสร็จสิ้น"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("อัปโหลดไฟล์"),
        "usbC": MessageLookupByLibrary.simpleMessage("USB C"),
        "use": MessageLookupByLibrary.simpleMessage("ใช้"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("ใช้ Pos Saas"),
        "useOfTheSystem": MessageLookupByLibrary.simpleMessage("การใช้ระบบ"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("ผู้ใช้ถูกลบแล้ว"),
        "userRole": MessageLookupByLibrary.simpleMessage("บทบาทของผู้ใช้"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("รายละเอียดบทบาทผู้ใช้"),
        "userTitle": MessageLookupByLibrary.simpleMessage("ชื่อผู้ใช้"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "ชื่อผู้ใช้ไม่สามารถว่างเปล่าได้"),
        "value": MessageLookupByLibrary.simpleMessage("ค่า"),
        "vatDoesNotApply": MessageLookupByLibrary.simpleMessage("VAT ไม่ใช้"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("ยืนยัน OTP"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("ยืนยันหมายเลขโทรศัพท์"),
        "viewAll": MessageLookupByLibrary.simpleMessage("ดูทั้งหมด"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("ดูรายละเอียด"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("ลูกค้าเดินเข้า"),
        "warehouse": MessageLookupByLibrary.simpleMessage("คลังสินค้า"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("คลังสินค้ามีอยู่แล้ว"),
        "warehouseList":
            MessageLookupByLibrary.simpleMessage("รายชื่อคลังสินค้า"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("ชื่อคลังสินค้า"),
        "warranty": MessageLookupByLibrary.simpleMessage("การรับประกัน"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "เราได้ส่งอีเมลพร้อมคำแนะนำเกี่ยวกับวิธีการรีเซ็ตรหัสผ่านไปที่:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "เราอาจใช้บริการจากบุคคลที่สามเพื่อสนับสนุนฟังก์ชันของแอปของเรา เช่นผู้ให้บริการการวิเคราะห์และผู้ประมวลผลการชำระเงิน เมื่อคุณใช้แอปของเรา บริการจากบุคคลที่สามเหล่านี้อาจจะเก็บข้อมูลเกี่ยวกับคุณ โปรดทราบว่าเราไม่รับผิดชอบต่อวิธีการรักษาความเป็นส่วนตัวของบริการจากบุคคลที่สามเหล่านี้"),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "เราใช้มาตรฐานในอุตสาหกรรมเพื่อคุ้มครองข้อมูลส่วนบุคคลของคุณ รวมถึงการเข้ารหัสและการเก็บข้อมูลที่ปลอดภัย เรายังจำกัดการเข้าถึงข้อมูลของคุณให้กับบุคคลที่ได้รับอนุญาตเท่านั้น"),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "เราเข้าใจความสำคัญของการดำเนินงานโดยไม่ขัดข้อง นั่นเหมือนเป็นเหตุผลที่บริการของเราตลอด 24 ชั่วโมงพร้อมให้ความช่วยเหลือคุณไม่ว่าจะเป็นคำถามรวดเร็วหรือปัญหาที่ครอบคลุม ติดต่อเราได้ทุกเวลาทุกที่ผ่านทางโทรศัพท์หรือ WhatsApp เพื่อสัมผัสบริการที่ไม่เหมือนใคร"),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "เราใช้ข้อมูลส่วนบุคคลของคุณเพื่อให้คุณได้รับประสบการณ์ที่ดีที่สุดในแอปของเรา รวมถึงการปรับให้เหมาะกับคำแนะนำเนื้อหาของคุณ การเชื่อมต่อคุณกับผู้เชี่ยวชาญ และการพัฒนาฟังก์ชันของแอปของเรา เราอาจใช้ข้อมูลของคุณเพื่อติดต่อคุณเกี่ยวกับข้อมูลการอัปเดต โปรโมชั่น หรือข้อมูลอื่นที่เกี่ยวข้องกับแอปของเรา"),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "เราจะตรวจสอบการชำระเงินและอนุมัติภายใน 1-2 ชั่วโมง"),
        "weekly": MessageLookupByLibrary.simpleMessage("รายสัปดาห์"),
        "weight": MessageLookupByLibrary.simpleMessage("น้ำหนัก"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("มีอะไรใหม่"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("ผู้ขายส่ง"),
        "wholeSalePrice": MessageLookupByLibrary.simpleMessage("ราคาขายส่ง"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("ราคาขายส่ง"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("ผู้ค้าส่ง"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("จะถูกเพิ่มเร็วๆ นี้"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("จะหมดอายุที่"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("เขียนข้อความของคุณที่นี่"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("OTP ไม่ถูกต้อง"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "รหัสผ่านที่ให้มาไม่ถูกต้องสำหรับผู้ใช้รายนั้น"),
        "yearly": MessageLookupByLibrary.simpleMessage("รายปี"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("ใช่ ลบอย่างถาวร"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("คุณไม่ใช่ผู้ใช้ที่ถูกต้อง"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("คุณกำลังใช้งาน"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "คุณไม่สามารถชำระเงินเกินกว่าที่ค้างชำระได้"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("คุณได้รับอีเมล"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "คุณเข้าสู่ระบบสำเร็จแล้ว อยู่กับ Pos Saas ไปเถอะ"),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("คุณต้องให้สิทธิ์"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "คุณต้องเข้าสู่ระบบใหม่ในบัญชีของคุณ"),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "คุณต้องตรวจสอบตัวตนก่อนที่คุณจะซื้อ"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("ข้อความของคุณยังคงเหลือ"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("แพคเกจของคุณ"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "แพคเกจของคุณจะหมดอายุใน 5 วัน")
      };
}
