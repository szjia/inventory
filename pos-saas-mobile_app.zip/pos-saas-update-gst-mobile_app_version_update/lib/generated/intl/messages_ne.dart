// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a ne locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'ne';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("बिल प्लिज"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("जारी राख्नुहोस्"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("जीएसटी नम्बर"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("M.R.P"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("एमआरपी आवश्यक छ"),
        "OK": MessageLookupByLibrary.simpleMessage("ठीक छ"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("पीओएस एसएएएस"),
        "Paypal": MessageLookupByLibrary.simpleMessage("पेपल"),
        "PhNo": MessageLookupByLibrary.simpleMessage("फोन नं."),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("रेजोरपय"),
        "SL": MessageLookupByLibrary.simpleMessage("क्रम"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT कोड"),
        "Snacks": MessageLookupByLibrary.simpleMessage("स्न्याक्स"),
        "TAX": MessageLookupByLibrary.simpleMessage("कर"),
        "Uploading": MessageLookupByLibrary.simpleMessage("अपलोड गर्दै"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("प्रयोगकर्ता शीर्षक"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "तपाइंको प्याकेज आज समाप्त हुनेछ\n\nकृपया पुन: किन्नुहोस्"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) The System is provided solely for the\npurpose of facilitating point of sale\ntransactions andrelatedactivities in your\nbusiness."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) To use the System, you may be\nrequired to create an account. You\nagree to provide accurate, current, and\ncomplete information during\nthe registration process and toupdate\nsuchinformationto keep itaccurate\nand complete."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("अप्लिकेशनको बारेमा"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("हाम्रो बारेमा"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Acceptance of Terms"),
        "accountName": MessageLookupByLibrary.simpleMessage("खाता नाम"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("खाता नम्बर"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Account Registration"),
        "acton": MessageLookupByLibrary.simpleMessage("कार्य"),
        "add": MessageLookupByLibrary.simpleMessage("थप्नुहोस्"),
        "addBrand": MessageLookupByLibrary.simpleMessage("ब्र्याण्ड थप्नुहोस्"),
        "addCategory": MessageLookupByLibrary.simpleMessage("श्रेणी थप्नुहोस्"),
        "addContact": MessageLookupByLibrary.simpleMessage("संपर्क थप्नुहोस्"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("ग्राहक थप्नुहोस्"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("वितरण थप्नुहोस्"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("विवरण थप्नुहोस्"),
        "addDescription": MessageLookupByLibrary.simpleMessage("नोट थप्नुहोस्"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("छूट थप्नुहोस्"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("परिचयपत्र आइडी थप्नुहोस्"),
        "addDucument": MessageLookupByLibrary.simpleMessage("कागजात थप्नुहोस्"),
        "addExpense": MessageLookupByLibrary.simpleMessage("खर्च थप्नुहोस्"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("खर्च श्रेणी थप्नुहोस्"),
        "addItems": MessageLookupByLibrary.simpleMessage("वस्त्रहरू थप्नुहोस्"),
        "addNew": MessageLookupByLibrary.simpleMessage("नयाँ थप्नुहोस्"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("नयाँ ठेगाना थप्नुहोस्"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("नयाँ उत्पाद थप्नुहोस्"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("नयाँ कर थप्नुहोस्"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "एकल/बहु कर प्रकारसँग नयाँ कर थप्नुहोस्"),
        "addNote": MessageLookupByLibrary.simpleMessage("नोट थप्नुहोस्"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("पहिले उत्पादन थप्नुहोस्"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("प्रोमो कोड थप्नुहोस्"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("क्रय थप्नुहोस्"),
        "addSales": MessageLookupByLibrary.simpleMessage("बिक्री थप्नुहोस्"),
        "addSuccessful": MessageLookupByLibrary.simpleMessage("सफल थपियो"),
        "addUnit": MessageLookupByLibrary.simpleMessage("इकाइ थप्नुहोस्"),
        "addUserRole": MessageLookupByLibrary.simpleMessage(
            "प्रयोगकर्ता भूमिका थप्नुहोस्"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("सफलतापूर्वक थपियो"),
        "addedToCart": MessageLookupByLibrary.simpleMessage("कार्टमा थपियो"),
        "address": MessageLookupByLibrary.simpleMessage("ठेगाना"),
        "admin": MessageLookupByLibrary.simpleMessage("व्यवस्थापक"),
        "all": MessageLookupByLibrary.simpleMessage("सबै"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("सबै व्यवसायिक समाधानहरू"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("पहिल्यै थपिएको"),
        "alreadyExists":
            MessageLookupByLibrary.simpleMessage("पहिले नै अस्तित्वमा छ"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("पहिले नै खाता छ?"),
        "amount": MessageLookupByLibrary.simpleMessage("रकम"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "एक इमेल पठाइएको छ\\nतपाईँको इनबक्स जाँच गर्नुहोस्"),
        "androidIOSAppSupport":
            MessageLookupByLibrary.simpleMessage("एन्ड्रोइड र आईओएस एप समर्थन"),
        "applicableTax": MessageLookupByLibrary.simpleMessage("लागु हुने कर"),
        "apply": MessageLookupByLibrary.simpleMessage("लागू गर्नुहोस्"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "के तपाईं यो इनभ्वाइस हटाउन पक्का हुनुहुन्छ?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "के तपाईं यो बिक्री हटाउन पक्का हुनुहुन्छ?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "के तपाइँ यो प्रयोगकर्ता मेट्न निश्चित हुनुहुन्छ?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "के तपाईँ यस करलाई मेटाउन निश्चित हुनुहुन्छ?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "के तपाईँ यस कर समूहलाई मेटाउन निश्चित हुनुहुन्छ?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "के तपाईँ यो गोदाम मेटाउन चाहानुहुन्छ?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "के तपाईं यस प्रयोगकर्ता लाई मेटाउन चाहनुहुन्छ?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("अधिकार प्राप्त हस्ताक्षर"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) You are responsible for\nmaintainingthe confidentiality of your\naccount and password andfor restricting\naccess to your account. You accept\nresponsibility for all activities that\noccur under your account."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) You must be at least 18 years old or the\nlegal age of majority in your jurisdiction to\nuse the System."),
        "backSide": MessageLookupByLibrary.simpleMessage("पछाडीको तर्फ"),
        "backToHome":
            MessageLookupByLibrary.simpleMessage("हाम्रो गृहमा फर्किनुहोस्"),
        "balance": MessageLookupByLibrary.simpleMessage("संतुलन"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("बंगलादेश"),
        "bank": MessageLookupByLibrary.simpleMessage("बैंक"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("बैंक खाता मुद्रा"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("बैंक खाता मुद्रा"),
        "bankInformation": MessageLookupByLibrary.simpleMessage("बैंक जानकारी"),
        "bankName": MessageLookupByLibrary.simpleMessage("बैंकको नाम"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("बैंक ट्रान्सफर"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("बारकोड फेला परेको छ"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("बिल/इनभ्वाइस"),
        "billTo":
            MessageLookupByLibrary.simpleMessage("कसको नाममा बिल बुझाउनुहोस्"),
        "branchName": MessageLookupByLibrary.simpleMessage("ब्राञ्चको नाम"),
        "brand": MessageLookupByLibrary.simpleMessage("ब्र्याण्ड"),
        "brandName": MessageLookupByLibrary.simpleMessage("ब्र्याण्डको नाम"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("थोक \nअपलोड"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("व्यापार कोटि"),
        "buy": MessageLookupByLibrary.simpleMessage("किन्नुहोस्"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("प्रीमियम योजना किन्नुहोस्"),
        "buySms": MessageLookupByLibrary.simpleMessage("SMS किन्नुहोस्"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "By accessing or using the Point of Sale (POS) System (the \"System\") provided by [Your Company Name] (\"Company\"), you agree to be bound by these Terms of Use. If you do not agree to these Terms of Use, do not use the System."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) You are responsible for ensuring that your\naccess to and use of the System is in\ncompliance with all applicable laws and\nregulations."),
        "cacel": MessageLookupByLibrary.simpleMessage("रद्द गर्नुहोस्"),
        "call": MessageLookupByLibrary.simpleMessage("कल"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "आपतकालीन समर्थनको लागि कल गर्नुहोस्"),
        "camera": MessageLookupByLibrary.simpleMessage("क्यामेरा"),
        "cancel": MessageLookupByLibrary.simpleMessage("रद्द गर्नुहोस्"),
        "cancelAllProduct": MessageLookupByLibrary.simpleMessage(
            "सभी उत्पादनहरू रद्द गर्नुहोस्"),
        "capacity": MessageLookupByLibrary.simpleMessage("क्षमता"),
        "card": MessageLookupByLibrary.simpleMessage("कार्ड"),
        "cash": MessageLookupByLibrary.simpleMessage("नगद"),
        "cashFree": MessageLookupByLibrary.simpleMessage("क्यास फ्री"),
        "categories": MessageLookupByLibrary.simpleMessage("श्रेणीहरू"),
        "category": MessageLookupByLibrary.simpleMessage("श्रेणी"),
        "categoryName": MessageLookupByLibrary.simpleMessage("श्रेणी नाम"),
        "categoryNameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("श्रेणी नाम पहिले नै मौजूद छ"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("श्रेणीको नाम"),
        "change": MessageLookupByLibrary.simpleMessage("परिवर्तन गर्नुहोस्?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("पासवर्ड परिवर्तन गर्नुहोस्"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("ईमेल हेर्नुहोस्"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("कुनै ग्राहक छनौट गर्नुहोस्"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("कुनै प्रदायक छनौट गर्नुहोस्"),
        "choseYourFeature": MessageLookupByLibrary.simpleMessage(
            "तपाइंको सुविधा चयन गर्नुहोस्"),
        "clarence": MessageLookupByLibrary.simpleMessage("क्लियरन्स"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("जडानका लागि क्लिक गर्नुहोस्"),
        "close": MessageLookupByLibrary.simpleMessage("बन्द गर्नुहोस्"),
        "color": MessageLookupByLibrary.simpleMessage("रङ्ग"),
        "combinationOfMultipleTaxes":
            MessageLookupByLibrary.simpleMessage("(धेरै करहरूको संयोजन)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("छिट्टै आउँदैछ"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("कम्पनीको ठेगाना"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("कम्पनी र दुकानको नाम"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("कम्पनी र व्यापारको नाम"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("लेनदेन पूरा गर्नुहोस्"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("पासवर्ड पुष्टि गर्नुहोस्"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("फिर्ता पुष्टि गर्नुहोस्"),
        "congratulations": MessageLookupByLibrary.simpleMessage("अभिनन्दन"),
        "contactUs":
            MessageLookupByLibrary.simpleMessage("हामीलाई सम्पर्क गर्नुहोस्"),
        "continu": MessageLookupByLibrary.simpleMessage("सुरु गर्नुहोस्"),
        "country": MessageLookupByLibrary.simpleMessage("देश"),
        "create": MessageLookupByLibrary.simpleMessage("सिर्जना गर्नुहोस्"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("मुफ्त खाता बनाउनुहोस्"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("सिर्जना गरिएको र सुरक्षित"),
        "currency": MessageLookupByLibrary.simpleMessage("मुद्रा"),
        "currentStock": MessageLookupByLibrary.simpleMessage("हालको भण्डार"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("कस्टम इनभ्वाइस ब्रान्डिङ"),
        "customer": MessageLookupByLibrary.simpleMessage("ग्राहक"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("ग्राहकका विवरण"),
        "customerGST": MessageLookupByLibrary.simpleMessage("ग्राहकको जीएसटी"),
        "customerName": MessageLookupByLibrary.simpleMessage("ग्राहकको नाम"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("दैनिक लेनदेन"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Dashboard Overview"),
        "dataSavedSuccessfully": MessageLookupByLibrary.simpleMessage(
            "डेटा सफलतापूर्वक सुरक्षित गरियो"),
        "date": MessageLookupByLibrary.simpleMessage("मिति"),
        "day": MessageLookupByLibrary.simpleMessage("दिन"),
        "dealer": MessageLookupByLibrary.simpleMessage("व्यापारी"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("डिलर मूल्य"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("डिफल्ट VAT प्रतिशत"),
        "delete": MessageLookupByLibrary.simpleMessage("मेटाउनुहोस्"),
        "deleting": MessageLookupByLibrary.simpleMessage("हटाइँदैछ"),
        "deliveryAddress": MessageLookupByLibrary.simpleMessage("वितरण ठेगाना"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("डेलिभरी ठेगानाहरू"),
        "deliveryCharge": MessageLookupByLibrary.simpleMessage("वितरण शुल्क"),
        "describtion": MessageLookupByLibrary.simpleMessage("वर्णन"),
        "description": MessageLookupByLibrary.simpleMessage("विवरण"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("विवरण खाली हुन सक्दैन"),
        "details": MessageLookupByLibrary.simpleMessage("विवरण"),
        "discount": MessageLookupByLibrary.simpleMessage("छुट"),
        "doNotDistrub":
            MessageLookupByLibrary.simpleMessage("बिचराम नदिनुहोस्"),
        "done": MessageLookupByLibrary.simpleMessage("गरेको"),
        "downloadExcelFormat": MessageLookupByLibrary.simpleMessage(
            "एक्सेल ढाँचा डाउनलोड गर्नुहोस्"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "डाउनलोड फोल्डरमा सफलतापूर्वक डाउनलोड गरियो"),
        "due": MessageLookupByLibrary.simpleMessage("बाकी"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("बाकी रकम: "),
        "dueCollection": MessageLookupByLibrary.simpleMessage("बाकीको संग्रह"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("बाँकी वसूली प्रतिवेदनहरू"),
        "dueList": MessageLookupByLibrary.simpleMessage("बाकीको सूची"),
        "dueReports": MessageLookupByLibrary.simpleMessage("बक्सिस प्रतिवेदन"),
        "duration": MessageLookupByLibrary.simpleMessage("अवधि"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("अवधि: देखि"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "सजिलो प्रयोग गर्ने मोबाइल पोस"),
        "edit": MessageLookupByLibrary.simpleMessage("सम्पादन गर्नुहोस्"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("क्रय बिल सम्पादन गर्नुहोस्"),
        "editSalesInvoice": MessageLookupByLibrary.simpleMessage(
            "बिक्री बिल सम्पादन गर्नुहोस्"),
        "editSocailMedia": MessageLookupByLibrary.simpleMessage(
            "सामाजिक मिडिया सम्पादन गर्नुहोस्"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("सफलतापूर्वक सम्पादन गरियो"),
        "editTax": MessageLookupByLibrary.simpleMessage("कर सम्पादन गर्नुहोस्"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("कर समूह सम्पादन गर्नुहोस्"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("गोदाम सम्पादन गर्नुहोस्"),
        "email": MessageLookupByLibrary.simpleMessage("इमेल"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("इमेल ठेगाना"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("इमेल खाली हुन सक्दैन"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "इमेल पठाइएको! कृपया आफ्नो इन्बक्स जाँच गर्नुहोस्"),
        "endDate": MessageLookupByLibrary.simpleMessage("समाप्ति मिति"),
        "enterAValidAmount": MessageLookupByLibrary.simpleMessage(
            "मान्य रकम प्रविष्ट गर्नुहोस्"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("वैध छुट प्रविष्ट गर्नुहोस्"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "मान्य फोन नम्बर प्रविष्ट गर्नुहोस्"),
        "enterAValidPrice": MessageLookupByLibrary.simpleMessage(
            "वैध मूल्य प्रविष्ट गर्नुहोस्"),
        "enterAValidQuantity": MessageLookupByLibrary.simpleMessage(
            "वैध मात्र प्रविष्ट गर्नुहोस्"),
        "enterAddress":
            MessageLookupByLibrary.simpleMessage("ठेगाना प्रविष्ट गर्नुहोस्"),
        "enterAmount":
            MessageLookupByLibrary.simpleMessage("रकम प्रविष्ट गर्नुहोस्।"),
        "enterBrandName": MessageLookupByLibrary.simpleMessage(
            "ब्र्याण्डको नाम प्रविष्ट गर्नुहोस्"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("क्षमता प्रविष्ट गर्नुहोस्"),
        "enterCategoryName": MessageLookupByLibrary.simpleMessage(
            "श्रेणीको नाम प्रविष्ट गर्नुहोस्"),
        "enterColor":
            MessageLookupByLibrary.simpleMessage("रङ्ग प्रविष्ट गर्नुहोस्"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "ग्राहकको जीएसटी नम्बर प्रविष्ट गर्नुहोस्"),
        "enterDealerPrice": MessageLookupByLibrary.simpleMessage(
            "डिलर मूल्य प्रविष्ट गर्नुहोस्"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("विवरण प्रविष्ट गर्नुहोस्"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("छुट प्रविष्ट गर्नुहोस्"),
        "enterExpenseDate": MessageLookupByLibrary.simpleMessage(
            "खर्च मिति प्रविष्ट गर्नुहोस्"),
        "enterFullAddress": MessageLookupByLibrary.simpleMessage(
            "पूरा ठेगाना प्रविष्ट गर्नुहोस्"),
        "enterInvoiceNumber": MessageLookupByLibrary.simpleMessage(
            "बिल नम्बर प्रविष्ट गर्नुहोस्"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "कम स्टक चेतावनीको मात्रा प्रविष्ट गर्नुहोस्"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("निर्माता प्रविष्ट गर्नुहोस्"),
        "enterMessageContent": MessageLookupByLibrary.simpleMessage(
            "सन्देश सामग्री प्रविष्ट गर्नुहोस्"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "M.R.P/खुद्रा मूल्य प्रविष्ट गर्नुहोस्"),
        "enterName":
            MessageLookupByLibrary.simpleMessage("नाम प्रविष्ट गर्नुहोस्"),
        "enterNote":
            MessageLookupByLibrary.simpleMessage("नोट प्रविष्ट गर्नुहोस्"),
        "enterPartyName": MessageLookupByLibrary.simpleMessage(
            "पार्टीको नाम प्रविष्ट गर्नुहोस्"),
        "enterPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "फोन नम्बर प्रविष्ट गर्नुहोस्"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "उत्पादको कोड प्रविष्ट गर्नुहोस् वा स्क्यान गर्नुहोस्"),
        "enterProductName": MessageLookupByLibrary.simpleMessage(
            "उत्पादको नाम प्रविष्ट गर्नुहोस्"),
        "enterPurchasePrice": MessageLookupByLibrary.simpleMessage(
            "क्रय मूल्य प्रविष्ट गर्नुहोस्"),
        "enterReferenceNumber": MessageLookupByLibrary.simpleMessage(
            "संदर्भ नम्बर प्रविष्ट गर्नुहोस्"),
        "enterSize":
            MessageLookupByLibrary.simpleMessage("साइज प्रविष्ट गर्नुहोस्"),
        "enterStocks":
            MessageLookupByLibrary.simpleMessage("स्टकहरू प्रविष्ट गर्नुहोस्"),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("कर दर प्रविष्ट गर्नुहोस्"),
        "enterTransactionId": MessageLookupByLibrary.simpleMessage(
            "लेनदेन आइडी प्रविष्ट गर्नुहोस्"),
        "enterType":
            MessageLookupByLibrary.simpleMessage("प्रकार प्रविष्ट गर्नुहोस्"),
        "enterUserTitle": MessageLookupByLibrary.simpleMessage(
            "प्रयोगकर्ता शीर्षक प्रवेश गर्नुहोस्"),
        "enterValidAmount": MessageLookupByLibrary.simpleMessage(
            "मान्य रकम प्रविष्ट गर्नुहोस्"),
        "enterWarehouseName": MessageLookupByLibrary.simpleMessage(
            "गोदाम नाम प्रविष्ट गर्नुहोस्"),
        "enterWeight":
            MessageLookupByLibrary.simpleMessage("वजन प्रविष्ट गर्नुहोस्"),
        "enterWholeSalePrice": MessageLookupByLibrary.simpleMessage(
            "होलसेल मूल्य प्रविष्ट गर्नुहोस्"),
        "enterYourDescriptionHere": MessageLookupByLibrary.simpleMessage(
            "यहाँ तपाइको विवरण प्रविष्ट गर्नुहोस्"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "तपाईंको इमेल ठेगाना प्रविष्ट गर्नुहोस्"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "तपाईंको प्रतिक्रिया शीर्षक प्रविष्ट गर्नुहोस्"),
        "enterYourGSTNumber": MessageLookupByLibrary.simpleMessage(
            "आफ्नो जीएसटी नम्बर प्रविष्ट गर्नुहोस्"),
        "enterYourMobileNumber": MessageLookupByLibrary.simpleMessage(
            "तपाइंको मोबाइल नम्बर प्रविष्ट गर्नुहोस्"),
        "enterYourName": MessageLookupByLibrary.simpleMessage(
            "तपाईंको नाम प्रविष्ट गर्नुहोस्"),
        "enterYourNumber": MessageLookupByLibrary.simpleMessage(
            "तपाईंको फोन नम्बर प्रविष्ट गर्नुहोस्"),
        "enterYourPassword": MessageLookupByLibrary.simpleMessage(
            "तपाईंको पासवर्ड प्रवेश गर्नुहोस्"),
        "enterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "तपाईंको फोन नम्बर प्रविष्ट गर्नुहोस्"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "तपाइंको लेनदेन आइडी प्रविष्ट गर्नुहोस्"),
        "error": MessageLookupByLibrary.simpleMessage("त्रुटि"),
        "excTax": MessageLookupByLibrary.simpleMessage("करमा बाहिर"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("एक्सेल अपलोडर"),
        "exclusive": MessageLookupByLibrary.simpleMessage("विशेष"),
        "expense": MessageLookupByLibrary.simpleMessage("खर्च"),
        "expenseCategory": MessageLookupByLibrary.simpleMessage("खर्च श्रेणी"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("खर्च मिति"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("खर्चको लागि"),
        "expenseReport": MessageLookupByLibrary.simpleMessage("खर्च प्रतिवेदन"),
        "expireDate": MessageLookupByLibrary.simpleMessage("समाप्ति मिति"),
        "expired": MessageLookupByLibrary.simpleMessage("समाप्त भएको"),
        "expiring": MessageLookupByLibrary.simpleMessage("समाप्त हुँदैछ"),
        "facebok": MessageLookupByLibrary.simpleMessage("फेसबुक"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("त्रुटीसँग असफल"),
        "fashion": MessageLookupByLibrary.simpleMessage("फेसन"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "विशेषताहरू महत्त्वपूर्ण भाग हुन् जसले Pos Saas लाई परम्परागत समाधानहरू भन्दा फरक बनाउँछ।"),
        "feedBack": MessageLookupByLibrary.simpleMessage("प्रतिक्रिया"),
        "firstName": MessageLookupByLibrary.simpleMessage("पहिलो नाम"),
        "followUsOnFacebook": MessageLookupByLibrary.simpleMessage(
            "हामीलाई फेसबुकमा फलो गर्नुहोस्"),
        "followUsOnTwitter": MessageLookupByLibrary.simpleMessage(
            "हामीलाई ट्विटरमा फलो गर्नुहोस्"),
        "fontSide": MessageLookupByLibrary.simpleMessage("फोन्ट साइड"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("असीमित प्रयोगका लागि"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("पासवर्ड भुल्नु भयो"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("पासवर्ड बिर्सेँ?"),
        "formDate": MessageLookupByLibrary.simpleMessage("मिति देखि"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("नि: शुल्क डाटा ब्याकअप"),
        "freeLifeTimeUpdate":
            MessageLookupByLibrary.simpleMessage("नि: शुल्क लाइफटाइम अपडेट"),
        "freePacakge":
            MessageLookupByLibrary.simpleMessage("नि: शुल्क प्याकेज"),
        "freePlan": MessageLookupByLibrary.simpleMessage("नि: शुल्क योजना"),
        "from": MessageLookupByLibrary.simpleMessage("(बाट"),
        "fullyPaid":
            MessageLookupByLibrary.simpleMessage("पूर्ण भुक्तान गरिएको"),
        "gallary": MessageLookupByLibrary.simpleMessage("ग्यालरी"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("PDF तयार गर्दै"),
        "getOtp":
            MessageLookupByLibrary.simpleMessage("ओटिपी प्राप्त गर्नुहोस्"),
        "govermentId": MessageLookupByLibrary.simpleMessage("सरकारी परिचयपत्र"),
        "guest": MessageLookupByLibrary.simpleMessage("अतिथि"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("कुनै खाता छैन?"),
        "history": MessageLookupByLibrary.simpleMessage("इतिहास"),
        "home": MessageLookupByLibrary.simpleMessage("गृहपृष्ठ"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "How We Protect Your Information"),
        "howWeUseYourInformation":
            MessageLookupByLibrary.simpleMessage("How We Use Your Information"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("पहिचान प्रमाणिकरण गर्नुहोस्"),
        "image": MessageLookupByLibrary.simpleMessage("तस्वीर"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("इनहाउस मेटाउन सकिँदैन"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("इनहाउस सम्पादन गर्न सकिँदैन"),
        "inWord": MessageLookupByLibrary.simpleMessage("शब्दमा"),
        "incTax": MessageLookupByLibrary.simpleMessage("करमा समावेश"),
        "inclusive": MessageLookupByLibrary.simpleMessage("समावेशी"),
        "increaseStock":
            MessageLookupByLibrary.simpleMessage("स्टक बढाउनुहोस्"),
        "inistrument": MessageLookupByLibrary.simpleMessage("यन्त्र"),
        "instragram": MessageLookupByLibrary.simpleMessage("इन्स्टाग्राम"),
        "invNo": MessageLookupByLibrary.simpleMessage("क्रमिक नम्बर"),
        "invoice": MessageLookupByLibrary.simpleMessage("चालान"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("बिल नम्बर"),
        "invoiceSetting": MessageLookupByLibrary.simpleMessage("बिल सेटिङ"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("चालान दृश्यकर्ता"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("वस्त्र थपियो"),
        "kg": MessageLookupByLibrary.simpleMessage("कि.ग्रा."),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("केवाइसी प्रमाणिकरण"),
        "language": MessageLookupByLibrary.simpleMessage("भाषा"),
        "lastName": MessageLookupByLibrary.simpleMessage("थर"),
        "ledger": MessageLookupByLibrary.simpleMessage("लेजर"),
        "lifeTimePurchase": MessageLookupByLibrary.simpleMessage("जीवनको लागि"),
        "link": MessageLookupByLibrary.simpleMessage("लिंक"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("लिंक्डइन"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("प्रत्यक्ष च्याट समर्थन"),
        "loading": MessageLookupByLibrary.simpleMessage("लोड हुँदैछ"),
        "logIn": MessageLookupByLibrary.simpleMessage("लग इन गर्नुहोस्"),
        "logOUt": MessageLookupByLibrary.simpleMessage("सकियो"),
        "logOut": MessageLookupByLibrary.simpleMessage("लगआउट गर्नुहोस्"),
        "login": MessageLookupByLibrary.simpleMessage("लग इन गर्नुहोस्"),
        "logo": MessageLookupByLibrary.simpleMessage("लोगो"),
        "loss": MessageLookupByLibrary.simpleMessage("हानि"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("हानि/फाइदा"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("हानि/फाइदा विवरण"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("हानि/नाफा रिपोर्ट"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("हानि/नाफा रिपोर्ट"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("कम स्टक चेतावनी"),
        "maan": MessageLookupByLibrary.simpleMessage("मान"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "ब्रान्डेड इनभ्वाइसहरूको साथ तपाईंको ग्राहकहरूमा स्थायी छाप बनाउनुहोस्। हाम्रो असीमित अपग्रेडले तपाइँको इनभ्वाइसहरू अनुकूलन गर्ने, तपाइँको ब्रान्ड पहिचानलाई सुदृढ गर्ने र ग्राहकको वफादारीलाई बढावा दिने पेशेवर टच थप्ने अद्वितीय फाइदा प्रदान गर्दछ।"),
        "manageYourBussinessWith": MessageLookupByLibrary.simpleMessage(
            "तपाईंको व्यापार प्रबन्ध गर्नुहोस् "),
        "manufactureDate": MessageLookupByLibrary.simpleMessage("निर्माण मिति"),
        "margin": MessageLookupByLibrary.simpleMessage("मार्जिन"),
        "masterCard": MessageLookupByLibrary.simpleMessage("मास्टर कार्ड"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("निर्माता"),
        "message": MessageLookupByLibrary.simpleMessage("सन्देश"),
        "messageHistory": MessageLookupByLibrary.simpleMessage("सन्देश इतिहास"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Pos Saas एप नि: शुल्क, प्रयोग गर्न सजिलो छ। वास्तवमा, यो संसारभरि सबै भन्दा राम्रो POS प्रणाली मध्ये एक हो।"),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas स्टक, खाता, बिक्री, खर्च र हानि / लाभ संग एक पूर्ण व्यापार समाधान छ।"),
        "mobile": MessageLookupByLibrary.simpleMessage("मोबाइल"),
        "mobilePayment":
            MessageLookupByLibrary.simpleMessage("मोबाइल भुक्तानी"),
        "monthly": MessageLookupByLibrary.simpleMessage("मासिक"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("थप जानकारी"),
        "name": MessageLookupByLibrary.simpleMessage(
            "तपाईंको नाम प्रविष्ट गर्नुहोस्।"),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("नाम पहिले नै मौजूद छ"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("नाम खाली हुन सक्दैन"),
        "next": MessageLookupByLibrary.simpleMessage("अर्को"),
        "noConnection": MessageLookupByLibrary.simpleMessage("कुनै जडान छैन"),
        "noData": MessageLookupByLibrary.simpleMessage("कुनै डाटा छैन"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("कुनै डाटा उपलब्ध छैन"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("कुनै डाटा फेला परेन"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("कुनै पनि इतिहास फेला परेन!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("कुनै उत्पादन भेटिएन"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("कुनै उप कर चयन गरिएको छैन"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("कुनै पनि लेनदेन फेला परेन!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "तपाईंको इमेलको लागि कुनै प्रयोगकर्ता फेला परेन।"),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "कुनै प्रयोगकर्ता भूमिका पाइएन"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("सक्रिय प्रयोगकर्ता होइन"),
        "notProvided":
            MessageLookupByLibrary.simpleMessage("प्रदान गरिएको छैन"),
        "note": MessageLookupByLibrary.simpleMessage("नोट"),
        "notes": MessageLookupByLibrary.simpleMessage("नोटहरू"),
        "notification": MessageLookupByLibrary.simpleMessage("सूचना"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("ओटीपी पठाइएको छ"),
        "office": MessageLookupByLibrary.simpleMessage("कार्यालय"),
        "ok": MessageLookupByLibrary.simpleMessage("ठिक छ"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS that contains a great deal of functionality, including sales tracking, inventory management."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "This system helps you improve your operations for your customers."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Our POS system should simplify daily operations automatically, making it easy to navigate."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("आरम्भिक शेष राख्नुहोस्"),
        "order": MessageLookupByLibrary.simpleMessage("अर्डर"),
        "other": MessageLookupByLibrary.simpleMessage("अन्य"),
        "otp": MessageLookupByLibrary.simpleMessage("बन्द गर्नुहोस्"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("स्टकमा छैन"),
        "pacakge": MessageLookupByLibrary.simpleMessage("प्याकेज"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("प्याकेज सुविधाहरू"),
        "paid": MessageLookupByLibrary.simpleMessage("भुक्तान गरिएको"),
        "paidAmount":
            MessageLookupByLibrary.simpleMessage("भुक्तान गरिएको रकम"),
        "parties": MessageLookupByLibrary.simpleMessage("पार्टीहरू"),
        "partiesList": MessageLookupByLibrary.simpleMessage("पार्टीहरूको सूची"),
        "partyGST": MessageLookupByLibrary.simpleMessage("पार्टीको जीएसटी"),
        "partyName": MessageLookupByLibrary.simpleMessage("पार्टीको नाम"),
        "password": MessageLookupByLibrary.simpleMessage("पासवर्ड"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "पासवर्ड र पुष्टिकरण पासवर्ड मिल्दैन"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("पासवर्ड खाली हुन सक्दैन"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("पासवर्ड मिल्दैन"),
        "payCash":
            MessageLookupByLibrary.simpleMessage("क्यास भुक्तानी गर्नुहोस्"),
        "payStack": MessageLookupByLibrary.simpleMessage("पेम स्ट्याक"),
        "payWithBkash": MessageLookupByLibrary.simpleMessage(
            "बिकाशको साथ भुक्तान गर्नुहोस्"),
        "payWithPaypal": MessageLookupByLibrary.simpleMessage(
            "पेपालको साथ भुक्तान गर्नुहोस्"),
        "payeeName":
            MessageLookupByLibrary.simpleMessage("भुक्तानकर्ता को नाम"),
        "payeeNumber":
            MessageLookupByLibrary.simpleMessage("भुक्तानकर्ता को नम्बर"),
        "payment": MessageLookupByLibrary.simpleMessage("भुक्तानी"),
        "paymentAmount":
            MessageLookupByLibrary.simpleMessage("भुक्तान गरिएको रकम"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("भुक्तान पूरा भएको छ"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("भुक्तान निर्देश:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("भुक्तानी विधि"),
        "paymentType": MessageLookupByLibrary.simpleMessage("भुक्तानको प्रकार"),
        "pdfView": MessageLookupByLibrary.simpleMessage("PDF दृश्य"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("व्यक्तिगत जानकारी"),
        "phone": MessageLookupByLibrary.simpleMessage("फोन"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("फोन नम्बर"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "फोन नम्बर पहिल्यै प्रयोग भएको छ"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("फोन नम्बर मान्य छैन"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("फोन नम्बर आवश्यक छ"),
        "pickAndUploadFile": MessageLookupByLibrary.simpleMessage(
            "फाइल चयन गर्नुहोस् र अपलोड गर्नुहोस्"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("समाप्ति मिति चयन गर्नुहोस्"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("प्रारम्भ मिति चयन गर्नुहोस्"),
        "plan": MessageLookupByLibrary.simpleMessage("योजना"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("कृपया मात्र थप्नुहोस्"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "कृपया तपाईंको इन्टरनेट कनेक्टिभिटी जाँच्नुहोस्"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "कृपया पहिलो प्रिन्टर जडान गर्नुहोस्"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "कृपया आफ्नो ब्लुटूथ प्रिन्टर जडान गर्नुहोस्"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "कृपया ठूलो पासवर्ड प्रविष्ट गर्नुहोस्"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "कृपया पासवर्ड पुष्टि गर्नुहोस्"),
        "pleaseEnterAPassword": MessageLookupByLibrary.simpleMessage(
            "कृपया पासवर्ड प्रविष्ट गर्नुहोस्"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "कृपया एक मान्य इमेल प्रविष्ट गर्नुहोस्"),
        "pleaseEnterName": MessageLookupByLibrary.simpleMessage(
            "कृपया नाम प्रविष्ट गर्नुहोस्"),
        "pleaseEnterPassword": MessageLookupByLibrary.simpleMessage(
            "कृपया पासवर्ड प्रविष्ट गर्नुहोस्"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "कृपया पासवर्ड रिसेट लिंक प्राप्त गर्नका लागि तपाईंको इमेल ठेगाना तल प्रविष्ट गर्नुहोस्।"),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "कृपया लेनदेन नम्बर प्रविष्ट गर्नुहोस्"),
        "pleaseInterAmount": MessageLookupByLibrary.simpleMessage(
            "कृपया रकम प्रविष्ट गर्नुहोस्"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "कृपया पहिलो श्रेणी चयन गर्नुहोस्"),
        "pleaseSelectAPlan": MessageLookupByLibrary.simpleMessage(
            "कृपया एक योजना चयन गर्नुहोस्"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "कृपया व्यापार श्रेणी चयन गर्नुहोस्"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "कृपया एप प्रयोग गर्नका लागि मान्य खरीद कोड प्रयोग गर्नुहोस्"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Pos Saas द्वारा प्राधिकृत"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("द्वारा संचालित"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("प्रिमियम ग्राहक समर्थन"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("प्रिमियम योजना"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("पूर्व पेस रकमहरू"),
        "price": MessageLookupByLibrary.simpleMessage("मूल्य"),
        "print": MessageLookupByLibrary.simpleMessage("मुद्रण गर्नुहोस्"),
        "printingOption": MessageLookupByLibrary.simpleMessage("मुद्रण विकल्प"),
        "privacyPolicy": MessageLookupByLibrary.simpleMessage("गोपनीयता नीति"),
        "product": MessageLookupByLibrary.simpleMessage("उत्पाद"),
        "productCode": MessageLookupByLibrary.simpleMessage("उत्पादको कोड"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("उत्पादनको कोड आवश्यक छ"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("उत्पादन कोड/नाम"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("उत्पादन विवरण"),
        "productDetails": MessageLookupByLibrary.simpleMessage("उत्पादन विवरण"),
        "productList": MessageLookupByLibrary.simpleMessage("उत्पाद सूची"),
        "productName": MessageLookupByLibrary.simpleMessage("उत्पादको नाम"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "यो गोदाममा उत्पादनको नाम पहिल्यै छ"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "उत्पादको नाम पहिले नै थपिएको छ"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("उत्पादनको नाम आवश्यक छ"),
        "products": MessageLookupByLibrary.simpleMessage("उत्पादनहरू"),
        "profile": MessageLookupByLibrary.simpleMessage("प्रोफाइल"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("प्रोफाइल सम्पादन"),
        "profit": MessageLookupByLibrary.simpleMessage("फाइदा"),
        "promo": MessageLookupByLibrary.simpleMessage("प्रमो"),
        "promoCode": MessageLookupByLibrary.simpleMessage("प्रमो कोड"),
        "purchase": MessageLookupByLibrary.simpleMessage("क्रय"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage("खरिद अलार्म"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("खरिद पुष्टि गरिएको छ"),
        "purchaseDetails": MessageLookupByLibrary.simpleMessage("क्रय विवरण"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("खरीद इनभ्वाइस"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("क्रय सूची"),
        "purchaseNow":
            MessageLookupByLibrary.simpleMessage("अहिलेसम्म किनिदिनुहोस्"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("प्रीमियम योजना किन्नुहोस्"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("क्रय मूल्य"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("किन्ने मूल्य आवश्यक छ"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("क्रय प्रतिवेदन"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("क्रय प्रतिवेदन"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("खरीद विवरणहरू"),
        "purchaseReturn": MessageLookupByLibrary.simpleMessage("खरीद फिर्ता"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("खरीद फिर्ता रिपोर्ट"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("खरीदको संक्रमण"),
        "qty": MessageLookupByLibrary.simpleMessage("मात्रा"),
        "quantity": MessageLookupByLibrary.simpleMessage("मात्रा"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("हालको लेनदेनहरू"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("पिन प्राप्त गरियो"),
        "referenceNumber": MessageLookupByLibrary.simpleMessage("संदर्भ नम्बर"),
        "register": MessageLookupByLibrary.simpleMessage("रेजिष्टर गर्नुहोस्"),
        "registering": MessageLookupByLibrary.simpleMessage("पंजीकरण गर्दै"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("बाकी रकम"),
        "remove": MessageLookupByLibrary.simpleMessage("हटाउनुहोस्"),
        "reports": MessageLookupByLibrary.simpleMessage("प्रतिवेदनहरू"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("अनुरोध पठाइएको छ"),
        "resendCode": MessageLookupByLibrary.simpleMessage("पुन: पठाउनुहोस्"),
        "resendOtp":
            MessageLookupByLibrary.simpleMessage("ओटिपी पुनः पठाउँदै : "),
        "retailer": MessageLookupByLibrary.simpleMessage("खुद्रा विक्रेता"),
        "retur": MessageLookupByLibrary.simpleMessage("फिर्ता"),
        "returN": MessageLookupByLibrary.simpleMessage("फिर्ता"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("फिर्ता रकम"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("फिर्ता रकम"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("फिर्ता मात्र"),
        "revenue": MessageLookupByLibrary.simpleMessage("राजस्व"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "आफ्नो व्यापार डेटा सहजै सुरक्षित गर्नुहोस्। हाम्रो Pos Saas POS Unlimited अपग्रेडमा नि:शुल्क डाटा ब्याकअप समावेश छ, तपाइँको बहुमूल्य जानकारीलाई कुनै पनि अप्रत्याशित घटनाहरूबाट सुरक्षित गरिएको छ भन्ने सुनिश्चित गर्दै। साँच्चै महत्त्वपूर्ण कुराहरूमा ध्यान दिनुहोस् - तपाईंको व्यापार वृद्धि।"),
        "saleAmount": MessageLookupByLibrary.simpleMessage("बिक्री रकम"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("बिक्री विवरण"),
        "salePrice": MessageLookupByLibrary.simpleMessage("बिक्री मूल्य"),
        "saleReports": MessageLookupByLibrary.simpleMessage("बिक्री प्रतिवेदन"),
        "saleReportss": MessageLookupByLibrary.simpleMessage("बेचि विवरणहरू"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("बिक्री फिर्ता"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("बिक्री फिर्ता रिपोर्ट"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("बिक्री सेटिङ"),
        "sales": MessageLookupByLibrary.simpleMessage("बिक्री"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("Sale & Purchase Reports"),
        "salesList": MessageLookupByLibrary.simpleMessage("बिक्री सूची"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("बिक्री फिर्ता"),
        "save": MessageLookupByLibrary.simpleMessage("बचत गर्नुहोस्"),
        "saveAndPublish": MessageLookupByLibrary.simpleMessage(
            "सुरक्षित गर्नुहोस् र प्रकाशित गर्नुहोस्"),
        "saveChanges": MessageLookupByLibrary.simpleMessage(
            "परिवर्तनहरू सुरक्षित गर्नुहोस्"),
        "saving": MessageLookupByLibrary.simpleMessage("बचत गर्दै"),
        "scanProductQRCode": MessageLookupByLibrary.simpleMessage(
            "उत्पादनको QR कोड स्क्यान गर्नुहोस्"),
        "search": MessageLookupByLibrary.simpleMessage("खोज्नुहोस्"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "उत्पादन कोड वा नाम द्वारा खोज्नुहोस्"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("सबै प्रमो कोड हेर्नुहोस्"),
        "select": MessageLookupByLibrary.simpleMessage("चयन गर्नुहोस्"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "फिर्ताका लागि उत्पादन चयन गर्नुहोस्"),
        "selectBrand":
            MessageLookupByLibrary.simpleMessage("ब्राण्ड चयन गर्नुहोस्"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("श्रेणी चयन गर्नुहोस्"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("संपर्कहरू चयन गर्नुहोस्"),
        "selectProductCategory": MessageLookupByLibrary.simpleMessage(
            "उत्पादन श्रेणी चयन गर्नुहोस्"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("दोकान श्रेणी चयन गर्नुहोस्"),
        "selectTax": MessageLookupByLibrary.simpleMessage("कर चयन गर्नुहोस्"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("कर प्रकार चयन गर्नुहोस्"),
        "selectUnit":
            MessageLookupByLibrary.simpleMessage("एकाइ चयन गर्नुहोस्"),
        "selectvariations": MessageLookupByLibrary.simpleMessage(
            "मिलाउने विविधता छनौट गर्नुहोस्: "),
        "seller": MessageLookupByLibrary.simpleMessage("बिक्रेता"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("द्वारा बिक्री"),
        "send": MessageLookupByLibrary.simpleMessage("पठाउनुहोस्"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("इमेल पठाउनुहोस्"),
        "sendMessage":
            MessageLookupByLibrary.simpleMessage("सन्देश पठाउनुहोस्"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("रिसेट लिंक पठाउनुहोस्"),
        "sendSms": MessageLookupByLibrary.simpleMessage("SMS पठाउनुहोस्"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("SMS पठाउनुहोस्?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("व्हाट्सएप सन्देश पठाउनुहोस्"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("तपाईंको इमेल पठाउनुहोस्"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage("इमेल पठाउँदै"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("सन्देश पठाइँदैछ"),
        "serviceShipping": MessageLookupByLibrary.simpleMessage("सेवा/शिपिङ"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("तपाईंको प्रोफाइल बनाउनुहोस्"),
        "setting": MessageLookupByLibrary.simpleMessage("सेटिङ"),
        "share": MessageLookupByLibrary.simpleMessage("साझा"),
        "shopGST": MessageLookupByLibrary.simpleMessage("दोकानको जीएसटी"),
        "signIn": MessageLookupByLibrary.simpleMessage("लगइन गर्नुहोस्"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("इमेलसँग लगइन गर्नुहोस्"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("ग्राहकको हस्ताक्षर"),
        "size": MessageLookupByLibrary.simpleMessage("साइज"),
        "skip": MessageLookupByLibrary.simpleMessage("छोड्नुहोस्"),
        "sms": MessageLookupByLibrary.simpleMessage("एसएमएस"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("सामाजिक मार्केटिंग"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "माफ गर्नुहोस्, तपाईंलाई यो सेवामा पहुँचको अनुमति छैन"),
        "startDate": MessageLookupByLibrary.simpleMessage("प्रारम्भ मिति"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("नयाँ बिक्री सुरु गर्नुहोस्"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage(
            "खोज्नका लागि प्रारम्भ गर्नुहोस्"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "कुनै पनि अतिरिक्त लागत बिना प्राविधिक प्रगतिको अगाडि रहनुहोस्। हाम्रो Pos Saas POS Unlimited अपग्रेडले तपाईको औँलाको छेउमा सँधै नवीनतम उपकरण र सुविधाहरू छन् भनी सुनिश्चित गर्दछ, तपाईको व्यवसाय अत्याधुनिक रहने ग्यारेन्टी गर्दै।"),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("अझै अव्यवस्थित"),
        "stock": MessageLookupByLibrary.simpleMessage("स्टक"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("स्टक आवश्यक छ"),
        "stockList": MessageLookupByLibrary.simpleMessage("स्टक सूची"),
        "stocks": MessageLookupByLibrary.simpleMessage("स्टकहरू"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "एक्सेल फाइल बनाउनको लागि भण्डारण अनुमति आवश्यक छ"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("उप कर सूची"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("उप करहरू"),
        "subTotal": MessageLookupByLibrary.simpleMessage("उपकुल"),
        "submit": MessageLookupByLibrary.simpleMessage("पेश गर्नुहोस्"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "हाम्रो यूट्यूब च्यानलमा सदस्यता लिनुहोस्"),
        "subscription": MessageLookupByLibrary.simpleMessage("सदस्यता"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("सफलतापूर्वक गरिएको"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("सफलतापूर्वक लगआउट गरिएको"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("सफलतापूर्वक अद्यावधिक गरियो"),
        "supplier": MessageLookupByLibrary.simpleMessage("प्रदायक"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("दिनुहोस् गर्नेको नाम"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT कोड"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "चालक परिचयपत्र, राष्ट्रिय परिचयपत्र वा पासपोर्टको फोटो लिनुहोस्"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "तपाइको जानकारी जाँच गर्नका लागि परिचयपत्र लिनुहोस्"),
        "tap": MessageLookupByLibrary.simpleMessage("ट्याप गर्नुहोस्"),
        "tax": MessageLookupByLibrary.simpleMessage("कर"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("कर समूह"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("कर प्रतिशत"),
        "taxRate": MessageLookupByLibrary.simpleMessage("कर दर"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "कर दरहरू - तपाईँका कर दरहरू व्यवस्थापन गर्नुहोस्"),
        "taxReport": MessageLookupByLibrary.simpleMessage("कर रिपोर्ट"),
        "taxType": MessageLookupByLibrary.simpleMessage("कर प्रकार"),
        "taxes": MessageLookupByLibrary.simpleMessage("करहरू"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("शर्त र अवस्था"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("प्रयोगका सर्तहरू"),
        "termsPrivacy": MessageLookupByLibrary.simpleMessage("नियम र गोपनीयता"),
        "thankYOuForYourDuePayment":
            MessageLookupByLibrary.simpleMessage("बाकी भुक्तानका लागि धन्यवाद"),
        "thankYou": MessageLookupByLibrary.simpleMessage("धन्यवाद"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("तपाइको खरिदका लागि धन्यवाद"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "त्यो इमेलका लागि खाता पहिले नै मौजूद छ"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "एक्सेल फाइल पहिल्यै डाउनलोड गरिएको छ"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "नामले सबै भन्छ। Pos Saas POS Unlimited को साथ, तपाईंको प्रयोगमा कुनै सीमा छैन। चाहे तपाइँ मुट्ठीभर लेनदेनहरू प्रशोधन गर्दै हुनुहुन्छ वा ग्राहकहरूको भीडको अनुभव गर्दै हुनुहुन्छ, तपाइँ सीमाहरूद्वारा बाधा नभएको थाहा पाउँदा तपाइँ आत्मविश्वासका साथ सञ्चालन गर्न सक्नुहुन्छ।"),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "प्रदान गरिएको पासवर्ड धेरै कमजोर छ"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "यो बिक्री हटाइनेछ र यस खरिदको बारेमा सबै डेटा हटाइनेछ। के तपाईं यो हटाउन पक्का हुनुहुन्छ?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "यो बिक्री हटाइनेछ र यस बिक्रीको बारेमा सबै डेटा हटाइनेछ। के तपाईं यो हटाउन पक्का हुनुहुन्छ?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "प्रयोगकर्ता मेटाइएको छ र सबै डाटा तपाईंको खाताबाट मेटाइएको छ। के तपाईं यसलाई मेटाउन चाहनुहुन्छ?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "यो प्रयोगकर्ता मेटिनेछ र तपाईको खाता बाट सबै डेटा मेटिनेछ। के तपाई निश्चित हुनुहुन्छ?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Third-Party Services"),
        "thisCategoryCannotBeDeleted":
            MessageLookupByLibrary.simpleMessage("यो श्रेणी मेटाउन सक्दैन"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(यस महिना)"),
        "thisProductAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("यो उत्पादन पहिल्यै थपिएको छ"),
        "title": MessageLookupByLibrary.simpleMessage("शिर्षक"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("शीर्षक खाली हुन सक्दैन"),
        "to": MessageLookupByLibrary.simpleMessage("लाई"),
        "toDate": MessageLookupByLibrary.simpleMessage("मिति सम्म"),
        "today": MessageLookupByLibrary.simpleMessage("आज"),
        "total": MessageLookupByLibrary.simpleMessage("कुल"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("कुल रकम"),
        "totalCollected": MessageLookupByLibrary.simpleMessage("कुल संकलन"),
        "totalDue": MessageLookupByLibrary.simpleMessage("कुल बाकी"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("कुल खर्च"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("कुल क्षति"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("कुल भुक्तान गर्नुपर्ने"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("कुल मूल्य"),
        "totalProducts": MessageLookupByLibrary.simpleMessage("कुल उत्पादनहरू"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("कुल नाफा"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("कुल खरिद"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("कुल फिर्ता रकम"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("कुल फिर्ताहरू"),
        "totalSale": MessageLookupByLibrary.simpleMessage("कुल बिक्री"),
        "totalStock": MessageLookupByLibrary.simpleMessage("कुल भण्डार"),
        "totalValue": MessageLookupByLibrary.simpleMessage("कुल मान"),
        "totalVat": MessageLookupByLibrary.simpleMessage("कुल भ्याट"),
        "totals": MessageLookupByLibrary.simpleMessage("कुल: "),
        "transaction": MessageLookupByLibrary.simpleMessage("लेनदेन"),
        "transactionId": MessageLookupByLibrary.simpleMessage("लेनदेन आइडी"),
        "tryAgain":
            MessageLookupByLibrary.simpleMessage("पुन: प्रयास गर्नुहोस्"),
        "twitter": MessageLookupByLibrary.simpleMessage("ट्विटर"),
        "type": MessageLookupByLibrary.simpleMessage("प्रकार"),
        "unitName": MessageLookupByLibrary.simpleMessage("इकाइको नाम"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("एकक मूल्य"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("एकाइ मूल्य"),
        "units": MessageLookupByLibrary.simpleMessage("इकाइहरू"),
        "unlimited": MessageLookupByLibrary.simpleMessage("असीमित"),
        "unlimitedUsage": MessageLookupByLibrary.simpleMessage("असीमित उपयोग"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "हाम्रो विशेषज्ञ टोलीको नेतृत्वमा व्यक्तिगत प्रशिक्षण सत्रहरूको साथ Pos Saas POS को पूर्ण क्षमता अनलक गर्नुहोस्। आधारभूत देखि उन्नत प्रविधिहरू सम्म, हामी सुनिश्चित गर्छौं कि तपाइँ तपाइँको व्यवसाय प्रक्रियाहरु लाई अनुकूलन गर्न प्रणाली को हरेक पक्ष को उपयोग मा राम्रो संग जान्दछ।"),
        "unpaid": MessageLookupByLibrary.simpleMessage("भुक्तानी नगरेको"),
        "update": MessageLookupByLibrary.simpleMessage("अपडेट गर्नुहोस्"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("संपर्क अपडेट गर्नुहोस्"),
        "updateNow": MessageLookupByLibrary.simpleMessage("अब अपडेट गर्नुहोस्"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("उत्पाद अपडेट गर्नुहोस्"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "पहिले आफ्नो योजना अपडेट गर्नुहोस्, तपाईंको सीमा समाप्त भएको छ"),
        "updateYourProfile": MessageLookupByLibrary.simpleMessage(
            "तपाईंको प्रोफाइल अपडेट गर्नुहोस्"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "तपाईंको प्रोफाइल अपडेट गर्दा तपाईंको डाक्टरलाई राम्रो प्रतिष्ठानसहित जडान गर्नुहोस्"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "तपाइंको प्रोफाइल अपडेट गर्नुहोस् भने ग्राहकसँग बेस्ट इम्प्रेसन बनाउनका लागि"),
        "updated": MessageLookupByLibrary.simpleMessage("अद्यावधिक गरियो"),
        "upload": MessageLookupByLibrary.simpleMessage("अपलोड"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("कागजात अपलोड गर्नुहोस्"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("अपलोड पूरा"),
        "uploadFile":
            MessageLookupByLibrary.simpleMessage("फाइल अपलोड गर्नुहोस्"),
        "upplier": MessageLookupByLibrary.simpleMessage("प्रदायक"),
        "usbC": MessageLookupByLibrary.simpleMessage("यूएसबी सी"),
        "use": MessageLookupByLibrary.simpleMessage("प्रयोग गर्नुहोस्"),
        "useMobiPos":
            MessageLookupByLibrary.simpleMessage("Pos Saas प्रयोग गर्नुहोस्"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Use of the system"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("प्रयोगकर्ता मेटिएको छ"),
        "userRole": MessageLookupByLibrary.simpleMessage("प्रयोगकर्ता भूमिका"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("प्रयोगकर्ता भूमिका विवरण"),
        "userTitle": MessageLookupByLibrary.simpleMessage("प्रयोगकर्ता शीर्षक"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "प्रयोगकर्ता शीर्षक खाली हुन सक्दैन"),
        "value": MessageLookupByLibrary.simpleMessage("मान"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("भ्याट लागू हुँदैन"),
        "verifyOtp":
            MessageLookupByLibrary.simpleMessage("ओटिपी सत्यापन गर्दै"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("फोन नम्बर सत्यापन गर्नुहोस्"),
        "viewAll": MessageLookupByLibrary.simpleMessage("सबै हेर्नुहोस्"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("विवरण हेर्नुहोस्"),
        "walkInCustomer": MessageLookupByLibrary.simpleMessage("आवाजको ग्राहक"),
        "warehouse": MessageLookupByLibrary.simpleMessage("गोदाम"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("गोदाम पहिले नै मौजूद छ"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("गोदाम सूची"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("गोदाम नाम"),
        "warranty": MessageLookupByLibrary.simpleMessage("गारंटी"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "हामीले पासवर्ड रिसेट कसरी गर्ने भन्ने बारे निर्देशन सहित एउटा इमेल पठाएका छौं:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "We may use third-party services to support our app\'s functionality, such as analytics providers and payment processors. These third-party services may collect information about you when you use our app. Please note that we are not responsible for the privacy practices of these third-party services."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "We take industry-standard measures to protect your personal information, including encryption and secure storage. We also limit access to your information to authorized personnel only."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "हामी निर्बाध सञ्चालनको महत्त्व बुझ्छौं। यसैले हाम्रो चौबीसै घण्टा समर्थन तपाईंलाई सहयोग गर्न उपलब्ध छ, चाहे यो द्रुत प्रश्न होस् वा व्यापक चिन्ता। अतुलनीय ग्राहक सेवा अनुभव गर्नको लागि कल वा व्हाट्सएप मार्फत जुनसुकै बेला, कहिँ पनि हामीसँग जडान गर्नुहोस्।"),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "We use your personal information to provide you with the best possible experience on our app, including to personalize your content recomme ndations, connect you with experts, and improve our apps functionality. We may also use your information to communicate with you about updates, promotions, or other information related to our app."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "हामी भुक्तानीको समीक्षा गरिसकेपछि यसलाई १-२ घण्टामा स्वीकृत गर्नेछौं"),
        "weekly": MessageLookupByLibrary.simpleMessage("साप्ताहिक"),
        "weight": MessageLookupByLibrary.simpleMessage("वजन"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("के नयाँ छ"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("थोक विक्रेता"),
        "wholeSalePrice": MessageLookupByLibrary.simpleMessage("होलसेल मूल्य"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("थोक मूल्य"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("थोक विक्रेता"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("छिट्टै थपिनेछ"),
        "willExpireAt":
            MessageLookupByLibrary.simpleMessage("यो मिति समाप्त हुनेछ"),
        "writeYourMessageHere": MessageLookupByLibrary.simpleMessage(
            "तपाइको सन्देश यहाँ लेख्नुहोस्"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("गलत ओटीपी"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "तपाईंको उपयोगकर्ताको लागि गलत पासवर्ड प्रदान गरिएको छ।"),
        "yearly": MessageLookupByLibrary.simpleMessage("वार्षिक"),
        "yesDeleteForever": MessageLookupByLibrary.simpleMessage(
            "हो, स्थायी रूपमा मेटाउनुहोस्"),
        "youAreNotAValidUser": MessageLookupByLibrary.simpleMessage(
            "तपाईं मान्य प्रयोगकर्ता होइन"),
        "youAreUsing":
            MessageLookupByLibrary.simpleMessage("तपाईंले प्रयोग गरिरहेका छौं"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "तपाईंले बक्यौता भन्दा बढी भुक्तानी गर्न सक्दैन"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("तपाईंले एउटा इमेल पाउनुभयो"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "तपाईं सफलतापूर्वक आफ्नो खातामा लगइएका छौं। Pos Saas सँग बस्नुहोस्।"),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("तपाईँले अनुमति दिनु पर्छ"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "तपाईंलाई आफ्नो खातामा पुन: लगइन गर्नुपर्छ।"),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "तपाइंले खरिद गर्नु अघि तपाइंको पहिचान प्रमाणिकरण गर्नुपर्छ"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("तपाइंको सन्देश बाँकि छ"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("तपाइंको प्याकेज"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "तपाइंको प्याकेज ५ दिनमा समाप्त हुनेछ")
      };
}
