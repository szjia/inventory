// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a bn locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'bn';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("বিলপ্লিজ"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("চালিয়ে যান"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("জিএসটি নম্বর"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("এমআরপি"),
        "MRPIsRequired": MessageLookupByLibrary.simpleMessage("এমআরপি আবশ্যক"),
        "OK": MessageLookupByLibrary.simpleMessage("ঠিক আছে"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("পেপাল"),
        "PhNo": MessageLookupByLibrary.simpleMessage("ফোন নম্বর"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("ক্রমিক"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT কোড"),
        "Snacks": MessageLookupByLibrary.simpleMessage("স্ন্যাকস"),
        "TAX": MessageLookupByLibrary.simpleMessage("কর"),
        "Uploading": MessageLookupByLibrary.simpleMessage("আপলোড হচ্ছে"),
        "UserTitle":
            MessageLookupByLibrary.simpleMessage("ব্যবহারকারী শিরোনাম"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "আপনার প্যাকেজ আজ মেয়াদ উত্তীর্ণ হবে\nঅনুগ্রহ করে আবার ক্রয় করুন"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) সিস্টেমটি শুধুমাত্র এর জন্য প্রদান করা হয়\nবিক্রয় পয়েন্ট সুবিধার উদ্দেশ্য\nআপনার মধ্যে লেনদেন এবং সম্পর্কিত কার্যকলাপ\nব্যবসা"),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(ক) সিস্টেম ব্যবহার করতে, আপনি হতে পারেন\nএকটি অ্যাকাউন্ট তৈরি করতে হবে। আপনি\nসঠিক, বর্তমান, এবং প্রদান করতে সম্মত\nসময় সম্পূর্ণ তথ্য\nনিবন্ধন প্রক্রিয়া এবং আপডেট\nএই ধরনের তথ্য সঠিক রাখতে\nএবং সম্পূর্ণ।"),
        "aboutApp": MessageLookupByLibrary.simpleMessage("অ্যাপ সম্পর্কে"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("আমাদের সম্পর্কে"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("শর্তাবলী গ্রহণ"),
        "accountName": MessageLookupByLibrary.simpleMessage("অ্যাকাউন্টের নাম"),
        "accountNumber":
            MessageLookupByLibrary.simpleMessage("অ্যাকাউন্ট নম্বর"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("অ্যাকাউন্ট নিবন্ধন"),
        "acton": MessageLookupByLibrary.simpleMessage("অ্যাকশন"),
        "add": MessageLookupByLibrary.simpleMessage("যোগ "),
        "addBrand": MessageLookupByLibrary.simpleMessage("ব্র্যান্ড যোগ করুন"),
        "addCategory": MessageLookupByLibrary.simpleMessage("বিভাগ যোগ করুন"),
        "addContact": MessageLookupByLibrary.simpleMessage("পরিচিতি যোগ করুন"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("গ্রাহক যোগ করুন"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("বিতরণ যোগ করুন"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("বর্ণনা যোগ করুন"),
        "addDescription": MessageLookupByLibrary.simpleMessage("নোট যোগ করুন"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("ছাড় যোগ করুন"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("ডকুমেন্ট আইডি যোগ করুন"),
        "addDucument": MessageLookupByLibrary.simpleMessage("নথি যোগ করুন"),
        "addExpense": MessageLookupByLibrary.simpleMessage("খরচ যোগ করুন"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("ব্যয় বিভাগ যোগ করুন"),
        "addItems": MessageLookupByLibrary.simpleMessage("আইটেম যুক্ত করুন"),
        "addNew": MessageLookupByLibrary.simpleMessage("নতুন যোগ করুন"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("নতুন ঠিকানা যোগ করুন"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("নতুন পণ্য যোগ করুন"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("নতুন কর যোগ করুন"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "একক/একাধিক কর প্রকার সহ নতুন কর যোগ করুন"),
        "addNote": MessageLookupByLibrary.simpleMessage("নোট যোগ করুন"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("প্রথমে পণ্য যোগ করুন"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("প্রোমো কোড যোগ করুন"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("ক্রয় যোগ করুন"),
        "addSales": MessageLookupByLibrary.simpleMessage("বিক্রয় যোগ করুন"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("সফলভাবে যোগ করা হয়েছে"),
        "addUnit": MessageLookupByLibrary.simpleMessage("ইউনিট যোগ করুন"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("ব্যবহারকারী ভূমিকা যোগ করুন"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("সফলভাবে যোগ করা হয়েছে"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("কার্টে যোগ করা হয়েছে"),
        "address": MessageLookupByLibrary.simpleMessage("ঠিকানা"),
        "admin": MessageLookupByLibrary.simpleMessage("প্রশাসক"),
        "all": MessageLookupByLibrary.simpleMessage("সব"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("সমস্ত ব্যবসা সমাধান"),
        "alreadyAdded":
            MessageLookupByLibrary.simpleMessage("ইতিমধ্যে যোগ করা হয়েছে"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("আগেই বিদ্যমান"),
        "alreadyHaveAnAccounts": MessageLookupByLibrary.simpleMessage(
            "ইতিমধ্যে একটি অ্যাকাউন্ট আছে"),
        "amount": MessageLookupByLibrary.simpleMessage("পরিমাণ"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "একটি ইমেল পাঠানো হয়েছে\nইনবক্স পরীক্ষা করুন"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "অ্যান্ড্রয়েড এবং iOS অ্যাপ সাপোর্ট"),
        "applicableTax": MessageLookupByLibrary.simpleMessage("প্রযোজ্য কর"),
        "apply": MessageLookupByLibrary.simpleMessage("আবেদন করুন"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "আপনি কি নিশ্চিতভাবে এই চালান মুছতে চান?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "আপনি কি নিশ্চিতভাবে এই বিক্রয়টি মুছতে চান?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "আপনি কি এই ব্যবহারকারীকে মুছে ফেলতে নিশ্চিত?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "আপনি কি নিশ্চিত এই ট্যাক্স মুছতে চান?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "আপনি কি নিশ্চিত এই ট্যাক্স গ্রুপ মুছতে চান?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "আপনি কি এই গুদামটি মুছতে চান?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "আপনি এই ব্যবহারকারী মুছে ফেলার বিষয়ে নিশ্চিত?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("অনুমোদিত স্বাক্ষর"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(খ) আপনি রক্ষণাবেক্ষণের জন্য দায়ী\nআপনার অ্যাকাউন্টের গোপনীয়তা এবং\nপাসওয়ার্ড এবং আপনার অ্যাক্সেস\nসীমাবদ্ধ করার জন্য অ্যাকাউন্ট আপনি\nসকলের দায় স্বীকার করুনআপনার\nঅ্যাকাউন্টের অধীনে যেকার্যকলাপগুলি ঘটে।"),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(খ) আপনার বয়স হতে হবে কমপক্ষে ১৮ বছর বা\nআপনার এখতিয়ারে সংখ্যাগরিষ্ঠের আইনি বয়স\nসিস্টেম ব্যবহার করুন।"),
        "backSide": MessageLookupByLibrary.simpleMessage("পিছনের পাশ"),
        "backToHome":
            MessageLookupByLibrary.simpleMessage("মূলপৃষ্ঠায় ফিরে যান"),
        "balance": MessageLookupByLibrary.simpleMessage("ব্যালেন্স"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("বাংলাদেশ"),
        "bank": MessageLookupByLibrary.simpleMessage("ব্যাংক"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("ব্যাংক অ্যাকাউন্ট মুদ্রা"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("ব্যাংক অ্যাকাউন্ট মুদ্রা"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("ব্যাংকের তথ্য"),
        "bankName": MessageLookupByLibrary.simpleMessage("ব্যাংকের নাম"),
        "bankTransfer":
            MessageLookupByLibrary.simpleMessage("ব্যাংক স্থানান্তর"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("বারকোড পাওয়া গেছে"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("বিল/চালান"),
        "billTo": MessageLookupByLibrary.simpleMessage("বিল প্রাপ্তি করুন"),
        "branchName": MessageLookupByLibrary.simpleMessage("শাখার নাম"),
        "brand": MessageLookupByLibrary.simpleMessage("ব্র্যান্ড"),
        "brandName": MessageLookupByLibrary.simpleMessage("ব্র্যান্ডের নাম"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("বাল্ক\nআপলোড"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("ব্যবসার বিভাগ"),
        "buy": MessageLookupByLibrary.simpleMessage("ক্রয় করুন"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("প্রিমিয়াম প্ল্যান কেনো"),
        "buySms": MessageLookupByLibrary.simpleMessage("এসএমএস কেনো"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "[আপনার কোম্পানির নাম] (\"কোম্পানি\") দ্বারা প্রদত্ত পয়েন্ট অফ সেল (পিওএস) সিস্টেম (\"সিস্টেম\") অ্যাক্সেস বা ব্যবহার করে, আপনি এই ব্যবহারের শর্তাবলী দ্বারা আবদ্ধ হতে সম্মত হন। আপনি যদি এই ব্যবহারের শর্তাবলীতে সম্মত না হন তবে সিস্টেমটি ব্যবহার করবেন না।"),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(গ) আপনি নিশ্চিত করার জন্য দায়ী যে আপনার\nসিস্টেমের অ্যাক্সেস এবং ব্যবহার রয়েছে\nসমস্ত প্রযোজ্য আইনের সাথে সম্মতি এবং\nআইন."),
        "cacel": MessageLookupByLibrary.simpleMessage("বাতিল"),
        "call": MessageLookupByLibrary.simpleMessage("কল"),
        "callForEmergencySupport":
            MessageLookupByLibrary.simpleMessage("জরুরি সহায়তার জন্য কল করুন"),
        "camera": MessageLookupByLibrary.simpleMessage("ক্যামেরা"),
        "cancel": MessageLookupByLibrary.simpleMessage("বাতিল"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("সমস্ত পণ্য বাতিল করুন"),
        "capacity": MessageLookupByLibrary.simpleMessage("ধারণক্ষমতা"),
        "card": MessageLookupByLibrary.simpleMessage("কার্ড"),
        "cash": MessageLookupByLibrary.simpleMessage("নগদ"),
        "cashFree": MessageLookupByLibrary.simpleMessage("ক্যাশফ্রি"),
        "categories": MessageLookupByLibrary.simpleMessage("বিভাগসমূহ"),
        "category": MessageLookupByLibrary.simpleMessage("বিভাগ"),
        "categoryName": MessageLookupByLibrary.simpleMessage("ক্যাটাগরি নাম"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "ক্যাটাগরি নাম ইতিমধ্যেই বিদ্যমান"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("বিভাগের নাম"),
        "change": MessageLookupByLibrary.simpleMessage("পরিবর্তন?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("পাসওয়ার্ড পরিবর্তন করুন"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("ইমেইল চেক কর"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("একটি গ্রাহক চয়ন করুন"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("একটি সরবরাহকারী চয়ন করুন"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("আপনার বৈশিষ্ট্য চয়ন করুন"),
        "clarence": MessageLookupByLibrary.simpleMessage("ক্লারেন্স"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("সংযোগ করতে ক্লিক করুন"),
        "close": MessageLookupByLibrary.simpleMessage("বন্ধ করুন"),
        "color": MessageLookupByLibrary.simpleMessage("রং"),
        "combinationOfMultipleTaxes":
            MessageLookupByLibrary.simpleMessage("(একাধিক ট্যাক্সের সমন্বয়)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("শীঘ্রই আসছে"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("প্রতিষ্ঠান এর ঠিকানা"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("কোম্পানি এবং দোকানের নাম"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("কোম্পানি ও ব্যবসার নাম"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("লেনদেন সম্পূর্ণ করুন"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("পাসওয়ার্ড নিশ্চিত করুন"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("রিটার্ন নিশ্চিত করুন"),
        "congratulations": MessageLookupByLibrary.simpleMessage("অভিনন্দন"),
        "contactUs": MessageLookupByLibrary.simpleMessage("যোগাযোগ করুন"),
        "continu": MessageLookupByLibrary.simpleMessage("চালিয়ে যান"),
        "country": MessageLookupByLibrary.simpleMessage("দেশ"),
        "create": MessageLookupByLibrary.simpleMessage("তৈরি করুন"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("অস্ত্রোপচার"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("তৈরি এবং সংরক্ষণ করা হয়েছে"),
        "currency": MessageLookupByLibrary.simpleMessage("মুদ্রা"),
        "currentStock": MessageLookupByLibrary.simpleMessage("বর্তমান স্টক"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("কাস্টম চালান ব্র্যান্ডিং"),
        "customer": MessageLookupByLibrary.simpleMessage("গ্রাহক"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("কাস্টমার বিস্তারিত"),
        "customerGST": MessageLookupByLibrary.simpleMessage("গ্রাহক জিএসটি"),
        "customerName": MessageLookupByLibrary.simpleMessage("গ্রাহকের নাম"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("দৈনিক লেনদেন"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("ড্যাশবোর্ড ওভারভিউ"),
        "dataSavedSuccessfully": MessageLookupByLibrary.simpleMessage(
            "তথ্য সফলভাবে সংরক্ষিত হয়েছে"),
        "date": MessageLookupByLibrary.simpleMessage("তারিখ"),
        "day": MessageLookupByLibrary.simpleMessage("দিন"),
        "dealer": MessageLookupByLibrary.simpleMessage("ডিলার"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("ডিলার মূল্য"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("ডিফল্ট VAT শতাংশ"),
        "delete": MessageLookupByLibrary.simpleMessage("মুছে ফেলুন"),
        "deleting": MessageLookupByLibrary.simpleMessage("মুছে ফেলা হচ্ছে"),
        "deliveryAddress": MessageLookupByLibrary.simpleMessage("বিতরণ ঠিকানা"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("ডেলিভারি ঠিকানা"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("ডেলিভারি চার্জ"),
        "describtion": MessageLookupByLibrary.simpleMessage("বিবরণ"),
        "description": MessageLookupByLibrary.simpleMessage("বর্ণনা"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("বর্ণনা খালি থাকতে পারে না"),
        "details": MessageLookupByLibrary.simpleMessage("বিস্তারিত"),
        "discount": MessageLookupByLibrary.simpleMessage("ডিসকাউন্ট"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("বিচ্ছেদ ন করুন"),
        "done": MessageLookupByLibrary.simpleMessage("সম্পন্ন"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("এক্সেল ফরম্যাট ডাউনলোড করুন"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "ডাউনলোড ফোল্ডারে সফলভাবে ডাউনলোড করা হয়েছে"),
        "due": MessageLookupByLibrary.simpleMessage("বাকি"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("বকেয়া পরিমাণ: "),
        "dueCollection": MessageLookupByLibrary.simpleMessage("বকেয়া আদায়"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("বকেয়া সংগ্রহ রিপোর্ট"),
        "dueList": MessageLookupByLibrary.simpleMessage("বকেয়া লিস্ট"),
        "dueReports": MessageLookupByLibrary.simpleMessage("বকেয়া রিপোর্ট"),
        "duration": MessageLookupByLibrary.simpleMessage("স্থায়িত্ব"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("মেয়াদ: থেকে"),
        "easyToUseMobilePos":
            MessageLookupByLibrary.simpleMessage("ব্যবহার করা সহজ মোবাইল POS"),
        "edit": MessageLookupByLibrary.simpleMessage("সম্পাদনা করুন"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("ক্রয় চালান সম্পাদনা করুন"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("বিক্রয় চালান সম্পাদনা করুন"),
        "editSocailMedia": MessageLookupByLibrary.simpleMessage(
            "সামাজিক মিডিয়া সম্পাদনা করুন"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("সফলভাবে সম্পাদিত"),
        "editTax":
            MessageLookupByLibrary.simpleMessage("ট্যাক্স সম্পাদনা করুন"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("ট্যাক্স গ্রুপ সম্পাদনা করুন"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("গুদাম সম্পাদনা করুন"),
        "email": MessageLookupByLibrary.simpleMessage("ইমেইল"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("ইমেইল ঠিকানা"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("ইমেইল খালি হতে পারবে না"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "ইমেইল পাঠানো হয়েছে! আপনার ইনবক্স চেক করুন"),
        "endDate": MessageLookupByLibrary.simpleMessage("শেষ তারিখ"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("একটি বৈধ পরিমাণ প্রবেশ করান"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("একটি বৈধ ছাড় প্রবেশ করান"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "একটি বৈধ ফোন নম্বর প্রবেশ করান"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("একটি বৈধ মূল্য লিখুন"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("একটি বৈধ পরিমাণ লিখুন"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("ঠিকানা লিখুন"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("পরিমান লিখুন"),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("ব্র্যান্ডের নাম লিখুন"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("ধারণক্ষমতা লিখুন"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("বিভাগের নাম লিখুন"),
        "enterColor": MessageLookupByLibrary.simpleMessage("রং লিখুন"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "গ্রাহকের জিএসটি নম্বর প্রবেশ করান"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("ডিলার মূল্য লিখুন"),
        "enterDescription": MessageLookupByLibrary.simpleMessage("বর্ণনা দিন"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("ডিসকাউন্ট লিখুন"),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("খরচের তারিখ লিখুন"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("সম্পূর্ণ ঠিকানা লিখুন"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("চালান নম্বর লিখুন"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "নিম্ন স্টক সতর্কতার পরিমাণ দিন"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("উত্পাদনকারী লিখুন"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("বার্তা সামগ্রী লিখুন"),
        "enterMrpOrRetailerPirce":
            MessageLookupByLibrary.simpleMessage("এমআরপি / খুদরা মূল্য লিখুন"),
        "enterName": MessageLookupByLibrary.simpleMessage("নাম লিখুন"),
        "enterNote": MessageLookupByLibrary.simpleMessage("মন্তব্য লিখুন"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("পার্টির নাম লিখুন"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("ফোন নম্বর লিখুন"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "পণ্য কোড লিখুন বা স্ক্যান করুন"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("পণ্যের নাম লিখুন"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("ক্রয় মূল্য লিখুন"),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("রেফারেন্স নম্বর লিখুন"),
        "enterSize": MessageLookupByLibrary.simpleMessage("আকার লিখুন"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("স্টক লিখুন"),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("ট্যাক্স হার লিখুন"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("লেনদেন আইডি দিন"),
        "enterType": MessageLookupByLibrary.simpleMessage("প্রকার লিখুন"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("ব্যবহারকারী শিরোনাম লিখুন"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("একটি বৈধ পরিমাণ প্রবেশ করান"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("গুদাম নাম লিখুন"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("ওজন লিখুন"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("হোলসেল মূল্য লিখুন"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("আপনার বিবরণ এখানে লিখুন"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("তোমার ই - মেইল ঠিকানা লেখো"),
        "enterYourFeedBackTitle":
            MessageLookupByLibrary.simpleMessage("আপনার মতামতের শিরোনাম লিখুন"),
        "enterYourGSTNumber": MessageLookupByLibrary.simpleMessage(
            "আপনার জিএসটি নম্বর প্রবেশ করান"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("আপনার মোবাইল নম্বর লিখুন"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("আপনার নাম লিখুন"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("আপনার ফোন নম্বর লিখুন"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("আপনার পাসওয়ার্ড দিন"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("আপনার ফোন নম্বর লিখুন"),
        "enterYourTransactionId":
            MessageLookupByLibrary.simpleMessage("আপনার লেনদেন আইডি লিখুন"),
        "error": MessageLookupByLibrary.simpleMessage("ত্রুটি"),
        "excTax": MessageLookupByLibrary.simpleMessage("কর বাদে"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("এক্সেল আপলোডার"),
        "exclusive": MessageLookupByLibrary.simpleMessage("এক্সক্লুসিভ"),
        "expense": MessageLookupByLibrary.simpleMessage("ব্যয়"),
        "expenseCategory": MessageLookupByLibrary.simpleMessage("ব্যয় বিভাগ"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("খরচের তারিখ"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("এর জন্য খরচ"),
        "expenseReport": MessageLookupByLibrary.simpleMessage("ব্যয় রিপোর্ট"),
        "expireDate":
            MessageLookupByLibrary.simpleMessage("মেয়াদোত্তীর্ণ তারিখ"),
        "expired": MessageLookupByLibrary.simpleMessage("মেয়াদোত্তীর্ণ"),
        "expiring": MessageLookupByLibrary.simpleMessage("মেয়াদোত্তীর্ণ"),
        "facebok": MessageLookupByLibrary.simpleMessage("ফেসবুক"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("ত্রুটি সহ ব্যর্থ হয়েছে"),
        "fashion": MessageLookupByLibrary.simpleMessage("ফ্যাশন"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "ববৈশিষ্ট্যগুলি হল গুরুত্বপূর্ণ অংশ যা পস সাসকে ঐতিহ্যগত সমাধান থেকে আলাদা করে তোলে।"),
        "feedBack": MessageLookupByLibrary.simpleMessage("মতামত"),
        "firstName": MessageLookupByLibrary.simpleMessage("প্রথম নাম"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("ফেসবুকে আমাদের অনুসরণ করুন"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("টুইটারে আমাদের অনুসরণ করুন"),
        "fontSide": MessageLookupByLibrary.simpleMessage("সামনের পাশ"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("অসীম ব্যবহারের জন্য"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("পাসওয়ার্ড ভুলে গেছেন"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("পাসওয়ার্ড ভুলে গেছেন?"),
        "formDate": MessageLookupByLibrary.simpleMessage("তারিখ থেকে"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("বিনামূল্যে ডেটা ব্যাকআপ"),
        "freeLifeTimeUpdate":
            MessageLookupByLibrary.simpleMessage("বিনামূল্যে লাইফটাইম আপডেট"),
        "freePacakge":
            MessageLookupByLibrary.simpleMessage("বিনামূল্যে প্যাকেজ"),
        "freePlan": MessageLookupByLibrary.simpleMessage("বিনামূল্যে প্ল্যান"),
        "from": MessageLookupByLibrary.simpleMessage("(থেকে"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("সম্পূর্ণ পরিশোধিত"),
        "gallary": MessageLookupByLibrary.simpleMessage("গ্যালারি"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("PDF তৈরি হচ্ছে"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Otp পান"),
        "govermentId":
            MessageLookupByLibrary.simpleMessage("সরকারি পরিচয়পত্র"),
        "guest": MessageLookupByLibrary.simpleMessage("অতিথি"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("কোন অ্যাকাউন্ট নেই?"),
        "history": MessageLookupByLibrary.simpleMessage("ইতিহাস"),
        "home": MessageLookupByLibrary.simpleMessage("হোম"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "কিভাবে আমরা আপনার তথ্য সুরক্ষিত"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "আমরা কিভাবে আপনার তথ্য ব্যবহার করি"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("পরিচয় যাচাই করুন"),
        "image": MessageLookupByLibrary.simpleMessage("চিত্র"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("ইনহাউস মুছে ফেলা যাবে না"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("ইনহাউস সম্পাদনা করা যাবে না"),
        "inWord": MessageLookupByLibrary.simpleMessage("শব্দে"),
        "incTax": MessageLookupByLibrary.simpleMessage("কর অন্তর্ভুক্ত"),
        "inclusive": MessageLookupByLibrary.simpleMessage("অন্তর্ভুক্ত"),
        "increaseStock":
            MessageLookupByLibrary.simpleMessage("স্টক বৃদ্ধি করুন"),
        "inistrument": MessageLookupByLibrary.simpleMessage("ইনস্ট্রুমেন্ট"),
        "instragram": MessageLookupByLibrary.simpleMessage("ইনস্টাগ্রাম"),
        "invNo": MessageLookupByLibrary.simpleMessage("চালান নং"),
        "invoice": MessageLookupByLibrary.simpleMessage("চালান"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("চালান নম্বর"),
        "invoiceSetting": MessageLookupByLibrary.simpleMessage("চালান সেটিং"),
        "invoiceViewer": MessageLookupByLibrary.simpleMessage("চালান দর্শক"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("আইটেম যুক্ত হয়েছে"),
        "kg": MessageLookupByLibrary.simpleMessage("কেজি"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("কেওয়াইসি যাচাই"),
        "language": MessageLookupByLibrary.simpleMessage("ভাষা"),
        "lastName": MessageLookupByLibrary.simpleMessage("শেষ নাম"),
        "ledger": MessageLookupByLibrary.simpleMessage("লেজার"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("লাইফটাইম ক্রয়"),
        "link": MessageLookupByLibrary.simpleMessage("লিংক"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("লিঙ্কডইন"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("লাইভ চ্যাট সহায়তা"),
        "loading": MessageLookupByLibrary.simpleMessage("লোড হচ্ছে"),
        "logIn": MessageLookupByLibrary.simpleMessage("প্রবেশ করুন"),
        "logOUt": MessageLookupByLibrary.simpleMessage("লগ আউট"),
        "logOut": MessageLookupByLibrary.simpleMessage("লগ আউট"),
        "login": MessageLookupByLibrary.simpleMessage("প্রবেশ করুন"),
        "logo": MessageLookupByLibrary.simpleMessage("লোগো"),
        "loss": MessageLookupByLibrary.simpleMessage("লস"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("লস / প্রফিট"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("লস / প্রফিট বিবরণী"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("ক্ষতি/লাভ রিপোর্ট"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("ক্ষতি/লাভ রিপোর্ট"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("নিম্ন স্টক সতর্কতা"),
        "maan": MessageLookupByLibrary.simpleMessage("মান"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "আপনার গ্রাহকদের সাথে ব্র্যান্ডেড চালানে স্থায়ী প্রভাব জানান। আমাদের সীমাহীন আপগ্রেড আপনার চালানগুলি কাস্টমাইজ করার অনন্য সুযোগ প্রদান করে, একটি পেশাদার স্পর্শ যোগ করে আপনার ব্র্যান্ড গুরুত্ব দেয় এবং গ্রাহক বিশ্বাস উৎপন্ন করে।"),
        "manageYourBussinessWith": MessageLookupByLibrary.simpleMessage(
            "এর সাথে আপনার ব্যবসা পরিচালনা করুন"),
        "manufactureDate": MessageLookupByLibrary.simpleMessage("উৎপাদন তারিখ"),
        "margin": MessageLookupByLibrary.simpleMessage("মার্জিন"),
        "masterCard": MessageLookupByLibrary.simpleMessage("মাস্টার কার্ড"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("উত্পাদনকারী"),
        "message": MessageLookupByLibrary.simpleMessage("বার্তা"),
        "messageHistory": MessageLookupByLibrary.simpleMessage("বার্তা ইতিহাস"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Pos Sass অ্যাপ বিনামূল্যে, ব্যবহার সহজ। সত্যিই, এটি বিশ্বের সেরা POS সিস্টেমের মধ্যে একটি।"),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas একটি পূর্ণ ব্যবসা সমাধান যা স্টক, হিসাব, বিক্রয়, ব্যয় এবং ক্ষতি/লাভ অধ্যায়ে থাকে।"),
        "mobile": MessageLookupByLibrary.simpleMessage("মোবাইল"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("মোবাইল পেমেন্ট"),
        "monthly": MessageLookupByLibrary.simpleMessage("মাসিক"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("অধিক তথ্য"),
        "name": MessageLookupByLibrary.simpleMessage("আপনার নাম প্রবেশ করুন"),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("নাম ইতিমধ্যেই বিদ্যমান"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("নাম খালি হতে পারবে না"),
        "next": MessageLookupByLibrary.simpleMessage("পরবর্তী"),
        "noConnection": MessageLookupByLibrary.simpleMessage("সংযোগ নেই"),
        "noData": MessageLookupByLibrary.simpleMessage("কোন তথ্য নেই"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("কোন ডেটা উপলব্ধ নেই"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("কোনো তথ্য পাওয়া যায়নি"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("কোন ইতিহাস পাওয়া যায়নি!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("কোন পণ্য পাওয়া যায়নি"),
        "noSubTaxSelected": MessageLookupByLibrary.simpleMessage(
            "কোনো সাব ট্যাক্স নির্বাচন করা হয়নি"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("কোন লেনদেন পাওয়া যায়নি!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "সেই ইমেলের জন্য কোনো ব্যবহারকারী পাওয়া যায়নি।"),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "কোনও ব্যবহারকারী ভূমিকা পাওয়া যায়নি"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("সক্রিয় ব্যবহারকারী নন"),
        "notProvided": MessageLookupByLibrary.simpleMessage("প্রদত্ত নয়"),
        "note": MessageLookupByLibrary.simpleMessage("মন্তব্য"),
        "notes": MessageLookupByLibrary.simpleMessage("মন্তব্য"),
        "notification": MessageLookupByLibrary.simpleMessage("বিজ্ঞপ্তি"),
        "oTPSentTo":
            MessageLookupByLibrary.simpleMessage("ওটিপি পাঠানো হয়েছে"),
        "office": MessageLookupByLibrary.simpleMessage("অফিস"),
        "ok": MessageLookupByLibrary.simpleMessage("ঠিক আছে"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS যেটিতে বিক্রয় ট্র্যাকিং, ইনভেন্টরি ম্যানেজমেন্ট সহ প্রচুর কার্যকারিতা রয়েছে।"),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "এই সিস্টেম আপনাকে আপনার গ্রাহকদের জন্য আপনার অপারেশন উন্নত করতে সাহায্য করে।"),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "আমাদের POS সিস্টেমটি প্রতিদিনের ক্রিয়াকলাপগুলিকে স্বয়ংক্রিয়ভাবে সরল করা উচিত, এটি নেভিগেট করা সহজ করে।"),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("ওপেনিং ব্যালেন্স"),
        "order": MessageLookupByLibrary.simpleMessage("অর্ডার"),
        "other": MessageLookupByLibrary.simpleMessage("অন্যান্য"),
        "otp": MessageLookupByLibrary.simpleMessage("বন্ধ"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("স্টক নেই"),
        "pacakge": MessageLookupByLibrary.simpleMessage("প্যাকেজ"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("প্যাকেজ বৈশিষ্ট্য"),
        "paid": MessageLookupByLibrary.simpleMessage("পরিশোধিত"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("পরিশোধিত পরিমাণ"),
        "parties": MessageLookupByLibrary.simpleMessage("পার্টি লিস্ট"),
        "partiesList": MessageLookupByLibrary.simpleMessage("দলগুলোর তালিকা"),
        "partyGST": MessageLookupByLibrary.simpleMessage("পার্টি জিএসটি"),
        "partyName": MessageLookupByLibrary.simpleMessage("পার্টির নাম"),
        "password": MessageLookupByLibrary.simpleMessage("পাসওয়ার্ড"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "পাসওয়ার্ড এবং নিশ্চিত পাসওয়ার্ড মেলে না"),
        "passwordCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "পাসওয়ার্ড খালি হতে পারবে না"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("পাসওয়ার্ড মেলেনি"),
        "payCash": MessageLookupByLibrary.simpleMessage("নগদ প্রদান করুন"),
        "payStack": MessageLookupByLibrary.simpleMessage("পে স্ট্যাক"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("বিকাশে পরিশোধ করুন"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("পেপ্যাল দিয়ে পরিশোধ করুন"),
        "payeeName": MessageLookupByLibrary.simpleMessage("পেইয়ি নাম"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("পেইয়ি নাম্বার"),
        "payment": MessageLookupByLibrary.simpleMessage("পেমেন্ট"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("পেমেন্ট পরিমাণ"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("পেমেন্ট সম্পূর্ণ"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("পেমেন্ট নির্দেশাবলি:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("পেমেন্ট পদ্ধতি"),
        "paymentType": MessageLookupByLibrary.simpleMessage("পেমেন্ট ধরণ"),
        "pdfView": MessageLookupByLibrary.simpleMessage("PDF দেখুন"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("ব্যক্তিগত তথ্য"),
        "phone": MessageLookupByLibrary.simpleMessage("ফোন"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("ফোন নম্বর"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "ফোন নম্বর ইতিমধ্যেই ব্যবহৃত হয়েছে"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("ফোন নম্বর সঠিক নয়"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("ফোন নম্বর আবশ্যক"),
        "pickAndUploadFile": MessageLookupByLibrary.simpleMessage(
            "ফাইল নির্বাচন করুন এবং আপলোড করুন"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("শেষ তারিখ চয়ন করুন"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("শুরুর তারিখ চয়ন করুন"),
        "plan": MessageLookupByLibrary.simpleMessage("পরিকল্পনা"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("অনুগ্রহ করে পরিমাণ যোগ করুন"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "আপনার ইন্টারনেট সংযোগ পরীক্ষা করুন"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "অনুগ্রহ করে প্রথমে প্রিন্টারটি সংযুক্ত করুন"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "আপনার ব্লুটুথ প্রিন্টার সংযোগ করুন"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "অনুগ্রহ করে বড় পাসওয়ার্ড দিন"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "দয়া করে একটি নিশ্চিত পাসওয়ার্ড দিন"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("একটি পাসওয়ার্ড লিখুন"),
        "pleaseEnterAValidEmail":
            MessageLookupByLibrary.simpleMessage("একটি বৈধ ইমেইল প্রদান করুন"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("দয়া করে নাম দিন"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("দয়া করে পাসওয়ার্ড লিখুন"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "পাসওয়ার্ড রিসেট লিঙ্ক পেতে নিচে আপনার ইমেল ঠিকানা লিখুন."),
        "pleaseEnterTransactionNumber":
            MessageLookupByLibrary.simpleMessage("লেনদেন নম্বর লিখুন"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("দয়া করে পরিমাণ দিন"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "প্রথমে একটি বিভাগ নির্বাচন করুন"),
        "pleaseSelectAPlan": MessageLookupByLibrary.simpleMessage(
            "অনুগ্রহ করে একটি পরিকল্পনা নির্বাচন করুন"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "অনুগ্রহ করে ব্যবসার বিভাগ নির্বাচন করুন"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "অ্যাপ ব্যবহার করতে বৈধ ক্রয় কোড ব্যবহার করুন"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Pos Saas দ্বারা চালিত"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("দ্বারা চালিত"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("প্রিমিয়াম গ্রাহক সমর্থন"),
        "premiumPlan":
            MessageLookupByLibrary.simpleMessage("প্রিমিয়াম প্ল্যান"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("পূর্ববর্তী পে পরিমাণ"),
        "price": MessageLookupByLibrary.simpleMessage("মূল্য"),
        "print": MessageLookupByLibrary.simpleMessage("মুদ্রণ"),
        "printingOption": MessageLookupByLibrary.simpleMessage("মুদ্রণ বিকল্প"),
        "privacyPolicy": MessageLookupByLibrary.simpleMessage("গোপনীয়তা নীতি"),
        "product": MessageLookupByLibrary.simpleMessage("প্রোডাক্ট"),
        "productCode": MessageLookupByLibrary.simpleMessage("পণ্য কোড"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("পণ্যের কোড আবশ্যক"),
        "productCodeName": MessageLookupByLibrary.simpleMessage("পণ্য কোড/নাম"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("পণ্যের বিবরণ"),
        "productDetails": MessageLookupByLibrary.simpleMessage("পণ্যের বিবরণ"),
        "productList": MessageLookupByLibrary.simpleMessage("পণ্য তালিকা"),
        "productName": MessageLookupByLibrary.simpleMessage("পণ্যের নাম"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "এই গুদামে পণ্যের নাম ইতিমধ্যেই বিদ্যমান"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "পণ্যের নাম ইতিমধ্যেই যোগ করা হয়েছে"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("পণ্যের নাম আবশ্যক"),
        "products": MessageLookupByLibrary.simpleMessage("পণ্য"),
        "profile": MessageLookupByLibrary.simpleMessage("প্রোফাইল"),
        "profileEdit":
            MessageLookupByLibrary.simpleMessage("প্রোফাইল সম্পাদনা"),
        "profit": MessageLookupByLibrary.simpleMessage("প্রফিট"),
        "promo": MessageLookupByLibrary.simpleMessage("প্রোমো"),
        "promoCode": MessageLookupByLibrary.simpleMessage("প্রোমো কোড"),
        "purchase": MessageLookupByLibrary.simpleMessage("ক্রয়"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage("ক্রয় সতর্কতা"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("ক্রয় নিশ্চিত"),
        "purchaseDetails": MessageLookupByLibrary.simpleMessage("ক্রয় বিশদ"),
        "purchaseInvoice": MessageLookupByLibrary.simpleMessage("ক্রয় চালান"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("ক্রয় তালিকা"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("এখন কিনুন"),
        "purchasePremiumPlan": MessageLookupByLibrary.simpleMessage(
            "প্রিমিয়াম প্ল্যান ক্রয় করুন"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("ক্রয় মূল্য"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("ক্রয় মূল্য আবশ্যক"),
        "purchaseRepoet": MessageLookupByLibrary.simpleMessage("ক্রয় রিপোর্ট"),
        "purchaseReports": MessageLookupByLibrary.simpleMessage("ক্রয় মূল্য"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("ক্রয় রিপোর্ট"),
        "purchaseReturn": MessageLookupByLibrary.simpleMessage("ক্রয় রিটার্ন"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("ক্রয় রিটার্ন রিপোর্ট"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("ক্রয় স্থানান্তর"),
        "qty": MessageLookupByLibrary.simpleMessage("পরিমাণ"),
        "quantity": MessageLookupByLibrary.simpleMessage("পরিমাণ"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("সাম্প্রতিক লেনদেন"),
        "recivedThePin": MessageLookupByLibrary.simpleMessage("পিন পেয়েছি"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("রেফারেন্স নম্বর"),
        "register": MessageLookupByLibrary.simpleMessage("নিবন্ধন"),
        "registering":
            MessageLookupByLibrary.simpleMessage("নিবন্ধন করা হচ্ছে"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("বাকি অবশিষ্ট"),
        "remove": MessageLookupByLibrary.simpleMessage("অপসারণ"),
        "reports": MessageLookupByLibrary.simpleMessage("রিপোর্টস"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("অনুরোধ পাঠানো হয়েছে"),
        "resendCode":
            MessageLookupByLibrary.simpleMessage("পুনরায় পাঠানো কোড"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("OTP আবার পাঠান:"),
        "retailer": MessageLookupByLibrary.simpleMessage("খুচরা বিক্রেতা"),
        "retur": MessageLookupByLibrary.simpleMessage("ফেরত"),
        "returN": MessageLookupByLibrary.simpleMessage("রিটার্ন"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("ফেরত মূল্য"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("ফেরত মূল্য"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("রিটার্ন পরিমাণ"),
        "revenue": MessageLookupByLibrary.simpleMessage("রাজস্ব"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "আপনার ব্যবসা ডেটা সহজলাভ করুন। আমাদের Pos Saas POS সীমাহীন আপগ্রেড বিনামূল্যে ডেটা ব্যাকআপ সহ এনেছে, আপনার মূল্যবান তথ্যটি যে কোনও অনুমান নিরাপত্তা প্রদান করে। সত্যিই গুরুত্বপূর্ণ মাধ্যমে আপনার ব্যবসা বৃদ্ধি করুন।"),
        "saleAmount": MessageLookupByLibrary.simpleMessage("বিক্রয় পরিমাণ"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("বিক্রয় বিশদ"),
        "salePrice": MessageLookupByLibrary.simpleMessage("বিক্রয় মূল্য"),
        "saleReports": MessageLookupByLibrary.simpleMessage("বিক্রয় রিপোর্ট"),
        "saleReportss": MessageLookupByLibrary.simpleMessage("বিক্রয় রিপোর্ট"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("বিক্রয় রিটার্ন"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("বিক্রয় রিটার্ন রিপোর্ট"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("বিক্রয় সেটিং"),
        "sales": MessageLookupByLibrary.simpleMessage("বিক্রয়"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("বিক্রয় ও ক্রয় প্রতিবেদন"),
        "salesList": MessageLookupByLibrary.simpleMessage("বিক্রয় তালিকা"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("বিক্রয় রিটার্ন"),
        "save": MessageLookupByLibrary.simpleMessage("সংরক্ষণ"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("সংরক্ষণ এবং প্রকাশ করুন"),
        "saveChanges":
            MessageLookupByLibrary.simpleMessage("পরিবর্তন সংরক্ষণ করুন"),
        "saving": MessageLookupByLibrary.simpleMessage("সংরক্ষণ"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("পণ্যের QR কোড স্ক্যান করুন"),
        "search": MessageLookupByLibrary.simpleMessage("অনুসন্ধান করুন"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "পণ্য কোড বা নাম দ্বারা অনুসন্ধান করুন"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("সমস্ত প্রোমো কোড দেখুন"),
        "select": MessageLookupByLibrary.simpleMessage("নির্বাচন করুন"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "রিটার্নের জন্য একটি পণ্য নির্বাচন করুন"),
        "selectBrand":
            MessageLookupByLibrary.simpleMessage("ব্র্যান্ড নির্বাচন করুন"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("বিভাগ নির্বাচন করুন"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("যোগাযোগগুলি নির্বাচন করুন"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("পণ্যের বিভাগ নির্বাচন করুন"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("দোকানের বিভাগ নির্বাচন করুন"),
        "selectTax": MessageLookupByLibrary.simpleMessage("কর নির্বাচন"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("কর প্রকার নির্বাচন করুন"),
        "selectUnit":
            MessageLookupByLibrary.simpleMessage("ইউনিট নির্বাচন করুন"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("পরিবর্তন নির্বাচন করুন: "),
        "seller": MessageLookupByLibrary.simpleMessage("বিক্রেতা"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("বিক্রি করেছেন"),
        "send": MessageLookupByLibrary.simpleMessage("প্রেরণ"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("ইমেল পাঠান"),
        "sendMessage":
            MessageLookupByLibrary.simpleMessage("বার্তা প্রেরণ করুন"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("রিসেট লিঙ্ক পাঠান"),
        "sendSms": MessageLookupByLibrary.simpleMessage("এসএমএস পাঠান"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("এসএমএস প্রেরণ করুন?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("হোয়াটসঅ্যাপ বার্তা পাঠান"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("আপনার ইমেল প্রেরণ করুন"),
        "sendingEmail":
            MessageLookupByLibrary.simpleMessage("ইমেইল পাঠানো হচ্ছে"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("বার্তা পাঠানো হচ্ছে"),
        "serviceShipping": MessageLookupByLibrary.simpleMessage("সেবা/শিপিং"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("আপনার প্রোফাইল সেটআপ করুন"),
        "setting": MessageLookupByLibrary.simpleMessage("সেটিংস"),
        "share": MessageLookupByLibrary.simpleMessage("ভাগ"),
        "shopGST": MessageLookupByLibrary.simpleMessage("দোকানের জিএসটি"),
        "signIn": MessageLookupByLibrary.simpleMessage("সাইন ইন"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("ইমেইল দিয়ে সাইন ইন করুন"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("গ্রাহকের স্বাক্ষর"),
        "size": MessageLookupByLibrary.simpleMessage("আকার"),
        "skip": MessageLookupByLibrary.simpleMessage("এড়িয়ে যান"),
        "sms": MessageLookupByLibrary.simpleMessage("এসএমএস"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("সামাজিক মার্কেটিং"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "দুঃখিত, আপনার এই সেবায় প্রবেশের অনুমতি নেই"),
        "startDate": MessageLookupByLibrary.simpleMessage("শুরুর তারিখ"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("নতুন বিক্রয় শুরু করুন"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage(
            "অনুসন্ধান করতে টাইপ করা শুরু করুন"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "অতিরিক্ত খরচ ছাড়াই প্রযুক্তিগত উন্নতির আগে থাকুন। আমাদের Pos Saas POS সীমাহীন আপগ্রেড আপনার হাতে সর্বদা সর্বশেষ সরঞ্জাম এবং সুবিধা থাকতে নিশ্চিত করে, আপনার ব্যবসা সর্বদা একটি কোটি-একাধিক থাকতে সহায়ক হয়।"),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("এখনও বকেয়া"),
        "stock": MessageLookupByLibrary.simpleMessage("স্টক"),
        "stockIsRequired": MessageLookupByLibrary.simpleMessage("স্টক আবশ্যক"),
        "stockList": MessageLookupByLibrary.simpleMessage("মজুত তালিকা"),
        "stocks": MessageLookupByLibrary.simpleMessage("স্টক"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "এক্সেল ফাইল তৈরি করতে স্টোরেজ অনুমতি প্রয়োজন"),
        "subTaxList":
            MessageLookupByLibrary.simpleMessage("সাব ট্যাক্স তালিকা"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("সাব ট্যাক্স"),
        "subTotal": MessageLookupByLibrary.simpleMessage("উপ-মোট"),
        "submit": MessageLookupByLibrary.simpleMessage("জমা দিন"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "ইউটিউবে আমাদের সাবস্ক্রাইব করুন"),
        "subscription": MessageLookupByLibrary.simpleMessage("সাবস্ক্রিপশন"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("সফলভাবে সম্পন্ন"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("সফলভাবে লগ আউট হয়েছে"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("সফলভাবে আপডেট হয়েছে"),
        "supplier": MessageLookupByLibrary.simpleMessage("সরবরাহকারী"),
        "supplierName": MessageLookupByLibrary.simpleMessage("সরবরাহকারীর নাম"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("সুইফ্ট কোড"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "ড্রাইভার লাইসেন্স, জাতীয় পরিচয় কার্ড বা পাসপোর্টের ছবি তুলুন"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "আপনার তথ্য পরীক্ষা করার জন্য একটি পরিচয়পত্র নিন"),
        "tap": MessageLookupByLibrary.simpleMessage("ট্যাপ"),
        "tax": MessageLookupByLibrary.simpleMessage("কর"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("ট্যাক্স গ্রুপ"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("কর শতাংশ"),
        "taxRate": MessageLookupByLibrary.simpleMessage("ট্যাক্স হার"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "ট্যাক্স হার - আপনার ট্যাক্স হার পরিচালনা করুন"),
        "taxReport": MessageLookupByLibrary.simpleMessage("ট্যাক্স রিপোর্ট"),
        "taxType": MessageLookupByLibrary.simpleMessage("কর প্রকার"),
        "taxes": MessageLookupByLibrary.simpleMessage("কর"),
        "termsAndConditions": MessageLookupByLibrary.simpleMessage("শর্তাবলী"),
        "termsOfUse":
            MessageLookupByLibrary.simpleMessage("ব্যবহারের শর্তাবলী"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("শর্তাবলী ও গোপনীয়তা"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "আপনার বাকি পরিশোধের জন্য আপনাকে ধন্যবাদ"),
        "thankYou": MessageLookupByLibrary.simpleMessage("ধন্যবাদ"),
        "thankYouForYourPurchase": MessageLookupByLibrary.simpleMessage(
            "আপনার ক্রয়ের জন্য আপনাকে ধন্যবাদ"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "এই ইমেইলের জন্য অ্যাকাউন্ট ইতিমধ্যেই বিদ্যমান"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "এক্সেল ফাইল ইতিমধ্যেই ডাউনলোড করা হয়েছে"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "নামটি সব কিছু বলে। Pos Saas POS সীমাহীন ব্যবহারে আপনার ব্যবহারের কোনও সীমা নেই। আপনি যদি কোনও লেনদেন প্রসেস করতে অথবা গ্রাহকের এক গুম থাকতে, তবে আপনি সীমাবদ্ধ নন হওয়া কারণে আত্মবিশ্বাসে কাজ করতে পারেন।"),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "প্রদত্ত পাসওয়ার্ডটি খুবই দুর্বল"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "বিক্রয়টি মুছে ফেলা হবে এবং এই ক্রয়ের সমস্ত তথ্য মুছে ফেলা হবে। আপনি কি মুছে ফেলার ব্যাপারে নিশ্চিত?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "বিক্রয়টি মুছে ফেলা হবে এবং এই বিক্রয়ের সমস্ত তথ্য মুছে ফেলা হবে। আপনি কি মুছে ফেলার ব্যাপারে নিশ্চিত?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "ব্যবহারকারীকে মুছে ফেলা হবে এবং আপনার অ্যাকাউন্ট থেকে সমস্ত ডেটা মুছে ফেলা হবে৷ আপনি কি এটি মুছতে নিশ্চিত?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "ব্যবহারকারী এবং তার সকল তথ্য আপনার অ্যাকাউন্ট থেকে মুছে ফেলা হবে। আপনি কি নিশ্চিত?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("তৃতীয় পক্ষের পরিষেবা"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "এই ক্যাটাগরি মুছতে পারবেন না"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(এই মাসে)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "এই পণ্য ইতিমধ্যেই যোগ করা হয়েছে"),
        "title": MessageLookupByLibrary.simpleMessage("শিরোনাম"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("শিরোনাম খালি থাকতে পারে না"),
        "to": MessageLookupByLibrary.simpleMessage("পর্যন্ত"),
        "toDate": MessageLookupByLibrary.simpleMessage("তারিখ পর্যন্ত"),
        "today": MessageLookupByLibrary.simpleMessage("আজ"),
        "total": MessageLookupByLibrary.simpleMessage("মোট"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("মোট পরিমাণ"),
        "totalCollected": MessageLookupByLibrary.simpleMessage("মোট সংগ্রহ"),
        "totalDue": MessageLookupByLibrary.simpleMessage("মোট বাকি"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("মোট ব্যয়"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("মোট ক্ষতি"),
        "totalPayable": MessageLookupByLibrary.simpleMessage("মোট প্রদেয়"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("মোট মূল্য"),
        "totalProducts": MessageLookupByLibrary.simpleMessage("মোট পণ্য"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("মোট লাভ"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("মোট ক্রয়"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("মোট রিটার্ন পরিমাণ"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("মোট রিটার্ন"),
        "totalSale": MessageLookupByLibrary.simpleMessage("মোট বিক্রয়"),
        "totalStock": MessageLookupByLibrary.simpleMessage("মোট স্টক"),
        "totalValue": MessageLookupByLibrary.simpleMessage("মোট মূল্য"),
        "totalVat": MessageLookupByLibrary.simpleMessage("মোট ভ্যাট"),
        "totals": MessageLookupByLibrary.simpleMessage("মোট: "),
        "transaction": MessageLookupByLibrary.simpleMessage("লেনদেন"),
        "transactionId": MessageLookupByLibrary.simpleMessage("লেনদেন আইডি"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("আবার চেষ্টা কর"),
        "twitter": MessageLookupByLibrary.simpleMessage("টুইটার"),
        "type": MessageLookupByLibrary.simpleMessage("প্রকার"),
        "unitName": MessageLookupByLibrary.simpleMessage("ইউনিটের নাম"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("ইউনিট মূল্য"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("একক মূল্য"),
        "units": MessageLookupByLibrary.simpleMessage("ইউনিট"),
        "unlimited": MessageLookupByLibrary.simpleMessage("সীমাহীন"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("সীমাহীন ব্যবহার"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Pos Saas POS এর ব্যবহারের পূর্ণ সামর্থ্য খোলুন, আমাদের বিশেষজ্ঞ দলের প্রথম প্রশাসক অভিযানের সাথে ব্যক্তিগত প্রশিক্ষণ অধিকার করে। মৌলিক থেকে উন্নত প্রযুক্তিগত কৌশলগুলির জন্য, আমরা আপনি আপনার ব্যবসার প্রক্রিয়াগুলি সর্বোत্তম করতে সিস্টেমের প্রত্যেক দিকে প্রকৌশলিক সম্পূর্ণ শিক্ষিত হওয়া নিশ্চিত করি।"),
        "unpaid": MessageLookupByLibrary.simpleMessage("অবিতরিক"),
        "update": MessageLookupByLibrary.simpleMessage("আপডেট করুন"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("যোগাযোগ আপডেট করুন"),
        "updateNow": MessageLookupByLibrary.simpleMessage("এখনই আপডেট করুন"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("পণ্য আপডেট করুন"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "প্রথমে আপনার পরিকল্পনা আপডেট করুন,\nআপনার সীমা শেষ হয়েছে"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("আপনার প্রোফাইল আপডেট করুন"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "আপনার ডাক্তারের সাথে আরও ভাল ইম্প্রেশনের সাথে সংযোগ করতে আপনার প্রোফাইল আপডেট করুন"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "আপনার প্রোফাইল আপডেট করুন আপনার গ্রাহককে আরও ভাল ছবি দেওয়ার জন্য"),
        "updated": MessageLookupByLibrary.simpleMessage("আপডেট করা হয়েছে"),
        "upload": MessageLookupByLibrary.simpleMessage("আপলোড"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("ডকুমেন্ট আপলোড করুন"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("আপলোড সম্পন্ন"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("ফাইল আপলোড করুন"),
        "upplier": MessageLookupByLibrary.simpleMessage("সরবরাহকারী"),
        "usbC": MessageLookupByLibrary.simpleMessage("ইউএসবি সি"),
        "use": MessageLookupByLibrary.simpleMessage("ব্যবহার"),
        "useMobiPos":
            MessageLookupByLibrary.simpleMessage("Pos Saas ব্যবহার করুন"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("সিস্টেমের ব্যবহার"),
        "userIsDeleted": MessageLookupByLibrary.simpleMessage(
            "ব্যবহারকারী মুছে ফেলা হয়েছে"),
        "userRole": MessageLookupByLibrary.simpleMessage("ব্যবহারকারী ভূমিকা"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("ব্যবহারকারী ভূমিকা বিবরণ"),
        "userTitle":
            MessageLookupByLibrary.simpleMessage("ব্যবহারকারী শিরোনাম"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "ব্যবহারকারীর শিরোনাম খালি হতে পারবে না"),
        "value": MessageLookupByLibrary.simpleMessage("মূল্য"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("ভ্যাট প্রযোজ্য নয়"),
        "verifyOtp":
            MessageLookupByLibrary.simpleMessage("OTP যাচাই করা হচ্ছে"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("ফোন নম্বর যাচাই করুন"),
        "viewAll": MessageLookupByLibrary.simpleMessage("সব দেখ"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("বিস্তারিত দেখুন"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("ওয়াক-ইন গ্রাহক"),
        "warehouse": MessageLookupByLibrary.simpleMessage("গুদাম"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("গুদাম ইতিমধ্যেই বিদ্যমান"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("গুদাম তালিকা"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("গুদাম নাম"),
        "warranty": MessageLookupByLibrary.simpleMessage("ওয়ারেন্টি"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "আমরা এখানে পাসওয়ার্ড রিসেট করার নির্দেশাবলী সহ একটি ইমেল পাঠিয়েছি:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "আমরা আমাদের অ্যাপের কার্যকারিতাকে সমর্থন করার জন্য তৃতীয় পক্ষের পরিষেবাগুলি ব্যবহার করতে পারি, যেমন বিশ্লেষণ প্রদানকারী এবং পেমেন্ট প্রসেসর। আপনি যখন আমাদের অ্যাপ ব্যবহার করেন তখন এই তৃতীয় পক্ষের পরিষেবাগুলি আপনার সম্পর্কে তথ্য সংগ্রহ করতে পারে। দয়া করে মনে রাখবেন যে আমরা এই তৃতীয় পক্ষের পরিষেবাগুলির গোপনীয়তা অনুশীলনের জন্য দায়ী নই।"),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "আমরা এনক্রিপশন এবং সুরক্ষিত সঞ্চয়স্থান সহ আপনার ব্যক্তিগত তথ্য সুরক্ষিত করার জন্য শিল্প-মান ব্যবস্থা গ্রহণ করি। আমরা শুধুমাত্র অনুমোদিত কর্মীদের জন্য আপনার তথ্য অ্যাক্সেস সীমিত."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "আমরা সহজলাভ চালানোর গুরুত্ব বুঝি। তাই আমাদের সার্বক্ষণিক সমর্থন আপনাকে সাহায্য করতে উপলব্ধ, আপনি যে কোনও দ্বিমুथ্য প্রশ্ন বা সামগ্রিক চিন্তা হোক। আমরা অবিচ্ছেদ্য গ্রাহক সেবা অনুভব করার জন্য যে কোনও সময়, যে কোথাও কল বা WhatsApp দ্বারা যোগাযোগ করতে পারেন।"),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "আমরা আপনার ব্যক্তিগত তথ্য ব্যবহার করি আপনাকে আমাদের অ্যাপে সম্ভাব্য সর্বোত্তম অভিজ্ঞতা প্রদানের জন্য, যার মধ্যে আপনার বিষয়বস্তুর প্রস্তাবনাগুলি ব্যক্তিগতকৃত করা, আপনাকে বিশেষজ্ঞদের সাথে সংযোগ করা এবং আমাদের অ্যাপের কার্যকারিতা উন্নত করা। আমরা আপডেট, প্রচার, বা আমাদের অ্যাপ সম্পর্কিত অন্যান্য তথ্য সম্পর্কে আপনার সাথে যোগাযোগ করতে আপনার তথ্য ব্যবহার করতে পারি।"),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "আমরা অর্থপ্রদান পর্যালোচনা করব এবং ১-২ ঘন্টার মধ্যে অনুমোদন করব"),
        "weekly": MessageLookupByLibrary.simpleMessage("সাপ্তাহিক"),
        "weight": MessageLookupByLibrary.simpleMessage("ওজন"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("নতুন কি"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("পাইকারী বিক্রেতা"),
        "wholeSalePrice": MessageLookupByLibrary.simpleMessage("হোলসেল মূল্য"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("পাইকারি মূল্য"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("পাইকারি বিক্রেতা"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("শীঘ্রই যোগ করা হবে"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("মেয়াদ শেষ হবে"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("আপনার বার্তা এখানে লিখুন"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("ভুল ওটিপি"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "সেই ব্যবহারকারীর জন্য দেওয়া ভুল পাসওয়ার্ড।"),
        "yearly": MessageLookupByLibrary.simpleMessage("বার্ষিক"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("হ্যাঁ, চিরতরে মুছুন"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("আপনি বৈধ ব্যবহারকারী নন"),
        "youAreUsing":
            MessageLookupByLibrary.simpleMessage("আপনি ব্যবহার করছেন"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "আপনি নির্ধারিত বকেয়ার চেয়ে বেশি পরিশোধ করতে পারবেন না"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("আপনি একটি ইমেল পেয়েছেন"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "আপনি সফলভাবে আপনার অ্যাকাউন্টে লগইন করেছেন৷ Pos Saas এর সাথে থাকুন"),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("আপনাকে অনুমতি দিতে হবে"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "আপনাকে আপনার অ্যাকাউন্টে পুনরায় লগইন করতে হবে।"),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "আপনি ক্রয় করার আগে পরিচয় যাচাই করতে আপনার প্রয়োজন"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("আপনার বার্তা বাকি আছে"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("আপনার প্যাকেজ"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "আপনার প্যাকেজ ৫ দিনে মেয়াদ উত্তীর্ণ হবে")
      };
}
