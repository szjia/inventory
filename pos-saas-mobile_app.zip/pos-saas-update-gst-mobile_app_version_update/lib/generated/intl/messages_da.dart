// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a da locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'da';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Fortsæt"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("Momsnummer"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP":
            MessageLookupByLibrary.simpleMessage("Maksimal udsalgspris (MRP)"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("Maksimalpris er påkrævet"),
        "OK": MessageLookupByLibrary.simpleMessage("OK"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Tlf.nr."),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT-kode"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Snacks"),
        "TAX": MessageLookupByLibrary.simpleMessage("MOMS"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Uploader"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("Brugertitel"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Din pakke udløber i dag\n\nKøb venligst igen"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) Systemet leveres udelukkende med det formål at lette salgstransaktioner og relaterede aktiviteter i din virksomhed."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) For at bruge Systemet kan det være nødvendigt at oprette en konto. Du accepterer at give nøjagtige, aktuelle og fuldstændige oplysninger under registreringsprocessen og opdatere sådanne oplysninger for at holde dem nøjagtige og fuldstændige."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("Om appen"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Om os"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Accept af Vilkår"),
        "accountName": MessageLookupByLibrary.simpleMessage("Kontonavn"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("Kontonummer"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Kontooprettelse"),
        "acton": MessageLookupByLibrary.simpleMessage("Handling"),
        "add": MessageLookupByLibrary.simpleMessage("Tilføj"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Tilføj mærke"),
        "addCategory": MessageLookupByLibrary.simpleMessage("Tilføj kategori"),
        "addContact": MessageLookupByLibrary.simpleMessage("Tilføj kontakt"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Tilføj kunde"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("Tilføj levering"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Tilføj beskrivelse"),
        "addDescription": MessageLookupByLibrary.simpleMessage("Tilføj note"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Tilføj rabat"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Tilføj dokument-ID"),
        "addDucument": MessageLookupByLibrary.simpleMessage("Tilføj dokument"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Tilføj udgift"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Tilføj udgiftskategori"),
        "addItems": MessageLookupByLibrary.simpleMessage("Tilføj varer"),
        "addNew": MessageLookupByLibrary.simpleMessage("Tilføj ny"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Tilføj ny adresse"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Tilføj nyt produkt"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("Tilføj ny skat"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Tilføj ny skat med enkelt/flere skatte typer"),
        "addNote": MessageLookupByLibrary.simpleMessage("Tilføj note"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Tilføj produkt først"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Tilføj kampagnekode"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Tilføj køb"),
        "addSales": MessageLookupByLibrary.simpleMessage("Tilføj salg"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Tilføjet med succes"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Tilføj enhed"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Tilføj brugerrolle"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Tilføjet succesfuldt"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("Tilføjet til kurv"),
        "address": MessageLookupByLibrary.simpleMessage("Adresse"),
        "admin": MessageLookupByLibrary.simpleMessage("Administrator"),
        "all": MessageLookupByLibrary.simpleMessage("Alle"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("Alle forretningsløsninger"),
        "alreadyAdded":
            MessageLookupByLibrary.simpleMessage("Allerede tilføjet"),
        "alreadyExists":
            MessageLookupByLibrary.simpleMessage("Eksisterer allerede"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Har allerede en konto"),
        "amount": MessageLookupByLibrary.simpleMessage("Beløb"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "En e-mail er sendt\\nTjek din indbakke"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Android- og iOS-app-understøttelse"),
        "applicableTax": MessageLookupByLibrary.simpleMessage("Gældende moms"),
        "apply": MessageLookupByLibrary.simpleMessage("Anvend"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Er du sikker på, at du vil slette denne faktura"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Er du sikker på, at du vil slette dette salg"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Er du sikker på, at du vil slette denne bruger"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Er du sikker på, at du vil slette denne skat"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Er du sikker på, at du vil slette denne skattegruppe"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Er du sikker på, at du vil slette dette lager"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Er du sikker på, at du vil slette denne bruger?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Autoriseret underskrift"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Du er ansvarlig for at opretholde fortroligheden af din konto og adgangskode samt begrænse adgangen til din konto. Du accepterer ansvaret for alle aktiviteter, der forekommer under din konto."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Du skal være mindst 18 år gammel eller den lovlige myndighedsalder i din jurisdiktion for at bruge Systemet."),
        "backSide": MessageLookupByLibrary.simpleMessage("Bagside"),
        "backToHome": MessageLookupByLibrary.simpleMessage("Tilbage til start"),
        "balance": MessageLookupByLibrary.simpleMessage("Balance"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladesh"),
        "bank": MessageLookupByLibrary.simpleMessage("Bank"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Bankkonto-valuta"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Bankkontovaluta"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Bankoplysninger"),
        "bankName": MessageLookupByLibrary.simpleMessage("Banknavn"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("Bankoverførsel"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Stregkode fundet"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Regning/Faktura"),
        "billTo": MessageLookupByLibrary.simpleMessage("Fakturer til"),
        "branchName": MessageLookupByLibrary.simpleMessage("Filialnavn"),
        "brand": MessageLookupByLibrary.simpleMessage("Mærke"),
        "brandName": MessageLookupByLibrary.simpleMessage("Mærkenavn"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("Masse\\nUpload"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Virksomhedskategori"),
        "buy": MessageLookupByLibrary.simpleMessage("Køb"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Køb Premium Plan"),
        "buySms": MessageLookupByLibrary.simpleMessage("Køb SMS"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Ved at få adgang til eller bruge Salgspunktet (POS) Systemet (\"Systemet\") leveret af [Dit Firmnavn] (\"Firmaet\"), accepterer du at være bundet af disse Brugsbetingelser. Hvis du ikke accepterer disse Brugsbetingelser, må du ikke bruge Systemet."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Du er ansvarlig for at sikre, at din adgang til og brug af Systemet er i overensstemmelse med alle gældende love og regler."),
        "cacel": MessageLookupByLibrary.simpleMessage("Afbryd"),
        "call": MessageLookupByLibrary.simpleMessage("Ring op"),
        "callForEmergencySupport":
            MessageLookupByLibrary.simpleMessage("Ring for nødhjælp"),
        "camera": MessageLookupByLibrary.simpleMessage("Kamera"),
        "cancel": MessageLookupByLibrary.simpleMessage("Annuller"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Annuller alle produkter"),
        "capacity": MessageLookupByLibrary.simpleMessage("Kapacitet"),
        "card": MessageLookupByLibrary.simpleMessage("Kort"),
        "cash": MessageLookupByLibrary.simpleMessage("Kontant"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Kontantfri"),
        "categories": MessageLookupByLibrary.simpleMessage("Kategorier"),
        "category": MessageLookupByLibrary.simpleMessage("Kategori"),
        "categoryName": MessageLookupByLibrary.simpleMessage("Kategorinavn"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "Kategorinavnet findes allerede"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("Kategorinavn"),
        "change": MessageLookupByLibrary.simpleMessage("Skift?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Skift adgangskode"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("Tjek e-mail"),
        "choseACustomer": MessageLookupByLibrary.simpleMessage("Vælg en kunde"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Vælg en leverandør"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Vælg dine funktioner"),
        "clarence": MessageLookupByLibrary.simpleMessage("Clarence"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Klik for at forbinde"),
        "close": MessageLookupByLibrary.simpleMessage("Luk"),
        "color": MessageLookupByLibrary.simpleMessage("Farve"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(Kombination af flere skatter)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Kommer snart"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Virksomhedsadresse"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Firma- og butiksnavn"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("Firma- og Forretningsnavn"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Fuldfør transaktion"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Bekræft adgangskode"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Bekræft returnering"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Tillykke"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Kontakt os"),
        "continu": MessageLookupByLibrary.simpleMessage("Fortsæt"),
        "country": MessageLookupByLibrary.simpleMessage("Land"),
        "create": MessageLookupByLibrary.simpleMessage("Opret"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Opret en gratis konto"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Oprettet og gemt"),
        "currency": MessageLookupByLibrary.simpleMessage("Valuta"),
        "currentStock":
            MessageLookupByLibrary.simpleMessage("Aktuel beholdning"),
        "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
            "Brugerdefineret fakturabranding"),
        "customer": MessageLookupByLibrary.simpleMessage("Kunde"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Kundedetaljer"),
        "customerGST": MessageLookupByLibrary.simpleMessage("Kundemoms"),
        "customerName": MessageLookupByLibrary.simpleMessage("Kundenavn"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Daglig transaktion"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Overblik over dashboard"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Data gemt succesfuldt"),
        "date": MessageLookupByLibrary.simpleMessage("Dato"),
        "day": MessageLookupByLibrary.simpleMessage("Dag"),
        "dealer": MessageLookupByLibrary.simpleMessage("Forhandler"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("Forhandlerpris"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("Standard momsprocent"),
        "delete": MessageLookupByLibrary.simpleMessage("Slet"),
        "deleting": MessageLookupByLibrary.simpleMessage("Sletter"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Leveringsadresse"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Leveringsadresser"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Leveringsgebyr"),
        "describtion": MessageLookupByLibrary.simpleMessage("Beskrivelse"),
        "description": MessageLookupByLibrary.simpleMessage("Beskrivelse"),
        "descriptionCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Beskrivelse kan ikke være tom"),
        "details": MessageLookupByLibrary.simpleMessage("Detaljer"),
        "discount": MessageLookupByLibrary.simpleMessage("Rabat"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Forstyrr ikke"),
        "done": MessageLookupByLibrary.simpleMessage("Færdig"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Download Excel-format"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Downloadet succesfuldt i download-mappen"),
        "due": MessageLookupByLibrary.simpleMessage("Skyldig"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Skyldig beløb: "),
        "dueCollection":
            MessageLookupByLibrary.simpleMessage("Indsamling af skyldig beløb"),
        "dueCollectionReports": MessageLookupByLibrary.simpleMessage(
            "Rapporter om forfaldne indbetalinger"),
        "dueList": MessageLookupByLibrary.simpleMessage("Skyldig liste"),
        "dueReports": MessageLookupByLibrary.simpleMessage("Skylderapport"),
        "duration": MessageLookupByLibrary.simpleMessage("Varighed"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Varighed: Fra"),
        "easyToUseMobilePos":
            MessageLookupByLibrary.simpleMessage("Let at bruge mobil POS"),
        "edit": MessageLookupByLibrary.simpleMessage("Rediger"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Rediger købsfaktura"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Rediger salgsfaktura"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Rediger sociale medier"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Redigering fuldført"),
        "editTax": MessageLookupByLibrary.simpleMessage("Rediger skat"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Rediger skattegruppe"),
        "editWarehouse": MessageLookupByLibrary.simpleMessage("Rediger lager"),
        "email": MessageLookupByLibrary.simpleMessage("E-mail"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("E-mailadresse"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Email kan ikke være tom"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "E-mail sendt! Tjek din indbakke"),
        "endDate": MessageLookupByLibrary.simpleMessage("Slutdato"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Indtast et gyldigt beløb"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Indtast en gyldig rabat"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Indtast et gyldigt telefonnummer"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Indtast en gyldig pris"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("Indtast en gyldig mængde"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("Indtast adresse"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("Indtast beløb."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Indtast mærkenavn"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Indtast kapacitet"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Indtast kategorinavn"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Indtast farve"),
        "enterCustomerGstNumber":
            MessageLookupByLibrary.simpleMessage("Indtast kundens momsnummer"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Indtast forhandlerpris"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Indtast beskrivelse"),
        "enterDiscount": MessageLookupByLibrary.simpleMessage("Indtast rabat"),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Indtast udgiftsdato"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Indtast fuld adresse"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Indtast fakturanummer"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Indtast mængde for lav lageradvarsel"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Indtast producent"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("Indtast beskedindhold"),
        "enterMrpOrRetailerPirce":
            MessageLookupByLibrary.simpleMessage("Indtast MRP/Detailpris"),
        "enterName": MessageLookupByLibrary.simpleMessage("Indtast navn"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Indtast note"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Indtast partinavn"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Indtast telefonnummer"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Indtast produktkode eller scan"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Indtast produktnavn"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Indtast købspris"),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("Indtast referencenummer"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Indtast størrelse"),
        "enterStocks":
            MessageLookupByLibrary.simpleMessage("Indtast lagerbeholdning"),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Indtast skattesats"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("Indtast transaktions-ID"),
        "enterType": MessageLookupByLibrary.simpleMessage("Indtast type"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("Indtast brugertitel"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Indtast gyldigt beløb"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Indtast lagerets navn"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Indtast vægt"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Indtast engrospris"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("Indtast din beskrivelse her"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("Indtast din e-mailadresse"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "Indtast titel til din feedback"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Indtast dit momsnummer"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("Indtast dit mobilnummer"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Indtast dit navn"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("Indtast dit telefonnummer"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Indtast din adgangskode"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Indtast dit telefonnummer"),
        "enterYourTransactionId":
            MessageLookupByLibrary.simpleMessage("Indtast din transaktions-ID"),
        "error": MessageLookupByLibrary.simpleMessage("Fejl"),
        "excTax": MessageLookupByLibrary.simpleMessage("Ekskl. moms"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("Excel-upload"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Eksklusiv"),
        "expense": MessageLookupByLibrary.simpleMessage("Udgifter"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Udgiftskategori"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Udgiftsdato"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Udgift til"),
        "expenseReport": MessageLookupByLibrary.simpleMessage("Udgiftsrapport"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Udløbsdato"),
        "expired": MessageLookupByLibrary.simpleMessage("Udløbet"),
        "expiring": MessageLookupByLibrary.simpleMessage("Udløber"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Mislykkedes med fejl"),
        "fashion": MessageLookupByLibrary.simpleMessage("Mode"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Funktioner er den vigtige del, der adskiller Pos Saas fra traditionelle løsninger."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Feedback"),
        "firstName": MessageLookupByLibrary.simpleMessage("Fornavn"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Følg os på\\nFacebook"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Følg os på\\nTwitter"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Forside"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("Til ubegrænset brug"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Glemt adgangskode"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Glemt adgangskode?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Fra dato"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("Gratis databackup"),
        "freeLifeTimeUpdate":
            MessageLookupByLibrary.simpleMessage("Gratis livslang opdatering"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Gratis pakke"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Gratis plan"),
        "from": MessageLookupByLibrary.simpleMessage("(Fra"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Fuldt betalt"),
        "gallary": MessageLookupByLibrary.simpleMessage("Galleri"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("Genererer PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Hent OTP"),
        "govermentId": MessageLookupByLibrary.simpleMessage("Regerings-ID"),
        "guest": MessageLookupByLibrary.simpleMessage("Gæst"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Har du ikke en konto?"),
        "history": MessageLookupByLibrary.simpleMessage("Historik"),
        "home": MessageLookupByLibrary.simpleMessage("Hjem"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Hvordan vi beskytter dine oplysninger"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Hvordan vi bruger dine oplysninger"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Identitetsbekræftelse"),
        "image": MessageLookupByLibrary.simpleMessage("Billede"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("InHouse kan ikke slettes"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("InHouse kan ikke redigeres"),
        "inWord": MessageLookupByLibrary.simpleMessage("Med ord"),
        "incTax": MessageLookupByLibrary.simpleMessage("Inkl. moms"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Inklusiv"),
        "increaseStock":
            MessageLookupByLibrary.simpleMessage("Forøg lagerbeholdning"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Instrument"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Fakturanummer"),
        "invoice": MessageLookupByLibrary.simpleMessage("Faktura"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("Fakturanummer"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Faktura indstilling"),
        "invoiceViewer": MessageLookupByLibrary.simpleMessage("Fakturavisning"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Vare tilføjet"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("KYC Verifikation"),
        "language": MessageLookupByLibrary.simpleMessage("Sprog"),
        "lastName": MessageLookupByLibrary.simpleMessage("Efternavn"),
        "ledger": MessageLookupByLibrary.simpleMessage("Bogføring"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Livstids\nKøb"),
        "link": MessageLookupByLibrary.simpleMessage("Link"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Live Chat Support"),
        "loading": MessageLookupByLibrary.simpleMessage("Indlæser"),
        "logIn": MessageLookupByLibrary.simpleMessage("Log ind"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Log ud"),
        "logOut": MessageLookupByLibrary.simpleMessage("Log ud"),
        "login": MessageLookupByLibrary.simpleMessage("Log ind"),
        "logo": MessageLookupByLibrary.simpleMessage("Logo"),
        "loss": MessageLookupByLibrary.simpleMessage("Tab"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Tab/Profit"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Detaljer om tab/profit"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Tab/Fortjeneste-rapport"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Tab/Fortjeneste-rapporter"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Lav lageradvarsel"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Gør en varig impression på dine kunder med mærkede fakturaer. Vores Ubegrænsede Opgradering tilbyder den unikke fordel ved at tilpasse dine fakturaer, tilføje et professionelt touch, der styrker din brandidentitet og fremmer kundeloyalitet."),
        "manageYourBussinessWith": MessageLookupByLibrary.simpleMessage(
            "Administrer din virksomhed med"),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Produktionsdato"),
        "margin": MessageLookupByLibrary.simpleMessage("Margin"),
        "masterCard": MessageLookupByLibrary.simpleMessage("MasterCard"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Producent"),
        "message": MessageLookupByLibrary.simpleMessage("Besked"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Beskedhistorik"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Pos Saas-appen er gratis og nem at bruge. Faktisk er den en af de bedste POS-systemer i verden."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas er en komplet forretningsløsning med lager, regnskab, salg, udgifter og tab/profit."),
        "mobile": MessageLookupByLibrary.simpleMessage("Mobil"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("Mobilbetaling"),
        "monthly": MessageLookupByLibrary.simpleMessage("Månedlig"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("Mere info"),
        "name": MessageLookupByLibrary.simpleMessage("Indtast dit navn."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Navnet findes allerede"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("Navnet må ikke være tomt"),
        "next": MessageLookupByLibrary.simpleMessage("Næste"),
        "noConnection":
            MessageLookupByLibrary.simpleMessage("Ingen forbindelse"),
        "noData": MessageLookupByLibrary.simpleMessage("Ingen data"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Ingen data tilgængelige"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Ingen data fundet"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("Ingen historik fundet!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Ingen produkter fundet"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("Ingen underafgift valgt"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("Ingen transaktion fundet!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Ingen bruger fundet med den e-mailadresse."),
        "noUserRoleFound":
            MessageLookupByLibrary.simpleMessage("Ingen brugerrolle fundet"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Ikke aktiv bruger"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Ikke angivet"),
        "note": MessageLookupByLibrary.simpleMessage("Note"),
        "notes": MessageLookupByLibrary.simpleMessage("Noter"),
        "notification": MessageLookupByLibrary.simpleMessage("Notifikation"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP sendt til"),
        "office": MessageLookupByLibrary.simpleMessage("Kontor"),
        "ok": MessageLookupByLibrary.simpleMessage("OK"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS, der indeholder en masse funktionalitet, herunder salgssporing og lagerstyring."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Dette system hjælper dig med at forbedre dine operationer for dine kunder."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Vores POS-system bør automatisere daglige operationer og gøre det nemt at navigere."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("Åbningsbalance"),
        "order": MessageLookupByLibrary.simpleMessage("Ordrer"),
        "other": MessageLookupByLibrary.simpleMessage("Andet"),
        "otp": MessageLookupByLibrary.simpleMessage("Luk"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Ikke på lager"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Pakke"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Pakkefunktioner"),
        "paid": MessageLookupByLibrary.simpleMessage("Betalt"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Betalt beløb"),
        "parties": MessageLookupByLibrary.simpleMessage("Parter"),
        "partiesList":
            MessageLookupByLibrary.simpleMessage("Liste over parter"),
        "partyGST": MessageLookupByLibrary.simpleMessage("Parti moms"),
        "partyName": MessageLookupByLibrary.simpleMessage("Partinavn"),
        "password": MessageLookupByLibrary.simpleMessage("Adgangskode"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Adgangskoden og bekræftelsen stemmer ikke overens"),
        "passwordCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Adgangskode kan ikke være tom"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("Adgangskoden matcher ikke"),
        "payCash": MessageLookupByLibrary.simpleMessage("Betal kontant"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash": MessageLookupByLibrary.simpleMessage("Betal med bkash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Betal med Paypal"),
        "payeeName": MessageLookupByLibrary.simpleMessage("Modtager navn"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("Modtager nummer"),
        "payment": MessageLookupByLibrary.simpleMessage("Betaling"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("Betalt beløb"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Betaling fuldført"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Betalingsinstruktion:"),
        "paymentMethod":
            MessageLookupByLibrary.simpleMessage("Betalingsmetode"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Betalingsmetode"),
        "pdfView": MessageLookupByLibrary.simpleMessage("PDF-visning"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Personlige oplysninger"),
        "phone": MessageLookupByLibrary.simpleMessage("Telefon"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Telefonnummer"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Telefonnummeret er allerede brugt"),
        "phoneNumberIsNotValid": MessageLookupByLibrary.simpleMessage(
            "Telefonnummeret er ikke gyldigt"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("Telefonnummer er påkrævet"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("Vælg og upload fil"),
        "pickEndDate": MessageLookupByLibrary.simpleMessage("Vælg slutdato"),
        "pickStartDate": MessageLookupByLibrary.simpleMessage("Vælg startdato"),
        "plan": MessageLookupByLibrary.simpleMessage("Plan"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("Tilføj venligst mængde"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Tjek venligst din internetforbindelse"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Forbind venligst printeren først"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Tilslut venligst din Bluetooth-printer"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Indtast en længere adgangskode"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Indtast venligst en bekræftelsesadgangskode"),
        "pleaseEnterAPassword": MessageLookupByLibrary.simpleMessage(
            "Indtast venligst en adgangskode"),
        "pleaseEnterAValidEmail":
            MessageLookupByLibrary.simpleMessage("Indtast en gyldig email"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Indtast venligst navn"),
        "pleaseEnterPassword": MessageLookupByLibrary.simpleMessage(
            "Indtast venligst adgangskode"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Indtast din e-mailadresse nedenfor for at modtage et link til nulstilling af adgangskoden."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Indtast venligst transaktionsnummer"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("Indtast beløb"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Vælg venligst en kategori først"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("Vælg venligst en plan"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Vælg venligst virksomheds kategori"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Brug venligst den gyldige købekode for at bruge appen"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Drevet af Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Drevet af"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Premium kundesupport"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Premium-plan"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Tidligere betalingsbeløb"),
        "price": MessageLookupByLibrary.simpleMessage("Pris"),
        "print": MessageLookupByLibrary.simpleMessage("Udskriv"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Udskrivningsmulighed"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Fortrolighedspolitik"),
        "product": MessageLookupByLibrary.simpleMessage("Produkt"),
        "productCode": MessageLookupByLibrary.simpleMessage("Produktkode"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("Produktkode er påkrævet"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Produktkode/Navn"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Produktbeskrivelse"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Produktdetaljer"),
        "productList": MessageLookupByLibrary.simpleMessage("Produktliste"),
        "productName": MessageLookupByLibrary.simpleMessage("Produktnavn"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Produktnavn findes allerede i dette lager"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Produktnavn er allerede tilføjet"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("Produktnavn er påkrævet"),
        "products": MessageLookupByLibrary.simpleMessage("Produkter"),
        "profile": MessageLookupByLibrary.simpleMessage("Profil"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("Rediger profil"),
        "profit": MessageLookupByLibrary.simpleMessage("Profit"),
        "promo": MessageLookupByLibrary.simpleMessage("Kampagne"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Kampagnekode"),
        "purchase": MessageLookupByLibrary.simpleMessage("Køb"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage("Købsalarm"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Køb bekræftet"),
        "purchaseDetails": MessageLookupByLibrary.simpleMessage("Købsdetaljer"),
        "purchaseInvoice": MessageLookupByLibrary.simpleMessage("Købsfaktura"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("Købsliste"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Køb nu"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Køb Premium Plan"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("Købspris"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("Købspris er påkrævet"),
        "purchaseRepoet": MessageLookupByLibrary.simpleMessage("Købsrapport"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Købsrapporter"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Købsrapporter"),
        "purchaseReturn": MessageLookupByLibrary.simpleMessage("Retur af køb"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("Købsretur-rapport"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Købsovergang"),
        "qty": MessageLookupByLibrary.simpleMessage("Antal"),
        "quantity": MessageLookupByLibrary.simpleMessage("Antal"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Seneste transaktioner"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("Modtaget PIN-kode"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Referencenummer"),
        "register": MessageLookupByLibrary.simpleMessage("Registrer"),
        "registering": MessageLookupByLibrary.simpleMessage("Registrerer"),
        "remainingDue":
            MessageLookupByLibrary.simpleMessage("Resterende skyldig"),
        "remove": MessageLookupByLibrary.simpleMessage("Fjern"),
        "reports": MessageLookupByLibrary.simpleMessage("Rapporter"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Anmodning er sendt"),
        "resendCode": MessageLookupByLibrary.simpleMessage("Gensend kode"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("Gensend OTP: "),
        "retailer": MessageLookupByLibrary.simpleMessage("Detailhandler"),
        "retur": MessageLookupByLibrary.simpleMessage("Returner"),
        "returN": MessageLookupByLibrary.simpleMessage("Retur"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("Returbeløb"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("Returbeløb"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("Returneret mængde"),
        "revenue": MessageLookupByLibrary.simpleMessage("Indtægter"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Beskyt dine forretningsdata ubesværet. Vores Pos Saas POS Ubegrænset Opgradering inkluderer gratis databackup, der sikrer, at dine værdifulde oplysninger er beskyttet mod uforudsete begivenheder. Fokuser på det, der virkelig betyder noget - væksten af din virksomhed."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Salgsbeløb"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("Salgsdetaljer"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Salgspris"),
        "saleReports": MessageLookupByLibrary.simpleMessage("Salgsrapport"),
        "saleReportss": MessageLookupByLibrary.simpleMessage("Salgsrapporter"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("Salgsretur"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Salgsretur-rapport"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("Salgsindstilling"),
        "sales": MessageLookupByLibrary.simpleMessage("Salg"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("Salgs- og Købsrapporter"),
        "salesList": MessageLookupByLibrary.simpleMessage("Salgsliste"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("Salgsretur"),
        "save": MessageLookupByLibrary.simpleMessage("Gem"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Gem og offentliggør"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("Gem ændringer"),
        "saving": MessageLookupByLibrary.simpleMessage("Gemmer"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("Scan produktets QR-kode"),
        "search": MessageLookupByLibrary.simpleMessage("Søg"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Søg efter produktkode eller navn"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("Se alle kampagnekoder"),
        "select": MessageLookupByLibrary.simpleMessage("Vælg"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Vælg et produkt til returnering"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Vælg mærke"),
        "selectCategory": MessageLookupByLibrary.simpleMessage("Vælg kategori"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Vælg kontakter"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("Vælg produktkategori"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("Vælg butikskategori"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Vælg moms"),
        "selectTaxType": MessageLookupByLibrary.simpleMessage("Vælg momstype"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("Vælg enhed"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Vælg variation: "),
        "seller": MessageLookupByLibrary.simpleMessage("Sælger"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Sælges af"),
        "send": MessageLookupByLibrary.simpleMessage("Send"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("Send e-mail"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Send besked"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("Send nulstillingslink"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Send SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Send sms?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Send WhatsApp-besked"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Send din e-mail"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage("Sender e-mail"),
        "sendingMessage": MessageLookupByLibrary.simpleMessage("Sender besked"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Service/Forsendelse"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Opsæt din profil"),
        "setting": MessageLookupByLibrary.simpleMessage("Indstillinger"),
        "share": MessageLookupByLibrary.simpleMessage("Del"),
        "shopGST": MessageLookupByLibrary.simpleMessage("Butiks moms"),
        "signIn": MessageLookupByLibrary.simpleMessage("Log ind"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("Log ind med email"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Kundens underskrift"),
        "size": MessageLookupByLibrary.simpleMessage("Størrelse"),
        "skip": MessageLookupByLibrary.simpleMessage("Spring over"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Sociale medier marketing"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Beklager, du har ikke tilladelse til at få adgang til denne service"),
        "startDate": MessageLookupByLibrary.simpleMessage("Startdato"),
        "startNewSale": MessageLookupByLibrary.simpleMessage("Start nyt salg"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage(
            "Begynd at skrive for at søge"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Forbliv i frontlinjen af teknologiske fremskridt uden ekstra omkostninger. Vores Pos Saas POS Ubegrænset Opgradering sikrer, at du altid har de nyeste værktøjer og funktioner lige ved hånden og garanterer, at din virksomhed forbliver skarpskåren."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("Stadig ubetalt"),
        "stock": MessageLookupByLibrary.simpleMessage("Lager"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Lager er påkrævet"),
        "stockList": MessageLookupByLibrary.simpleMessage("Lagerliste"),
        "stocks": MessageLookupByLibrary.simpleMessage("Lagerbeholdning"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Lageradgang er påkrævet for at oprette Excel-fil"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("Underafgiftsliste"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Underafgifter"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Subtotal"),
        "submit": MessageLookupByLibrary.simpleMessage("Indsend"),
        "subscribeToOurYoutube":
            MessageLookupByLibrary.simpleMessage("Abonner på vores\\nYoutube"),
        "subscription": MessageLookupByLibrary.simpleMessage("Abonnement"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Udført med succes"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Logget ud med succes"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Opdateret med succes"),
        "supplier": MessageLookupByLibrary.simpleMessage("Leverandør"),
        "supplierName": MessageLookupByLibrary.simpleMessage("Leverandørnavn"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT-kode"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Tag et kørekort, nationalt identitetskort eller pasfoto"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "Tag et ID-kort for at kontrollere dine oplysninger"),
        "tap": MessageLookupByLibrary.simpleMessage("Tryk"),
        "tax": MessageLookupByLibrary.simpleMessage("Skat"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Skattegruppe"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("Skatteprocent"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Skattesats"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Skattesatser - Administrer dine skattesatser"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Skatterapport"),
        "taxType": MessageLookupByLibrary.simpleMessage("Momstype"),
        "taxes": MessageLookupByLibrary.simpleMessage("Skatter"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Vilkår og betingelser"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("Brugsbetingelser"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Vilkår & Privatliv"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Tak for din betaling af skyldig beløb"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Tak"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Tak for dit køb"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "Der findes allerede en konto med den e-mail"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Excel-filen er allerede downloadet"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Navnet siger det hele. Med Pos Saas POS Ubegrænset er der ingen begrænsning for din brug. Uanset om du behandler en håndfuld transaktioner eller oplever en strøm af kunder, kan du arbejde med tillid og vide, at du ikke er begrænset af begrænsninger."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "Den indtastede adgangskode er for svag"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Salget vil blive slettet, og alle data om dette køb vil blive slettet. Er du sikker på, at du vil slette dette"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Salget vil blive slettet, og alle data om dette salg vil blive slettet. Er du sikker på, at du vil slette dette"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Brugeren vil blive slettet, og alle data slettes fra din konto. Er du sikker på, at du vil slette dette?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Brugeren vil blive slettet, og alle data vil blive slettet fra din konto. Er du sikker på, at du vil slette dette?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Tredjepartstjenester"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Denne kategori kan ikke slettes"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Denne måned)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Dette produkt er allerede tilføjet"),
        "title": MessageLookupByLibrary.simpleMessage("Titel"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Titel kan ikke være tom"),
        "to": MessageLookupByLibrary.simpleMessage("til"),
        "toDate": MessageLookupByLibrary.simpleMessage("Til dato"),
        "today": MessageLookupByLibrary.simpleMessage("I dag"),
        "total": MessageLookupByLibrary.simpleMessage("Samlet"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Totalbeløb"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Samlet indsamlet"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Samlet skyldig"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("Samlet udgift"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Samlet tab"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("Samlet betalbart"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Samlet pris"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("Samlede produkter"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Samlet overskud"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("Samlet køb"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Total returbeløb"),
        "totalReturns":
            MessageLookupByLibrary.simpleMessage("Samlede returneringer"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Samlet salg"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Samlet beholdning"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Samlet værdi"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Samlet moms"),
        "totals": MessageLookupByLibrary.simpleMessage("Totalt: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Transaktion"),
        "transactionId":
            MessageLookupByLibrary.simpleMessage("Transaktions-ID"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Prøv igen"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Type"),
        "unitName": MessageLookupByLibrary.simpleMessage("Enhedsnavn"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Enhedspris"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Enhedspris"),
        "units": MessageLookupByLibrary.simpleMessage("Enheder"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Ubegrænset"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Ubegrænset brug"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Lås den fulde potentiale op for Pos Saas POS med personlige træningssessioner ledet af vores ekspertteam. Fra grundlæggende til avancerede teknikker sørger vi for, at du er godt rustet til at udnytte hver facet af systemet for at optimere dine forretningsprocesser."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Ubetalt"),
        "update": MessageLookupByLibrary.simpleMessage("Opdater"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Opdater kontakt"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Opdater nu"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("Opdater produkt"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Opdater din plan først,\\ndin grænse er overskredet"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Opdater din profil"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Opdater din profil for at forbinde dig bedre med din læge"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Opdater din profil for at forbinde dig bedre med kunderne"),
        "updated": MessageLookupByLibrary.simpleMessage("Opdateret"),
        "upload": MessageLookupByLibrary.simpleMessage("Upload"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Upload dokument"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("Upload færdig"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Upload fil"),
        "upplier": MessageLookupByLibrary.simpleMessage("Leverandør"),
        "usbC": MessageLookupByLibrary.simpleMessage("Usb C"),
        "use": MessageLookupByLibrary.simpleMessage("Brug"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("Brug Pos Saas"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Brug af systemet"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Bruger er slettet"),
        "userRole": MessageLookupByLibrary.simpleMessage("Brugerrolle"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("Brugerrolledetaljer"),
        "userTitle": MessageLookupByLibrary.simpleMessage("Brugertitel"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Brugertitlen må ikke være tom"),
        "value": MessageLookupByLibrary.simpleMessage("Værdi"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("Moms gælder ikke"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("Verificerer OTP"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Bekræft telefonnummer"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Se alle"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("Se detaljer"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Kunde uden aftale"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Lager"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Lageret findes allerede"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("Lagerliste"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("Lagerets navn"),
        "warranty": MessageLookupByLibrary.simpleMessage("Garanti"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Vi har sendt en e-mail med instruktioner om, hvordan du nulstiller adgangskoden til:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Vi kan bruge tredjepartstjenester til at understøtte appens funktionalitet, såsom analyseudbydere og betalingsbehandlere. Disse tredjepartstjenester kan indsamle oplysninger om dig, når du bruger vores app. Bemærk, at vi ikke er ansvarlige for privatlivspraksis for disse tredjepartstjenester."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Vi tager branchestandardforanstaltninger for at beskytte dine personlige oplysninger, herunder kryptering og sikker opbevaring. Vi begrænser også adgangen til dine oplysninger til autoriseret personale kun."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Vi forstår vigtigheden af problemfri drift. Derfor er vores døgnsupport tilgængelig for at hjælpe dig, uanset om det er en hurtig forespørgsel eller en omfattende bekymring. Forbind dig med os når som helst og hvor som helst via opkald eller WhatsApp for at opleve en enestående kundeservice."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Vi bruger dine personlige oplysninger for at give dig den bedst mulige oplevelse på vores app, herunder at personalisere dine indholdsanbefalinger, forbinde dig med eksperter og forbedre appens funktionalitet. Vi kan også bruge dine oplysninger til at kommunikere med dig om opdateringer, kampagner eller anden information relateret til vores app."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Vi vil gennemgå betalingen og godkende den inden for 1-2 timer"),
        "weekly": MessageLookupByLibrary.simpleMessage("Ugentlig"),
        "weight": MessageLookupByLibrary.simpleMessage("Vægt"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Hvad er nyt"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Engroshandler"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Engroshandelspris"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("Engrospris"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Engrosforhandler"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Vil blive tilføjet snart"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Udløber kl."),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Skriv din besked her"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("Forkert OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Forkert adgangskode angivet for den bruger."),
        "yearly": MessageLookupByLibrary.simpleMessage("Årlig"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Ja, slet permanent"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("Du er ikke en gyldig bruger"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Du bruger"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Du kan ikke betale mere end forfaldne beløb"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Du har modtaget en e-mail"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Du er logget ind på din konto med succes. Bliv hos Pos Saas."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("Du skal give tilladelse"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Du skal GENINDLOGGE dig på din konto."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Du skal bekræfte din identitet, før du kan købe SMS"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Din besked forbliver"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Din pakke"),
        "yourPackageWillExpireinDay":
            MessageLookupByLibrary.simpleMessage("Din pakke udløber om 5 dage")
      };
}
