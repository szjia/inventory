// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a ky locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'ky';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Улантуу"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("GST номери"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("MRP талап кылынат"),
        "OK": MessageLookupByLibrary.simpleMessage("ЖАРДАМ"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Ф.нум."),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT Коду"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Тамак-аш"),
        "TAX": MessageLookupByLibrary.simpleMessage("САЛЫК"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Жүктөлүүдө"),
        "UserTitle":
            MessageLookupByLibrary.simpleMessage("Пайдалануучунун наамы"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Сиздин пакетиңиз бүгүн мөөнөтү өтөт\n\nСураныч, кайра сатып алыңыз"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) Жүйө бизнестеги сатуу операцияларын жана ага байланыштуу иш-аракеттерди жеңилдетүү максатында гана берилет."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) Жүйөнү колдонуу үчүн сизден каттоо эсебин түзүү талап кылыншы мүмкүн. Сиз каттоо процессинде так, учурдагы жана толук маалымат берүүгө макулсуз жана мындай маалыматты так жана толук сактоо үчүн жаңыртууга макулсуз."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("Косо жөнүндө"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Биз жөнүндө"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Шарттарды кабыл алуу"),
        "accountName": MessageLookupByLibrary.simpleMessage("Эсептин аты"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("Эсеп номери"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Каттоо эсеби"),
        "acton": MessageLookupByLibrary.simpleMessage("Акция"),
        "add": MessageLookupByLibrary.simpleMessage("Кошуу"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Бренд кошуңуз"),
        "addCategory":
            MessageLookupByLibrary.simpleMessage("Категория кошуңуз"),
        "addContact": MessageLookupByLibrary.simpleMessage("Байланышты Кошуу"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Кардарды Кошуу"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("Жеткирүүнү Кошуу"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Сипаттоо кошуу"),
        "addDescription":
            MessageLookupByLibrary.simpleMessage("Эскертме Кошуу"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Чегерүү кошуу"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Документ ID кошуу"),
        "addDucument": MessageLookupByLibrary.simpleMessage("Документ кошуу"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Чыгым Кошуу"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Чыгым Категориясын Кошуу"),
        "addItems":
            MessageLookupByLibrary.simpleMessage("Элементтерди кошуңуз"),
        "addNew": MessageLookupByLibrary.simpleMessage("Жаңы кошуу"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Жаңы Дарек Кошуу"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Жаңы өнүм кошуңуз"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("Жаңы Салык кошуу"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Бир же бир нече салык түрү менен жаңы салык кошуу"),
        "addNote": MessageLookupByLibrary.simpleMessage("Эскертме Кошуу"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Алды менен продукт кошуңуз"),
        "addPromoCode": MessageLookupByLibrary.simpleMessage("Промо-код кошуу"),
        "addPurchase":
            MessageLookupByLibrary.simpleMessage("Сатып алууну кошуңуз"),
        "addSales": MessageLookupByLibrary.simpleMessage("Сатуу кошуу"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Кошуу ийгиликтүү"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Бирдик кошуңуз"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Пайдалануу ролун кошуу"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Ушул сәтте кошулду"),
        "addedToCart": MessageLookupByLibrary.simpleMessage("Себетке кошулду"),
        "address": MessageLookupByLibrary.simpleMessage("Дарек"),
        "admin": MessageLookupByLibrary.simpleMessage("Админ"),
        "all": MessageLookupByLibrary.simpleMessage("Бардык"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("Бардык бизнес чечимдер"),
        "alreadyAdded":
            MessageLookupByLibrary.simpleMessage("Ушул сәтте кошулду"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Мурда бар"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Алдын ала Аккаунт бар"),
        "amount": MessageLookupByLibrary.simpleMessage("Сумма"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "Электрондук почта жөнөтүлдү\\nКабылдамаларыңызды текшериңиз"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Android & iOS колдонмо колдоосу"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Колдонулуучу салык"),
        "apply": MessageLookupByLibrary.simpleMessage("Колдонуу"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Бул фактураны өчүрүүгө ишенесизби?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Бул сатуу өчүрүүгө ишенесизби?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Бул колдонуучуну өчүрүүгө ишенесизби?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Сиз бул салыкты жок кылууну каалайсызбы?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Сиз бул салык тобун жок кылууну каалайсызбы?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Сиз бул сактоочу жайды жок кылууну каалайсызбы?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Бул колдонуучуну жок кылууга ишенесизби?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Ушундан оюу"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Сиз өз эсептик жазууңуздун жана сырсөзүңүздүн купуялыгын сактоого жана өз эсептик жазууңузга кирүүнү чектөөгө жоопкерсиз. Сиздин эсептик жазууңуз астында болгон бардык иш-аракеттер үчүн жоопкерчиликти кабыл аласыз."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Сиз Жүйөнү колдонуу үчүн 18 жашта же өз юрисдикцияңыздагы мыйзамдуу куракка жетишиңиз керек."),
        "backSide": MessageLookupByLibrary.simpleMessage("Арткы тарап"),
        "backToHome":
            MessageLookupByLibrary.simpleMessage("Башкы бетке кайтуу"),
        "balance": MessageLookupByLibrary.simpleMessage("Баланc"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Бангладеш"),
        "bank": MessageLookupByLibrary.simpleMessage("Банк"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Банктык эсептин валютасы"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Банк эсебинин валютасы"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Банк маалыматы"),
        "bankName": MessageLookupByLibrary.simpleMessage("Банк аты"),
        "bankTransfer":
            MessageLookupByLibrary.simpleMessage("Банк аркылуу өткөрүү"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Штрих-код табылды"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Билл/Фактура"),
        "billTo": MessageLookupByLibrary.simpleMessage("Төлөм Жасоо"),
        "branchName": MessageLookupByLibrary.simpleMessage("Бөлүмдүн аты"),
        "brand": MessageLookupByLibrary.simpleMessage("Бренд"),
        "brandName": MessageLookupByLibrary.simpleMessage("Бренддин аты"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("Көп\nЖүктөө"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Бизнес категориясы"),
        "buy": MessageLookupByLibrary.simpleMessage("Сатып алуу"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Премиум планды сатып алуу"),
        "buySms": MessageLookupByLibrary.simpleMessage("SMS сатып алуу"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Сиз [Сиздин Компанияңыздын Аты] (\"Компания\") тарабынан сунушталган Сатуу Точкасы (POS) Жүйөсүнө (\"Жүйө\") кирип же колдонуу менен, ушул Пайдалануучулар Шарттарына баш ийүүгө макул болуп жатасыз. Эгерде сиз ушул Пайдалануучулар Шарттарына макул болбосоңуз, Жүйөнү колдонбоңуз."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Сиз Жүйөгө кирүү жана аны колдонуу боюнча бардык тиешелүү мыйзамдарга жана эрежелерге ылайык келишин камсыз кылуу үчүн жоопкерсиз."),
        "cacel": MessageLookupByLibrary.simpleMessage("Жокко чыгаруу"),
        "call": MessageLookupByLibrary.simpleMessage("Чалуу"),
        "callForEmergencySupport":
            MessageLookupByLibrary.simpleMessage("Тез жардам үчүн чалыңыз"),
        "camera": MessageLookupByLibrary.simpleMessage("Камера"),
        "cancel": MessageLookupByLibrary.simpleMessage("Болгону"),
        "cancelAllProduct": MessageLookupByLibrary.simpleMessage(
            "Бардык продуктуларды жокко чыгаруу"),
        "capacity": MessageLookupByLibrary.simpleMessage("Кабатталыш"),
        "card": MessageLookupByLibrary.simpleMessage("Карта"),
        "cash": MessageLookupByLibrary.simpleMessage("Наличные"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Категориялар"),
        "category": MessageLookupByLibrary.simpleMessage("Категория"),
        "categoryName":
            MessageLookupByLibrary.simpleMessage("Категориянын аты"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "Категориянын аты мурунтан бар"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("Категория Аты"),
        "change": MessageLookupByLibrary.simpleMessage("Өзгөртүү?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Паролду алмаштырыңыз"),
        "checkEmail": MessageLookupByLibrary.simpleMessage(
            "Электрондук катты текшериңиз"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Кардарды тандаңыз"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Жеткирүүчүнү тандаңыз"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Өзгөчөлүктөрүңүздү тандаңыз"),
        "clarence": MessageLookupByLibrary.simpleMessage("Сатык"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Байланыш үчүн чыкылдатыңыз"),
        "close": MessageLookupByLibrary.simpleMessage("Жабуу"),
        "color": MessageLookupByLibrary.simpleMessage("Түс"),
        "combinationOfMultipleTaxes":
            MessageLookupByLibrary.simpleMessage("(Көп салык комбинациясы)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Жакында"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Компаниянын Дареги"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Компания жана Дүкөндүн Аты"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("Компания жана бизнес аты"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Транзакцияны бүтүрүү"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Паролду Тастыктоо"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Кайтууну ырастоо"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Куттуктайбыз"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Биз менен байланыш"),
        "continu": MessageLookupByLibrary.simpleMessage("Улантуу"),
        "country": MessageLookupByLibrary.simpleMessage("Мамлекет"),
        "create": MessageLookupByLibrary.simpleMessage("Түзүү"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Тегин Аккаунт Жасоо"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Түзүлдү жана сакталды"),
        "currency": MessageLookupByLibrary.simpleMessage("Валюта"),
        "currentStock":
            MessageLookupByLibrary.simpleMessage("Учурдагы инвентаризация"),
        "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
            "Бренддик счет-фактураны ылайыкташтыруу"),
        "customer": MessageLookupByLibrary.simpleMessage("Кардар"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Кардардын Маалыматтары"),
        "customerGST": MessageLookupByLibrary.simpleMessage("Кардардын GST"),
        "customerName": MessageLookupByLibrary.simpleMessage("Кардардын Аты"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Күнүмдүк транзакциялар"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Дашборддун жалпы көрүнүшү"),
        "dataSavedSuccessfully": MessageLookupByLibrary.simpleMessage(
            "Маалымат ийгиликтүү сакталды"),
        "date": MessageLookupByLibrary.simpleMessage("Дата"),
        "day": MessageLookupByLibrary.simpleMessage("Күн"),
        "dealer": MessageLookupByLibrary.simpleMessage("Дилер"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("Дилердин баасы"),
        "defaultVATPercentage": MessageLookupByLibrary.simpleMessage(
            "Стандарттык НДС пайыздык бөлүгү"),
        "delete": MessageLookupByLibrary.simpleMessage("Жоюу"),
        "deleting": MessageLookupByLibrary.simpleMessage("Өчүрүү"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Жеткирүү Дареги"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Жеткирүү даректери"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Жеткирип берүү акысы"),
        "describtion": MessageLookupByLibrary.simpleMessage("Сипаттама"),
        "description": MessageLookupByLibrary.simpleMessage("Сипаттама"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Сипаттама бош боло албайт"),
        "details": MessageLookupByLibrary.simpleMessage("Маалыматтар"),
        "discount": MessageLookupByLibrary.simpleMessage("Жарна"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Тынчыңыз"),
        "done": MessageLookupByLibrary.simpleMessage("Аяктады"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Excel форматын жүктөө"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Жүктөө папкасында ийгиликтүү жүктөлдү"),
        "due": MessageLookupByLibrary.simpleMessage("Карыз"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Карыз Суммасы: "),
        "dueCollection": MessageLookupByLibrary.simpleMessage("Карыз Жыйноо"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("Жардам боюнча отчеттор"),
        "dueList": MessageLookupByLibrary.simpleMessage("Карыз Тизими"),
        "dueReports": MessageLookupByLibrary.simpleMessage("Калган отчет"),
        "duration": MessageLookupByLibrary.simpleMessage("Убакыт"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Убакыт: Дан"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "Колдонууга оңой мобилдик POS"),
        "edit": MessageLookupByLibrary.simpleMessage("Түзөтүү"),
        "editPurchaseInvoice": MessageLookupByLibrary.simpleMessage(
            "Сатып алуу инвойсин өзгөртүү"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Сатуу инвойсин өзгөртүү"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Социалдык медианы түзөтүңүз"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Ийгиликтүү өзгөртүлдү"),
        "editTax": MessageLookupByLibrary.simpleMessage("Салыктарды өзгөртүү"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Салык топторун өзгөртүү"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("Сактоочу жайды өзгөртүү"),
        "email": MessageLookupByLibrary.simpleMessage("Электрондук почта"),
        "emailAddress":
            MessageLookupByLibrary.simpleMessage("Электрондук почта дареги"),
        "emailCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Электрондук почта бош болбойт"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "Электрондук почта жөнөтүлдү! Кошулбаларды текшериңиз"),
        "endDate": MessageLookupByLibrary.simpleMessage("Аяктагы күнү"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Туура сумманы киргизиңиз"),
        "enterAValidDiscount": MessageLookupByLibrary.simpleMessage(
            "Жарактуу жеңилдикти киргизиңиз"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Туура телефон номерин киргизиңиз"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Жарактуу бааны киргизиңиз"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("Жарактуу санды киргизиңиз"),
        "enterAddress":
            MessageLookupByLibrary.simpleMessage("Дарек Киргизиңиз"),
        "enterAmount":
            MessageLookupByLibrary.simpleMessage("Сумманы Киргизиңиз."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Бренддин атын жазыңыз"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Кабатталышты жазыңыз"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Категориянын атын жазыңыз"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Түс жазыңыз"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "Кардардын GST номерин киргизиңиз"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Дилердин баасын жазыңыз"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Сипаттаманы киргизиңиз"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("Жарнаманы жазыңыз."),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Чыгым Датасын Киргизиңиз"),
        "enterFullAddress": MessageLookupByLibrary.simpleMessage(
            "Толук Дарегиңизди Киргизиңиз"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Инвойс номерин жазыңыз"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Төмөн запастын эскертүү санын киргизиңиз"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Өндүрүүчүнүн атын жазыңыз"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("Билдирүү мазмунун жазыңыз"),
        "enterMrpOrRetailerPirce":
            MessageLookupByLibrary.simpleMessage("MRP/Сатуу баасын жазыңыз"),
        "enterName":
            MessageLookupByLibrary.simpleMessage("Атыңызды Киргизиңиз"),
        "enterNote":
            MessageLookupByLibrary.simpleMessage("Эскертменин Киргизиңиз"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Тараптын Атын Киргизиңиз"),
        "enterPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Телефон Номериңизди Киргизиңиз"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Өнүм кодун жазыңыз же сканердеңиз"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Өнүмдүн атын жазыңыз"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Сатып алуу баасын жазыңыз."),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("Ссылка Номерди Киргизиңиз"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Размерди жазыңыз"),
        "enterStocks":
            MessageLookupByLibrary.simpleMessage("Коомдук фондду жазыңыз."),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Салык ченин киргизиңиз"),
        "enterTransactionId": MessageLookupByLibrary.simpleMessage(
            "Транзакция идентификаторун киргизиңиз"),
        "enterType": MessageLookupByLibrary.simpleMessage("Түрдү жазыңыз"),
        "enterUserTitle": MessageLookupByLibrary.simpleMessage(
            "Пайдалануучунун наамын киргизиңиз"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Туура сумманы киргизиңиз"),
        "enterWarehouseName": MessageLookupByLibrary.simpleMessage(
            "Сактоочу жайдын атын киргизиңиз"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Салмакты жазыңыз"),
        "enterWholeSalePrice": MessageLookupByLibrary.simpleMessage(
            "Болот сатып алуу баасын жазыңыз"),
        "enterYourDescriptionHere": MessageLookupByLibrary.simpleMessage(
            "Муну жазып алууга мүмкүнчүлүк бериңиз"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "Электрондук почта дарегиңизди киргизиңиз"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "Сиздин пикирдин атын жазыңыз"),
        "enterYourGSTNumber": MessageLookupByLibrary.simpleMessage(
            "Сиздин GST номериңизди киргизиңиз"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("Мобилдик номерин жазыңыз"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Атыңызды Киргизиңиз"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("Телефон номерини киргизиңиз"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Сырсөзүңүздү киргизиңиз"),
        "enterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Телефон Номериңизди Киргизиңиз"),
        "enterYourTransactionId":
            MessageLookupByLibrary.simpleMessage("Транзакция IDңизди жазыңыз"),
        "error": MessageLookupByLibrary.simpleMessage("Ката"),
        "excTax": MessageLookupByLibrary.simpleMessage("Четтетилген салык"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("Excel жүктөөчү"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Четтетилген"),
        "expense": MessageLookupByLibrary.simpleMessage("Чыгым"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Чыгым Категориясы"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Чыгым Датасы"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Чыгым үчүн"),
        "expenseReport": MessageLookupByLibrary.simpleMessage("Чыгым Арыз"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Мөөнөтү"),
        "expired": MessageLookupByLibrary.simpleMessage("Мөөнөтү өттү"),
        "expiring": MessageLookupByLibrary.simpleMessage("Мөөнөтү бүтүп жатат"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Ката менен ишке ашпай калды"),
        "fashion": MessageLookupByLibrary.simpleMessage("Мода"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Өзгөчөлүктөр POS SaaSты традициялык чечимдерден айырмалаган маанилүү бөлүк."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Пикир"),
        "firstName": MessageLookupByLibrary.simpleMessage("Алгачкы Аты"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Бизди Facebook\'та следите"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Бизди Twitter\'та следите"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Алдыңкы тарап"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("Чексиз колдонуу үчүн"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Паролун унуттуңузбу"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Парольду унуттуңузбу?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Датадан"),
        "freeDataBackup": MessageLookupByLibrary.simpleMessage(
            "Тегин маалыматтарды резервдөө"),
        "freeLifeTimeUpdate":
            MessageLookupByLibrary.simpleMessage("Тегин өмүр бою жаңыртуу"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Акысыз пакет"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Акысыз пландар"),
        "from": MessageLookupByLibrary.simpleMessage("(Дан"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Толук төлөнгөн"),
        "gallary": MessageLookupByLibrary.simpleMessage("Галерея"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("PDF түзүү"),
        "getOtp": MessageLookupByLibrary.simpleMessage("OTP алуу"),
        "govermentId":
            MessageLookupByLibrary.simpleMessage("Өкмөт тарабынан берилген ИД"),
        "guest": MessageLookupByLibrary.simpleMessage("Келүүчү"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Эсеп жокпу?"),
        "history": MessageLookupByLibrary.simpleMessage("Тарых"),
        "home": MessageLookupByLibrary.simpleMessage("Башкы Баракча"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Биз сиздин маалыматтарды кантип коргойбуз"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Биз сиздин маалыматтарды кантип колдонобуз"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Идентификацияны текшерүү"),
        "image": MessageLookupByLibrary.simpleMessage("Сүрөт"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("Жатакта жок кылынбайт"),
        "inHouseCantBeEdited": MessageLookupByLibrary.simpleMessage(
            "Жатакта өзгөртүүгө мүмкүн эмес"),
        "inWord": MessageLookupByLibrary.simpleMessage("Сөз менен"),
        "incTax": MessageLookupByLibrary.simpleMessage("Кош. салык"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Киргизилген"),
        "increaseStock":
            MessageLookupByLibrary.simpleMessage("Запасты көбөйтүү"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Курал"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Инв. номер."),
        "invoice": MessageLookupByLibrary.simpleMessage("Эсеп-фактура"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("Инвойс номері"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Инвойс жөндөөлөрү"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Эсеп-фактураны көрүү"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Жазылган"),
        "kg": MessageLookupByLibrary.simpleMessage("Кг"),
        "kycVerification": MessageLookupByLibrary.simpleMessage("KYC текшерүү"),
        "language": MessageLookupByLibrary.simpleMessage("Тил"),
        "lastName": MessageLookupByLibrary.simpleMessage("Акыркы Аты"),
        "ledger": MessageLookupByLibrary.simpleMessage("Журнал"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Туруктуу\nСатып алуу"),
        "link": MessageLookupByLibrary.simpleMessage("Байланыш"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Тиркеме колдоосу"),
        "loading": MessageLookupByLibrary.simpleMessage("Жүктөлүүдө"),
        "logIn": MessageLookupByLibrary.simpleMessage("Кирүү"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Чыгуу"),
        "logOut": MessageLookupByLibrary.simpleMessage("Чыгуу"),
        "login": MessageLookupByLibrary.simpleMessage("Кирүү"),
        "logo": MessageLookupByLibrary.simpleMessage("Логотип"),
        "loss": MessageLookupByLibrary.simpleMessage("Зыяны"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Зыяны/пайдасы"),
        "lossOrProfitDetails": MessageLookupByLibrary.simpleMessage(
            "Зыяны/пайдасы тууралуу маалымат"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Жоготуу/пайда отчету"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Жоготуу/пайда отчеттору"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Төмөн запастын эскертүүсү"),
        "maan": MessageLookupByLibrary.simpleMessage("Ман"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Кардарларыңызда туруктуу таасир калтырыңыз. Биздин Чексиз Жаңыртуу брендинг менен счет-фактураларды ылайыкташтыруу мүмкүнчүлүгүн берет, бул сиздин бренд идентификацияңызды бекемдейт жана кардарлардын берилгендигин жогорулатат."),
        "manageYourBussinessWith": MessageLookupByLibrary.simpleMessage(
            "Сиздин бизнесиңизди башкаруу "),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Өндүрүш датасы"),
        "margin": MessageLookupByLibrary.simpleMessage("Маржа"),
        "masterCard": MessageLookupByLibrary.simpleMessage("Master Card"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Өндүрүүчү"),
        "message": MessageLookupByLibrary.simpleMessage("Билдирүү"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Билдирүүлөрдүн тарыхы"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "POS SaaS тиркемеси акысыз, колдонууга оңой. Чынында, бул дүйнө жүзүндөгү мыкты POS системалардын бири."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "POS SaaS – бул толук бизнес чечими, инвентаризация, эсеп, сатуу, чыгым жана пайда/жоготуу менен."),
        "mobile": MessageLookupByLibrary.simpleMessage("Мобилдик"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("Мобилдик төлөм"),
        "monthly": MessageLookupByLibrary.simpleMessage("Ай сайын"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("Көбүрөөк Маалымат"),
        "name": MessageLookupByLibrary.simpleMessage("Атыңызды Киргизиңиз."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Атын мурунтан бар"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("Аты бош боло албайт"),
        "next": MessageLookupByLibrary.simpleMessage("Кийинки"),
        "noConnection": MessageLookupByLibrary.simpleMessage("Байланыш жок"),
        "noData": MessageLookupByLibrary.simpleMessage("Деректер жок"),
        "noDataAvailable": MessageLookupByLibrary.simpleMessage("Маалымат жок"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Деректер табылбайт"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("Тарых табылбады!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Продукт табылган жок"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("Кичи салык тандалган жок"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("Транзакция табылбады!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Ошол электрондук почта үчүн колдонуучу табылган жок."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "Пайдалануу ролу табылган жок"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Активдүү Колдонуучу Эмес"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Берилген жок"),
        "note": MessageLookupByLibrary.simpleMessage("Эскертме"),
        "notes": MessageLookupByLibrary.simpleMessage("Эскертпелер"),
        "notification": MessageLookupByLibrary.simpleMessage("Эскертүү"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP жөнөтүлдү"),
        "office": MessageLookupByLibrary.simpleMessage("Офис"),
        "ok": MessageLookupByLibrary.simpleMessage("Ок"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "Сатуу мониторингин, инвентаризацияны башкарууну камтыган функционалдык жактан жогорку POS."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Бул система сиздин операцияларыңызды кардарларыңыз үчүн жакшыртууга жардам берет."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Биздин POS системабыз күнүмдүк операцияларды автоматташтырууну жөнөкөйлөтүшү керек, бул оңой навигация жасоого жардам берет."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("Ачылыш Балансы"),
        "order": MessageLookupByLibrary.simpleMessage("Заказдар"),
        "other": MessageLookupByLibrary.simpleMessage("Башка"),
        "otp": MessageLookupByLibrary.simpleMessage("Жабуу"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Запаста жок"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Пакет"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Пакеттин өзгөчөлүктөрү"),
        "paid": MessageLookupByLibrary.simpleMessage("Төлөндү"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Төлөнгөн Сумма"),
        "parties": MessageLookupByLibrary.simpleMessage("Тараптар"),
        "partiesList":
            MessageLookupByLibrary.simpleMessage("Тараптардын Тизими"),
        "partyGST": MessageLookupByLibrary.simpleMessage("Тарап GST"),
        "partyName": MessageLookupByLibrary.simpleMessage("Тараптын Аты"),
        "password": MessageLookupByLibrary.simpleMessage("Пароль"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Пароль жана растау паролунун ортосундагы туура келбейт"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Пароль бош болбойт"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("Пароль туура эмес"),
        "payCash": MessageLookupByLibrary.simpleMessage("Наличных төлөө"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("Bkash менен төлөө"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Paypal менен төлөө"),
        "payeeName":
            MessageLookupByLibrary.simpleMessage("Төлөм алган адамдын аты"),
        "payeeNumber":
            MessageLookupByLibrary.simpleMessage("Төлөм алган адамдын номер"),
        "payment": MessageLookupByLibrary.simpleMessage("Төлөм"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("Төлөм Суммасы"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Төлөм толукталды"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Төлөм көрсөтмөлөрү:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("Төлөм ыкмасы"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Төлөм Тиеси"),
        "pdfView": MessageLookupByLibrary.simpleMessage("PDF көрүнүшү"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Жеке маалыматтар"),
        "phone": MessageLookupByLibrary.simpleMessage("Телефон"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Телефон Номери"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Телефон номери мурунтан колдонулууда"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("Телефон номери туура эмес"),
        "phoneNumberIsRequired": MessageLookupByLibrary.simpleMessage(
            "Телефон номери талап кылынат"),
        "pickAndUploadFile": MessageLookupByLibrary.simpleMessage(
            "Файлды тандаңыз жана жүктөңүз"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("Аяктагы күндү тандаңыз"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Башталган күндү тандаңыз"),
        "plan": MessageLookupByLibrary.simpleMessage("План"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("Саны кошуңуз"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Интернет байланышыңызды текшериңиз"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Сураныч, алгач принтерди туташтырыңыз"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Сураныч, Bluetooth Принтериңизди кошуңуз"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Сураныч, чоңураак пароль киргизиңиз"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Сураныч, Тастыктоочу Паролду Киргизиңиз"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("Пароль киргизиңиз"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Сураныч, туура электрондук почта киргизиңиз"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Сураныч, атын киргизиңиз"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("Сураныч, паролду киргизиңиз"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Парольди жаңыртуу шилтемесин алуу үчүн электрондук почтаңызды киргизиңиз."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Сураныч, Транзакция Номерин Киргизиңиз"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("Сураныч, сумманы киргизиңиз"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Сураныч, алгач категорияны тандаңыз"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("Сураныч, Пландарды Тандаңыз"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Сураныч, бизнес категориясын тандаңыз"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Тилекке каршы, колдонмо үчүн жарактуу сатып алуу кодун колдонуңуз"),
        "powerdedByMobiPos": MessageLookupByLibrary.simpleMessage(
            "MobiPos тарабынан камсыздалган"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Жасалган"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Premium кардарларды колдоо"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Премиум пландар"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Мурдагы төлөм суммалары"),
        "price": MessageLookupByLibrary.simpleMessage("Баа"),
        "print": MessageLookupByLibrary.simpleMessage("Басып чыгарыңыз"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Басып чыгаруу параметри"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Жекеменчиги саясаты"),
        "product": MessageLookupByLibrary.simpleMessage("Өнүм"),
        "productCode": MessageLookupByLibrary.simpleMessage("Өнүм коду"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("Продукт коду талап кылынат"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Продукт коду/Аты"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Продукттун сүрөттөлүшү"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Продукт жөнүндө маалымат"),
        "productList": MessageLookupByLibrary.simpleMessage("Өнүмдүн тизмеси"),
        "productName": MessageLookupByLibrary.simpleMessage("Өнүмдүн аты"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Продукттун аты ушул кампада мурунтан бар"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Продукттун аты мурда кошулган"),
        "productNameIsRequired": MessageLookupByLibrary.simpleMessage(
            "Продукттун аты талап кылынат"),
        "products": MessageLookupByLibrary.simpleMessage("Өнүмдөр"),
        "profile": MessageLookupByLibrary.simpleMessage("Профиль"),
        "profileEdit":
            MessageLookupByLibrary.simpleMessage("Профилди редакциялоо"),
        "profit": MessageLookupByLibrary.simpleMessage("Пайда"),
        "promo": MessageLookupByLibrary.simpleMessage("Промо"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Промо-код"),
        "purchase": MessageLookupByLibrary.simpleMessage("Сатып алуу"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage(
            "Сатып алуулар боюнча эскертүү"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Сатып алуу тастыкталды"),
        "purchaseDetails": MessageLookupByLibrary.simpleMessage(
            "Сатып алуу тууралуу маалымат"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Сатып алуу фактурасы"),
        "purchaseList":
            MessageLookupByLibrary.simpleMessage("Сатып алуу тизмеси"),
        "purchaseNow":
            MessageLookupByLibrary.simpleMessage("Азыр сатып алыңыз"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Премиум план сатып алуу"),
        "purchasePrice":
            MessageLookupByLibrary.simpleMessage("Сатып алуу баасы"),
        "purchasePriceIsRequired": MessageLookupByLibrary.simpleMessage(
            "Сатып алуу баасы талап кылынат"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("Сатып алуу отчету"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Сатып алуу баасы"),
        "purchaseReportss": MessageLookupByLibrary.simpleMessage(
            "Сатып алуулар боюнча отчеттор"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("Сатып алуу кайтарымы"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("Сатып алуу кайтарым отчету"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Сатып алуу өткөрмөсү"),
        "qty": MessageLookupByLibrary.simpleMessage("Саны"),
        "quantity": MessageLookupByLibrary.simpleMessage("Саны"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Жакындагы Транзакциялар"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("PIN номерин кабыл алды"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Ссылка Номери"),
        "register": MessageLookupByLibrary.simpleMessage("Каттоо"),
        "registering": MessageLookupByLibrary.simpleMessage("Катталып жатат"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("Калган Карыз"),
        "remove": MessageLookupByLibrary.simpleMessage("Жалгашыңыз"),
        "reports": MessageLookupByLibrary.simpleMessage("Арыздар"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Сураныч жөнөтүлдү"),
        "resendCode":
            MessageLookupByLibrary.simpleMessage("Кодду кайра жөнөтүү"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("OTP кайра жөнөтүү:"),
        "retailer": MessageLookupByLibrary.simpleMessage("Ретейлер"),
        "retur": MessageLookupByLibrary.simpleMessage("Кайтаруу"),
        "returN": MessageLookupByLibrary.simpleMessage("Кайтуу"),
        "returnAMount":
            MessageLookupByLibrary.simpleMessage("Кайтаруу суммасы"),
        "returnAmount":
            MessageLookupByLibrary.simpleMessage("Кайтаруу суммасы"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("Кайтарым саны"),
        "revenue": MessageLookupByLibrary.simpleMessage("Киреше"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Сиздин бизнес маалыматтарыңызды коопсуздукта сактаңыз. Биздин POS SaaS POS Чексиз Жаңыртуу акысыз маалыматтарды резервдөөнү камтыйт, бул сиздин баалуу маалыматтарыңызды күтүлбөгөн окуяларга каршы коргойт. Чынында маанилүү нерселерге көңүл буруңуз - бизнесиңиздин өсүшү."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Сатуунун суммасы"),
        "saleDetails":
            MessageLookupByLibrary.simpleMessage("Сатуу тууралуу маалымат"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Сатуу баасы"),
        "saleReports": MessageLookupByLibrary.simpleMessage("Сатуу отчету"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Сатуулар боюнча отчеттор"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("Сатуу кайтарымы"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Сатуу кайтарым отчету"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("Сатуу жөндөөлөрү"),
        "sales": MessageLookupByLibrary.simpleMessage("Сатуу"),
        "salesAndPurchaseReports": MessageLookupByLibrary.simpleMessage(
            "Сатуу жана сатып алуу отчеттору"),
        "salesList": MessageLookupByLibrary.simpleMessage("Сатуу тизмеси"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("Сатуу кайтарымы"),
        "save": MessageLookupByLibrary.simpleMessage("Сактоо"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Сактап, жарыялаңыз"),
        "saveChanges":
            MessageLookupByLibrary.simpleMessage("Өзгөртүүлөрдү сактоо"),
        "saving": MessageLookupByLibrary.simpleMessage("Сактоо"),
        "scanProductQRCode": MessageLookupByLibrary.simpleMessage(
            "Продукттун QR кодун сканерлеп алыңыз"),
        "search": MessageLookupByLibrary.simpleMessage("Издөө"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Продукт кодун же атын издеңиз"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("Бардык промо-коддорду көрүү"),
        "select": MessageLookupByLibrary.simpleMessage("Тандоо"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Кайтуу үчүн продукт тандаңыз"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Брендди тандаңыз"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Категорияны тандаңыз"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Контактыларды тандаңыз"),
        "selectProductCategory": MessageLookupByLibrary.simpleMessage(
            "Продукт категориясын тандаңыз"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("Дүкөн категориясын тандаңыз"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Салыкты тандаңыз"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Салык түрүн тандаңыз"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("Бирдикти тандаңыз"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Вариацияны тандаңыз:"),
        "seller": MessageLookupByLibrary.simpleMessage("Сатучы"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Сатылган"),
        "send": MessageLookupByLibrary.simpleMessage("Жиберүү"),
        "sendEmail":
            MessageLookupByLibrary.simpleMessage("Электрондук почта жиберүү"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Билдирүү жиберүү"),
        "sendResetLink": MessageLookupByLibrary.simpleMessage(
            "Парольди жаңыртуу шилтемесин жөнөтүү"),
        "sendSms": MessageLookupByLibrary.simpleMessage("SMS жиберүү"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("SMS жиберемби?"),
        "sendWhatsappMessage": MessageLookupByLibrary.simpleMessage(
            "Whatsapp билдирүүсүн жөнөтүү"),
        "sendYOurEmail": MessageLookupByLibrary.simpleMessage(
            "Электрондук почтаңызды жиберүү"),
        "sendingEmail":
            MessageLookupByLibrary.simpleMessage("Электрондук почта жөнөтүү"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Билдирүү жөнөтүүдө"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Кызмат/Жөнөтүү"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Профилиңизди орнотуңуз"),
        "setting": MessageLookupByLibrary.simpleMessage("Түзүлүш"),
        "share": MessageLookupByLibrary.simpleMessage("Бөлүшүү"),
        "shopGST": MessageLookupByLibrary.simpleMessage("Дүкөн GST"),
        "signIn": MessageLookupByLibrary.simpleMessage("Кирүү"),
        "signInWithEmail": MessageLookupByLibrary.simpleMessage(
            "Электрондук почта менен кирүү"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Кардардын кол тамгасы"),
        "size": MessageLookupByLibrary.simpleMessage("Размер"),
        "skip": MessageLookupByLibrary.simpleMessage("Калдыруу"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Социалдык маркетинг"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Кечиресиз, сиз бул кызматка кирүүгө уруксат берилген эмес"),
        "startDate": MessageLookupByLibrary.simpleMessage("Башталган күнү"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Жаңы сатууну баштаңыз"),
        "startTypingToSearch":
            MessageLookupByLibrary.simpleMessage("Издөө үчүн жазууну баштаңыз"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Технологиянын акыркы жаңылыктарынан четте калбайсыз. Биздин POS SaaS POS Чексиз Жаңыртуу сизге акыркы инструменттерди жана функцияларды колуңузда кармап, бизнесиңизди актуалдуу кылат."),
        "stillUnpaid":
            MessageLookupByLibrary.simpleMessage("Хазіргі төлөнгөн жок"),
        "stock": MessageLookupByLibrary.simpleMessage("Запас"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Запас талап кылынат"),
        "stockList": MessageLookupByLibrary.simpleMessage("Запас тизмеси"),
        "stocks": MessageLookupByLibrary.simpleMessage("Коомдук фонд"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Excel файлын түзүү үчүн сактоого уруксат талап кылынат"),
        "subTaxList":
            MessageLookupByLibrary.simpleMessage("Кичи салык тизмеси"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Кичи Салыктар"),
        "subTotal":
            MessageLookupByLibrary.simpleMessage("Жарым-жартылай сумма"),
        "submit": MessageLookupByLibrary.simpleMessage("Жөнөтүү"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "Биздин Youtube\'ка жазылыңыз"),
        "subscription": MessageLookupByLibrary.simpleMessage("Жазылуу"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Ийгиликтүү аякталды"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("С ийгиликтүү чыктыңыз"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Ийгиликтүү жаңыртылды"),
        "supplier": MessageLookupByLibrary.simpleMessage("Жабдыручулар"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("Жеткирүүчүнүн аты"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT коду"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Жүргүнчү лицензиясын, улуттук идентти берүү картасын же паспорттун сүрөтүн алыңыз"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "Маалыматыңызды текшерүү үчүн идентификация картасын алыңыз"),
        "tap": MessageLookupByLibrary.simpleMessage("Тап"),
        "tax": MessageLookupByLibrary.simpleMessage("Салык"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Салык тобу"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("Салык пайыз"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Салык  чени"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Салык чендери - Сиздин салык чендериңизди башкаруу"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Салык отчёту"),
        "taxType": MessageLookupByLibrary.simpleMessage("Салык түрү"),
        "taxes": MessageLookupByLibrary.simpleMessage("Салыктар"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Шарттар жана Талаптар"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("Колдонуу шарттары"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Шарттар жана Жекелик"),
        "thankYOuForYourDuePayment":
            MessageLookupByLibrary.simpleMessage("Карыз Төлөмүңүз үчүн Рахмат"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Рахмат"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Сатып алганыңыз үчүн рахмат"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "Ошол электрондук почта үчүн аккаунт мурунтан бар"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Excel файлы буга чейин жүктөлгөн"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Атын өзү көрсөтөт. POS SaaS POS Чексиз, колдонууга эч кандай чектөө жок. Сиз аздаган операцияларды же кардарлардын агымын иштетип жатасызбы, чектелген жок экендигиңизди билүү менен иштей аласыз."),
        "thePasswordProvidedIsTooWeak":
            MessageLookupByLibrary.simpleMessage("Берилген пароль өтө алсыз"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Сатып алуу өчүрүлөт жана ушул сатып алуу боюнча бардык маалыматтар өчүрүлөт. Сиз бул фактраны өчүрүүгө ишенесизби?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Сатуу өчүрүлөт жана ушул сатуу боюнча бардык маалыматтар өчүрүлөт. Сиз бул сатууну өчүрүүгө ишенесизби?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Колдонуучу жок болот жана бардык маалыматтар аккаунтуңуздан жок кылынат. Чынында жок кылууга ишенесизби?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Колдонуучу өчүрүлөт жана бардык маалыматтар сиздин эсептиңизден өчүрүлөт. Сиз чынында эле өчүрүүгө ишенесизби?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Үчүнчү тараптын кызматтары"),
        "thisCategoryCannotBeDeleted":
            MessageLookupByLibrary.simpleMessage("Бул категория жок кылынбайт"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Бул ай)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Бул продукт мурунтан кошулган"),
        "title": MessageLookupByLibrary.simpleMessage("Аты"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Тема бош боло албайт"),
        "to": MessageLookupByLibrary.simpleMessage("ге"),
        "toDate": MessageLookupByLibrary.simpleMessage("Датага"),
        "today": MessageLookupByLibrary.simpleMessage("Бүгүн"),
        "total": MessageLookupByLibrary.simpleMessage("Жалпы"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Жалпы Сумма"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Жалпы чогултулган"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Жалпы Карыз"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("Жалпы Чыгым"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Жалпы жоготуу"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("Жалпы төлөнүүчү сумма"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Жалпы баа"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("Жалпы продуктылар"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Жалпы пайда"),
        "totalPurchase":
            MessageLookupByLibrary.simpleMessage("Жалпы сатып алуу"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Жалпы кайтарым суммасы"),
        "totalReturns":
            MessageLookupByLibrary.simpleMessage("Жалпы кайтарымдар"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Жалпы сатуу"),
        "totalStock":
            MessageLookupByLibrary.simpleMessage("Жалпы инвентаризация"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Жалпы мааниси"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Жалпы КНД"),
        "totals": MessageLookupByLibrary.simpleMessage("Жалпы: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Транзакция"),
        "transactionId":
            MessageLookupByLibrary.simpleMessage("Транзакциянын ID"),
        "tryAgain": MessageLookupByLibrary.simpleMessage(
            "Кайрадан аракет кылып көрүңүз"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Түр"),
        "unitName": MessageLookupByLibrary.simpleMessage("Бирдиктин аты"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Бирдиктин баасы"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Бөлүк баасы"),
        "units": MessageLookupByLibrary.simpleMessage("Бирдиктер"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Чектелбеген"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Чек жок колдонуу"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "POS SaaS POS системасынын толук потенциалын жогору жактан жеткирүүчүлөр тарабынан берилген индивидуалдык окутуу сессиялары менен ачык кылыңыз. Негизги жана өнүккөн техникага чейин, биз системанын ар бир бөлүгүн колдонуп, бизнес процесстерин оптимизациялоого жардам беребиз."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Төлөнгөн эмес"),
        "update": MessageLookupByLibrary.simpleMessage("Жаңыртуу"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Байланышты Жаңыртуу"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Азыр жаңыртыңыз"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("Өнүмдү жаңыртуу"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Сиздин чегиңиз өтүп кетти, алгач планыңызды жаңыртыңыз"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Профилиңизди жаңыртыңыз"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Докторуңуз менен жакшы байланыш үчүн профилиңизди жаңыртыңыз"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Профилиңизди жаңыртыңыз, кардарларыңыз менен жакшы байланышка чыгуу үчүн"),
        "updated": MessageLookupByLibrary.simpleMessage("Жаңыртылды"),
        "upload": MessageLookupByLibrary.simpleMessage("Жүктөө"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Документ жүктөө"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("Жүктөө аяктады"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Файл жүктөө"),
        "upplier": MessageLookupByLibrary.simpleMessage("Жабдыручулар"),
        "usbC": MessageLookupByLibrary.simpleMessage("USB C"),
        "use": MessageLookupByLibrary.simpleMessage("Колдонуу"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("POS SaaS колдонуу"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Жүйөнү колдонуу"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Колдонуучу өчүрүлдү"),
        "userRole": MessageLookupByLibrary.simpleMessage("Пайдалануу ролу"),
        "userRoleDetails": MessageLookupByLibrary.simpleMessage(
            "Колдонуучу ролунун маалыматтары"),
        "userTitle":
            MessageLookupByLibrary.simpleMessage("Пайдалануучунун наамы"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Колдонуучу наамы бош боло албайт"),
        "value": MessageLookupByLibrary.simpleMessage("Мааниси"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("VAT колдонулбайт"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("OTP текшерүү"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Телефон номерин текшерүү"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Бардыгын Караңыз"),
        "viewDetails":
            MessageLookupByLibrary.simpleMessage("Талданууга көз салуу"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Жүрүп келген кардар"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Кампа"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Сактоочу жай мурунтан бар"),
        "warehouseList":
            MessageLookupByLibrary.simpleMessage("Сактоочу тизмеси"),
        "warehouseName":
            MessageLookupByLibrary.simpleMessage("Сактоочу жайдын аты"),
        "warranty": MessageLookupByLibrary.simpleMessage("Кепилдик"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Парольдү жаңыртуу үчүн көрсөтмөлөр менен электрондук кат жөнөттүк:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Биз колдонмобуздун функционалдуулугун колдоо үчүн үчүнчү тараптын кызматтарын колдонушубуз мүмкүн, мисалы, аналитикалык провайдерлер жана төлөм процессорлору. Бул үчүнчү тараптын кызматтары сиз биздин колдонмобузду колдонгондо сиз жөнүндө маалыматтарды чогулта алышы мүмкүн. Бул үчүнчү тараптын кызматтарынын купуялык практикалары үчүн биз жоопкерчилик албайбыз."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Биз сиздин жеке маалыматтарыңызды коргоо үчүн өнөр жай стандарттарына ылайык чараларды көрөбүз, анын ичинде шифрлөө жана коопсуз сактоо. Биз ошондой эле сиздин маалыматыңызга кирүү мүмкүнчүлүгүн авторлоштурулган кызматкерлер менен гана чектейбиз."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Биз үзгүлтүксүз операциялардын маанилүүлүгүн түшүнөбүз. Ошондуктан, бизди ар кандай суроолор же кеңири маселе үчүн 24/7 колдоо менен байланыша аласыз. Кандайдыр бир учурда, каалаган убакта биз менен байланышып, мисалы, чалуу же WhatsApp аркылуу теңдешсиз кардарлардын кызматын көрүңүз."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Биз сиздин жеке маалыматтарды колдонобуз, бул сизге колдонмобуздагы мыкты тажрыйба берүү үчүн, анын ичинде контент сунуштарыңызды жеке  кылуу, адистер менен байланыштыруу жана колдонмобуздун функционалдуулугун жакшыртуу. Биз ошондой эле сиз менен жаңыртуулар, промо-акциялар же колдонмобузга байланыштуу башка маалыматтар боюнча байланышууга мүмкүн."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Биз төлөмдү карап, 1-2 сааттын ичинде жактырабыз"),
        "weekly": MessageLookupByLibrary.simpleMessage("Жуманын"),
        "weight": MessageLookupByLibrary.simpleMessage("Салмак"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Жаңы Нерселер"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Оптовик"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Болот сатып алуу баасы"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("Жалпы баа"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Оптовик"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Кийинчерээк кошулат"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Мөөнөтү өтөт"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Бул жерге билдирүү жазыңыз"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("Туура эмес OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Ал колдонуучу үчүн туура эмес пароль берилди."),
        "yearly": MessageLookupByLibrary.simpleMessage("Жылдык"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Ооба, Түптүк Ооруу"),
        "youAreNotAValidUser": MessageLookupByLibrary.simpleMessage(
            "Сиз Жарактуу Колдонуучу Эмессиңиз"),
        "youAreUsing":
            MessageLookupByLibrary.simpleMessage("Сиз колдонуп жатасыз"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Сиз мөөнөтүнө караганда көбүрөөк төлөй албайсыз"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Сизге электрондук кат келди"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Сиз аккаунтуңузга ийгиликтүү кирдиңиз. Pos SaaS менен калыңыз."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("Сиз уруксат беришиңиз керек"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Сиз эсебиңизге кайра киришиңиз керек."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "SMS сатып алуудан мурун идентификацияны текшерүү керек"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Сиздин билдирүүңүз калды"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Сиздин пакет"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Сиздин пакетиңиз 5 күндүн ичинде мөөнөтү өтөт")
      };
}
