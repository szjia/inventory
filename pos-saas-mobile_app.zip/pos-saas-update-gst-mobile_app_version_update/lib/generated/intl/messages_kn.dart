// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a kn locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'kn';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("ಬಿಲ್ ಪ್ಲಜ್"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("ಮುಂದುವರಿಯಿರಿ"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("ಜಿಎಸ್‌ಟಿ ಸಂಖ್ಯೆ"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("ಐಯಜಿಕೋ"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("ಕೆಕೆಐಪೇ"),
        "MRP": MessageLookupByLibrary.simpleMessage("ಎಂಆರ್‌ಪಿ"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("ಎಮ್‌ಆರ್‌ಪಿಯ ಅಗತ್ಯವಿದೆ"),
        "OK": MessageLookupByLibrary.simpleMessage("ಒಂದು"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("ಪೋಸ್ ಎಸ್‌ಎಎಸ್"),
        "Paypal": MessageLookupByLibrary.simpleMessage("ಪೇಪಾಲ್"),
        "PhNo": MessageLookupByLibrary.simpleMessage("ಫೋನ್ ನಂ"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("ರೆಜರ್ಪೇ"),
        "SL": MessageLookupByLibrary.simpleMessage("ಎಸ್‌ಎಲ್"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("ಎಸ್‌ಎಲ್‌ಕಾಮರ್ಝ್"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT ಕೋಡ್"),
        "Snacks": MessageLookupByLibrary.simpleMessage("ಸ್ನಾಕ್ಸ್"),
        "TAX": MessageLookupByLibrary.simpleMessage("ತೆರಿಗೆ"),
        "Uploading": MessageLookupByLibrary.simpleMessage("ಹಲಿಸುತ್ತಿದೆ"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("ಬಳಕೆದಾರ ಶೀರ್ಷಿಕೆ"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "ನಿಮ್ಮ ಪ್ಯಾಕೇಜ್ ಇಂದೇ ಕೊನೆಗೊಳ್ಳುತ್ತದೆ\n\nದಯವಿಟ್ಟು ಮತ್ತೊಮ್ಮೆ ಖರೀದಿಸಿ"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) The System is provided solely for the\npurpose of facilitating point of sale\ntransactions andrelatedactivities in your\nbusiness."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) To use the System, you may be\nrequired to create an account. You\nagree to provide accurate, current, and\ncomplete information during\nthe registration process and toupdate\nsuchinformationto keep itaccurate\nand complete."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("ಆಪ್ ಬಗ್ಗೆ"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("ನಮ್ಮ ಬಗ್ಗೆ"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Acceptance of Terms"),
        "accountName": MessageLookupByLibrary.simpleMessage("ಖಾತೆ ಹೆಸರು"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("ಖಾತೆ ಸಂಖ್ಯೆ"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Account Registration"),
        "acton": MessageLookupByLibrary.simpleMessage("ಚಟುವಟಿಕೆ"),
        "add": MessageLookupByLibrary.simpleMessage("ಹೊಂದಿಸಿ"),
        "addBrand": MessageLookupByLibrary.simpleMessage("ಬ್ರ್ಯಾಂಡ್ ಸೇರಿಸಿ"),
        "addCategory": MessageLookupByLibrary.simpleMessage("ವರ್ಗ ಸೇರಿಸಿ"),
        "addContact": MessageLookupByLibrary.simpleMessage("ಸಂಪರ್ಕ ಸೇರಿಸಿ"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("ಗ್ರಾಹಕ ಸೇರಿಸಿ"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("ವಿತರಣೆ ಸೇರಿಸಿ"),
        "addDescriptioN": MessageLookupByLibrary.simpleMessage("ವಿವರಣೆ ಸೇರಿಸಿ"),
        "addDescription": MessageLookupByLibrary.simpleMessage("ನೋಡಿಗೆ ಸೇರಿಸಿ"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("ಹರಿವು ಸೇರಿಸಿ"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("ಡಾಕ್ಯುಮೆಂಟ್ ಐಡಿ ಸೇರಿಸಿ"),
        "addDucument":
            MessageLookupByLibrary.simpleMessage("ಡಾಕ್ಯುಮೆಂಟ್ ಸೇರಿಸಿ"),
        "addExpense": MessageLookupByLibrary.simpleMessage("ವೆಚ್ಚ ಸೇರಿಸಿ"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("ವೆಚ್ಚ ವರ್ಗ ಸೇರಿಸಿ"),
        "addItems": MessageLookupByLibrary.simpleMessage("ಐಟಂಗಳನ್ನು ಸೇರಿಸಿ"),
        "addNew": MessageLookupByLibrary.simpleMessage("ಹೊಸದು ಸೇರಿಸಿ"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("ಹೊಸ ವಿಳಾಸವನ್ನು ಸೇರಿಸಿ"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("ಹೊಸ ಉತ್ಪನ್ನ ಸೇರಿಸಿ"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("ಹೊಸ ತೆರಿಗೆ ಸೇರಿಸಿ"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "ಒಂದೇ/ಬಹು ತೆರಿಗೆ ಶ್ರೇಣಿಯೊಂದಿಗೆ ಹೊಸ ತೆರಿಗೆ ಸೇರಿಸಿ"),
        "addNote": MessageLookupByLibrary.simpleMessage("ಟೀಕೆ ಸೇರಿಸಿ"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("ಮೊದಲಿಗೆ ಉತ್ಪನ್ನವನ್ನು ಸೇರಿಸಿ"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("ಪ್ರೋಮೋ ಕೋಡ್ ಸೇರಿಸಿ"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("ಖರೀದಿ ಸೇರಿಸಿ"),
        "addSales": MessageLookupByLibrary.simpleMessage("ಮಾರಾಟ ಸೇರಿಸಿ"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("ಯಶಸ್ವಿಯಾಗಿ ಸೇರಿಸಲಾಗಿದೆ"),
        "addUnit": MessageLookupByLibrary.simpleMessage("ಯೂನಿಟ್ ಸೇರಿಸಿ"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("ಬಳಕೆದಾರ ಪಾತ್ರ ಸೇರಿಸಿ"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("ಸಾಧಾರಣವಾಗಿ ಸೇರಿಸಲಾಗಿದೆ"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("ಕಾರ್ಟಿಗೆ ಸೇರಿಸಲಾಗಿದೆ"),
        "address": MessageLookupByLibrary.simpleMessage("ವಿಳಾಸ"),
        "admin": MessageLookupByLibrary.simpleMessage("ನಿರ್ವಾಹಕ"),
        "all": MessageLookupByLibrary.simpleMessage("ಎಲ್ಲಾ"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("ಎಲ್ಲಾ ವ್ಯಾಪಾರ ಪರಿಹಾರಗಳು"),
        "alreadyAdded":
            MessageLookupByLibrary.simpleMessage("ಹಿಂದೆಯೇ ಸೇರಿಸಲಾಗಿದೆ"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("ಇದುವರೆಗೆ ಇದೆ"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("ಈಗಾಗಲೇ ಖಾತೆ ಹೊಂದಿದ್ದೀರಿ"),
        "amount": MessageLookupByLibrary.simpleMessage("ಮೊತ್ತ"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "ಇಮೇಲ್‌ ಕಳುಹಿಸಲಾಗಿದೆ\\nನಿಮ್ಮ ಇನ್‌ಬಾಕ್ಸ್ ಪರಿಶೀಲಿಸಿ"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Android ಮತ್ತು iOS ಆ್ಯಪ್ ಬೆಂಬಲ"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("ಅನ್ವಯವಾಗುವ ತೆರಿಗೆ"),
        "apply": MessageLookupByLibrary.simpleMessage("ಅನ್ವಯಿಸಿ"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "ಈ ರಶೀದಿಯನ್ನು ಅಳಿಸಲು ನೀವು ಖಚಿತವೇ?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "ಈ ಮಾರಾಟವನ್ನು ಅಳಿಸಲು ನೀವು ಖಚಿತವೇ?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "ಈ ಬಳಕೆದಾರರನ್ನು ಅಳಿಸಲು ನೀವು ಖಚಿತವಾಗಿದ್ದೀರಾ?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "ನೀವು ಈ ಮಾಡಿಕೋಟ್ಟನ್ನು ಅಳಿಸಲು ಖಚಿತವಾಗಿದ್ದೀರಾ?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "ನೀವು ಈ ಮಾಡಿಕೋಟ್ ಗುಂಪನ್ನು ಅಳಿಸಲು ಖಚಿತವಾಗಿದ್ದೀರಾ?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "ನೀವು ಈ ಗೋದಾಮನ್ನು ಅಳಿಸಲು ಬಯಸುತ್ತೀರಾ?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "ನೀವು ಈ ಬಳಕೆದಾರನನ್ನು ನಿಶ್ಚಿತವಾಗಿ ಅಳಿಸಲು ಖಚಿತರಾಗಿದ್ದೀರಾ?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("ಅಧಿಕೃತ ಸಹಿ"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) You are responsible for\nmaintainingthe confidentiality of your\naccount and password andfor restricting\naccess to your account. You accept\nresponsibility for all activities that\noccur under your account."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) You must be at least 18 years old or the\nlegal age of majority in your jurisdiction to\nuse the System."),
        "backSide": MessageLookupByLibrary.simpleMessage("ಹಿಂಭಾಗ"),
        "backToHome":
            MessageLookupByLibrary.simpleMessage("ಮುಖಪುಟಕ್ಕೆ ಹಿಂದಿರುಗಿ"),
        "balance": MessageLookupByLibrary.simpleMessage("ಮಿತಿ"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("ಬಂಗಲಾದೇಶ"),
        "bank": MessageLookupByLibrary.simpleMessage("ಬ್ಯಾಂಕ್"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("ಬ್ಯಾಂಕ್ ಖಾತೆ ನಾಣ್ಯ"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("ಬ್ಯಾಂಕ್ ಖಾತೆ ಮುದ್ರಾ"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("ಬ್ಯಾಂಕ್ ಮಾಹಿತಿ"),
        "bankName": MessageLookupByLibrary.simpleMessage("ಬ್ಯಾಂಕ್ ಹೆಸರು"),
        "bankTransfer":
            MessageLookupByLibrary.simpleMessage("ಬ್ಯಾಂಕ್ ವರ್ಗಾವಣೆ"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("ಬಾರ್ಕೋಡ್ ಪತ್ತೆಯಾಗಿದೆ"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("ಬಿಲ್/ರಶೀದಿ"),
        "billTo": MessageLookupByLibrary.simpleMessage("ಬಿಲ್ ಟು"),
        "branchName": MessageLookupByLibrary.simpleMessage("ಶಾಖಾ ಹೆಸರು"),
        "brand": MessageLookupByLibrary.simpleMessage("ಬ್ರ್ಯಾಂಡ್"),
        "brandName": MessageLookupByLibrary.simpleMessage("ಬ್ರ್ಯಾಂಡ್ ಹೆಸರು"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("ತೂಕದ ಅಪ್‌ಲೋಡ್"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("ವ್ಯಾಪಾರ ವರ್ಗ"),
        "buy": MessageLookupByLibrary.simpleMessage("ಖರೀದಿ"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("ಪ್ರೀಮಿಯಂ ಯೋಜನೆ ಖರೀದಿಸಿ"),
        "buySms": MessageLookupByLibrary.simpleMessage("ಎಸ್ಎಂಎಸ್ ಖರೀದಿಸಿ"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "By accessing or using the Point of Sale (POS) System (the \"System\") provided by [Your Company Name] (\"Company\"), you agree to be bound by these Terms of Use. If you do not agree to these Terms of Use, do not use the System."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) You are responsible for ensuring that your\naccess to and use of the System is in\ncompliance with all applicable laws and\nregulations."),
        "cacel": MessageLookupByLibrary.simpleMessage("ರದ್ದುಗೊಳಿಸಿ"),
        "call": MessageLookupByLibrary.simpleMessage("ಕಾಲ್"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "ಆಕಸ್ಮಿಕ ಬೆಂಬಲಕ್ಕಾಗಿ ಕರೆ ಮಾಡಿ"),
        "camera": MessageLookupByLibrary.simpleMessage("ಕ್ಯಾಮೆರಾ"),
        "cancel": MessageLookupByLibrary.simpleMessage("ರದ್ದುಮಾಡಿ"),
        "cancelAllProduct": MessageLookupByLibrary.simpleMessage(
            "ಎಲ್ಲಾ ಉತ್ಪನ್ನಗಳನ್ನು ರದ್ದುಮಾಡಿ"),
        "capacity": MessageLookupByLibrary.simpleMessage("ಹೊರಗೆ"),
        "card": MessageLookupByLibrary.simpleMessage("ಕಾರ್ಡ್"),
        "cash": MessageLookupByLibrary.simpleMessage("ನಗದು"),
        "cashFree": MessageLookupByLibrary.simpleMessage("ಕ್ಯಾಶ್ ಫ್ರೀ"),
        "categories": MessageLookupByLibrary.simpleMessage("ವರ್ಗಗಳು"),
        "category": MessageLookupByLibrary.simpleMessage("ವರ್ಗ"),
        "categoryName": MessageLookupByLibrary.simpleMessage("ವರ್ಗದ ಹೆಸರು"),
        "categoryNameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("ವರ್ಗದ ಹೆಸರು ಈಗಾಗಲೇ ಇದೆ"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("ವರ್ಗ ಹೆಸರು"),
        "change": MessageLookupByLibrary.simpleMessage("ಬದಲಾಯಿಸಿ"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("ಪಾಸ್ವರ್ಡ್ ಬದಲಾಯಿಸಿ"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("ಇಮೇಲ್ ತನಿಖೆಗೆ"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("ಗ್ರಾಹಕ ಆಯ್ಕೆಮಾಡಿ"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("ಸಪ್ಲೈಯರ್ ಆಯ್ಕೆಮಾಡಿ"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("ನಿಮ್ಮ ವಿಶೇಷಗಳನ್ನು ಆಯ್ಕೆಮಾಡಿ"),
        "clarence": MessageLookupByLibrary.simpleMessage("ಕ್ಲಾರೆನ್ಸ್"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("ಸಂಪರ್ಕಿಸಲು ಕ್ಲಿಕ್ ಮಾಡಿ"),
        "close": MessageLookupByLibrary.simpleMessage("ಮುಚ್ಚು"),
        "color": MessageLookupByLibrary.simpleMessage("ಬಣ್ಣ"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(ಬಹುವಿಧ ಮಾಡುವಿಕೋಟ್ಟುಗಳ ಸಂಯೋಜನೆ)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("ಶೀಘ್ರದಲ್ಲೇ ಬರಲಿದೆ"),
        "companyAddress": MessageLookupByLibrary.simpleMessage("ಕಂಪೆನಿ ವಿಳಾಸ"),
        "companyAndShopName": MessageLookupByLibrary.simpleMessage(
            "ಕಂಪೇನಿ ಮತ್ತು ಮಾರಾಟಗಾರಿಕೆ ಹೆಸರು"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("ಕಂಪನಿಯ ಮತ್ತು ವ್ಯವಹಾರದ ಹೆಸರು"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("ಟ್ರಾನ್ಸಾಕ್ಷನ್ ಮುಗಿಸಿ"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("ಪಾಸ್ವರ್ಡ್ ದೃಢೀಕರಿಸಿ"),
        "confirmReturn": MessageLookupByLibrary.simpleMessage(
            "ಹಿಂತೆಗೆದುಕೊಳ್ಳುವನ್ನು ಖಚಿತಪಡಿಸಿ"),
        "congratulations": MessageLookupByLibrary.simpleMessage("ಅಭಿನಂದನೆಗಳು"),
        "contactUs": MessageLookupByLibrary.simpleMessage("ನಮ್ಮಿಂದ ಸಂಪರ್ಕಿಸಿ"),
        "country": MessageLookupByLibrary.simpleMessage("ದೇಶ"),
        "create": MessageLookupByLibrary.simpleMessage("ರಚಿಸಿ"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("ಉಚಿತ ಖಾತೆ ತೆರೆಯಿರಿ"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("ರಚಿಸಲಾಯಿತು ಮತ್ತು ಉಳಿಸಲಾಗಿದೆ"),
        "currency": MessageLookupByLibrary.simpleMessage("ಕರೆನ್ಸಿ"),
        "currentStock": MessageLookupByLibrary.simpleMessage("ಪ್ರಸ್ತುತ ಸ್ಟಾಕ್"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("ವೈಯಕ್ತಿಕ ಚಲನ ಬ್ರ್ಯಾಂಡಿಂಗ್"),
        "customer": MessageLookupByLibrary.simpleMessage("ಗ್ರಾಹಕ"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("ಗ್ರಾಹಕ ವಿವರಗಳು"),
        "customerGST": MessageLookupByLibrary.simpleMessage("ಗ್ರಾಹಕ ಜಿಎಸ್‌ಟಿ"),
        "customerName": MessageLookupByLibrary.simpleMessage("ಗ್ರಾಹಕ ಹೆಸರು"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("ದಿನಾಂಕಿಕ ಲೆಕ್ಕಾಚಾರ"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Dashboard Overview"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("ಡೇಟಾ ಯಶಸ್ವಿಯಾಗಿ ಉಳಿಸಲಾಗಿದೆ"),
        "date": MessageLookupByLibrary.simpleMessage("ದಿನಾಂಕ"),
        "day": MessageLookupByLibrary.simpleMessage("ದಿನ"),
        "dealer": MessageLookupByLibrary.simpleMessage("ವಿಪಣಿದಾರ"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("ಡೀಲರ್ ಬೆಲೆ"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("ಅನುಕೂಲ VAT ಶೇ.% ಶೇಕಡಾವಾರು"),
        "delete": MessageLookupByLibrary.simpleMessage("ಅಳಿಸಿ"),
        "deleting": MessageLookupByLibrary.simpleMessage("ಅಳಿಸುತ್ತಿದೆ"),
        "deliveryAddress": MessageLookupByLibrary.simpleMessage("ವಿತರಣಾ ವಿಳಾಸ"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("ವಿತರಣಾ ವಿಳಾಸಗಳು"),
        "deliveryCharge": MessageLookupByLibrary.simpleMessage("ವಿತರಣಾ ಶುಲ್ಕ"),
        "describtion": MessageLookupByLibrary.simpleMessage("ವಿವರಣೆ"),
        "description": MessageLookupByLibrary.simpleMessage("ವಿವರಣೆ"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("ವಿವರಣೆಯನ್ನು ಖಾಲಿ ಇರಬಾರದು"),
        "details": MessageLookupByLibrary.simpleMessage("ವಿವರಗಳು"),
        "discount": MessageLookupByLibrary.simpleMessage("ರಿಯಾಯಿತಿ"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("ಖಚಿತಪಡಿಸಬೇಡಿ"),
        "done": MessageLookupByLibrary.simpleMessage("ಮುಗಿಯಿತು"),
        "downloadExcelFormat": MessageLookupByLibrary.simpleMessage(
            "ಎಕ್ಸೆಲ್ ರೂಪದಲ್ಲಿ ಡೌನ್‌ಲೋಡ್ ಮಾಡಿ"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "ಡೌನ್‌ಲೋಡ್ ಫೋಲ್ಡರ್‌ನಲ್ಲಿ ಯಶಸ್ವಿಯಾಗಿ ಡೌನ್‌ಲೋಡ್ ಮಾಡಲಾಗಿದೆ"),
        "due": MessageLookupByLibrary.simpleMessage("ಬಾಕಿ"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("ಬಾಕಿ ಮೊತ್ತ: "),
        "dueCollection": MessageLookupByLibrary.simpleMessage("ಬಾಕಿ ಸಂಗ್ರಹ"),
        "dueCollectionReports": MessageLookupByLibrary.simpleMessage(
            "ಸಾವಧಾನಗೊಳಿಸುತ್ತಿದ್ದ ವಸೂಲಿ ವರದಿಗಳು"),
        "dueList": MessageLookupByLibrary.simpleMessage("ಬಾಕಿ ಪಟ್ಟಿ"),
        "dueReports": MessageLookupByLibrary.simpleMessage("ಬಾಕಿ ವರದಿ"),
        "duration": MessageLookupByLibrary.simpleMessage("ಅವಧಿ"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("ಅವಧಿ: ನಿಂದ"),
        "easyToUseMobilePos":
            MessageLookupByLibrary.simpleMessage("ಸುಲಭವಾದ ಮೊಬೈಲ್ ಪಾಸ್"),
        "edit": MessageLookupByLibrary.simpleMessage("ಸಂಪಾದಿಸು"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("ಖರೀದಿ ಚಲಾನದ ಬದಲಾಯಿಸಿ"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("ಮಾರಾಟ ಚಲಾನದ ಬದಲಾಯಿಸಿ"),
        "editSocailMedia": MessageLookupByLibrary.simpleMessage(
            "ಸಾಮಾಜಿಕ ಮಾಧ್ಯಮಗಳನ್ನು ಸಂಪಾದಿಸಿ"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("ಶುಭವಾಗಿ ಸಂಪಾದಿಸಲಾಗಿದೆ"),
        "editTax":
            MessageLookupByLibrary.simpleMessage("ಮಾಡಿಕೋಟ್ಟನ್ನು ಸಂಪಾದಿಸಿ"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("ಮಾಡಿಕೋಟ್ ಗುಂಪು ಸಂಪಾದಿಸಿ"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("ಗೋದಾಮನ್ನು ಸಂಪಾದಿಸಿ"),
        "email": MessageLookupByLibrary.simpleMessage("ಇಮೇಲ್"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("ಇಮೇಲ್ ವಿಳಾಸ"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("ಇಮೇಲ್ ಖಾಲಿ ಇರಬಾರದು"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "ಇಮೇಲ್ ಕಳುಹಿಸಲಾಗಿದೆ! ನಿಮ್ಮ ಇನ್ಬಾಕ್ಸ್ ಅನ್ನು ಪರಿಶೀಲಿಸಿ"),
        "endDate": MessageLookupByLibrary.simpleMessage("ಕೊನೆಯ ದಿನಾಂಕ"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("ಮಾನ್ಯ ಮೊತ್ತವನ್ನು ನಮೂದಿಸಿ"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("ಸರಿಯಾದ ಕಡಿತವನ್ನು ನಮೂದಿಸಿ"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "ಮಾನ್ಯ ದೂರವಾಣಿ ಸಂಖ್ಯೆಯನ್ನು ನಮೂದಿಸಿ"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("ಸರಿಯಾದ ಬೆಲೆಯನ್ನು ನಮೂದಿಸಿ"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("ಸರಿಯಾದ ಪ್ರಮಾಣವನ್ನು ನಮೂದಿಸಿ"),
        "enterAddress":
            MessageLookupByLibrary.simpleMessage("ವಿಳಾಸವನ್ನು ನಮೂದಿಸಿ"),
        "enterAmount":
            MessageLookupByLibrary.simpleMessage("ಮೊತ್ತವನ್ನು ನಮೂದಿಸಿ"),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("ಬ್ರ್ಯಾಂಡ್ ಹೆಸರನ್ನು ನಮೂದಿಸಿ"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("ಹೊರಗೆಯನ್ನು ನಮೂದಿಸಿ"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("ವರ್ಗ ಹೆಸರನ್ನು ನಮೂದಿಸಿ"),
        "enterColor": MessageLookupByLibrary.simpleMessage("ಬಣ್ಣವನ್ನು ನಮೂದಿಸಿ"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "ಗ್ರಾಹಕ ಜಿಎಸ್‌ಟಿ ಸಂಖ್ಯೆಯನ್ನು ನಮೂದಿಸಿ"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("ಡೀಲರ್ ಬೆಲೆ ನಮೂದಿಸಿ"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("ವಿವರಣೆ ನಮೂದಿಸಿ"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("ಡಿಸ್ಕೌಂಟ್ ನಮೂದಿಸಿ"),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("ವೆಚ್ಚ ದಿನಾಂಕವನ್ನು ನಮೂದಿಸಿ"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("ಪೂರ್ಣ ವಿಳಾಸವನ್ನು ನಮೂದಿಸಿ"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("ಚಲಾನ ಸಂಖ್ಯೆ ನಮೂದಿಸಿ"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "ಕೀಳ್ಮಟ್ಟದ ಸ್ಟಾಕ್ ಸೂಚನೆ ಪ್ರಮಾಣವನ್ನು ನಮೂದಿಸಿ"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("ನಿರ್ಮಾತೃ ನಮೂದಿಸಿ"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("ಸಂದೇಶ ವಿಷಯವನ್ನು ನಮೂದಿಸಿ"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "ಎಂಆರ್‌ಪಿ/ಖರೀದಿಕರ್ತ ಬೆಲೆ ನಮೂದಿಸಿ"),
        "enterName": MessageLookupByLibrary.simpleMessage("ಹೆಸರನ್ನು ನಮೂದಿಸಿ"),
        "enterNote": MessageLookupByLibrary.simpleMessage("ಟೀಕೆ ನಮೂದಿಸಿ"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("ಪಕ್ಷ ಹೆಸರನ್ನು ನಮೂದಿಸಿ"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("ಫೋನ್ ಸಂಖ್ಯೆಯನ್ನು ನಮೂದಿಸಿ"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "ಉತ್ಪನ್ನ ಕೋಡ್ ಅಥವಾ ಸ್ಕ್ಯಾನ್ ಮಾಡಿ"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("ಉತ್ಪನ್ನ ಹೆಸರನ್ನು ನಮೂದಿಸಿ"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("ಖರೀದಿ ಬೆಲೆ ನಮೂದಿಸಿ"),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("ಸಂದರ್ಭ ಸಂಖ್ಯೆಯನ್ನು ನಮೂದಿಸಿ"),
        "enterSize": MessageLookupByLibrary.simpleMessage("ಗಾತ್ರವನ್ನು ನಮೂದಿಸಿ"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("ಸ್ಟಾಕ್ಸ್ ನಮೂದಿಸಿ"),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("ಮಾಡಿಕೋಟ್ಟು ದರ ನಮೂದಿಸಿ"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("ಲಾಭ ಲಭ್ಯತೆ ಐಡಿ ನಮೂದಿಸಿ"),
        "enterType":
            MessageLookupByLibrary.simpleMessage("ಪ್ರಕಾರವನ್ನು ನಮೂದಿಸಿ"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("ಬಳಕೆದಾರ ಶೀರ್ಷಿಕೆ ನಮೂದಿಸಿ"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("ಮಾನ್ಯ ಮೊತ್ತವನ್ನು ನಮೂದಿಸಿ"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("ಗೋದಾಮಿನ ಹೆಸರನ್ನು ನಮೂದಿಸಿ"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("ತೂಕವನ್ನು ನಮೂದಿಸಿ"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("ಮೊತ್ತವಿಕ್ರಯ ಬೆಲೆ ನಮೂದಿಸಿ"),
        "enterYourDescriptionHere": MessageLookupByLibrary.simpleMessage(
            "ಇಲ್ಲಿ ನಿಮ್ಮ ವಿವರಣೆಯನ್ನು ನಮೂದಿಸಿ"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "ನಿಮ್ಮ ಇಮೇಲ್ ವಿಳಾಸವನ್ನು ನಮೂದಿಸಿ"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "ನಿಮ್ಮ ಪ್ರತಿಕ್ರಿಯಾ ಶೀರ್ಷಿಕೆಯನ್ನು ನಮೂದಿಸಿ"),
        "enterYourGSTNumber": MessageLookupByLibrary.simpleMessage(
            "ನಿಮ್ಮ ಜಿಎಸ್‌ಟಿ ಸಂಖ್ಯೆಯನ್ನು ನಮೂದಿಸಿ"),
        "enterYourMobileNumber": MessageLookupByLibrary.simpleMessage(
            "ನಿಮ್ಮ ಮೊಬೈಲ್ ಸಂಖ್ಯೆಯನ್ನು ನಮೂದಿಸಿ"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("ನಿಮ್ಮ ಹೆಸರನ್ನು ನಮೂದಿಸಿ"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("ನಿಮ್ಮ ಫೋನ್ ನಂಬರನ್ನು ನಮೂದಿಸಿ"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("ನಿಮ್ಮ ಪಾಸ್‌ವರ್ಡ್ ನಮೂದಿಸಿ"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("ನಿಮ್ಮ ಫೋನ್ ನಂಬರನ್ನು ನಮೂದಿಸಿ"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "ನಿಮ್ಮ ಟ್ರಾನ್ಸಕ್ಷನ್ ಐಡಿಯನ್ನು ನಮೂದಿಸಿ"),
        "error": MessageLookupByLibrary.simpleMessage("ದೋಷ"),
        "excTax": MessageLookupByLibrary.simpleMessage("ಏಕ್ಸ್. ತೆರಿಗೆ"),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("ಎಕ್ಸೆಲ್ ಅಪ್ಲೋಡರ್"),
        "exclusive": MessageLookupByLibrary.simpleMessage("ಕೆಲವು ಮಾತ್ರ"),
        "expense": MessageLookupByLibrary.simpleMessage("ವೇತನ"),
        "expenseCategory": MessageLookupByLibrary.simpleMessage("ವೆಚ್ಚ ವರ್ಗ"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("ವೆಚ್ಚ ದಿನಾಂಕ"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("ವೆಚ್ಚ ಪರವಾನಗಿ"),
        "expenseReport": MessageLookupByLibrary.simpleMessage("ವೆಚ್ಚ ವರದಿ"),
        "expireDate": MessageLookupByLibrary.simpleMessage("ಅವಧಿ ಕೊನೆ ದಿನಾಂಕ"),
        "expired": MessageLookupByLibrary.simpleMessage("ಅತ್ಯುತ್ತೀರ್ಣ"),
        "expiring": MessageLookupByLibrary.simpleMessage("ಅತ್ಯುತ್ತೀರ್ಣ"),
        "facebok": MessageLookupByLibrary.simpleMessage("ಫೇಸ್‌ಬುಕ್"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("ದೋಷದಿಂದ ವಿಫಲವಾಗಿದೆ"),
        "fashion": MessageLookupByLibrary.simpleMessage("ಫ್ಯಾಷನ್"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "ವಿಶೇಷಗಳು ಪಾರಂಪರಿಕ ಪರಿಹಾರಗಳಿಂದ ಬೇರೆಯಾಗಿ ಮಾಡುವಂತೆ ಮಾಡುವುದು ಮುಖ್ಯ ಭಾಗವಾಗಿದೆ."),
        "feedBack": MessageLookupByLibrary.simpleMessage("ಪ್ರತಿಕ್ರಿಯೆ"),
        "firstName": MessageLookupByLibrary.simpleMessage("ಮೊದಲ ಹೆಸರು"),
        "followUsOnFacebook": MessageLookupByLibrary.simpleMessage(
            "ನಮನ್ನು ಫೇಸ್ಬುಕ್‌ನಲ್ಲಿ ಅನುಸರಿಸಿ"),
        "followUsOnTwitter": MessageLookupByLibrary.simpleMessage(
            "ನಮನ್ನು ಟ್ವಿಟ್ಟರ್‌ನಲ್ಲಿ ಅನುಸರಿಸಿ"),
        "fontSide": MessageLookupByLibrary.simpleMessage("ಮುಂಗಡ ಭಾಗ"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("ಅಸೀಮಿತ ಬಳಕೆಗಾಗಿ"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("ಪಾಸ್ವರ್ಡ್ ಮರೆತಿದ್ದೀರಿ"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("ಪಾಸ್ವರ್ಡ್ ಮರೆತಿದ್ದೀರಿ?"),
        "formDate": MessageLookupByLibrary.simpleMessage("ದಿನಾಂಕದಿಂದ"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("ಉಚಿತ ಡೇಟಾ ಬ್ಯಾಕಪ್"),
        "freeLifeTimeUpdate":
            MessageLookupByLibrary.simpleMessage("ಉಚಿತ ಜೀವನ ಅಪ್‌ಡೇಟ್"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("ಉಚಿತ ಪ್ಯಾಕೇಜ್"),
        "freePlan": MessageLookupByLibrary.simpleMessage("ಉಚಿತ ಯೋಜನೆ"),
        "from": MessageLookupByLibrary.simpleMessage("(ರಿಂದ"),
        "fullyPaid":
            MessageLookupByLibrary.simpleMessage("ಪೂರ್ಣವಾಗಿ ಪಾವತಿಸಲಾಗಿದೆ"),
        "gallary": MessageLookupByLibrary.simpleMessage("ಗ್ಯಾಲರಿ"),
        "generatingPDF":
            MessageLookupByLibrary.simpleMessage("ಪಿಡಿಎಫ್ ಅನ್ನು ರಚಿಸುತ್ತಿದೆ"),
        "getOtp": MessageLookupByLibrary.simpleMessage("ಒಟಿಪಿ ಪಡೆಯಿರಿ"),
        "govermentId": MessageLookupByLibrary.simpleMessage("ಸರ್ಕಾರದ ಗುರುತು"),
        "guest": MessageLookupByLibrary.simpleMessage("ಅತಿಥಿ"),
        "havenotAnAccounts": MessageLookupByLibrary.simpleMessage(
            "ಯಾವುದೇ ಖಾತೆಯನ್ನು ಹೊಂದಿಲ್ಲವೇ?"),
        "history": MessageLookupByLibrary.simpleMessage("ಇತಿಹಾಸ"),
        "home": MessageLookupByLibrary.simpleMessage("ಮುಖಪುಟ"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "How We Protect Your Information"),
        "howWeUseYourInformation":
            MessageLookupByLibrary.simpleMessage("How We Use Your Information"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("ಗುರುತು ಪರಿಶೀಲಿಸಿ"),
        "image": MessageLookupByLibrary.simpleMessage("ಚಿತ್ರ"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("ಇನ್‌ಹೌಸ್ ಅಳಿಸಲಾಗುವುದಿಲ್ಲ"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("ಇನ್‌ಹೌಸ್ ಸಂಪಾದಿಸಲಾಗುವುದಿಲ್ಲ"),
        "inWord": MessageLookupByLibrary.simpleMessage("ಶಬ್ದದಲ್ಲಿ"),
        "incTax": MessageLookupByLibrary.simpleMessage("ಇನ್. ತೆರಿಗೆ"),
        "inclusive": MessageLookupByLibrary.simpleMessage("ಒಂದಕ್ಕಿಂತ ಹೆಚ್ಚು"),
        "increaseStock":
            MessageLookupByLibrary.simpleMessage("ಭಂಡಾರವನ್ನು ಹೆಚ್ಚಿಸಿ"),
        "inistrument": MessageLookupByLibrary.simpleMessage("ಉಪಕರಣ"),
        "instragram": MessageLookupByLibrary.simpleMessage("ಇಂಸ್ಟಾಗ್ರಾಮ್"),
        "invNo": MessageLookupByLibrary.simpleMessage("ಮಿಡಿತ ಸಂಖ್ಯೆ"),
        "invoice": MessageLookupByLibrary.simpleMessage("ಬಿಲ್ಲು"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("ಚಲಾನ ಸಂಖ್ಯೆ"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("ಚಲಾನ ಸೆಟ್ಟಿಂಗ್"),
        "invoiceViewer": MessageLookupByLibrary.simpleMessage("ಬಿಲ್ಲು ವೀಕ್ಷಕ"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("ಐಟಂ ಸೇರಿದರು"),
        "kg": MessageLookupByLibrary.simpleMessage("ಕಿಗ್ರಾಂ"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("ಕೆವೈಸಿ ಪರಿಶೀಲಣೆ"),
        "language": MessageLookupByLibrary.simpleMessage("ಭಾಷೆ"),
        "lastName": MessageLookupByLibrary.simpleMessage("ಕೊನೆಯ ಹೆಸರು"),
        "ledger": MessageLookupByLibrary.simpleMessage("ಲೆಡ್ಜರ್"),
        "lifeTimePurchase": MessageLookupByLibrary.simpleMessage("ಜೀವನದ ಕೊಳೆ"),
        "link": MessageLookupByLibrary.simpleMessage("ಲಿಂಕ್"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("ಲಿಂಕ್ಡ್‌ಇನ್"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("ಜೀವಂತ ಚಾಟ್ ಬೆಂಬಲ"),
        "loading": MessageLookupByLibrary.simpleMessage("ಭರ್ತಿಯಾಗುತ್ತಿದೆ"),
        "logIn": MessageLookupByLibrary.simpleMessage("ಲಾಗಿನ್ ಮಾಡಿ"),
        "logOUt": MessageLookupByLibrary.simpleMessage("ಲಾಗ್ ಔಟ್"),
        "logOut": MessageLookupByLibrary.simpleMessage("ಲಾಗ್ ಔಟ್"),
        "login": MessageLookupByLibrary.simpleMessage("ಲಾಗಿನ್ ಮಾಡಿ"),
        "logo": MessageLookupByLibrary.simpleMessage("ಲೋಗೋ"),
        "loss": MessageLookupByLibrary.simpleMessage("ನಷ್ಟ"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("ಲಾಭ/ನಷ್ಟ"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("ಲಾಭ/ನಷ್ಟ ವಿವರಗಳು"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("ನಷ್ಟ/ಲಾಭ ವರದಿ"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("ನಷ್ಟ/ಲಾಭ ವರದಿಗಳು"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("ಕೀಳ್ಮಟ್ಟದ ಸ್ಟಾಕ್ ಸೂಚನೆ"),
        "maan": MessageLookupByLibrary.simpleMessage("ಮಾನ್"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "ಬ್ರಾಂಡ್ ಇನ್ ವಾಯ್ಸ್ ಗಳೊಂದಿಗೆ ನಿಮ್ಮ ಗ್ರಾಹಕರ ಮೇಲೆ ಶಾಶ್ವತವಾದ ಪ್ರಭಾವ ಬೀರಿ. ನಮ್ಮ ಅನ್ ಲಿಮಿಟೆಡ್ ಅಪ್ ಗ್ರೇಡ್ ನಿಮ್ಮ ಇನ್ ವಾಯ್ಸ್ ಗಳನ್ನು ಕಸ್ಟಮೈಸ್ ಮಾಡುವ ವಿಶಿಷ್ಟ ಪ್ರಯೋಜನವನ್ನು ನೀಡುತ್ತದೆ, ನಿಮ್ಮ ಬ್ರ್ಯಾಂಡ್ ಗುರುತನ್ನು ಬಲಪಡಿಸುವ ಮತ್ತು ಗ್ರಾಹಕರ ನಿಷ್ಠೆಯನ್ನು ಉತ್ತೇಜಿಸುವ ವೃತ್ತಿಪರ ಸ್ಪರ್ಶವನ್ನು ಸೇರಿಸುತ್ತದೆ."),
        "manageYourBussinessWith": MessageLookupByLibrary.simpleMessage(
            "ನಿಮ್ಮ ವ್ಯಾಪಾರವನ್ನು ನಿರ್ವಹಿಸಿ "),
        "manufactureDate": MessageLookupByLibrary.simpleMessage("ತಯಾರಿ ದಿನಾಂಕ"),
        "margin": MessageLookupByLibrary.simpleMessage("ಆಸ್ತಿ"),
        "masterCard": MessageLookupByLibrary.simpleMessage("ಮಾಸ್ಟರ್ ಕಾರ್ಡ್"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("ನಿರ್ಮಾತಾ"),
        "message": MessageLookupByLibrary.simpleMessage("ಸಂದೇಶ"),
        "messageHistory": MessageLookupByLibrary.simpleMessage("ಸಂದೇಶ ಇತಿಹಾಸ"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Pos Saas ಆ್ಯಪ್ ಉಚಿತವಾಗಿದೆ, ಬಳಕೆಯಲ್ಲಿ ಸುಲಭ. ವಾಸ್ತವವಾಗಿ, ಇದು ವಿಶ್ವದ ಹೊರಗಿನ ಅತ್ಯದ್ಭುತ ಪಿಓಎಸ್ ವ್ಯವಸ್ಥೆಗಳಲ್ಲಿ ಒಂದು."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas ಪೂರ್ಣ ವ್ಯಾಪಾರ ಪರಿಹಾರ ಆಗಿದೆ, ಸ್ಟಾಕ್, ಖಾತೆ, ಮಾರಾಟ, ವ್ಯಯ ಮತ್ತು ಲಾಭ/ಲಾಭ ಹೊಂದಿದೆ."),
        "mobile": MessageLookupByLibrary.simpleMessage("ಮೊಬೈಲ್"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("ಮೊಬೈಲ್ ಪಾವತಿ"),
        "monthly": MessageLookupByLibrary.simpleMessage("ಮಾಸಿಕ"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("ಹೆಚ್ಚಿನ ಮಾಹಿತಿ"),
        "name": MessageLookupByLibrary.simpleMessage("ನಿಮ್ಮ ಹೆಸರನ್ನು ನಮೂದಿಸಿ"),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("ಹೆಸರು ಈಗಾಗಲೇ ಇದೆ"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("ಹೆಸರು ಖಾಲಿ ಇರಬಾರದು"),
        "next": MessageLookupByLibrary.simpleMessage("ಮುಂದೆ"),
        "noConnection": MessageLookupByLibrary.simpleMessage("ಸಂಪರ್ಕ ಇಲ್ಲ"),
        "noData": MessageLookupByLibrary.simpleMessage("ಡೇಟಾ ಇಲ್ಲ"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("ಡೇಟಾ ಲಭ್ಯವಿಲ್ಲ"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("ಯಾವುದೇ ಡೇಟಾ ಕಂಡುಬಂದಿಲ್ಲ"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("ಯಾವ ಇತಿಹಾಸವೂ ಕಂಡುಬಂದಿಲ್ಲ!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("ಉತ್ಪನ್ನವನ್ನು ಕಂಡುಬಂದಿಲ್ಲ"),
        "noSubTaxSelected": MessageLookupByLibrary.simpleMessage(
            "ಯಾವುದೇ ಉಪ ತೆರಿಗೆ ಆಯ್ಕೆ ಮಾಡಿಲ್ಲ"),
        "noTransactionFound": MessageLookupByLibrary.simpleMessage(
            "ಯಾವ ಲೆಕ್ಕಾಚಾರವೂ ಕಂಡುಬಂದಿಲ್ಲ!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "ಆ ಇಮೇಲ್ ಗೆ ಯಾವ ಬಳಕೆದಾರರೂ ಕಂಡುಬಂದಿಲ್ಲ."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "ಯಾವುದೇ ಬಳಕೆದಾರ ಪಾತ್ರ ಸಿಗಲಿಲ್ಲ"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("ಕ್ರಿಯಾತ್ಮಕ ಬಳಕೆದಾರ ಅಲ್ಲ"),
        "notProvided": MessageLookupByLibrary.simpleMessage("ನೀಡಲಾಗಿಲ್ಲ"),
        "note": MessageLookupByLibrary.simpleMessage("ಟೀಕೆ"),
        "notes": MessageLookupByLibrary.simpleMessage("ಗಮನಗಳು"),
        "notification": MessageLookupByLibrary.simpleMessage("ಅಧಿಸೂಚನೆ"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("ಓಟಿಪಿ ಕಳುಹಿಸಲಾಗಿದೆ"),
        "office": MessageLookupByLibrary.simpleMessage("ಕಾರ್ಯಾಲಯ"),
        "ok": MessageLookupByLibrary.simpleMessage("ಸರಿ"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS that contains a great deal of functionality, including sales tracking, inventory management."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "This system helps you improve your operations for your customers."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Our POS system should simplify daily operations automatically, making it easy to navigate."),
        "openingBalance": MessageLookupByLibrary.simpleMessage("ಆರಂಭಿಕ ಶಿಲುಬೆ"),
        "order": MessageLookupByLibrary.simpleMessage("ಆದೇಶಗಳು"),
        "other": MessageLookupByLibrary.simpleMessage("ಇತರ"),
        "otp": MessageLookupByLibrary.simpleMessage("ಮುಕ್ತ"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("ಸ್ಟಾಕ್‌ನಲ್ಲಿ ಇಲ್ಲ"),
        "pacakge": MessageLookupByLibrary.simpleMessage("ಪ್ಯಾಕೇಜ್"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("ಪ್ಯಾಕೇಜ್ ವೈಶಿಷ್ಟ್ಯಗಳು"),
        "paid": MessageLookupByLibrary.simpleMessage("ಪಾವತಿಸಿದ"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("ಪಾವಿತ ಮೊತ್ತ"),
        "parties": MessageLookupByLibrary.simpleMessage("ಪಕ್ಷಗಳು"),
        "partiesList": MessageLookupByLibrary.simpleMessage("ಪಕ್ಷಗಳ ಪಟ್ಟಿ"),
        "partyGST": MessageLookupByLibrary.simpleMessage("ಪಾರ್ಟಿ ಜಿಎಸ್‌ಟಿ"),
        "partyName": MessageLookupByLibrary.simpleMessage("ಪಕ್ಷ ಹೆಸರು"),
        "password": MessageLookupByLibrary.simpleMessage("ಪಾಸ್ವರ್ಡ್"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "ಗುಪ್ತಪದ ಮತ್ತು ದೃಢೀಕರಣ ಗುಪ್ತಪದವು ಹೊಂದಿಕೆಯಾಗುತ್ತಿಲ್ಲ"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("ಪಾಸ್‌ವರ್ಡ್ ಖಾಲಿ ಇರಬಾರದು"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("ಪಾಸ್‌ವರ್ಡ್ ಹೊಂದುತ್ತಿಲ್ಲ"),
        "payCash": MessageLookupByLibrary.simpleMessage("ಕ್ಯಾಷ್ ಪಾವ್"),
        "payStack": MessageLookupByLibrary.simpleMessage("ಪೇಸ್ಟಾಕ್"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("ಬಿಕ್ಯಾಷ್ ಬಳಸಿ ಪಾವತಿಗೆ ಮಾಡಿ"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("ಪೇಪಾಲ್ ಬಳಸಿ ಪಾವತಿಗೆ ಮಾಡಿ"),
        "payeeName": MessageLookupByLibrary.simpleMessage("ಪಾವತಿಗೆ ಹೆಸರು"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("ಪಾವತಿಗೆ ಸಂಖ್ಯೆ"),
        "payment": MessageLookupByLibrary.simpleMessage("ಪಾವತಿ"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("ಪಾವತಿ ಮೊತ್ತ"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("ಪಾವತಿ ಮುಕ್ತಾಯವಾಗಿದೆ"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("ಪಾವತಿ ನಿರ್ದೇಶನೆ:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("ಪಾವತಿ ವಿಧಾನ"),
        "paymentType": MessageLookupByLibrary.simpleMessage("ಪಾವತಿ ಪ್ರಕಾರ"),
        "pdfView": MessageLookupByLibrary.simpleMessage("ಪಿಡಿಎಫ್ ವೀಕ್ಷಣೆ"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("ಖಾಸಗಿ ಮಾಹಿತಿ"),
        "phone": MessageLookupByLibrary.simpleMessage("ಫೋನ್"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("ಫೋನ್ ಸಂಖ್ಯೆ"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "ದೂರವಾಣಿ ಸಂಖ್ಯೆ ಹಿಂದೆಯೇ ಬಳಸಲಾಗಿದೆ"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("ದೂರವಾಣಿ ಸಂಖ್ಯೆ ಮಾನ್ಯವಲ್ಲ"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("ದೂರವಾಣಿ ಸಂಖ್ಯೆ ಅಗತ್ಯವಿದೆ"),
        "pickAndUploadFile": MessageLookupByLibrary.simpleMessage(
            "ಫೈಲ್ ಆಯ್ಕೆ ಮಾಡಿ ಮತ್ತು ಅಪ್ಲೋಡ್ ಮಾಡಿ"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("ಕೊನೆಯ ದಿನಾಂಕ ಆಯ್ಕೆಮಾಡಿ"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("ಪ್ರಾರಂಭ ದಿನಾಂಕ ಆಯ್ಕೆಮಾಡಿ"),
        "plan": MessageLookupByLibrary.simpleMessage("ಯೋಜನೆ"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("ದಯವಿಟ್ಟು ಪ್ರಮಾಣವನ್ನು ಸೇರಿಸಿ"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "ದಯವಿಟ್ಟು ನಿಮ್ಮ ಇಂಟರ್ನೆಟ್ ಸಂಪರ್ಕವನ್ನು ಪರೀಕ್ಷಿಸಿ"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "ದಯವಿಟ್ಟು ಮೊದಲು ಮುದ್ರಕವನ್ನು ಸಂಪರ್ಕಿಸಿ"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "ದಯವಿಟ್ಟು ನಿಮ್ಮ ಬ್ಲೂಟೂಥ್ ಮುದ್ರಕವನ್ನು ಸಂಪರ್ಕಿಸಿ"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "ದಯವಿಟ್ಟು ದೊಡ್ಡ ಪಾಸ್‌ವರ್ಡ್ ನಮೂದಿಸಿ"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "ದಯವಿಟ್ಟು ದೃಢೀಕರಿಸಿ ಪಾಸ್ವರ್ಡ್ ನಮೂದಿಸಿ"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("ದಯವಿಟ್ಟು ಪಾಸ್ವರ್ಡ್ ನಮೂದಿಸಿ"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "ದಯವಿಟ್ಟು ಒಳ್ಳೆಯ ಇಮೇಲ್ ನಮೂದಿಸಿ"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("ದಯವಿಟ್ಟು ಹೆಸರು ನಮೂದಿಸಿ"),
        "pleaseEnterPassword": MessageLookupByLibrary.simpleMessage(
            "ದಯವಿಟ್ಟು ಗುಪ್ತಪದವನ್ನು ನಮೂದಿಸಿ"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "ದಯವಿಟ್ಟು ಪಾಸ್ವರ್ಡ್ ರೀಸೆಟ್ ಲಿಂಕ್ ಪಡೆಯಲು ಕೆಳಗಿನ ಇಮೇಲ್ ವಿಳಾಸವನ್ನು ನಮೂದಿಸಿ."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "ದಯವಿಟ್ಟು ವ್ಯವಹಾರ ಸಂಖ್ಯೆಯನ್ನು ನಮೂದಿಸಿ"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("ದಯವಿಟ್ಟು ಮೊತ್ತವನ್ನು ನಮೂದಿಸಿ"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "ದಯವಿಟ್ಟು ಮೊದಲು ವರ್ಗವನ್ನು ಆಯ್ಕೆಮಾಡಿ"),
        "pleaseSelectAPlan": MessageLookupByLibrary.simpleMessage(
            "ದಯವಿಟ್ಟು ಒಂದು ಯೋಜನೆಯನ್ನು ಆಯ್ಕೆ ಮಾಡಿ"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "ದಯವಿಟ್ಟು ವ್ಯವಹಾರ ವರ್ಗವನ್ನು ಆಯ್ಕೆಮಾಡಿ"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "ಆಪ್ಲಿಕೇಶನ್ ಬಳಸಲು ಸರಿಯಾದ ಖರೀದಿ ಕೋಡ್ ಅನ್ನು ಬಳಸಿರಿ"),
        "powerdedByMobiPos": MessageLookupByLibrary.simpleMessage(
            "Pos Saas ದ್ವಾರಾ ಸಶಕ್ತಗೊಂಡಿದೆ"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("ನಿರ್ವಹಿಸುತ್ತದೆ"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("ಪ್ರೀಮಿಯಂ ಗ್ರಾಹಕ ಬೆಂಬಲ"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("ಪ್ರೀಮಿಯಂ ಯೋಜನೆ"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("ಹಿಂದಿನ ಪಾವತಿ ಮೊತ್ತಗಳು"),
        "price": MessageLookupByLibrary.simpleMessage("ಬೆಲೆ"),
        "print": MessageLookupByLibrary.simpleMessage("ಮುದ್ರಿಸು"),
        "printingOption": MessageLookupByLibrary.simpleMessage("ಮುದ್ರಣ ಆಯ್ಕೆ"),
        "privacyPolicy": MessageLookupByLibrary.simpleMessage("ಗೌಪ್ಯತಾ ನೀತಿ"),
        "product": MessageLookupByLibrary.simpleMessage("ಉತ್ಪನ್ನ"),
        "productCode": MessageLookupByLibrary.simpleMessage("ಉತ್ಪನ್ನ ಕೋಡ್"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("ಉತ್ಪನ್ನ ಕೋಡ್ ಅಗತ್ಯವಿದೆ"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("ಉತ್ಪನ್ನ ಕೋಡ್/ಹೆಸರು"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("ಉತ್ಪನ್ನ ವಿವರಣೆ"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("ಉತ್ಪನ್ನ ವಿವರಗಳು"),
        "productList": MessageLookupByLibrary.simpleMessage("ಉತ್ಪನ್ನ ಪಟ್ಟಿ"),
        "productName": MessageLookupByLibrary.simpleMessage("ಉತ್ಪನ್ನ ಹೆಸರು"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "ಉತ್ಪನ್ನ ಹೆಸರು ಈ ಗೋದಾಮಿನಲ್ಲಿ ಹಿಂದೆಯೇ ಇದೆ"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "ಉತ್ಪನ್ನದ ಹೆಸರು ಈಗಾಗಲೇ ಸೇರಿಸಲಾಗಿದೆ"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("ಉತ್ಪನ್ನ ಹೆಸರಿನ ಅಗತ್ಯವಿದೆ"),
        "products": MessageLookupByLibrary.simpleMessage("ಉತ್ಪನ್ನಗಳು"),
        "profile": MessageLookupByLibrary.simpleMessage("ಪ್ರೊಫೈಲ್"),
        "profileEdit":
            MessageLookupByLibrary.simpleMessage("ಪ್ರೊಫೈಲ್ ಸಂಪಾದಿಸಿ"),
        "profit": MessageLookupByLibrary.simpleMessage("ಲಾಭ"),
        "promo": MessageLookupByLibrary.simpleMessage("ಪ್ರೊಮೊ"),
        "promoCode": MessageLookupByLibrary.simpleMessage("ಪ್ರೊಮೊ ಕೋಡ್"),
        "purchase": MessageLookupByLibrary.simpleMessage("ಖರೀದಿ"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage("ಖರೀದಿ ಎಚ್ಚರಿಕೆ"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("ಖರೀದಿ ದೃಢೀಕರಿಸಲಾಗಿದೆ"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("ಖರೀದಿ ವಿವರಗಳು"),
        "purchaseInvoice": MessageLookupByLibrary.simpleMessage("ಖರೀದಿ ರಶೀದಿ"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("ಖರೀದಿ ಪಟ್ಟಿ"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("ಈಗ ಖರೀದಿಸಿ"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("ಪ್ರೀಮಿಯಂ ಯೋಜನೆ ಖರೀದಿಸಿ"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("ಖರೀದಿ ಬೆಲೆ"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("ಖರೀದಿ ಬೆಲೆಯ ಅಗತ್ಯವಿದೆ"),
        "purchaseRepoet": MessageLookupByLibrary.simpleMessage("ಖರೀದಿ ವರದಿ"),
        "purchaseReports": MessageLookupByLibrary.simpleMessage("ಖರೀದಿ ವರದಿ"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("ಖರೀದಿ ವರದಿಗಳು"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("ಖರೀದಿ ಹಿಂತೆಗೆದುಕೊಳ್ಳಿ"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("ಖರೀದಿ ಹಿಂತೆಗೆದುಕೊಳ್ಳುವ ವರದಿ"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("ಖರೀದಿ ಪರಿವರ್ತನೆ"),
        "qty": MessageLookupByLibrary.simpleMessage("ಮೊತ್ತ"),
        "quantity": MessageLookupByLibrary.simpleMessage("ಪ್ರಮಾಣ"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("ಇತ್ತಿಹಾಸದ ಲೇಖನಗಳು"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("ಪಿನ್ ಪಡೆದಿದ್ದೇನೆ"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("ಸಂದರ್ಭ ಸಂಖ್ಯೆ"),
        "register": MessageLookupByLibrary.simpleMessage("ಹೊಸ ಖಾತೆ ತೆರೆಯಿರಿ"),
        "registering": MessageLookupByLibrary.simpleMessage("ನೋಂದಣಿ"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("ಉಳಿದ ಬಾಕಿ"),
        "remove": MessageLookupByLibrary.simpleMessage("ಅಳಿಸಿ"),
        "reports": MessageLookupByLibrary.simpleMessage("ವರದಿಗಳು"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("ಬಂದಾಯಿಸಿ ಕಳುಹಿಸಲಾಗಿದೆ"),
        "resendCode": MessageLookupByLibrary.simpleMessage("ಮರುಹೊಂದಿಸು ಕೋಡ್"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("ಮರುಹೊಂದಿಸು ಒಟಿಪಿ: "),
        "retailer": MessageLookupByLibrary.simpleMessage("ಖರೀದಿದಾರ"),
        "retur": MessageLookupByLibrary.simpleMessage("ರಿಟರ್ನ್"),
        "returN": MessageLookupByLibrary.simpleMessage("ಹಿಂತೆಗೆದುಕೊಳ್ಳಿ"),
        "returnAMount":
            MessageLookupByLibrary.simpleMessage("ಮೊತ್ತ ಹಿಂತಿರುಗಿಸಿ"),
        "returnAmount":
            MessageLookupByLibrary.simpleMessage("ಹಿಂತಿರುಗಿಸುವ ಮೊತ್ತ"),
        "returnQTY":
            MessageLookupByLibrary.simpleMessage("ಹಿಂತೆಗೆದುಕೊಳ್ಳುವ ಪ್ರಮಾಣ"),
        "revenue": MessageLookupByLibrary.simpleMessage("ಆದಾಯ"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "ನಿಮ್ಮ ವ್ಯಾಪಾರ ಡೇಟಾವನ್ನು ಸಲೀಸಾಗಿ ರಕ್ಷಿಸಿ. ನಮ್ಮ Pos Saas POS ಅನ್ ಲಿಮಿಟೆಡ್ ಅಪ್ ಗ್ರೇಡ್ ಉಚಿತ ಡೇಟಾ ಬ್ಯಾಕಪ್ ಅನ್ನು ಒಳಗೊಂಡಿರುತ್ತದೆ, ನಿಮ್ಮ ಅಮೂಲ್ಯವಾದ ಮಾಹಿತಿಯನ್ನು ಯಾವುದೇ ಅನಿರೀಕ್ಷಿತ ಘಟನೆಗಳಿಂದ ರಕ್ಷಿಸಲಾಗಿದೆ ಎಂದು ಖಚಿತಪಡಿಸುತ್ತದೆ. ನಿಜವಾಗಿಯೂ ಮುಖ್ಯವಾದುದನ್ನು ಕೇಂದ್ರೀಕರಿಸಿ - ನಿಮ್ಮ ವ್ಯಾಪಾರ ಬೆಳವಣಿಗೆ."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("ಮಾರಾಟದ ಮೊತ್ತ"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("ಮಾರಾಟ ವಿವರಗಳು"),
        "salePrice": MessageLookupByLibrary.simpleMessage("ಮಾರಾಟ ಬೆಲೆ"),
        "saleReports": MessageLookupByLibrary.simpleMessage("ಮಾರಾಟ ವರದಿ"),
        "saleReportss": MessageLookupByLibrary.simpleMessage("ಮಾರಾಟ ವರದಿಗಳು"),
        "saleReturn":
            MessageLookupByLibrary.simpleMessage("ಮಾರಾಟ ಹಿಂತೆಗೆದುಕೊಳ್ಳಿ"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("ಮಾರಾಟ ಹಿಂತೆಗೆದುಕೊಳ್ಳುವ ವರದಿ"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("ಮಾರಾಟ ಹೊಂದಿಕೆ"),
        "sales": MessageLookupByLibrary.simpleMessage("ಮಾರಾಟಗಳು"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("Sale & Purchase Reports"),
        "salesList": MessageLookupByLibrary.simpleMessage("ಮಾರಾಟ ಪಟ್ಟಿ"),
        "salesReturn":
            MessageLookupByLibrary.simpleMessage("ಮಾರಾಟ ಹಿಂತೆಗೆದುಕೊಳ್ಳಿ"),
        "save": MessageLookupByLibrary.simpleMessage("ಉಳಿಸಿ"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("ಉಳಿಸಿ ಮತ್ತು ಪ್ರಕಟಿಸಿ"),
        "saveChanges":
            MessageLookupByLibrary.simpleMessage("ಬದಲಾವಣೆಗಳನ್ನು ಉಳಿಸಿ"),
        "saving": MessageLookupByLibrary.simpleMessage("ಉಳಿಸುತ್ತಿದೆ"),
        "scanProductQRCode": MessageLookupByLibrary.simpleMessage(
            "ಉತ್ಪನ್ನ QR ಕೋಡ್ ಅನ್ನು స్కಾನ್ ಮಾಡಿ"),
        "search": MessageLookupByLibrary.simpleMessage("ಹುಡುಕಿ"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "ಉತ್ಪನ್ನ ಕೋಡ್ ಅಥವಾ ಹೆಸರಿನ ಮೂಲಕ ಹುಡುಕಿ"),
        "seeAllPromoCode": MessageLookupByLibrary.simpleMessage(
            "ಎಲ್ಲಾ ಪ್ರೊಮೊ ಕೋಡ್‌ಗಳನ್ನು ವೀಕ್ಷಿಸಿ"),
        "select": MessageLookupByLibrary.simpleMessage("ಆಯ್ಕೆಮಾಡಿ"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "ಹಿಂತೆಗೆದುಕೊಳ್ಳಲು ಉತ್ಪನ್ನವನ್ನು ಆಯ್ಕೆ ಮಾಡಿ"),
        "selectBrand":
            MessageLookupByLibrary.simpleMessage("ಬ್ರಾಂಡ್ ಆಯ್ಕೆ ಮಾಡಿ"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("ವರ್ಗವನ್ನು ಆಯ್ಕೆಮಾಡಿ"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("ಸಂಪರ್ಕಗಳನ್ನು ಆಯ್ಕೆಮಾಡಿ"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("ಉತ್ಪನ್ನ ವರ್ಗವನ್ನು ಆಯ್ಕೆಮಾಡಿ"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("ಅಂಗಡಿ ವರ್ಗವನ್ನು ಆಯ್ಕೆಮಾಡಿ"),
        "selectTax": MessageLookupByLibrary.simpleMessage("ತೆರಿಗೆ ಆಯ್ಕೆ ಮಾಡಿ"),
        "selectTaxType": MessageLookupByLibrary.simpleMessage(
            "ತೆರಿಗೆ ಪ್ರಕಾರವನ್ನು ಆಯ್ಕೆ ಮಾಡಿ"),
        "selectUnit":
            MessageLookupByLibrary.simpleMessage("ಒನ್ನವನ್ನು ಆಯ್ಕೆ ಮಾಡಿ"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("ವ್ಯತ್ಯಾಸಗಳನ್ನು ಆಯ್ಕೆಮಾಡಿ: "),
        "seller": MessageLookupByLibrary.simpleMessage("ಮರಳು"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("ಮಾರಾಟದ ಮೂಲಕ"),
        "send": MessageLookupByLibrary.simpleMessage("ಕಳುಹಿಸಿ"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("ಇಮೇಲ್ ಕಳುಹಿಸಿ"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("ಸಂದೇಶ ಕಳುಹಿಸಿ"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("ರೀಸೆಟ್ ಲಿಂಕ್ ಕಳುಹಿಸಿ"),
        "sendSms": MessageLookupByLibrary.simpleMessage("ಎಸ್ಎಂಎಸ್ ಕಳುಹಿಸಿ"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("SMS ಕಳುಹಿಸಬೇಕೆ?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("ವಾಟ್ಸಾಪ್ ಸಂದೇಶ ಕಳುಹಿಸಿ"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("ನಿಮ್ಮ ಇಮೇಲ್ ಕಳುಹಿಸಿ"),
        "sendingEmail":
            MessageLookupByLibrary.simpleMessage("ಇಮೇಲ್ ಕಳುಹಿಸುತ್ತಿದೆ"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("ಸಂದೇಶ ಕಳುಹಿಸುತ್ತಿದೆ"),
        "serviceShipping": MessageLookupByLibrary.simpleMessage("ಸೇವೆ/ನೌಕೆ"),
        "setUpYourProfile": MessageLookupByLibrary.simpleMessage(
            "ನಿಮ್ಮ ಪ್ರೊಫೈಲ್ ಸೆಟ್ ಅಪ್ ಮಾಡಿ"),
        "setting": MessageLookupByLibrary.simpleMessage("ಸೆಟ್ಟಿಂಗ್"),
        "share": MessageLookupByLibrary.simpleMessage("ಹಂಚಿಕೊಳ್ಳಿ"),
        "shopGST": MessageLookupByLibrary.simpleMessage("ಅಂಗಡಿ ಜಿಎಸ್‌ಟಿ"),
        "signIn": MessageLookupByLibrary.simpleMessage("ಸೈನ್ ಇನ್"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("ಇಮೇಲ್‌ನೊಂದಿಗೆ ಸೈನ್ ಇನ್ ಮಾಡಿ"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("ಗ್ರಾಹಕದ ಸಹಿ"),
        "size": MessageLookupByLibrary.simpleMessage("ಗಾತ್ರ"),
        "skip": MessageLookupByLibrary.simpleMessage("ವಿಳಂಬಿಸಿ"),
        "sms": MessageLookupByLibrary.simpleMessage("ಎಸ್ಎಂಎಸ್"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("ಸಾಮಾಜಿಕ ಮಾರುಕಟ್ಟೆ"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "ಕ್ಷಮಿಸಿ, ನೀವು ಈ ಸೇವೆ ಬಳಸಲು ಅನುಮತಿಯನ್ನು ಹೊಂದಿಲ್ಲ"),
        "startDate": MessageLookupByLibrary.simpleMessage("ಪ್ರಾರಂಭ ದಿನಾಂಕ"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("ಹೊಸ ಮಾರಾಟ ಪ್ರಾರಂಭಿಸಿ"),
        "startTypingToSearch":
            MessageLookupByLibrary.simpleMessage("ಹುಡುಕಲು ಟೈಪ್ ಮಾಡಿ"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "ಯಾವುದೇ ಹೆಚ್ಚುವರಿ ವೆಚ್ಚವಿಲ್ಲದೆ ತಾಂತ್ರಿಕ ಪ್ರಗತಿಯಲ್ಲಿ ಮುಂಚೂಣಿಯಲ್ಲಿರಿ. ನಮ್ಮ Pos Saas POS ಅನ್ ಲಿಮಿಟೆಡ್ ಅಪ್ ಗ್ರೇಡ್ ನಿಮ್ಮ ಬೆರಳ ತುದಿಯಲ್ಲಿ ನೀವು ಯಾವಾಗಲೂ ಇತ್ತೀಚಿನ ಪರಿಕರಗಳು ಮತ್ತು ವೈಶಿಷ್ಟ್ಯಗಳನ್ನು ಹೊಂದಿರುವುದನ್ನು ಖಚಿತಪಡಿಸುತ್ತದೆ, ನಿಮ್ಮ ವ್ಯಾಪಾರವು ಅತ್ಯಾಧುನಿಕವಾಗಿ ಉಳಿಯುತ್ತದೆ ಎಂದು ಖಾತರಿಪಡಿಸುತ್ತದೆ."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("ಇನ್ನೂ ಪಾವತಿಸಿಲ್ಲ"),
        "stock": MessageLookupByLibrary.simpleMessage("ಸ್ಟಾಕ್"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("ಸ್ಟಾಕ್ ಅಗತ್ಯವಿದೆ"),
        "stockList": MessageLookupByLibrary.simpleMessage("ಸ್ಟಾಕ್ ಪಟ್ಟಿ"),
        "stocks": MessageLookupByLibrary.simpleMessage("ಸ್ಟಾಕ್ಸ್"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "ಎಕ್ಸೆಲ್ ಫೈಲ್ ಅನ್ನು ಸೃಷ್ಟಿಸಲು ಸಂಗ್ರಹ ಅನುಮತಿ ಅಗತ್ಯವಿದೆ"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("ಉಪ ತೆರಿಗೆಗಳ ಪಟ್ಟಿ"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("ಉಪ ತೆರಿಗೆಗಳು"),
        "subTotal": MessageLookupByLibrary.simpleMessage("ಉಪಮೊತ್ತ"),
        "submit": MessageLookupByLibrary.simpleMessage("ಸಲ್ಲಿಸಿ"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "ನಮ್ಮ ಯುಟ್ಯೂಬ್ನಲ್ಲಿ ಚಂದಾದಾರರಾಗಿ"),
        "subscription": MessageLookupByLibrary.simpleMessage("ಚಂದಾದಾರಿ"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("ಸಫಲವಾಗಿ ಮಾಡಲಾಗಿದೆ"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("ಸಫಲವಾಗಿ ಲಾಗ್ ಔಟ್"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("ಶುಭವಾಗಿ ನವೀಕರಿಸಲಾಗಿದೆ"),
        "supplier": MessageLookupByLibrary.simpleMessage("ಸರಬರಾಜು"),
        "supplierName": MessageLookupByLibrary.simpleMessage("ಸಪ್ಲೈಯರ್ ಹೆಸರು"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("ಸ್ವಿಫ್ಟ್ ಕೋಡ್"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "ಡ್ರೈವರ್ಸ್ ಲೈಸೆನ್ಸ್, ರಾಷ್ಟ್ರೀಯ ಗುರುತು ಪತ್ರವನ್ನು ಅಥವಾ ಪಾಸ್ಪೋರ್ಟ್ ಫೋಟೊವನ್ನು ತೆಗೆದುಕೊಳ್ಳಿ"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "ನಿಮ್ಮ ಮಾಹಿತಿಯನ್ನು ಪರಿಶೀಲಿಸಲು ಒಂದು ಗುರುತಿನ ಕಾರ್ಡ್ ತೆಗೆದುಕೊಳ್ಳಿ"),
        "tap": MessageLookupByLibrary.simpleMessage("ಟಾಪ್"),
        "tax": MessageLookupByLibrary.simpleMessage("ತೆರಿಗೆ"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("ಮಾಡಿಕೋಟ್ ಗುಂಪು"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("ತೆರಿಗೆ ಶೇ."),
        "taxRate": MessageLookupByLibrary.simpleMessage("ಮಾಡಿಕೋಟ್ಟು ದರ"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "ಮಾಡಿಕೋಟ್ಟು ದರಗಳು - ನಿಮ್ಮ ಮಾಡುವಿಕೋಟ್ಟು ದರಗಳನ್ನು ನಿರ್ವಹಿಸಿ"),
        "taxReport": MessageLookupByLibrary.simpleMessage("ಮಾಡಿಕೋಟ್ ವರದಿ"),
        "taxType": MessageLookupByLibrary.simpleMessage("ತೆರಿಗೆ ಪ್ರಕಾರ"),
        "taxes": MessageLookupByLibrary.simpleMessage("ಕರಗಳು"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("ನಿಬಂಧನೆಗಳು ಮತ್ತು ಷರತ್ತುಗಳು"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("ಬಳಕೆಯ ನಿಯಮಗಳು"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("ನಿಯಮಗಳು ಮತ್ತು ಗೌಪ್ಯತೆ"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "ನಿಮ್ಮ ಬಾಕಿ ಪಾವತಿಗೆ ಧನ್ಯವಾದಗಳು"),
        "thankYou": MessageLookupByLibrary.simpleMessage("ಧನ್ಯವಾದಗಳು"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("ನಿಮ್ಮ ಖರೀದಿಗೆ ಧನ್ಯವಾದಗಳು"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "ಆ ಇಮೇಲ್‌ಗಾಗಿ ಖಾತೆ ಈಗಾಗಲೇ ಇದೆ"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "ಎಕ್ಸೆಲ್ ಫೈಲ್ ಈಗಾಗಲೇ ಡೌನ್‌ಲೋಡ್ ಮಾಡಲಾಗಿದೆ"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "ಹೆಸರು ಎಲ್ಲವನ್ನೂ ಹೇಳುತ್ತದೆ. Pos Saas POS ಅನ್ಲಿಮಿಟೆಡ್ ನೊಂದಿಗೆ, ನಿಮ್ಮ ಬಳಕೆಯ ಮೇಲೆ ಯಾವುದೇ ಮಿತಿಯಿಲ್ಲ. ನೀವು ಬೆರಳೆಣಿಕೆಯಷ್ಟು ವಹಿವಾಟುಗಳನ್ನು ಪ್ರಕ್ರಿಯೆಗೊಳಿಸುತ್ತಿರಲಿ ಅಥವಾ ಗ್ರಾಹಕರ ವಿಪರೀತವನ್ನು ಅನುಭವಿಸುತ್ತಿರಲಿ, ನೀವು ಮಿತಿಗಳಿಂದ ನಿರ್ಬಂಧಿತರಾಗಿಲ್ಲ ಎಂದು ತಿಳಿದುಕೊಂಡು ನೀವು ಆತ್ಮವಿಶ್ವಾಸದಿಂದ ಕಾರ್ಯನಿರ್ವಹಿಸಬಹುದು"),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "ನೀಡುವ ಗುಪ್ತಪದವು ತುಂಬಾ ಬಲಹೀನವಾಗಿದೆ"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "ಈ ಮಾರಾಟವನ್ನು ಅಳಿಸಲಾಗುವುದು ಮತ್ತು ಈ ಖರೀದಿಯಲ್ಲಿನ ಎಲ್ಲಾ ಡೇಟಾ ಅಳಿಸಲಾಗುತ್ತದೆ. ನೀವು ಇದನ್ನು ಅಳಿಸಲು ಖಚಿತವಾಗಿದ್ದೀರಾ?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "ಈ ಮಾರಾಟವನ್ನು ಅಳಿಸಲಾಗುವುದು ಮತ್ತು ಈ ಮಾರಾಟದ ಎಲ್ಲ ಡೇಟಾ ಅಳಿಸಲಾಗುತ್ತದೆ. ನೀವು ಇದನ್ನು ಅಳಿಸಲು ಖಚಿತವಾಗಿದ್ದೀರಾ?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "ಬಳಕೆದಾರನನ್ನು ಅಳಿಸಲಾಗುತ್ತದೆ ಮತ್ತು ನಿಮ್ಮ ಖಾತೆಯಿಂದ ಎಲ್ಲಾ ಡೇಟಾ ಅಳಿಸಲಾಗುತ್ತದೆ. ಖಚಿತವಾಗಿ ಅಳಿಸಲು ಖಚಿತರಾಗಿದ್ದೀರಾ?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "ಬಳಕೆದಾರ ಅಳಿಸಲಾಗುತ್ತದೆ ಮತ್ತು ನಿಮ್ಮ ಖಾತೆಯಿಂದ ಎಲ್ಲಾ ಡೇಟಾ ಅಳಿಸಲಾಗುತ್ತದೆ. ನೀವು ಇದನ್ನು ಅಳಿಸಲು ಖಚಿತವಾಗಿದ್ದೀರಾ?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Third-Party Services"),
        "thisCategoryCannotBeDeleted":
            MessageLookupByLibrary.simpleMessage("ಈ ವರ್ಗವನ್ನು ಅಳಿಸಲಾಗುವುದಿಲ್ಲ"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(ಈ ತಿಂಗಳು)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "ಈ ಉತ್ಪನ್ನವನ್ನು ಹಿಂದೆಯೇ ಸೇರಿಸಲಾಗಿದೆ"),
        "title": MessageLookupByLibrary.simpleMessage("ಶೀರ್ಷಿಕೆ"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("ಶೀರ್ಷಿಕೆಯು ಖಾಲಿ ಇರಬಾರದು"),
        "to": MessageLookupByLibrary.simpleMessage("ಗೆ"),
        "toDate": MessageLookupByLibrary.simpleMessage("ದಿನಾಂಕಕ್ಕೆ"),
        "today": MessageLookupByLibrary.simpleMessage("ಇಂದು"),
        "total": MessageLookupByLibrary.simpleMessage("ಒಟ್ಟು"),
        "totalAmount":
            MessageLookupByLibrary.simpleMessage("ಮೊತ್ತ ಹೆಚ್ಚಿಕೊಳ್ಳಿ"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("ಒಟ್ಟು ಸಂಗ್ರಹಿತ"),
        "totalDue": MessageLookupByLibrary.simpleMessage("ಒಟ್ಟು ಬಾಕಿ"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("ಒಟ್ಟು ವೆಚ್ಚ"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("ಒಟ್ಟು ನಷ್ಟ"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("ಒಟ್ಟು ಪಾವತಿಯಾಗಬೇಕಾದ ಮೊತ್ತ"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("ಒಟ್ಟು ಬೆಲೆ"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("ಒಟ್ಟು ಉತ್ಪನ್ನಗಳು"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("ಒಟ್ಟು ಲಾಭ"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("ಒಟ್ಟು ಖರೀದಿ"),
        "totalReturnAmount": MessageLookupByLibrary.simpleMessage(
            "ಒಟ್ಟು ಹಿಂತೆಗೆದುಕೊಳ್ಳುವ ಮೊತ್ತ"),
        "totalReturns":
            MessageLookupByLibrary.simpleMessage("ಒಟ್ಟು ಹಿಂತೆಗೆದುಕೊಳ್ಳುವಿಕೆ"),
        "totalSale": MessageLookupByLibrary.simpleMessage("ಒಟ್ಟು ಮಾರಾಟ"),
        "totalStock": MessageLookupByLibrary.simpleMessage("ಒಟ್ಟು ಸ್ಟಾಕ್ಗಳು"),
        "totalValue": MessageLookupByLibrary.simpleMessage("ಒಟ್ಟು ಮೌಲ್ಯ"),
        "totalVat": MessageLookupByLibrary.simpleMessage("ಒಟ್ಟು ವ್ಯಾಟ್"),
        "totals": MessageLookupByLibrary.simpleMessage("ಒಟ್ಟು: "),
        "transaction": MessageLookupByLibrary.simpleMessage("ಲೆಕ್ಕಾಚಾರ"),
        "transactionId":
            MessageLookupByLibrary.simpleMessage("ಟ್ರಾನ್ಸಕ್ಷನ್ ಐಡಿ"),
        "tryAgain":
            MessageLookupByLibrary.simpleMessage("ಮತ್ತೊಮ್ಮೆ ಪ್ರಯತ್ನಿಸಿ"),
        "twitter": MessageLookupByLibrary.simpleMessage("ಟ್ವಿಟರ್"),
        "type": MessageLookupByLibrary.simpleMessage("ಪ್ರಕಾರ"),
        "unitName": MessageLookupByLibrary.simpleMessage("ಯೂನಿಟ್ ಹೆಸರು"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("ಯೂನಿಟ್ ಬೆಲೆ"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("ಒಟ್ಟು ಬೆಲೆ"),
        "units": MessageLookupByLibrary.simpleMessage("ಯೂನಿಟ್ಗಳು"),
        "unlimited": MessageLookupByLibrary.simpleMessage("ಅನಂತ"),
        "unlimitedUsage": MessageLookupByLibrary.simpleMessage("ಅಮಿತ ಬಳಕೆ"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "ನಮ್ಮ ಪರಿಣಿತ ತಂಡದ ನೇತೃತ್ವದ ವೈಯಕ್ತಿಕಗೊಳಿಸಿದ ತರಬೇತಿ ಅವಧಿಗಳೊಂದಿಗೆ Pos Saas POS ನ ಸಂಪೂರ್ಣ ಸಾಮರ್ಥ್ಯವನ್ನು ಅನ್ಲಾಕ್ ಮಾಡಿ. ಮೂಲಭೂತದಿಂದ ಸುಧಾರಿತ ತಂತ್ರಗಳವರೆಗೆ, ನಿಮ್ಮ ವ್ಯಾಪಾರ ಪ್ರಕ್ರಿಯೆಗಳನ್ನು ಅತ್ಯುತ್ತಮವಾಗಿಸಲು ಸಿಸ್ಟಮ್ ನ ಪ್ರತಿಯೊಂದು ಅಂಶವನ್ನು ಬಳಸಿಕೊಳ್ಳುವಲ್ಲಿ ನೀವು ಚೆನ್ನಾಗಿ ಪರಿಣತರಾಗಿರುವಿರಿ ಎಂದು ನಾವು ಖಚಿತಪಡಿಸುತ್ತೇವೆ."),
        "unpaid": MessageLookupByLibrary.simpleMessage("ಪಾವತಿ ಮಾಡದ"),
        "update": MessageLookupByLibrary.simpleMessage("ನವೀಕರಿಸಿ"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("ಸಂಪರ್ಕವನ್ನು ನವೀಕರಿಸಿ"),
        "updateNow": MessageLookupByLibrary.simpleMessage("ಈಗ ಅಪ್ಡೇಟ್ ಮಾಡಿ"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("ಉತ್ಪನ್ನವನ್ನು ಅಪ್ಡೇಟ್ ಮಾಡಿ"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "ನಿಮ್ಮ ಯೋಜನೆಯನ್ನು ಮೊದಲು ನವೀಕರಿಸಿ, ನಿಮ್ಮ ಮಿತಿಯು ಮುಗಿದಿದೆ"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("ನಿಮ್ಮ ಪ್ರೊಫೈಲ್ ಅಪ್ಡೇಟ್ ಮಾಡಿ"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "ನಿಮ್ಮ ಡಾಕ್ಟರ್ ಗೆ ಉತ್ತಮ ಪ್ರತಿನಿಧಿಯಾಗಿ ನಿಮ್ಮ ಪ್ರೊಫೈಲ್ ಅನ್ನು ನವೀಕರಿಸಿ"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "ನಿಮ್ಮ ಪ್ರೊಫೈಲ್ ಅಪ್ಡೇಟ್ ಮಾಡಿ, ನಿಮ್ಮ ಗ್ರಾಹಕರನ್ನು ಉತ್ತಮ ಪ್ರಭಾವದಿಂದ ಸಂಪರ್ಕಿಸಲು"),
        "updated": MessageLookupByLibrary.simpleMessage("ನವೀಕರಿಸಲಾಗಿದೆ"),
        "upload": MessageLookupByLibrary.simpleMessage("ಅಪ್ಲೋಡ್"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("ದಾಖಲೆ ಅಪ್ಲೋಡ್ ಮಾಡಿ"),
        "uploadDone":
            MessageLookupByLibrary.simpleMessage("ಅಪ್ಲೋಡ್ ಹಂಚಿಸಲಾಗಿದೆ"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("ಫೈಲ್ ಅಪ್ಲೋಡ್ ಮಾಡಿ"),
        "upplier": MessageLookupByLibrary.simpleMessage("ಸರಬರಾಜು"),
        "usbC": MessageLookupByLibrary.simpleMessage("ಯುಎಸ್‌ಬಿ ಸಿ"),
        "use": MessageLookupByLibrary.simpleMessage("ಬಳಸಿ"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("ಪೋಸ್ ಸಾಸ್ ಬಳಸಿ"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Use of the system"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("ಬಳಕೆದಾರನು ಅಳಿಸಲಾಗಿದೆ"),
        "userRole": MessageLookupByLibrary.simpleMessage("ಬಳಕೆದಾರ ಪಾತ್ರ"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("ಬಳಕೆದಾರ ಪಾತ್ರ ವಿವರಗಳು"),
        "userTitle": MessageLookupByLibrary.simpleMessage("ಬಳಕೆದಾರ ಶೀರ್ಷಿಕೆ"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "ಬಳಕೆದಾರ ಶೀರ್ಷಿಕೆ ಖಾಲಿ ಇರಬಾರದು"),
        "value": MessageLookupByLibrary.simpleMessage("ಮೌಲ್ಯ"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("ವಾಟ್ ಅನ್ವಯಿಸುವುದಿಲ್ಲ"),
        "verifyOtp":
            MessageLookupByLibrary.simpleMessage("ಒಟಿಪಿ ಪರಿಶೀಲಿಸಲಾಗುತ್ತಿದೆ"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("ಫೋನ್ ಸಂಖ್ಯೆಯನ್ನು ಪರಿಶೀಲಿಸಿ"),
        "viewAll": MessageLookupByLibrary.simpleMessage("ಎಲ್ಲವನ್ನು ವೀಕ್ಷಿಸಿ"),
        "viewDetails":
            MessageLookupByLibrary.simpleMessage("ವಿವರಗಳನ್ನು ವೀಕ್ಷಿಸಿ"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("ನಡೆದು ಬರುವ ಗ್ರಾಹಕ"),
        "warehouse": MessageLookupByLibrary.simpleMessage("ಗೋದಾಮು"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("ಗೋದಾಮು ಈಗಾಗಲೇ ಇದೆ"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("ಗೋದಾಮುಗಳ ಪಟ್ಟಿ"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("ಗೋದಾಮಿನ ಹೆಸರು"),
        "warranty": MessageLookupByLibrary.simpleMessage("ವಾರಂಟಿ"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "ನಿರ್ದೇಶನೆಗಳೊಂದಿಗೆ ಇಮೇಲ್ ಕಳುಹಿಸಲಾಗಿದೆ. ಹೊಸ ಪಾಸ್ವರ್ಡ್ ಹೊಂದಿಸಲು:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "We may use third-party services to support our app\'s functionality, such as analytics providers and payment processors. These third-party services may collect information about you when you use our app. Please note that we are not responsible for the privacy practices of these third-party services."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "We take industry-standard measures to protect your personal information, including encryption and secure storage. We also limit access to your information to authorized personnel only."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "ತಡೆರಹಿತ ಕಾರ್ಯಾಚರಣೆಗಳ ಪ್ರಾಮುಖ್ಯತೆಯನ್ನು ನಾವು ಅರ್ಥಮಾಡಿಕೊಂಡಿದ್ದೇವೆ. ಅದಕ್ಕಾಗಿಯೇ ತ್ವರಿತ ಪ್ರಶ್ನೆಯಾಗಿರಲಿ ಅಥವಾ ಸಮಗ್ರ ಕಾಳಜಿಯಾಗಿರಲಿ ನಿಮಗೆ ಸಹಾಯ ಮಾಡಲು ನಮ್ಮ ರೌಂಡ್-ದಿ-ಕ್ಲಾಕ್ ಬೆಂಬಲ ಲಭ್ಯವಿದೆ. ಅಪ್ರತಿಮ ಗ್ರಾಹಕ ಸೇವೆಯನ್ನು ಅನುಭವಿಸಲು ಯಾವುದೇ ಸಮಯದಲ್ಲಿ, ಎಲ್ಲಿಯಾದರೂ ಕರೆ ಅಥವಾ WhatsApp ಮೂಲಕ ನಮ್ಮೊಂದಿಗೆ ಸಂಪರ್ಕ ಸಾಧಿಸಿ."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "We use your personal information to provide you with the best possible experience on our app, including to personalize your content recomme ndations, connect you with experts, and improve our apps functionality. We may also use your information to communicate with you about updates, promotions, or other information related to our app."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "ನಾವು ಪಾವತಿಯನ್ನು ಪರಿಶೀಲಿಸುತ್ತೇವೆ ಮತ್ತು ಈಡೇರಿಸುತ್ತೇವೆ 1-2 ಗಂಟೆಗಳ ಒಳಗಾಗಿ"),
        "weekly": MessageLookupByLibrary.simpleMessage("ವಾರಿಕ"),
        "weight": MessageLookupByLibrary.simpleMessage("ತೂಕ"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("ಹೊಸದು ಏನು"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("ಹೊಲಸೇಲ್ ವಿಕ್ರೇತಾ"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("ಮೊತ್ತವಿಕ್ರಯ ಬೆಲೆ"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("ಹೋಲ್ಸೇಲ್ ಬೆಲೆ"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("ಹೋಲ್ಸೇಲರ್"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("ನಂತರ ಸೇರಿಸಲಾಗುತ್ತದೆ"),
        "willExpireAt":
            MessageLookupByLibrary.simpleMessage("ಅತ್ಯುತ್ತೀರ್ಣವಾಗಲಿದೆ"),
        "writeYourMessageHere": MessageLookupByLibrary.simpleMessage(
            "ನಿಮ್ಮ ಸಂದೇಶವನ್ನು ಇಲ್ಲಿ ಬರೆಯಿರಿ"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("ತಪ್ಪಾದ ಓಟಿಪಿ"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "ಆ ಬಳಕೆದಾರನಿಗೆ ತಪ್ಪಾದ ಪಾಸ್ವರ್ಡ್ ನೀಡಲಾಗಿದೆ."),
        "yearly": MessageLookupByLibrary.simpleMessage("ವಾರ್ಷಿಕ"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("ಹೌದು, ಶಾಶ್ವತವಾಗಿ ಅಳಿಸಿ"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("ನೀವು ಮಾನ್ಯ ಬಳಕೆದಾರ ಅಲ್ಲ"),
        "youAreUsing":
            MessageLookupByLibrary.simpleMessage("ನೀವು ಬಳಸುತ್ತಿದ್ದೀರಿ"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "ನೀವು ಬಾಕಿ ಇರುವಕ್ಕಿಂತ ಹೆಚ್ಚು ಪಾವತಿಸಬೇಕಾಗಿಲ್ಲ"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("ನೀವು ಇಮೇಲ್ ಪಡೆದಿದ್ದೀರಿ"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "ನೀವು ಯಶಸ್ವಿಯಾಗಿ ನಿಮ್ಮ ಖಾತೆಗೆ ಲಾಗಿನ್ ಆಗಿದ್ದೀರಿ. ಸ್ಮಾರ್ಟ್ ಬಿಯಾಶಾರ ನೊಂದಿಗೆ ಇರಿ."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("ನೀವು ಅನುಮತಿ ನೀಡಬೇಕಾಗಿದೆ"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "ನೀವು ನಿಮ್ಮ ಖಾತೆಗೆ ಮರುಪ್ರವೇಶಿಸಬೇಕಾಗಿದೆ."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "ಖರೀದಿಯ ಮೊದಲು ನೀವು ಗುರುತು ಪರಿಶೀಲಿಸಬೇಕಾಗಿದೆ"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("ನಿಮ್ಮ ಸಂದೇಶ ಉಳಿಯುತ್ತದೆ"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("ನಿಮ್ಮ ಪ್ಯಾಕೇಜ್"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "ನಿಮ್ಮ ಪ್ಯಾಕೇಜ್ 5 ದಿನಗಳಲ್ಲಿ ಕೊನೆಗೊಳ್ಳುತ್ತದೆ")
      };
}
