// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a tr locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'tr';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Devam Et"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("GST Numarası"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired": MessageLookupByLibrary.simpleMessage("MRP gereklidir"),
        "OK": MessageLookupByLibrary.simpleMessage("Tamam"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Tel. No"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT Kodu"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Atıştırmalıklar"),
        "TAX": MessageLookupByLibrary.simpleMessage("VERGİ"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Yükleniyor"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("Kullanıcı Ünvanı"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Paketiniz Bugün Sona Erecek\n\nLütfen Tekrar Satın Alın"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) Sistem, işletmenizde satış işlemlerini ve ilgili faaliyetleri kolaylaştırmak amacıyla sunulmaktadır."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) Sistemi kullanmak için bir hesap oluşturmanız gerekebilir. Kayıt süreci sırasında doğru, güncel ve eksiksiz bilgileri sağlama ve bu bilgileri güncel tutma konusunda anlaşırsınız."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("Uygulama Hakkında"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Hakkımızda"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Şartların Kabulü"),
        "accountName": MessageLookupByLibrary.simpleMessage("Hesap Adı"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("Hesap Numarası"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Hesap Kaydı"),
        "acton": MessageLookupByLibrary.simpleMessage("Eylem"),
        "add": MessageLookupByLibrary.simpleMessage("Ekle"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Marka Ekle"),
        "addCategory": MessageLookupByLibrary.simpleMessage("Kategori Ekle"),
        "addContact": MessageLookupByLibrary.simpleMessage("Kişi Ekle"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Müşteri Ekle"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("Teslimat Ekle"),
        "addDescriptioN": MessageLookupByLibrary.simpleMessage("Açıklama ekle"),
        "addDescription": MessageLookupByLibrary.simpleMessage("Not Ekle"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("İndirim Ekle"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Belge Kimliği Ekle"),
        "addDucument": MessageLookupByLibrary.simpleMessage("Belge Ekle"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Gider Ekle"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Gider Kategorisi Ekle"),
        "addItems": MessageLookupByLibrary.simpleMessage("Ürünleri Ekle"),
        "addNew": MessageLookupByLibrary.simpleMessage("Yeni ekle"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Yeni Adres Ekle"),
        "addNewProduct": MessageLookupByLibrary.simpleMessage("Yeni Ürün Ekle"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("Yeni Vergi Ekle"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Tek/Çoklu Vergi Türü ile Yeni Vergi Ekle"),
        "addNote": MessageLookupByLibrary.simpleMessage("Not Ekle"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Önce ürün ekleyin"),
        "addPromoCode": MessageLookupByLibrary.simpleMessage("Promo Kodu Ekle"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Satın Alma Ekle"),
        "addSales": MessageLookupByLibrary.simpleMessage("Satış Ekle"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Başarıyla Eklendi"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Birim Ekle"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Kullanıcı Rolü Ekle"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Başarıyla eklendi"),
        "addedToCart": MessageLookupByLibrary.simpleMessage("Sepete Eklendi"),
        "address": MessageLookupByLibrary.simpleMessage("Adres"),
        "admin": MessageLookupByLibrary.simpleMessage("Yönetici"),
        "all": MessageLookupByLibrary.simpleMessage("Hepsi"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("Tüm İş Çözümleri"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("Zaten Eklendi"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Zaten Var"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Zaten bir hesabınız var mı?"),
        "amount": MessageLookupByLibrary.simpleMessage("Miktar"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "Bir e-posta gönderildi.\\nGelen kutunuzu kontrol edin"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Android ve iOS Uygulama Desteği"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Uygulanabilir Vergi"),
        "apply": MessageLookupByLibrary.simpleMessage("Uygula"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Bu faturayı silmek istediğinizden emin misiniz?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Bu satışı silmek istediğinizden emin misiniz?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Bu kullanıcıyı silmek istediğinizden emin misiniz?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Bu vergiyi silmek istediğinizden emin misiniz?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Bu vergi grubunu silmek istediğinizden emin misiniz?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Bu depoyu silmek istiyor musunuz?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Bu kullanıcıyı silmek istediğinizden emin misiniz?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Yetkili İmza"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Hesabınızın ve şifrenizin gizliliğini korumak ve hesabınıza erişimi sınırlamak sizin sorumluluğunuzdadır. Hesabınız altında gerçekleşen tüm faaliyetlerden sorumlu olduğunuzu kabul edersiniz."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Sistemi kullanmak için en az 18 yaşında veya bulunduğunuz yargı alanında çoğunluk yaşında olmanız gerekmektedir."),
        "backSide": MessageLookupByLibrary.simpleMessage("Arka Yüz"),
        "backToHome": MessageLookupByLibrary.simpleMessage("Ana Sayfaya Dön"),
        "balance": MessageLookupByLibrary.simpleMessage("Bakiye"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladeş"),
        "bank": MessageLookupByLibrary.simpleMessage("Banka"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Banka Hesabı Para Birimi"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Banka Hesap Para Birimi"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Banka Bilgileri"),
        "bankName": MessageLookupByLibrary.simpleMessage("Banka Adı"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("Banka Transferi"),
        "barcodeFound": MessageLookupByLibrary.simpleMessage("Barkod bulundu"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Fatura/İşlem"),
        "billTo": MessageLookupByLibrary.simpleMessage("Fatura Adresi"),
        "branchName": MessageLookupByLibrary.simpleMessage("Şube Adı"),
        "brand": MessageLookupByLibrary.simpleMessage("Marka"),
        "brandName": MessageLookupByLibrary.simpleMessage("Marka Adı"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("Toplu\nYükleme"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("İş Kategorisi"),
        "buy": MessageLookupByLibrary.simpleMessage("Satın Al"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Premium Plan Satın Al"),
        "buySms": MessageLookupByLibrary.simpleMessage("SMS Satın Al"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Point of Sale (POS) Sistemi (\"Sistem\")\'ne [Kurum Adınız] (\"Şirket\") tarafından sağlanan erişerek veya kullanarak, bu Kullanım Şartları ile bağlı olmayı kabul edersiniz. Bu Kullanım Şartları\'na katılmıyorsanız, lütfen Sistemi kullanmayın."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Sisteme erişiminiz ve kullanımınızın ilgili yasalara ve düzenlemelere uygun olduğundan emin olmak sizin sorumluluğunuzdadır."),
        "cacel": MessageLookupByLibrary.simpleMessage("İptal"),
        "call": MessageLookupByLibrary.simpleMessage("Ara"),
        "callForEmergencySupport":
            MessageLookupByLibrary.simpleMessage("Acil Destek İçin Ara"),
        "camera": MessageLookupByLibrary.simpleMessage("Kamera"),
        "cancel": MessageLookupByLibrary.simpleMessage("İptal"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Tüm Ürünleri İptal Et"),
        "capacity": MessageLookupByLibrary.simpleMessage("Kapasite"),
        "card": MessageLookupByLibrary.simpleMessage("Kart"),
        "cash": MessageLookupByLibrary.simpleMessage("Nakit"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Nakit Ücretsiz"),
        "categories": MessageLookupByLibrary.simpleMessage("Kategoriler"),
        "category": MessageLookupByLibrary.simpleMessage("Kategori"),
        "categoryName": MessageLookupByLibrary.simpleMessage("Kategori adı"),
        "categoryNameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Kategori adı zaten mevcut"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("Kategori Adı"),
        "change": MessageLookupByLibrary.simpleMessage("Değiştir?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Şifre Değiştir"),
        "checkEmail":
            MessageLookupByLibrary.simpleMessage("E-Postayı Kontrol Et"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Bir Müşteri Seçin"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Bir Tedarikçi Seçin"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Özelliklerinizi Seçin"),
        "clarence": MessageLookupByLibrary.simpleMessage("Clarence"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Bağlanmak için tıklayın"),
        "close": MessageLookupByLibrary.simpleMessage("Kapat"),
        "color": MessageLookupByLibrary.simpleMessage("Renk"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(Birden fazla verginin kombinasyonu)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Yakında"),
        "companyAddress": MessageLookupByLibrary.simpleMessage("Şirket Adresi"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Şirket ve Mağaza Adı"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("Şirket ve İş Adı"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("İşlemi Tamamla"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Şifreyi Onayla"),
        "confirmReturn": MessageLookupByLibrary.simpleMessage("İade onayla"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Tebrikler"),
        "contactUs":
            MessageLookupByLibrary.simpleMessage("Bizimle İletişime Geçin"),
        "continu": MessageLookupByLibrary.simpleMessage("Devam Et"),
        "country": MessageLookupByLibrary.simpleMessage("Ülke"),
        "create": MessageLookupByLibrary.simpleMessage("Oluştur"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Ücretsiz Bir Hesap Oluştur"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Oluşturuldu ve Kaydedildi"),
        "currency": MessageLookupByLibrary.simpleMessage("Para Birimi"),
        "currentStock": MessageLookupByLibrary.simpleMessage("Mevcut Stok"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("Özel Fatura Markalama"),
        "customer": MessageLookupByLibrary.simpleMessage("Müşteri"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Müşteri Detayları"),
        "customerGST": MessageLookupByLibrary.simpleMessage("Müşteri GST"),
        "customerName": MessageLookupByLibrary.simpleMessage("Müşteri Adı"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Günlük İşlem"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Panel Genel Bakış"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Veri Başarıyla Kaydedildi"),
        "date": MessageLookupByLibrary.simpleMessage("Tarih"),
        "day": MessageLookupByLibrary.simpleMessage("Gün"),
        "dealer": MessageLookupByLibrary.simpleMessage("Bayi"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("Bayi Fiyatı"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("Varsayılan KDV Yüzdesi"),
        "delete": MessageLookupByLibrary.simpleMessage("Sil"),
        "deleting": MessageLookupByLibrary.simpleMessage("Siliniyor"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Teslimat Adresi"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Teslimat Adresleri"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Teslimat Ücreti"),
        "describtion": MessageLookupByLibrary.simpleMessage("Açıklama"),
        "description": MessageLookupByLibrary.simpleMessage("Açıklama"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Açıklama boş olamaz"),
        "details": MessageLookupByLibrary.simpleMessage("Detaylar"),
        "discount": MessageLookupByLibrary.simpleMessage("İndirim"),
        "doNotDistrub":
            MessageLookupByLibrary.simpleMessage("Rahatsız Etmeyin"),
        "done": MessageLookupByLibrary.simpleMessage("Tamamlandı"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Excel Formatını İndir"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "İndirme klasörüne başarıyla indirildi"),
        "due": MessageLookupByLibrary.simpleMessage("Vade"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Vade Miktarı: "),
        "dueCollection": MessageLookupByLibrary.simpleMessage("Vade Toplama"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("Tahsilat Raporları"),
        "dueList": MessageLookupByLibrary.simpleMessage("Vade Listesi"),
        "dueReports": MessageLookupByLibrary.simpleMessage("Borç Raporu"),
        "duration": MessageLookupByLibrary.simpleMessage("Süre"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Süre: Den"),
        "easyToUseMobilePos":
            MessageLookupByLibrary.simpleMessage("Kullanımı Kolay Mobil POS"),
        "edit": MessageLookupByLibrary.simpleMessage("Düzenle"),
        "editPurchaseInvoice": MessageLookupByLibrary.simpleMessage(
            "Satın Alma Faturasını Düzenle"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Satış Faturasını Düzenle"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Sosyal Medyayı Düzenle"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Başarıyla düzenlendi"),
        "editTax": MessageLookupByLibrary.simpleMessage("Vergiyi düzenle"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Vergi grubunu düzenle"),
        "editWarehouse": MessageLookupByLibrary.simpleMessage("Depoyu düzenle"),
        "email": MessageLookupByLibrary.simpleMessage("E-Posta"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("E-Posta Adresi"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("E-posta boş olamaz"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "E-posta Gönderildi! Gelen Kutunuzu Kontrol Edin"),
        "endDate": MessageLookupByLibrary.simpleMessage("Bitiş Tarihi"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Geçerli Bir Miktar Girin"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Geçerli bir İndirim Girin"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Geçerli bir telefon numarası girin"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Geçerli bir fiyat girin"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("Geçerli bir miktar girin"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("Adresi Girin"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("Miktarı Girin"),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Marka Adını Girin"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Kapasiteyi Girin"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Kategori Adını Girin"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Rengi Girin"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "Müşteri GST numarasını girin"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Bayi Fiyatını Girin"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Açıklamayı Girin"),
        "enterDiscount": MessageLookupByLibrary.simpleMessage("İndirim Girin"),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Gider Tarihini Girin"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Tam Adresi Girin"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Fatura Numarasını Girin"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Düşük Stok Uyarı Miktarını Girin"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Üreticiyi Girin"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("Mesaj İçeriğini Girin"),
        "enterMrpOrRetailerPirce":
            MessageLookupByLibrary.simpleMessage("MRP/Ticaret Fiyatını Girin"),
        "enterName": MessageLookupByLibrary.simpleMessage("Adı Girin"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Not Girin"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Parti Adını Girin"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Telefon Numarasını Girin"),
        "enterProductCodeOrScan":
            MessageLookupByLibrary.simpleMessage("Ürün Kodunu Girin veya Tara"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Ürün Adını Girin"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Satın Alma Fiyatını Girin"),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("Referans Numarasını Girin"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Bedeni Girin"),
        "enterStocks":
            MessageLookupByLibrary.simpleMessage("Stok Miktarını Girin"),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Vergi oranını girin"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("İşlem Kimliği Girin"),
        "enterType": MessageLookupByLibrary.simpleMessage("Tipi Girin"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("Kullanıcı Ünvanını Girin"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Geçerli Miktar Girin"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Depo adını girin"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Ağırlığı Girin"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Toptan Satış Fiyatını Girin"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("Açıklamanızı Buraya Girin"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("E-Posta Adresinizi Girin"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "Geri Bildirim Başlığını Girin"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("GST Numaranızı girin"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("Mobil numaranızı girin"),
        "enterYourName": MessageLookupByLibrary.simpleMessage("Adınızı Girin"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("Telefon numaranızı girin"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Şifrenizi Girin"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Telefon Numaranızı Girin"),
        "enterYourTransactionId":
            MessageLookupByLibrary.simpleMessage("İşlem kimliğinizi girin"),
        "error": MessageLookupByLibrary.simpleMessage("Hata"),
        "excTax": MessageLookupByLibrary.simpleMessage("KDV Hariç"),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("Excel Yükleyici"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Hariç"),
        "expense": MessageLookupByLibrary.simpleMessage("Gider"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Gider Kategorisi"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Gider Tarihi"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Gider Türü"),
        "expenseReport": MessageLookupByLibrary.simpleMessage("Gider Raporu"),
        "expireDate":
            MessageLookupByLibrary.simpleMessage("Son Kullanma Tarihi"),
        "expired": MessageLookupByLibrary.simpleMessage("Süresi Dolmuş"),
        "expiring": MessageLookupByLibrary.simpleMessage("Son Kullanım Tarihi"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Hata ile başarısız oldu"),
        "fashion": MessageLookupByLibrary.simpleMessage("Moda"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Özellikler, Pos Saas\'yı geleneksel çözümlerden farklı kılan önemli bir parçadır."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Geri Bildirim"),
        "firstName": MessageLookupByLibrary.simpleMessage("Ad"),
        "followUsOnFacebook": MessageLookupByLibrary.simpleMessage(
            "Bizi Facebook\'ta Takip Edin"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Bizi Twitter\'da Takip Edin"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Ön Yüz"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("Sınırsız kullanımlar için"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Şifrenizi Unuttunuz"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Şifreyi mi unuttunuz?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Başlangıç Tarihi"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("Ücretsiz Veri Yedekleme"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "Ücretsiz Ömür Boyu Güncelleme"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Ücretsiz Paket"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Ücretsiz Plan"),
        "from": MessageLookupByLibrary.simpleMessage("(Den"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Tamamen Ödenmiş"),
        "gallary": MessageLookupByLibrary.simpleMessage("Galeri"),
        "generatingPDF":
            MessageLookupByLibrary.simpleMessage("PDF Oluşturuluyor"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Otp Al"),
        "govermentId": MessageLookupByLibrary.simpleMessage("Hükümet Kimliği"),
        "guest": MessageLookupByLibrary.simpleMessage("Misafir"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Hesabınız yok mu?"),
        "history": MessageLookupByLibrary.simpleMessage("Geçmiş"),
        "home": MessageLookupByLibrary.simpleMessage("Ana Sayfa"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Bilgilerinizi Nasıl Koruyoruz"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Bilgilerinizi Nasıl Kullanıyoruz"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Kimlik Doğrulama"),
        "image": MessageLookupByLibrary.simpleMessage("Resim"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("İçeride silinemez"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("İçeride düzenlenemez"),
        "inWord": MessageLookupByLibrary.simpleMessage("Yazıyla"),
        "incTax": MessageLookupByLibrary.simpleMessage("KDV Dahil"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Dahil"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("Stok artır"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Araç"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Fatura No."),
        "invoice": MessageLookupByLibrary.simpleMessage("Fatura"),
        "invoiceNumber":
            MessageLookupByLibrary.simpleMessage("Fatura Numarası"),
        "invoiceSetting": MessageLookupByLibrary.simpleMessage("Fatura Ayarı"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Fatura Görüntüleyici"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Ürün Eklendi"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("KYC Doğrulaması"),
        "language": MessageLookupByLibrary.simpleMessage("Dil"),
        "lastName": MessageLookupByLibrary.simpleMessage("Soyad"),
        "ledger": MessageLookupByLibrary.simpleMessage("Defter"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Ömür Boyu\nSatın Alma"),
        "link": MessageLookupByLibrary.simpleMessage("Bağlantı"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Canlı Sohbet Desteği"),
        "loading": MessageLookupByLibrary.simpleMessage("Yükleniyor"),
        "logIn": MessageLookupByLibrary.simpleMessage("Giriş Yap"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Çıkış Yap"),
        "logOut": MessageLookupByLibrary.simpleMessage("Çıkış Yap"),
        "login": MessageLookupByLibrary.simpleMessage("Giriş Yap"),
        "logo": MessageLookupByLibrary.simpleMessage("Logo"),
        "loss": MessageLookupByLibrary.simpleMessage("Zarar"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Zarar/Kar"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Zarar/Kar Detayları"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Zarar/Kâr Raporu"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Zarar/Kâr Raporları"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Düşük Stok Uyarısı"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Müşterileriniz üzerinde markalı faturalarla kalıcı bir izlenim bırakın. Sınırsız Güncelleme, markanızı pekiştiren ve müşteri sadakatini destekleyen profesyonel bir dokunuş eklemenin benzersiz avantajını sunar."),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("İşinizi şununla yönetin: "),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Üretim Tarihi"),
        "margin": MessageLookupByLibrary.simpleMessage("Marj"),
        "masterCard": MessageLookupByLibrary.simpleMessage("Mastercard"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Üretici"),
        "message": MessageLookupByLibrary.simpleMessage("Mesaj"),
        "messageHistory": MessageLookupByLibrary.simpleMessage("Mesaj Geçmişi"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Pos Saas uygulaması ücretsizdir, kolay kullanılır. Aslında, dünyanın en iyi POS sistemlerinden biridir."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas, stok, hesap, satış, gider ve kar/zarar ile tam bir iş çözümüdür."),
        "mobile": MessageLookupByLibrary.simpleMessage("Mobil"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("Mobil Ödeme"),
        "monthly": MessageLookupByLibrary.simpleMessage("Aylık"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("Daha Fazla Bilgi"),
        "name": MessageLookupByLibrary.simpleMessage("Adınızı Girin"),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("İsim zaten mevcut"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("İsim boş bırakılamaz"),
        "next": MessageLookupByLibrary.simpleMessage("İleri"),
        "noConnection": MessageLookupByLibrary.simpleMessage("Bağlantı Yok"),
        "noData": MessageLookupByLibrary.simpleMessage("Veri Yok"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Veri mevcut değil"),
        "noDataFound": MessageLookupByLibrary.simpleMessage("Veri bulunamadı"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("Geçmiş Bulunamadı!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Ürün Bulunamadı"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("Hiçbir Alt Vergi Seçilmedi"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("İşlem Bulunamadı!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Bu e-posta için kullanıcı bulunamadı."),
        "noUserRoleFound":
            MessageLookupByLibrary.simpleMessage("Kullanıcı Rolü Bulunamadı"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Aktif Kullanıcı Değil"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Verilmedi"),
        "note": MessageLookupByLibrary.simpleMessage("Not"),
        "notes": MessageLookupByLibrary.simpleMessage("Notlar"),
        "notification": MessageLookupByLibrary.simpleMessage("Bildirim"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP gönderildi"),
        "office": MessageLookupByLibrary.simpleMessage("Ofis"),
        "ok": MessageLookupByLibrary.simpleMessage("Tamam"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "Satış izleme, envanter yönetimi dahil birçok işlevi içeren bir POS."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Bu sistem, işlemlerinizi müşterileriniz için iyileştirmenize yardımcı olur."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "POS sistemimiz günlük işlemleri otomatik olarak basit hale getirmelidir, bu da gezinmeyi kolaylaştırır."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("Açılış Bakiyesi"),
        "order": MessageLookupByLibrary.simpleMessage("Siparişler"),
        "other": MessageLookupByLibrary.simpleMessage("Diğer"),
        "otp": MessageLookupByLibrary.simpleMessage("Kapat"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Stokta Yok"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Paket"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Paket Özellikleri"),
        "paid": MessageLookupByLibrary.simpleMessage("Ödenen"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Ödenen Miktar"),
        "parties": MessageLookupByLibrary.simpleMessage("Taraflar"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Taraflar Listesi"),
        "partyGST": MessageLookupByLibrary.simpleMessage("Taraf GST"),
        "partyName": MessageLookupByLibrary.simpleMessage("Parti Adı"),
        "password": MessageLookupByLibrary.simpleMessage("Şifre"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Şifre ve onay şifresi eşleşmiyor"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Şifre boş olamaz"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("Şifre eşleşmiyor"),
        "payCash": MessageLookupByLibrary.simpleMessage("Nakit Ödeme"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash": MessageLookupByLibrary.simpleMessage("Bkash ile Öde"),
        "payWithPaypal": MessageLookupByLibrary.simpleMessage("PayPal ile Öde"),
        "payeeName": MessageLookupByLibrary.simpleMessage("Alıcı Adı"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("Alıcı Numarası"),
        "payment": MessageLookupByLibrary.simpleMessage("Ödeme"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("Ödeme Miktarı"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Ödeme Tamamlandı"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Ödeme Talimatı:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("Ödeme Yöntemi"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Ödeme Türü"),
        "pdfView": MessageLookupByLibrary.simpleMessage("Pdf Görünümü"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Kişisel Bilgiler"),
        "phone": MessageLookupByLibrary.simpleMessage("Telefon"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Telefon Numarası"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Telefon Numarası Zaten Kullanıldı"),
        "phoneNumberIsNotValid": MessageLookupByLibrary.simpleMessage(
            "Telefon numarası geçerli değil"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("Telefon Numarası gereklidir"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("Dosya Seç ve Yükle"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("Bitiş Tarihini Seçin"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Başlangıç Tarihini Seçin"),
        "plan": MessageLookupByLibrary.simpleMessage("Plan"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("Lütfen miktar ekleyin"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Lütfen internet bağlantınızı kontrol edin"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Lütfen önce yazıcıyı bağlayın"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Lütfen Bluetooth yazıcınızı bağlayın"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Lütfen daha uzun bir şifre girin"),
        "pleaseEnterAConfirmPassword":
            MessageLookupByLibrary.simpleMessage("Lütfen bir şifre onaylayın"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("Lütfen bir şifre girin"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Lütfen geçerli bir e-posta adresi girin"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Lütfen İsim Girin"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("Lütfen şifre girin"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Şifre sıfırlama bağlantısı almak için lütfen e-posta adresinizi girin."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Lütfen İşlem Numarasını Girin"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("Lütfen Miktar Girin"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Lütfen önce bir kategori seçin"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("Lütfen Bir Plan Seçin"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Lütfen İş Kategorisini Seçin"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Uygulamayı kullanmak için geçerli bir satın alma kodu kullanın"),
        "powerdedByMobiPos": MessageLookupByLibrary.simpleMessage(
            "Pos Saas tarafından desteklenmektedir"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Destekleyen"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Premium Müşteri Desteği"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Premium Plan"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Önceki Ödeme Miktarları"),
        "price": MessageLookupByLibrary.simpleMessage("Fiyat"),
        "print": MessageLookupByLibrary.simpleMessage("Yazdır"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Baskı Seçeneği"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Gizlilik Politikası"),
        "product": MessageLookupByLibrary.simpleMessage("Ürün"),
        "productCode": MessageLookupByLibrary.simpleMessage("Ürün Kodu"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("Ürün Kodu gereklidir"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Ürün Kodu/Adı"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Ürün Açıklaması"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Ürün Detayları"),
        "productList": MessageLookupByLibrary.simpleMessage("Ürün Listesi"),
        "productName": MessageLookupByLibrary.simpleMessage("Ürün Adı"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Ürün Adı bu depoda zaten mevcut"),
        "productNameIsAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("Ürün adı zaten eklenmiş"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("Ürün adı gereklidir"),
        "products": MessageLookupByLibrary.simpleMessage("Ürünler"),
        "profile": MessageLookupByLibrary.simpleMessage("Profil"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("Profil Düzenle"),
        "profit": MessageLookupByLibrary.simpleMessage("Kar"),
        "promo": MessageLookupByLibrary.simpleMessage("Promosyon"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Promosyon Kodu"),
        "purchase": MessageLookupByLibrary.simpleMessage("Satın Alma"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("Satın Alma Alarmı"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Satın Alma Onaylandı"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Satın Alma Detayları"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Alım Faturası"),
        "purchaseList":
            MessageLookupByLibrary.simpleMessage("Satın Alma Listesi"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Şimdi Satın Al"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Premium Plan Satın Al"),
        "purchasePrice":
            MessageLookupByLibrary.simpleMessage("Satın Alma Fiyatı"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("Alış Fiyatı gereklidir"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("Satın Alma Raporu"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Satın Alma Raporu"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Satın Alma Raporları"),
        "purchaseReturn": MessageLookupByLibrary.simpleMessage("Alım İadesi"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("Alım İade Raporu"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Alım Geçişi"),
        "qty": MessageLookupByLibrary.simpleMessage("Miktar"),
        "quantity": MessageLookupByLibrary.simpleMessage("Miktar"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Son İşlemler"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("Pin Kodu Alındı"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Referans Numarası"),
        "register": MessageLookupByLibrary.simpleMessage("Kayıt Ol"),
        "registering": MessageLookupByLibrary.simpleMessage("Kayıt yapılıyor"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("Kalan Borç"),
        "remove": MessageLookupByLibrary.simpleMessage("Kaldır"),
        "reports": MessageLookupByLibrary.simpleMessage("Raporlar"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Talep gönderildi"),
        "resendCode":
            MessageLookupByLibrary.simpleMessage("Kodu Tekrar Gönder"),
        "resendOtp":
            MessageLookupByLibrary.simpleMessage("OTP\'yi Yeniden Gönder: "),
        "retailer": MessageLookupByLibrary.simpleMessage("Perakendeci"),
        "retur": MessageLookupByLibrary.simpleMessage("İade"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("İade Miktarı"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("İade Miktarı"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("İade Miktarı"),
        "revenue": MessageLookupByLibrary.simpleMessage("Gelir"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "İş verilerinizi kolayca koruyun. Pos Saas POS Sınırsız Güncelleme, değerli bilgilerinizi beklenmedik olaylara karşı koruyan ücretsiz veri yedeklemeyi içerir. Gerçekten önemli olan şeye odaklanın - iş büyümeniz."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Satış Tutarı"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("Satış Detayları"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Satış Fiyatı"),
        "saleReports": MessageLookupByLibrary.simpleMessage("Satış Raporu"),
        "saleReportss": MessageLookupByLibrary.simpleMessage("Satış Raporları"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("Satış iadesi"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Satış İade Raporu"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("Satış Ayarları"),
        "sales": MessageLookupByLibrary.simpleMessage("Satışlar"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("Satış ve Alım Raporları"),
        "salesList": MessageLookupByLibrary.simpleMessage("Satış Listesi"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("Satış İadesi"),
        "save": MessageLookupByLibrary.simpleMessage("Kaydet"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Kaydet ve Yayınla"),
        "saveChanges":
            MessageLookupByLibrary.simpleMessage("Değişiklikleri Kaydet"),
        "saving": MessageLookupByLibrary.simpleMessage("Kaydediliyor"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("Ürün QR kodunu tara"),
        "search": MessageLookupByLibrary.simpleMessage("Ara"),
        "searchByProductCodeOrName":
            MessageLookupByLibrary.simpleMessage("Ürün kodu veya adıyla ara"),
        "seeAllPromoCode": MessageLookupByLibrary.simpleMessage(
            "Tüm promosyon kodlarını görüntüle"),
        "select": MessageLookupByLibrary.simpleMessage("Seç"),
        "selectAProductForReturn":
            MessageLookupByLibrary.simpleMessage("İade için bir ürün seçin"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Marka Seçin"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Kategori Seçin"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Kişileri Seçin"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("Ürün Kategorisini Seçin"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("Mağaza Kategorisini Seçin"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Vergi Seçin"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Vergi Tipini Seçin"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("Birim Seçin"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Varyasyon Seçin: "),
        "seller": MessageLookupByLibrary.simpleMessage("Satıcı"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Satış Yapan"),
        "send": MessageLookupByLibrary.simpleMessage("Gönder"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("E-Posta Gönder"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Mesaj Gönder"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("Sıfırlama Bağlantısı Gönder"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Sms Gönder"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Sms gönderilsin mi?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Whatsapp mesajı gönder"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("E-Postanızı Gönderin"),
        "sendingEmail":
            MessageLookupByLibrary.simpleMessage("E-posta Gönderiliyor"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Mesaj gönderiliyor"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Hizmet/Taşıma"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Profilinizi Ayarlayın"),
        "setting": MessageLookupByLibrary.simpleMessage("Ayarlar"),
        "share": MessageLookupByLibrary.simpleMessage("Paylaş"),
        "shopGST": MessageLookupByLibrary.simpleMessage("Mağaza GST"),
        "signIn": MessageLookupByLibrary.simpleMessage("Giriş Yap"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("E-posta ile giriş yap"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Müşteri İmzası"),
        "size": MessageLookupByLibrary.simpleMessage("Beden"),
        "skip": MessageLookupByLibrary.simpleMessage("Atla"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Sosyal Pazarlama"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Üzgünüz, bu hizmete erişim izniniz yok"),
        "startDate": MessageLookupByLibrary.simpleMessage("Başlangıç Tarihi"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Yeni Satış Başlat"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage(
            "Aramak için yazmaya başlayın"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Ekstra maliyet olmadan teknolojik gelişmelerin önünde olun. Pos Saas POS Sınırsız Güncelleme, her zaman en son araçlara ve özelliklere sahip olduğunuzdan emin olarak işinizin son teknoloji olmasını garanti eder."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("Hala Ödenmemiş"),
        "stock": MessageLookupByLibrary.simpleMessage("Stok"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Stok gereklidir"),
        "stockList": MessageLookupByLibrary.simpleMessage("Stok Listesi"),
        "stocks": MessageLookupByLibrary.simpleMessage("Stoklar"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Excel dosyası oluşturmak için depolama izni gereklidir"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("Alt Vergi Listesi"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Alt Vergiler"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Ara Toplam"),
        "submit": MessageLookupByLibrary.simpleMessage("Gönder"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "Youtube Kanalımıza Abone Olun"),
        "subscription": MessageLookupByLibrary.simpleMessage("Abonelik"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Başarıyla Tamamlandı"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Başarıyla Çıkış Yapıldı"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Başarıyla güncellendi"),
        "supplier": MessageLookupByLibrary.simpleMessage("Tedarikçi"),
        "supplierName": MessageLookupByLibrary.simpleMessage("Tedarikçi Adı"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT Kodu"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Sürücü belgesi, kimlik kartı veya pasaport fotoğrafı çekin"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "Kimliğinizi kontrol etmek için kimlik kartı alın"),
        "tap": MessageLookupByLibrary.simpleMessage("Dokunun"),
        "tax": MessageLookupByLibrary.simpleMessage("Vergi"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Vergi grubu"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("Veri Yüzdesi"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Vergi oranı"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Vergi oranları - Vergi oranlarınızı yönetin"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Vergi raporu"),
        "taxType": MessageLookupByLibrary.simpleMessage("Vergi Türü"),
        "taxes": MessageLookupByLibrary.simpleMessage("Vergiler"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Şartlar ve Koşullar"),
        "termsOfUse":
            MessageLookupByLibrary.simpleMessage("Kullanım Koşulları"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Şartlar ve Gizlilik"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Vade Ödemeniz İçin Teşekkür Ederiz"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Teşekkürler"),
        "thankYouForYourPurchase": MessageLookupByLibrary.simpleMessage(
            "Satın Alımınız İçin Teşekkür Ederiz"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "O e-posta adresi için hesap zaten mevcut"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Excel dosyası zaten indirildi"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "İsim her şeyi söyler. Pos Saas POS Sınırsız ile kullanımınıza bir sınırlama yok. Bir avuç işlemi işliyor ya da müşterilerin akınına uğruyorsanız, sınırlamalarla sınırlı olmadığınızı bilerek güvenle çalışabilirsiniz."),
        "thePasswordProvidedIsTooWeak":
            MessageLookupByLibrary.simpleMessage("Verilen şifre çok zayıf"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Satış silinecek ve bu satın alma ile ilgili tüm veriler silinecek. Bu satışın silineceğinden emin misiniz?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Satış silinecek ve bu satışla ilgili tüm veriler silinecek. Bu satışın silineceğinden emin misiniz?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Kullanıcı silinecek ve tüm veriler hesabınızdan silinecek. Bunun silmek istediğinizden emin misiniz?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Kullanıcı silinecek ve tüm veriler hesabınızdan silinecek. Bunu silmek istediğinizden emin misiniz?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Üçüncü Taraf Hizmetleri"),
        "thisCategoryCannotBeDeleted":
            MessageLookupByLibrary.simpleMessage("Bu kategori silinemez"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Bu Ay)"),
        "thisProductAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("Bu Ürün Zaten Eklendi"),
        "title": MessageLookupByLibrary.simpleMessage("Başlık"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Başlık boş olamaz"),
        "to": MessageLookupByLibrary.simpleMessage("e)"),
        "toDate": MessageLookupByLibrary.simpleMessage("Bitiş Tarihi"),
        "today": MessageLookupByLibrary.simpleMessage("Bugün"),
        "total": MessageLookupByLibrary.simpleMessage("Toplam"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Toplam Miktar"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Toplam Tahsilat"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Toplam Borç"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("Toplam Gider"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Toplam Kayıp"),
        "totalPayable": MessageLookupByLibrary.simpleMessage("Toplam Ödenecek"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Toplam Fiyat"),
        "totalProducts": MessageLookupByLibrary.simpleMessage("Toplam Ürünler"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Toplam Kar"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("Toplam Alım"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Toplam İade Tutarı"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("Toplam İadeler"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Toplam Satış"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Toplam Stok"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Toplam değer"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Toplam KDV"),
        "totals": MessageLookupByLibrary.simpleMessage("Toplam: "),
        "transaction": MessageLookupByLibrary.simpleMessage("İşlem"),
        "transactionId": MessageLookupByLibrary.simpleMessage("İşlem Kimliği"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Tekrar Deneyin"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Tip"),
        "unitName": MessageLookupByLibrary.simpleMessage("Birim Adı"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Birim Fiyat"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Birim Fiyatı"),
        "units": MessageLookupByLibrary.simpleMessage("Birimler"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Sınırsız"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Sınırsız Kullanım"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Pos Saas POS\'un tam potansiyelini uzman ekibimizin yönettiği kişiselleştirilmiş eğitim oturumlarıyla açın. Temelden ileri tekniklere kadar, sistemin her yönünü kullanarak iş süreçlerinizi optimize etmek için iyi eğitim almış olduğunuzdan emin oluruz."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Ödenmemiş"),
        "update": MessageLookupByLibrary.simpleMessage("Güncelle"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Kişiyi Güncelle"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Şimdi Güncelle"),
        "updateProduct": MessageLookupByLibrary.simpleMessage("Ürünü Güncelle"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Önce planınızı güncelleyin, limitiniz dolmuş durumda"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Profilinizi Güncelleyin"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Doktorunuzla daha iyi bir izlenimle bağlantı kurmak için profilinizi güncelleyin"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Müşterinizle daha iyi bir bağlantı kurmak için profilinizi güncelleyin"),
        "updated": MessageLookupByLibrary.simpleMessage("Güncellendi"),
        "upload": MessageLookupByLibrary.simpleMessage("Yükle"),
        "uploadDocument": MessageLookupByLibrary.simpleMessage("Belge Yükle"),
        "uploadDone":
            MessageLookupByLibrary.simpleMessage("Yükleme Tamamlandı"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Dosya Yükle"),
        "usbC": MessageLookupByLibrary.simpleMessage("Usb C"),
        "use": MessageLookupByLibrary.simpleMessage("Kullan"),
        "useMobiPos":
            MessageLookupByLibrary.simpleMessage("Pos Saas\'yı Kullanın"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Sistemi Kullanım"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Kullanıcı silindi"),
        "userRole": MessageLookupByLibrary.simpleMessage("Kullanıcı Rolü"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("Kullanıcı Rolü Detayları"),
        "userTitle": MessageLookupByLibrary.simpleMessage("Kullanıcı Ünvanı"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Kullanıcı başlığı boş bırakılamaz"),
        "value": MessageLookupByLibrary.simpleMessage("Değer"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("KDV Uygulanmaz"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("OTP Doğrulanıyor"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Telefon Numarasını Doğrula"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Tümünü Gör"),
        "viewDetails":
            MessageLookupByLibrary.simpleMessage("Detayları Görüntüle"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Yerinde Müşteri"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Depo"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Depo zaten mevcut"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("Depo listesi"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("Depo adı"),
        "warranty": MessageLookupByLibrary.simpleMessage("Garanti"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Bir E-Posta gönderdik, talimatları şuraya nasıl sıfırlayacağınıza dair:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Uygulamamızın işlevselliğini desteklemek için analiz sağlayıcıları ve ödeme işlemcileri gibi üçüncü taraf hizmetlerini kullanabiliriz. Bu üçüncü taraf hizmetleri, uygulamamızı kullandığınızda sizin hakkınızda bilgi toplayabilir. Lütfen bu üçüncü taraf hizmetlerin gizlilik uygulamalarından sorumlu olmadığımızı unutmayın."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Kişisel bilgilerinizi korumak için şifreleme ve güvenli depolama da dahil olmak üzere endüstri standart önlemleri alıyoruz. Bilgilerinize sadece yetkili personelin erişimini sınırlıyoruz."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Sorunsuz işlemlerin önemini anlıyoruz. Bu nedenle gece gündüz destek ekibimiz, hızlı bir soru veya kapsamlı bir endişe olsun, sizi her zaman desteklemek için hazır. Sorunsuz müşteri hizmeti deneyimi yaşamak için her zaman ve her yerde bize çağrı veya WhatsApp aracılığıyla bağlanın."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Kişisel bilgilerinizi size uygulamamızda en iyi deneyimi sunmak, içerik önerilerinizi kişiselleştirmek, uzmanlarla sizi buluşturmak ve uygulamamızın işlevselliğini artırmak için kullanıyoruz. Ayrıca, bilgilerinizi güncellemeler, promosyonlar veya uygulamamıza ilişkin diğer bilgiler hakkında sizinle iletişim kurmak için de kullanabiliriz."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Ödemeyi gözden geçireceğiz ve 1-2 saat içinde onaylayacağız"),
        "weekly": MessageLookupByLibrary.simpleMessage("Haftalık"),
        "weight": MessageLookupByLibrary.simpleMessage("Ağırlık"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Yenilikler Neler"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Toptancı"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Toptan Satış Fiyatı"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("Toptan fiyat"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Toptancı"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Yakında Eklenecek"),
        "willExpireAt":
            MessageLookupByLibrary.simpleMessage("Şurada Süresi Dolacak"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Mesajınızı Buraya Yazın"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("Yanlış OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Bu kullanıcı için yanlış şifre verildi."),
        "yearly": MessageLookupByLibrary.simpleMessage("Yıllık"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Evet, Kalıcı Olarak Sil"),
        "youAreNotAValidUser": MessageLookupByLibrary.simpleMessage(
            "Geçerli bir kullanıcı değilsiniz"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Kullanıyorsunuz"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Ödeme miktarından fazlasını ödeyemezsiniz"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Bir E-Posta Aldınız"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Hesabınıza başarıyla giriş yaptınız. Pos Saas  ile kalın."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("İzin vermeniz gerekiyor"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Hesabınıza TEKRAR GİRİŞ yapmalısınız."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Satın almadan önce kimlik doğrulaması yapmanız gerekiyor"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Mesajınız hala"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Paketiniz"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Paketiniz 5 gün içinde sona erecek")
      };
}
