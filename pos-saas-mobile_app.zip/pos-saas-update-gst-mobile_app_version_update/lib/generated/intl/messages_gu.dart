// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a gu locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'gu';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Continuar"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("Número GST"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("É necesario MRP"),
        "OK": MessageLookupByLibrary.simpleMessage("OK"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Tel."),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("Código SWIFT"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Aperitivos"),
        "TAX": MessageLookupByLibrary.simpleMessage("IMPOSTO"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Subindo"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("Título do usuario"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "O teu paquete expira hoxe\n\nPor favor, compra de novo"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) O sistema proporcionase exclusivamente para facilitar transaccións de punto de venda e actividades relacionadas no seu negocio."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) Para utilizar o sistema, pode ser necesario que cree unha conta. Acepta proporcionar información precisa, actual e completa durante o proceso de rexistro e actualizar dicha información para mantela precisa e completa."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("Sobre a App"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Sobre nós"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Aceptación dos termos"),
        "accountName": MessageLookupByLibrary.simpleMessage("Nome da Conta"),
        "accountNumber":
            MessageLookupByLibrary.simpleMessage("Número da Conta"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Registro de conta"),
        "acton": MessageLookupByLibrary.simpleMessage("Acción"),
        "add": MessageLookupByLibrary.simpleMessage("Engadir"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Engadir Marca"),
        "addCategory":
            MessageLookupByLibrary.simpleMessage("Engadir Categoría"),
        "addContact": MessageLookupByLibrary.simpleMessage("Engadir Contacto"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Engadir Cliente"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("Engadir Entrega"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Engadir descrición"),
        "addDescription": MessageLookupByLibrary.simpleMessage("Engadir Nota"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Engadir desconto"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Engadir ID de documento"),
        "addDucument":
            MessageLookupByLibrary.simpleMessage("Engadir documento"),
        "addExpense":
            MessageLookupByLibrary.simpleMessage("Engadir Desembolso"),
        "addExpenseCategory": MessageLookupByLibrary.simpleMessage(
            "Engadir Categoría de Desembolso"),
        "addItems": MessageLookupByLibrary.simpleMessage("Engadir Elementos"),
        "addNew": MessageLookupByLibrary.simpleMessage("Engadir novo"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Engadir Novo Enderezo"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Engadir Produto"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("Engadir nova taxa"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Engadir nova taxa con tipo de taxa única/múltiple"),
        "addNote": MessageLookupByLibrary.simpleMessage("Engadir Nota"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Engada o produto primeiro"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Engadir código promocional"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Engadir Compra"),
        "addSales": MessageLookupByLibrary.simpleMessage("Engadir vendas"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Engadido con éxito"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Engadir Unidade"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Engadir rol de usuario"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Engadido correctamente"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("Engadido ao carro"),
        "address": MessageLookupByLibrary.simpleMessage("Enderezo"),
        "admin": MessageLookupByLibrary.simpleMessage("Administración"),
        "all": MessageLookupByLibrary.simpleMessage("Todo"),
        "allBusinessSolution": MessageLookupByLibrary.simpleMessage(
            "Todas as solucións empresariais"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("Xa engadido"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Xa existe"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Xa Tes Unha Conta"),
        "amount": MessageLookupByLibrary.simpleMessage("Cantidade"),
        "anEmailHasBeenSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "Envióuselle un correo electrónico.\\nVerifique a súa caixa de entrada"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Soporte para aplicacións Android e iOS"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Imposto aplicable"),
        "apply": MessageLookupByLibrary.simpleMessage("Aplicar"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Está seguro de que quere eliminar esta factura?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Está seguro de que quere eliminar esta venda?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Estás seguro de que queres eliminar este usuario?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Estás seguro de que desexas eliminar este imposto?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Estás seguro de que desexas eliminar este grupo de impostos?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Queres eliminar este almacén?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Estás seguro de que queres borrar este usuario?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Sinatura autorizada"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Vostede é responsable de manter a confidencialidade da súa conta e contrasinal e de restringir o acceso á súa conta. Acepta a responsabilidade por todas as actividades que ocorran na súa conta."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Debe ter polo menos 18 anos ou a idade legal de maioría na súa xurisdición para utilizar o sistema."),
        "backSide": MessageLookupByLibrary.simpleMessage("Lado posterior"),
        "backToHome": MessageLookupByLibrary.simpleMessage("Voltar á casa"),
        "balance": MessageLookupByLibrary.simpleMessage("Balance"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladesh"),
        "bank": MessageLookupByLibrary.simpleMessage("Banco"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Moeda da conta bancaria"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Moeda da Conta Bancaria"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Información bancaria"),
        "bankName": MessageLookupByLibrary.simpleMessage("Nome do Banco"),
        "bankTransfer":
            MessageLookupByLibrary.simpleMessage("Transferencia bancaria"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Código de barras atopado"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Factura"),
        "billTo": MessageLookupByLibrary.simpleMessage("Facturar a"),
        "branchName": MessageLookupByLibrary.simpleMessage("Nome da Sucursal"),
        "brand": MessageLookupByLibrary.simpleMessage("Marca"),
        "brandName": MessageLookupByLibrary.simpleMessage("Nome da Marca"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("Subida masiva"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Categoría de Negocio"),
        "buy": MessageLookupByLibrary.simpleMessage("Comprar"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Comprar plan premium"),
        "buySms": MessageLookupByLibrary.simpleMessage("Comprar Sms"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Ao acceder ou utilizar o sistema de punto de venda (POS) (o \"Sistema\") proporcionado por [Nome da súa empresa] (\"Empresa\"), acepta estar vinculado por estes termos de uso. Se non acepta estes termos de uso, non utilice o sistema."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Vostede é responsable de garantir que o seu acceso e uso do sistema cumpran todas as leis e regulacións aplicables."),
        "cacel": MessageLookupByLibrary.simpleMessage("Cancelar"),
        "call": MessageLookupByLibrary.simpleMessage("Chamar"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "Chame para soporte de emerxencia"),
        "camera": MessageLookupByLibrary.simpleMessage("Cámara"),
        "cancel": MessageLookupByLibrary.simpleMessage("Cancelar"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Cancelar todos os produtos"),
        "capacity": MessageLookupByLibrary.simpleMessage("Capacidade"),
        "card": MessageLookupByLibrary.simpleMessage("Tarxeta"),
        "cash": MessageLookupByLibrary.simpleMessage("Efectivo"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Categorías"),
        "category": MessageLookupByLibrary.simpleMessage("Categoría"),
        "categoryName":
            MessageLookupByLibrary.simpleMessage("Nome da categoría"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "O nome da categoría xa existe"),
        "cateogryName":
            MessageLookupByLibrary.simpleMessage("Nome da Categoría"),
        "change": MessageLookupByLibrary.simpleMessage("Cambiar?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Cambiar Contrasinal"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("Comproba o Correo"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Escolla un cliente"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Escolle un Proveedor"),
        "choseYourFeature": MessageLookupByLibrary.simpleMessage(
            "Escolle as túas características"),
        "clarence": MessageLookupByLibrary.simpleMessage("Liquidación"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Fai clic para conectar"),
        "close": MessageLookupByLibrary.simpleMessage("Pechar"),
        "color": MessageLookupByLibrary.simpleMessage("Cor"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(Combinación de múltiples impostos)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Próximamente"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Enderezo da Empresa"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Nome da Empresa e da Tenda"),
        "companyBusinessName": MessageLookupByLibrary.simpleMessage(
            "Nome da empresa e do negocio"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Completar transacción"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Confirmar Contrasinal"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Confirme a devolución"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Parabéns"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Contacta con nós"),
        "continu": MessageLookupByLibrary.simpleMessage("Continuar"),
        "country": MessageLookupByLibrary.simpleMessage("País"),
        "create": MessageLookupByLibrary.simpleMessage("Crear"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Crea unha Conta Gratuita"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Creado e gardado"),
        "currency": MessageLookupByLibrary.simpleMessage("Moeda"),
        "currentStock": MessageLookupByLibrary.simpleMessage("Stock actual"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("Personalización de facturas"),
        "customer": MessageLookupByLibrary.simpleMessage("Cliente"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Detalles do Cliente"),
        "customerGST": MessageLookupByLibrary.simpleMessage("GST do cliente"),
        "customerName": MessageLookupByLibrary.simpleMessage("Nome do Cliente"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Transacción Diaria"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Visión xeral do taboleiro"),
        "dataSavedSuccessfully": MessageLookupByLibrary.simpleMessage(
            "Datos gardados correctamente"),
        "date": MessageLookupByLibrary.simpleMessage("Data"),
        "day": MessageLookupByLibrary.simpleMessage("Día"),
        "dealer": MessageLookupByLibrary.simpleMessage("Distribuidor"),
        "dealerPrice":
            MessageLookupByLibrary.simpleMessage("Prezo de Distribuidor"),
        "defaultVATPercentage": MessageLookupByLibrary.simpleMessage(
            "Porcentaxe de IVA predeterminada"),
        "delete": MessageLookupByLibrary.simpleMessage("Eliminar"),
        "deleting": MessageLookupByLibrary.simpleMessage("Eliminando"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Enderezo de Entrega"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Direccións de entrega"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Custo de Entrega"),
        "describtion": MessageLookupByLibrary.simpleMessage("Descrición"),
        "description": MessageLookupByLibrary.simpleMessage("Descrición"),
        "descriptionCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "A descrición non pode estar baleira"),
        "details": MessageLookupByLibrary.simpleMessage("Detalles"),
        "discount": MessageLookupByLibrary.simpleMessage("Desconto"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Non molestar"),
        "done": MessageLookupByLibrary.simpleMessage("Feito"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Descargar formato Excel"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Descargado con éxito na carpeta de descargas"),
        "due": MessageLookupByLibrary.simpleMessage("Debido"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Cantidade Debida: "),
        "dueCollection":
            MessageLookupByLibrary.simpleMessage("Recolleita de Deberes"),
        "dueCollectionReports": MessageLookupByLibrary.simpleMessage(
            "Informes de Cobranza Pendentes"),
        "dueList": MessageLookupByLibrary.simpleMessage("Lista de Deberes"),
        "dueReports":
            MessageLookupByLibrary.simpleMessage("Informe de débedas"),
        "duration": MessageLookupByLibrary.simpleMessage("Duración"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Duración: Desde"),
        "easyToUseMobilePos":
            MessageLookupByLibrary.simpleMessage("Fácil de usar móbil pos"),
        "edit": MessageLookupByLibrary.simpleMessage("Editar"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Editar factura de compra"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Editar factura de vendas"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Editar Redes Sociais"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Editado con éxito"),
        "editTax": MessageLookupByLibrary.simpleMessage("Editar imposto"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Editar grupo de impostos"),
        "editWarehouse": MessageLookupByLibrary.simpleMessage("Editar almacén"),
        "email": MessageLookupByLibrary.simpleMessage("Correo Electrónico"),
        "emailAddress": MessageLookupByLibrary.simpleMessage(
            "Enderezo de Correo Electrónico"),
        "emailCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "O correo electrónico non pode estar baleiro"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "Correo enviado! Comprobe a súa caixa de entrada"),
        "endDate": MessageLookupByLibrary.simpleMessage("Data de finalización"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Introduce un importe válido"),
        "enterAValidDiscount": MessageLookupByLibrary.simpleMessage(
            "Introduza un desconto válido"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Introduce un número de teléfono válido"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Introduza un prezo válido"),
        "enterAValidQuantity": MessageLookupByLibrary.simpleMessage(
            "Introduza unha cantidade válida"),
        "enterAddress":
            MessageLookupByLibrary.simpleMessage("Introduce o Enderezo"),
        "enterAmount":
            MessageLookupByLibrary.simpleMessage("Introduce a Cantidade."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Introducir Nome da Marca"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Introducir Capacidade"),
        "enterCategoryName": MessageLookupByLibrary.simpleMessage(
            "Introducir Nome da Categoría"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Introducir Cor"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "Introduce o número GST do cliente"),
        "enterDealerPrice": MessageLookupByLibrary.simpleMessage(
            "Introducir Prezo de Distribuidor"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Introduza a descrición"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("Introducir Desconto."),
        "enterExpenseDate": MessageLookupByLibrary.simpleMessage(
            "Introduce a Data do Desembolso"),
        "enterFullAddress": MessageLookupByLibrary.simpleMessage(
            "Introduce o Enderezo Completo"),
        "enterInvoiceNumber": MessageLookupByLibrary.simpleMessage(
            "Introduza o número de factura"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Introduza a cantidade de alerta de baixo stock"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Introducir Fabricante"),
        "enterMessageContent": MessageLookupByLibrary.simpleMessage(
            "Introduza o contido do mensaje"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "Introducir MRP/Prezo de Venda"),
        "enterName": MessageLookupByLibrary.simpleMessage("Introduce o Nome"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Introduce a Nota"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Introduce o Nome da Parte"),
        "enterPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Introduce o Número de Teléfono"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Introducir Código do Produto ou Escanear"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Introducir Nome do Produto"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Introducir Prezo de Compra."),
        "enterReferenceNumber": MessageLookupByLibrary.simpleMessage(
            "Introduce o Número de Referencia"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Introducir Tamaño"),
        "enterStocks":
            MessageLookupByLibrary.simpleMessage("Introducir Accións."),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Introduce a taxa de imposto"),
        "enterTransactionId": MessageLookupByLibrary.simpleMessage(
            "Introducir ID de Transacción"),
        "enterType": MessageLookupByLibrary.simpleMessage("Introducir Tipo"),
        "enterUserTitle": MessageLookupByLibrary.simpleMessage(
            "Introduza o título do usuario"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Introduce un importe válido"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Introduce o nome do almacén"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Introducir Peso"),
        "enterWholeSalePrice": MessageLookupByLibrary.simpleMessage(
            "Introducir Prezo de Venda por Xunto"),
        "enterYourDescriptionHere": MessageLookupByLibrary.simpleMessage(
            "Introduza a súa descrición aquí"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "Introduce a túa Dirección de Correo Electrónico"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "Introduza o título da súa opinión"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Introduce o teu número GST"),
        "enterYourMobileNumber": MessageLookupByLibrary.simpleMessage(
            "Introduza o seu número de móbil"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Introduce o Teu Nome"),
        "enterYourNumber": MessageLookupByLibrary.simpleMessage(
            "Introduce o teu número de teléfono"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Introduza a súa contrasinal"),
        "enterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Introduce o Teu Número de Teléfono"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "Introduza o seu ID de transacción"),
        "error": MessageLookupByLibrary.simpleMessage("Erro"),
        "excTax": MessageLookupByLibrary.simpleMessage("Exclúe imposto"),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("Cargador de Excel"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Exclusivo"),
        "expense": MessageLookupByLibrary.simpleMessage("Gastos"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Categoría de Desembolso"),
        "expenseDate":
            MessageLookupByLibrary.simpleMessage("Data do Desembolso"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Desembolso Para"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Informe de Desembolsos"),
        "expireDate":
            MessageLookupByLibrary.simpleMessage("Data de caducidade"),
        "expired": MessageLookupByLibrary.simpleMessage("Caducado"),
        "expiring": MessageLookupByLibrary.simpleMessage("Caducando"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Fallou con erro"),
        "fashion": MessageLookupByLibrary.simpleMessage("Moda"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "As características son a parte importante que fai que Pos Saas sexa diferente das solucións tradicionais."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Opinión"),
        "firstName": MessageLookupByLibrary.simpleMessage("Primeiro Nome"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Síguenos en\nFacebook"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Síguenos en\nTwitter"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Lado frontal"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("Para usos ilimitados"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Olvidaches a contrasinal?"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Olvidaches a Contrasinal?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Desde a Data"),
        "freeDataBackup": MessageLookupByLibrary.simpleMessage(
            "Copia de seguridade de datos gratuíta"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "Actualización de por vida gratuíta"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Paquete gratuíto"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Plan gratuíto"),
        "from": MessageLookupByLibrary.simpleMessage("(Desde"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Total pagado"),
        "gallary": MessageLookupByLibrary.simpleMessage("Galería"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("Xenerando PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Obter OTP"),
        "govermentId":
            MessageLookupByLibrary.simpleMessage("Identificación do goberno"),
        "guest": MessageLookupByLibrary.simpleMessage("Convidado"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Non tes ningunha conta?"),
        "history": MessageLookupByLibrary.simpleMessage("Historia"),
        "home": MessageLookupByLibrary.simpleMessage("Inicio"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Como protexemos a súa información"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Como utilizamos a súa información"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Verificación de identidade"),
        "image": MessageLookupByLibrary.simpleMessage("Imaxe"),
        "inHouseCantBeDelete": MessageLookupByLibrary.simpleMessage(
            "Non se pode eliminar en casa"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("Non se pode editar en casa"),
        "inWord": MessageLookupByLibrary.simpleMessage("En palabras"),
        "incTax": MessageLookupByLibrary.simpleMessage("Inclúe imposto"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Incluínte"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("Aumentar stock"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Instrumento"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("No. de Inv."),
        "invoice": MessageLookupByLibrary.simpleMessage("Factura"),
        "invoiceNumber":
            MessageLookupByLibrary.simpleMessage("Número de factura"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Configuración da factura"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Visor de facturas"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Elemento Engadido"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("Verificación KYC"),
        "language": MessageLookupByLibrary.simpleMessage("Idioma"),
        "lastName": MessageLookupByLibrary.simpleMessage("Último Nome"),
        "ledger": MessageLookupByLibrary.simpleMessage("Libro de Contas"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Compra de por vida"),
        "link": MessageLookupByLibrary.simpleMessage("Ligazón"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Soporte por chat en directo"),
        "loading": MessageLookupByLibrary.simpleMessage("Cargando"),
        "logIn": MessageLookupByLibrary.simpleMessage("Iniciar Sesión"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Cerrar sesión"),
        "logOut": MessageLookupByLibrary.simpleMessage("Desconectar"),
        "login": MessageLookupByLibrary.simpleMessage("Iniciar Sesión"),
        "logo": MessageLookupByLibrary.simpleMessage("Logotipo"),
        "loss": MessageLookupByLibrary.simpleMessage("Pérdida"),
        "lossOrProfit":
            MessageLookupByLibrary.simpleMessage("Pérdida/Ganancia"),
        "lossOrProfitDetails": MessageLookupByLibrary.simpleMessage(
            "Detalles de Pérdida/Ganancia"),
        "lossProfitReport": MessageLookupByLibrary.simpleMessage(
            "Informe de perdas/beneficios"),
        "lossProfitReports": MessageLookupByLibrary.simpleMessage(
            "Informes de perdas/beneficios"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Alerta de baixo stock"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Faga unha impresión duradeira nos seus clientes con facturas personalizadas. A nosa actualización ilimitada ofrece a vantaxe única de personalizar as súas facturas, engadindo un toque profesional que reforza a súa identidade de marca e fomenta a lealdade do cliente."),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("Xestiona o teu negocio con"),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Data de fabricación"),
        "margin": MessageLookupByLibrary.simpleMessage("Margen"),
        "masterCard": MessageLookupByLibrary.simpleMessage("MasterCard"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Fabricante"),
        "message": MessageLookupByLibrary.simpleMessage("Mensaxe"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Historial de mensaxes"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "A aplicación Pos Saas é gratuíta, fácil de usar. De feito, é un dos mellores sistemas POS do mundo."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas é unha solución empresarial completa con stock, contabilidade, vendas, gastos e beneficios/pérdidas."),
        "mobile": MessageLookupByLibrary.simpleMessage("Móbil"),
        "mobilePayment":
            MessageLookupByLibrary.simpleMessage("Pagamento móbil"),
        "monthly": MessageLookupByLibrary.simpleMessage("Mensual"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("Máis Información"),
        "name": MessageLookupByLibrary.simpleMessage("Introduce o Teu Nome."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("O nome xa existe"),
        "nameCantBeEmpty": MessageLookupByLibrary.simpleMessage(
            "O nome non pode estar baleiro"),
        "next": MessageLookupByLibrary.simpleMessage("Seguinte"),
        "noConnection": MessageLookupByLibrary.simpleMessage("Sen Conexión"),
        "noData": MessageLookupByLibrary.simpleMessage("Sen datos"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Non hai datos dispoñibles"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Non se atoparon datos"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("¡Sen historial encontrado!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Ningún produto atopado"),
        "noSubTaxSelected": MessageLookupByLibrary.simpleMessage(
            "Non se seleccionou ningunha subtaxa"),
        "noTransactionFound": MessageLookupByLibrary.simpleMessage(
            "¡Sen transacción encontrada!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Non se atopou ningún usuario para ese correo electrónico."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "Non se atopou ningún rol de usuario"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Non usuario activo"),
        "notProvided":
            MessageLookupByLibrary.simpleMessage("Non proporcionado"),
        "note": MessageLookupByLibrary.simpleMessage("Nota"),
        "notes": MessageLookupByLibrary.simpleMessage("Notas"),
        "notification": MessageLookupByLibrary.simpleMessage("Notificación"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP enviado a"),
        "office": MessageLookupByLibrary.simpleMessage("Oficina"),
        "ok": MessageLookupByLibrary.simpleMessage("De acordo"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS que contén unha gran cantidade de funcionalidade, incluíndo seguimento de vendas, xestión de inventario."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Este sistema axúdalle a mellorar as súas operacións para os seus clientes."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "O noso sistema POS debería simplificar as operacións diarias de forma automática, facilitando a navegación."),
        "openingBalance": MessageLookupByLibrary.simpleMessage("Saldo Inicial"),
        "order": MessageLookupByLibrary.simpleMessage("Encomendas"),
        "other": MessageLookupByLibrary.simpleMessage("Outro"),
        "otp": MessageLookupByLibrary.simpleMessage("Pechar"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Agotado"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Paquete"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Características do paquete"),
        "paid": MessageLookupByLibrary.simpleMessage("Pagado"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Cantidade Pagada"),
        "parties": MessageLookupByLibrary.simpleMessage("Partes"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Lista de Partes"),
        "partyGST": MessageLookupByLibrary.simpleMessage("GST da parte"),
        "partyName": MessageLookupByLibrary.simpleMessage("Nome da Parte"),
        "password": MessageLookupByLibrary.simpleMessage("Contrasinal"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "A contrasinal e a confirmación da contrasinal non coinciden"),
        "passwordCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "A contrasinal non pode estar baleiro"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("A contrasinal non coincide"),
        "payCash": MessageLookupByLibrary.simpleMessage("Pagar en efectivo"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash": MessageLookupByLibrary.simpleMessage("Pagar con bkash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Paga con Paypal"),
        "payeeName":
            MessageLookupByLibrary.simpleMessage("Nome do beneficiario"),
        "payeeNumber":
            MessageLookupByLibrary.simpleMessage("Número do beneficiario"),
        "payment": MessageLookupByLibrary.simpleMessage("Pago"),
        "paymentAmount":
            MessageLookupByLibrary.simpleMessage("Cantidade de Pago"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Pago Completado"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Instruccións de pagamento:"),
        "paymentMethod":
            MessageLookupByLibrary.simpleMessage("Método de pagamento"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Tipo de Pago"),
        "pdfView": MessageLookupByLibrary.simpleMessage("Vista PDF"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Información persoal"),
        "phone": MessageLookupByLibrary.simpleMessage("Teléfono"),
        "phoneNumber":
            MessageLookupByLibrary.simpleMessage("Número de Teléfono"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Número de teléfono xa utilizado"),
        "phoneNumberIsNotValid": MessageLookupByLibrary.simpleMessage(
            "O número de teléfono non é válido"),
        "phoneNumberIsRequired": MessageLookupByLibrary.simpleMessage(
            "O número de teléfono é necesario"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("Elixa e cargue o arquivo"),
        "pickEndDate": MessageLookupByLibrary.simpleMessage(
            "Escolla a data de finalización"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Escolla a data de inicio"),
        "plan": MessageLookupByLibrary.simpleMessage("Plan"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("Por favor, engada cantidade"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Por favor, comproba a túa conectividade a Internet"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Por favor, conecta primeiro a impresora"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Por favor, conecta a túa impresora Bluetooth"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Por favor, introduce unha contrasinal máis longa"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Por favor, Introduce un Contrasinal de Confirmación"),
        "pleaseEnterAPassword": MessageLookupByLibrary.simpleMessage(
            "Por favor, introduce unha contrasinal"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Por favor, introduce un correo electrónico válido"),
        "pleaseEnterName": MessageLookupByLibrary.simpleMessage(
            "Por favor, introduce un nome"),
        "pleaseEnterPassword": MessageLookupByLibrary.simpleMessage(
            "Por favor, introduce a contrasinal"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Por favor, introduce a túa dirección de correo electrónico abaixo para recibir o enlace de restablecemento da contrasinal."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Por favor, introduce o número de transacción"),
        "pleaseInterAmount": MessageLookupByLibrary.simpleMessage(
            "Por favor, introduce o importe"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Por favor, selecciona unha categoría primeiro"),
        "pleaseSelectAPlan": MessageLookupByLibrary.simpleMessage(
            "Por favor, selecciona un plan"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Por favor, selecciona a categoría empresarial"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Por favor, usa o código de compra válido para usar a aplicación"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Desenvolvido por Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Desenvolvido por"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Soporte ao cliente premium"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Plan premium"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Importes de pago anteriores"),
        "price": MessageLookupByLibrary.simpleMessage("prezo"),
        "print": MessageLookupByLibrary.simpleMessage("Imprimir"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Opcións de impresión"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Política de Privacidade"),
        "product": MessageLookupByLibrary.simpleMessage("Produto"),
        "productCode":
            MessageLookupByLibrary.simpleMessage("Código do Produto"),
        "productCodeIsRequired": MessageLookupByLibrary.simpleMessage(
            "O código do produto é necesario"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Código/nome do produto"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Descrición do produto"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Detalles do produto"),
        "productList":
            MessageLookupByLibrary.simpleMessage("Lista de Produtos"),
        "productName": MessageLookupByLibrary.simpleMessage("Nome do Produto"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "O nome do produto xa existe neste almacén"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "O nome do produto xa foi engadido"),
        "productNameIsRequired": MessageLookupByLibrary.simpleMessage(
            "O nome do produto é necesario"),
        "products": MessageLookupByLibrary.simpleMessage("Produtos"),
        "profile": MessageLookupByLibrary.simpleMessage("Perfil"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("Editar perfil"),
        "profit": MessageLookupByLibrary.simpleMessage("Ganancia"),
        "promo": MessageLookupByLibrary.simpleMessage("promo"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Código promocional"),
        "purchase": MessageLookupByLibrary.simpleMessage("Compra"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("Alarma de Compra"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Compra Confirmada"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Detalles da compra"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Factura de compra"),
        "purchaseList":
            MessageLookupByLibrary.simpleMessage("Lista de compras"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Compra agora"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Comprar plan premium"),
        "purchasePrice":
            MessageLookupByLibrary.simpleMessage("Prezo de Compra"),
        "purchasePriceIsRequired": MessageLookupByLibrary.simpleMessage(
            "O prezo de compra é necesario"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("Informe de compra"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Prezo de compra"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Informes de Compra"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("Devolución de compra"),
        "purchaseReturnReport": MessageLookupByLibrary.simpleMessage(
            "Informe de devolución de compra"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Transición de compra"),
        "qty": MessageLookupByLibrary.simpleMessage("Cant."),
        "quantity": MessageLookupByLibrary.simpleMessage("Cantidade"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Transaccións Recentes"),
        "recivedThePin": MessageLookupByLibrary.simpleMessage("Recibín o PIN"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Número de Referencia"),
        "register": MessageLookupByLibrary.simpleMessage("Registrar"),
        "registering": MessageLookupByLibrary.simpleMessage("Registrando"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("Débeda Restante"),
        "remove": MessageLookupByLibrary.simpleMessage("Eliminar"),
        "reports": MessageLookupByLibrary.simpleMessage("Informes"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("A solicitude foi enviada"),
        "resendCode": MessageLookupByLibrary.simpleMessage("Reenviar Código"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("Reenviar OTP:"),
        "retailer": MessageLookupByLibrary.simpleMessage("Minorista"),
        "retur": MessageLookupByLibrary.simpleMessage("Devolución"),
        "returN": MessageLookupByLibrary.simpleMessage("Devolución"),
        "returnAMount":
            MessageLookupByLibrary.simpleMessage("Devolución de Cantidade"),
        "returnAmount":
            MessageLookupByLibrary.simpleMessage("Importe de devolución"),
        "returnQTY":
            MessageLookupByLibrary.simpleMessage("Cantidade de devolución"),
        "revenue": MessageLookupByLibrary.simpleMessage("Receita"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Protexa os datos do seu negocio sen esforzo. A nosa actualización Pos Saas POS Ilimitada inclúe copia de seguridade de datos gratuíta, garantindo que a súa valiosa información esté protexida contra calquera evento imprevisto. Concéntrese no que realmente importa: o crecemento do seu negocio."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Importe da venda"),
        "saleDetails":
            MessageLookupByLibrary.simpleMessage("Detalles da venda"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Prezo de venda"),
        "saleReports":
            MessageLookupByLibrary.simpleMessage("Informe de vendas"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Informes de Venda"),
        "saleReturn":
            MessageLookupByLibrary.simpleMessage("Devolución de venda"),
        "saleReturnReport": MessageLookupByLibrary.simpleMessage(
            "Informe de devolución de venda"),
        "saleSetting":
            MessageLookupByLibrary.simpleMessage("Configuración de venda"),
        "sales": MessageLookupByLibrary.simpleMessage("Vendas"),
        "salesAndPurchaseReports": MessageLookupByLibrary.simpleMessage(
            "Informes de vendas e compras"),
        "salesList": MessageLookupByLibrary.simpleMessage("Lista de vendas"),
        "salesReturn":
            MessageLookupByLibrary.simpleMessage("Devolución de vendas"),
        "save": MessageLookupByLibrary.simpleMessage("Gardar"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Gardar e Publicar"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("Gardar cambios"),
        "saving": MessageLookupByLibrary.simpleMessage("Gardando"),
        "scanProductQRCode": MessageLookupByLibrary.simpleMessage(
            "Escanear o código QR do produto"),
        "search": MessageLookupByLibrary.simpleMessage("Buscar"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Busque por código ou nome do produto"),
        "seeAllPromoCode": MessageLookupByLibrary.simpleMessage(
            "Ver todos os códigos promocionais"),
        "select": MessageLookupByLibrary.simpleMessage("Seleccionar"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Seleccione un produto para devolver"),
        "selectBrand":
            MessageLookupByLibrary.simpleMessage("Selecciona a marca"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Selecciona a categoría"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Seleccionar contactos"),
        "selectProductCategory": MessageLookupByLibrary.simpleMessage(
            "Selecciona a categoría do produto"),
        "selectShopCategory": MessageLookupByLibrary.simpleMessage(
            "Selecciona a categoría da tenda"),
        "selectTax":
            MessageLookupByLibrary.simpleMessage("Selecciona o imposto"),
        "selectTaxType": MessageLookupByLibrary.simpleMessage(
            "Selecciona o tipo de imposto"),
        "selectUnit":
            MessageLookupByLibrary.simpleMessage("Selecciona a unidade"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Seleccionar Variación: "),
        "seller": MessageLookupByLibrary.simpleMessage("Vendedor"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Vendido por"),
        "send": MessageLookupByLibrary.simpleMessage("Enviar"),
        "sendEmail":
            MessageLookupByLibrary.simpleMessage("Enviar Correo Electrónico"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Enviar mensaxe"),
        "sendResetLink": MessageLookupByLibrary.simpleMessage(
            "Enviar Enlace de Restablecemento"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Enviar SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Enviar sms?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Enviar mensaxe por whatsapp"),
        "sendYOurEmail": MessageLookupByLibrary.simpleMessage(
            "Envía o seu correo electrónico"),
        "sendingEmail":
            MessageLookupByLibrary.simpleMessage("Enviando correo electrónico"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Enviando mensaxe"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Servizo/Envío"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Configura o Teu Perfil"),
        "setting": MessageLookupByLibrary.simpleMessage("Configuración"),
        "share": MessageLookupByLibrary.simpleMessage("Compartir"),
        "shopGST": MessageLookupByLibrary.simpleMessage("GST da tenda"),
        "signIn": MessageLookupByLibrary.simpleMessage("Iniciar sesión"),
        "signInWithEmail": MessageLookupByLibrary.simpleMessage(
            "Inicia sesión co correo electrónico"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Sinatura do cliente"),
        "size": MessageLookupByLibrary.simpleMessage("Tamaño"),
        "skip": MessageLookupByLibrary.simpleMessage("Saltar"),
        "sms": MessageLookupByLibrary.simpleMessage("Sms"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Marketing Social"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Desculpa, non tes permiso para acceder a este servizo"),
        "startDate": MessageLookupByLibrary.simpleMessage("Data de inicio"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Comezar Nova Venda"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage(
            "Comeza a escribir para buscar"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Mantéñase á vangarda dos avances tecnolóxicos sen custos adicionais. A nosa actualización de Pos Saas POS ilimitada asegura que sempre teña as ferramentas e características máis recentes ao seu alcance, garantindo que o seu negocio siga a ser de última xeración."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("Aínda non pagado"),
        "stock": MessageLookupByLibrary.simpleMessage("Stock"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("O stock é necesario"),
        "stockList": MessageLookupByLibrary.simpleMessage("Lista de Stock"),
        "stocks": MessageLookupByLibrary.simpleMessage("Accións"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "É necesario permiso de almacenamento para crear un arquivo Excel"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("Lista de subtaxas"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Subtaxas"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Subtotal"),
        "submit": MessageLookupByLibrary.simpleMessage("Enviar"),
        "subscribeToOurYoutube":
            MessageLookupByLibrary.simpleMessage("Suscríbete ao noso\nYoutube"),
        "subscription": MessageLookupByLibrary.simpleMessage("Subscripción"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Realizado con éxito"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Desconectado con éxito"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Actualizado con éxito"),
        "supplier": MessageLookupByLibrary.simpleMessage("Provedor"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("Nome do Provedor"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("Código SWIFT"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Tome unha foto do carné de conducir, do DNI ou do pasaporte"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "Tome un carné de identidade para verificar a súa información"),
        "tap": MessageLookupByLibrary.simpleMessage("Tocar"),
        "tax": MessageLookupByLibrary.simpleMessage("Imposto"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Grupo de impostos"),
        "taxPercentage":
            MessageLookupByLibrary.simpleMessage("Porcentaxe de imposto"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Taxa de imposto"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Taxas de impostos - Xestiona as túas taxas de impostos"),
        "taxReport":
            MessageLookupByLibrary.simpleMessage("Informe de impostos"),
        "taxType": MessageLookupByLibrary.simpleMessage("Tipo de imposto"),
        "taxes": MessageLookupByLibrary.simpleMessage("Impostos"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Termos e condicións"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("Termos de Uso"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Termos e Privacidade"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Grazas polo Teu Pago Debedor"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Grazas"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Grazas pola súa compra"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "A conta xa existe para ese correo electrónico"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "O arquivo Excel xa foi descargado"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "O nome o di todo. Con Pos Saas POS Ilimitado, non hai límite no seu uso. Estea procesando un puñado de transaccións ou experimentando unha afluencia de clientes, pode operar con confianza, sabendo que non está limitado."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "A contrasinal proporcionada é demasiado débil"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "A venda será eliminada e todos os datos sobre esta compra serán eliminados. Está seguro de que quere eliminar isto?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "A venda será eliminada e todos os datos sobre esta venda serán eliminados. Está seguro de que quere eliminar isto?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "O usuario será borrado e todos os datos eliminaranse da túa conta. Estás seguro de que queres borrar isto?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "O usuario será eliminado e todos os datos serán eliminados da túa conta. Estás seguro de que queres eliminar isto?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Servizos de terceiros"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Esta categoría non se pode eliminar"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Este mes)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Este produto xa foi engadido"),
        "title": MessageLookupByLibrary.simpleMessage("Título"),
        "titleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "O título non pode estar baleiro"),
        "to": MessageLookupByLibrary.simpleMessage("a"),
        "toDate": MessageLookupByLibrary.simpleMessage("Ata a Data"),
        "today": MessageLookupByLibrary.simpleMessage("Hoxe"),
        "total": MessageLookupByLibrary.simpleMessage("Total"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Cantidade Total"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Total recadado"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Total Debido"),
        "totalExpense":
            MessageLookupByLibrary.simpleMessage("Desembolso Total"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Pérdida total"),
        "totalPayable": MessageLookupByLibrary.simpleMessage("Total a Pagar"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Prezo Total"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("Total de produtos"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Beneficio total"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("Compra total"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Importe total de devolución"),
        "totalReturns":
            MessageLookupByLibrary.simpleMessage("Total de devolucións"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Total de Vendas"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Total de stocks"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Valor total"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Total IVA"),
        "totals": MessageLookupByLibrary.simpleMessage("Total: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Transacción"),
        "transactionId":
            MessageLookupByLibrary.simpleMessage("ID da transacción"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Intenta de Novo"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Tipo"),
        "unitName": MessageLookupByLibrary.simpleMessage("Nome da Unidade"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Prezo por Unidade"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Prezo por unidade"),
        "units": MessageLookupByLibrary.simpleMessage("Unidades"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Ilimitado"),
        "unlimitedUsage": MessageLookupByLibrary.simpleMessage("Uso ilimitado"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Desbloquea todo o potencial de Pos Saas POS con sesións de formación personalizadas dirixidas polo noso equipo de expertos. Desde os conceptos básicos até as técnicas avanzadas, asegurámonos de que estés ben versado na utilización de cada faceta do sistema para optimizar os teus procesos empresariais."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Non pagado"),
        "update": MessageLookupByLibrary.simpleMessage("Actualizar"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Actualizar Contacto"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Actualizar Agora"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("Actualizar Produto"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Actualiza o teu plan primeiro,\\ o teu límite está esgotado"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Actualizar o Seu Perfil"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Actualiza o teu perfil para conectar ao teu médico con unha mellor impresión"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Actualiza o seu perfil para conectar co seu cliente cunha mellor impresión"),
        "updated": MessageLookupByLibrary.simpleMessage("Actualizado"),
        "upload": MessageLookupByLibrary.simpleMessage("Cargar"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Subir Documento"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("Carga completa"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Subir Ficheiro"),
        "upplier": MessageLookupByLibrary.simpleMessage("Provedor"),
        "usbC": MessageLookupByLibrary.simpleMessage("Usb C"),
        "use": MessageLookupByLibrary.simpleMessage("Usar"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("Usa Pos Saas"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Uso do sistema"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("O usuario foi eliminado"),
        "userRole": MessageLookupByLibrary.simpleMessage("Rol do usuario"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("Detalles do Rol do Usuario"),
        "userTitle": MessageLookupByLibrary.simpleMessage("Título do usuario"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "O título do usuario non pode estar baleiro"),
        "value": MessageLookupByLibrary.simpleMessage("Valor"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("O IVA non se aplica"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("Verificando OTP"),
        "verifyPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Verificar Número de Teléfono"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Ver Todo"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("Ver detalles"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Cliente que entra"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Almacén"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("O almacén xa existe"),
        "warehouseList":
            MessageLookupByLibrary.simpleMessage("Lista de almacéns"),
        "warehouseName":
            MessageLookupByLibrary.simpleMessage("Nome do almacén"),
        "warranty": MessageLookupByLibrary.simpleMessage("Garantía"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Envíaus un correo electrónico con instrucións sobre como restablecer a contrasinal a:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Podemos usar servizos de terceiros para apoiar a funcionalidade da nosa aplicación, como provedores de analíticas e procesadores de pagos. Estes servizos de terceiros poden recoller información sobre vostede cando usa a nosa aplicación. Teña en conta que non somos responsables das prácticas de privacidade destes servizos de terceiros."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Tomamos medidas estándar da industria para protexer a súa información persoal, incluíndo cifrado e almacenamento seguro. Tamén limitamos o acceso á súa información só ao persoal autorizado."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Entendemos a importancia de operacións sen fisuras. É por iso que o noso soporte 24 horas está dispoñible para axudarche, xa sexa cunha consulta rápida ou cunha preocupación ampla. Conéctate connosco en calquera momento e en calquera lugar a través de chamada ou WhatsApp para experimentar un servizo ao cliente sen igual."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Utilizamos a súa información persoal para ofrecerlle a mellor experiencia posible na nosa aplicación, incluíndo personalizar as súas recomendacións de contido, conectalo con expertos e mellorar a funcionalidade das nosas aplicacións. Tamén podemos usar a súa información para comunicarnos con vostede sobre actualizacións, promocións ou outras informacións relacionadas coa nosa aplicación."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Revisaremos o pagamento e aprobámo-lo dentro de 1-2 horas"),
        "weekly": MessageLookupByLibrary.simpleMessage("Semanal"),
        "weight": MessageLookupByLibrary.simpleMessage("Peso"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Novidades"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Mayorista"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Prezo de Venda por Xunto"),
        "wholesalePrice":
            MessageLookupByLibrary.simpleMessage("Prezo ao por maior"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Distribuidor"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Serán engadidos pronto"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Caducará en"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Escriba a súa mensaxe aquí"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("OTP incorrecto"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Contrasinal incorrecto proporcionado para ese usuario."),
        "yearly": MessageLookupByLibrary.simpleMessage("Anual"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Si, Borrar Para Sempre"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("Non es un usuario válido"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Estás usando"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Non podes pagar máis do que debes"),
        "youHaveGotAnEmail": MessageLookupByLibrary.simpleMessage(
            "Recibiches un Correo Electrónico"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Iniciaste sesión correctamente na túa conta. Quédate con Pos Saas."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("Debes conceder permiso"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Ten que volver iniciar sesión na súa conta."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Necesita verificar a identidade antes de comprar sms"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("A súa mensaxe permanece"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("O teu paquete"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "O teu paquete expira en 5 días")
      };
}
