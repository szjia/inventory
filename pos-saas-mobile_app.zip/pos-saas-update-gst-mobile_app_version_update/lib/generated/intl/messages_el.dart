// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a el locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'el';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Συνέχεια"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("Αριθμός GST"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP":
            MessageLookupByLibrary.simpleMessage("Τιμή Πώλησης Λιανικής (MRP)"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("Η MRP είναι υποχρεωτική"),
        "OK": MessageLookupByLibrary.simpleMessage("Εντάξει"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Τηλ."),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("Α/Α"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT Κωδικός"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Σνακ"),
        "TAX": MessageLookupByLibrary.simpleMessage("ΦΟΡΟΣ"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Ανέβασμα"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("Τίτλος χρήστη"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Your Package Will Expire Today\nPlease Purchase again"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(α) Το Σύστημα παρέχεται αποκλειστικά για τον σκοπό της διευκόλυνσης των συναλλαγών σημείου πώλησης και σχετικών δραστηριοτήτων στην επιχείρησή σας."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(α) Για να χρησιμοποιήσετε το Σύστημα, μπορεί να απαιτείται η δημιουργία ενός λογαριασμού. Συμφωνείτε να παρέχετε ακριβείς, ενημερωμένες και πλήρεις πληροφορίες κατά τη διάρκεια της διαδικασίας εγγραφής και να ενημερώνετε αυτές τις πληροφορίες για να τις διατηρείτε ακριβείς και πλήρεις."),
        "aboutApp":
            MessageLookupByLibrary.simpleMessage("Σχετικά με την εφαρμογή"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Σχετικά με εμάς"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Αποδοχή Όρων"),
        "accountName":
            MessageLookupByLibrary.simpleMessage("Όνομα λογαριασμού"),
        "accountNumber":
            MessageLookupByLibrary.simpleMessage("Αριθμός λογαριασμού"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Εγγραφή Λογαριασμού"),
        "acton": MessageLookupByLibrary.simpleMessage("Δράση"),
        "add": MessageLookupByLibrary.simpleMessage("Προσθήκη"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Προσθήκη Μάρκας"),
        "addCategory":
            MessageLookupByLibrary.simpleMessage("Προσθήκη Κατηγορίας"),
        "addContact": MessageLookupByLibrary.simpleMessage("Προσθήκη Επαφής"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Προσθήκη Πελάτη"),
        "addDelivery":
            MessageLookupByLibrary.simpleMessage("Προσθήκη Παράδοσης"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Προσθέστε Περιγραφή"),
        "addDescription":
            MessageLookupByLibrary.simpleMessage("Προσθήκη σημείωσης"),
        "addDiscount":
            MessageLookupByLibrary.simpleMessage("Προσθήκη έκπτωσης"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Add Document Id"),
        "addDucument": MessageLookupByLibrary.simpleMessage("Add Document"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Προσθήκη Έξοδου"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Προσθήκη Κατηγορίας Έξοδου"),
        "addItems":
            MessageLookupByLibrary.simpleMessage("Προσθήκη Αντικειμένων"),
        "addNew": MessageLookupByLibrary.simpleMessage("Προσθέστε Νέο"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Προσθήκη Νέας Διεύθυνσης"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Προσθήκη Νέου Προϊόντος"),
        "addNewTax":
            MessageLookupByLibrary.simpleMessage("Προσθήκη νέου φόρου"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Προσθήκη νέου φόρου με τύπο φόρου ενός/πολλών"),
        "addNote": MessageLookupByLibrary.simpleMessage("Προσθήκη Σημείωσης"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Προσθέστε πρώτα προϊόν"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Προσθήκη κωδικού προώθησης"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Προσθήκη Αγοράς"),
        "addSales": MessageLookupByLibrary.simpleMessage("Προσθήκη Πωλήσεων"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Προστέθηκε με επιτυχία"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Προσθήκη Μονάδας"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Προσθήκη ρόλου χρήστη"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Προστέθηκε με επιτυχία"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("Προστέθηκε στο καλάθι"),
        "address": MessageLookupByLibrary.simpleMessage("Διεύθυνση"),
        "admin": MessageLookupByLibrary.simpleMessage("Διαχειριστής"),
        "all": MessageLookupByLibrary.simpleMessage("Όλα"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("All business solutions"),
        "alreadyAdded":
            MessageLookupByLibrary.simpleMessage("Έχει ήδη προστεθεί"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Ήδη υπάρχει"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Ήδη Έχετε Λογαριασμό"),
        "amount": MessageLookupByLibrary.simpleMessage("Ποσό"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "Έχει σταλεί ένα email\nΕλέγξτε το εισερχόμενο σας"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Υποστήριξη εφαρμογών Android & iOS"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Εφαρμόσιμος φόρος"),
        "apply": MessageLookupByLibrary.simpleMessage("Εφαρμογή"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Είστε σίγουροι ότι θέλετε να διαγράψετε αυτό το τιμολόγιο;"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Είστε σίγουροι ότι θέλετε να διαγράψετε αυτή την πώληση;"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Είστε σίγουροι ότι θέλετε να διαγράψετε αυτόν τον χρήστη;"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Είστε σίγουροι ότι θέλετε να διαγράψετε αυτόν τον φόρο;"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Είστε σίγουροι ότι θέλετε να διαγράψετε αυτήν την ομάδα φόρου;"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Θέλετε να διαγράψετε αυτή την αποθήκη;"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Είστε σίγουροι ότι θέλετε να διαγράψετε αυτόν τον χρήστη;"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Εξουσιοδοτημένη υπογραφή"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(β) Είστε υπεύθυνοι για τη διατήρηση της εμπιστευτικότητας του λογαριασμού σας και του κωδικού πρόσβασής σας και για τον περιορισμό της πρόσβασης στον λογαριασμό σας. Αποδέχεστε την ευθύνη για όλες τις δραστηριότητες που συμβαίνουν υπό τον λογαριασμό σας."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(β) Πρέπει να είστε τουλάχιστον 18 ετών ή της νόμιμης ηλικίας της πλειοψηφίας στη δικαιοδοσία σας για να χρησιμοποιήσετε το Σύστημα."),
        "backSide": MessageLookupByLibrary.simpleMessage("Back side"),
        "backToHome": MessageLookupByLibrary.simpleMessage("Back To Home"),
        "balance": MessageLookupByLibrary.simpleMessage("Υπόλοιπο"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Μπανγκλαντές"),
        "bank": MessageLookupByLibrary.simpleMessage("Τράπεζα"),
        "bankAccountCurrency": MessageLookupByLibrary.simpleMessage(
            "Νόμισμα τραπεζικού λογαριασμού"),
        "bankAccountingCurrecny": MessageLookupByLibrary.simpleMessage(
            "Νομισματική μονάδα τραπεζικού λογαριασμού"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Τραπεζικές πληροφορίες"),
        "bankName": MessageLookupByLibrary.simpleMessage("Όνομα τράπεζας"),
        "bankTransfer":
            MessageLookupByLibrary.simpleMessage("Τραπεζική μεταφορά"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Βρέθηκε γραμμωτός κωδικός"),
        "billInvoice":
            MessageLookupByLibrary.simpleMessage("Λογαριασμός/Τιμολόγιο"),
        "billTo": MessageLookupByLibrary.simpleMessage("Χρέωση Προς"),
        "branchName": MessageLookupByLibrary.simpleMessage("Όνομα κλαδιού"),
        "brand": MessageLookupByLibrary.simpleMessage("Μάρκα"),
        "brandName": MessageLookupByLibrary.simpleMessage("Όνομα Μάρκας"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("Ομαδικό\nΑνέβασμα"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Κατηγορία επιχείρησης"),
        "buy": MessageLookupByLibrary.simpleMessage("Αγορά"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Buy Premium Plan"),
        "buySms": MessageLookupByLibrary.simpleMessage("Buy Sms"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Με την πρόσβαση ή τη χρήση του Συστήματος Σημείου Πώλησης (POS) (του \"Συστήματος\") που παρέχεται από [Το Όνομα της Εταιρείας σας] (τη \"Εταιρεία\"), συμφωνείτε να υποκείστε σε αυτούς τους Όρους Χρήσης. Αν δεν συμφωνείτε με αυτούς τους Όρους Χρήσης, μη χρησιμοποιείτε το Σύστημα."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(γ) Είστε υπεύθυνοι για τη διασφάλιση ότι η πρόσβαση και η χρήση του Συστήματος συμμορφώνονται με όλους τους ισχύοντες νόμους και κανονιστικές απαιτήσεις."),
        "cacel": MessageLookupByLibrary.simpleMessage("Ακύρωση"),
        "call": MessageLookupByLibrary.simpleMessage("Κλήση"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "Καλέστε για έκτακτη υποστήριξη"),
        "camera": MessageLookupByLibrary.simpleMessage("Φωτογραφική μηχανή"),
        "cancel": MessageLookupByLibrary.simpleMessage("Ακύρωση"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Ακύρωση όλων των προϊόντων"),
        "capacity": MessageLookupByLibrary.simpleMessage("Χωρητικότητα"),
        "card": MessageLookupByLibrary.simpleMessage("Κάρτα"),
        "cash": MessageLookupByLibrary.simpleMessage("Μετρητά"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Κατηγορίες"),
        "category": MessageLookupByLibrary.simpleMessage("Κατηγορία"),
        "categoryName":
            MessageLookupByLibrary.simpleMessage("Όνομα Κατηγορίας"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "Το Όνομα Κατηγορίας Υπάρχει Ήδη"),
        "cateogryName":
            MessageLookupByLibrary.simpleMessage("Όνομα Κατηγορίας"),
        "change": MessageLookupByLibrary.simpleMessage("Αλλαγή;"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Αλλαγή Κωδικού"),
        "checkEmail":
            MessageLookupByLibrary.simpleMessage("Ελέγξτε το email σας"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Επιλέξτε έναν Πελάτη"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Επιλέξτε έναν Προμηθευτή"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Choose your features"),
        "clarence": MessageLookupByLibrary.simpleMessage("Clarence"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Κάντε κλικ για σύνδεση"),
        "close": MessageLookupByLibrary.simpleMessage("Κλείσιμο"),
        "color": MessageLookupByLibrary.simpleMessage("Χρώμα"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(Συνδυασμός πολλαπλών φόρων)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Έρχεται σύντομα"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Διεύθυνση εταιρείας"),
        "companyAndShopName": MessageLookupByLibrary.simpleMessage(
            "Όνομα εταιρείας και καταστήματος"),
        "companyBusinessName": MessageLookupByLibrary.simpleMessage(
            "Όνομα Εταιρείας & Επιχείρησης"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Complete Transaction"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Επιβεβαίωση Κωδικού"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Επιβεβαίωση επιστροφής"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Συγχαρητήρια"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Contact Us"),
        "continu": MessageLookupByLibrary.simpleMessage("Συνέχεια"),
        "country": MessageLookupByLibrary.simpleMessage("Χώρα"),
        "create": MessageLookupByLibrary.simpleMessage("Δημιουργία"),
        "createAFreeAccounts": MessageLookupByLibrary.simpleMessage(
            "Δημιουργία δωρεάν λογαριασμού"),
        "createdAndSaved": MessageLookupByLibrary.simpleMessage(
            "Δημιουργήθηκε και αποθηκεύτηκε"),
        "currency": MessageLookupByLibrary.simpleMessage("Currency"),
        "currentStock": MessageLookupByLibrary.simpleMessage("Current Stock"),
        "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
            "Προσαρμοσμένη επισήμανση τιμολογίων"),
        "customer": MessageLookupByLibrary.simpleMessage("Customer"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Στοιχεία Πελάτη"),
        "customerGST": MessageLookupByLibrary.simpleMessage("GST Πελάτη"),
        "customerName": MessageLookupByLibrary.simpleMessage("Όνομα Πελάτη"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Ημερήσια Συναλλαγή"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Επισκόπηση Πίνακα Ελέγχου"),
        "dataSavedSuccessfully": MessageLookupByLibrary.simpleMessage(
            "Τα δεδομένα αποθηκεύτηκαν με επιτυχία"),
        "date": MessageLookupByLibrary.simpleMessage("Ημερομηνία"),
        "day": MessageLookupByLibrary.simpleMessage("Ημέρα"),
        "dealer": MessageLookupByLibrary.simpleMessage("Έμπορος"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("Τιμή Εμπόρου"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("Προεπιλεγμένο ποσοστό ΦΠΑ"),
        "delete": MessageLookupByLibrary.simpleMessage("Διαγραφή"),
        "deleting": MessageLookupByLibrary.simpleMessage("Διαγραφή"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Διεύθυνση Παράδοσης"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Διευθύνσεις παράδοσης"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Κόστος Παράδοσης"),
        "describtion": MessageLookupByLibrary.simpleMessage("Περιγραφή"),
        "description": MessageLookupByLibrary.simpleMessage("Περιγραφή"),
        "descriptionCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Η περιγραφή δεν μπορεί να είναι κενή"),
        "details": MessageLookupByLibrary.simpleMessage("Λεπτομέρειες"),
        "discount": MessageLookupByLibrary.simpleMessage("Έκπτωση"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Do not disturb"),
        "done": MessageLookupByLibrary.simpleMessage("Ολοκληρώθηκε"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Λήψη μορφής Excel"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Λήφθηκε με επιτυχία στον φάκελο λήψης"),
        "due": MessageLookupByLibrary.simpleMessage("Οφειλόμενο"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Οφειλόμενο Ποσό: "),
        "dueCollection":
            MessageLookupByLibrary.simpleMessage("Συλλογή Οφειλών"),
        "dueCollectionReports": MessageLookupByLibrary.simpleMessage(
            "Αναφορές Εκκρεμοτήτων Είσπραξης"),
        "dueList": MessageLookupByLibrary.simpleMessage("Λίστα Οφειλών"),
        "dueReports": MessageLookupByLibrary.simpleMessage("Αναφορά Οφειλής"),
        "duration": MessageLookupByLibrary.simpleMessage("Διάρκεια"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Διάρκεια: Από"),
        "easyToUseMobilePos":
            MessageLookupByLibrary.simpleMessage("Easy to use mobile pos"),
        "edit": MessageLookupByLibrary.simpleMessage("Επεξεργασία"),
        "editPurchaseInvoice": MessageLookupByLibrary.simpleMessage(
            "Επεξεργασία Τιμολογίου Αγοράς"),
        "editSalesInvoice": MessageLookupByLibrary.simpleMessage(
            "Επεξεργασία Τιμολογίου Πωλήσεων"),
        "editSocailMedia": MessageLookupByLibrary.simpleMessage(
            "Επεξεργασία Κοινωνικών Μέσων"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Επεξεργασία Επιτυχής"),
        "editTax": MessageLookupByLibrary.simpleMessage("Επεξεργασία Φόρου"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Επεξεργασία Ομάδας Φόρου"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("Επεξεργασία Αποθήκης"),
        "email": MessageLookupByLibrary.simpleMessage("Email"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("Διεύθυνση Email"),
        "emailCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Η διεύθυνση email δεν μπορεί να είναι κενή"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "Email εστάλη! Ελέγξτε το εισερχόμενο σας"),
        "endDate": MessageLookupByLibrary.simpleMessage("Ημερομηνία Λήξης"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Εισάγετε ένα έγκυρο ποσό"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Εισάγετε έγκυρη έκπτωση"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Εισάγετε έναν έγκυρο αριθμό τηλεφώνου"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Εισάγετε έγκυρη τιμή"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("Εισάγετε έγκυρη ποσότητα"),
        "enterAddress":
            MessageLookupByLibrary.simpleMessage("Εισαγάγετε τη διεύθυνση"),
        "enterAmount":
            MessageLookupByLibrary.simpleMessage("Εισαγάγετε το ποσό."),
        "enterBrandName": MessageLookupByLibrary.simpleMessage(
            "Εισαγάγετε το όνομα της μάρκας"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Εισαγάγετε τη χωρητικότητα"),
        "enterCategoryName": MessageLookupByLibrary.simpleMessage(
            "Εισαγάγετε το όνομα της κατηγορίας"),
        "enterColor":
            MessageLookupByLibrary.simpleMessage("Εισαγάγετε το χρώμα"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "Εισάγετε τον αριθμό GST του πελάτη"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Εισαγάγετε την τιμή εμπόρου"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Εισάγετε περιγραφή"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("Εισαγάγετε την έκπτωση."),
        "enterExpenseDate": MessageLookupByLibrary.simpleMessage(
            "Εισαγάγετε Ημερομηνία Έξοδου"),
        "enterFullAddress": MessageLookupByLibrary.simpleMessage(
            "Εισαγάγετε την πλήρη διεύθυνση"),
        "enterInvoiceNumber": MessageLookupByLibrary.simpleMessage(
            "Εισαγάγετε τον αριθμό τιμολογίου"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Εισάγετε την ποσότητα ειδοποίησης χαμηλού αποθέματος"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Εισαγάγετε τον κατασκευαστή"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("Enter Message Content"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "Εισαγάγετε την τιμή πώλησης λιανικής (MRP)"),
        "enterName": MessageLookupByLibrary.simpleMessage("Εισαγάγετε Όνομα"),
        "enterNote":
            MessageLookupByLibrary.simpleMessage("Εισαγάγετε Σημείωση"),
        "enterPartyName": MessageLookupByLibrary.simpleMessage(
            "Εισαγάγετε το όνομα συμμετέχοντος"),
        "enterPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Εισαγάγετε τον αριθμό τηλεφώνου"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Εισαγάγετε τον κωδικό του προϊόντος ή σαρώστε"),
        "enterProductName": MessageLookupByLibrary.simpleMessage(
            "Εισαγάγετε το όνομα του προϊόντος"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Εισαγάγετε την τιμή αγοράς."),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("Εισαγάγετε Αριθμό Αναφοράς"),
        "enterSize":
            MessageLookupByLibrary.simpleMessage("Εισαγάγετε το μέγεθος"),
        "enterStocks":
            MessageLookupByLibrary.simpleMessage("Εισαγάγετε τα αποθέματα."),
        "enterTaxRate": MessageLookupByLibrary.simpleMessage(
            "Εισάγετε Φορολογικό Συντελεστή"),
        "enterTransactionId": MessageLookupByLibrary.simpleMessage(
            "Εισαγωγή αναγνωριστικού συναλλαγής"),
        "enterType":
            MessageLookupByLibrary.simpleMessage("Εισαγάγετε τον τύπο"),
        "enterUserTitle": MessageLookupByLibrary.simpleMessage(
            "Εισάγετε τον τίτλο του χρήστη"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Εισάγετε έγκυρο ποσό"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Εισάγετε Όνομα Αποθήκης"),
        "enterWeight":
            MessageLookupByLibrary.simpleMessage("Εισαγάγετε το βάρος"),
        "enterWholeSalePrice": MessageLookupByLibrary.simpleMessage(
            "Εισαγάγετε την τιμή χονδρικής"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("Enter your description here"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "Εισαγάγετε τη διεύθυνση email σας"),
        "enterYourFeedBackTitle":
            MessageLookupByLibrary.simpleMessage("Enter Your Feedback Tittle"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Εισάγετε τον αριθμό GST σας"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("Enter your mobile number"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Εισαγάγετε το όνομά σας"),
        "enterYourNumber": MessageLookupByLibrary.simpleMessage(
            "Εισαγάγετε τον αριθμό τηλεφώνου σας"),
        "enterYourPassword": MessageLookupByLibrary.simpleMessage(
            "Εισάγετε τον κωδικό πρόσβασής σας"),
        "enterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Εισαγάγετε τον αριθμό τηλεφώνου σας"),
        "enterYourTransactionId":
            MessageLookupByLibrary.simpleMessage("Enter your transaction id"),
        "error": MessageLookupByLibrary.simpleMessage("Σφάλμα"),
        "excTax": MessageLookupByLibrary.simpleMessage("Χωρίς ΦΠΑ"),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("Εκφορτωτής Excel"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Εξαιρούμενο"),
        "expense": MessageLookupByLibrary.simpleMessage("Έξοδο"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Κατηγορία Έξοδου"),
        "expenseDate":
            MessageLookupByLibrary.simpleMessage("Ημερομηνία Έξοδου"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Έξοδο Για"),
        "expenseReport": MessageLookupByLibrary.simpleMessage("Αναφορά Έξοδων"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Ημερομηνία λήξης"),
        "expired": MessageLookupByLibrary.simpleMessage("Έχει λήξει"),
        "expiring": MessageLookupByLibrary.simpleMessage("Λήγει"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Αποτυχία με Σφάλμα"),
        "fashion": MessageLookupByLibrary.simpleMessage("Μόδα"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Features are the important part which makes Pos Saas  different from traditional solutions."),
        "feedBack": MessageLookupByLibrary.simpleMessage("FeedBack"),
        "firstName": MessageLookupByLibrary.simpleMessage("Όνομα"),
        "followUsOnFacebook": MessageLookupByLibrary.simpleMessage(
            "Ακολουθήστε μας στο\\nFacebook"),
        "followUsOnTwitter": MessageLookupByLibrary.simpleMessage(
            "Ακολουθήστε μας στο\\nTwitter"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Font Side"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("For unlimited usages"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Ξεχάσατε τον κωδικό σας;"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Ξεχάσατε τον κωδικό σας;"),
        "formDate": MessageLookupByLibrary.simpleMessage("Από Ημερομηνία"),
        "freeDataBackup": MessageLookupByLibrary.simpleMessage(
            "Δωρεάν αντίγραφα ασφαλείας δεδομένων"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "Δωρεάν ενημέρωση εφόρου ζωής"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Free Package"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Free Plan"),
        "from": MessageLookupByLibrary.simpleMessage("(Από"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Πλήρως πληρωμένο"),
        "gallary": MessageLookupByLibrary.simpleMessage("Συλλογή"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("Δημιουργία PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Λήψη OTP"),
        "govermentId": MessageLookupByLibrary.simpleMessage("Government Id"),
        "guest": MessageLookupByLibrary.simpleMessage("Επισκέπτης"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Δεν έχετε λογαριασμό;"),
        "history": MessageLookupByLibrary.simpleMessage("History"),
        "home": MessageLookupByLibrary.simpleMessage("Αρχική"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Πώς Προστατεύουμε τις Πληροφορίες Σας"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Πώς Χρησιμοποιούμε τις Πληροφορίες Σας"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Identity Verify"),
        "image": MessageLookupByLibrary.simpleMessage("Εικόνα"),
        "inHouseCantBeDelete": MessageLookupByLibrary.simpleMessage(
            "Η εσωτερική αποθήκη δεν μπορεί να διαγραφεί"),
        "inHouseCantBeEdited": MessageLookupByLibrary.simpleMessage(
            "Η εσωτερική αποθήκη δεν μπορεί να επεξεργαστεί"),
        "inWord": MessageLookupByLibrary.simpleMessage("Σε λέξεις"),
        "incTax": MessageLookupByLibrary.simpleMessage("Με ΦΠΑ"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Συμπεριλαμβανομένο"),
        "increaseStock":
            MessageLookupByLibrary.simpleMessage("Αύξηση Αποθέματος"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Όργανο"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Αρ. Τιμολογίου"),
        "invoice": MessageLookupByLibrary.simpleMessage("Τιμολόγιο"),
        "invoiceNumber":
            MessageLookupByLibrary.simpleMessage("Αριθμός Τιμολογίου"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Invoice Setting"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Θεατής τιμολογίων"),
        "itemAdded":
            MessageLookupByLibrary.simpleMessage("Το αντικείμενο προστέθηκε"),
        "kg": MessageLookupByLibrary.simpleMessage("Κιλά"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("KYC Verification"),
        "language": MessageLookupByLibrary.simpleMessage("Γλώσσα"),
        "lastName": MessageLookupByLibrary.simpleMessage("Επώνυμο"),
        "ledger": MessageLookupByLibrary.simpleMessage("Λογιστικό βιβλίο"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Lifetime\nPurchase"),
        "link": MessageLookupByLibrary.simpleMessage("Σύνδεσμος"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport": MessageLookupByLibrary.simpleMessage(
            "Υποστήριξη ζωντανής συνομιλίας"),
        "loading": MessageLookupByLibrary.simpleMessage("Φόρτωση"),
        "logIn": MessageLookupByLibrary.simpleMessage("Σύνδεση"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Log Out"),
        "logOut": MessageLookupByLibrary.simpleMessage("Αποσύνδεση"),
        "login": MessageLookupByLibrary.simpleMessage("Σύνδεση"),
        "logo": MessageLookupByLibrary.simpleMessage("Logo"),
        "loss": MessageLookupByLibrary.simpleMessage("Ζημιά"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Ζημιά/Κέρδος"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Λεπτομέρειες Ζημιάς/Κέρδους"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Αναφορά ζημίας/κέρδους"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Αναφορές ζημίας/κέρδους"),
        "lowStockAlert": MessageLookupByLibrary.simpleMessage(
            "Ειδοποίηση χαμηλού αποθέματος"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Δημιουργήστε μια διαρκή εντύπωση στους πελάτες σας με επισημασμένα τιμολόγια. Η αναβάθμιση Unlimited προσφέρει το μοναδικό πλεονέκτημα της προσαρμογής των τιμολογίων σας, προσθέτοντας μια επαγγελματική πινελιά που ενισχύει την αναγνωρισιμότητα της εταιρικής σας ταυτότητας και ενθαρρύνει την πιστότητα των πελατών."),
        "manageYourBussinessWith": MessageLookupByLibrary.simpleMessage(
            "Διαχειριστείτε την επιχείρησή σας με"),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Ημερομηνία παραγωγής"),
        "margin": MessageLookupByLibrary.simpleMessage("Περιθώριο"),
        "masterCard": MessageLookupByLibrary.simpleMessage("Κάρτα Master"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Κατασκευαστής"),
        "message": MessageLookupByLibrary.simpleMessage("Μήνυμα"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Message History"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Pos Saas  app is free, easy to use. In fact, it\'s one of the best  POS systems around the world."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas  is a complete business solution with stock, account, sales, expense & loss/profit."),
        "mobile": MessageLookupByLibrary.simpleMessage("Κινητό"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("Μobile Payment"),
        "monthly": MessageLookupByLibrary.simpleMessage("Monthly"),
        "moreInfo":
            MessageLookupByLibrary.simpleMessage("Περισσότερες Πληροφορίες"),
        "name":
            MessageLookupByLibrary.simpleMessage("Εισαγάγετε το όνομά σας."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Το Όνομα Υπάρχει Ήδη"),
        "nameCantBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Το Όνομα δεν μπορεί να είναι κενό"),
        "next": MessageLookupByLibrary.simpleMessage("Next"),
        "noConnection": MessageLookupByLibrary.simpleMessage("Χωρίς σύνδεση"),
        "noData": MessageLookupByLibrary.simpleMessage("No Data"),
        "noDataAvailable": MessageLookupByLibrary.simpleMessage(
            "Δεν υπάρχουν διαθέσιμα δεδομένα"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Δεν βρέθηκαν δεδομένα"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("No History Found!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Δεν βρέθηκε προϊόν"),
        "noSubTaxSelected": MessageLookupByLibrary.simpleMessage(
            "Καμία υποφορολογία επιλεγμένη"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("No Transaction Found!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Δεν βρέθηκε χρήστης με αυτό το email."),
        "noUserRoleFound":
            MessageLookupByLibrary.simpleMessage("Δεν βρέθηκε ρόλος χρήστη"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Μη ενεργός χρήστης"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Δεν παρέχεται"),
        "note": MessageLookupByLibrary.simpleMessage("Σημείωση"),
        "notes": MessageLookupByLibrary.simpleMessage("Σημειώσεις"),
        "notification": MessageLookupByLibrary.simpleMessage("Ειδοποίηση"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP στάλθηκε σε"),
        "office": MessageLookupByLibrary.simpleMessage("Γραφείο"),
        "ok": MessageLookupByLibrary.simpleMessage("Εντάξει"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS που περιλαμβάνει πολλές λειτουργίες, συμπεριλαμβανομένης της παρακολούθησης των πωλήσεων και της διαχείρισης του αποθέματος."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Αυτό το σύστημα σας βοηθά να βελτιώσετε τις λειτουργίες σας για τους πελάτες σας."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Το POS μας θα απλοποιήσει αυτόματα τις καθημερινές λειτουργίες, καθιστώντας την πλοήγηση ευκολότερη."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("Αρχικό υπόλοιπο"),
        "order": MessageLookupByLibrary.simpleMessage("Παραγγελίες"),
        "other": MessageLookupByLibrary.simpleMessage("Άλλο"),
        "otp": MessageLookupByLibrary.simpleMessage("Κλείσιμο"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Μη διαθέσιμο"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Πακέτο"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Package Features"),
        "paid": MessageLookupByLibrary.simpleMessage("Πληρώθηκε"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Πληρωμένο Ποσό"),
        "parties": MessageLookupByLibrary.simpleMessage("Συμμετέχοντες"),
        "partiesList":
            MessageLookupByLibrary.simpleMessage("Λίστα Συμμετεχόντων"),
        "partyGST": MessageLookupByLibrary.simpleMessage("GST Μέρους"),
        "partyName":
            MessageLookupByLibrary.simpleMessage("Όνομα Συμμετέχοντος"),
        "password": MessageLookupByLibrary.simpleMessage("Κωδικός"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Ο κωδικός πρόσβασης και η επιβεβαίωση κωδικού δεν ταιριάζουν"),
        "passwordCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Ο κωδικός πρόσβασης δεν μπορεί να είναι κενός"),
        "passwordNotMach": MessageLookupByLibrary.simpleMessage(
            "Ο κωδικός πρόσβασης δεν ταιριάζει"),
        "payCash": MessageLookupByLibrary.simpleMessage("Πληρωμή μετρητοίς"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash": MessageLookupByLibrary.simpleMessage("Pay with bkash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Pay with Paypal"),
        "payeeName": MessageLookupByLibrary.simpleMessage("Payee Name"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("Payee Number"),
        "payment": MessageLookupByLibrary.simpleMessage("Πληρωμή"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("Ποσό Πληρωμής"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Η Πληρωμή Ολοκληρώθηκε"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Payment Instruction:"),
        "paymentMethod":
            MessageLookupByLibrary.simpleMessage("Μέθοδος πληρωμής"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Τύπος Πληρωμής"),
        "pdfView": MessageLookupByLibrary.simpleMessage("Προβολή PDF"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Προσωπικές Πληροφορίες"),
        "phone": MessageLookupByLibrary.simpleMessage("Τηλέφωνο"),
        "phoneNumber":
            MessageLookupByLibrary.simpleMessage("Αριθμός τηλεφώνου"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Ο αριθμός τηλεφώνου έχει ήδη χρησιμοποιηθεί"),
        "phoneNumberIsNotValid": MessageLookupByLibrary.simpleMessage(
            "Ο αριθμός τηλεφώνου δεν είναι έγκυρος"),
        "phoneNumberIsRequired": MessageLookupByLibrary.simpleMessage(
            "Ο αριθμός τηλεφώνου είναι υποχρεωτικός"),
        "pickAndUploadFile": MessageLookupByLibrary.simpleMessage(
            "Επιλέξτε και ανεβάστε αρχείο"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("Επιλέξτε ημερομηνία λήξης"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Επιλέξτε ημερομηνία έναρξης"),
        "plan": MessageLookupByLibrary.simpleMessage("Σχέδιο"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("Παρακαλώ προσθέστε ποσότητα"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Παρακαλούμε ελέγξτε τη σύνδεσή σας στο διαδίκτυο"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Παρακαλώ συνδέστε πρώτα τον εκτυπωτή"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Παρακαλούμε συνδέστε τον εκτυπωτή Bluetooth σας"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Παρακαλώ εισάγετε έναν μεγαλύτερο κωδικό πρόσβασης"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Παρακαλώ Εισαγάγετε Επιβεβαίωση Κωδικού"),
        "pleaseEnterAPassword": MessageLookupByLibrary.simpleMessage(
            "Παρακαλώ εισαγάγετε έναν κωδικό"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Παρακαλώ εισάγετε μια έγκυρη διεύθυνση email"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Παρακαλώ εισάγετε όνομα"),
        "pleaseEnterPassword": MessageLookupByLibrary.simpleMessage(
            "Παρακαλώ εισάγετε τον κωδικό πρόσβασης"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Παρακαλώ εισαγάγετε το email σας παρακάτω για να λάβετε τον σύνδεσμο επαναφοράς κωδικού πρόσβασης."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Παρακαλώ εισάγετε τον αριθμό συναλλαγής"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("Παρακαλώ εισάγετε ποσό"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Παρακαλώ επιλέξτε πρώτα μια κατηγορία"),
        "pleaseSelectAPlan": MessageLookupByLibrary.simpleMessage(
            "Παρακαλώ επιλέξτε ένα σχέδιο"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Παρακαλώ επιλέξτε κατηγορία επιχείρησης"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Παρακαλώ χρησιμοποιήστε τον έγκυρο κωδικό αγοράς για να χρησιμοποιήσετε την εφαρμογή"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Κινητοποιημένο από Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Δημιουργήθηκε από"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Πρεμιέρα υποστήριξη πελατών"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Premium plan"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Previous Pay Amounts"),
        "price": MessageLookupByLibrary.simpleMessage("Τιμή"),
        "print": MessageLookupByLibrary.simpleMessage("Εκτύπωση"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Printing Option"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Πολιτική απορρήτου"),
        "product": MessageLookupByLibrary.simpleMessage("Προϊόν"),
        "productCode":
            MessageLookupByLibrary.simpleMessage("Κωδικός Προϊόντος"),
        "productCodeIsRequired": MessageLookupByLibrary.simpleMessage(
            "Ο κωδικός προϊόντος είναι υποχρεωτικός"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Κωδικός/Όνομα προϊόντος"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Περιγραφή προϊόντος"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Λεπτομέρειες προϊόντος"),
        "productList": MessageLookupByLibrary.simpleMessage("Λίστα Προϊόντων"),
        "productName": MessageLookupByLibrary.simpleMessage("Όνομα Προϊόντος"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Το όνομα προϊόντος υπάρχει ήδη σε αυτή την αποθήκη"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Το όνομα του προϊόντος έχει ήδη προστεθεί"),
        "productNameIsRequired": MessageLookupByLibrary.simpleMessage(
            "Το όνομα προϊόντος είναι υποχρεωτικό"),
        "products": MessageLookupByLibrary.simpleMessage("Προϊόντα"),
        "profile": MessageLookupByLibrary.simpleMessage("Προφίλ"),
        "profileEdit":
            MessageLookupByLibrary.simpleMessage("Επεξεργασία προφίλ"),
        "profit": MessageLookupByLibrary.simpleMessage("Κέρδος"),
        "promo": MessageLookupByLibrary.simpleMessage("Προσφορά"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Κωδικός Προσφοράς"),
        "purchase": MessageLookupByLibrary.simpleMessage("Αγορά"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("Συναγερμός Αγοράς"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Η Αγορά Επιβεβαιώθηκε"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Λεπτομέρειες Αγοράς"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Τιμολόγιο αγοράς"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("Λίστα Αγορών"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Αγοράστε τώρα"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Purchase Premium Plan"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("Τιμή Αγοράς"),
        "purchasePriceIsRequired": MessageLookupByLibrary.simpleMessage(
            "Η τιμή αγοράς είναι υποχρεωτική"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("Αναφορά Αγοράς"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Αναφορά Αγοράς"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Αναφορές Αγορών"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("Επιστροφή αγοράς"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("Αναφορά επιστροφής αγοράς"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Μετάβαση αγοράς"),
        "qty": MessageLookupByLibrary.simpleMessage("Ποσότητα"),
        "quantity": MessageLookupByLibrary.simpleMessage("Ποσότητα"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Πρόσφατες Συναλλαγές"),
        "recivedThePin": MessageLookupByLibrary.simpleMessage("Λήψη του PIN"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Αριθμός Αναφοράς"),
        "register": MessageLookupByLibrary.simpleMessage("Εγγραφή"),
        "registering": MessageLookupByLibrary.simpleMessage("Εγγραφή"),
        "remainingDue":
            MessageLookupByLibrary.simpleMessage("Υπόλοιπο Οφειλόμενο"),
        "remove": MessageLookupByLibrary.simpleMessage("Αφαίρεση"),
        "reports": MessageLookupByLibrary.simpleMessage("Αναφορές"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Το αίτημα έχει αποσταλεί"),
        "resendCode":
            MessageLookupByLibrary.simpleMessage("Επανάληψη αποστολής κώδικα"),
        "resendOtp":
            MessageLookupByLibrary.simpleMessage("Επανάληψη αποστολής OTP: "),
        "retailer": MessageLookupByLibrary.simpleMessage("Λιανοπώλης"),
        "retur": MessageLookupByLibrary.simpleMessage("Επιστροφή"),
        "returN": MessageLookupByLibrary.simpleMessage("Επιστροφή"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("Ποσό Επιστροφής"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("Return Amount"),
        "returnQTY":
            MessageLookupByLibrary.simpleMessage("Ποσότητα επιστροφής"),
        "revenue": MessageLookupByLibrary.simpleMessage("Έσοδα"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Προστατέψτε τα δεδομένα της επιχείρησής σας με ευκολία. Η αναβάθμιση Pos Saas POS Unlimited περιλαμβάνει δωρεάν αντίγραφα ασφαλείας δεδομένων, διασφαλίζοντας ότι οι πολύτιμες πληροφορίες σας προστατεύονται από απρόβλεπα γεγονότα. Επικεντρωθείτε σε αυτό που έχει πραγματική σημασία - την ανάπτυξη της επιχείρησής σας."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Ποσό πώλησης"),
        "saleDetails":
            MessageLookupByLibrary.simpleMessage("Λεπτομέρειες Πώλησης"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Τιμή Πώλησης"),
        "saleReports": MessageLookupByLibrary.simpleMessage("Αναφορά Πώλησης"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Αναφορές Πωλήσεων"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("Επιστροφή πώλησης"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Αναφορά επιστροφής πώλησης"),
        "saleSetting":
            MessageLookupByLibrary.simpleMessage("Ρυθμίσεις πώλησης"),
        "sales": MessageLookupByLibrary.simpleMessage("Πωλήσεις"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("Αναφορές Πωλήσεων & Αγορών"),
        "salesList": MessageLookupByLibrary.simpleMessage("Λίστα Πωλήσεων"),
        "salesReturn":
            MessageLookupByLibrary.simpleMessage("Επιστροφή πωλήσεων"),
        "save": MessageLookupByLibrary.simpleMessage("Αποθήκευση"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Αποθήκευση και Δημοσίευση"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("Save Changes"),
        "saving": MessageLookupByLibrary.simpleMessage("Αποθήκευση"),
        "scanProductQRCode": MessageLookupByLibrary.simpleMessage(
            "Σαρώστε τον QR κωδικό του προϊόντος"),
        "search": MessageLookupByLibrary.simpleMessage("Αναζήτηση"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Αναζήτηση με βάση τον κωδικό ή το όνομα του προϊόντος"),
        "seeAllPromoCode": MessageLookupByLibrary.simpleMessage(
            "Δείτε όλους τους κωδικούς προσφοράς"),
        "select": MessageLookupByLibrary.simpleMessage("Επιλογή"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Επιλέξτε ένα προϊόν για επιστροφή"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Επιλέξτε μάρκα"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Επιλέξτε κατηγορία"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Select Contacts"),
        "selectProductCategory": MessageLookupByLibrary.simpleMessage(
            "Επιλέξτε κατηγορία προϊόντος"),
        "selectShopCategory": MessageLookupByLibrary.simpleMessage(
            "Επιλέξτε κατηγορία καταστήματος"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Επιλέξτε φόρο"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Επιλέξτε τύπο φόρου"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("Επιλέξτε μονάδα"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Επιλέξτε Παραλλαγή:"),
        "seller": MessageLookupByLibrary.simpleMessage("Πωλητής"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Πωλείται από"),
        "send": MessageLookupByLibrary.simpleMessage("Αποστολή"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("Αποστολή Email"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Send Message"),
        "sendResetLink": MessageLookupByLibrary.simpleMessage(
            "Αποστολή συνδέσμου επαναφοράς"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Αποστολή SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Αποστολή SMS;"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Αποστολή μηνύματος WhatsApp"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Send Your Email"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage("Αποστολή Email"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Αποστολή μηνύματος"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Υπηρεσία/Αποστολή"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Ρύθμιση του προφίλ σας"),
        "setting": MessageLookupByLibrary.simpleMessage("Ρυθμίσεις"),
        "share": MessageLookupByLibrary.simpleMessage("Κοινοποίηση"),
        "shopGST": MessageLookupByLibrary.simpleMessage("GST Καταστήματος"),
        "signIn": MessageLookupByLibrary.simpleMessage("Σύνδεση"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("Συνδεθείτε με email"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Υπογραφή πελάτη"),
        "size": MessageLookupByLibrary.simpleMessage("Μέγεθος"),
        "skip": MessageLookupByLibrary.simpleMessage("Skip"),
        "sms": MessageLookupByLibrary.simpleMessage("Sms"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Κοινωνικό Μάρκετινγκ"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Λυπάμαι, δεν έχετε άδεια να αποκτήσετε πρόσβαση σε αυτή την υπηρεσία"),
        "startDate": MessageLookupByLibrary.simpleMessage("Ημερομηνία Έναρξης"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Ξεκινήστε νέα πώληση"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage(
            "Ξεκινήστε την πληκτρολόγηση για αναζήτηση"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Μείνετε στην πρωτοπορία των τεχνολογικών εξελίξεων χωρίς καμία επιπλέον χρέωση. Η αναβάθμιση Pos Saas POS Unlimited εξασφαλίζει ότι θα έχετε πάντα τα τελευταία εργαλεία και χαρακτηριστικά στη διάθεσή σας, εξασφαλίζοντας ότι η επιχείρησή σας παραμένει στην κορυφή."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("Ακόμη απλήρωτο"),
        "stock": MessageLookupByLibrary.simpleMessage("Απόθεμα"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Απαιτείται απόθεμα"),
        "stockList": MessageLookupByLibrary.simpleMessage("Λίστα Αποθεμάτων"),
        "stocks": MessageLookupByLibrary.simpleMessage("Αποθέματα"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Η άδεια αποθήκευσης απαιτείται για να δημιουργηθεί το αρχείο Excel"),
        "subTaxList":
            MessageLookupByLibrary.simpleMessage("Λίστα υποφορολογιών"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Υποφορολογίες"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Μερικό Σύνολο"),
        "submit": MessageLookupByLibrary.simpleMessage("Υποβολή"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "Εγγραφείτε στο\\nYoutube μας"),
        "subscription": MessageLookupByLibrary.simpleMessage("Subscription"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Ολοκληρώθηκε με επιτυχία"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Αποσυνδέθηκε με επιτυχία"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Ενημερώθηκε με επιτυχία"),
        "supplier": MessageLookupByLibrary.simpleMessage("Προμηθευτής"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("Όνομα Προμηθευτή"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("Κωδικός SWIFT"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Take a driver\'s license, national identity card or passport photo"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "Take an identity card to check your information"),
        "tap": MessageLookupByLibrary.simpleMessage("Πατήστε"),
        "tax": MessageLookupByLibrary.simpleMessage("Φόρος"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Ομάδα Φόρου"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("Ποσοστό φόρου"),
        "taxRate":
            MessageLookupByLibrary.simpleMessage("Φορολογικός Συντελεστής"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Φορολογικοί Συντελεστές - Διαχειριστείτε τους Φορολογικούς Συντελεστές σας"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Έκθεση Φόρου"),
        "taxType": MessageLookupByLibrary.simpleMessage("Τύπος φόρου"),
        "taxes": MessageLookupByLibrary.simpleMessage("Φόροι"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Όροι και Προϋποθέσεις"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("Όροι χρήσης"),
        "termsPrivacy": MessageLookupByLibrary.simpleMessage("Όροι & Απόρρητο"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Σας Ευχαριστούμε Για Την Εξόφληση Οφειλομένων"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Ευχαριστώ"),
        "thankYouForYourPurchase": MessageLookupByLibrary.simpleMessage(
            "Σας ευχαριστούμε για την αγορά σας"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "Ο λογαριασμός ήδη υπάρχει για αυτό το email"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Το αρχείο Excel έχει ήδη ληφθεί"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Το όνομα λέει τα πάντα. Με το Pos Saas POS Unlimited, δεν υπάρχει καμία περιοριστική ορολογία για τη χρήση σας. Είτε επεξεργάζεστε μια μικρή ποσότητα συναλλαγών είτε αντιμετωπίζετε έναν ύψιστο αριθμό πελατών, μπορείτε να λειτουργήσετε με αυτοπεποίθηση, γνωρίζοντας ότι δεν υπάρχουν περιορισμοί."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "Ο παρεχόμενος κωδικός πρόσβασης είναι πολύ αδύναμος"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Η πώληση θα διαγραφεί και όλα τα δεδομένα σχετικά με αυτή την αγορά θα διαγραφούν. Είστε σίγουροι ότι θέλετε να το διαγράψετε;"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Η πώληση θα διαγραφεί και όλα τα δεδομένα σχετικά με αυτή την πώληση θα διαγραφούν. Είστε σίγουροι ότι θέλετε να το διαγράψετε;"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Ο χρήστης θα διαγραφεί και όλα τα δεδομένα θα διαγραφούν από τον λογαριασμό σας. Είστε σίγουροι ότι θέλετε να διαγράψετε;"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Ο χρήστης θα διαγραφεί και όλα τα δεδομένα θα διαγραφούν από τον λογαριασμό σας. Είστε σίγουροι ότι θέλετε να το διαγράψετε;"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Υπηρεσίες τρίτων"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Αυτή η κατηγορία δεν μπορεί να διαγραφεί"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Αυτόν τον μήνα)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Αυτό το προϊόν έχει ήδη προστεθεί"),
        "title": MessageLookupByLibrary.simpleMessage("Title"),
        "titleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Ο τίτλος δεν μπορεί να είναι κενός"),
        "to": MessageLookupByLibrary.simpleMessage("έως"),
        "toDate": MessageLookupByLibrary.simpleMessage("Έως Ημερομηνία"),
        "today": MessageLookupByLibrary.simpleMessage("Σήμερα"),
        "total": MessageLookupByLibrary.simpleMessage("Σύνολο"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Συνολικό Ποσό"),
        "totalCollected": MessageLookupByLibrary.simpleMessage(
            "Συνολικό ποσό που συγκεντρώθηκε"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Συνολικό Οφειλόμενο"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("Συνολικό Έξοδο"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Συνολική ζημία"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("Συνολικό Πληρεξοφληθέν Ποσό"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Συνολική Τιμή"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("Συνολικά προϊόντα"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Συνολικό κέρδος"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("Συνολική αγορά"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Συνολικό ποσό επιστροφής"),
        "totalReturns":
            MessageLookupByLibrary.simpleMessage("Συνολικές επιστροφές"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Συνολικές Πωλήσεις"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Total Stocks"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Συνολική Αξία"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Συνολικό ΦΠΑ"),
        "totals": MessageLookupByLibrary.simpleMessage("Σύνολο: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Transaction"),
        "transactionId": MessageLookupByLibrary.simpleMessage("Transaction Id"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Δοκιμάστε ξανά"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Τύπος"),
        "unitName": MessageLookupByLibrary.simpleMessage("Όνομα Μονάδας"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Τιμή Μονάδας"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Τιμή μονάδας"),
        "units": MessageLookupByLibrary.simpleMessage("Μονάδες"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Απεριόριστο"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Απεριόριστη χρήση"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Ξεκλειδώστε το πλήρες δυναμικό του Pos Saas POS με εξατομικευμένες συνεδρίες εκπαίδευσης υπό την καθοδήγηση της ομάδας εμπειρογνωμόνων μας. Από τα βασικά έως τις προηγμένες τεχνικές, εξασφαλίζουμε ότι γνωρίζετε καλά τη χρήση κάθε πτυχής του συστήματος για τη βελτιστοποίηση των επιχειρηματικών διαδικασιών σας."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Απλήρωτο"),
        "update": MessageLookupByLibrary.simpleMessage("Ενημέρωση"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Ενημέρωση Επαφής"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Ενημέρωση Τώρα"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("Ενημέρωση Προϊόντος"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Ενημερώστε το σχέδιό σας πρώτα, το όριό σας έχει ξεπεραστεί"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Ενημέρωση του Προφίλ σας"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Ενημερώστε το προφίλ σας για καλύτερη σύνδεση με το γιατρό σας"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Ενημερώστε το προφίλ σας για να συνδέσετε τον πελάτη σας με καλύτερη εντύπωση"),
        "updated": MessageLookupByLibrary.simpleMessage("Ενημερώθηκε"),
        "upload": MessageLookupByLibrary.simpleMessage("Ανέβασμα"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Μεταφόρτωση εγγράφου"),
        "uploadDone":
            MessageLookupByLibrary.simpleMessage("Ανέβασμα ολοκληρώθηκε"),
        "uploadFile":
            MessageLookupByLibrary.simpleMessage("Μεταφόρτωση αρχείου"),
        "upplier": MessageLookupByLibrary.simpleMessage("Προμηθευτής"),
        "usbC": MessageLookupByLibrary.simpleMessage("USB C"),
        "use": MessageLookupByLibrary.simpleMessage("Χρήση"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("Use Pos Saas"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Χρήση του Συστήματος"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Ο χρήστης διαγράφηκε"),
        "userRole": MessageLookupByLibrary.simpleMessage("Ρόλος χρήστη"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("Λεπτομέρειες ρόλου χρήστη"),
        "userTitle": MessageLookupByLibrary.simpleMessage("Τίτλος χρήστη"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Ο τίτλος χρήστη δεν μπορεί να είναι κενός"),
        "value": MessageLookupByLibrary.simpleMessage("Αξία"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("Ο ΦΠΑ δεν εφαρμόζεται"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("Επαλήθευση OTP"),
        "verifyPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Επαλήθευση αριθμού τηλεφώνου"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Προβολή Όλων"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("View details"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Πελάτης χωρίς ραντεβού"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Αποθήκη"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Η Αποθήκη Υπάρχει Ήδη"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("Λίστα Αποθηκών"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("Όνομα Αποθήκης"),
        "warranty": MessageLookupByLibrary.simpleMessage("Εγγύηση"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Σας έχουμε στείλει ένα email με οδηγίες για το πώς να επαναφέρετε τον κωδικό πρόσβασης στο:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Μπορεί να χρησιμοποιούμε υπηρεσίες τρίτων για την υποστήριξη της λειτουργικότητας της εφαρμογής μας, όπως πάροχοι αναλύσεων και επεξεργασίας πληρωμών. Αυτές οι υπηρεσίες τρίτων μπορεί να συλλέγουν πληροφορίες σχετικά μαζί σας όταν χρησιμοποιείτε την εφαρμογή μας. Σημειώστε ότι δεν φέρουμε ευθύνη για τις πρακτικές απορρήτου αυτών των υπηρεσιών τρίτων."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Λαμβάνουμε μέτρα βιομηχανικού προτύπου για την προστασία των προσωπικών σας πληροφοριών, συμπεριλαμβανομένης της κρυπτογράφησης και της ασφικούς αποθήκευσης. Επίσης, περιορίζουμε την πρόσβαση στις πληροφορίες σας μόνο σε εξουσιοδοτημένο προσωπικό."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Κατανοούμε τη σημασία της άψογης λειτουργίας. Γι\' αυτό η υποστήριξη μας διατίθεται όλο το εικοσιτετράωρο για να σας βοηθήσει, είτε πρόκειται για γρήγορες ερωτήσεις είτε για πιο λεπτομερή ανησυχία. Επικοινωνήστε μαζί μας όποτε και όπου είναι απαραίτητο μέσω κλήσης ή WhatsApp για να ζήσετε ασύγκριτη εξυπηρέτηση πελατών."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Χρησιμοποιούμε τις προσωπικές σας πληροφορίες για να σας παρέχουμε την καλύτερη δυνατή εμπειρία στην εφαρμογή μας, συμπεριλαμβανομένης της εξατομίκευσης των συστάσεων περιεχομένου σας, της σύνδεσής σας με ειδικούς και της βελτίωσης της λειτουργικότητας της εφαρμογής μας. Επίσης, μπορεί να χρησιμοποιούμε τις πληροφορίες σας για να επικοινωνούμε μαζί σας σχετικά με ενημερώσεις, προσφορές ή άλλες πληροφορίες που σχετίζονται με την εφαρμογή μας."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Θα εξετάσουμε την πληρωμή & θα την εγκρίνουμε εντός 1-2 ωρών"),
        "weekly": MessageLookupByLibrary.simpleMessage("Εβδομαδιαία"),
        "weight": MessageLookupByLibrary.simpleMessage("Βάρος"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Τι Νέο Υπάρχει"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Χονδρέμπορος"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Τιμή Χονδρικής"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("Χονδρική τιμή"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Χονδρέμπορος"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Θα προστεθεί σύντομα"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Θα λήξει στις"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Write your message here"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("Λάθος OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Λανθασμένος κωδικός πρόσβασης για αυτόν τον χρήστη."),
        "yearly": MessageLookupByLibrary.simpleMessage("Yearly"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Ναι, Διαγραφή Οριστικά"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("Δεν είστε έγκυρος χρήστης"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("You are using"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Δεν μπορείτε να πληρώσετε περισσότερα από το χρέος"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Έχετε λάβει ένα email"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Συνδεθήκατε με επιτυχία στον λογαριασμό σας. Μείνετε με το Pos Saas"),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("Πρέπει να δώσετε άδεια"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Πρέπει να ξανασυνδεθείτε στον λογαριασμό σας."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "You need to identity verify before your buying sms"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Your message remains"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Your Package"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Your Package Will Expire in 5 Day")
      };
}
