// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a hr locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'hr';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Nastavi"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("Broj PDV-a"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("MRP je obavezan"),
        "OK": MessageLookupByLibrary.simpleMessage("U redu"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("PayPal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Br. tel."),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT kod"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Grickalice"),
        "TAX": MessageLookupByLibrary.simpleMessage("POREZ"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Učitavanje"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("Naslov korisnika"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Vaš paket ističe danas\nMolimo kupite ponovo"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) Sustav je pružen isključivo u svrhu olakšavanja transakcija na prodajnom mjestu i povezanih aktivnosti u vašem poslovanju."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) Da biste koristili sustav, možda ćete morati stvoriti račun. Slažete se pružiti točne, trenutačne i potpune informacije tijekom postupka registracije i ažurirati takve informacije kako biste ih održavali točnima i potpunima."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("O aplikaciji"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("O nama"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Prihvaćanje uvjeta"),
        "accountName": MessageLookupByLibrary.simpleMessage("Ime računa"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("Broj računa"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Registracija računa"),
        "acton": MessageLookupByLibrary.simpleMessage("Akcija"),
        "add": MessageLookupByLibrary.simpleMessage("Dodaj"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Dodaj marku"),
        "addCategory": MessageLookupByLibrary.simpleMessage("Dodaj kategoriju"),
        "addContact": MessageLookupByLibrary.simpleMessage("Dodaj kontakt"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Dodaj kupca"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("Dodaj dostavu"),
        "addDescriptioN": MessageLookupByLibrary.simpleMessage("Dodaj opis"),
        "addDescription":
            MessageLookupByLibrary.simpleMessage("Dodaj napomenu"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Dodajte popust"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Dodaj ID dokumenta"),
        "addDucument": MessageLookupByLibrary.simpleMessage("Dodaj dokument"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Dodaj trošak"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Dodaj kategoriju troška"),
        "addItems": MessageLookupByLibrary.simpleMessage("Dodaj artikle"),
        "addNew": MessageLookupByLibrary.simpleMessage("Dodaj novo"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Dodaj novu adresu"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Dodaj novi proizvod"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("Dodajte novi porez"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Dodajte novi porez s jednom/višestrukom vrstom poreza"),
        "addNote": MessageLookupByLibrary.simpleMessage("Dodaj napomenu"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Prvo dodajte proizvod"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Dodajte promotivni kod"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Dodaj kupovinu"),
        "addSales": MessageLookupByLibrary.simpleMessage("Dodaj prodaju"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Uspješno dodano"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Dodaj jedinicu"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Dodaj korisničku ulogu"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Uspješno dodano"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("Dodano u košaricu"),
        "address": MessageLookupByLibrary.simpleMessage("Adresa"),
        "admin": MessageLookupByLibrary.simpleMessage("Administrator"),
        "all": MessageLookupByLibrary.simpleMessage("Sve"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("Sva poslovna rješenja"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("Već dodano"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Već postoji"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Već imate račun?"),
        "amount": MessageLookupByLibrary.simpleMessage("Iznos"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "Email je poslan\\nProvjerite svoju pristiglu poštu"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Podrška za Android i iOS aplikacije"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Primjenjivi porez"),
        "apply": MessageLookupByLibrary.simpleMessage("Primijeni"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Jeste li sigurni da želite izbrisati ovu fakturu"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Jeste li sigurni da želite obrisati ovu prodaju"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Jeste li sigurni da želite izbrisati ovog korisnika"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Jeste li sigurni da želite obrisati ovaj porez"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Jeste li sigurni da želite obrisati ovu poreznu grupu"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Želite li obrisati ovo skladište"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Jeste li sigurni da želite izbrisati ovog korisnika?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Ovlašteni potpis"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Vi ste odgovorni za održavanje povjerljivosti svog računa i lozinke i za ograničavanje pristupa vašem računu. Preuzimate odgovornost za sve aktivnosti koje se odvijaju na vašem računu."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Mora te imati najmanje 18 godina ili zakonski punoljetnost u vašem području za korištenje sustava."),
        "backSide": MessageLookupByLibrary.simpleMessage("Zadnja strana"),
        "backToHome": MessageLookupByLibrary.simpleMessage(
            "Povratak na početnu stranicu"),
        "balance": MessageLookupByLibrary.simpleMessage("Stanje"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladeš"),
        "bank": MessageLookupByLibrary.simpleMessage("Banka"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Valuta bankovnog računa"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Valuta bankovnog računa"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Bankovne informacije"),
        "bankName": MessageLookupByLibrary.simpleMessage("Ime banke"),
        "bankTransfer":
            MessageLookupByLibrary.simpleMessage("Bankovni prijenos"),
        "barcodeFound": MessageLookupByLibrary.simpleMessage("Barkod pronađen"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Račun/Faktura"),
        "billTo": MessageLookupByLibrary.simpleMessage("Račun na"),
        "branchName": MessageLookupByLibrary.simpleMessage("Ime podružnice"),
        "brand": MessageLookupByLibrary.simpleMessage("Marka"),
        "brandName": MessageLookupByLibrary.simpleMessage("Naziv marke"),
        "bulkUpload":
            MessageLookupByLibrary.simpleMessage("Masovno\nUčitavanje"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Kategorija poslovanja"),
        "buy": MessageLookupByLibrary.simpleMessage("Kupi"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Kupi Premium plan"),
        "buySms": MessageLookupByLibrary.simpleMessage("Kupi SMS"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Pristupom ili korištenjem sustava za prodaju (POS sustava) koji pruža [Ime Vaše tvrtke] („Tvrtka“), pristajete biti obvezani ovim Uvjetima korištenja. Ako se ne slažete s ovim Uvjetima korištenja, nemojte koristiti sustav."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Vi ste odgovorni za osiguravanje da vaš pristup i korištenje sustava budu u skladu sa svim primjenjivim zakonima i propisima."),
        "cacel": MessageLookupByLibrary.simpleMessage("Odustani"),
        "call": MessageLookupByLibrary.simpleMessage("Poziv"),
        "callForEmergencySupport":
            MessageLookupByLibrary.simpleMessage("Nazovite za hitnu podršku"),
        "camera": MessageLookupByLibrary.simpleMessage("Kamera"),
        "cancel": MessageLookupByLibrary.simpleMessage("Odustani"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Otkaži sve proizvode"),
        "capacity": MessageLookupByLibrary.simpleMessage("Kapacitet"),
        "card": MessageLookupByLibrary.simpleMessage("Kartica"),
        "cash": MessageLookupByLibrary.simpleMessage("Gotovina"),
        "cashFree":
            MessageLookupByLibrary.simpleMessage("Gotovina bez naknade"),
        "categories": MessageLookupByLibrary.simpleMessage("Kategorije"),
        "category": MessageLookupByLibrary.simpleMessage("Kategorija"),
        "categoryName":
            MessageLookupByLibrary.simpleMessage("Naziv kategorije"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "Naziv kategorije već postoji"),
        "cateogryName":
            MessageLookupByLibrary.simpleMessage("Naziv kategorije"),
        "change": MessageLookupByLibrary.simpleMessage("Promijeni"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Promijeni lozinku"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("Provjeri e-mail"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Odaberite kupca"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Odaberite dobavljača"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Odaberite svoje značajke"),
        "clarence": MessageLookupByLibrary.simpleMessage("Klarisa"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Kliknite za povezivanje"),
        "close": MessageLookupByLibrary.simpleMessage("Zatvori"),
        "color": MessageLookupByLibrary.simpleMessage("Boja"),
        "combinationOfMultipleTaxes":
            MessageLookupByLibrary.simpleMessage("(Kombinacija više poreza)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Uskoro dolazi"),
        "companyAddress": MessageLookupByLibrary.simpleMessage("Adresa tvrtke"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Naziv tvrtke i trgovine"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("Naziv tvrtke i poslovanja"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Dovrši transakciju"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Potvrdi lozinku"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Potvrdite povrat"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Čestitke"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Kontaktirajte nas"),
        "continu": MessageLookupByLibrary.simpleMessage("Nastavi"),
        "country": MessageLookupByLibrary.simpleMessage("Zemlja"),
        "create": MessageLookupByLibrary.simpleMessage("Stvori"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Izradite besplatan račun"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Stvoreno i spremljeno"),
        "currency": MessageLookupByLibrary.simpleMessage("Valuta"),
        "currentStock": MessageLookupByLibrary.simpleMessage("Trenutne zalihe"),
        "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
            "Prilagođeno označavanje računa"),
        "customer": MessageLookupByLibrary.simpleMessage("Kupac"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Detalji kupca"),
        "customerGST": MessageLookupByLibrary.simpleMessage("PDV kupca"),
        "customerName": MessageLookupByLibrary.simpleMessage("Ime kupca"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Dnevna transakcija"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Pregled nadzorne ploče"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Podaci uspješno spremljeni"),
        "date": MessageLookupByLibrary.simpleMessage("Datum"),
        "day": MessageLookupByLibrary.simpleMessage("Dan"),
        "dealer": MessageLookupByLibrary.simpleMessage("Dobavljač"),
        "dealerPrice":
            MessageLookupByLibrary.simpleMessage("Cijena za trgovca"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("Zadani postotak PDV-a"),
        "delete": MessageLookupByLibrary.simpleMessage("Izbriši"),
        "deleting": MessageLookupByLibrary.simpleMessage("Brisanje"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Adresa dostave"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Adrese dostave"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Trošak dostave"),
        "describtion": MessageLookupByLibrary.simpleMessage("Opis"),
        "description": MessageLookupByLibrary.simpleMessage("Opis"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Opis ne može biti prazan"),
        "details": MessageLookupByLibrary.simpleMessage("Detalji"),
        "discount": MessageLookupByLibrary.simpleMessage("Popust"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Ne ometaj"),
        "done": MessageLookupByLibrary.simpleMessage("Gotovo"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Preuzmi Excel format"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Uspješno preuzeto u mapu za preuzimanje"),
        "due": MessageLookupByLibrary.simpleMessage("Duguje"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Iznos duga:"),
        "dueCollection":
            MessageLookupByLibrary.simpleMessage("Prikupljeni dug"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("Izvješća o dugu za naplatu"),
        "dueList": MessageLookupByLibrary.simpleMessage("Popis duga"),
        "dueReports": MessageLookupByLibrary.simpleMessage("Izvještaji o dugu"),
        "duration": MessageLookupByLibrary.simpleMessage("Trajanje"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Trajanje: Od"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "Jednostavna mobilna POS aplikacija"),
        "edit": MessageLookupByLibrary.simpleMessage("Uredi"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Uredi račun za kupovinu"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Uredi račun za prodaju"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Uredi društvene medije"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Uspješno uređeno"),
        "editTax": MessageLookupByLibrary.simpleMessage("Uredi porez"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Uredi poreznu grupu"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("Uredi skladište"),
        "email": MessageLookupByLibrary.simpleMessage("E-pošta"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("Adresa e-pošte"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Email ne može biti prazan"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "E-pošta poslana! Provjerite pristiglu poštu"),
        "endDate": MessageLookupByLibrary.simpleMessage("Datum završetka"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Unesite valjan iznos"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Unesite valjan popust"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Unesite valjan broj telefona"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Unesite valjanu cijenu"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("Unesite valjanu količinu"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("Unesite adresu"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("Unesite iznos"),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Unesite naziv marke"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Unesite kapacitet"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Unesite naziv kategorije"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Unesite boju"),
        "enterCustomerGstNumber":
            MessageLookupByLibrary.simpleMessage("Unesite PDV broj kupca"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Unesite cijenu za trgovca"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Unesite opis"),
        "enterDiscount": MessageLookupByLibrary.simpleMessage("Unesite popust"),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Unesite datum troška"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Unesite punu adresu"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Unesite broj računa"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Unesite količinu za upozorenje na niske zalihe"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Unesite proizvođača"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("Unesite sadržaj poruke"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "Unesite MRP/cijenu za maloprodaju"),
        "enterName": MessageLookupByLibrary.simpleMessage("Unesite ime"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Unesite napomenu"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Unesite naziv stranke"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Unesite broj telefona"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Unesite šifru proizvoda ili skenirajte"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Unesite naziv proizvoda"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Unesite cijenu kupovine"),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("Unesite referentni broj"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Unesite veličinu"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("Unesite zalihe"),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Unesite poreznu stopu"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("Unesite ID transakcije"),
        "enterType": MessageLookupByLibrary.simpleMessage("Unesite tip"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("Unesite naslov korisnika"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Unesite valjani iznos"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Unesite naziv skladišta"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Unesite težinu"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Unesite cijenu veleprodaje"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("Unesite svoj opis ovdje"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "Unesite svoju adresu e-pošte"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "Unesite naslov povratne informacije"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Unesite svoj broj PDV-a"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("Unesite svoj broj mobitela"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Unesite svoje ime"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("Unesite svoj broj telefona"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Unesite svoju lozinku"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Unesite svoj broj telefona"),
        "enterYourTransactionId":
            MessageLookupByLibrary.simpleMessage("Unesite svoj ID transakcije"),
        "error": MessageLookupByLibrary.simpleMessage("Greška"),
        "excTax": MessageLookupByLibrary.simpleMessage("Isključen porez"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("Excel Uploader"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Isključen"),
        "expense": MessageLookupByLibrary.simpleMessage("Trošak"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Kategorija troška"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Datum troška"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Trošak za"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Izvješće o troškovima"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Datum isteka"),
        "expired": MessageLookupByLibrary.simpleMessage("Isteklo"),
        "expiring": MessageLookupByLibrary.simpleMessage("Istječe"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Neuspjelo s pogreškom"),
        "fashion": MessageLookupByLibrary.simpleMessage("Moda"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Značajke su važan dio koji Pos Saas čini drugačijim od tradicionalnih rješenja."),
        "feedBack":
            MessageLookupByLibrary.simpleMessage("Povratna informacija"),
        "firstName": MessageLookupByLibrary.simpleMessage("Ime"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Pratite nas na\\nFacebooku"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Pratite nas na\\nTwitteru"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Prednja strana"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("Za neograničenu upotrebu"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Zaboravili ste lozinku"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Zaboravili ste lozinku?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Od datuma"),
        "freeDataBackup": MessageLookupByLibrary.simpleMessage(
            "Besplatno sigurnosno kopiranje podataka"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "Besplatno doživotno ažuriranje"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Besplatni paket"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Besplatni plan"),
        "from": MessageLookupByLibrary.simpleMessage("Od"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Potpuno plaćeno"),
        "gallary": MessageLookupByLibrary.simpleMessage("Galerija"),
        "generatingPDF":
            MessageLookupByLibrary.simpleMessage("Generiranje PDF-a"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Dohvati OTP"),
        "govermentId": MessageLookupByLibrary.simpleMessage("Vladin ID"),
        "guest": MessageLookupByLibrary.simpleMessage("Gost"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Nemate račun?"),
        "history": MessageLookupByLibrary.simpleMessage("Povijest"),
        "home": MessageLookupByLibrary.simpleMessage("Početna"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Kako štitimo vaše informacije"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Kako koristimo vaše informacije"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Provjeri identitet"),
        "image": MessageLookupByLibrary.simpleMessage("Slika"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("InHouse se ne može obrisati"),
        "inHouseCantBeEdited": MessageLookupByLibrary.simpleMessage(
            "InHouse se ne može uređivati"),
        "inWord": MessageLookupByLibrary.simpleMessage("Riječima"),
        "incTax": MessageLookupByLibrary.simpleMessage("Uključ. porez"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Uključen"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("Povećaj zalihe"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Instrument"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Broj računa"),
        "invoice": MessageLookupByLibrary.simpleMessage("Račun"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("Broj računa"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Postavke računa"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Preglednik računa"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Artikl dodan"),
        "kg": MessageLookupByLibrary.simpleMessage("kg"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("Verifikacija KYC"),
        "language": MessageLookupByLibrary.simpleMessage("Jezik"),
        "lastName": MessageLookupByLibrary.simpleMessage("Prezime"),
        "ledger": MessageLookupByLibrary.simpleMessage("Knjiga"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Doživotna\nkupovina"),
        "link": MessageLookupByLibrary.simpleMessage("Poveznica"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Podrška uživo"),
        "loading": MessageLookupByLibrary.simpleMessage("Učitavanje"),
        "logIn": MessageLookupByLibrary.simpleMessage("Prijava"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Odjava"),
        "logOut": MessageLookupByLibrary.simpleMessage("Odjava"),
        "login": MessageLookupByLibrary.simpleMessage("Prijava"),
        "logo": MessageLookupByLibrary.simpleMessage("Logo"),
        "loss": MessageLookupByLibrary.simpleMessage("Gubitak"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Gubitak/Dobit"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Detalji gubitka/dobiti"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Izvještaj o gubitku/dobiti"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Izvještaji o gubitku/dobiti"),
        "lowStockAlert": MessageLookupByLibrary.simpleMessage(
            "Upozorenje o niskim zalihama"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Ostavite trajan dojam na svoje klijente s markiranim računima. Naša neograničena nadogradnja nudi jedinstvenu prednost prilagodbe računa, dodajući profesionalni dodir koji jača identitet vaše marke i potiče vjernost kupaca."),
        "manageYourBussinessWith": MessageLookupByLibrary.simpleMessage(
            "Upravljajte svojim poslovanjem s "),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Datum proizvodnje"),
        "margin": MessageLookupByLibrary.simpleMessage("Marža"),
        "masterCard": MessageLookupByLibrary.simpleMessage("MasterCard"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Proizvođač"),
        "message": MessageLookupByLibrary.simpleMessage("Poruka"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Povijest poruka"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Pos Sale aplikacija je besplatna i jednostavna za upotrebu. Zapravo, jedan je od najboljih POS sustava diljem svijeta."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas je potpuno poslovno rješenje sa zalihama, računima, prodajom, troškovima i gubitkom/dobitkom."),
        "mobile": MessageLookupByLibrary.simpleMessage("Mobilni"),
        "mobilePayment":
            MessageLookupByLibrary.simpleMessage("Mobilno plaćanje"),
        "monthly": MessageLookupByLibrary.simpleMessage("Mjesečno"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("Više informacija"),
        "name": MessageLookupByLibrary.simpleMessage("Unesite svoje ime"),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Ime već postoji"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("Ime ne može biti prazno"),
        "next": MessageLookupByLibrary.simpleMessage("Sljedeće"),
        "noConnection": MessageLookupByLibrary.simpleMessage("Nema veze"),
        "noData": MessageLookupByLibrary.simpleMessage("Nema podataka"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Nema dostupnih podataka"),
        "noDataFound": MessageLookupByLibrary.simpleMessage("Nema podataka"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("Nema pronađene povijesti!"),
        "noProductFound": MessageLookupByLibrary.simpleMessage(
            "Nije pronađen nijedan proizvod"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("Nije odabran podporez"),
        "noTransactionFound": MessageLookupByLibrary.simpleMessage(
            "Nema pronađenih transakcija!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Nema korisnika s tom adresom e-pošte."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "Nema pronađene korisničke uloge"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Nije aktivan korisnik"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Nije dostavljeno"),
        "note": MessageLookupByLibrary.simpleMessage("Napomena"),
        "notes": MessageLookupByLibrary.simpleMessage("Bilješke"),
        "notification": MessageLookupByLibrary.simpleMessage("Obavijest"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP poslan na"),
        "office": MessageLookupByLibrary.simpleMessage("Ured"),
        "ok": MessageLookupByLibrary.simpleMessage("U redu"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS sustav koji sadrži obilje funkcionalnosti, uključujući praćenje prodaje i upravljanje zalihama."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Ovaj sustav pomaže vam poboljšati operacije za vaše kupce."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Naš POS sustav trebao bi automatski pojednostaviti svakodnevne operacije, olakšavajući navigaciju."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("Početno stanje"),
        "order": MessageLookupByLibrary.simpleMessage("Narudžbe"),
        "other": MessageLookupByLibrary.simpleMessage("Ostalo"),
        "otp": MessageLookupByLibrary.simpleMessage("Zatvori"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Nema na skladištu"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Pakiranje"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Značajke paketa"),
        "paid": MessageLookupByLibrary.simpleMessage("Plaćeno"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Plaćeni iznos"),
        "parties": MessageLookupByLibrary.simpleMessage("Strane"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Popis stranaka"),
        "partyGST": MessageLookupByLibrary.simpleMessage("PDV stranke"),
        "partyName": MessageLookupByLibrary.simpleMessage("Naziv stranke"),
        "password": MessageLookupByLibrary.simpleMessage("Lozinka"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Lozinka i potvrda lozinke se ne podudaraju"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Lozinka ne može biti prazna"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("Lozinke se ne podudaraju"),
        "payCash": MessageLookupByLibrary.simpleMessage("Plati gotovinom"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("Plati putem bkash-a"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Plati putem Paypala"),
        "payeeName": MessageLookupByLibrary.simpleMessage("Naziv primatelja"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("Broj primatelja"),
        "payment": MessageLookupByLibrary.simpleMessage("Plaćanje"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("Iznos plaćanja"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Plaćanje dovršeno"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Upute za plaćanje:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("Način plaćanja"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Vrsta plaćanja"),
        "pdfView": MessageLookupByLibrary.simpleMessage("PDF prikaz"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Osobne informacije"),
        "phone": MessageLookupByLibrary.simpleMessage("Telefon"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Broj telefona"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Broj telefona je već korišten"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("Broj telefona nije valjan"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("Broj telefona je obavezan"),
        "pickAndUploadFile": MessageLookupByLibrary.simpleMessage(
            "Odaberite i učitajte datoteku"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("Odaberite datum završetka"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Odaberite datum početka"),
        "plan": MessageLookupByLibrary.simpleMessage("Plan"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("Molimo dodajte količinu"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Provjerite svoju internetsku povezanost"),
        "pleaseConnectThePrinterFirst":
            MessageLookupByLibrary.simpleMessage("Prvo spojite pisač"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Molimo povežite svoj Bluetooth pisač"),
        "pleaseEnterABiggerPassword":
            MessageLookupByLibrary.simpleMessage("Unesite dužu lozinku"),
        "pleaseEnterAConfirmPassword":
            MessageLookupByLibrary.simpleMessage("Unesite potvrdu lozinke"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("Unesite lozinku"),
        "pleaseEnterAValidEmail":
            MessageLookupByLibrary.simpleMessage("Unesite valjan email"),
        "pleaseEnterName": MessageLookupByLibrary.simpleMessage("Unesite ime"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("Molimo unesite lozinku"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Unesite svoju adresu e-pošte u nastavku kako biste primili vezu za resetiranje lozinke."),
        "pleaseEnterTransactionNumber":
            MessageLookupByLibrary.simpleMessage("Unesite broj transakcije"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("Unesite iznos"),
        "pleaseSelectACategoryFirst":
            MessageLookupByLibrary.simpleMessage("Prvo odaberite kategoriju"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("Molimo odaberite plan"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Odaberite poslovnu kategoriju"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Molimo koristite valjani kod za kupnju za korištenje aplikacije"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Pokreće Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Pokreće"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Premium korisnička podrška"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Premium plan"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Prethodni iznosi plaćanja"),
        "price": MessageLookupByLibrary.simpleMessage("Cijena"),
        "print": MessageLookupByLibrary.simpleMessage("Ispis"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Opcija ispisivanja"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Pravila o privatnosti"),
        "product": MessageLookupByLibrary.simpleMessage("Proizvod"),
        "productCode": MessageLookupByLibrary.simpleMessage("Šifra proizvoda"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("Kod proizvoda je obavezan"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Šifra/Naziv proizvoda"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Opis proizvoda"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Detalji o proizvodu"),
        "productList": MessageLookupByLibrary.simpleMessage("Popis proizvoda"),
        "productName": MessageLookupByLibrary.simpleMessage("Naziv proizvoda"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Naziv proizvoda već postoji u ovom skladištu"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Naziv proizvoda je već dodan"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("Naziv proizvoda je obavezan"),
        "products": MessageLookupByLibrary.simpleMessage("Proizvodi"),
        "profile": MessageLookupByLibrary.simpleMessage("Profil"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("Uredi profil"),
        "profit": MessageLookupByLibrary.simpleMessage("Dobit"),
        "promo": MessageLookupByLibrary.simpleMessage("Promocija"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Promotivna šifra"),
        "purchase": MessageLookupByLibrary.simpleMessage("Kupovina"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("Alarm za kupovinu"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Kupovina potvrđena"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Detalji kupovine"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Faktura kupnje"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("Popis kupovina"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Kupite odmah"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Kupi Premium plan"),
        "purchasePrice":
            MessageLookupByLibrary.simpleMessage("Cijena kupovine"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("Kupovna cijena je obavezna"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("Izvještaj o kupovini"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Izvještaji o kupovini"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Izvješća o kupovini"),
        "purchaseReturn": MessageLookupByLibrary.simpleMessage("Povrat kupnje"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("Izvještaj o povratu kupnje"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Prijelaz kupnje"),
        "qty": MessageLookupByLibrary.simpleMessage("Količina"),
        "quantity": MessageLookupByLibrary.simpleMessage("Količina"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Nedavne transakcije"),
        "recivedThePin": MessageLookupByLibrary.simpleMessage("Primljen PIN"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Referentni broj"),
        "register": MessageLookupByLibrary.simpleMessage("Registracija"),
        "registering": MessageLookupByLibrary.simpleMessage("Registracija"),
        "remainingDue":
            MessageLookupByLibrary.simpleMessage("Preostalo duguje"),
        "remove": MessageLookupByLibrary.simpleMessage("Ukloni"),
        "reports": MessageLookupByLibrary.simpleMessage("Izvještaji"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Zahtjev je poslan"),
        "resendCode":
            MessageLookupByLibrary.simpleMessage("Ponovno pošalji kod"),
        "resendOtp":
            MessageLookupByLibrary.simpleMessage("Ponovno pošalji OTP: "),
        "retailer": MessageLookupByLibrary.simpleMessage("Prodavač"),
        "retur": MessageLookupByLibrary.simpleMessage("Povrat"),
        "returN": MessageLookupByLibrary.simpleMessage("Povrat"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("Iznos povrata"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("Iznos povrata"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("Količina povrata"),
        "revenue": MessageLookupByLibrary.simpleMessage("Prihod"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Lako zaštitite podatke svojeg poslovanja. Naša Pos Saas POS Unlimited nadogradnja uključuje besplatno sigurnosno kopiranje podataka, osiguravajući da su vaši dragocjeni podaci zaštićeni od neočekivanih događaja. Fokusirajte se na ono što stvarno važi - rast vašeg poslovanja."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Iznos prodaje"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("Detalji prodaje"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Cijena prodaje"),
        "saleReports":
            MessageLookupByLibrary.simpleMessage("Izvještaji o prodaji"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Izvješća o prodaji"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("Povrat prodaje"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Izvještaj o povratu prodaje"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("Postavke prodaje"),
        "sales": MessageLookupByLibrary.simpleMessage("Prodaja"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("Izvješća o prodaji i kupnji"),
        "salesList": MessageLookupByLibrary.simpleMessage("Popis prodaje"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("Povrat prodaje"),
        "save": MessageLookupByLibrary.simpleMessage("Spremi"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Spremi i objavi"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("Spremi promjene"),
        "saving": MessageLookupByLibrary.simpleMessage("Spremanje"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("Skenirajte QR kod proizvoda"),
        "search": MessageLookupByLibrary.simpleMessage("Pretraživanje"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Pretraži po šifri ili nazivu proizvoda"),
        "seeAllPromoCode": MessageLookupByLibrary.simpleMessage(
            "Pogledajte sve promotivne šifre"),
        "select": MessageLookupByLibrary.simpleMessage("Odaberi"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Odaberite proizvod za povrat"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Odaberite marku"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Odaberite kategoriju"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Odaberite kontakte"),
        "selectProductCategory": MessageLookupByLibrary.simpleMessage(
            "Odaberite kategoriju proizvoda"),
        "selectShopCategory": MessageLookupByLibrary.simpleMessage(
            "Odaberite kategoriju trgovine"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Odaberite porez"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Odaberite vrstu poreza"),
        "selectUnit":
            MessageLookupByLibrary.simpleMessage("Odaberite jedinicu"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Odaberite varijaciju:"),
        "seller": MessageLookupByLibrary.simpleMessage("Prodavač"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Prodaje"),
        "send": MessageLookupByLibrary.simpleMessage("Pošalji"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("Pošalji e-poštu"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Pošalji poruku"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("Pošalji vezu za resetiranje"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Pošalji SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Poslati SMS?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Pošaljite WhatsApp poruku"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Pošaljite svoj e-mail"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage("Slanje e-pošte"),
        "sendingMessage": MessageLookupByLibrary.simpleMessage("Slanje poruke"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Usluga/Dostava"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Postavite svoj profil"),
        "setting": MessageLookupByLibrary.simpleMessage("Postavke"),
        "share": MessageLookupByLibrary.simpleMessage("Podijeli"),
        "shopGST": MessageLookupByLibrary.simpleMessage("PDV trgovine"),
        "signIn": MessageLookupByLibrary.simpleMessage("Prijavi se"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("Prijavi se putem emaila"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Potpis kupca"),
        "size": MessageLookupByLibrary.simpleMessage("Veličina"),
        "skip": MessageLookupByLibrary.simpleMessage("Preskoči"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Društveni marketing"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Nažalost, nemate dozvolu za pristup ovoj usluzi"),
        "startDate": MessageLookupByLibrary.simpleMessage("Datum početka"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Započnite novu prodaju"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage(
            "Počnite tipkati za pretraživanje"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Ostanite u prvom planu tehničkih napretka bez dodatnih troškova. Naša Pos Saas POS Unlimited nadogradnja osigurava da uvijek imate najnovije alate i značajke na dohvat ruke, jamčeći da vaša tvrtka ostane na vodećem mjestu."),
        "stillUnpaid":
            MessageLookupByLibrary.simpleMessage("Još uvijek neplaćeno"),
        "stock": MessageLookupByLibrary.simpleMessage("Zaliha"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Zaliha je obavezna"),
        "stockList": MessageLookupByLibrary.simpleMessage("Popis zaliha"),
        "stocks": MessageLookupByLibrary.simpleMessage("Zalihe"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Dopuštenje za pohranu je potrebno za stvaranje Excel datoteke"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("Popis podporeza"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Podporezi"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Međuzbroj"),
        "submit": MessageLookupByLibrary.simpleMessage("Pošalji"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "Pretplatite se na naš\\nYouTube"),
        "subscription": MessageLookupByLibrary.simpleMessage("Pretplata"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Uspješno izvršeno"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Uspješno odjavljeno"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Uspješno ažurirano"),
        "supplier": MessageLookupByLibrary.simpleMessage("Dobavljač"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("Naziv dobavljača"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT kod"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Uzmite vozačku dozvolu, osobnu iskaznicu ili fotografiju putovnice"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "Uzmite osobnu iskaznicu kako biste provjerili svoje podatke"),
        "tap": MessageLookupByLibrary.simpleMessage("Tap"),
        "tax": MessageLookupByLibrary.simpleMessage("Porez"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Porezna grupa"),
        "taxPercentage":
            MessageLookupByLibrary.simpleMessage("Postotak poreza"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Porezna stopa"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Porezne stope - Upravljajte svojim poreznim stopama"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Porezni izvještaj"),
        "taxType": MessageLookupByLibrary.simpleMessage("Vrsta poreza"),
        "taxes": MessageLookupByLibrary.simpleMessage("Porezi"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Uvjeti i odredbe"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("Uvjeti korištenja"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Uvjeti i privatnost"),
        "thankYOuForYourDuePayment":
            MessageLookupByLibrary.simpleMessage("Hvala vam na plaćanju duga"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Hvala"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Hvala vam na vašoj kupovini"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "Račun za taj email već postoji"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Excel datoteka je već preuzeta"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Sve je u imenu. S Pos Saas POS Unlimited nema ograničenja u upotrebi. Bilo da obrađujete nekoliko transakcija ili imate navalu kupaca, možete raditi s povjerenjem, znajući da niste ograničeni limitima."),
        "thePasswordProvidedIsTooWeak":
            MessageLookupByLibrary.simpleMessage("Pružena lozinka je preslaba"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Prodaja će biti izbrisana, a svi podaci o ovoj kupnji bit će izbrisani. Jeste li sigurni da želite obrisati?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Prodaja će biti izbrisana, a svi podaci o ovoj prodaji će biti izbrisani. Jeste li sigurni da želite obrisati?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Korisnik će biti izbrisan i svi podaci bit će izbrisani s vašeg računa. Jeste li sigurni da želite ovo izbrisati?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Korisnik će biti izbrisan, a svi podaci bit će uklonjeni s vašeg računa. Jeste li sigurni da želite izbrisati ovo?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Usluge trećih strana"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Ova kategorija se ne može obrisati"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Ovaj mjesec)"),
        "thisProductAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("Ovaj proizvod je već dodan"),
        "title": MessageLookupByLibrary.simpleMessage("Naslov"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Naslov ne može biti prazan"),
        "to": MessageLookupByLibrary.simpleMessage("do"),
        "toDate": MessageLookupByLibrary.simpleMessage("Do datuma"),
        "today": MessageLookupByLibrary.simpleMessage("Danas"),
        "total": MessageLookupByLibrary.simpleMessage("Ukupno"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Ukupni iznos"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Ukupno prikupljeno"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Ukupno duguje"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("Ukupni trošak"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Ukupan gubitak"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("Ukupno za platiti"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Ukupna cijena"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("Ukupno proizvoda"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Ukupna dobit"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("Ukupna kupnja"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Ukupan iznos povrata"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("Ukupno povrata"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Ukupna prodaja"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Ukupne zalihe"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Ukupna vrijednost"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Ukupni PDV"),
        "totals": MessageLookupByLibrary.simpleMessage("Ukupno:"),
        "transaction": MessageLookupByLibrary.simpleMessage("Transakcija"),
        "transactionId": MessageLookupByLibrary.simpleMessage("ID transakcije"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Pokušajte ponovno"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Tip"),
        "unitName": MessageLookupByLibrary.simpleMessage("Naziv jedinice"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Cijena po komadu"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Jedinična cijena"),
        "units": MessageLookupByLibrary.simpleMessage("Jedinice"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Neograničeno"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Neograničena upotreba"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Otkrijte puni potencijal Pos Saas POS-a s personaliziranim treninzima koje vodi naš stručni tim. Od osnovnih do naprednih tehnika, osiguravamo da ste dobro upućeni u korištenje svakog aspekta sustava kako biste optimizirali svoje poslovne procese."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Neplaćeno"),
        "update": MessageLookupByLibrary.simpleMessage("Ažuriraj"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Ažuriraj kontakt"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Ažurirajte sada"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("Ažuriraj proizvod"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Ažurirajte svoj plan, vaš limit je istekao"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Ažurirajte svoj profil"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Ažurirajte svoj profil kako biste se bolje povezali sa svojim doktorom"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Ažurirajte svoj profil kako biste se bolje povezali s kupcem"),
        "updated": MessageLookupByLibrary.simpleMessage("Ažurirano"),
        "upload": MessageLookupByLibrary.simpleMessage("Učitaj"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Učitaj dokument"),
        "uploadDone":
            MessageLookupByLibrary.simpleMessage("Učitavanje završeno"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Učitaj datoteku"),
        "upplier": MessageLookupByLibrary.simpleMessage("Dobavljač"),
        "usbC": MessageLookupByLibrary.simpleMessage("Usb C"),
        "use": MessageLookupByLibrary.simpleMessage("Koristite"),
        "useMobiPos":
            MessageLookupByLibrary.simpleMessage("Koristite Pos Saas"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Korištenje sustava"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Korisnik je izbrisan"),
        "userRole": MessageLookupByLibrary.simpleMessage("Korisnička uloga"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("Detalji korisničke uloge"),
        "userTitle": MessageLookupByLibrary.simpleMessage("Naslov korisnika"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Naslov korisnika ne može biti prazan"),
        "value": MessageLookupByLibrary.simpleMessage("Vrijednost"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("PDV se ne primjenjuje"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("Verifikacija OTP-a"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Verificiraj broj telefona"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Prikaži sve"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("Pogledaj detalje"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Kupac bez narudžbe"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Skladište"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Skladište već postoji"),
        "warehouseList":
            MessageLookupByLibrary.simpleMessage("Popis skladišta"),
        "warehouseName":
            MessageLookupByLibrary.simpleMessage("Naziv skladišta"),
        "warranty": MessageLookupByLibrary.simpleMessage("Jamstvo"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Poslali smo vam e-mail s uputama o tome kako resetirati lozinku na:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Možemo koristiti usluge trećih strana kako bismo podržali funkcionalnost naše aplikacije, kao što su pružatelji analitike i procesori plaćanja. Ove usluge trećih strana mogu prikupljati informacije o vama kada koristite našu aplikaciju. Imajte na umu da nismo odgovorni za praksu privatnosti ovih usluga trećih strana."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Poduzimamo standardne mjere zaštite vaših osobnih informacija, uključujući šifriranje i sigurno pohranjivanje. Također ograničavamo pristup vašim informacijama samo ovlaštenom osoblju."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Razumijemo važnost besprijekornog poslovanja. Zato vam je naša podrška dostupna 24 sata dnevno, bilo da se radi o brzom pitanju ili sveobuhvatnom problemu. Povežite se s nama bilo kada i bilo gdje putem poziva ili WhatsApp-a kako biste doživjeli neusporedivu korisničku uslugu."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Koristimo vaše osobne informacije kako bismo vam pružili najbolje moguće iskustvo na našoj aplikaciji, uključujući personalizaciju preporuka za sadržaj, povezivanje s ekspertima i poboljšanje funkcionalnosti naše aplikacije. Također možemo koristiti vaše informacije kako bismo vas obavještavali o ažuriranjima, promocijama ili drugim informacijama povezanim s našom aplikacijom."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Pregledat ćemo uplatu i odobriti je unutar 1-2 sata"),
        "weekly": MessageLookupByLibrary.simpleMessage("Tjedno"),
        "weight": MessageLookupByLibrary.simpleMessage("Težina"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Što je novo"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Veledobavljač"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Cijena veleprodaje"),
        "wholesalePrice":
            MessageLookupByLibrary.simpleMessage("Veleprodajna cijena"),
        "wholesaler":
            MessageLookupByLibrary.simpleMessage("Veleprodajni kupac"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Bit će uskoro dodano"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Isteknut će"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Napišite svoju poruku ovdje"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("Pogrešan OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Navedena je kriva lozinka za tog korisnika."),
        "yearly": MessageLookupByLibrary.simpleMessage("Godišnje"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Da, izbriši zauvijek"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("Niste valjan korisnik"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Koristite"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Ne možete platiti više od duga"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Dobili ste e-mail"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Uspješno ste se prijavili na svoj račun. Ostanite uz Pos Saas."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("Morate dati dopuštenje"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Morate se ponovno prijaviti na svoj račun."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Morate provjeriti identitet prije kupovine SMS-a"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Vaša poruka ostaje"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Vaš paket"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Vaš paket će isteći za 5 dana")
      };
}
