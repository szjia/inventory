// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a lt locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'lt';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Tęsti"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("GST numeris"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("MRP yra privalomas"),
        "OK": MessageLookupByLibrary.simpleMessage("Gerai"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("PayPal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Tel. nr."),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT Kodas"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Užkandžiai"),
        "TAX": MessageLookupByLibrary.simpleMessage("MOKESTIS"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Kraunama"),
        "UserTitle":
            MessageLookupByLibrary.simpleMessage("Vartotojo pavadinimas"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Jūsų paketas baigs galioti šiandien\n\nPrašome pirkti dar kartą"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) Sistema teikiama tik tam, kad palengvintų pardavimo operacijas ir susijusias veiklas jūsų versle."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) Norint naudotis Sistema, gali reikėti sukurti paskyrą. Sutinkate pateikti tikslią, dabartinę ir išsamią informaciją registracijos proceso metu ir atnaujinti tokią informaciją, kad ji būtų tiksli ir išsami."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("Apie programą"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Apie mus"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Sąlygų priėmimas"),
        "accountName":
            MessageLookupByLibrary.simpleMessage("Sąskaitos pavadinimas"),
        "accountNumber":
            MessageLookupByLibrary.simpleMessage("Sąskaitos numeris"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Paskyros registracija"),
        "acton": MessageLookupByLibrary.simpleMessage("Veiksmas"),
        "add": MessageLookupByLibrary.simpleMessage("Pridėti"),
        "addBrand":
            MessageLookupByLibrary.simpleMessage("Pridėti Prekės Ženklo"),
        "addCategory":
            MessageLookupByLibrary.simpleMessage("Pridėti Kategoriją"),
        "addContact": MessageLookupByLibrary.simpleMessage("Pridėti Kontaktą"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Pridėti Klientą"),
        "addDelivery":
            MessageLookupByLibrary.simpleMessage("Pridėti Pristatymą"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Pridėti Aprašymą"),
        "addDescription":
            MessageLookupByLibrary.simpleMessage("Pridėti Pastabą"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Pridėti nuolaidą"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Pridėti dokumento ID"),
        "addDucument":
            MessageLookupByLibrary.simpleMessage("Pridėti dokumentą"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Pridėti Išlaidas"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Pridėti Išlaidų Kategoriją"),
        "addItems": MessageLookupByLibrary.simpleMessage("Pridėti Prekes"),
        "addNew": MessageLookupByLibrary.simpleMessage("Pridėti Naują"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Pridėti Naują Adresą"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Pridėti Produktą"),
        "addNewTax":
            MessageLookupByLibrary.simpleMessage("Pridėti Naują Mokestį"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Pridėti Naują Mokestį su vienu/daugybe Mokestį"),
        "addNote": MessageLookupByLibrary.simpleMessage("Pridėti Pastabą"),
        "addProductFirst": MessageLookupByLibrary.simpleMessage(
            "Pirmiausia pridėkite produktą"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Pridėti akcijos kodą"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Pridėti Pirkimą"),
        "addSales": MessageLookupByLibrary.simpleMessage("Pridėti pardavimus"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Sėkmingai pridėta"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Pridėti Vnt."),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Pridėti vartotojo vaidmenį"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Sėkmingai pridėta"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("Pridėta Į Krepšelį"),
        "address": MessageLookupByLibrary.simpleMessage("Adresas"),
        "admin": MessageLookupByLibrary.simpleMessage("Administratorius"),
        "all": MessageLookupByLibrary.simpleMessage("Visi"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("Visos verslo sprendimų"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("Jau pridėta"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Jau Egzistuoja"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Jau turite paskyrų"),
        "amount": MessageLookupByLibrary.simpleMessage("Suma"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "El. laiškas buvo išsiųstas\\nPatikrinkite savo pašto dėžutę"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Android ir iOS programėlės palaikymas"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Taikomas mokestis"),
        "apply": MessageLookupByLibrary.simpleMessage("Taikyti"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Ar tikrai norite ištrinti šią sąskaitą?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Ar tikrai norite ištrinti šią pardavimą?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Ar tikrai norite ištrinti šį vartotoją?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Ar tikrai norite ištrinti šį mokestį?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Ar tikrai norite ištrinti šią mokesčių grupę?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Ar norite ištrinti šį sandėlį?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Ar tikrai norite ištrinti šį vartotoją?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Įgalioto Parašas"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Jūs esate atsakingas už savo paskyros ir slaptažodžio konfidencialumo užtikrinimą bei prieigos prie savo paskyros apribojimą. Priimate atsakomybę už visus veiksmus, kurie vyksta jūsų paskyroje."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Jūs turite būti bent 18 metų amžiaus arba būti teisėtu suaugusiuoju pagal jūsų jurisdikciją, kad galėtumėte naudotis Sistema."),
        "backSide": MessageLookupByLibrary.simpleMessage("Atvirkštinė pusė"),
        "backToHome": MessageLookupByLibrary.simpleMessage("Atgal į namus"),
        "balance": MessageLookupByLibrary.simpleMessage("Balansas"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladešas"),
        "bank": MessageLookupByLibrary.simpleMessage("Bankas"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Banko Sąskaitos Valiuta"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Banko sąskaitos valiuta"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Banko informacija"),
        "bankName": MessageLookupByLibrary.simpleMessage("Banko pavadinimas"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("Banko Perlaida"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Juostos kodas rastas"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Sąskaita/Faktūra"),
        "billTo": MessageLookupByLibrary.simpleMessage("Sąskaita"),
        "branchName":
            MessageLookupByLibrary.simpleMessage("Filialo pavadinimas"),
        "brand": MessageLookupByLibrary.simpleMessage("Prekės Ženklas"),
        "brandName":
            MessageLookupByLibrary.simpleMessage("Prekės Ženklo Pavadinimas"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("Masinis\nįkėlimas"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Verslo Kategorija"),
        "buy": MessageLookupByLibrary.simpleMessage("Pirkti"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Pirkti Premium planą"),
        "buySms": MessageLookupByLibrary.simpleMessage("Pirkti SMS"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Naudodamiesi arba pasiekdami Pardavimo taško (POS) sistemą (toliau - \"Sistema\"), kurią teikia [Jūsų įmonės pavadinimas] (toliau - \"Įmonė\"), sutinkate laikytis šių Naudojimosi sąlygų. Jei nesutinkate su šios Naudojimosi sąlygomis, nesinaudokite Sistema."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Jūs esate atsakingas už tai, kad jūsų prieiga prie ir naudojimasis Sistema atitiktų visus taikomus įstatymus ir taisykles."),
        "cacel": MessageLookupByLibrary.simpleMessage("Atšaukti"),
        "call": MessageLookupByLibrary.simpleMessage("Skambinti"),
        "callForEmergencySupport":
            MessageLookupByLibrary.simpleMessage("Skambinti pagalbai"),
        "camera": MessageLookupByLibrary.simpleMessage("Kamera"),
        "cancel": MessageLookupByLibrary.simpleMessage("Atšaukti"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Atšaukti visus produktus"),
        "capacity": MessageLookupByLibrary.simpleMessage("Talpa"),
        "card": MessageLookupByLibrary.simpleMessage("Kortelė"),
        "cash": MessageLookupByLibrary.simpleMessage("Grynaisiais"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Kategorijos"),
        "category": MessageLookupByLibrary.simpleMessage("Kategorija"),
        "categoryName":
            MessageLookupByLibrary.simpleMessage("Kategorijos Pavadinimas"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "Kategorijos Pavadinimas Jau Egzistuoja"),
        "cateogryName":
            MessageLookupByLibrary.simpleMessage("Kategorijos Pavadinimas"),
        "change": MessageLookupByLibrary.simpleMessage("Pakeisti?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Keisti Slaptažodį"),
        "checkEmail":
            MessageLookupByLibrary.simpleMessage("Patikrinkite el. paštą"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Pasirinkite klientą"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Pasirinkite Tiekėją"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Pasirinkite savo funkcijas"),
        "clarence": MessageLookupByLibrary.simpleMessage("Išpardavimas"),
        "clickToConnect": MessageLookupByLibrary.simpleMessage(
            "Paspauskite, kad prisijungtumėte"),
        "close": MessageLookupByLibrary.simpleMessage("Uždaryti"),
        "color": MessageLookupByLibrary.simpleMessage("Spalva"),
        "combinationOfMultipleTaxes":
            MessageLookupByLibrary.simpleMessage("(Daugelio mokesčių derinys)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Netrukus"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Įmonės Adresas"),
        "companyAndShopName": MessageLookupByLibrary.simpleMessage(
            "Įmonės ir Parduotuvės Pavadinimas"),
        "companyBusinessName": MessageLookupByLibrary.simpleMessage(
            "Įmonės ir Verslo Pavadinimas"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Užbaigti sandorį"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Patvirtinti Slaptažodį"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Patvirtinti Grąžinimą"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Sveikiname"),
        "contactUs":
            MessageLookupByLibrary.simpleMessage("Susisiekite su mumis"),
        "continu": MessageLookupByLibrary.simpleMessage("Tęsti"),
        "country": MessageLookupByLibrary.simpleMessage("Šalis"),
        "create": MessageLookupByLibrary.simpleMessage("Sukurti"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Sukurti Nemokamą Paskyrą"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Sukurtas ir Išsaugotas"),
        "currency": MessageLookupByLibrary.simpleMessage("Valiuta"),
        "currentStock":
            MessageLookupByLibrary.simpleMessage("Dabartinis likutis"),
        "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
            "Pasirinktinis sąskaitų faktūrų prekės ženklas"),
        "customer": MessageLookupByLibrary.simpleMessage("Klientas"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Kliento Duomenys"),
        "customerGST": MessageLookupByLibrary.simpleMessage("Kliento GST"),
        "customerName": MessageLookupByLibrary.simpleMessage("Kliento Vardas"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Kasdienė Operacija"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Valdymo skydelis"),
        "dataSavedSuccessfully": MessageLookupByLibrary.simpleMessage(
            "Duomenys sėkmingai išsaugoti"),
        "date": MessageLookupByLibrary.simpleMessage("Data"),
        "day": MessageLookupByLibrary.simpleMessage("Diena"),
        "dealer": MessageLookupByLibrary.simpleMessage("Pardavėjas"),
        "dealerPrice":
            MessageLookupByLibrary.simpleMessage("Prekybininko Kaina"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("Numatytas PVM procentas"),
        "delete": MessageLookupByLibrary.simpleMessage("Ištrinti"),
        "deleting": MessageLookupByLibrary.simpleMessage("Naikinama"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Pristatymo Adresas"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Pristatymo adresai"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Pristatymo Mokestis"),
        "describtion": MessageLookupByLibrary.simpleMessage("Aprašymas"),
        "description": MessageLookupByLibrary.simpleMessage("Aprašymas"),
        "descriptionCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Aprašymas negali būti tuščias"),
        "details": MessageLookupByLibrary.simpleMessage("Detalės"),
        "discount": MessageLookupByLibrary.simpleMessage("Nuolaida"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Netrukdyti"),
        "done": MessageLookupByLibrary.simpleMessage("Baigta"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Atsisiųsti Excel Formatą"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Sėkmingai atsisiųsta į atsisiuntimų aplanką"),
        "due": MessageLookupByLibrary.simpleMessage("Mokėtina"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Mokėtina Suma: "),
        "dueCollection":
            MessageLookupByLibrary.simpleMessage("Mokėtinos Sumos Surinkimas"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("Pradelstų sumų ataskaitos"),
        "dueList": MessageLookupByLibrary.simpleMessage("Mokėtinos Sumos"),
        "dueReports": MessageLookupByLibrary.simpleMessage("Skolos ataskaita"),
        "duration": MessageLookupByLibrary.simpleMessage("Trukmė"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Trukmė: Nuo"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "Lengva naudoti mobilioji POS"),
        "edit": MessageLookupByLibrary.simpleMessage("Redaguoti"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Redaguoti pirkimo sąskaitą"),
        "editSalesInvoice": MessageLookupByLibrary.simpleMessage(
            "Redaguoti pardavimo sąskaitą"),
        "editSocailMedia": MessageLookupByLibrary.simpleMessage(
            "Redaguoti Socialinę Žiniasklaidą"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Sėkmingai Redaguota"),
        "editTax": MessageLookupByLibrary.simpleMessage("Redaguoti Mokestį"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Redaguoti Mokesčių Grupę"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("Redaguoti Sandėlį"),
        "email": MessageLookupByLibrary.simpleMessage("El. paštas"),
        "emailAddress":
            MessageLookupByLibrary.simpleMessage("El. pašto adresas"),
        "emailCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "El. paštas negali būti tuščias"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "El. Paštas Išsiųstas! Patikrinkite savo Gauti"),
        "endDate": MessageLookupByLibrary.simpleMessage("Pabaigos data"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Įveskite galiojančią sumą"),
        "enterAValidDiscount": MessageLookupByLibrary.simpleMessage(
            "Įveskite galiojantį Nuolaidą"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Įveskite galiojantį telefono numerį"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Įveskite galiojančią kainą"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("Įveskite galiojantį kiekį"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("Įveskite Adresą"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("Įveskite Sumą."),
        "enterBrandName": MessageLookupByLibrary.simpleMessage(
            "Įveskite Prekės Ženklo Pavadinimą"),
        "enterCapacity": MessageLookupByLibrary.simpleMessage("Įveskite Talpą"),
        "enterCategoryName": MessageLookupByLibrary.simpleMessage(
            "Įveskite Kategorijos Pavadinimą"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Įveskite Spalvą"),
        "enterCustomerGstNumber":
            MessageLookupByLibrary.simpleMessage("Įveskite kliento GST numerį"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Įveskite Prekybininko Kainą"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Įveskite Aprašymą"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("Įveskite Nuolaidą."),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Įveskite Išlaidų Datą"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Įveskite Visą Adresą"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Įveskite sąskaitos numerį"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Įveskite Mažo Atsargų Pranešimo Kiekį"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Įveskite Gamytoją"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("Įveskite žinutės turinį"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "Įveskite MRP/Pardavėjo Kainą"),
        "enterName": MessageLookupByLibrary.simpleMessage("Įveskite Vardą"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Įveskite Pastabą"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Įveskite Šalies Pavadinimą"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Įveskite Telefono Numerį"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Įveskite Produkto Kodą arba Nuskaitykite"),
        "enterProductName": MessageLookupByLibrary.simpleMessage(
            "Įveskite Produkto Pavadinimą"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Įveskite Pirkimo Kainą."),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("Įveskite Nuorodos Numerį"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Įveskite Dydį"),
        "enterStocks":
            MessageLookupByLibrary.simpleMessage("Įveskite Atsargas."),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Įveskite Mokesčių Normą"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("Įveskite sandorio ID"),
        "enterType": MessageLookupByLibrary.simpleMessage("Įveskite Tipą"),
        "enterUserTitle": MessageLookupByLibrary.simpleMessage(
            "Įveskite vartotojo pavadinimą"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Įveskite galiojantį sumą"),
        "enterWarehouseName": MessageLookupByLibrary.simpleMessage(
            "Įveskite Sandėlio Pavadinimą"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Įveskite Svorį"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Įveskite Didmeninę Kainą"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("Įveskite savo aprašymą čia"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "Įveskite savo el. pašto adresą"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "Įveskite savo atsiliepimo pavadinimą"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Įveskite savo GST numerį"),
        "enterYourMobileNumber": MessageLookupByLibrary.simpleMessage(
            "Įveskite savo mobiliojo telefono numerį"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Įveskite Savo Vardą"),
        "enterYourNumber": MessageLookupByLibrary.simpleMessage(
            "Įveskite savo telefono numerį"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Įveskite savo slaptažodį"),
        "enterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Įveskite Savo Telefono Numerį"),
        "enterYourTransactionId":
            MessageLookupByLibrary.simpleMessage("Įveskite savo sandorio ID"),
        "error": MessageLookupByLibrary.simpleMessage("Klaida"),
        "excTax": MessageLookupByLibrary.simpleMessage("Išskaitant mokestį"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("Excel Įkėlėjas"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Išskirta"),
        "expense": MessageLookupByLibrary.simpleMessage("Išlaidos"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Išlaidų Kategorija"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Išlaidų Data"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Išlaidos už"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Išlaidų Ataskaita"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Galiojimo Data"),
        "expired": MessageLookupByLibrary.simpleMessage("Pasibaigęs"),
        "expiring": MessageLookupByLibrary.simpleMessage("Galioja"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Nepavyko su Klaida"),
        "fashion": MessageLookupByLibrary.simpleMessage("Mada"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Funkcijos yra svarbi dalis, kuri daro POS SaaS skirtingą nuo tradicinių sprendimų."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Atsiliepimai"),
        "firstName": MessageLookupByLibrary.simpleMessage("Vardas"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Sekite mus Facebook\'e"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Sekite mus Twitter\'yje"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Priekinė pusė"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("Neišsemiamam naudojimui"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Pamiršote slaptažodį"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Pamiršote slaptažodį?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Nuo Datos"),
        "freeDataBackup": MessageLookupByLibrary.simpleMessage(
            "Nemokama duomenų atsarginė kopija"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "Nemokamas gyvavimo atnaujinimas"),
        "freePacakge":
            MessageLookupByLibrary.simpleMessage("Nemokamas paketas"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Nemokamas planas"),
        "from": MessageLookupByLibrary.simpleMessage("(Nuo"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Visiškai Apmokėta"),
        "gallary": MessageLookupByLibrary.simpleMessage("Galerija"),
        "generatingPDF":
            MessageLookupByLibrary.simpleMessage("Generuojama PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Gauti OTP"),
        "govermentId": MessageLookupByLibrary.simpleMessage("Vyriausybinis ID"),
        "guest": MessageLookupByLibrary.simpleMessage("Svečių"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Neturite paskyros?"),
        "history": MessageLookupByLibrary.simpleMessage("Istorija"),
        "home": MessageLookupByLibrary.simpleMessage("Pagrindinis"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Kaip mes saugome jūsų informaciją"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Kaip mes naudojame jūsų informaciją"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Tapatybės patikra"),
        "image": MessageLookupByLibrary.simpleMessage("Vaizdas"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("Įmonėje negalima ištrinti"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("Įmonėje negalima redaguoti"),
        "inWord": MessageLookupByLibrary.simpleMessage("Žodžiais"),
        "incTax": MessageLookupByLibrary.simpleMessage("Įskaitant mokestį"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Įskaičiuota"),
        "increaseStock":
            MessageLookupByLibrary.simpleMessage("Padidinti Atsargas"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Instrumentas"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Sąsk. Nr."),
        "invoice": MessageLookupByLibrary.simpleMessage("Sąskaita"),
        "invoiceNumber":
            MessageLookupByLibrary.simpleMessage("Sąskaitos numeris"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Sąskaitų nustatymai"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Sąskaitos peržiūra"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Prekė Pridėta"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification": MessageLookupByLibrary.simpleMessage("KYC patikra"),
        "language": MessageLookupByLibrary.simpleMessage("Kalba"),
        "lastName": MessageLookupByLibrary.simpleMessage("Pavardė"),
        "ledger": MessageLookupByLibrary.simpleMessage("Apskaitos Žurnalas"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Viso gyvenimo\npirkimas"),
        "link": MessageLookupByLibrary.simpleMessage("Nuoroda"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Gyvas Pokalbių Palaikymas"),
        "loading": MessageLookupByLibrary.simpleMessage("Kraunama"),
        "logIn": MessageLookupByLibrary.simpleMessage("Prisijungti"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Atsijungti"),
        "logOut": MessageLookupByLibrary.simpleMessage("Atsijungti"),
        "login": MessageLookupByLibrary.simpleMessage("Prisijungti"),
        "logo": MessageLookupByLibrary.simpleMessage("Logotipas"),
        "loss": MessageLookupByLibrary.simpleMessage("Nuostoliai"),
        "lossOrProfit":
            MessageLookupByLibrary.simpleMessage("Nuostoliai/Pelno"),
        "lossOrProfitDetails": MessageLookupByLibrary.simpleMessage(
            "Nuostolių/Pelno Išsami Informacija"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Nuostolių/Pelno Ataskaita"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Nuostolių/Pelno Ataskaitos"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Mažo Atsargų Pranešimas"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Padarykite ilgalaikį įspūdį savo klientams su prekės ženklu pažymėtomis sąskaitomis faktūromis. Mūsų neribotas atnaujinimas siūlo unikalią galimybę pritaikyti jūsų sąskaitas faktūras, suteikdamas profesionalų atspalvį, kuris sustiprina jūsų prekės ženklo tapatybę ir skatina klientų lojalumą."),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("Tvarkykite savo verslą su"),
        "manufactureDate": MessageLookupByLibrary.simpleMessage("Gaminti Data"),
        "margin": MessageLookupByLibrary.simpleMessage("Marža"),
        "masterCard": MessageLookupByLibrary.simpleMessage("MasterCard"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Gamytojas"),
        "message": MessageLookupByLibrary.simpleMessage("Žinutė"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Žinučių istorija"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "POS SaaS programa yra nemokama, lengva naudoti. Iš tikrųjų tai yra viena geriausių POS sistemų visame pasaulyje."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "POS SaaS yra visapusiškas verslo sprendimas su atsargomis, apskaita, pardavimais, išlaidomis ir pelnu/nuostoliais."),
        "mobile": MessageLookupByLibrary.simpleMessage("Mobilus"),
        "mobilePayment":
            MessageLookupByLibrary.simpleMessage("Mobilusis mokėjimas"),
        "monthly": MessageLookupByLibrary.simpleMessage("Mėnesinis"),
        "moreInfo":
            MessageLookupByLibrary.simpleMessage("Daugiau Informacijos"),
        "name": MessageLookupByLibrary.simpleMessage("Įveskite Savo Vardą."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Pavadinimas Jau Egzistuoja"),
        "nameCantBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Pavadinimas negali būti tuščias"),
        "next": MessageLookupByLibrary.simpleMessage("Kitas"),
        "noConnection": MessageLookupByLibrary.simpleMessage("Nėra ryšio"),
        "noData": MessageLookupByLibrary.simpleMessage("Nėra duomenų"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Nėra prieinamų duomenų"),
        "noDataFound": MessageLookupByLibrary.simpleMessage("Duomenų Nerasta"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("Istorija nerasta!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Produktas nerastas"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("Nėra pasirinkta submokesčių"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("Sandoris nerastas!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Vartotojas nerastas pagal šį el. pašto adresą."),
        "noUserRoleFound":
            MessageLookupByLibrary.simpleMessage("Vartotojo vaidmuo nerastas"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Neaktyvus Vartotojas"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Neteikta"),
        "note": MessageLookupByLibrary.simpleMessage("Pastaba"),
        "notes": MessageLookupByLibrary.simpleMessage("Pastabos"),
        "notification": MessageLookupByLibrary.simpleMessage("Pranešimas"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP išsiųsta į"),
        "office": MessageLookupByLibrary.simpleMessage("Biuras"),
        "ok": MessageLookupByLibrary.simpleMessage("Gerai"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS, turintis daugybę funkcijų, įskaitant pardavimų sekimą ir atsargų valdymą."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Ši sistema padeda jums pagerinti jūsų operacijas jūsų klientams."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Mūsų POS sistema turėtų supaprastinti kasdienę veiklą automatiškai, kad būtų lengva naršyti."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("Pradinis Balansas"),
        "order": MessageLookupByLibrary.simpleMessage("Užsakymai"),
        "other": MessageLookupByLibrary.simpleMessage("Kita"),
        "otp": MessageLookupByLibrary.simpleMessage("Uždaryti"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Nėra Atsargų"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Pakuotė"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Paketo funkcijos"),
        "paid": MessageLookupByLibrary.simpleMessage("Apmokėta"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Sumokėta Suma"),
        "parties": MessageLookupByLibrary.simpleMessage("Šalys"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Šalių Sąrašas"),
        "partyGST": MessageLookupByLibrary.simpleMessage("Šalies GST"),
        "partyName": MessageLookupByLibrary.simpleMessage("Šalies Pavadinimas"),
        "password": MessageLookupByLibrary.simpleMessage("Slaptažodis"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Slaptažodis ir patvirtinimo slaptažodis nesutampa"),
        "passwordCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Slaptažodis negali būti tuščias"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("Slaptažodžiai nesutampa"),
        "payCash": MessageLookupByLibrary.simpleMessage("Mokėti grynaisiais"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash": MessageLookupByLibrary.simpleMessage("Mokėti su Bkash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Mokėti per Paypal"),
        "payeeName": MessageLookupByLibrary.simpleMessage("Mokėtojo vardas"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("Mokėtojo numeris"),
        "payment": MessageLookupByLibrary.simpleMessage("Mokėjimas"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("Mokėjimo Suma"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Mokėjimas Baigtas"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Mokėjimo instrukcijos:"),
        "paymentMethod":
            MessageLookupByLibrary.simpleMessage("Mokėjimo Metodas"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Mokėjimo Tipas"),
        "pdfView": MessageLookupByLibrary.simpleMessage("PDF Peržiūra"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Asmeninė informacija"),
        "phone": MessageLookupByLibrary.simpleMessage("Telefonas"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Telefono Numeris"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Telefono numeris jau naudojamas"),
        "phoneNumberIsNotValid": MessageLookupByLibrary.simpleMessage(
            "Telefono numeris nėra galiojantis"),
        "phoneNumberIsRequired": MessageLookupByLibrary.simpleMessage(
            "Telefono numeris yra privalomas"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("Pasirinkti ir Įkelti Failą"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("Pasirinkite pabaigos datą"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Pasirinkite pradžios datą"),
        "plan": MessageLookupByLibrary.simpleMessage("Planas"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("Prašome pridėti kiekį"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Prašome patikrinti interneto ryšį"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Prašome pirmiausia prijungti spausdintuvą"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Prašome prijungti savo „Bluetooth“ spausdintuvą"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Prašome įvesti ilgesnį slaptažodį"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Prašome Įvesti Patvirtintą Slaptažodį"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("Prašome įvesti slaptažodį"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Prašome įvesti galiojantį el. paštą"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Prašome įvesti vardą"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("Prašome įvesti slaptažodį"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Įveskite savo el. pašto adresą žemiau, kad gautumėte slaptažodžio atkūrimo nuorodą."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Prašome įvesti sandorio numerį"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("Prašome įvesti sumą"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Prašome pirmiausia pasirinkti kategoriją"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("Prašome pasirinkti planą"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Prašome pasirinkti verslo kategoriją"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Prašome naudoti galiojantį pirkimo kodą, kad naudotumėte programą"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Teikia Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Sukurtas"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Premium klientų palaikymas"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Premium planas"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Ankstesnių mokėjimų sumos"),
        "price": MessageLookupByLibrary.simpleMessage("Kaina"),
        "print": MessageLookupByLibrary.simpleMessage("Spausdinti"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Spausdinimo parinktis"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Privatumo politika"),
        "product": MessageLookupByLibrary.simpleMessage("Produktas"),
        "productCode": MessageLookupByLibrary.simpleMessage("Produkto Kodas"),
        "productCodeIsRequired": MessageLookupByLibrary.simpleMessage(
            "Produkto kodas yra privalomas"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Produkto kodas/Pavadinimas"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Produkto Aprašymas"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Produkto Detalės"),
        "productList": MessageLookupByLibrary.simpleMessage("Produktų Sąrašas"),
        "productName":
            MessageLookupByLibrary.simpleMessage("Produkto Pavadinimas"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Produkto pavadinimas jau egzistuoja šiame sandėlyje"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Produkto pavadinimas jau pridėtas"),
        "productNameIsRequired": MessageLookupByLibrary.simpleMessage(
            "Produkto pavadinimas yra privalomas"),
        "products": MessageLookupByLibrary.simpleMessage("Produktai"),
        "profile": MessageLookupByLibrary.simpleMessage("Profilis"),
        "profileEdit":
            MessageLookupByLibrary.simpleMessage("Profilio redagavimas"),
        "profit": MessageLookupByLibrary.simpleMessage("Pelno"),
        "promo": MessageLookupByLibrary.simpleMessage("Akcija"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Akcijos kodas"),
        "purchase": MessageLookupByLibrary.simpleMessage("Pirkimas"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("Pirkimo Signalas"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Pirkimas Patvirtintas"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Pirkimo detalės"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Pirkimo Faktūra"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("Pirkimų sąrašas"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Pirkti Dabar"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Įsigykite Premium planą"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("Pirkimo Kaina"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("Pirkimo kaina yra privaloma"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("Pirkimo ataskaita"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Pirkimo kaina"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Pirkimo ataskaitos"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("Pirkimo Grąžinimas"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("Pirkimo Grąžinimo Ataskaita"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Pirkimo Perėjimas"),
        "qty": MessageLookupByLibrary.simpleMessage("Kiekis"),
        "quantity": MessageLookupByLibrary.simpleMessage("Kiekis"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Naujausi Sandoriai"),
        "recivedThePin": MessageLookupByLibrary.simpleMessage("Gautas PIN"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Nuorodos Numeris"),
        "register": MessageLookupByLibrary.simpleMessage("Registruotis"),
        "registering": MessageLookupByLibrary.simpleMessage("Registracija"),
        "remainingDue":
            MessageLookupByLibrary.simpleMessage("Likusios Mokėtinos Sumos"),
        "remove": MessageLookupByLibrary.simpleMessage("Pašalinti"),
        "reports": MessageLookupByLibrary.simpleMessage("Ataskaitos"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Prašymas buvo išsiųstas"),
        "resendCode":
            MessageLookupByLibrary.simpleMessage("Pakartotinai siųsti kodą"),
        "resendOtp":
            MessageLookupByLibrary.simpleMessage("Pakartotinai siųsti OTP:"),
        "retailer": MessageLookupByLibrary.simpleMessage("Prekybininkas"),
        "retur": MessageLookupByLibrary.simpleMessage("Grąžinimas"),
        "returN": MessageLookupByLibrary.simpleMessage("Grąžinimas"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("Grąžinimo Suma"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("Grąžinimo suma"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("Grąžinimo Kiekis"),
        "revenue": MessageLookupByLibrary.simpleMessage("Pajamos"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Apsaugokite savo verslo duomenis be pastangų. Mūsų Pos Saas POS neribotas atnaujinimas apima nemokamą duomenų atsarginę kopiją, užtikrinančią, kad jūsų vertinga informacija būtų apsaugota nuo netikėtų įvykių. Sutelkite dėmesį į tai, kas iš tikrųjų svarbu - jūsų verslo augimą."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Pardavimo Suma"),
        "saleDetails":
            MessageLookupByLibrary.simpleMessage("Pardavimo detalės"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Pardavimo kaina"),
        "saleReports":
            MessageLookupByLibrary.simpleMessage("Pardavimo ataskaita"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Pardavimo ataskaitos"),
        "saleReturn":
            MessageLookupByLibrary.simpleMessage("Pardavimo grąžinimas"),
        "saleReturnReport": MessageLookupByLibrary.simpleMessage(
            "Pardavimo Grąžinimo Ataskaita"),
        "saleSetting":
            MessageLookupByLibrary.simpleMessage("Pardavimo Nustatymai"),
        "sales": MessageLookupByLibrary.simpleMessage("Pardavimai"),
        "salesAndPurchaseReports": MessageLookupByLibrary.simpleMessage(
            "Pardavimų ir pirkimų ataskaitos"),
        "salesList": MessageLookupByLibrary.simpleMessage("Pardavimų sąrašas"),
        "salesReturn":
            MessageLookupByLibrary.simpleMessage("Pardavimo Grąžinimas"),
        "save": MessageLookupByLibrary.simpleMessage("Išsaugoti"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Išsaugoti ir Publikuoti"),
        "saveChanges":
            MessageLookupByLibrary.simpleMessage("Išsaugoti pakeitimus"),
        "saving": MessageLookupByLibrary.simpleMessage("Saugojimas"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("Skenuoti produkto QR kodą"),
        "search": MessageLookupByLibrary.simpleMessage("Paieška"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Ieškoti pagal produkto kodą arba pavadinimą"),
        "seeAllPromoCode": MessageLookupByLibrary.simpleMessage(
            "Peržiūrėti visus akcijos kodus"),
        "select": MessageLookupByLibrary.simpleMessage("Pasirinkti"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Pasirinkite produktą grąžinimui"),
        "selectBrand":
            MessageLookupByLibrary.simpleMessage("Pasirinkite prekės ženklą"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Pasirinkite kategoriją"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Pasirinkite kontaktus"),
        "selectProductCategory": MessageLookupByLibrary.simpleMessage(
            "Pasirinkite produkto kategoriją"),
        "selectShopCategory": MessageLookupByLibrary.simpleMessage(
            "Pasirinkite parduotuvės kategoriją"),
        "selectTax":
            MessageLookupByLibrary.simpleMessage("Pasirinkite mokestį"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Pasirinkite mokesčio tipą"),
        "selectUnit":
            MessageLookupByLibrary.simpleMessage("Pasirinkite vienetą"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Pasirinkite Variacijas: "),
        "seller": MessageLookupByLibrary.simpleMessage("Pardavėjas"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Parduoda"),
        "send": MessageLookupByLibrary.simpleMessage("Siųsti"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("Siųsti El. Laišką"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Siųsti žinutę"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("Siųsti atkūrimo nuorodą"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Siųsti SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Siųsti SMS?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Siųsti WhatsApp žinutę"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Siųskite savo el. paštą"),
        "sendingEmail":
            MessageLookupByLibrary.simpleMessage("Siunčiama El. Paštu"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Siunčiama žinutė"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Paslaugos/Gabentoji"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Nustatykite savo profilį"),
        "setting": MessageLookupByLibrary.simpleMessage("Nustatymai"),
        "share": MessageLookupByLibrary.simpleMessage("Dalintis"),
        "shopGST": MessageLookupByLibrary.simpleMessage("Parduotuvės GST"),
        "signIn": MessageLookupByLibrary.simpleMessage("Prisijungti"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("Prisijungti su el. paštu"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Kliento Parašas"),
        "size": MessageLookupByLibrary.simpleMessage("Dydis"),
        "skip": MessageLookupByLibrary.simpleMessage("Praleisti"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Socialinė Rinkodara"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Atsiprašome, neturite teisės pasiekti šios paslaugos"),
        "startDate": MessageLookupByLibrary.simpleMessage("Pradžios data"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Pradėti Naują Parduodamą"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage(
            "Pradėkite rašyti, kad ieškotumėte"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Būkite technologijų pažangos priekyje be jokių papildomų išlaidų. Mūsų Pos Saas POS neriboto atnaujinimo užtikrina, kad visada turite naujausius įrankius ir funkcijas, garantuojančius, kad jūsų verslas išliks modernus."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("Dar Neapmokėta"),
        "stock": MessageLookupByLibrary.simpleMessage("Atsargos"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Atsargos yra privalomos"),
        "stockList": MessageLookupByLibrary.simpleMessage("Atsargų sąrašas"),
        "stocks": MessageLookupByLibrary.simpleMessage("Atsargos"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Reikalingas saugojimo leidimas, kad būtų sukurtas Excel failas"),
        "subTaxList":
            MessageLookupByLibrary.simpleMessage("Submokesčių Sąrašas"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Submokesčiai"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Tarpinė Suma"),
        "submit": MessageLookupByLibrary.simpleMessage("Pateikti"),
        "subscribeToOurYoutube":
            MessageLookupByLibrary.simpleMessage("Prenumeruokite mūsų Youtube"),
        "subscription": MessageLookupByLibrary.simpleMessage("Prenumerata"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Sėkmingai Atlikta"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Sėkmingai Atsijungta"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Sėkmingai Atnaujinta"),
        "supplier": MessageLookupByLibrary.simpleMessage("Tiekėjas"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("Tiekėjo Pavadinimas"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT kodas"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Pasirinkite vairuotojo pažymėjimą, nacionalinę tapatybės kortelę arba paso nuotrauką"),
        "takeaNidCardToCheckYourInformation": MessageLookupByLibrary.simpleMessage(
            "Pasirinkite tapatybės kortelę, kad patikrintumėte savo informaciją"),
        "tap": MessageLookupByLibrary.simpleMessage("Bakstelėti"),
        "tax": MessageLookupByLibrary.simpleMessage("Mokestis"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Mokesčių Grupė"),
        "taxPercentage":
            MessageLookupByLibrary.simpleMessage("Mokesčių Procentas"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Mokesčių Norma"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Mokesčių Normos - Tvarkykite savo Mokesčių Normas"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Mokesčių Ataskaita"),
        "taxType": MessageLookupByLibrary.simpleMessage("Mokesčio tipas"),
        "taxes": MessageLookupByLibrary.simpleMessage("Mokesčiai"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Taisyklės ir Sąlygos"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("Naudojimo sąlygos"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Taisyklės ir Privatumas"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Ačiū už jūsų mokėtinas sumas"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Ačiū"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Ačiū už jūsų pirkimą"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "Paskyra jau egzistuoja šiam el. paštui"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Excel failas jau buvo atsisiųstas"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Pavadinimas pasako viską. Su Pos Saas POS neribota, nėra ribojimų jūsų naudojimui. Nesvarbu, ar apdorojate nedidelį kiekį operacijų, ar patiriate klientų antplūdį, galite veikti drąsiai, žinodami, kad nesate ribojami."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "Pateiktas slaptažodis yra per silpnas"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Pardavimas bus ištrintas, o visa informacija apie šį pirkimą taip pat bus ištrinta. Ar tikrai norite tai ištrinti?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Pardavimas bus ištrintas, o visa informacija apie šį pardavimą taip pat bus ištrinta. Ar tikrai norite tai ištrinti?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Vartotojas bus ištrintas, o visi duomenys bus ištrinti iš jūsų paskyros. Ar tikrai norite tai padaryti?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Vartotojas bus ištrintas, ir visi duomenys bus ištrinti iš jūsų paskyros. Ar tikrai norite ištrinti šį vartotoją?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Trečiųjų šalių paslaugos"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Šios kategorijos negalima ištrinti"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Šį Mėnesį)"),
        "thisProductAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("Šis produktas jau pridėtas"),
        "title": MessageLookupByLibrary.simpleMessage("Pavadinimas"),
        "titleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Pavadinimas negali būti tuščias"),
        "to": MessageLookupByLibrary.simpleMessage("iki"),
        "toDate": MessageLookupByLibrary.simpleMessage("Iki Datos"),
        "today": MessageLookupByLibrary.simpleMessage("Šiandien"),
        "total": MessageLookupByLibrary.simpleMessage("Bendra"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Bendra Suma"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Iš viso Surinkta"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Bendra Mokėtina"),
        "totalExpense":
            MessageLookupByLibrary.simpleMessage("Bendros Išlaidos"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Bendras nuostolis"),
        "totalPayable": MessageLookupByLibrary.simpleMessage("Bendra Suma"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Bendra Kaina"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("Bendra produktų suma"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Bendras pelnas"),
        "totalPurchase":
            MessageLookupByLibrary.simpleMessage("Iš viso Pirkimas"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Iš viso Grąžinama Suma"),
        "totalReturns":
            MessageLookupByLibrary.simpleMessage("Iš viso Grąžinimų"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Bendra Parduota"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Visas likutis"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Bendra Vertė"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Bendra PVM"),
        "totals": MessageLookupByLibrary.simpleMessage("Iš viso: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Sandoris"),
        "transactionId": MessageLookupByLibrary.simpleMessage("Sandorio ID"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Bandykite dar kartą"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Tipas"),
        "unitName": MessageLookupByLibrary.simpleMessage("Vnt. Pavadinimas"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Vieneto Kaina"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Vieneto Kaina"),
        "units": MessageLookupByLibrary.simpleMessage("Vnt."),
        "unlimited": MessageLookupByLibrary.simpleMessage("Neribotas"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Neribotas naudojimas"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Atverkite visą Pos Saas POS potencialą su individualiomis mokymo sesijomis, kurias vedame mūsų ekspertų komanda. Nuo pagrindų iki pažangių technikų užtikriname, kad būtumėte gerai išmanyti kiekvieną sistemos aspektą, kad optimizuotumėte savo verslo procesus."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Nepamokėta"),
        "update": MessageLookupByLibrary.simpleMessage("Atnaujinti"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Atnaujinti Kontaktą"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Atnaujinkite Dabar"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("Atnaujinti Produktą"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Pirmiausia atnaujinkite savo planą,\n jūsų riba pasibaigė"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Atnaujinti Jūsų Profilį"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Atnaujinkite savo profilį, kad geriau susisiektumėte su savo gydytoju"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Atnaujinkite savo profilį, kad geriau susisiekite su klientais"),
        "updated": MessageLookupByLibrary.simpleMessage("Atnaujinta"),
        "upload": MessageLookupByLibrary.simpleMessage("Įkelti"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Įkelti dokumentą"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("Įkėlimas Baigtas"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Įkelti failą"),
        "upplier": MessageLookupByLibrary.simpleMessage("Tiekėjas"),
        "usbC": MessageLookupByLibrary.simpleMessage("USB C"),
        "use": MessageLookupByLibrary.simpleMessage("Naudoti"),
        "useMobiPos":
            MessageLookupByLibrary.simpleMessage("Naudokite POS SaaS"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Sistemos naudojimas"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Vartotojas ištrintas"),
        "userRole": MessageLookupByLibrary.simpleMessage("Vartotojo vaidmuo"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("Vartotojo vaidmens detalės"),
        "userTitle":
            MessageLookupByLibrary.simpleMessage("Vartotojo pavadinimas"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Vartotojo pavadinimas negali būti tuščias"),
        "value": MessageLookupByLibrary.simpleMessage("Vertė"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("PVM netaikomas"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("Patvirtinant OTP"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Patvirtinti telefono numerį"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Peržiūrėti Viską"),
        "viewDetails":
            MessageLookupByLibrary.simpleMessage("Peržiūrėti detales"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Eikite klientas"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Sandėlys"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Sandėlis Jau Egzistuoja"),
        "warehouseList":
            MessageLookupByLibrary.simpleMessage("Sandėlių Sąrašas"),
        "warehouseName":
            MessageLookupByLibrary.simpleMessage("Sandėlio Pavadinimas"),
        "warranty": MessageLookupByLibrary.simpleMessage("Garantija"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Išsiuntėme el. laišką su instrukcijomis, kaip atkurti slaptažodį adresu:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Mes galime naudoti trečiųjų šalių paslaugas, kad palaikytume mūsų programėlės funkcionalumą, pvz., analizės teikėjus ir mokėjimo apdorotojus. Šios trečiųjų šalių paslaugos gali rinkti informaciją apie jus, kai naudojatės mūsų programėle. Prašome atkreipti dėmesį, kad mes nesame atsakingi už šių trečiųjų šalių paslaugų privatumo praktiką."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Mes imamės pramonės standartų priemonių, kad apsaugotume jūsų asmeninę informaciją, įskaitant šifravimą ir saugų saugojimą. Mes taip pat ribojame prieigą prie jūsų informacijos tik įgaliotam personalui."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Mes suprantame sklandžių operacijų svarbą. Būtent todėl mūsų palaikymas dirba visą parą, kad jums padėtų, ar tai būtų greitas klausimas, ar išsami problema. Susisiekite su mumis bet kada ir bet kur, telefonu ar WhatsApp, kad patirtumėte neprilygstamą klientų aptarnavimą."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Mes naudojame jūsų asmeninę informaciją, kad suteiktume jums geriausią patirtį mūsų programėlėje, įskaitant turinio rekomendacijų pritaikymą, ryšio užmezgimą su ekspertais ir mūsų programėlės funkcionalumo tobulinimą. Mes taip pat galime naudoti jūsų informaciją, kad susisiektume su jumis dėl atnaujinimų, akcijų ar kitos informacijos, susijusios su mūsų programėle."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Peržiūrėsime mokėjimą ir patvirtinsime per 1-2 valandas"),
        "weekly": MessageLookupByLibrary.simpleMessage("Kas savaitę"),
        "weight": MessageLookupByLibrary.simpleMessage("Svoris"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Kas Naujo"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Didmenininkas"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Didmeninė Kaina"),
        "wholesalePrice":
            MessageLookupByLibrary.simpleMessage("Didmeninė Kaina"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Didmenininkas"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Bus pridėta Netrukus"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Pasibaigs"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Įrašykite savo žinutę čia"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("Neteisingas OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Neteisingas slaptažodis šiam vartotojui."),
        "yearly": MessageLookupByLibrary.simpleMessage("Metinis"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Taip, Ištrinti Visam laikui"),
        "youAreNotAValidUser": MessageLookupByLibrary.simpleMessage(
            "Jūs nesate galiojantis vartotojas"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Jūs naudojate"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Negalite mokėti daugiau nei yra skolinga"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Gavote el. laišką"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Sėkmingai prisijungėte prie savo paskyros. Likite su Pos SaaS."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("Turite suteikti leidimą"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Turite vėl prisijungti prie savo paskyros."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Prieš pirkdami SMS, turite patvirtinti tapatybę"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Jūsų žinutės liko"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Jūsų paketas"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Jūsų paketas baigs galioti per 5 dienas")
      };
}
