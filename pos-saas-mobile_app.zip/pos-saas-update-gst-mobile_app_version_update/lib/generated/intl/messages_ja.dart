// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a ja locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'ja';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("続行"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("GST番号"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("売価"),
        "MRPIsRequired": MessageLookupByLibrary.simpleMessage("MRPは必須です"),
        "OK": MessageLookupByLibrary.simpleMessage("OK"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("PayPal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("電話番号"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFTコード"),
        "Snacks": MessageLookupByLibrary.simpleMessage("スナック"),
        "TAX": MessageLookupByLibrary.simpleMessage("税金"),
        "Uploading": MessageLookupByLibrary.simpleMessage("アップロード中"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("ユーザー タイトル"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "あなたのパッケージは今日に期限切れになります\n\n再度購入してください"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) システムは、あなたのビジネスにおいて売上および関連する活動を円滑にすることを目的として提供されています。"),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) システムを利用するためには、アカウントを作成する必要がある場合があります。登録プロセス中に正確で、最新で、完全な情報を提供し、それを正確かつ完全な情報に保つことに同意します。"),
        "aboutApp": MessageLookupByLibrary.simpleMessage("アプリについて"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("私たちについて"),
        "acceptanceOfTerms": MessageLookupByLibrary.simpleMessage("利用規約の承諾"),
        "accountName": MessageLookupByLibrary.simpleMessage("口座名"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("口座番号"),
        "accountRegistration": MessageLookupByLibrary.simpleMessage("アカウント登録"),
        "acton": MessageLookupByLibrary.simpleMessage("アクション"),
        "add": MessageLookupByLibrary.simpleMessage("追加"),
        "addBrand": MessageLookupByLibrary.simpleMessage("ブランドを追加"),
        "addCategory": MessageLookupByLibrary.simpleMessage("カテゴリを追加"),
        "addContact": MessageLookupByLibrary.simpleMessage("連絡先を追加"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("顧客を追加"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("配送を追加"),
        "addDescriptioN": MessageLookupByLibrary.simpleMessage("説明を追加"),
        "addDescription": MessageLookupByLibrary.simpleMessage("ノートを追加"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("割引を追加"),
        "addDocumentId": MessageLookupByLibrary.simpleMessage("文書IDを追加"),
        "addDucument": MessageLookupByLibrary.simpleMessage("文書を追加"),
        "addExpense": MessageLookupByLibrary.simpleMessage("支出を追加"),
        "addExpenseCategory": MessageLookupByLibrary.simpleMessage("支出カテゴリを追加"),
        "addItems": MessageLookupByLibrary.simpleMessage("アイテムを追加"),
        "addNew": MessageLookupByLibrary.simpleMessage("新規追加"),
        "addNewAddress": MessageLookupByLibrary.simpleMessage("新しい住所を追加"),
        "addNewProduct": MessageLookupByLibrary.simpleMessage("新しい商品を追加"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("新しい税金を追加"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage("単一/複数の税タイプで新しい税金を追加"),
        "addNote": MessageLookupByLibrary.simpleMessage("ノートを追加"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("最初に商品を追加してください"),
        "addPromoCode": MessageLookupByLibrary.simpleMessage("プロモーションコードを追加"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("仕入れを追加"),
        "addSales": MessageLookupByLibrary.simpleMessage("販売を追加"),
        "addSuccessful": MessageLookupByLibrary.simpleMessage("追加に成功"),
        "addUnit": MessageLookupByLibrary.simpleMessage("単位を追加"),
        "addUserRole": MessageLookupByLibrary.simpleMessage("ユーザー ロールを追加"),
        "addedSuccessfully": MessageLookupByLibrary.simpleMessage("追加されました"),
        "addedToCart": MessageLookupByLibrary.simpleMessage("カートに追加されました"),
        "address": MessageLookupByLibrary.simpleMessage("住所"),
        "admin": MessageLookupByLibrary.simpleMessage("管理者"),
        "all": MessageLookupByLibrary.simpleMessage("すべて"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("すべてのビジネスソリューション"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("すでに追加されています"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("既に存在します"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("すでにアカウントをお持ちですか？"),
        "amount": MessageLookupByLibrary.simpleMessage("金額"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage("メールが送信されました\n受信トレイを確認してください"),
        "androidIOSAppSupport":
            MessageLookupByLibrary.simpleMessage("AndroidおよびiOSアプリサポート"),
        "applicableTax": MessageLookupByLibrary.simpleMessage("適用税"),
        "apply": MessageLookupByLibrary.simpleMessage("適用"),
        "areYouSureToDeleteThisInvoice":
            MessageLookupByLibrary.simpleMessage("この請求書を削除してもよろしいですか"),
        "areYouSureToDeleteThisSale":
            MessageLookupByLibrary.simpleMessage("この販売を削除してもよろしいですか"),
        "areYouSureToDeleteThisUser":
            MessageLookupByLibrary.simpleMessage("このユーザーを削除してもよろしいですか？"),
        "areYouSureWantToDeleteThisTax":
            MessageLookupByLibrary.simpleMessage("この税金を削除してもよろしいですか"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage("この税グループを削除してもよろしいですか"),
        "areYouWantToDeleteThisWarehouse":
            MessageLookupByLibrary.simpleMessage("この倉庫を削除してもよろしいですか"),
        "areYourSureDeleteThisUser":
            MessageLookupByLibrary.simpleMessage("このユーザーを削除してもよろしいですか？"),
        "authorizedSignature": MessageLookupByLibrary.simpleMessage("権限のある署名"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) アカウントとパスワードの機密性を維持し、アカウントへのアクセスを制限する責任があります。アカウントの下で発生するすべての活動に対する責任を負います。"),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) システムを利用するには、少なくとも18歳以上であるか、あなたの管轄区域の法的な成年年齢である必要があります。"),
        "backSide": MessageLookupByLibrary.simpleMessage("裏面"),
        "backToHome": MessageLookupByLibrary.simpleMessage("ホームに戻る"),
        "balance": MessageLookupByLibrary.simpleMessage("残高"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("バングラデシュ"),
        "bank": MessageLookupByLibrary.simpleMessage("銀行"),
        "bankAccountCurrency": MessageLookupByLibrary.simpleMessage("銀行口座通貨"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("銀行口座の通貨"),
        "bankInformation": MessageLookupByLibrary.simpleMessage("銀行情報"),
        "bankName": MessageLookupByLibrary.simpleMessage("銀行名"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("銀行振込"),
        "barcodeFound": MessageLookupByLibrary.simpleMessage("バーコードが見つかりました"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("請求書"),
        "billTo": MessageLookupByLibrary.simpleMessage("請求先"),
        "branchName": MessageLookupByLibrary.simpleMessage("支店名"),
        "brand": MessageLookupByLibrary.simpleMessage("ブランド"),
        "brandName": MessageLookupByLibrary.simpleMessage("ブランド名"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("一括アップロード"),
        "businessCategory": MessageLookupByLibrary.simpleMessage("ビジネスカテゴリー"),
        "buy": MessageLookupByLibrary.simpleMessage("購入"),
        "buyPremiumPlan": MessageLookupByLibrary.simpleMessage("プレミアムプランを購入"),
        "buySms": MessageLookupByLibrary.simpleMessage("SMSを購入"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "[会社名] (以下「会社」とする) が提供するポイント・オブ・セール (POS) システム (以下「システム」とする) へのアクセスまたは利用により、これらの利用規約に拘束されることに同意します。これらの利用規約に同意しない場合は、システムを使用しないでください。"),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) システムへのアクセスと利用がすべての適用法令および規制に準拠していることを確保する責任があります。"),
        "cacel": MessageLookupByLibrary.simpleMessage("キャンセル"),
        "call": MessageLookupByLibrary.simpleMessage("通話"),
        "callForEmergencySupport":
            MessageLookupByLibrary.simpleMessage("緊急サポートのために電話"),
        "camera": MessageLookupByLibrary.simpleMessage("カメラ"),
        "cancel": MessageLookupByLibrary.simpleMessage("キャンセル"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("すべての製品をキャンセル"),
        "capacity": MessageLookupByLibrary.simpleMessage("容量"),
        "card": MessageLookupByLibrary.simpleMessage("カード"),
        "cash": MessageLookupByLibrary.simpleMessage("現金"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("カテゴリ"),
        "category": MessageLookupByLibrary.simpleMessage("カテゴリ"),
        "categoryName": MessageLookupByLibrary.simpleMessage("カテゴリ名"),
        "categoryNameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("カテゴリ名は既に存在します"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("カテゴリ名"),
        "change": MessageLookupByLibrary.simpleMessage("変更"),
        "changePassword": MessageLookupByLibrary.simpleMessage("パスワードを変更"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("Eメールを確認"),
        "choseACustomer": MessageLookupByLibrary.simpleMessage("顧客を選択"),
        "choseASupplier": MessageLookupByLibrary.simpleMessage("サプライヤーを選択"),
        "choseYourFeature": MessageLookupByLibrary.simpleMessage("機能を選択してください"),
        "clarence": MessageLookupByLibrary.simpleMessage("クリアランス"),
        "clickToConnect": MessageLookupByLibrary.simpleMessage("接続するにはクリック"),
        "close": MessageLookupByLibrary.simpleMessage("閉じる"),
        "color": MessageLookupByLibrary.simpleMessage("色"),
        "combinationOfMultipleTaxes":
            MessageLookupByLibrary.simpleMessage("(複数の税金の組み合わせ)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("近日公開"),
        "companyAddress": MessageLookupByLibrary.simpleMessage("会社の住所"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("会社名およびショップ名"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("会社名・ビジネス名"),
        "completeTransaction": MessageLookupByLibrary.simpleMessage("取引を完了"),
        "confirmPassword": MessageLookupByLibrary.simpleMessage("パスワードの確認"),
        "confirmReturn": MessageLookupByLibrary.simpleMessage("返品を確認"),
        "congratulations": MessageLookupByLibrary.simpleMessage("おめでとうございます"),
        "contactUs": MessageLookupByLibrary.simpleMessage("お問い合わせ"),
        "continu": MessageLookupByLibrary.simpleMessage("続行"),
        "country": MessageLookupByLibrary.simpleMessage("国"),
        "create": MessageLookupByLibrary.simpleMessage("作成"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("無料アカウントを作成"),
        "createdAndSaved": MessageLookupByLibrary.simpleMessage("作成して保存しました"),
        "currency": MessageLookupByLibrary.simpleMessage("通貨"),
        "currentStock": MessageLookupByLibrary.simpleMessage("現在の在庫"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("カスタム請求書ブランディング"),
        "customer": MessageLookupByLibrary.simpleMessage("顧客"),
        "customerDetails": MessageLookupByLibrary.simpleMessage("顧客詳細"),
        "customerGST": MessageLookupByLibrary.simpleMessage("顧客GST"),
        "customerName": MessageLookupByLibrary.simpleMessage("顧客名"),
        "dailyTransaciton": MessageLookupByLibrary.simpleMessage("毎日の取引"),
        "dashBoardOverView": MessageLookupByLibrary.simpleMessage("ダッシュボード概要"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("データが正常に保存されました"),
        "date": MessageLookupByLibrary.simpleMessage("日付"),
        "day": MessageLookupByLibrary.simpleMessage("日"),
        "dealer": MessageLookupByLibrary.simpleMessage("ディーラー"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("ディーラー価格"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("デフォルトのVAT率"),
        "delete": MessageLookupByLibrary.simpleMessage("削除"),
        "deleting": MessageLookupByLibrary.simpleMessage("削除中"),
        "deliveryAddress": MessageLookupByLibrary.simpleMessage("配送先住所"),
        "deliveryAddresses": MessageLookupByLibrary.simpleMessage("配送先住所"),
        "deliveryCharge": MessageLookupByLibrary.simpleMessage("配送料"),
        "describtion": MessageLookupByLibrary.simpleMessage("説明"),
        "description": MessageLookupByLibrary.simpleMessage("説明"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("説明は空にできません"),
        "details": MessageLookupByLibrary.simpleMessage("詳細"),
        "discount": MessageLookupByLibrary.simpleMessage("割引"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("お静かに"),
        "done": MessageLookupByLibrary.simpleMessage("完了"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Excelフォーマットをダウンロード"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage("ダウンロードフォルダーに正常にダウンロードされました"),
        "due": MessageLookupByLibrary.simpleMessage("未払い"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("未払い金額："),
        "dueCollection": MessageLookupByLibrary.simpleMessage("未払いの回収"),
        "dueCollectionReports": MessageLookupByLibrary.simpleMessage("未収金報告"),
        "dueList": MessageLookupByLibrary.simpleMessage("未払いリスト"),
        "dueReports": MessageLookupByLibrary.simpleMessage("未払いレポート"),
        "duration": MessageLookupByLibrary.simpleMessage("期間"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("期間: から"),
        "easyToUseMobilePos":
            MessageLookupByLibrary.simpleMessage("簡単に使えるモバイルPOS"),
        "edit": MessageLookupByLibrary.simpleMessage("編集"),
        "editPurchaseInvoice": MessageLookupByLibrary.simpleMessage("仕入請求書を編集"),
        "editSalesInvoice": MessageLookupByLibrary.simpleMessage("販売請求書を編集"),
        "editSocailMedia": MessageLookupByLibrary.simpleMessage("ソーシャルメディアを編集"),
        "editSuccessfully": MessageLookupByLibrary.simpleMessage("編集が成功しました"),
        "editTax": MessageLookupByLibrary.simpleMessage("税金を編集"),
        "editTaxGroup": MessageLookupByLibrary.simpleMessage("税グループを編集"),
        "editWarehouse": MessageLookupByLibrary.simpleMessage("倉庫を編集"),
        "email": MessageLookupByLibrary.simpleMessage("Eメール"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("メールアドレス"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("メールは空にできません"),
        "emailSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage("メールが送信されました！受信トレイを確認してください"),
        "endDate": MessageLookupByLibrary.simpleMessage("終了日"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("有効な金額を入力してください"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("有効な割引を入力してください"),
        "enterAValidPhoneNumber":
            MessageLookupByLibrary.simpleMessage("有効な電話番号を入力してください"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("有効な価格を入力してください"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("有効な数量を入力してください"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("住所を入力"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("金額を入力してください"),
        "enterBrandName": MessageLookupByLibrary.simpleMessage("ブランド名を入力"),
        "enterCapacity": MessageLookupByLibrary.simpleMessage("容量を入力"),
        "enterCategoryName": MessageLookupByLibrary.simpleMessage("カテゴリ名を入力"),
        "enterColor": MessageLookupByLibrary.simpleMessage("色を入力"),
        "enterCustomerGstNumber":
            MessageLookupByLibrary.simpleMessage("顧客のGST番号を入力してください"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("ディーラー価格を入力してください"),
        "enterDescription": MessageLookupByLibrary.simpleMessage("説明を入力してください"),
        "enterDiscount": MessageLookupByLibrary.simpleMessage("割引を入力してください。"),
        "enterExpenseDate": MessageLookupByLibrary.simpleMessage("支出日を入力"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("完全な住所を入力してください"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("請求書番号を入力してください"),
        "enterLowStockAlertQuantity":
            MessageLookupByLibrary.simpleMessage("在庫不足アラート数量を入力してください"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("メーカーを入力してください"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("メッセージ内容を入力"),
        "enterMrpOrRetailerPirce":
            MessageLookupByLibrary.simpleMessage("売価/小売価格を入力してください"),
        "enterName": MessageLookupByLibrary.simpleMessage("名前を入力"),
        "enterNote": MessageLookupByLibrary.simpleMessage("ノートを入力"),
        "enterPartyName": MessageLookupByLibrary.simpleMessage("取引先名を入力"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("電話番号を入力してください"),
        "enterProductCodeOrScan":
            MessageLookupByLibrary.simpleMessage("商品コードを入力またはスキャンしてください"),
        "enterProductName": MessageLookupByLibrary.simpleMessage("商品名を入力"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("仕入れ価格を入力してください。"),
        "enterReferenceNumber": MessageLookupByLibrary.simpleMessage("参照番号を入力"),
        "enterSize": MessageLookupByLibrary.simpleMessage("サイズを入力"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("在庫を入力してください。"),
        "enterTaxRate": MessageLookupByLibrary.simpleMessage("税率を入力してください"),
        "enterTransactionId": MessageLookupByLibrary.simpleMessage("取引IDを入力"),
        "enterType": MessageLookupByLibrary.simpleMessage("タイプを入力"),
        "enterUserTitle": MessageLookupByLibrary.simpleMessage("ユーザー タイトルを入力"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("有効な金額を入力してください"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("倉庫名を入力してください"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("重量を入力"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("卸売価格を入力してください"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("ここに説明を入力してください"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("Eメールアドレスを入力してください"),
        "enterYourFeedBackTitle":
            MessageLookupByLibrary.simpleMessage("フィードバックのタイトルを入力してください"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("あなたのGST番号を入力してください"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("携帯電話番号を入力"),
        "enterYourName": MessageLookupByLibrary.simpleMessage("名前を入力"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("電話番号を入力してください"),
        "enterYourPassword": MessageLookupByLibrary.simpleMessage("パスワードを入力"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("電話番号を入力してください"),
        "enterYourTransactionId":
            MessageLookupByLibrary.simpleMessage("取引IDを入力"),
        "error": MessageLookupByLibrary.simpleMessage("エラー"),
        "excTax": MessageLookupByLibrary.simpleMessage("税抜"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("Excelアップローダー"),
        "exclusive": MessageLookupByLibrary.simpleMessage("排他的"),
        "expense": MessageLookupByLibrary.simpleMessage("経費"),
        "expenseCategory": MessageLookupByLibrary.simpleMessage("支出カテゴリ"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("支出日"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("支出先"),
        "expenseReport": MessageLookupByLibrary.simpleMessage("支出レポート"),
        "expireDate": MessageLookupByLibrary.simpleMessage("有効期限"),
        "expired": MessageLookupByLibrary.simpleMessage("期限切れ"),
        "expiring": MessageLookupByLibrary.simpleMessage("期限切れ"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError": MessageLookupByLibrary.simpleMessage("エラーで失敗しました"),
        "fashion": MessageLookupByLibrary.simpleMessage("ファッション"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "機能は、Pos Saasを従来のソリューションとは異なるものにする重要な部分です。"),
        "feedBack": MessageLookupByLibrary.simpleMessage("フィードバック"),
        "firstName": MessageLookupByLibrary.simpleMessage("名"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Facebookでフォロー"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Twitterでフォロー"),
        "fontSide": MessageLookupByLibrary.simpleMessage("表面"),
        "forUnlimitedUses": MessageLookupByLibrary.simpleMessage("無制限の利用のため"),
        "forgotPassword": MessageLookupByLibrary.simpleMessage("パスワードをお忘れですか"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("パスワードをお忘れですか？"),
        "formDate": MessageLookupByLibrary.simpleMessage("開始日"),
        "freeDataBackup": MessageLookupByLibrary.simpleMessage("無料のデータバックアップ"),
        "freeLifeTimeUpdate":
            MessageLookupByLibrary.simpleMessage("無料の終身アップデート"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("無料パッケージ"),
        "freePlan": MessageLookupByLibrary.simpleMessage("無料プラン"),
        "from": MessageLookupByLibrary.simpleMessage("(から"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("全額支払い済み"),
        "gallary": MessageLookupByLibrary.simpleMessage("ギャラリー"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("PDFを生成中"),
        "getOtp": MessageLookupByLibrary.simpleMessage("OTPを取得"),
        "govermentId": MessageLookupByLibrary.simpleMessage("政府発行ID"),
        "guest": MessageLookupByLibrary.simpleMessage("ゲスト"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("アカウントをお持ちでないですか？"),
        "history": MessageLookupByLibrary.simpleMessage("履歴"),
        "home": MessageLookupByLibrary.simpleMessage("ホーム"),
        "howWeProtectYourInformation":
            MessageLookupByLibrary.simpleMessage("情報の保護方法"),
        "howWeUseYourInformation":
            MessageLookupByLibrary.simpleMessage("情報の利用方法"),
        "identityVerify": MessageLookupByLibrary.simpleMessage("本人確認"),
        "image": MessageLookupByLibrary.simpleMessage("画像"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("社内は削除できません"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("社内は編集できません"),
        "inWord": MessageLookupByLibrary.simpleMessage("言葉で"),
        "incTax": MessageLookupByLibrary.simpleMessage("税込"),
        "inclusive": MessageLookupByLibrary.simpleMessage("包括的"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("在庫を増やす"),
        "inistrument": MessageLookupByLibrary.simpleMessage("インストルメント"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("請求書番号"),
        "invoice": MessageLookupByLibrary.simpleMessage("請求書"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("請求書番号"),
        "invoiceSetting": MessageLookupByLibrary.simpleMessage("請求書設定"),
        "invoiceViewer": MessageLookupByLibrary.simpleMessage("請求書ビューワー"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("アイテムが追加されました"),
        "kg": MessageLookupByLibrary.simpleMessage("kg"),
        "kycVerification": MessageLookupByLibrary.simpleMessage("KYC認証"),
        "language": MessageLookupByLibrary.simpleMessage("言語"),
        "lastName": MessageLookupByLibrary.simpleMessage("姓"),
        "ledger": MessageLookupByLibrary.simpleMessage("取引履歴"),
        "lifeTimePurchase": MessageLookupByLibrary.simpleMessage("一括購入"),
        "link": MessageLookupByLibrary.simpleMessage("リンク"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport": MessageLookupByLibrary.simpleMessage("ライブチャットサポート"),
        "loading": MessageLookupByLibrary.simpleMessage("読み込み中"),
        "logIn": MessageLookupByLibrary.simpleMessage("ログイン"),
        "logOUt": MessageLookupByLibrary.simpleMessage("ログアウト"),
        "logOut": MessageLookupByLibrary.simpleMessage("ログアウト"),
        "login": MessageLookupByLibrary.simpleMessage("ログイン"),
        "logo": MessageLookupByLibrary.simpleMessage("ロゴ"),
        "loss": MessageLookupByLibrary.simpleMessage("損失"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("損益"),
        "lossOrProfitDetails": MessageLookupByLibrary.simpleMessage("損益詳細"),
        "lossProfitReport": MessageLookupByLibrary.simpleMessage("損益レポート"),
        "lossProfitReports": MessageLookupByLibrary.simpleMessage("損益レポート"),
        "lowStockAlert": MessageLookupByLibrary.simpleMessage("在庫不足アラート"),
        "maan": MessageLookupByLibrary.simpleMessage("マーン"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "ブランドのある請求書で顧客に長続きする印象を与えます。当社の無制限のアップグレードは、請求書をカスタマイズする独自の利点を提供し、プロのタッチを加え、ブランドアイデンティティを強化し、顧客の忠誠心を育むことができます。"),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("ビジネスを管理する："),
        "manufactureDate": MessageLookupByLibrary.simpleMessage("製造日"),
        "margin": MessageLookupByLibrary.simpleMessage("マージン"),
        "masterCard": MessageLookupByLibrary.simpleMessage("マスターカード"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("メーカー"),
        "message": MessageLookupByLibrary.simpleMessage("メッセージ"),
        "messageHistory": MessageLookupByLibrary.simpleMessage("メッセージ履歴"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Pos Saasアプリは無料で、使いやすいです。実際、これは世界中で最も優れたPOSシステムの1つです。"),
        "mobiPosIsaCompleteBusinesSolution":
            MessageLookupByLibrary.simpleMessage(
                "Pos Saasは在庫、アカウント、販売、支出、損益を含む完全なビジネスソリューションです。"),
        "mobile": MessageLookupByLibrary.simpleMessage("モバイル"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("モバイル決済"),
        "monthly": MessageLookupByLibrary.simpleMessage("月次"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("詳細情報"),
        "name": MessageLookupByLibrary.simpleMessage("名前を入力してください"),
        "nameAlreadyExists": MessageLookupByLibrary.simpleMessage("名前は既に存在します"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("名前を空にすることはできません"),
        "next": MessageLookupByLibrary.simpleMessage("次へ"),
        "noConnection": MessageLookupByLibrary.simpleMessage("接続なし"),
        "noData": MessageLookupByLibrary.simpleMessage("データなし"),
        "noDataAvailable": MessageLookupByLibrary.simpleMessage("データがありません"),
        "noDataFound": MessageLookupByLibrary.simpleMessage("データが見つかりません"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("履歴が見つかりませんでした！"),
        "noProductFound": MessageLookupByLibrary.simpleMessage("商品が見つかりませんでした"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("選択されたサブ税はありません"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("取引が見つかりませんでした！"),
        "noUserFoundForThatEmail":
            MessageLookupByLibrary.simpleMessage("そのメールアドレスに対するユーザーが見つかりません。"),
        "noUserRoleFound":
            MessageLookupByLibrary.simpleMessage("ユーザー ロールが見つかりません"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("アクティブユーザーではありません"),
        "notProvided": MessageLookupByLibrary.simpleMessage("提供されていません"),
        "note": MessageLookupByLibrary.simpleMessage("ノート"),
        "notes": MessageLookupByLibrary.simpleMessage("メモ"),
        "notification": MessageLookupByLibrary.simpleMessage("通知"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTPが送信されました"),
        "office": MessageLookupByLibrary.simpleMessage("オフィス"),
        "ok": MessageLookupByLibrary.simpleMessage("OK"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "売上追跡、在庫管理を含む多くの機能を備えたPOSシステム。"),
        "onboardThree":
            MessageLookupByLibrary.simpleMessage("このシステムはお客様の運用を向上させるのに役立ちます。"),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "当社のPOSシステムは、日常の運用を自動化し、ナビゲーションを容易にするべきです。"),
        "openingBalance": MessageLookupByLibrary.simpleMessage("初期残高"),
        "order": MessageLookupByLibrary.simpleMessage("注文"),
        "other": MessageLookupByLibrary.simpleMessage("その他"),
        "otp": MessageLookupByLibrary.simpleMessage("閉じる"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("在庫切れ"),
        "pacakge": MessageLookupByLibrary.simpleMessage("パッケージ"),
        "packageFeatures": MessageLookupByLibrary.simpleMessage("パッケージの特徴"),
        "paid": MessageLookupByLibrary.simpleMessage("支払済み"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("支払金額"),
        "parties": MessageLookupByLibrary.simpleMessage("取引先"),
        "partiesList": MessageLookupByLibrary.simpleMessage("取引先リスト"),
        "partyGST": MessageLookupByLibrary.simpleMessage("パーティGST"),
        "partyName": MessageLookupByLibrary.simpleMessage("取引先名"),
        "password": MessageLookupByLibrary.simpleMessage("パスワード"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage("パスワードと確認用パスワードが一致しません"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("パスワードは空にできません"),
        "passwordNotMach": MessageLookupByLibrary.simpleMessage("パスワードが一致しません"),
        "payCash": MessageLookupByLibrary.simpleMessage("現金支払い"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash": MessageLookupByLibrary.simpleMessage("Bkashで支払う"),
        "payWithPaypal": MessageLookupByLibrary.simpleMessage("PayPalで支払う"),
        "payeeName": MessageLookupByLibrary.simpleMessage("受取人名"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("受取人番号"),
        "payment": MessageLookupByLibrary.simpleMessage("支払い"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("支払い額"),
        "paymentComplete": MessageLookupByLibrary.simpleMessage("支払い完了"),
        "paymentInstructions": MessageLookupByLibrary.simpleMessage("支払い指示："),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("支払い方法"),
        "paymentType": MessageLookupByLibrary.simpleMessage("支払い方法"),
        "pdfView": MessageLookupByLibrary.simpleMessage("PDFビュー"),
        "personalInformation": MessageLookupByLibrary.simpleMessage("個人情報"),
        "phone": MessageLookupByLibrary.simpleMessage("電話"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("電話番号"),
        "phoneNumberAlreadyUsed":
            MessageLookupByLibrary.simpleMessage("電話番号はすでに使用されています"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("電話番号は無効です"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("電話番号は必須です"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("ファイルを選択してアップロード"),
        "pickEndDate": MessageLookupByLibrary.simpleMessage("終了日を選択"),
        "pickStartDate": MessageLookupByLibrary.simpleMessage("開始日を選択"),
        "plan": MessageLookupByLibrary.simpleMessage("プラン"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("数量を追加してください"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage("インターネット接続を確認してください"),
        "pleaseConnectThePrinterFirst":
            MessageLookupByLibrary.simpleMessage("最初にプリンターを接続してください"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage("Bluetoothプリンターを接続してください"),
        "pleaseEnterABiggerPassword":
            MessageLookupByLibrary.simpleMessage("もっと大きなパスワードを入力してください"),
        "pleaseEnterAConfirmPassword":
            MessageLookupByLibrary.simpleMessage("パスワードを確認してください"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("パスワードを入力してください"),
        "pleaseEnterAValidEmail":
            MessageLookupByLibrary.simpleMessage("有効なメールアドレスを入力してください"),
        "pleaseEnterName": MessageLookupByLibrary.simpleMessage("名前を入力してください"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("パスワードを入力してください"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "パスワードリセットリンクを受け取るために、以下にメールアドレスを入力してください。"),
        "pleaseEnterTransactionNumber":
            MessageLookupByLibrary.simpleMessage("トランザクション番号を入力してください"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("金額を入力してください"),
        "pleaseSelectACategoryFirst":
            MessageLookupByLibrary.simpleMessage("最初にカテゴリを選択してください"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("プランを選択してください"),
        "pleaseSelectBusinessCategory":
            MessageLookupByLibrary.simpleMessage("ビジネスカテゴリを選択してください"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "アプリを使用するために有効な購入コードを使用してください"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Powered By Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("提供元"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("プレミアムカスタマーサポート"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("プレミアムプラン"),
        "previousPayAmounts": MessageLookupByLibrary.simpleMessage("以前の支払額"),
        "price": MessageLookupByLibrary.simpleMessage("価格"),
        "print": MessageLookupByLibrary.simpleMessage("印刷"),
        "printingOption": MessageLookupByLibrary.simpleMessage("印刷オプション"),
        "privacyPolicy": MessageLookupByLibrary.simpleMessage("プライバシーポリシー"),
        "product": MessageLookupByLibrary.simpleMessage("商品"),
        "productCode": MessageLookupByLibrary.simpleMessage("商品コード"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("製品コードは必須です"),
        "productCodeName": MessageLookupByLibrary.simpleMessage("商品コード/名前"),
        "productDescription": MessageLookupByLibrary.simpleMessage("商品説明"),
        "productDetails": MessageLookupByLibrary.simpleMessage("製品の詳細"),
        "productList": MessageLookupByLibrary.simpleMessage("商品リスト"),
        "productName": MessageLookupByLibrary.simpleMessage("商品名"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage("この倉庫に製品名はすでに存在します"),
        "productNameIsAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("商品名はすでに追加されています"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("製品名は必須です"),
        "products": MessageLookupByLibrary.simpleMessage("商品"),
        "profile": MessageLookupByLibrary.simpleMessage("プロフィール"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("プロフィールの編集"),
        "profit": MessageLookupByLibrary.simpleMessage("利益"),
        "promo": MessageLookupByLibrary.simpleMessage("プロモーション"),
        "promoCode": MessageLookupByLibrary.simpleMessage("プロモーションコード"),
        "purchase": MessageLookupByLibrary.simpleMessage("仕入"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage("購入アラート"),
        "purchaseConfirmed": MessageLookupByLibrary.simpleMessage("購入確認済み"),
        "purchaseDetails": MessageLookupByLibrary.simpleMessage("仕入詳細"),
        "purchaseInvoice": MessageLookupByLibrary.simpleMessage("購入請求書"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("仕入リスト"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("今すぐ購入"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("プレミアムプランを購入"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("仕入れ価格"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("購入価格は必須です"),
        "purchaseRepoet": MessageLookupByLibrary.simpleMessage("仕入レポート"),
        "purchaseReports": MessageLookupByLibrary.simpleMessage("仕入レポート"),
        "purchaseReportss": MessageLookupByLibrary.simpleMessage("購入レポート"),
        "purchaseReturn": MessageLookupByLibrary.simpleMessage("購入返品"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("購入返品レポート"),
        "purchaseTransition": MessageLookupByLibrary.simpleMessage("購入の移行"),
        "qty": MessageLookupByLibrary.simpleMessage("数量"),
        "quantity": MessageLookupByLibrary.simpleMessage("数量"),
        "recentTransactions": MessageLookupByLibrary.simpleMessage("最近の取引"),
        "recivedThePin": MessageLookupByLibrary.simpleMessage("PINを受け取りました"),
        "referenceNumber": MessageLookupByLibrary.simpleMessage("参照番号"),
        "register": MessageLookupByLibrary.simpleMessage("登録"),
        "registering": MessageLookupByLibrary.simpleMessage("登録中"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("残り未払い額"),
        "remove": MessageLookupByLibrary.simpleMessage("削除"),
        "reports": MessageLookupByLibrary.simpleMessage("レポート"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("リクエストが送信されました"),
        "resendCode": MessageLookupByLibrary.simpleMessage("コードを再送信"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("OTP再送信："),
        "retailer": MessageLookupByLibrary.simpleMessage("小売業者"),
        "retur": MessageLookupByLibrary.simpleMessage("返品"),
        "returN": MessageLookupByLibrary.simpleMessage("返品"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("返金額"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("返金額"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("返品数量"),
        "revenue": MessageLookupByLibrary.simpleMessage("収益"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "ビジネスデータを簡単に保護します。Pos Saas POS Unlimited Upgradeには無料のデータバックアップが含まれており、貴重な情報が予期せぬ出来事から保護されます。真に重要なことに集中してください - あなたのビジネスの成長です。"),
        "saleAmount": MessageLookupByLibrary.simpleMessage("販売金額"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("販売詳細"),
        "salePrice": MessageLookupByLibrary.simpleMessage("販売価格"),
        "saleReports": MessageLookupByLibrary.simpleMessage("販売レポート"),
        "saleReportss": MessageLookupByLibrary.simpleMessage("売上レポート"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("販売返品"),
        "saleReturnReport": MessageLookupByLibrary.simpleMessage("販売返品レポート"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("販売設定"),
        "sales": MessageLookupByLibrary.simpleMessage("販売"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("売上および購入レポート"),
        "salesList": MessageLookupByLibrary.simpleMessage("販売リスト"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("販売返品"),
        "save": MessageLookupByLibrary.simpleMessage("保存"),
        "saveAndPublish": MessageLookupByLibrary.simpleMessage("保存して公開"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("変更を保存"),
        "saving": MessageLookupByLibrary.simpleMessage("保存中"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("商品のQRコードをスキャン"),
        "search": MessageLookupByLibrary.simpleMessage("検索"),
        "searchByProductCodeOrName":
            MessageLookupByLibrary.simpleMessage("商品コードまたは名前で検索"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("すべてのプロモーションコードを見る"),
        "select": MessageLookupByLibrary.simpleMessage("選択"),
        "selectAProductForReturn":
            MessageLookupByLibrary.simpleMessage("返品する商品を選択してください"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("ブランドを選択してください"),
        "selectCategory": MessageLookupByLibrary.simpleMessage("カテゴリを選択してください"),
        "selectContacts": MessageLookupByLibrary.simpleMessage("連絡先を選択"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("製品カテゴリを選択してください"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("ショップカテゴリを選択してください"),
        "selectTax": MessageLookupByLibrary.simpleMessage("税を選択してください"),
        "selectTaxType": MessageLookupByLibrary.simpleMessage("税タイプを選択してください"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("単位を選択してください"),
        "selectvariations": MessageLookupByLibrary.simpleMessage("バリエーションを選択:"),
        "seller": MessageLookupByLibrary.simpleMessage("売り手"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("販売者"),
        "send": MessageLookupByLibrary.simpleMessage("送信"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("メールを送信"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("メッセージを送信"),
        "sendResetLink": MessageLookupByLibrary.simpleMessage("リセットリンクを送信"),
        "sendSms": MessageLookupByLibrary.simpleMessage("SMSを送信"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("SMSを送信しますか？"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("WhatsAppメッセージを送信"),
        "sendYOurEmail": MessageLookupByLibrary.simpleMessage("メールを送信"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage("メールを送信中"),
        "sendingMessage": MessageLookupByLibrary.simpleMessage("メッセージを送信中"),
        "serviceShipping": MessageLookupByLibrary.simpleMessage("サービス/配送"),
        "setUpYourProfile": MessageLookupByLibrary.simpleMessage("プロフィールの設定"),
        "setting": MessageLookupByLibrary.simpleMessage("設定"),
        "share": MessageLookupByLibrary.simpleMessage("共有"),
        "shopGST": MessageLookupByLibrary.simpleMessage("ショップGST"),
        "signIn": MessageLookupByLibrary.simpleMessage("サインイン"),
        "signInWithEmail": MessageLookupByLibrary.simpleMessage("メールでサインイン"),
        "signatureOfCustomer": MessageLookupByLibrary.simpleMessage("顧客の署名"),
        "size": MessageLookupByLibrary.simpleMessage("サイズ"),
        "skip": MessageLookupByLibrary.simpleMessage("スキップ"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing": MessageLookupByLibrary.simpleMessage("ソーシャルマーケティング"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "申し訳ありませんが、このサービスにアクセスする権限がありません"),
        "startDate": MessageLookupByLibrary.simpleMessage("開始日"),
        "startNewSale": MessageLookupByLibrary.simpleMessage("新しい販売を開始"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage("検索を開始する"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "追加費用なしで技術の最前線にとどまります。当社のPos Saas POS Unlimited Upgradeは、常に最新のツールと機能を手に入れることを保証し、あなたのビジネスが常に最新のものであることを保証します。"),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("未払い"),
        "stock": MessageLookupByLibrary.simpleMessage("在庫"),
        "stockIsRequired": MessageLookupByLibrary.simpleMessage("在庫は必須です"),
        "stockList": MessageLookupByLibrary.simpleMessage("在庫リスト"),
        "stocks": MessageLookupByLibrary.simpleMessage("在庫"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Excelファイルを作成するにはストレージの権限が必要です"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("サブ税リスト"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("サブ税"),
        "subTotal": MessageLookupByLibrary.simpleMessage("小計"),
        "submit": MessageLookupByLibrary.simpleMessage("送信"),
        "subscribeToOurYoutube":
            MessageLookupByLibrary.simpleMessage("YouTubeチャンネルを購読"),
        "subscription": MessageLookupByLibrary.simpleMessage("サブスクリプション"),
        "successfullyDone": MessageLookupByLibrary.simpleMessage("正常に完了しました"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("正常にログアウトしました"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("正常に更新されました"),
        "supplier": MessageLookupByLibrary.simpleMessage("サプライヤー"),
        "supplierName": MessageLookupByLibrary.simpleMessage("サプライヤー名"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFTコード"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "運転免許証、国民IDカード、またはパスポートの写真を提供してください"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage("本人情報を確認するためにIDカードを使用してください"),
        "tap": MessageLookupByLibrary.simpleMessage("タップ"),
        "tax": MessageLookupByLibrary.simpleMessage("税"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("税グループ"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("税率"),
        "taxRate": MessageLookupByLibrary.simpleMessage("税率"),
        "taxRatesManageYourTaxRates":
            MessageLookupByLibrary.simpleMessage("税率 - あなたの税率を管理"),
        "taxReport": MessageLookupByLibrary.simpleMessage("税報告書"),
        "taxType": MessageLookupByLibrary.simpleMessage("税タイプ"),
        "taxes": MessageLookupByLibrary.simpleMessage("税金"),
        "termsAndConditions": MessageLookupByLibrary.simpleMessage("利用規約"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("利用規約"),
        "termsPrivacy": MessageLookupByLibrary.simpleMessage("利用規約とプライバシー"),
        "thankYOuForYourDuePayment":
            MessageLookupByLibrary.simpleMessage("未払いの支払い、ありがとうございます"),
        "thankYou": MessageLookupByLibrary.simpleMessage("ありがとうございます"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("ご購入いただき、ありがとうございます"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage("そのメールアドレスのアカウントは既に存在します"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage("Excelファイルはすでにダウンロードされています"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "その名前がすべてを物語っています。Pos Saas POS Unlimitedでは、使用回数に制限はありません。少数の取引を処理している場合でも、多くの顧客が押し寄せている場合でも、制限に縛られないで操作できます。"),
        "thePasswordProvidedIsTooWeak":
            MessageLookupByLibrary.simpleMessage("提供されたパスワードは弱すぎます"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "この販売が削除され、すべてのデータが削除されます。この削除を確認しますか"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "この販売が削除され、すべてのデータが削除されます。この削除を確認しますか"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "ユーザーは削除され、すべてのデータがアカウントから削除されます。本当に削除してもよろしいですか？"),
        "theUserWillBeDeletedAndAllTheData":
            MessageLookupByLibrary.simpleMessage(
                "ユーザーは削除され、すべてのデータがあなたのアカウントから削除されます。本当に削除してもよろしいですか？"),
        "thirdPartyServices": MessageLookupByLibrary.simpleMessage("第三者サービス"),
        "thisCategoryCannotBeDeleted":
            MessageLookupByLibrary.simpleMessage("このカテゴリは削除できません"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(今月)"),
        "thisProductAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("この製品はすでに追加されています"),
        "title": MessageLookupByLibrary.simpleMessage("タイトル"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("タイトルは空にできません"),
        "to": MessageLookupByLibrary.simpleMessage("まで"),
        "toDate": MessageLookupByLibrary.simpleMessage("終了日"),
        "today": MessageLookupByLibrary.simpleMessage("今日"),
        "total": MessageLookupByLibrary.simpleMessage("合計"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("合計金額"),
        "totalCollected": MessageLookupByLibrary.simpleMessage("合計収集額"),
        "totalDue": MessageLookupByLibrary.simpleMessage("合計未払い額"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("総支出"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("総損失"),
        "totalPayable": MessageLookupByLibrary.simpleMessage("支払総額"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("合計価格"),
        "totalProducts": MessageLookupByLibrary.simpleMessage("合計製品"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("総利益"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("合計購入"),
        "totalReturnAmount": MessageLookupByLibrary.simpleMessage("合計返品額"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("合計返品"),
        "totalSale": MessageLookupByLibrary.simpleMessage("総売上"),
        "totalStock": MessageLookupByLibrary.simpleMessage("総在庫"),
        "totalValue": MessageLookupByLibrary.simpleMessage("合計値"),
        "totalVat": MessageLookupByLibrary.simpleMessage("合計VAT"),
        "totals": MessageLookupByLibrary.simpleMessage("合計："),
        "transaction": MessageLookupByLibrary.simpleMessage("取引"),
        "transactionId": MessageLookupByLibrary.simpleMessage("取引ID"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("再試行"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("タイプ"),
        "unitName": MessageLookupByLibrary.simpleMessage("単位名"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("単価"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("単価"),
        "units": MessageLookupByLibrary.simpleMessage("単位"),
        "unlimited": MessageLookupByLibrary.simpleMessage("無制限"),
        "unlimitedUsage": MessageLookupByLibrary.simpleMessage("制限なしの利用"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "専門家チームによるパーソナライズされたトレーニングセッションを活用して、Pos Saas POSのフルポテンシャルを引き出します。基本から高度なテクニックまで、システムのあらゆる側面を最適化してビジネスプロセスを行うことができるようにします。"),
        "unpaid": MessageLookupByLibrary.simpleMessage("未払い"),
        "update": MessageLookupByLibrary.simpleMessage("更新"),
        "updateContact": MessageLookupByLibrary.simpleMessage("連絡先を更新"),
        "updateNow": MessageLookupByLibrary.simpleMessage("今すぐ更新"),
        "updateProduct": MessageLookupByLibrary.simpleMessage("商品を更新"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "最初にプランを更新してください。あなたの限度を超えています"),
        "updateYourProfile": MessageLookupByLibrary.simpleMessage("プロフィールを更新"),
        "updateYourProfileToConnect":
            MessageLookupByLibrary.simpleMessage("プロフィールを更新して、医師とより良い印象でつながる"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "顧客とのより良い印象で接続するためにプロフィールを更新してください"),
        "updated": MessageLookupByLibrary.simpleMessage("更新済み"),
        "upload": MessageLookupByLibrary.simpleMessage("アップロード"),
        "uploadDocument": MessageLookupByLibrary.simpleMessage("文書をアップロード"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("アップロード完了"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("ファイルをアップロード"),
        "upplier": MessageLookupByLibrary.simpleMessage("サプライヤー"),
        "usbC": MessageLookupByLibrary.simpleMessage("USB C"),
        "use": MessageLookupByLibrary.simpleMessage("使用"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("Pos Saasを使用する"),
        "useOfTheSystem": MessageLookupByLibrary.simpleMessage("システムの使用"),
        "userIsDeleted": MessageLookupByLibrary.simpleMessage("ユーザーが削除されました"),
        "userRole": MessageLookupByLibrary.simpleMessage("ユーザー ロール"),
        "userRoleDetails": MessageLookupByLibrary.simpleMessage("ユーザーロールの詳細"),
        "userTitle": MessageLookupByLibrary.simpleMessage("ユーザー タイトル"),
        "userTitleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("ユーザー名を空にすることはできません"),
        "value": MessageLookupByLibrary.simpleMessage("値"),
        "vatDoesNotApply": MessageLookupByLibrary.simpleMessage("VATは適用されません"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("OTPの確認"),
        "verifyPhoneNumber": MessageLookupByLibrary.simpleMessage("電話番号の確認"),
        "viewAll": MessageLookupByLibrary.simpleMessage("すべて表示"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("詳細を表示"),
        "walkInCustomer": MessageLookupByLibrary.simpleMessage("来店客"),
        "warehouse": MessageLookupByLibrary.simpleMessage("倉庫"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("倉庫は既に存在します"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("倉庫リスト"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("倉庫名"),
        "warranty": MessageLookupByLibrary.simpleMessage("保証"),
        "weHaveSendAnEmailwithInstructions":
            MessageLookupByLibrary.simpleMessage(
                "パスワードのリセット方法に関する指示が含まれたEメールを送信しました:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "私たちはアプリの機能をサポートするためにアナリティクスプロバイダーや決済処理業者などの第三者サービスを利用することがあります。これらの第三者サービスは、私たちのアプリを使用する際にあなたに関する情報を収集する場合があります。これらの第三者サービスのプライバシー慣行については私たちの責任ではないことに注意してください。"),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "私たちは暗号化や安全な保存を含む個人情報を保護する業界標準の対策を取っています。また、情報へのアクセスを認可された担当者のみに制限しています。"),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "シームレスな運用の重要性を理解しています。そのため、私たちの24時間対応のサポートは、迅速な問い合わせから包括的な問題まで、いつでもどこでもお手伝いします。私たちに電話またはWhatsAppでいつでもどこでも接続し、無類のカスタマーサービスを体験してください。"),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "私たちはあなたの個人情報を利用して、私たちのアプリで最高の体験を提供し、コンテンツの推薦を個別化し、専門家と接続し、アプリの機能を向上させます。また、アップデート、プロモーション、またはアプリに関連するその他の情報についてあなたと連絡を取るためにあなたの情報を利用することがあります。"),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage("支払いを確認し、1-2時間以内に承認します"),
        "weekly": MessageLookupByLibrary.simpleMessage("週間"),
        "weight": MessageLookupByLibrary.simpleMessage("重量"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("新着情報"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("卸売業者"),
        "wholeSalePrice": MessageLookupByLibrary.simpleMessage("卸売価格"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("卸売価格"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("卸売業者"),
        "willBeAddedSoon": MessageLookupByLibrary.simpleMessage("近日追加されます"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("有効期限"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("メッセージをこちらに入力"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("間違ったOTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage("そのユーザーのパスワードが間違っています。"),
        "yearly": MessageLookupByLibrary.simpleMessage("年次"),
        "yesDeleteForever": MessageLookupByLibrary.simpleMessage("はい、永久に削除"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("有効なユーザーではありません"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("使用中："),
        "youCanNotPayMoreThenDue":
            MessageLookupByLibrary.simpleMessage("支払いが期限を超えることはできません"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Eメールを受信しました"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "アカウントに正常にログインしました。Pos Saas をご利用ください。"),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("権限を与える必要があります"),
        "youHaveToReLogin":
            MessageLookupByLibrary.simpleMessage("アカウントに再ログインする必要があります"),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage("購入前に本人確認が必要です"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("あなたのメッセージは残ります"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("あなたのパッケージ"),
        "yourPackageWillExpireinDay":
            MessageLookupByLibrary.simpleMessage("あなたのパッケージは5日後に期限切れになります")
      };
}
