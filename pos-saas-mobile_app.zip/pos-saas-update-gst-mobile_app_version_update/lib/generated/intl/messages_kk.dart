// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a kk locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'kk';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Жалғастыру"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("GST нөмірі"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("Мөлшері бағасы"),
        "MRPIsRequired": MessageLookupByLibrary.simpleMessage("MRP қажет"),
        "OK": MessageLookupByLibrary.simpleMessage("Жарайды"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Тел. номері"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT коды"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Тәттілер"),
        "TAX": MessageLookupByLibrary.simpleMessage("САЛЫҚ"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Жүктелуде"),
        "UserTitle":
            MessageLookupByLibrary.simpleMessage("Пайдаланушы Тақырыбы"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Сіздің пакетіңіз бүгін аяқталады\n\nҚайтадан сатып алуыңызды сұраймыз"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(а) Жүйе тек сату нүктесін жасау және байланысты амалдарды жасау мақсатында ұсынылады."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(а) Жүйені пайдалану үшін сізге ескертуі тиісіз екенін талап еді. Тіркелу процесінде дұрыс, ақталушы және толық ақпаратты ұсыну үшін келісесіз және оны жаңарту үшін сізге нысан айтуға келісесіз."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("Қолданба жайлы"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Біз туралы"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Шарттарды қабылдау"),
        "accountName": MessageLookupByLibrary.simpleMessage("Есеп аты"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("Есеп нөмірі"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Тіркелу жазбасы"),
        "acton": MessageLookupByLibrary.simpleMessage("Әрекет"),
        "add": MessageLookupByLibrary.simpleMessage("Қосу"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Бренд қосу"),
        "addCategory": MessageLookupByLibrary.simpleMessage("Санат қосу"),
        "addContact": MessageLookupByLibrary.simpleMessage("Байланыс қосу"),
        "addCustomer":
            MessageLookupByLibrary.simpleMessage("Тапсырыш берушіні қосу"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("Жеткізу қосу"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Сипаттама қосу"),
        "addDescription": MessageLookupByLibrary.simpleMessage("Ескертпе қосу"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Жеңілдік қосу"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Құжат идентификаторын қосу"),
        "addDucument": MessageLookupByLibrary.simpleMessage("Құжат қосу"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Шығын қосу"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Шығын санатын қосу"),
        "addItems": MessageLookupByLibrary.simpleMessage("Тауарды қосу"),
        "addNew": MessageLookupByLibrary.simpleMessage("Жаңа қосу"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Жаңа мекенжай қосу"),
        "addNewProduct": MessageLookupByLibrary.simpleMessage("Жаңа өнім қосу"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("Жаңа салық қосу"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Біржақты/көптеген салық түрімен жаңа салық қосу"),
        "addNote": MessageLookupByLibrary.simpleMessage("Ескертпе қосу"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Алдымен өнімді қосыңыз"),
        "addPromoCode": MessageLookupByLibrary.simpleMessage("Промокодты қосу"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Сатып алу қосу"),
        "addSales": MessageLookupByLibrary.simpleMessage("Сатып алу қосу"),
        "addSuccessful": MessageLookupByLibrary.simpleMessage("Сәтті қосылды"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Бірлік қосу"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Пайдаланушы рөлін қосу"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Сәтті қосылды"),
        "addedToCart": MessageLookupByLibrary.simpleMessage("Себетке қосылды"),
        "address": MessageLookupByLibrary.simpleMessage("Мекенжай"),
        "admin": MessageLookupByLibrary.simpleMessage("Әкімші"),
        "all": MessageLookupByLibrary.simpleMessage("Барлығы"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("Барлық бизнес шешімдері"),
        "alreadyAdded":
            MessageLookupByLibrary.simpleMessage("Алдын ала қосылған"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Уже бар"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Бұрын акаунты бар"),
        "amount": MessageLookupByLibrary.simpleMessage("Сома"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "Электрондық пошта жіберілді.\\nПоштаны тексеріңіз"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Android және iOS бағдарламасының қолдауы"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Қолданылатын салық"),
        "apply": MessageLookupByLibrary.simpleMessage("Қолдану"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Бұл шот-фактураны жоюға сенімдісіз бе?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Бұл сатуды жоюға сенімдісіз бе?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Бұл пайдаланушыны жоюға сенімдісіз бе?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Сіз осы салықты жойғыңыз келе ме?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Сіз осы салық тобын жойғыңыз келе ме?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Сіз осы сақтау қоймасын жойғыңыз келе ме?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Бұл пайдаланушын жою керекпіз бе?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Уәкілетті қол"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(б) Сіз тіркелу жазбасы және құпия сөзді ұстау және тіркелу жазбасыңызға қол жеткізу үшін жауапкерші болыс және оны пайдалануыңыздағы барлық іс-шаралар үшін жауапкерші болысыз."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(б) Сіздің жұртыңызда болуыңыз керек, сіз жүйені пайдалану үшін сіздің ішкі аймағыңыздағы жас үшін 18 жас немесе көпірек мерзімінің қануы керек."),
        "backSide": MessageLookupByLibrary.simpleMessage("Арты тарап"),
        "backToHome": MessageLookupByLibrary.simpleMessage("Басты бетке оралу"),
        "balance": MessageLookupByLibrary.simpleMessage("Баланс"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Бангладеш"),
        "bank": MessageLookupByLibrary.simpleMessage("Банк"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Банк шотының валютасы"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Банк есептік валюта"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Банк ақпараты"),
        "bankName": MessageLookupByLibrary.simpleMessage("Банк аты"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("Банк аударымы"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Штрих-код табылды"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Шот/Фактура"),
        "billTo": MessageLookupByLibrary.simpleMessage("Тапсырыш берушіге"),
        "branchName": MessageLookupByLibrary.simpleMessage("Филиал атауы"),
        "brand": MessageLookupByLibrary.simpleMessage("Бренд"),
        "brandName": MessageLookupByLibrary.simpleMessage("Бренд атауы"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("Көптеп \nЖүктеу"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Бизнес санаты"),
        "buy": MessageLookupByLibrary.simpleMessage("Сатып алу"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Премиум тақырыпты сатып алу"),
        "buySms": MessageLookupByLibrary.simpleMessage("СМС сатып алу"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Сіз [Сіздің Компания Аты] («Компания») тарапынан ұсынылған Сатып нүктесі (POS) Жүйесін пайдалану арқылы немесе қолдану арқылы, сіз бұл Пайдалану Шарттарымен біріктігіңізге келісесіз. Егер сіз бұл Пайдалану Шарттарымен келіспесіздер демесесіз, жүйені қолданбайтын едіңіз."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(с) Сіз жүйеге қол жеткізуіңіз мен оны пайдалануыңызды тиімді закондар мен тіркесті нормативтік актілермен сәйкес жүргізуіңіз керек."),
        "cacel": MessageLookupByLibrary.simpleMessage("Болдырмау"),
        "call": MessageLookupByLibrary.simpleMessage("Қоңырау шалу"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "Төтенше қолдау үшін қоңырау шалыңыз"),
        "camera": MessageLookupByLibrary.simpleMessage("Камера"),
        "cancel": MessageLookupByLibrary.simpleMessage("Бас тарту"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Барлық өнімдерді бас тарту"),
        "capacity": MessageLookupByLibrary.simpleMessage("Қабілеті"),
        "card": MessageLookupByLibrary.simpleMessage("Карта"),
        "cash": MessageLookupByLibrary.simpleMessage("Қағаз ақша"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Ақша жоқ"),
        "categories": MessageLookupByLibrary.simpleMessage("Санаттар"),
        "category": MessageLookupByLibrary.simpleMessage("Санат"),
        "categoryName": MessageLookupByLibrary.simpleMessage("Категория атауы"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "Категория атауы бұрыннан бар"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("Санат атауы"),
        "change": MessageLookupByLibrary.simpleMessage("Өзгерту?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Құпия сөзді өзгерту"),
        "checkEmail":
            MessageLookupByLibrary.simpleMessage("Поштаны тексеріңіз"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Тапсырыш берушін таңдаңыз"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Тапсырыш берушін таңдаңыз"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Мүмкіндіктерді таңдаңыз"),
        "clarence": MessageLookupByLibrary.simpleMessage("Clarence"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Байланыс үшін басыңыз"),
        "close": MessageLookupByLibrary.simpleMessage("Жабу"),
        "color": MessageLookupByLibrary.simpleMessage("Түсі"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(Көптеген салықтардың комбинациясы)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Жақын арада"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Компания мекенжайы"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Компания және дүкен атауы"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("Компания және Бизнес атауы"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Жүйелік ісігін аяқтау"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Құпия сөзді растау"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Қайтауды растау"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Құттықтаймыз"),
        "contactUs":
            MessageLookupByLibrary.simpleMessage("Бізбен байланысыңыз"),
        "continu": MessageLookupByLibrary.simpleMessage("Жалғастыру"),
        "country": MessageLookupByLibrary.simpleMessage("Ел"),
        "create": MessageLookupByLibrary.simpleMessage("Жасау"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Тегін тіркелу"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Жасалды және сақталды"),
        "currency": MessageLookupByLibrary.simpleMessage("Валюта"),
        "currentStock":
            MessageLookupByLibrary.simpleMessage("Ағымдағы қорытынды"),
        "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
            "Жеке Есептік Тапсырыс Брендинг"),
        "customer": MessageLookupByLibrary.simpleMessage("Тапсырыш беруші"),
        "customerDetails": MessageLookupByLibrary.simpleMessage(
            "Тапсырыш беруші туралы мәлімет"),
        "customerGST": MessageLookupByLibrary.simpleMessage("Клиенттің GST"),
        "customerName":
            MessageLookupByLibrary.simpleMessage("Тапсырыш беруші аты"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Күнделікті жүйе"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Бақалуар бақылау"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Деректер сәтті сақталды"),
        "date": MessageLookupByLibrary.simpleMessage("Күні"),
        "day": MessageLookupByLibrary.simpleMessage("Күн"),
        "dealer": MessageLookupByLibrary.simpleMessage("Дилер"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("Дилер бағасы"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("Әдеттегі ҚҚС пайызы"),
        "delete": MessageLookupByLibrary.simpleMessage("Жою"),
        "deleting": MessageLookupByLibrary.simpleMessage("Жою"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Жеткізу мекенжайы"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Жеткізу мекен-жайлары"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Жеткізу алдын алу"),
        "describtion": MessageLookupByLibrary.simpleMessage("Сипаттама"),
        "description": MessageLookupByLibrary.simpleMessage("Сипаттама"),
        "descriptionCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Сипаттамасы бос болмауы керек"),
        "details": MessageLookupByLibrary.simpleMessage("Мәліметтер"),
        "discount": MessageLookupByLibrary.simpleMessage("Жеңілдік"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Қиындау"),
        "done": MessageLookupByLibrary.simpleMessage("Аяқталды"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Excel форматында жүктеу"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Жүктеліп, жүктеу папкасында сәтті сақталды"),
        "due": MessageLookupByLibrary.simpleMessage("Төлем"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Төлем сомасы: "),
        "dueCollection": MessageLookupByLibrary.simpleMessage("Төлем тізімі"),
        "dueCollectionReports": MessageLookupByLibrary.simpleMessage(
            "Толтырылатын Толқу Хабарламалар"),
        "dueList": MessageLookupByLibrary.simpleMessage("Төлем тізімі"),
        "dueReports":
            MessageLookupByLibrary.simpleMessage("Төлемге дейінгі есеп"),
        "duration": MessageLookupByLibrary.simpleMessage("Уақыт"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Мерзім: Бастап"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "Мобильді біріктірілген терминалды пайдалануды жеңілдетеді"),
        "edit": MessageLookupByLibrary.simpleMessage("Түзету"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Сатып алу төлемін түзету"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Сатып алу төлемін түзету"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Социалды медианы түзету"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Сәтті өзгертілді"),
        "editTax": MessageLookupByLibrary.simpleMessage("Салықты өзгерту"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Салық тобын өзгерту"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("Сақтау қоймасын өзгерту"),
        "email": MessageLookupByLibrary.simpleMessage("Пошта"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("Пошта Мекенжайы"),
        "emailCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Электрондық пошта бос болмауы керек"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "Электрондық пошта жіберілді! Пошта жәшігіңізді тексеріңіз"),
        "endDate": MessageLookupByLibrary.simpleMessage("Аяқталу күні"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Дұрыс соманы енгізіңіз"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Дұрыс жеңілдікті енгізіңіз"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Дұрыс телефон нөмірін енгізіңіз"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Дұрыс бағасын енгізіңіз"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("Дұрыс сан енгізіңіз"),
        "enterAddress":
            MessageLookupByLibrary.simpleMessage("Мекенжайды енгізіңіз"),
        "enterAmount":
            MessageLookupByLibrary.simpleMessage("Соманы енгізіңіз."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Бренд атауын енгізіңіз"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Қабілетін енгізіңіз"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Санат атауын енгізіңіз"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Түсін енгізіңіз"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "Клиенттің GST нөмірін енгізіңіз"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Дилер бағасын енгізіңіз"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Сипаттаманы енгізіңіз"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("Жеңілдік енгізіңіз"),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Шығын күнін енгізіңіз"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Толық мекенжайды енгізіңіз"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Төлем нөмірін енгізіңіз"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Төмен қойма туралы ескерту саны енгізіңіз"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Әзіргіш атын енгізіңіз"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("Хабар мазмұнын енгізіңіз"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "Мөлшері бағасын немесе дропшиппинг бағасын енгізіңіз"),
        "enterName": MessageLookupByLibrary.simpleMessage("Атын енгізіңіз"),
        "enterNote":
            MessageLookupByLibrary.simpleMessage("Ескертпені енгізіңіз"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Тарап атауын енгізіңіз"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Телефон нөмірін енгізіңіз"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Өнім кодын енгізіңіз немесе скандап көріңіз"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Өнім атауын енгізіңіз"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Сатып алу бағасын енгізіңіз"),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("Сілтеме нөмірін енгізіңіз"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Өлшемін енгізіңіз"),
        "enterStocks":
            MessageLookupByLibrary.simpleMessage("Тауар санын енгізіңіз"),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Салық мөлшерін енгізіңіз"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("Транзакция ID-сын енгізіңіз"),
        "enterType": MessageLookupByLibrary.simpleMessage("Түрін енгізіңіз"),
        "enterUserTitle": MessageLookupByLibrary.simpleMessage(
            "Пайдаланушы тақырыбын енгізіңіз"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Дұрыс соманы енгізіңіз"),
        "enterWarehouseName": MessageLookupByLibrary.simpleMessage(
            "Сақтау қоймасының атауын енгізіңіз"),
        "enterWeight":
            MessageLookupByLibrary.simpleMessage("Салмағын енгізіңіз"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Опт бағасын енгізіңіз"),
        "enterYourDescriptionHere": MessageLookupByLibrary.simpleMessage(
            "Сипаттаманы осында енгізіңіз"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("Пошта мекенжайын енгізіңіз"),
        "enterYourFeedBackTitle":
            MessageLookupByLibrary.simpleMessage("Пікір тақырыбын енгізіңіз"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("GST нөміріңізді енгізіңіз"),
        "enterYourMobileNumber": MessageLookupByLibrary.simpleMessage(
            "Мобильді нөміріңізді енгізіңіз"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Атыңызды енгізіңіз"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("Телефон нөмірін енгізіңіз"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Құпия сөзді енгізіңіз"),
        "enterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Телефон нөміріңізді енгізіңіз"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "Сіздің жүйелік ісігідің идентификаторын енгізіңіз"),
        "error": MessageLookupByLibrary.simpleMessage("Қате"),
        "excTax": MessageLookupByLibrary.simpleMessage("Шығыс салық"),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("Excel жүктеушісі"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Қосымша"),
        "expense": MessageLookupByLibrary.simpleMessage("Шығын"),
        "expenseCategory": MessageLookupByLibrary.simpleMessage("Шығын санаты"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Шығын күні"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Шығын себебі"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Шығын есептемесі"),
        "expireDate":
            MessageLookupByLibrary.simpleMessage("Жарамдылық мерзімі"),
        "expired": MessageLookupByLibrary.simpleMessage("Аяқталды"),
        "expiring": MessageLookupByLibrary.simpleMessage("Аяқталатын"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Қате орын алды"),
        "fashion": MessageLookupByLibrary.simpleMessage("Мода"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Мүмкіндіктер біздің Pos Saas  түрліден айырылып келетін өнімдеріміздің маңызды бөлігі."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Пікір"),
        "firstName": MessageLookupByLibrary.simpleMessage("Аты"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Бізді Facebook-та бақылаңыз"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Бізді Twitter-де бақылаңыз"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Алды тарап"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("Шектеусіз пайдалану үшін"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Құпия сөзді ұмыттыңыз ба?"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Құпия сөзді ұмыттыңыз ба?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Күнінен"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("Тегін деректерді сақтау"),
        "freeLifeTimeUpdate":
            MessageLookupByLibrary.simpleMessage("Тегін орындау жасау"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Тегін пакет"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Тегін тақырып"),
        "from": MessageLookupByLibrary.simpleMessage("(Бастап"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Толығымен төленген"),
        "gallary": MessageLookupByLibrary.simpleMessage("Галерея"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("PDF жасалуда"),
        "getOtp": MessageLookupByLibrary.simpleMessage("ОТП алу"),
        "govermentId":
            MessageLookupByLibrary.simpleMessage("Мемлекеттік жетекші"),
        "guest": MessageLookupByLibrary.simpleMessage("Мекенжайдағы клиент"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Тіркелгіңіз жоқ па?"),
        "history": MessageLookupByLibrary.simpleMessage("Тарих"),
        "home": MessageLookupByLibrary.simpleMessage("Басты бет"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Сіздің ақпаратты қалай қорғаймыз"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Сіздің ақпаратты қалай қолданамыз"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Жеке мәліметті тексеру"),
        "image": MessageLookupByLibrary.simpleMessage("Сурет"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("Ішкі жойылмайды"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("Ішкі өзгертілмейді"),
        "inWord": MessageLookupByLibrary.simpleMessage("Сөзбен"),
        "incTax": MessageLookupByLibrary.simpleMessage("Қосылған салық"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Қамтитын"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("Қорды арттыру"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Инструмент"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Сатып алу нөмірі"),
        "invoice": MessageLookupByLibrary.simpleMessage("Шот-фактура"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("Төлем нөмірі"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Төлем параметрлері"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Шот-фактура көрушісі"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Тауар қосылды"),
        "kg": MessageLookupByLibrary.simpleMessage("Кг"),
        "kycVerification": MessageLookupByLibrary.simpleMessage("KYC тексеру"),
        "language": MessageLookupByLibrary.simpleMessage("Тіл"),
        "lastName": MessageLookupByLibrary.simpleMessage("Тегі"),
        "ledger": MessageLookupByLibrary.simpleMessage("Леджер"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Өмірлік\nСатып алу"),
        "link": MessageLookupByLibrary.simpleMessage("Сілтеме"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Тікелей чат қолдауы"),
        "loading": MessageLookupByLibrary.simpleMessage("Жүктелуде"),
        "logIn": MessageLookupByLibrary.simpleMessage("Кіру"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Шығу"),
        "logOut": MessageLookupByLibrary.simpleMessage("Шығу"),
        "login": MessageLookupByLibrary.simpleMessage("Кіру"),
        "logo": MessageLookupByLibrary.simpleMessage("Логотип"),
        "loss": MessageLookupByLibrary.simpleMessage("Кедергі"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Кедергі/Қаржы"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Кедергі/Қаржы толтырмалары"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Зиян/Пайда туралы есеп"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Зиян/Пайда есептері"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Төмен қойма туралы ескерту"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Таңдаушыларыңызға брендді тапсырыстармен жазылмыз. Біздің Шектеусіз Ортаға жасау брендингді жасауға қолдау қызметі ұсынады, брендіңізді қуаттап, таңдаушылардың мойындауын жасауға мүмкіндік береді."),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("Бизнесіңізді басқарыңыз "),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Өндірілген күні"),
        "margin": MessageLookupByLibrary.simpleMessage("Маржа"),
        "masterCard": MessageLookupByLibrary.simpleMessage("Master card"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Әзіргіш"),
        "message": MessageLookupByLibrary.simpleMessage("Хабарлама"),
        "messageHistory": MessageLookupByLibrary.simpleMessage("Хабар тарихы"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Pos Saas  бағдарламасы тегін, пайдалануы жеңілді. Себебі, бұл ең жақсы POS жүйесінің бірі."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas  барлық бизнес шешімі, есеп, сату, қақтығыш және кедергі/қаржы мені жеделдетеді."),
        "mobile": MessageLookupByLibrary.simpleMessage("Мобильді"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("Мобильді төлем"),
        "monthly": MessageLookupByLibrary.simpleMessage("Айлық"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("Толығырақ"),
        "name": MessageLookupByLibrary.simpleMessage("Атыңызды енгізіңіз."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Атауы бұрыннан бар"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("Атау бос болмауы керек"),
        "next": MessageLookupByLibrary.simpleMessage("Келесі"),
        "noConnection": MessageLookupByLibrary.simpleMessage("Қосылым жоқ"),
        "noData": MessageLookupByLibrary.simpleMessage("Мәліметтер жоқ"),
        "noDataAvailable": MessageLookupByLibrary.simpleMessage("Мәлімет жоқ"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Деректер табылған жоқ"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("Тарих табылған жоқ!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Өнім табылмады"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("Қос салық таңдалмаған"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("Жүйеден ақылу табылған жоқ!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Осы поштамекенжайымен пайдаланушы табылмады."),
        "noUserRoleFound":
            MessageLookupByLibrary.simpleMessage("Пайдаланушы рөлі табылмады"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Белсенді емес пайдаланушы"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Берілмеген"),
        "note": MessageLookupByLibrary.simpleMessage("Ескертпе"),
        "notes": MessageLookupByLibrary.simpleMessage("Ескертпелер"),
        "notification": MessageLookupByLibrary.simpleMessage("Хабарлама"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP жіберілді"),
        "office": MessageLookupByLibrary.simpleMessage("Офис"),
        "ok": MessageLookupByLibrary.simpleMessage("Жарайды"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "Сату бақылау, өнім қаржылау бейінде көп қосымшалықты орналастырып беретін POS"),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Бұл жүйе сіздің өзіңіздің клиенттеріңіз үшін жұмыс жасауыңызды қолдау етеді."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Біздің POS жүйеміз күнделікті жұмыс жасауыңызды оңай жасауымыз керек болады."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("Басып ашу сомасы"),
        "order": MessageLookupByLibrary.simpleMessage("Тапсырыстар"),
        "other": MessageLookupByLibrary.simpleMessage("Басқа"),
        "otp": MessageLookupByLibrary.simpleMessage("Жабу"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Қоймада жоқ"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Пакет"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Тақырыптың мүмкіндіктері"),
        "paid": MessageLookupByLibrary.simpleMessage("Төлем жасалды"),
        "paidAmount":
            MessageLookupByLibrary.simpleMessage("Төлемді ақылы сома"),
        "parties": MessageLookupByLibrary.simpleMessage("Таралар"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Тараптар тізімі"),
        "partyGST": MessageLookupByLibrary.simpleMessage("Тараптың GST"),
        "partyName": MessageLookupByLibrary.simpleMessage("Тарап атауы"),
        "password": MessageLookupByLibrary.simpleMessage("Құпия сөз"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Пароль мен растау паролі сәйкес келмейді"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Құпия сөз бос болмауы керек"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("Құпия сөз сәйкес келмейді"),
        "payCash": MessageLookupByLibrary.simpleMessage("Нақты төлеу"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("Bkash арқылы төлеу"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Paypal арқылы төлеу"),
        "payeeName": MessageLookupByLibrary.simpleMessage("Алымшы атауы"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("Алымшы нөмірі"),
        "payment": MessageLookupByLibrary.simpleMessage("Төлем"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("Төлем сомасы"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Төлем аяқталды"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Төлем нұсқаулары:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("Төлем әдісі"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Төлем түрі"),
        "pdfView": MessageLookupByLibrary.simpleMessage("PDF Көру"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Жеке ақпарат"),
        "phone": MessageLookupByLibrary.simpleMessage("Телефон"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Телефон нөмірі"),
        "phoneNumberAlreadyUsed":
            MessageLookupByLibrary.simpleMessage("Телефон нөмірі бұрыннан бар"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("Телефон нөмірі дұрыс емес"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("Телефон нөмірі қажет"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("Файлды таңдап, жүктеңіз"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("Аяқталу күнін таңдау"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Басталу күнін таңдау"),
        "plan": MessageLookupByLibrary.simpleMessage("Жоспар"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("Саныңызды қосыңыз"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Интернет қосылымын тексеріңіз"),
        "pleaseConnectThePrinterFirst":
            MessageLookupByLibrary.simpleMessage("Басқарғышты алдымен қосыңыз"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Bluetooth принтеріңізді қосыңыз"),
        "pleaseEnterABiggerPassword":
            MessageLookupByLibrary.simpleMessage("Ұзын құпия сөз енгізіңіз"),
        "pleaseEnterAConfirmPassword":
            MessageLookupByLibrary.simpleMessage("Өтініш, құпия сөзді растау"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("Құпия сөзді енгізіңіз"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Дұрыс электрондық поштаны енгізіңіз"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Аты-жөніңізді енгізіңіз"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("Парольді енгізіңіз"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Құпия сөзді қалпына келтіру сілтемесін алу үшін төмендегі пошта мекенжайын енгізіңіз."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Транзакция номерін енгізіңіз"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("Соманы енгізіңіз"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Алдымен категорияны таңдаңыз"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("Жоспарды таңдаңыз"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Бизнес категориясын таңдаңыз"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Қолданбаны пайдалану үшін дұрыс сатып алу кодын пайдаланыңыз"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Pos Saas жасалды"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Қолданушының"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Премиум Тіркеу Қолдауы"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Премиум тақырып"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Алдыңғы төлем сомалары"),
        "price": MessageLookupByLibrary.simpleMessage("бағасы"),
        "print": MessageLookupByLibrary.simpleMessage("Баспау"),
        "printingOption": MessageLookupByLibrary.simpleMessage("Басу опциясы"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Құпиялылық саясаты"),
        "product": MessageLookupByLibrary.simpleMessage("Өнім"),
        "productCode": MessageLookupByLibrary.simpleMessage("Өнім коды"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("Өнім коды қажет"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Өнім коды/Атауы"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Өнімнің сипаттамасы"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Өнімнің мәліметтері"),
        "productList": MessageLookupByLibrary.simpleMessage("Өнім тізімі"),
        "productName": MessageLookupByLibrary.simpleMessage("Өнім атауы"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Өнімнің атауы осы қоймада бар"),
        "productNameIsAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("Өнім атауы уже қосылды"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("Өнімнің атауы қажет"),
        "products": MessageLookupByLibrary.simpleMessage("Өнімдер"),
        "profile": MessageLookupByLibrary.simpleMessage("Профиль"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("Профильді өңдеу"),
        "profit": MessageLookupByLibrary.simpleMessage("Көрсеткіш"),
        "promo": MessageLookupByLibrary.simpleMessage("Промо"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Промо коды"),
        "purchase": MessageLookupByLibrary.simpleMessage("Сатып алу"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("Сатып алу хабары"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Сатып алу расталды"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Сатып алу толтырмалары"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Сатып алу фактурасы"),
        "purchaseList":
            MessageLookupByLibrary.simpleMessage("Сатып алу тізімі"),
        "purchaseNow":
            MessageLookupByLibrary.simpleMessage("Қазір сатып алыңыз"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Премиум тақырыпты сатып алу"),
        "purchasePrice":
            MessageLookupByLibrary.simpleMessage("Сатып алу бағасы"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("Сатып алу бағасы қажет"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("Сатып алу есептемесі"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Сатып алу есептемесі"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Сатып алу Хабарламалар"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("Сатып алу қайтарады"),
        "purchaseReturnReport": MessageLookupByLibrary.simpleMessage(
            "Сатып алу қайтару туралы есеп"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Сатып алу өтпесі"),
        "qty": MessageLookupByLibrary.simpleMessage("Мөлшері"),
        "quantity": MessageLookupByLibrary.simpleMessage("Саны"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Соңғы іс-шаралар"),
        "recivedThePin": MessageLookupByLibrary.simpleMessage("Пин кодты алу"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Сілтеме нөмірі"),
        "register": MessageLookupByLibrary.simpleMessage("Тіркеу"),
        "registering": MessageLookupByLibrary.simpleMessage("Тіркелу"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("Қалған төлем"),
        "remove": MessageLookupByLibrary.simpleMessage("Жою"),
        "reports": MessageLookupByLibrary.simpleMessage("Есептер"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Сұрау жіберілді"),
        "resendCode":
            MessageLookupByLibrary.simpleMessage("Кодты қайта жіберу"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("ОТП қайта жіберу: "),
        "retailer": MessageLookupByLibrary.simpleMessage("Торговец"),
        "retur": MessageLookupByLibrary.simpleMessage("Қайтару"),
        "returN": MessageLookupByLibrary.simpleMessage("Қайтару"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("Айыппу сомасы"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("Айыппу сомасы"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("Қайтару саны"),
        "revenue": MessageLookupByLibrary.simpleMessage("Табыс"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Сіздің бизнес деректеріңізді жасау жаттығушы болады. Біздің Pos Saas POS Unlimited Upgrade-і тегін деректерді сақтау қосымшасы, сіздің маңызды ақпаратыңызды жарамсыз событиялармен қарсы қорқытуға қамтамасыз етеді. Сіздің бизнесіңізді жастар қалдыруға құлақ аударыңыз."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Сату сомасы"),
        "saleDetails":
            MessageLookupByLibrary.simpleMessage("Сатып алу толтырмалары"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Сатып алу бағасы"),
        "saleReports":
            MessageLookupByLibrary.simpleMessage("Сатып алу есептемесі"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Сату Хабарламалар"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("Сату қайтару"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Сату қайтару есеп"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("Сату параметрі"),
        "sales": MessageLookupByLibrary.simpleMessage("Сатып алу"),
        "salesAndPurchaseReports": MessageLookupByLibrary.simpleMessage(
            "Сатып алу және сату есептері"),
        "salesList": MessageLookupByLibrary.simpleMessage("Сатып алу тізімі"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("Сату қайтару"),
        "save": MessageLookupByLibrary.simpleMessage("Сақтау"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Сақтау және жариялау"),
        "saveChanges":
            MessageLookupByLibrary.simpleMessage("Өзгерістерді сақтау"),
        "saving": MessageLookupByLibrary.simpleMessage("Сақтау"),
        "scanProductQRCode": MessageLookupByLibrary.simpleMessage(
            "Өнімнің QR кодын сканерлеңіз"),
        "search": MessageLookupByLibrary.simpleMessage("Іздеу"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Өнім кодымен немесе атаумен іздеу"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("Барлық промо кодтарды көру"),
        "select": MessageLookupByLibrary.simpleMessage("Таңдау"),
        "selectAProductForReturn":
            MessageLookupByLibrary.simpleMessage("Қайтару үшін өнім таңдаңыз"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Брендті таңдаңыз"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Категорияны таңдаңыз"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Байланыс тапсырыныз"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("Өнім категориясын таңдаңыз"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("Дүкен категориясын таңдаңыз"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Салықты таңдаңыз"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Салық түрін таңдаңыз"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("Бірлікті таңдаңыз"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Вариацияны таңдау: "),
        "seller": MessageLookupByLibrary.simpleMessage("Сатушы"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Сатушы"),
        "send": MessageLookupByLibrary.simpleMessage("Жіберу"),
        "sendEmail":
            MessageLookupByLibrary.simpleMessage("Электронды пошта жіберу"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Хабар жіберу"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("Сброс сілтемесін жіберу"),
        "sendSms": MessageLookupByLibrary.simpleMessage("СМС жіберу"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("СМС жіберу?"),
        "sendWhatsappMessage": MessageLookupByLibrary.simpleMessage(
            "Whatsapp хабарламасын жіберу"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Электронды поштаны жіберу"),
        "sendingEmail":
            MessageLookupByLibrary.simpleMessage("Электрондық поштаны жіберу"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Хабарлама жіберілуде"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Қызмет/Жеткізу"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Профилді орнату"),
        "setting": MessageLookupByLibrary.simpleMessage("Параметрлер"),
        "share": MessageLookupByLibrary.simpleMessage("Бөлісу"),
        "shopGST": MessageLookupByLibrary.simpleMessage("Дүкеннің GST"),
        "signIn": MessageLookupByLibrary.simpleMessage("Кіру"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("Электрондық поштамен кіру"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Тұтынушының қолы"),
        "size": MessageLookupByLibrary.simpleMessage("Өлшемі"),
        "skip": MessageLookupByLibrary.simpleMessage("Өткізу"),
        "sms": MessageLookupByLibrary.simpleMessage("СМС"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Социалды маркетинг"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Кешіріңіз, сізде осы қызметке қол жеткізу рұқсаты жоқ"),
        "startDate": MessageLookupByLibrary.simpleMessage("Басталу күні"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Жаңа сатып алу бастау"),
        "startTypingToSearch":
            MessageLookupByLibrary.simpleMessage("Іздеу бастау"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Толық технологиялық жетекшіліктердің қоршағанынан босқа қалмайтындай қалың қалу. Біздің Pos Saas POS Unlimited Upgrade, сізге қосымша төлемдер және мүмкіндіктердің соңғы нүсқаларының әрекеттерін жастауға әмірдейді, сіздің бизнесіңізді жаңа алқасын жарап тұртып қалады."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("Әлі төленбеген"),
        "stock": MessageLookupByLibrary.simpleMessage("Қор"),
        "stockIsRequired": MessageLookupByLibrary.simpleMessage("Қойма қажет"),
        "stockList": MessageLookupByLibrary.simpleMessage("Өнім тізімі"),
        "stocks": MessageLookupByLibrary.simpleMessage("Тауар саны"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Excel файлын жасау үшін сақтау рұқсаты қажет"),
        "subTaxList":
            MessageLookupByLibrary.simpleMessage("Қос салықтар тізімі"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Қос салықтар"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Жалпы сома"),
        "submit": MessageLookupByLibrary.simpleMessage("Жіберу"),
        "subscribeToOurYoutube":
            MessageLookupByLibrary.simpleMessage("Бізге Youtube-те жазылыңыз"),
        "subscription": MessageLookupByLibrary.simpleMessage("Тіркелу"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Сәтті аяқталды"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Сәтті шығып кетті"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Сәтті жаңартылды"),
        "supplier": MessageLookupByLibrary.simpleMessage("Тапсырыс беруші"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("Тапсырыш беруші атауы"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT код"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Жолаушы үйге алынған билет, ұлттық жеке белгі немесе қашықтан тұрған"),
        "takeaNidCardToCheckYourInformation": MessageLookupByLibrary.simpleMessage(
            "Сіздің мәліметтеріңізді тексеру үшін жеке мемлекеттік жетекшін алыңыз"),
        "tap": MessageLookupByLibrary.simpleMessage("Басу"),
        "tax": MessageLookupByLibrary.simpleMessage("Салық"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Салық тобы"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("Салық пайызы"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Салық мөлшері"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Салық мөлшерлері - Салық мөлшерлеріңізді басқару"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Салық есебі"),
        "taxType": MessageLookupByLibrary.simpleMessage("Салық түрі"),
        "taxes": MessageLookupByLibrary.simpleMessage("Салықтар"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Ережелер мен шарттар"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("Қолдану ережелері"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Шарттар & Жекелік"),
        "thankYOuForYourDuePayment":
            MessageLookupByLibrary.simpleMessage("Төлем үшін рахмет"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Рахмет"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Сатып алу үшін рахмет"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "Бұл электрондық пошта үшін аккаунт бар"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Excel файлы бұрыннан жүктелген"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Атау барлығын айтып қойады. Pos Saas POS Unlimited-де пайдаланушыдың пайдалануына шектеу жоқ. Сіз кейбір транзакцияларды өңдеу немесе клиенттердің асықтауын жасау қажет болса, сіз шектеулермен бағытталмаңызды қанауға болмайды деп біліп қаласыз."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "Көрсетілген пароль тым әлсіз"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Сату жойылады және осы сатып алу туралы барлық деректер жойылады. Сіз бұл әрекетке сенімдісіз бе?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Сату жойылады және осы сату туралы барлық деректер жойылады. Сіз бұл әрекетке сенімдісіз бе?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Пайдаланушы жойылады және барлық деректер аккаунттан жойылады. Сіз сенімдісіз бе, оларды жоюды растайсыз бе?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Пайдаланушы жойылады және барлық деректер сіздің есептік жазбаңыздан жойылады. Бұл жоюға сенімдісіз бе?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Үшінші тарап қызметтері"),
        "thisCategoryCannotBeDeleted":
            MessageLookupByLibrary.simpleMessage("Бұл категория жойылмайды"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Бұл айда)"),
        "thisProductAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("Бұл өнім уже қосылған"),
        "title": MessageLookupByLibrary.simpleMessage("Тақырып"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Атауы бос болмауы керек"),
        "to": MessageLookupByLibrary.simpleMessage("туралы"),
        "toDate": MessageLookupByLibrary.simpleMessage("Күніне"),
        "today": MessageLookupByLibrary.simpleMessage("Бүгін"),
        "total": MessageLookupByLibrary.simpleMessage("Жалпы"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Жалпы сома"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Жалпы жиналған"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Жалпы төлем"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("Жалпы шығын"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Жалпы шығын"),
        "totalPayable": MessageLookupByLibrary.simpleMessage("Жалпы төлем"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Жалпы баға"),
        "totalProducts": MessageLookupByLibrary.simpleMessage("Жалпы өнімдер"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Жалпы пайда"),
        "totalPurchase":
            MessageLookupByLibrary.simpleMessage("Жалпы сатып алу"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Жалпы қайтару сомасы"),
        "totalReturns":
            MessageLookupByLibrary.simpleMessage("Жалпы қайтарулар"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Жалпы сатып алу"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Жалпы қорытынды"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Жалпы құн"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Жалпы алдау"),
        "totals": MessageLookupByLibrary.simpleMessage("Жалпы: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Жүйеден ақылу"),
        "transactionId": MessageLookupByLibrary.simpleMessage(
            "Ісігіді қолданушы идентификаторы"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Қайтадан өту"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Түрі"),
        "unitName": MessageLookupByLibrary.simpleMessage("Бірлік атауы"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Бірлік бағасы"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Бірлік бағасы"),
        "units": MessageLookupByLibrary.simpleMessage("Бірліктер"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Шексіз"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Шектеусіз пайдалану"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Pos Saas POS-тың толық потенциалын ашу. Тәжірибелі құрамымыздың жүрегінен жеткізгі сессиялар арқылы қолданылу тәсілдеріне мастер жасау. Негіздерден кеңейтілген техникаларға дейін, біз сіздің құпия сөзді қолдану тәсілін жасау үшін жетісіп үйренуге кепілдік береміз."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Төленбеген"),
        "update": MessageLookupByLibrary.simpleMessage("Жаңарту"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Байланысты жаңарту"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Қазір жаңарту"),
        "updateProduct": MessageLookupByLibrary.simpleMessage("Өнімді жаңарту"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Алдымен жоспарыңызды жаңартыңыз, шегі таусылды"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Профиліңізді жаңартыңыз"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Докторңызды жеткізу үшін профиліңізді жаңартыңыз"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Әзіргішпен жүйелік байланыс орнату үшін профиліңізді жаңартыңыз"),
        "updated": MessageLookupByLibrary.simpleMessage("Жаңартылды"),
        "upload": MessageLookupByLibrary.simpleMessage("Жүктеу"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Құжатты жүктеу"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("Жүктеу аяқталды"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Файлды жүктеу"),
        "upplier": MessageLookupByLibrary.simpleMessage("Тапсырыс беруші"),
        "usbC": MessageLookupByLibrary.simpleMessage("USB C"),
        "use": MessageLookupByLibrary.simpleMessage("Қолдану"),
        "useMobiPos":
            MessageLookupByLibrary.simpleMessage("Pos Saas  пайдалану"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Жүйені пайдалану"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Пайдаланушы жойылды"),
        "userRole": MessageLookupByLibrary.simpleMessage("Пайдаланушы Рөлі"),
        "userRoleDetails": MessageLookupByLibrary.simpleMessage(
            "Пайдаланушы рөлі түсініктері"),
        "userTitle":
            MessageLookupByLibrary.simpleMessage("Пайдаланушы Тақырыбы"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Пайдаланушы атауы бос болмауы керек"),
        "value": MessageLookupByLibrary.simpleMessage("Құн"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("ҚҚС қолданылмайды"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("ОТП тексеру"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Телефон нөмірін тексеру"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Барлығын көру"),
        "viewDetails": MessageLookupByLibrary.simpleMessage(
            "Толтырылған мәліметтерді көру"),
        "walkInCustomer": MessageLookupByLibrary.simpleMessage("Шаққан клиент"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Қойма"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Сақтау қоймасы бұрыннан бар"),
        "warehouseList":
            MessageLookupByLibrary.simpleMessage("Сақтау қоймалары тізімі"),
        "warehouseName":
            MessageLookupByLibrary.simpleMessage("Сақтау қоймасының атауы"),
        "warranty": MessageLookupByLibrary.simpleMessage("Кепілдік"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Біз инструкциялармен құпия сөзді қалпына келтіру туралы хат жібердік:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Біздің қолданбамыздың функционалдылығын қолдау үшін аналитика ұсынышшылары мен төлемшілерді қамтамасыз ететін жасырын қызметтерді пайдалануымыз мүмкін. Олар жасау қызметтерімізді пайдаланыңызда сіз туралы ақпаратты жинауы мүмкін. Олардың жеке жаңарту әдістеріне жауапты емес екенімізді ескертіңіз."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Біз жеке ақпараттың қорғауы үшін көрсетілушы стандартты жағдайды қабылдамыз, оның ішінде шифрлау және қауіпсіз сақтау да бар. Сіздің ақпараттыңызға тек белсенді жеке адамдардың қол жеткізуі болып табуымыз керек."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Сіздің операциялардың себебін анықтауға білеміз. Осы себепті, күн сайын кешікті қойынша қолдау қол жетімді болады, бірақ ұсынысты сұрау немесе жоспарлы мәселе болса да. Бізбен кез келген уақытта, жерден жерге қоңырау немесе WhatsApp арқылы байланыс алып, ең өтіріксіз қолдау қызметін таңдаңыз."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Біз сіздің жеке ақпараттызды қосымша басымды тұрмысыздар арқылы сізге ең жақсы жолда беру үшін пайдаланамыз, міндетті сіздің мазмұн алғысын қосу, сізді эксперттермен байлау және біздің қолданбанымызды жақсарту. Біз сізді мазмұн алғысына жолдамасу, жаңартуларды, өнімдерді жаңартуларды немесе біздің қолданбамызға байланысты жаңартуларды сізге хабарлау үшін сіздің ақпаратты пайдалануымызға арналған болуымызға пайдаланамыз."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Біз төлемді қарап, 1-2 сағат ішінде мақұлдаймыз"),
        "weekly": MessageLookupByLibrary.simpleMessage("Апта сайын"),
        "weight": MessageLookupByLibrary.simpleMessage("Салмақ"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Не жаңа"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Оптовик"),
        "wholeSalePrice": MessageLookupByLibrary.simpleMessage("Опт бағасы"),
        "wholesalePrice":
            MessageLookupByLibrary.simpleMessage("Жабдықтау бағасы"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Жабдықтаушы"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Жақын арада қосылады"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Аяқталу уақыты"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Хабарды осында жазыңыз"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("Қате OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Осы пайдаланушы үшін дұрыс емес құпия сөз көрсетілді."),
        "yearly": MessageLookupByLibrary.simpleMessage("Жылдық"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Иә, шынымен жою"),
        "youAreNotAValidUser": MessageLookupByLibrary.simpleMessage(
            "Сіз жарамды пайдаланушы емессіз"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Сіз пайдалануда"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Сіз төлемнен көп төлей алмайсыз"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Сізге хат келді"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Сіз сәтті тұрып, аккаунтыңызға кірдіңіз. Pos Saas менімен болыңыз."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("Сіз рұқсат беруге тиіссіз"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Сіздің аккаунтыңызға қайта кіру қажет."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Сіз сатып алу алдын келесі тексеруді өткізуіңіз керек"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Сіздің хабарыңыз қалыпты"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Сіздің пакетіңіз"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Сіздің пакетіңіз 5 күнден кейін аяқталады")
      };
}
