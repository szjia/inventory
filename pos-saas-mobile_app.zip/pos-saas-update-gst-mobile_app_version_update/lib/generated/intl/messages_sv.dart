// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a sv locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'sv';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Fortsätt"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("GST-nummer"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage(
            "Pris rekommenderat av tillverkare"),
        "MRPIsRequired": MessageLookupByLibrary.simpleMessage("MRP krävs"),
        "OK": MessageLookupByLibrary.simpleMessage("OK"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Tfn.nr"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT-kod"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Snacks"),
        "TAX": MessageLookupByLibrary.simpleMessage("SKATT"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Laddar upp"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("Användartitel"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Ditt paket kommer att löpa ut idag\n\nVänligen köp igen"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) Systemet tillhandahålls enbart för att underlätta försäljningstransaktioner och relaterade aktiviteter i din verksamhet."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) För att använda Systemet kan det vara nödvändigt att skapa ett konto. Du samtycker till att lämna korrekt, aktuell och fullständig information under registreringsprocessen och att uppdatera sådan information för att hålla den korrekt och fullständig."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("Om appen"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Om oss"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Acceptans av villkor"),
        "accountName": MessageLookupByLibrary.simpleMessage("Kontonamn"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("Kontonummer"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Registrering av konto"),
        "acton": MessageLookupByLibrary.simpleMessage("Åtgärd"),
        "add": MessageLookupByLibrary.simpleMessage("Lägg till"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Lägg till varumärke"),
        "addCategory":
            MessageLookupByLibrary.simpleMessage("Lägg till kategori"),
        "addContact": MessageLookupByLibrary.simpleMessage("Lägg till kontakt"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Lägg till kund"),
        "addDelivery":
            MessageLookupByLibrary.simpleMessage("Lägg till leverans"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Lägg till beskrivning"),
        "addDescription":
            MessageLookupByLibrary.simpleMessage("Lägg till anteckning"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Lägg till rabatt"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Lägg till Dokument-ID"),
        "addDucument":
            MessageLookupByLibrary.simpleMessage("Lägg till dokument"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Lägg till utgift"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Lägg till utgiftskategori"),
        "addItems": MessageLookupByLibrary.simpleMessage("Lägg till artiklar"),
        "addNew": MessageLookupByLibrary.simpleMessage("Lägg till ny"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Lägg till ny adress"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Lägg till ny produkt"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("Lägg till ny skatt"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Lägg till ny skatt med enstaka/flertal skatte typer"),
        "addNote": MessageLookupByLibrary.simpleMessage("Lägg till anteckning"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Lägg till produkt först"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Lägg till kampanjkod"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Lägg till inköp"),
        "addSales":
            MessageLookupByLibrary.simpleMessage("Lägg till försäljning"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Tillagd framgångsrikt"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Lägg till enhet"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Lägg till användarroll"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Tillagd framgångsrikt"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("Tillagd i kundvagnen"),
        "address": MessageLookupByLibrary.simpleMessage("Adress"),
        "admin": MessageLookupByLibrary.simpleMessage("Admin"),
        "all": MessageLookupByLibrary.simpleMessage("Alla"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("Alla affärslösningar"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("Redan tillagd"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Finns redan"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Har redan ett konto"),
        "amount": MessageLookupByLibrary.simpleMessage("Belopp"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "Ett e-postmeddelande har skickats\\nKontrollera din inkorg"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Stöd för Android- och iOS-appar"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Tillämplig skatt"),
        "apply": MessageLookupByLibrary.simpleMessage("Tillämpa"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Är du säker på att du vill ta bort denna faktura?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Är du säker på att du vill ta bort denna försäljning?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Är du säker på att du vill radera den här användaren?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Är du säker på att du vill ta bort denna skatt?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Är du säker på att du vill ta bort denna skattegrupp?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Vill du ta bort detta lager?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Är du säker på att du vill ta bort den här användaren?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Auktoriserad signatur"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Du är ansvarig för att upprätthålla konfidentialiteten för ditt konto och lösenord samt för att begränsa åtkomsten till ditt konto. Du accepterar ansvaret för alla aktiviteter som sker under ditt konto."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Du måste vara minst 18 år gammal eller ha nått myndighetsåldern enligt din jurisdiktion för att använda Systemet."),
        "backSide": MessageLookupByLibrary.simpleMessage("Baksida"),
        "backToHome":
            MessageLookupByLibrary.simpleMessage("Tillbaka till startsidan"),
        "balance": MessageLookupByLibrary.simpleMessage("Saldo"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladesh"),
        "bank": MessageLookupByLibrary.simpleMessage("Bank"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Valuta för bankkonto"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Bankens kontovaluta"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Bankinformation"),
        "bankName": MessageLookupByLibrary.simpleMessage("Bankens namn"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("Banköverföring"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Streckkod hittad"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Räkning/Faktura"),
        "billTo": MessageLookupByLibrary.simpleMessage("Fakturera till"),
        "branchName": MessageLookupByLibrary.simpleMessage("Filialnamn"),
        "brand": MessageLookupByLibrary.simpleMessage("Varumärke"),
        "brandName": MessageLookupByLibrary.simpleMessage("Varumärkesnamn"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("Massuppladdning"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Företagskategori"),
        "buy": MessageLookupByLibrary.simpleMessage("Köp"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Köp Premiumplan"),
        "buySms": MessageLookupByLibrary.simpleMessage("Köp sms"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Genom att få tillgång till eller använda Point of Sale (POS) Systemet (\"Systemet\") tillhandahållet av [Ditt Företagsnamn] (\"Företaget\"), samtycker du till att vara bunden av dessa Användarvillkor. Om du inte godkänner dessa Användarvillkor, använd inte Systemet."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Du är ansvarig för att säkerställa att din åtkomst till och användning av Systemet följer alla tillämpliga lagar och föreskrifter."),
        "cacel": MessageLookupByLibrary.simpleMessage("Avbryt"),
        "call": MessageLookupByLibrary.simpleMessage("Ring"),
        "callForEmergencySupport":
            MessageLookupByLibrary.simpleMessage("Ring för nödhjälp"),
        "camera": MessageLookupByLibrary.simpleMessage("Kamera"),
        "cancel": MessageLookupByLibrary.simpleMessage("Avbryt"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Avbryt alla produkter"),
        "capacity": MessageLookupByLibrary.simpleMessage("Kapacitet"),
        "card": MessageLookupByLibrary.simpleMessage("Kort"),
        "cash": MessageLookupByLibrary.simpleMessage("Kontant"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Kategorier"),
        "category": MessageLookupByLibrary.simpleMessage("Kategori"),
        "categoryName": MessageLookupByLibrary.simpleMessage("Kategori namn"),
        "categoryNameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Kategori namn finns redan"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("Kategorinamn"),
        "change": MessageLookupByLibrary.simpleMessage("Ändra?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Ändra lösenord"),
        "checkEmail":
            MessageLookupByLibrary.simpleMessage("Kontrollera e-posten"),
        "choseACustomer": MessageLookupByLibrary.simpleMessage("Välj en kund"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Välj en leverantör"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Välj dina funktioner"),
        "clarence": MessageLookupByLibrary.simpleMessage("Klarering"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Klicka för att ansluta"),
        "close": MessageLookupByLibrary.simpleMessage("Stäng"),
        "color": MessageLookupByLibrary.simpleMessage("Färg"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(Kombination av flera skatter)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Kommer snart"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Företagsadress"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Företags- & Butiksnamn"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("Företagsnamn"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Slutför Transaktion"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Bekräfta lösenord"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Bekräfta återvändande"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Grattis"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Kontakta oss"),
        "continu": MessageLookupByLibrary.simpleMessage("Fortsätt"),
        "country": MessageLookupByLibrary.simpleMessage("Land"),
        "create": MessageLookupByLibrary.simpleMessage("Skapa"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Skapa ett gratis konto"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Skapad och sparad"),
        "currency": MessageLookupByLibrary.simpleMessage("Valuta"),
        "currentStock":
            MessageLookupByLibrary.simpleMessage("Aktuell Lagerbeholding"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("Anpassad fakturabranding"),
        "customer": MessageLookupByLibrary.simpleMessage("Kund"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Kundinformation"),
        "customerGST": MessageLookupByLibrary.simpleMessage("Kundens GST"),
        "customerName": MessageLookupByLibrary.simpleMessage("Kundnamn"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Dagliga transaktioner"),
        "dashBoardOverView": MessageLookupByLibrary.simpleMessage(
            "Översikt av instrumentpanelen"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Data sparad framgångsrikt"),
        "date": MessageLookupByLibrary.simpleMessage("Datum"),
        "day": MessageLookupByLibrary.simpleMessage("Dag"),
        "dealer": MessageLookupByLibrary.simpleMessage("Återförsäljare"),
        "dealerPrice":
            MessageLookupByLibrary.simpleMessage("Återförsäljarpris"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("Standard momsprocent"),
        "delete": MessageLookupByLibrary.simpleMessage("Radera"),
        "deleting": MessageLookupByLibrary.simpleMessage("Tar bort"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Leveransadress"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Leveransadresser"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Leveranskostnad"),
        "describtion": MessageLookupByLibrary.simpleMessage("Beskrivning"),
        "description": MessageLookupByLibrary.simpleMessage("Beskrivning"),
        "descriptionCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Beskrivningen kan inte vara tom"),
        "details": MessageLookupByLibrary.simpleMessage("Detaljer"),
        "discount": MessageLookupByLibrary.simpleMessage("Rabatt"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Stör ej"),
        "done": MessageLookupByLibrary.simpleMessage("Klar"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Ladda ner Excel-format"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Nedladdad framgångsrikt i nedladdningsmappen"),
        "due": MessageLookupByLibrary.simpleMessage("Förfallen"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Förfallet belopp: "),
        "dueCollection":
            MessageLookupByLibrary.simpleMessage("Förfallna belopp insamlade"),
        "dueCollectionReports": MessageLookupByLibrary.simpleMessage(
            "Rapporter om förfallna betalningar"),
        "dueList": MessageLookupByLibrary.simpleMessage(
            "Förteckning över förfallna belopp"),
        "dueReports": MessageLookupByLibrary.simpleMessage("Skuldrapport"),
        "duration": MessageLookupByLibrary.simpleMessage("Varaktighet"),
        "durationFrom":
            MessageLookupByLibrary.simpleMessage("Varaktighet: Från"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "Enkelt att använda mobil POS"),
        "edit": MessageLookupByLibrary.simpleMessage("Redigera"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Redigera inköpsfaktura"),
        "editSalesInvoice": MessageLookupByLibrary.simpleMessage(
            "Redigera försäljningsfaktura"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Redigera sociala medier"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Redigering lyckades"),
        "editTax": MessageLookupByLibrary.simpleMessage("Redigera skatt"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Redigera skattegrupp"),
        "editWarehouse": MessageLookupByLibrary.simpleMessage("Redigera lager"),
        "email": MessageLookupByLibrary.simpleMessage("E-post"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("E-postadress"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("E-post kan inte vara tom"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "E-post skickad! Kolla din inkorg"),
        "endDate": MessageLookupByLibrary.simpleMessage("Slutdatum"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Ange ett giltigt belopp"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Ange en giltig rabatt"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Ange ett giltigt telefonnummer"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Ange ett giltigt pris"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("Ange en giltig kvantitet"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("Ange adress"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("Ange belopp."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Ange varumärkesnamn"),
        "enterCapacity": MessageLookupByLibrary.simpleMessage("Ange kapacitet"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Ange kategorinamn"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Ange färg"),
        "enterCustomerGstNumber":
            MessageLookupByLibrary.simpleMessage("Ange kundens GST-nummer"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Ange återförsäljarpris"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Ange beskrivning"),
        "enterDiscount": MessageLookupByLibrary.simpleMessage("Ange rabatt."),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Ange utgiftdatum"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Ange fullständig adress"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Ange fakturanummer"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Ange låg lager varningskvantitet"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Ange tillverkare"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("Ange meddelandeinnehåll"),
        "enterMrpOrRetailerPirce":
            MessageLookupByLibrary.simpleMessage("Ange MRP/Återförsäljarpris"),
        "enterName": MessageLookupByLibrary.simpleMessage("Ange namn"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Ange anteckning"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Ange partinamn"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Ange telefonnummer"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Ange produktkod eller skanna"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Ange produktnamn"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Ange inköpspris."),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("Ange referensnummer"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Ange storlek"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("Ange lager."),
        "enterTaxRate": MessageLookupByLibrary.simpleMessage("Ange skattesats"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("Ange transaktions-ID"),
        "enterType": MessageLookupByLibrary.simpleMessage("Ange typ"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("Ange användartitel"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Ange giltigt belopp"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Ange lagernamn"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Ange vikt"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Ange återförsäljarpris"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("Ange din beskrivning här"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("Ange din e-postadress"),
        "enterYourFeedBackTitle":
            MessageLookupByLibrary.simpleMessage("Ange din feedback-titel"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Ange ditt GST-nummer"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("Ange ditt mobilnummer"),
        "enterYourName": MessageLookupByLibrary.simpleMessage("Ange ditt namn"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("Ange ditt telefonnummer"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Ange ditt lösenord"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Ange ditt telefonnummer"),
        "enterYourTransactionId":
            MessageLookupByLibrary.simpleMessage("Ange din transaktions-ID"),
        "error": MessageLookupByLibrary.simpleMessage("Fel"),
        "excTax": MessageLookupByLibrary.simpleMessage("Exkl. skatt"),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("Excel uppladdare"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Exklusive"),
        "expense": MessageLookupByLibrary.simpleMessage("Kostnad"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Utgiftskategori"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Utgiftdatum"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Utgift för"),
        "expenseReport": MessageLookupByLibrary.simpleMessage("Utgiftsrapport"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Utgångsdatum"),
        "expired": MessageLookupByLibrary.simpleMessage("Upphörd"),
        "expiring": MessageLookupByLibrary.simpleMessage("Upphör"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Misslyckades med fel"),
        "fashion": MessageLookupByLibrary.simpleMessage("Mode"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Funktioner är den viktiga delen som gör Pos Saas annorlunda än traditionella lösningar."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Feedback"),
        "firstName": MessageLookupByLibrary.simpleMessage("Förnamn"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Följ oss på\\nFacebook"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Följ oss på\\nTwitter"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Framsida"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("För obegränsad användning"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Glömt lösenord"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Glömt lösenordet?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Från datum"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("Gratis dataskyddskopia"),
        "freeLifeTimeUpdate":
            MessageLookupByLibrary.simpleMessage("Gratis livstidsuppdatering"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Gratis Paket"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Gratis Plan"),
        "from": MessageLookupByLibrary.simpleMessage("(Från"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Helt betald"),
        "gallary": MessageLookupByLibrary.simpleMessage("Galleri"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("Genererar PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Få OTP"),
        "govermentId": MessageLookupByLibrary.simpleMessage("Regerings-ID"),
        "guest": MessageLookupByLibrary.simpleMessage("Gäst"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Har du inget konto?"),
        "history": MessageLookupByLibrary.simpleMessage("Historik"),
        "home": MessageLookupByLibrary.simpleMessage("Hem"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Hur vi skyddar din information"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Hur vi använder din information"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Verifiera identitet"),
        "image": MessageLookupByLibrary.simpleMessage("Bild"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("InHouse kan inte tas bort"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("InHouse kan inte redigeras"),
        "inWord": MessageLookupByLibrary.simpleMessage("I ord"),
        "incTax": MessageLookupByLibrary.simpleMessage("Inkl. skatt"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Inklusive"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("Öka lager"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Instrument"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Fakturanr."),
        "invoice": MessageLookupByLibrary.simpleMessage("Faktura"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("Fakturanummer"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Fakturainställning"),
        "invoiceViewer": MessageLookupByLibrary.simpleMessage("Faktura visare"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Artikel tillagd"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("KYC-verifiering"),
        "language": MessageLookupByLibrary.simpleMessage("Språk"),
        "lastName": MessageLookupByLibrary.simpleMessage("Efternamn"),
        "ledger": MessageLookupByLibrary.simpleMessage("Huvudbok"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Livstids\nKöp"),
        "link": MessageLookupByLibrary.simpleMessage("Länk"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Live chat support"),
        "loading": MessageLookupByLibrary.simpleMessage("Laddar"),
        "logIn": MessageLookupByLibrary.simpleMessage("Logga in"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Logga ut"),
        "logOut": MessageLookupByLibrary.simpleMessage("Logga ut"),
        "login": MessageLookupByLibrary.simpleMessage("Logga in"),
        "logo": MessageLookupByLibrary.simpleMessage("Logotyp"),
        "loss": MessageLookupByLibrary.simpleMessage("Förlust"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Förlust/Vinst"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Detaljerad förlust/vinst"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Förlust/Vinst rapport"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Förlust/Vinst rapporter"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Låg lager varning"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Gör ett varaktigt intryck på dina kunder med varumärkta fakturor. Vår Unlimited Upgrade erbjuder den unika fördelen att anpassa dina fakturor, lägga till en professionell touch som stärker ditt varumärkesidentitet och främjar kundlojalitet."),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("Hantera ditt företag med "),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Tillverkningsdatum"),
        "margin": MessageLookupByLibrary.simpleMessage("Marginal"),
        "masterCard": MessageLookupByLibrary.simpleMessage("Mastercard"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Tillverkare"),
        "message": MessageLookupByLibrary.simpleMessage("Meddelande"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Meddelandehistorik"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Pos Saas-appen är gratis, lätt att använda. Faktum är att det är ett av de bästa POS-systemen i världen."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas är en komplett affärslösning med lager, konto, försäljning, kostnad och förlust/vinst."),
        "mobile": MessageLookupByLibrary.simpleMessage("Mobil"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("Mobilbetalning"),
        "monthly": MessageLookupByLibrary.simpleMessage("Månadsvis"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("Mer information"),
        "name": MessageLookupByLibrary.simpleMessage("Ange ditt namn."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Namnet finns redan"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("Namnet kan inte vara tomt"),
        "next": MessageLookupByLibrary.simpleMessage("Nästa"),
        "noConnection":
            MessageLookupByLibrary.simpleMessage("Ingen anslutning"),
        "noData": MessageLookupByLibrary.simpleMessage("Ingen Data"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Ingen data tillgänglig"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Ingen data hittades"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("Ingen historik hittades!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Ingen produkt hittad"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("Ingen underkategori vald"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("Ingen transaktion hittades!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Ingen användare hittades med den e-postadressen."),
        "noUserRoleFound":
            MessageLookupByLibrary.simpleMessage("Ingen användarroll hittades"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Inte aktiv användare"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Ej angivet"),
        "note": MessageLookupByLibrary.simpleMessage("Anteckning"),
        "notes": MessageLookupByLibrary.simpleMessage("Anteckningar"),
        "notification": MessageLookupByLibrary.simpleMessage("Notifiering"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP skickad till"),
        "office": MessageLookupByLibrary.simpleMessage("Kontor"),
        "ok": MessageLookupByLibrary.simpleMessage("OK"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS som innehåller en mängd funktioner, inklusive försäljningsövervakning och lagerhantering."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Detta system hjälper dig att förbättra dina operationer för dina kunder."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Vårt POS-system bör förenkla dagliga operationer automatiskt och göra det lätt att navigera."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("Ingående balans"),
        "order": MessageLookupByLibrary.simpleMessage("Beställningar"),
        "other": MessageLookupByLibrary.simpleMessage("Övrigt"),
        "otp": MessageLookupByLibrary.simpleMessage("Stäng"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Slut i lager"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Paket"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Paketfunktioner"),
        "paid": MessageLookupByLibrary.simpleMessage("Betalat"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Betalt belopp"),
        "parties": MessageLookupByLibrary.simpleMessage("Parter"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Partilista"),
        "partyGST": MessageLookupByLibrary.simpleMessage("Parti GST"),
        "partyName": MessageLookupByLibrary.simpleMessage("Partinamn"),
        "password": MessageLookupByLibrary.simpleMessage("Lösenord"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Lösenord och bekräfta lösenord stämmer inte överens"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Lösenord kan inte vara tomt"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("Lösenordet matchar inte"),
        "payCash": MessageLookupByLibrary.simpleMessage("Betala kontant"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("Betala med bkash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Betala med Paypal"),
        "payeeName": MessageLookupByLibrary.simpleMessage("Mottagarens Namn"),
        "payeeNumber":
            MessageLookupByLibrary.simpleMessage("Mottagarens Nummer"),
        "payment": MessageLookupByLibrary.simpleMessage("Betalning"),
        "paymentAmount":
            MessageLookupByLibrary.simpleMessage("Betalningsbelopp"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Betalning genomförd"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Betalningsinstruktion:"),
        "paymentMethod":
            MessageLookupByLibrary.simpleMessage("Betalningsmetod"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Betalningstyp"),
        "pdfView": MessageLookupByLibrary.simpleMessage("PDF-vy"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Personlig information"),
        "phone": MessageLookupByLibrary.simpleMessage("Telefon"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Telefonnummer"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Telefonnummer har redan använts"),
        "phoneNumberIsNotValid": MessageLookupByLibrary.simpleMessage(
            "Telefonnumret är inte giltigt"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("Telefonnummer krävs"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("Välj och ladda upp fil"),
        "pickEndDate": MessageLookupByLibrary.simpleMessage("Välj slutdatum"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Välj startdatum"),
        "plan": MessageLookupByLibrary.simpleMessage("Plan"),
        "pleaseAddQuantity": MessageLookupByLibrary.simpleMessage(
            "Vänligen lägg till kvantitet"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Kontrollera din internetanslutning"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Vänligen koppla in skrivaren först"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Anslut din Bluetooth-skrivare, vänligen"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Vänligen ange ett längre lösenord"),
        "pleaseEnterAConfirmPassword":
            MessageLookupByLibrary.simpleMessage("Ange ett bekräftat lösenord"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("Ange ett lösenord"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Vänligen ange en giltig e-postadress"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Vänligen ange namn"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("Ange lösenord"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Ange din e-postadress nedan för att ta emot en länk för återställning av lösenord."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Vänligen ange transaktionsnummer"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("Vänligen ange belopp"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Vänligen välj en kategori först"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("Vänligen välj en plan"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Vänligen välj företagskategori"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Vänligen använd giltig inköpskod för att använda appen"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Drivs av Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Drivs av"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Premium kundsupport"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Premiumplan"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Tidigare betalda belopp"),
        "price": MessageLookupByLibrary.simpleMessage("pris"),
        "print": MessageLookupByLibrary.simpleMessage("Skriv ut"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Utskriftsalternativ"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Integritetspolicy"),
        "product": MessageLookupByLibrary.simpleMessage("Produkt"),
        "productCode": MessageLookupByLibrary.simpleMessage("Produktkod"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("Produktkod krävs"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Produktkod/Namn"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Produktbeskrivning"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Produktinformation"),
        "productList": MessageLookupByLibrary.simpleMessage("Produktlista"),
        "productName": MessageLookupByLibrary.simpleMessage("Produktnamn"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Produktnamn finns redan i detta lager"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Produktnamn är redan tillagt"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("Produktnamn krävs"),
        "products": MessageLookupByLibrary.simpleMessage("Produkter"),
        "profile": MessageLookupByLibrary.simpleMessage("Profil"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("Redigera profil"),
        "profit": MessageLookupByLibrary.simpleMessage("Vinst"),
        "promo": MessageLookupByLibrary.simpleMessage("Reklam"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Kampanjkod"),
        "purchase": MessageLookupByLibrary.simpleMessage("Inköp"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage("Inköpslarm"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Köp bekräftat"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Inköpsdetaljer"),
        "purchaseInvoice": MessageLookupByLibrary.simpleMessage("Köpfaktura"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("Inköpslista"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Köp nu"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Köp Premiumplan"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("Inköpspris"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("Inköpspris krävs"),
        "purchaseRepoet": MessageLookupByLibrary.simpleMessage("Inköpsrapport"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Inköpsrapport"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Inköprapporter"),
        "purchaseReturn": MessageLookupByLibrary.simpleMessage("Köpbegäran"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("Köpbegärans rapport"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Köpövergång"),
        "qty": MessageLookupByLibrary.simpleMessage("Antal"),
        "quantity": MessageLookupByLibrary.simpleMessage("Kvantitet"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Senaste transaktioner"),
        "recivedThePin": MessageLookupByLibrary.simpleMessage("Mottog PIN-kod"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Referensnummer"),
        "register": MessageLookupByLibrary.simpleMessage("Registrera"),
        "registering": MessageLookupByLibrary.simpleMessage("Registrerar"),
        "remainingDue":
            MessageLookupByLibrary.simpleMessage("Återstående förfall"),
        "remove": MessageLookupByLibrary.simpleMessage("Ta bort"),
        "reports": MessageLookupByLibrary.simpleMessage("Rapporter"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Begäran har skickats"),
        "resendCode": MessageLookupByLibrary.simpleMessage("Skicka kod igen"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("Skicka OTP igen: "),
        "retailer": MessageLookupByLibrary.simpleMessage("Återförsäljare"),
        "retur": MessageLookupByLibrary.simpleMessage("Retur"),
        "returN": MessageLookupByLibrary.simpleMessage("Återvända"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("Retur Belopp"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("Retur Belopp"),
        "returnQTY":
            MessageLookupByLibrary.simpleMessage("Återvändande kvantitet"),
        "revenue": MessageLookupByLibrary.simpleMessage("Intäkter"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Skydda dina affärsdata problemfritt. Vår Pos Saas POS Unlimited Upgrade inkluderar gratis dataskyddskopia och säkerställer att din värdefulla information skyddas mot oväntade händelser. Fokusera på det som verkligen betyder något - din företagstillväxt."),
        "saleAmount":
            MessageLookupByLibrary.simpleMessage("Försäljningsbelopp"),
        "saleDetails":
            MessageLookupByLibrary.simpleMessage("Försäljningsdetaljer"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Försäljningspris"),
        "saleReports":
            MessageLookupByLibrary.simpleMessage("Försäljningsrapport"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Försäljningsrapporter"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("Försäljningsretur"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Försäljningsretur rapport"),
        "saleSetting":
            MessageLookupByLibrary.simpleMessage("Försäljningsinställning"),
        "sales": MessageLookupByLibrary.simpleMessage("Försäljning"),
        "salesAndPurchaseReports": MessageLookupByLibrary.simpleMessage(
            "Försäljnings- och inköprapporter"),
        "salesList": MessageLookupByLibrary.simpleMessage("Försäljningslista"),
        "salesReturn":
            MessageLookupByLibrary.simpleMessage("Försäljningsretur"),
        "save": MessageLookupByLibrary.simpleMessage("Spara"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Spara och publicera"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("Spara ändringar"),
        "saving": MessageLookupByLibrary.simpleMessage("Sparar"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("Skanna produktens QR-kod"),
        "search": MessageLookupByLibrary.simpleMessage("Sök"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Sök med produktkod eller namn"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("Se alla kampanjkoder"),
        "select": MessageLookupByLibrary.simpleMessage("Välj"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Välj en produkt för återvändande"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Välj märke"),
        "selectCategory": MessageLookupByLibrary.simpleMessage("Välj kategori"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Välj kontakter"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("Välj produktkategori"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("Välj butiks kategori"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Välj skatt"),
        "selectTaxType": MessageLookupByLibrary.simpleMessage("Välj skattetyp"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("Välj enhet"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Välj variation: "),
        "seller": MessageLookupByLibrary.simpleMessage("Säljare"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Såld av"),
        "send": MessageLookupByLibrary.simpleMessage("Skicka"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("Skicka e-post"),
        "sendMessage":
            MessageLookupByLibrary.simpleMessage("Skicka meddelande"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("Skicka återställningslänk"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Skicka SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Skicka sms?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Skicka WhatsApp-meddelande"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Skicka din e-post"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage("Skickar e-post"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Skickar meddelande"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Service/Frakt"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Ställ in din profil"),
        "setting": MessageLookupByLibrary.simpleMessage("Inställningar"),
        "share": MessageLookupByLibrary.simpleMessage("Dela"),
        "shopGST": MessageLookupByLibrary.simpleMessage("Butik GST"),
        "signIn": MessageLookupByLibrary.simpleMessage("Logga in"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("Logga in med e-post"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Kundens signatur"),
        "size": MessageLookupByLibrary.simpleMessage("Storlek"),
        "skip": MessageLookupByLibrary.simpleMessage("Hoppa över"),
        "sms": MessageLookupByLibrary.simpleMessage("Sms"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Social marknadsföring"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Tyvärr har du ingen behörighet att få åtkomst till denna tjänst"),
        "startDate": MessageLookupByLibrary.simpleMessage("Startdatum"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Börja ny försäljning"),
        "startTypingToSearch":
            MessageLookupByLibrary.simpleMessage("Börja skriva för att söka"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Håll dig i framkant av teknologiska framsteg utan extra kostnader. Vår Pos Saas POS Unlimited Upgrade ser till att du alltid har de senaste verktygen och funktionerna inom rånvidd, och garanterar att din verksamhet förblir toppmodern."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("Ännu obetald"),
        "stock": MessageLookupByLibrary.simpleMessage("Lager"),
        "stockIsRequired": MessageLookupByLibrary.simpleMessage("Lager krävs"),
        "stockList": MessageLookupByLibrary.simpleMessage("Lagerlista"),
        "stocks": MessageLookupByLibrary.simpleMessage("Lager"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Lagringsbehörighet krävs för att skapa Excel-fil"),
        "subTaxList":
            MessageLookupByLibrary.simpleMessage("Lista över underkatter"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Underkatter"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Delsumma"),
        "submit": MessageLookupByLibrary.simpleMessage("Skicka"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "Prenumerera på vår\\nYouTube"),
        "subscription": MessageLookupByLibrary.simpleMessage("Prenumeration"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Framgångsrikt utfört"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Framgångsrikt utloggad"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Uppdatering lyckades"),
        "supplier": MessageLookupByLibrary.simpleMessage("Leverantör"),
        "supplierName": MessageLookupByLibrary.simpleMessage("Leverantörsnamn"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT-kod"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Ta en körkort, nationellt ID-kort eller passfoto"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "Ta med ett ID-kort för att kontrollera din information"),
        "tap": MessageLookupByLibrary.simpleMessage("Tryck"),
        "tax": MessageLookupByLibrary.simpleMessage("Skatt"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Skattegrupp"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("Skatteprocent"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Skattesats"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Skattesatser - Hantera dina skattesatser"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Skatterapport"),
        "taxType": MessageLookupByLibrary.simpleMessage("Skattetyp"),
        "taxes": MessageLookupByLibrary.simpleMessage("Skatter"),
        "termsAndConditions": MessageLookupByLibrary.simpleMessage("Villkor"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("Användarvillkor"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Villkor & Integritet"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Tack för din förfallna betalning"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Tack"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Tack för ditt köp"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "Kontot finns redan för den e-postadressen"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Excel-filen har redan laddats ner"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Namnet säger allt. Med Pos Saas POS Unlimited finns det ingen begränsning för din användning. Oavsett om du behandlar en handfull transaktioner eller möter en rusning av kunder kan du arbeta med förtroende och veta att du inte är begränsad av gränser."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "Det angivna lösenordet är för svagt"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Försäljningen kommer att tas bort och all data om detta köp kommer att tas bort. Är du säker på att du vill ta bort detta?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Försäljningen kommer att tas bort och all data om denna försäljning kommer att tas bort. Är du säker på att du vill ta bort detta?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Användaren kommer att tas bort och all data kommer att tas bort från ditt konto. Är du säker på att du vill ta bort detta?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Användaren kommer att raderas och all data kommer att raderas från ditt konto. Är du säker på att du vill radera detta?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Tredjepartstjänster"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Denna kategori kan inte tas bort"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Denna månad)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Denna produkt är redan tillagd"),
        "title": MessageLookupByLibrary.simpleMessage("Rubrik"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Titeln kan inte vara tom"),
        "to": MessageLookupByLibrary.simpleMessage("till"),
        "toDate": MessageLookupByLibrary.simpleMessage("Till datum"),
        "today": MessageLookupByLibrary.simpleMessage("Idag"),
        "total": MessageLookupByLibrary.simpleMessage("Totalt"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Totalt belopp"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Totalt insamlat"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Totalt förfall"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("Total utgift"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Totala förluster"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("Totalt att betala"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Totalt pris"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("Totala produkter"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Totala vinster"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("Total inköp"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Totalt återbetalningsbelopp"),
        "totalReturns":
            MessageLookupByLibrary.simpleMessage("Totala återvändanden"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Total försäljning"),
        "totalStock":
            MessageLookupByLibrary.simpleMessage("Total Lagerbeholding"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Totalt värde"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Total moms"),
        "totals": MessageLookupByLibrary.simpleMessage("Totalt: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Transaktion"),
        "transactionId":
            MessageLookupByLibrary.simpleMessage("Transaktions-ID"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Försök igen"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Typ"),
        "unitName": MessageLookupByLibrary.simpleMessage("Enhetens namn"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Enhetspris"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Enhetspris"),
        "units": MessageLookupByLibrary.simpleMessage("Enheter"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Obegränsad"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Obegränsad användning"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Lås upp hela potentialen i Pos Saas POS med personliga träningspass ledda av vårt expertteam. Från grunderna till avancerade tekniker ser vi till att du är väl förtrogen med att utnyttja varje del av systemet för att optimera dina affärsprocesser."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Obetald"),
        "update": MessageLookupByLibrary.simpleMessage("Uppdatera"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Uppdatera kontakt"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Uppdatera nu"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("Uppdatera produkt"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Uppdatera din plan först, din gräns är över"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Uppdatera din profil"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Uppdatera din profil för att ansluta din läkare med ett bättre intryck"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Uppdatera din profil för att koppla samman med kunden med bättre intryck"),
        "updated": MessageLookupByLibrary.simpleMessage("Uppdaterad"),
        "upload": MessageLookupByLibrary.simpleMessage("Ladda upp"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Ladda upp dokument"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("Uppladdning klar"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Ladda upp fil"),
        "upplier": MessageLookupByLibrary.simpleMessage("Leverantör"),
        "usbC": MessageLookupByLibrary.simpleMessage("USB C"),
        "use": MessageLookupByLibrary.simpleMessage("Använd"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("Använd Pos Saas"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Användning av systemet"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Användaren är raderad"),
        "userRole": MessageLookupByLibrary.simpleMessage("Användarroll"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("Detaljer om användarroll"),
        "userTitle": MessageLookupByLibrary.simpleMessage("Användartitel"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Användartitel kan inte vara tom"),
        "value": MessageLookupByLibrary.simpleMessage("Värde"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("Moms gäller inte"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("Verifierar OTP"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Verifiera telefonnummer"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Visa alla"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("Visa detaljer"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Kund som går in"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Lager"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Lager finns redan"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("Lagerlista"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("Lager namn"),
        "warranty": MessageLookupByLibrary.simpleMessage("Garanti"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Vi har skickat ett e-postmeddelande med instruktioner om hur du återställer lösenord till:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Vi kan använda tredjepartstjänster för att stödja appens funktionalitet, som analytikaprovajderare och betalningsbehandlare. Dessa tredjepartstjänster kan samla in information om dig när du använder vår app. Observera att vi inte är ansvariga för integritetspraxis hos dessa tredjepartstjänster."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Vi vidtar branschstandardåtgärder för att skydda din personliga information, inklusive kryptering och säker lagring. Vi begränsar även åtkomsten till din information endast för behörig personal."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Vi förstår vikten av sömlös drift. Därför finns vår support tillgänglig dygnet runt för att hjälpa dig, oavsett om det är en snabb fråga eller ett omfattande problem. Anslut med oss när som helst, var som helst via samtal eller WhatsApp för att uppleva en oöverträffad kundtjänst."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Vi använder din personliga information för att ge dig den bästa möjliga upplevelsen i vår app, inklusive att anpassa dina rekommendationer av innehåll, koppla dig till experter och förbättra appens funktionalitet. Vi kan också använda din information för att kommunicera med dig om uppdateringar, kampanjer eller annan information relaterad till vår app."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Vi kommer att granska betalningen och godkänna den inom 1-2 timmar"),
        "weekly": MessageLookupByLibrary.simpleMessage("Veckovis"),
        "weight": MessageLookupByLibrary.simpleMessage("Vikt"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Vad är nytt"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Återförsäljare"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Återförsäljarpris"),
        "wholesalePrice":
            MessageLookupByLibrary.simpleMessage("Partihandelspris"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Partihandlare"),
        "willBeAddedSoon": MessageLookupByLibrary.simpleMessage(
            "Kommer snart att läggas till"),
        "willExpireAt":
            MessageLookupByLibrary.simpleMessage("Kommer att upphöra vid"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Skriv ditt meddelande här"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("Fel OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Fel lösenord angivet för den användaren."),
        "yearly": MessageLookupByLibrary.simpleMessage("Årlig"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Ja, ta bort för alltid"),
        "youAreNotAValidUser": MessageLookupByLibrary.simpleMessage(
            "Du är inte en giltig användare"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Du använder"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Du kan inte betala mer än vad som är förfallet"),
        "youHaveGotAnEmail": MessageLookupByLibrary.simpleMessage(
            "Du har fått ett e-postmeddelande"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Du har loggat in på ditt konto framgångsrikt. Stanna med Pos Saas."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("Du måste ge tillåtelse"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Du måste LOGGA IN på ditt konto igen."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Du måste verifiera din identitet innan du köper sms"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Ditt meddelande kvarstår"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Ditt Paket"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Ditt paket kommer att löpa ut om 5 dagar")
      };
}
