// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a ms locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'ms';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Teruskan"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("Nombor GST"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("Harga Runcit"),
        "MRPIsRequired": MessageLookupByLibrary.simpleMessage("MRP diperlukan"),
        "OK": MessageLookupByLibrary.simpleMessage("OK"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("No. Telefon"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("Kod SWIFT"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Snek"),
        "TAX": MessageLookupByLibrary.simpleMessage("CUKAI"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Memuat naik"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("Tajuk Pengguna"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Pakej Anda Akan Tamat Tempoh Hari Ini\n\nSila Beli Semula"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) Sistem ini disediakan semata-mata untuk\ntujuan memudahkan transaksi jualan\npoin dan aktiviti berkaitan dalam\nperniagaan anda."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) Untuk menggunakan Sistem ini, anda mungkin dikehendaki untuk membuat akaun. Anda bersetuju untuk memberikan maklumat yang tepat, terkini, dan lengkap semasa\nproses pendaftaran dan mengemaskini maklumat tersebut untuk memastikan ia adalah tepat dan lengkap."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("Tentang Aplikasi"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Tentang kami"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Penerimaan Terma"),
        "accountName": MessageLookupByLibrary.simpleMessage("Nama Akaun"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("Nombor Akaun"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Pendaftaran Akaun"),
        "acton": MessageLookupByLibrary.simpleMessage("Tindakan"),
        "add": MessageLookupByLibrary.simpleMessage("Tambah"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Tambah Jenama"),
        "addCategory": MessageLookupByLibrary.simpleMessage("Tambah Kategori"),
        "addContact": MessageLookupByLibrary.simpleMessage("Tambah Kenalan"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Tambah Pelanggan"),
        "addDelivery":
            MessageLookupByLibrary.simpleMessage("Tambah Penghantaran"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Tambah Penerangan"),
        "addDescription": MessageLookupByLibrary.simpleMessage("Tambah nota"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Tambah Diskaun"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Tambah ID Dokumen"),
        "addDucument": MessageLookupByLibrary.simpleMessage("Tambah Dokumen"),
        "addExpense":
            MessageLookupByLibrary.simpleMessage("Tambah Perbelanjaan"),
        "addExpenseCategory": MessageLookupByLibrary.simpleMessage(
            "Tambah Kategori Perbelanjaan"),
        "addItems": MessageLookupByLibrary.simpleMessage("Tambah Item"),
        "addNew": MessageLookupByLibrary.simpleMessage("Tambah Baru"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Tambah Alamat Baru"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Tambah Produk Baru"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("Tambah Cukai Baru"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Tambah Cukai Baru dengan jenis cukai tunggal/multiple"),
        "addNote": MessageLookupByLibrary.simpleMessage("Tambah Nota"),
        "addProductFirst": MessageLookupByLibrary.simpleMessage(
            "Tambah produk terlebih dahulu"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Tambah Kod Promosi"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Tambah Pembelian"),
        "addSales": MessageLookupByLibrary.simpleMessage("Tambah Jualan"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Berjaya Ditambah"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Tambah Unit"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Tambah Peranan Pengguna"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Ditambah dengan jayanya"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("Ditambahkan ke Troli"),
        "address": MessageLookupByLibrary.simpleMessage("Alamat"),
        "admin": MessageLookupByLibrary.simpleMessage("Admin"),
        "all": MessageLookupByLibrary.simpleMessage("Semua"),
        "allBusinessSolution": MessageLookupByLibrary.simpleMessage(
            "Semua Penyelesaian Perniagaan"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("Sudah ditambah"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Sudah Ada"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Sudah Memiliki Akaun"),
        "amount": MessageLookupByLibrary.simpleMessage("Jumlah"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "Satu Emel telah dihantar\nSemak peti masuk anda"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Sokongan Aplikasi Android & iOS"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Cukai yang terpakai"),
        "apply": MessageLookupByLibrary.simpleMessage("Mohon"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Adakah anda pasti mahu menghapuskan invois ini?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Adakah anda pasti mahu menghapuskan jualan ini?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Adakah anda pasti ingin memadam pengguna ini?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Adakah anda pasti ingin memadamkan Cukai ini?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Adakah anda pasti ingin memadamkan Kumpulan Cukai ini?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Adakah anda ingin memadamkan gudang ini?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Adakah anda pasti untuk memadam pengguna ini?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Tandatangan Berkuasa"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Anda bertanggungjawab untuk menjaga kerahsiaan akaun dan kata laluan anda serta menyekat\nakses kepada akaun anda. Anda menerima\ntanggungjawab atas semua aktiviti yang\nberlaku di bawah akaun anda."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Anda mesti berumur sekurang-kurangnya 18 tahun atau umur sah dalam bidang kuasa anda untuk\nmenggunakan Sistem ini."),
        "backSide": MessageLookupByLibrary.simpleMessage("Hala belakang"),
        "backToHome":
            MessageLookupByLibrary.simpleMessage("Kembali ke Laman Utama"),
        "balance": MessageLookupByLibrary.simpleMessage("Baki"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladesh"),
        "bank": MessageLookupByLibrary.simpleMessage("Bank"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Mata Wang Akaun Bank"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Mata Wang Akaun Bank"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Maklumat Bank"),
        "bankName": MessageLookupByLibrary.simpleMessage("Nama Bank"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("Pemindahan Bank"),
        "barcodeFound": MessageLookupByLibrary.simpleMessage("Kod bar ditemui"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Bil/Invois"),
        "billTo": MessageLookupByLibrary.simpleMessage("Bill Kepada"),
        "branchName": MessageLookupByLibrary.simpleMessage("Nama Cawangan"),
        "brand": MessageLookupByLibrary.simpleMessage("Jenama"),
        "brandName": MessageLookupByLibrary.simpleMessage("Nama Jenama"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("Muatan Pukal"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Kategori Perniagaan"),
        "buy": MessageLookupByLibrary.simpleMessage("Beli"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Beli Pelan Premium"),
        "buySms": MessageLookupByLibrary.simpleMessage("Beli Sms"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Dengan mengakses atau menggunakan Sistem Point of Sale (POS) (\"Sistem\") yang disediakan oleh [Nama Syarikat Anda] (\"Syarikat\"), anda bersetuju untuk terikat dengan Terma Penggunaan ini. Jika anda tidak bersetuju dengan Terma Penggunaan ini, jangan gunakan Sistem."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Anda bertanggungjawab untuk memastikan bahawa akses dan penggunaan Sistem ini mematuhi semua undang-undang dan peraturan yang berkenaan."),
        "cacel": MessageLookupByLibrary.simpleMessage("Batal"),
        "call": MessageLookupByLibrary.simpleMessage("Panggilan"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "Hubungi Untuk Sokongan Kecemasan"),
        "camera": MessageLookupByLibrary.simpleMessage("Kamera"),
        "cancel": MessageLookupByLibrary.simpleMessage("Batal"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Batal Semua Produk"),
        "capacity": MessageLookupByLibrary.simpleMessage("Kapasiti"),
        "card": MessageLookupByLibrary.simpleMessage("Kad"),
        "cash": MessageLookupByLibrary.simpleMessage("Tunai"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Tanpa Tunai"),
        "categories": MessageLookupByLibrary.simpleMessage("Kategori"),
        "category": MessageLookupByLibrary.simpleMessage("Kategori"),
        "categoryName": MessageLookupByLibrary.simpleMessage("Nama Kategori"),
        "categoryNameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Nama Kategori Sudah Ada"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("Nama Kategori"),
        "change": MessageLookupByLibrary.simpleMessage("Tukar?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Tukar Kata Laluan"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("Periksa Emel"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Pilih Pelanggan"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Pilih Pembekal"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Pilih ciri anda"),
        "clarence": MessageLookupByLibrary.simpleMessage("Clarence"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Klik untuk menyambung"),
        "close": MessageLookupByLibrary.simpleMessage("Tutup"),
        "color": MessageLookupByLibrary.simpleMessage("Warna"),
        "combinationOfMultipleTaxes":
            MessageLookupByLibrary.simpleMessage("(Gabungan pelbagai cukai)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Akan Datang"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Alamat Syarikat"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Nama Syarikat & Kedai"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("Nama Syarikat & Perniagaan"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Lengkapkan Transaksi"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Sahkan Kata Laluan"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Sahkan pulangan"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Tahniah"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Hubungi Kami"),
        "continu": MessageLookupByLibrary.simpleMessage("Teruskan"),
        "country": MessageLookupByLibrary.simpleMessage("Negara"),
        "create": MessageLookupByLibrary.simpleMessage("Cipta"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Cipta Akaun Percuma"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Dicipta dan Disimpan"),
        "currency": MessageLookupByLibrary.simpleMessage("Mata Wang"),
        "currentStock": MessageLookupByLibrary.simpleMessage("Stok Semasa"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("Penjenamaan Invois Kustom"),
        "customer": MessageLookupByLibrary.simpleMessage("Pelanggan"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Butiran Pelanggan"),
        "customerGST": MessageLookupByLibrary.simpleMessage("GST Pelanggan"),
        "customerName": MessageLookupByLibrary.simpleMessage("Nama Pelanggan"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Transaksi Harian"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Gambaran Papan Pemuka"),
        "dataSavedSuccessfully": MessageLookupByLibrary.simpleMessage(
            "Data disimpan dengan jayanya"),
        "date": MessageLookupByLibrary.simpleMessage("Tarikh"),
        "day": MessageLookupByLibrary.simpleMessage("Hari"),
        "dealer": MessageLookupByLibrary.simpleMessage("Pengedar"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("Harga Pengedar"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("Peratusan VAT Lalai"),
        "delete": MessageLookupByLibrary.simpleMessage("Padam"),
        "deleting": MessageLookupByLibrary.simpleMessage("Menghapus"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Alamat Penghantaran"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Alamat Penghantaran"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Cas Penghantaran"),
        "describtion": MessageLookupByLibrary.simpleMessage("Penerangan"),
        "description": MessageLookupByLibrary.simpleMessage("Penerangan"),
        "descriptionCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Deskripsi tidak boleh kosong"),
        "details": MessageLookupByLibrary.simpleMessage("Butiran"),
        "discount": MessageLookupByLibrary.simpleMessage("Diskaun"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Jangan Ganggu"),
        "done": MessageLookupByLibrary.simpleMessage("Selesai"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Muat Turun Format Excel"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Dimuat turun dengan jayanya dalam folder muat turun"),
        "due": MessageLookupByLibrary.simpleMessage("Tunggakan"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Jumlah Tunggakan: "),
        "dueCollection":
            MessageLookupByLibrary.simpleMessage("Pengutipan Tunggakan"),
        "dueCollectionReports": MessageLookupByLibrary.simpleMessage(
            "Laporan Pemungutan Berhutang"),
        "dueList": MessageLookupByLibrary.simpleMessage("Senarai Tunggakan"),
        "dueReports": MessageLookupByLibrary.simpleMessage("Laporan Tunggakan"),
        "duration": MessageLookupByLibrary.simpleMessage("Tempoh"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Tempoh: Dari"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "Mudah digunakan dengan aplikasi pos mudah alih"),
        "edit": MessageLookupByLibrary.simpleMessage("Edit"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Edit Invois Pembelian"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Edit Invois Jualan"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Edit Media Sosial"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Berjaya Mengedit"),
        "editTax": MessageLookupByLibrary.simpleMessage("Edit Cukai"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Edit Kumpulan Cukai"),
        "editWarehouse": MessageLookupByLibrary.simpleMessage("Edit Gudang"),
        "email": MessageLookupByLibrary.simpleMessage("Emel"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("Alamat Emel"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Emel tidak boleh kosong"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "E-mel Telah Dihantar! Semak peti masuk anda"),
        "endDate": MessageLookupByLibrary.simpleMessage("Tarikh Akhir"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Masukkan jumlah yang sah"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Masukkan Diskaun yang Sah"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Masukkan nombor telefon yang sah"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Masukkan harga yang sah"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("Masukkan kuantiti yang sah"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("Masukkan Alamat"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("Masukkan Jumlah."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Masukkan Nama Jenama"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Masukkan Kapasiti"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Masukkan Nama Kategori"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Masukkan Warna"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "Masukkan nombor GST pelanggan"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Masukkan Harga Pengedar"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Masukkan Penerangan"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("Masukkan Diskaun."),
        "enterExpenseDate": MessageLookupByLibrary.simpleMessage(
            "Masukkan Tarikh Perbelanjaan"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Masukkan Alamat Penuh"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Masukkan Nombor Invois"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Masukkan Jumlah Amaran Stok Rendah"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Masukkan Pengilang"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("Masukkan Kandungan Mesej"),
        "enterMrpOrRetailerPirce":
            MessageLookupByLibrary.simpleMessage("Masukkan Harga Runcit"),
        "enterName": MessageLookupByLibrary.simpleMessage("Masukkan Nama"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Masukkan Nota"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Masukkan Nama Pihak"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Masukkan Nombor Telefon"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Masukkan Kod Produk atau Imbas"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Masukkan Nama Produk"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Masukkan Harga Belian."),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("Masukkan Nombor Rujukan"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Masukkan Saiz"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("Masukkan Stok."),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Masukkan Kadar Cukai"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("Masukkan ID Transaksi"),
        "enterType": MessageLookupByLibrary.simpleMessage("Masukkan Jenis"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("Masukkan Tajuk Pengguna"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Masukkan jumlah yang sah"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Masukkan Nama Gudang"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Masukkan Berat"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Masukkan Harga Borong"),
        "enterYourDescriptionHere": MessageLookupByLibrary.simpleMessage(
            "Masukkan penerangan anda di sini"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("Masukkan Alamat Emel Anda"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "Masukkan Tajuk Maklum Balas Anda"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Masukkan Nombor GST anda"),
        "enterYourMobileNumber": MessageLookupByLibrary.simpleMessage(
            "Masukkan nombor telefon mudah alih anda"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Masukkan Nama Anda"),
        "enterYourNumber": MessageLookupByLibrary.simpleMessage(
            "Masukkan nombor telefon anda"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Masukkan Kata Laluan Anda"),
        "enterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Masukkan Nombor Telefon Anda"),
        "enterYourTransactionId":
            MessageLookupByLibrary.simpleMessage("Masukkan ID transaksi anda"),
        "error": MessageLookupByLibrary.simpleMessage("Ralat"),
        "excTax": MessageLookupByLibrary.simpleMessage("Cukai tidak termasuk"),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("Pemuat Naik Excel"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Eksklusif"),
        "expense": MessageLookupByLibrary.simpleMessage("Perbelanjaan"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Kategori Perbelanjaan"),
        "expenseDate":
            MessageLookupByLibrary.simpleMessage("Tarikh Perbelanjaan"),
        "expenseFor":
            MessageLookupByLibrary.simpleMessage("Perbelanjaan Untuk"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Laporan Perbelanjaan"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Tarikh Luput"),
        "expired": MessageLookupByLibrary.simpleMessage("Telah Luput"),
        "expiring": MessageLookupByLibrary.simpleMessage("Akan Luput"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Gagal dengan Ralat"),
        "fashion": MessageLookupByLibrary.simpleMessage("Fesyen"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Ciri-ciri adalah bahagian penting yang membezakan Pos Saas daripada penyelesaian tradisional."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Maklum Balas"),
        "firstName": MessageLookupByLibrary.simpleMessage("Nama Pertama"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Ikuti Kami Di\\nFacebook"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Ikuti Kami Di\\nTwitter"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Hala depan"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("Untuk penggunaan tanpa had"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Lupa kata laluan"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Lupa Kata Laluan?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Dari Tarikh"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("Sandaran Data Percuma"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "Kemas kini Seumur Hidup Percuma"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Pakej Percuma"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Pelan Percuma"),
        "from": MessageLookupByLibrary.simpleMessage("(Dari"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Sepenuhnya Dibayar"),
        "gallary": MessageLookupByLibrary.simpleMessage("Galeri"),
        "generatingPDF":
            MessageLookupByLibrary.simpleMessage("Menghasilkan PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Dapatkan OTP"),
        "govermentId": MessageLookupByLibrary.simpleMessage("ID Kerajaan"),
        "guest": MessageLookupByLibrary.simpleMessage("Tetamu"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Belum mempunyai akaun?"),
        "history": MessageLookupByLibrary.simpleMessage("Sejarah"),
        "home": MessageLookupByLibrary.simpleMessage("Utama"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Cara Kami Melindungi Maklumat Anda"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Cara Kami Menggunakan Maklumat Anda"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Pengesahan Identiti"),
        "image": MessageLookupByLibrary.simpleMessage("Imej"),
        "inHouseCantBeDelete": MessageLookupByLibrary.simpleMessage(
            "Dalam Rumah tidak boleh dipadam"),
        "inHouseCantBeEdited": MessageLookupByLibrary.simpleMessage(
            "Dalam Rumah tidak boleh diubah"),
        "inWord": MessageLookupByLibrary.simpleMessage("Dalam Perkataan"),
        "incTax": MessageLookupByLibrary.simpleMessage("Cukai termasuk"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Termasuk"),
        "increaseStock":
            MessageLookupByLibrary.simpleMessage("Tingkatkan Stok"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Instrumen"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("No. Inv"),
        "invoice": MessageLookupByLibrary.simpleMessage("Invois"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("Nombor Invois"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Tetapan Invois"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Penonton Invois"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Item Ditambah"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("Pengesahan KYC"),
        "language": MessageLookupByLibrary.simpleMessage("Bahasa"),
        "lastName": MessageLookupByLibrary.simpleMessage("Nama Terakhir"),
        "ledger": MessageLookupByLibrary.simpleMessage("Leger"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Pembelian Seumur Hidup"),
        "link": MessageLookupByLibrary.simpleMessage("Pautan"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport": MessageLookupByLibrary.simpleMessage(
            "Sokongan Chat Secara Langsung"),
        "loading": MessageLookupByLibrary.simpleMessage("Memuatkan"),
        "logIn": MessageLookupByLibrary.simpleMessage("Log Masuk"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Log Keluar"),
        "logOut": MessageLookupByLibrary.simpleMessage("Log Keluar"),
        "login": MessageLookupByLibrary.simpleMessage("Log Masuk"),
        "logo": MessageLookupByLibrary.simpleMessage("Logo"),
        "loss": MessageLookupByLibrary.simpleMessage("Rugi"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Rugi/Keuntungan"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Butiran Rugi/Keuntungan"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Laporan Kerugian/Keuntungan"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Laporan Kerugian/Keuntungan"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Amaran Stok Rendah"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Buat kesan yang berkekalan pada pelanggan anda dengan invois berjenama. Upgrade Tanpa Had kami menawarkan kelebihan unik untuk menyesuaikan invois anda, menambah sentuhan profesional yang memperkukuh identiti jenama anda dan membina kesetiaan pelanggan."),
        "manageYourBussinessWith": MessageLookupByLibrary.simpleMessage(
            "Uruskan perniagaan anda dengan "),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Tarikh Pembuatan"),
        "margin": MessageLookupByLibrary.simpleMessage("Margin"),
        "masterCard": MessageLookupByLibrary.simpleMessage("Kad Master"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Pengilang"),
        "message": MessageLookupByLibrary.simpleMessage("Mesej"),
        "messageHistory": MessageLookupByLibrary.simpleMessage("Sejarah Mesej"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Aplikasi Pos Saas adalah percuma, mudah digunakan. Sebenarnya, ini adalah salah satu sistem POS terbaik di seluruh dunia."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas adalah penyelesaian perniagaan yang lengkap dengan stok, akaun, jualan, perbelanjaan & rugi/keuntungan."),
        "mobile": MessageLookupByLibrary.simpleMessage("Mudah Alih"),
        "mobilePayment":
            MessageLookupByLibrary.simpleMessage("Pembayaran Mudah Alih"),
        "monthly": MessageLookupByLibrary.simpleMessage("Bulanan"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("Maklumat Lanjut"),
        "name": MessageLookupByLibrary.simpleMessage("Masukkan Nama Anda."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Nama Sudah Ada"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("Nama tidak boleh kosong"),
        "next": MessageLookupByLibrary.simpleMessage("Seterusnya"),
        "noConnection": MessageLookupByLibrary.simpleMessage("Tiada Sambungan"),
        "noData": MessageLookupByLibrary.simpleMessage("Tiada Data"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Tiada data yang tersedia"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Tiada Data Ditemukan"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("Tiada Sejarah Ditemui!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Tiada produk ditemui"),
        "noSubTaxSelected": MessageLookupByLibrary.simpleMessage(
            "Tiada Cukai Sub yang Dipilih"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("Tiada Transaksi Ditemui!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Tiada pengguna dijumpai untuk emel tersebut."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "Tiada Peranan Pengguna Ditemui"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Pengguna Tidak Aktif"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Tidak disediakan"),
        "note": MessageLookupByLibrary.simpleMessage("Nota"),
        "notes": MessageLookupByLibrary.simpleMessage("Nota"),
        "notification": MessageLookupByLibrary.simpleMessage("Pemberitahuan"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP dihantar ke"),
        "office": MessageLookupByLibrary.simpleMessage("Pejabat"),
        "ok": MessageLookupByLibrary.simpleMessage("Ok"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS yang mengandungi banyak fungsi, termasuk penjejakan jualan, pengurusan inventori."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Sistem ini membantu anda meningkatkan operasi anda untuk pelanggan anda."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Sistem POS kami sepatutnya menyederhanakan operasi harian secara automatik, menjadikannya mudah untuk dinavigasi."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("Baki Pembukaan "),
        "order": MessageLookupByLibrary.simpleMessage("Pesanan"),
        "other": MessageLookupByLibrary.simpleMessage("Lain-lain"),
        "otp": MessageLookupByLibrary.simpleMessage("Tutup"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Stok Habis"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Pakej"),
        "packageFeatures": MessageLookupByLibrary.simpleMessage("Ciri Pakej"),
        "paid": MessageLookupByLibrary.simpleMessage("Dibayar"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Jumlah Dibayar"),
        "parties": MessageLookupByLibrary.simpleMessage("Pihak-pihak"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Senarai Pihak"),
        "partyGST": MessageLookupByLibrary.simpleMessage("GST Pihak"),
        "partyName": MessageLookupByLibrary.simpleMessage("Nama Pihak"),
        "password": MessageLookupByLibrary.simpleMessage("Kata Laluan"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Kata laluan dan pengesahan kata laluan tidak sepadan"),
        "passwordCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Kata laluan tidak boleh kosong"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("Kata laluan tidak sepadan"),
        "payCash": MessageLookupByLibrary.simpleMessage("Bayar Tunai"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("Bayar dengan bkash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Bayar dengan Paypal"),
        "payeeName": MessageLookupByLibrary.simpleMessage("Nama Penerima"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("Nombor Penerima"),
        "payment": MessageLookupByLibrary.simpleMessage("Pembayaran"),
        "paymentAmount":
            MessageLookupByLibrary.simpleMessage("Jumlah Pembayaran"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Pembayaran Selesai"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Arahan Pembayaran:"),
        "paymentMethod":
            MessageLookupByLibrary.simpleMessage("Kaedah Pembayaran"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Jenis Pembayaran"),
        "pdfView": MessageLookupByLibrary.simpleMessage("Paparan PDF"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Maklumat Peribadi"),
        "phone": MessageLookupByLibrary.simpleMessage("Telefon"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Nombor Telefon"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Nombor telefon sudah digunakan"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("Nombor telefon tidak sah"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("Nombor telefon diperlukan"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("Pilih dan Muat Naik Fail"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("Pilih Tarikh Akhir"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Pilih Tarikh Mula"),
        "plan": MessageLookupByLibrary.simpleMessage("Pelan"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("Sila tambahkan kuantiti"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Sila periksa konektiviti internet anda"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Sila sambungkan pencetak terlebih dahulu"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Sila hubungkan pencetak Bluetooth anda"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Sila masukkan kata laluan yang lebih panjang"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Sila Masukkan Kata Laluan Pengesahan"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("Sila masukkan kata laluan"),
        "pleaseEnterAValidEmail":
            MessageLookupByLibrary.simpleMessage("Sila masukkan emel yang sah"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Sila masukkan nama"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("Sila Masukkan Kata Laluan"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Sila masukkan alamat emel anda di bawah untuk menerima Pautan Tetapan Semula Kata Laluan."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Sila Masukkan Nombor Transaksi"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("Sila masukkan jumlah"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Sila pilih kategori terlebih dahulu"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("Sila Pilih Pelan"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Sila pilih kategori perniagaan"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Sila gunakan kod pembelian yang sah untuk menggunakan aplikasi"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Dikuasakan Oleh Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Dikuasakan Oleh"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Sokongan Pelanggan Premium"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Pelan Premium"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Jumlah Bayaran Terdahulu"),
        "price": MessageLookupByLibrary.simpleMessage("harga"),
        "print": MessageLookupByLibrary.simpleMessage("Cetak"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Pilihan Cetakan"),
        "privacyPolicy": MessageLookupByLibrary.simpleMessage("Polisi Privasi"),
        "product": MessageLookupByLibrary.simpleMessage("Produk"),
        "productCode": MessageLookupByLibrary.simpleMessage("Kod Produk"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("Kod produk diperlukan"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Kod/Nama Produk"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Deskripsi Produk"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Butiran Produk"),
        "productList": MessageLookupByLibrary.simpleMessage("Senarai Produk"),
        "productName": MessageLookupByLibrary.simpleMessage("Nama Produk"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Nama produk sudah wujud dalam gudang ini"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Nama produk sudah ditambahkan"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("Nama produk diperlukan"),
        "products": MessageLookupByLibrary.simpleMessage("Produk"),
        "profile": MessageLookupByLibrary.simpleMessage("Profil"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("Sunting Profil"),
        "profit": MessageLookupByLibrary.simpleMessage("Keuntungan"),
        "promo": MessageLookupByLibrary.simpleMessage("Promosi"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Kod Promosi"),
        "purchase": MessageLookupByLibrary.simpleMessage("Pembelian"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("Pengingat Pembelian"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Pembelian Dikonfirmasi"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Butiran Pembelian"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Invois Pembelian"),
        "purchaseList":
            MessageLookupByLibrary.simpleMessage("Senarai Pembelian"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Beli Sekarang"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Pembelian Pelan Premium"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("Harga Belian"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("Harga pembelian diperlukan"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("Laporan Pembelian"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Laporan Pembelian"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Laporan Pembelian"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("Pulangan Pembelian"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("Laporan Pulangan Pembelian"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Transisi Pembelian"),
        "qty": MessageLookupByLibrary.simpleMessage("Kuantiti"),
        "quantity": MessageLookupByLibrary.simpleMessage("Kuantiti"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Transaksi Terkini"),
        "recivedThePin": MessageLookupByLibrary.simpleMessage("Menerima PIN"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Nombor Rujukan"),
        "register": MessageLookupByLibrary.simpleMessage("Daftar"),
        "registering": MessageLookupByLibrary.simpleMessage("Mendaftar"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("Baki Tunggakan"),
        "remove": MessageLookupByLibrary.simpleMessage("Buang"),
        "reports": MessageLookupByLibrary.simpleMessage("Laporan"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Permintaan telah dihantar"),
        "resendCode": MessageLookupByLibrary.simpleMessage("Hantar Semula Kod"),
        "resendOtp":
            MessageLookupByLibrary.simpleMessage("Hantar Semula OTP: "),
        "retailer": MessageLookupByLibrary.simpleMessage("Peniaga Runcit"),
        "retur": MessageLookupByLibrary.simpleMessage("Pulangan"),
        "returN": MessageLookupByLibrary.simpleMessage("Pulangan"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("Jumlah Pulangan"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("Jumlah Pulangan"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("Kuantiti Pulangan"),
        "revenue": MessageLookupByLibrary.simpleMessage("Pendapatan"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Lindungi data perniagaan anda dengan mudah. Upgrade Tanpa Had Pos Saas POS kami termasuk sandaran data percuma, memastikan maklumat berharga anda dilindungi daripada sebarang kejadian yang tidak dijangka. Tumpukan kepada apa yang benar-benar penting - pertumbuhan perniagaan anda."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Jumlah Jualan"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("Butiran Jualan"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Harga Jualan"),
        "saleReports": MessageLookupByLibrary.simpleMessage("Laporan Jualan"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Laporan Penjualan"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("Pulangan Jualan"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Laporan Pulangan Jualan"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("Tetapan Jualan"),
        "sales": MessageLookupByLibrary.simpleMessage("Jualan"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("Laporan Jualan & Pembelian"),
        "salesList": MessageLookupByLibrary.simpleMessage("Senarai Jualan"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("Pulangan Jualan"),
        "save": MessageLookupByLibrary.simpleMessage("Simpan"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Simpan dan Terbitkan"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("Simpan Perubahan"),
        "saving": MessageLookupByLibrary.simpleMessage("Menyimpan"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("Imbas kod QR produk"),
        "search": MessageLookupByLibrary.simpleMessage("Cari"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Cari dengan kod atau nama produk"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("Lihat semua kod promosi"),
        "select": MessageLookupByLibrary.simpleMessage("Pilih"),
        "selectAProductForReturn":
            MessageLookupByLibrary.simpleMessage("Pilih produk untuk pulangan"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Pilih Jenama"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Pilih Kategori"),
        "selectContacts": MessageLookupByLibrary.simpleMessage("Pilih Kenalan"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("Pilih Kategori Produk"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("Pilih Kategori Kedai"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Pilih Cukai"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Pilih Jenis Cukai"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("Pilih Unit"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Pilih Variasi: "),
        "seller": MessageLookupByLibrary.simpleMessage("Penjual"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Dijual Oleh"),
        "send": MessageLookupByLibrary.simpleMessage("Hantar"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("Hantar E-mel"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Hantar Mesej"),
        "sendResetLink": MessageLookupByLibrary.simpleMessage(
            "Hantar Pautan Tetapan Semula"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Hantar Sms"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Hantar sms?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Hantar mesej Whatsapp"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Hantar E-mel Anda"),
        "sendingEmail":
            MessageLookupByLibrary.simpleMessage("Menghantar E-mel"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Menghantar mesej"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Perkhidmatan/Penghantaran"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Tetapkan Profil Anda"),
        "setting": MessageLookupByLibrary.simpleMessage("Tetapan"),
        "share": MessageLookupByLibrary.simpleMessage("Bahagian"),
        "shopGST": MessageLookupByLibrary.simpleMessage("GST Kedai"),
        "signIn": MessageLookupByLibrary.simpleMessage("Log Masuk"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("Log masuk dengan emel"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Tandatangan Pelanggan"),
        "size": MessageLookupByLibrary.simpleMessage("Saiz"),
        "skip": MessageLookupByLibrary.simpleMessage("Lewatkan"),
        "sms": MessageLookupByLibrary.simpleMessage("Sms"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Pemasaran Sosial"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Maaf, anda tidak mempunyai kebenaran untuk mengakses perkhidmatan ini"),
        "startDate": MessageLookupByLibrary.simpleMessage("Tarikh Mula"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Mula Jualan Baru"),
        "startTypingToSearch":
            MessageLookupByLibrary.simpleMessage("Mula taip untuk mencari"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Tetap di hadapan perkembangan teknologi tanpa kos tambahan. Pos Saas POS Unlimited Upgrade kami memastikan anda sentiasa memiliki alat dan ciri terkini di hujung jari anda, menjamin perniagaan anda kekal dalam keadaan paling canggih."),
        "stillUnpaid":
            MessageLookupByLibrary.simpleMessage("Masih Belum Dibayar"),
        "stock": MessageLookupByLibrary.simpleMessage("Stok"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Stok diperlukan"),
        "stockList": MessageLookupByLibrary.simpleMessage("Senarai Stok"),
        "stocks": MessageLookupByLibrary.simpleMessage("Stok"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Kebenaran penyimpanan diperlukan untuk mencipta fail Excel"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("Senarai Cukai Sub"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Cukai Sub"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Jumlah Sub"),
        "submit": MessageLookupByLibrary.simpleMessage("Hantar"),
        "subscribeToOurYoutube":
            MessageLookupByLibrary.simpleMessage("Langgan Di\\nYoutube Kami"),
        "subscription": MessageLookupByLibrary.simpleMessage("Langganan"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Selesai dengan Jayanya"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Berjaya Log Keluar"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Berjaya Dikemas Kini"),
        "supplier": MessageLookupByLibrary.simpleMessage("Pembekal"),
        "supplierName": MessageLookupByLibrary.simpleMessage("Nama Pembekal"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("Kod SWIFT"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Ambil gambar lesen memandu, kad pengenalan negara atau pasport"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "Ambil kad pengenalan untuk memeriksa maklumat anda"),
        "tap": MessageLookupByLibrary.simpleMessage("Ketuk"),
        "tax": MessageLookupByLibrary.simpleMessage("Cukai"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Kumpulan Cukai"),
        "taxPercentage":
            MessageLookupByLibrary.simpleMessage("Peratusan Cukai"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Kadar Cukai"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Kadar Cukai - Urus Kadar Cukai Anda"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Laporan Cukai"),
        "taxType": MessageLookupByLibrary.simpleMessage("Jenis Cukai"),
        "taxes": MessageLookupByLibrary.simpleMessage("Cukai"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Terma dan Syarat"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("Terma Penggunaan"),
        "termsPrivacy": MessageLookupByLibrary.simpleMessage("Terma & Privasi"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Terima Kasih Atas Pembayaran Tunggakan Anda"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Terima Kasih"),
        "thankYouForYourPurchase": MessageLookupByLibrary.simpleMessage(
            "Terima kasih atas pembelian anda"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "Akaun sudah wujud untuk emel itu"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Fail Excel telah pun dimuat turun"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Nama tersebut mengatakan segalanya. Dengan Pos Saas POS Unlimited, tidak ada had penggunaan. Sama ada anda memproses beberapa urus niaga atau mengalami lonjakan pelanggan, anda boleh beroperasi dengan yakin, dengan pengetahuan bahawa anda tidak terikat oleh had."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "Kata laluan yang diberikan terlalu lemah"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Jualan akan dihapuskan dan semua data tentang pembelian ini akan dihapuskan. Adakah anda pasti mahu menghapusnya?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Jualan akan dihapuskan dan semua data tentang jualan ini akan dihapuskan. Adakah anda pasti mahu menghapusnya?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Pengguna ini akan dipadamkan dan semua data akan dihapuskan dari akaun anda. Adakah anda pasti untuk memadam ini?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Pengguna akan dipadam dan semua data akan dipadam dari akaun anda. Adakah anda pasti ingin memadam ini?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Perkhidmatan Pihak Ketiga"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Kategori ini tidak boleh dipadam"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Bulan Ini)"),
        "thisProductAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("Produk ini sudah ditambah"),
        "title": MessageLookupByLibrary.simpleMessage("Tajuk"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Tajuk tidak boleh kosong"),
        "to": MessageLookupByLibrary.simpleMessage("ke"),
        "toDate": MessageLookupByLibrary.simpleMessage("Hingga Tarikh"),
        "today": MessageLookupByLibrary.simpleMessage("Hari ini"),
        "total": MessageLookupByLibrary.simpleMessage("Jumlah"),
        "totalAmount":
            MessageLookupByLibrary.simpleMessage("Jumlah Keseluruhan"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Jumlah Diperolehi"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Jumlah Tunggakan"),
        "totalExpense":
            MessageLookupByLibrary.simpleMessage("Jumlah Perbelanjaan"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Jumlah Kerugian"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("Jumlah Bayaran Keseluruhan"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Jumlah Harga"),
        "totalProducts": MessageLookupByLibrary.simpleMessage("Jumlah Produk"),
        "totalProfit":
            MessageLookupByLibrary.simpleMessage("Jumlah Keuntungan"),
        "totalPurchase":
            MessageLookupByLibrary.simpleMessage("Jumlah Pembelian"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Jumlah Pulangan Keseluruhan"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("Jumlah Pulangan"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Jumlah Jualan"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Jumlah Stok"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Jumlah Nilai"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Jumlah Cukai"),
        "totals": MessageLookupByLibrary.simpleMessage("Jumlah: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Transaksi"),
        "transactionId": MessageLookupByLibrary.simpleMessage("ID Transaksi"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Cuba Lagi"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Jenis"),
        "unitName": MessageLookupByLibrary.simpleMessage("Nama Unit"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Harga Unit"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Harga Seunit"),
        "units": MessageLookupByLibrary.simpleMessage("Unit"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Tidak Terhad"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Penggunaan Tanpa Had"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Buka potensi penuh Pos Saas POS dengan sesi latihan yang disesuaikan oleh pasukan pakar kami. Dari asas hingga teknik-teknik yang lebih canggih, kami memastikan anda mahir dalam menggunakan setiap aspek sistem untuk mengoptimumkan proses perniagaan anda."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Belum dibayar"),
        "update": MessageLookupByLibrary.simpleMessage("Kemaskini"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Kemaskini Kenalan"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Kemaskini Sekarang"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("Kemaskini Produk"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Kemas kini pelan anda terlebih dahulu, had anda telah tamat"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Kemaskini Profil Anda"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Kemaskini profil anda untuk menghubungkan doktor anda dengan kesan yang lebih baik"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Kemaskini profil anda untuk menyambung pelanggan anda dengan kesan yang lebih baik"),
        "updated": MessageLookupByLibrary.simpleMessage("Dikemas Kini"),
        "upload": MessageLookupByLibrary.simpleMessage("Muat Naik"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Muat Naik Dokumen"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("Muat naik selesai"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Muat Naik Fail"),
        "usbC": MessageLookupByLibrary.simpleMessage("Usb C"),
        "use": MessageLookupByLibrary.simpleMessage("Gunakan"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("Guna Pos Saas"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Penggunaan Sistem"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Pengguna telah dipadam"),
        "userRole": MessageLookupByLibrary.simpleMessage("Peranan Pengguna"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("Butiran Peranan Pengguna"),
        "userTitle": MessageLookupByLibrary.simpleMessage("Tajuk Pengguna"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Tajuk pengguna tidak boleh kosong"),
        "value": MessageLookupByLibrary.simpleMessage("Nilai"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("VAT Tidak Terpakai"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("Mengesahkan OTP"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Mengesahkan Nombor Telefon"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Papar Semua"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("Lihat Butiran"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Pelanggan Masuk"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Gudang"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Gudang Sudah Ada"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("Senarai Gudang"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("Nama Gudang"),
        "warranty": MessageLookupByLibrary.simpleMessage("Jaminan"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Kami telah menghantar emel dengan arahan tentang cara menetapkan semula kata laluan ke:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Kami mungkin menggunakan perkhidmatan pihak ketiga untuk menyokong fungsi aplikasi kami, seperti penyedia analitik dan pemproses pembayaran. Perkhidmatan pihak ketiga ini mungkin mengumpul maklumat mengenai anda apabila anda menggunakan aplikasi kami. Sila ambil perhatian bahawa kami tidak bertanggungjawab terhadap amalan privasi perkhidmatan pihak ketiga ini."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Kami mengambil langkah-langkah piawai industri untuk melindungi maklumat peribadi anda, termasuk enkripsi dan penyimpanan yang selamat. Kami juga menyekat akses kepada maklumat anda kepada kakitangan yang diberi kuasa sahaja."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Kami faham kepentingan operasi yang lancar. Oleh itu, sokongan kami sepanjang masa sedia membantu anda, sama ada pertanyaan cepat atau kebimbangan menyeluruh. Hubungi kami pada bila-bila masa, di mana sahaja melalui panggilan atau WhatsApp untuk mengalami perkhidmatan pelanggan yang tiada tandingannya."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Kami menggunakan maklumat peribadi anda untuk memberikan pengalaman terbaik di aplikasi kami, termasuk untuk memperibadikan cadangan kandungan anda, menghubungkan anda dengan pakar, dan meningkatkan fungsi aplikasi kami. Kami juga boleh menggunakan maklumat anda untuk berkomunikasi dengan anda mengenai kemaskini, promosi, atau maklumat lain yang berkaitan dengan aplikasi kami."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Kami akan menyemak pembayaran dan meluluskannya dalam 1-2 jam"),
        "weekly": MessageLookupByLibrary.simpleMessage("Mingguan"),
        "weight": MessageLookupByLibrary.simpleMessage("Berat"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Apa yang Baru"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Pengedar Borong"),
        "wholeSalePrice": MessageLookupByLibrary.simpleMessage("Harga Borong"),
        "wholesalePrice":
            MessageLookupByLibrary.simpleMessage("Harga Pemborong"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Pemborong"),
        "willBeAddedSoon": MessageLookupByLibrary.simpleMessage(
            "Akan Ditambah Tidak Lama Lagi"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Akan Luput Pada"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Tulis mesej anda di sini"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("OTP salah"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Kata laluan yang salah diberikan untuk pengguna tersebut."),
        "yearly": MessageLookupByLibrary.simpleMessage("Tahunan"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Ya, Padam Selamanya"),
        "youAreNotAValidUser": MessageLookupByLibrary.simpleMessage(
            "Anda Bukan Pengguna Yang Sah"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Anda menggunakan"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Anda tidak boleh membayar lebih dari jumlah yang perlu dibayar"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Anda Telah Menerima Emel"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Anda berjaya log masuk ke akaun anda. Kekal dengan Pos Saas ."),
        "youHaveToGivePermission": MessageLookupByLibrary.simpleMessage(
            "Anda perlu memberikan kebenaran"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Anda perlu LOG MASUK semula ke akaun anda."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Anda perlu mengesahkan identiti sebelum membeli sms"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Mesej anda kekal"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Pakej Anda"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Pakej Anda Akan Tamat Tempoh dalam 5 Hari")
      };
}
