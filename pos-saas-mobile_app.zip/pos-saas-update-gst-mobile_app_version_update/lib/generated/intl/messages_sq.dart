// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a sq locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'sq';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Vazhdo"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("Numri GST"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("MRP është i nevojshëm"),
        "OK": MessageLookupByLibrary.simpleMessage("OK"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Numri i Telefonit"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("Kodi SWIFT"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Snacks"),
        "TAX": MessageLookupByLibrary.simpleMessage("TATIM"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Po ngarkohet"),
        "UserTitle":
            MessageLookupByLibrary.simpleMessage("Titulli i Përdoruesit"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Paketa juaj do të skadojë sot\n\nJu lutemi bëni blerjen përsëri"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) Sistemi ofrohet ekskluzivisht për qëllimin e lehtësimit të transaksioneve të shitjes dhe aktiviteteve të lidhura në biznesin tuaj."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) Për të përdorur Sistemin, mund t\'ju kërkohet të krijoni një llogari. Pajtoheni të siguroni informacion të saktë, aktual dhe të plotë gjatë procesit të regjistrimit dhe ta përditësoni atë për të mbetur të saktë dhe të plotë."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("Rreth Aplikacionit"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Rreth nesh"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Pranimi i kushteve"),
        "accountName": MessageLookupByLibrary.simpleMessage("Emri i Llogarisë"),
        "accountNumber":
            MessageLookupByLibrary.simpleMessage("Numri i Llogarisë"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Regjistrimi i llogarisë"),
        "acton": MessageLookupByLibrary.simpleMessage("Vepro"),
        "add": MessageLookupByLibrary.simpleMessage("Shto"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Shto Markë"),
        "addCategory": MessageLookupByLibrary.simpleMessage("Shto Kategori"),
        "addContact": MessageLookupByLibrary.simpleMessage("Shto Kontakt"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Shto Klient"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("Shto Dërgesë"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Shto përshkrimin"),
        "addDescription": MessageLookupByLibrary.simpleMessage("Shtoni shënim"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Shtoni zbritje"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Shto ID Dokumentit"),
        "addDucument": MessageLookupByLibrary.simpleMessage("Shto Dokumentin"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Shto Shpenzim"),
        "addExpenseCategory": MessageLookupByLibrary.simpleMessage(
            "Shto Kategorinë e Shpenzimeve"),
        "addItems": MessageLookupByLibrary.simpleMessage("Shto Artikuj"),
        "addNew": MessageLookupByLibrary.simpleMessage("Shto të re"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Shto Adresë të Re"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Shto Produkt të Ri"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("Shto Tatim të Ri"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Shto Tatim të Ri me një shumëllojshmëri tatimesh"),
        "addNote": MessageLookupByLibrary.simpleMessage("Shto shënim"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Shtoni produktin së pari"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Shtoni kodin promocional"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Shto Blerje"),
        "addSales": MessageLookupByLibrary.simpleMessage("Shto Shitje"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Shtimi është i Suksesshëm"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Shto Njësinë"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Shtoni Roli të Përdoruesit"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Shtuar me sukses"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("Shtuar në karrocë"),
        "address": MessageLookupByLibrary.simpleMessage("Adresa"),
        "admin": MessageLookupByLibrary.simpleMessage("Administratori"),
        "all": MessageLookupByLibrary.simpleMessage("Të Gjitha"),
        "allBusinessSolution": MessageLookupByLibrary.simpleMessage(
            "Të gjitha zgjidhjet e biznesit"),
        "alreadyAdded":
            MessageLookupByLibrary.simpleMessage("Të shtuar tashmë"),
        "alreadyExists":
            MessageLookupByLibrary.simpleMessage("Tashmë ekziston"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Tashmë keni një llogari?"),
        "amount": MessageLookupByLibrary.simpleMessage("Shuma"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "Një email është dërguar\nKontrolloni kutinë tuaj të postës"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Mbështetja për Aplikacionet Android dhe iOS"),
        "applicableTax": MessageLookupByLibrary.simpleMessage("Tatimi në fuqi"),
        "apply": MessageLookupByLibrary.simpleMessage("Apliko"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "A jeni të sigurt që dëshironi të fshini këtë faturë?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "A jeni të sigurt që dëshironi të fshini këtë shitje?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "A jeni i sigurt që dëshironi të fshini këtë përdorues?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "A jeni të sigurt se dëshironi të fshini këtë taksë?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "A jeni të sigurt se dëshironi të fshini këtë grup taksash?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "A dëshironi të fshini këtë magazinë?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Jeni të sigurt që dëshironi të fshini këtë përdorues?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Nënshkrimi i Autorizuar"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Ju jeni përgjegjës për mbajtjen e konfidencialitetit të llogarisë suaj dhe fjalëkalimit dhe për kufizimin e qasjes në llogarinë tuaj. Pranoni përgjegjësinë për të gjitha aktivitetet që ndodhin nën llogarinë tuaj."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Duhet të keni të paktën 18 vjeç ose moshën ligjore të shumicës në juridiksionin tuaj për të përdorur Sistemin."),
        "backSide": MessageLookupByLibrary.simpleMessage("Anëja e dytë"),
        "backToHome": MessageLookupByLibrary.simpleMessage("Kthehu te Ballina"),
        "balance": MessageLookupByLibrary.simpleMessage("Bilanci"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladeshi"),
        "bank": MessageLookupByLibrary.simpleMessage("Banka"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Monedha e Llogarisë Bankare"),
        "bankAccountingCurrecny": MessageLookupByLibrary.simpleMessage(
            "Monedha e Llogarisë së Bankës"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Informacioni i Bankës"),
        "bankName": MessageLookupByLibrary.simpleMessage("Emri i Bankës"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("Transfer Bankar"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Kodi i barkodit u gjet"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Fatura/Faturë"),
        "billTo": MessageLookupByLibrary.simpleMessage("Fatura Për"),
        "branchName": MessageLookupByLibrary.simpleMessage("Emri i Degës"),
        "brand": MessageLookupByLibrary.simpleMessage("Marka"),
        "brandName": MessageLookupByLibrary.simpleMessage("Emri i Markës"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("Ngarkim masiv"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Kategoria e Biznesit"),
        "buy": MessageLookupByLibrary.simpleMessage("Bli"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Bli Paketën Premium"),
        "buySms": MessageLookupByLibrary.simpleMessage("Bli Sms"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Duke pasur qasje ose duke përdorur Sistemin të Puntës së Shitjes (POS) (\"Sistemi\") të ofruar nga [Emri i Kompanisë Tuaj] (\"Kompania\"), pajtoheni të lidheni me këto Kushte Përdorimi. Nëse nuk pajtoheni me këto Kushte Përdorimi, mos përdorni Sistemin."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Ju jeni përgjegjës për sigurimin që qasja juaj dhe përdorimi i Sistemit të jetë në përputhje me të gjitha ligjet dhe rregulloret e zbatueshme."),
        "cacel": MessageLookupByLibrary.simpleMessage("Anulo"),
        "call": MessageLookupByLibrary.simpleMessage("Thirrje"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "Telefononi për Mbështetje Emergjente"),
        "camera": MessageLookupByLibrary.simpleMessage("Kamera"),
        "cancel": MessageLookupByLibrary.simpleMessage("Anulo"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Anulo të gjitha produktet"),
        "capacity": MessageLookupByLibrary.simpleMessage("Kapaciteti"),
        "card": MessageLookupByLibrary.simpleMessage("Kartë"),
        "cash": MessageLookupByLibrary.simpleMessage("Cash"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Kategoritë"),
        "category": MessageLookupByLibrary.simpleMessage("Kategoria"),
        "categoryName":
            MessageLookupByLibrary.simpleMessage("Emri i kategorisë"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "Emri i kategorisë ekziston tashmë"),
        "cateogryName":
            MessageLookupByLibrary.simpleMessage("Emri i Kategorisë"),
        "change": MessageLookupByLibrary.simpleMessage("Ndryshoni"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Ndrysho Fjalëkalimin"),
        "checkEmail":
            MessageLookupByLibrary.simpleMessage("Kontrolloni Email-in"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Zgjidhni një Klient"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Zgjidhni një Furnizues"),
        "choseYourFeature": MessageLookupByLibrary.simpleMessage(
            "Zgjidh karakteristikat tuaja"),
        "clarence": MessageLookupByLibrary.simpleMessage("Clarence"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Klikoni për të lidhur"),
        "close": MessageLookupByLibrary.simpleMessage("Mbylle"),
        "color": MessageLookupByLibrary.simpleMessage("Ngjyra"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(Kombinimi i taksave të shumta)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Së Shpejti"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Adresa e Kompanisë"),
        "companyAndShopName": MessageLookupByLibrary.simpleMessage(
            "Emri i Kompanisë dhe Dyqanit"),
        "companyBusinessName": MessageLookupByLibrary.simpleMessage(
            "Emri i Kompanisë dhe Biznesit"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Plotëso Transaksionin"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Konfirmo Fjalëkalimin"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Konfirmoni kthimin"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Urime"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Kontaktoni me Ne"),
        "continu": MessageLookupByLibrary.simpleMessage("Vazhdoni"),
        "country": MessageLookupByLibrary.simpleMessage("Vendi"),
        "create": MessageLookupByLibrary.simpleMessage("Krijo"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Krijo një Llogari të Lirë"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Krijuar dhe Ruajtur"),
        "currency": MessageLookupByLibrary.simpleMessage("Monedha"),
        "currentStock": MessageLookupByLibrary.simpleMessage("Stoku Aktual"),
        "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
            "Branding i Faturës Së Përshtatur"),
        "customer": MessageLookupByLibrary.simpleMessage("Klienti"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Detajet e Klientit"),
        "customerGST": MessageLookupByLibrary.simpleMessage("GST i klientit"),
        "customerName": MessageLookupByLibrary.simpleMessage("Emri i Klientit"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Transaksioni Ditore"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Pasqyra e panelit"),
        "dataSavedSuccessfully": MessageLookupByLibrary.simpleMessage(
            "Të dhënat janë ruajtur me sukses"),
        "date": MessageLookupByLibrary.simpleMessage("Data"),
        "day": MessageLookupByLibrary.simpleMessage("Ditë"),
        "dealer": MessageLookupByLibrary.simpleMessage("Tregtar"),
        "dealerPrice":
            MessageLookupByLibrary.simpleMessage("Çmimi i Tregtarit"),
        "defaultVATPercentage": MessageLookupByLibrary.simpleMessage(
            "Përqindja e TVSH-së Standard"),
        "delete": MessageLookupByLibrary.simpleMessage("Fshij"),
        "deleting": MessageLookupByLibrary.simpleMessage("Po fshihet"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Adresa e Dërgesës"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Adresat e dorëzimit"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Kosto e Dorëzimit"),
        "describtion": MessageLookupByLibrary.simpleMessage("Përshkrim"),
        "description": MessageLookupByLibrary.simpleMessage("Përshkrimi"),
        "descriptionCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Përshkrimi nuk mund të jetë bosh"),
        "details": MessageLookupByLibrary.simpleMessage("Detaje"),
        "discount": MessageLookupByLibrary.simpleMessage("Zbritje"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Mos u shqetëso"),
        "done": MessageLookupByLibrary.simpleMessage("Kryer"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Shkarkoni formatin Excel"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Shkarkuar me sukses në dosjen e shkarkimeve"),
        "due": MessageLookupByLibrary.simpleMessage("Borxh"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Shuma e Borxhit: "),
        "dueCollection":
            MessageLookupByLibrary.simpleMessage("Mbledhja e Borxhit"),
        "dueCollectionReports": MessageLookupByLibrary.simpleMessage(
            "Raporte për grumbullimin e detyrueshëm"),
        "dueList": MessageLookupByLibrary.simpleMessage("Lista e Borxhit"),
        "dueReports":
            MessageLookupByLibrary.simpleMessage("Raporti i Borxheve"),
        "duration": MessageLookupByLibrary.simpleMessage("Kohëzgjatja"),
        "durationFrom":
            MessageLookupByLibrary.simpleMessage("Kohëzgjatja: Nga"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "POS-i i lehtë për përdorim me celular"),
        "edit": MessageLookupByLibrary.simpleMessage("Edito"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Edito Faturën e Blerjes"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Edito Faturën e Shitjes"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Edito Mediat Sociale"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Redaktimi u krye me sukses"),
        "editTax": MessageLookupByLibrary.simpleMessage("Redakto taksën"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Redakto grupin e taksave"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("Redakto magazinën"),
        "email": MessageLookupByLibrary.simpleMessage("Email"),
        "emailAddress":
            MessageLookupByLibrary.simpleMessage("Adresa e Emailit"),
        "emailCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Emaili nuk mund të jetë bosh"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "Emaili është dërguar! Kontrolloni kutinë tuaj të postës"),
        "endDate": MessageLookupByLibrary.simpleMessage("Data e Përfundimit"),
        "enterAValidAmount": MessageLookupByLibrary.simpleMessage(
            "Shkruani një shumë të vlefshme"),
        "enterAValidDiscount": MessageLookupByLibrary.simpleMessage(
            "Vendosni një zbritje të vlefshme"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Shkruani një numër telefoni të vlefshëm"),
        "enterAValidPrice": MessageLookupByLibrary.simpleMessage(
            "Vendosni një çmim të vlefshëm"),
        "enterAValidQuantity": MessageLookupByLibrary.simpleMessage(
            "Vendosni një sasi të vlefshme"),
        "enterAddress":
            MessageLookupByLibrary.simpleMessage("Shkruani Adresën"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("Shkruani Shumën."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Shkruani Emrin e Markës"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Shkruani Kapacitetin"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Shkruani Emrin e Kategorisë"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Shkruani Ngjyrën"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "Shkruani numrin GST të klientit"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Shkruani Çmimin e Tregtarit"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Shkruani përshkrimin"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("Shkruani Zbritjen."),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Shkruani Datën e Shpenzimit"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Shkruani Adresën e Plotë"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Shkruani Numrin e Faturës"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Shkruani sasinë për alarm të stokut të ulët"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Shkruani Prodhuesin"),
        "enterMessageContent": MessageLookupByLibrary.simpleMessage(
            "Shkruani Përmbajtjen e Mesazhit"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "Shkruani MRP/Çmimin e Shitësit"),
        "enterName": MessageLookupByLibrary.simpleMessage("Shkruani Emrin"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Shkruani Shënimin"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Shkruani Emrin e Partisë"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Shkruani Numrin e Telefonit"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Shkruani Kodin e Produktit ose Skanoni"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Shkruani Emrin e Produktit"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Shkruani Çmimin e Blerjes."),
        "enterReferenceNumber": MessageLookupByLibrary.simpleMessage(
            "Shkruani Numrin e Referencës"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Shkruani Madhësinë"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("Shkruani Stoket."),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Shkruani normën e taksës"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("Vendosni ID e Transaksionit"),
        "enterType": MessageLookupByLibrary.simpleMessage("Shkruani Llojin"),
        "enterUserTitle": MessageLookupByLibrary.simpleMessage(
            "Vendosni titullin e përdoruesit"),
        "enterValidAmount": MessageLookupByLibrary.simpleMessage(
            "Shkruani një shumë të vlefshme"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Shkruani emrin e magazinës"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Shkruani Pesha"),
        "enterWholeSalePrice": MessageLookupByLibrary.simpleMessage(
            "Shkruani Çmimin për Shitje me Shumicë"),
        "enterYourDescriptionHere": MessageLookupByLibrary.simpleMessage(
            "Shkruani përshkrimin tuaj këtu"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "Shkruani Adresën Tuaj të Emailit"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "Shkruani Titullin e Feedback-ut Tuaj"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Shkruani numrin tuaj GST"),
        "enterYourMobileNumber": MessageLookupByLibrary.simpleMessage(
            "Shkruani numrin tuaj të celularit"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Shkruani Emrin Tuaj"),
        "enterYourNumber": MessageLookupByLibrary.simpleMessage(
            "Shkruani numrin tuaj të telefonit"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Vendosni fjalëkalimin tuaj"),
        "enterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Shkruani Numrin Tuaj të Telefonit"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "Shkruani ID e transaksionit tuaj"),
        "error": MessageLookupByLibrary.simpleMessage("Gabim"),
        "excTax": MessageLookupByLibrary.simpleMessage("Përjashton tatimin"),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("Ngarkuesi i Excel"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Përjashtuese"),
        "expense": MessageLookupByLibrary.simpleMessage("Shpenzimi"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Kategoria e Shpenzimeve"),
        "expenseDate":
            MessageLookupByLibrary.simpleMessage("Data e Shpenzimit"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Shpenzimi për"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Raporti i Shpenzimeve"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Data e skadimit"),
        "expired": MessageLookupByLibrary.simpleMessage("I skaduar"),
        "expiring": MessageLookupByLibrary.simpleMessage("Dëshmimi"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Dështoi me gabim"),
        "fashion": MessageLookupByLibrary.simpleMessage("Modë"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Karakteristikat janë pjesa e rëndësishme që bën Pos Saas të ndryshojë nga zgjidhjet tradicionale."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Feedback"),
        "firstName": MessageLookupByLibrary.simpleMessage("Emri i Parë"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Na ndiqni në\\nFacebook"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Na ndiqni në\\nTwitter"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Anëja e parë"),
        "forUnlimitedUses": MessageLookupByLibrary.simpleMessage(
            "Për përdorime të pakufizuara"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Keni harruar fjalëkalimin"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Keni harruar fjalëkalimin?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Nga Data"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("Kopjimi i të Dhënave Falas"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "Përditësimi pa Limit për Jetë"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Paketa e Lirë"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Paketa e Lirë"),
        "from": MessageLookupByLibrary.simpleMessage("(Nga"),
        "fullyPaid":
            MessageLookupByLibrary.simpleMessage("E Paguar Plotësisht"),
        "gallary": MessageLookupByLibrary.simpleMessage("Galeria"),
        "generatingPDF":
            MessageLookupByLibrary.simpleMessage("Duke gjeneruar PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Merrni OTP-në"),
        "govermentId": MessageLookupByLibrary.simpleMessage("ID e Qeverisë"),
        "guest": MessageLookupByLibrary.simpleMessage("Mysafir"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Nuk keni një llogari?"),
        "history": MessageLookupByLibrary.simpleMessage("Historiku"),
        "home": MessageLookupByLibrary.simpleMessage("Ballina"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Si e mbrojmë informacionin tuaj"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Si përdorim informacionin tuaj"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Verifikimi i Identitetit"),
        "image": MessageLookupByLibrary.simpleMessage("Imazh"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("Nuk mund të fshihet"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("Nuk mund të redaktohet"),
        "inWord": MessageLookupByLibrary.simpleMessage("Në Fjalë"),
        "incTax": MessageLookupByLibrary.simpleMessage("Përfshin tatimin"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Përfshirëse"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("Rritni stokin"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Instrument"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Nr. Faturës"),
        "invoice": MessageLookupByLibrary.simpleMessage("Faturë"),
        "invoiceNumber":
            MessageLookupByLibrary.simpleMessage("Numri i Faturës"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Cilësimet e Faturës"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Shikues i faturave"),
        "itemAdded":
            MessageLookupByLibrary.simpleMessage("Artikulli është Shtuar"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("Verifikimi KYC"),
        "language": MessageLookupByLibrary.simpleMessage("Gjuha"),
        "lastName": MessageLookupByLibrary.simpleMessage("Mbiemri"),
        "ledger": MessageLookupByLibrary.simpleMessage("Kartela"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Blerje e Përjetshme"),
        "link": MessageLookupByLibrary.simpleMessage("Linku"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport": MessageLookupByLibrary.simpleMessage(
            "Mbështetje në Bisedë të Drejtëpërdrejtë"),
        "loading": MessageLookupByLibrary.simpleMessage("Po ngarkohet"),
        "logIn": MessageLookupByLibrary.simpleMessage("Hyrje"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Ç\'kycje"),
        "logOut": MessageLookupByLibrary.simpleMessage("Ç\'kyçuni"),
        "login": MessageLookupByLibrary.simpleMessage("Hyrje"),
        "logo": MessageLookupByLibrary.simpleMessage("Logo"),
        "loss": MessageLookupByLibrary.simpleMessage("Humbje"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Fitim/Humbje"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Detajet e Fitimit/Humbjes"),
        "lossProfitReport": MessageLookupByLibrary.simpleMessage(
            "Raporti i Humbjes/Së Fitimit"),
        "lossProfitReports": MessageLookupByLibrary.simpleMessage(
            "Raportet e Humbjes/Së Fitimit"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Alarm për stok të ulët"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Krijojini një përshtypje të qëndrueshme te klientët tuaj me fatura të markuara. Përditësimi ynë pa kufi ofron avantazhin unik të përshtatjes së faturave tuaja, duke shtuar një prekje profesionale që përforcon identitetin tuaj të markës dhe përforcimi i besnikërisë së klientëve."),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("Menaxho biznesin tënd me"),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Data e prodhimit"),
        "margin": MessageLookupByLibrary.simpleMessage("Marzhi"),
        "masterCard": MessageLookupByLibrary.simpleMessage("Mastercard"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Prodhuesi"),
        "message": MessageLookupByLibrary.simpleMessage("Mesazh"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Historiku i Mesazheve"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Aplikacioni Pos Saas është falas dhe i lehtë për përdorim. Faktikisht, është një nga sistemet më të mira POS në botë."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas është një zgjidhje e plotë për biznesin me stok, llogari, shitje, shpenzime dhe humbje/profit."),
        "mobile": MessageLookupByLibrary.simpleMessage("Mobil"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("Pagesa mobile"),
        "monthly": MessageLookupByLibrary.simpleMessage("Mujore"),
        "moreInfo":
            MessageLookupByLibrary.simpleMessage("Më shumë Informacion"),
        "name": MessageLookupByLibrary.simpleMessage("Shkruani Emrin Tuaj."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Emri ekziston tashmë"),
        "nameCantBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Emri nuk mund të jetë i zbrazët"),
        "next": MessageLookupByLibrary.simpleMessage("Tjetra"),
        "noConnection": MessageLookupByLibrary.simpleMessage("Pa lidhje"),
        "noData": MessageLookupByLibrary.simpleMessage("Asnjë të dhënë"),
        "noDataAvailable": MessageLookupByLibrary.simpleMessage(
            "Nuk ka të dhëna të disponueshme"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Nuk u gjet asnjë të dhënë"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("Nuk u gjet histori!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Nuk u gjet asnjë produkt"),
        "noSubTaxSelected": MessageLookupByLibrary.simpleMessage(
            "Nuk është zgjedhur asnjë tatim nën"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("Nuk u gjet transaksion!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Nuk u gjet asnjë përdorues për atë email."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "Nuk u Gjet Roli i Përdoruesit"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Këtu ka përdorues të pasiv"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Nuk është ofruar"),
        "note": MessageLookupByLibrary.simpleMessage("Shënim"),
        "notes": MessageLookupByLibrary.simpleMessage("shënime"),
        "notification": MessageLookupByLibrary.simpleMessage("Njoftim"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP e dërguar në"),
        "office": MessageLookupByLibrary.simpleMessage("Zyra"),
        "ok": MessageLookupByLibrary.simpleMessage("Ok"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS që përmban një sasi të madhe të funksionalitetit, përfshirë ndjekjen e shitjeve dhe menaxhimin e inventarit."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Ky sistem ju ndihmon të përmirësoni operacionet tuaja për klientët tuaj."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Sistemi ynë POS duhet të thjeshtësojë operacionet ditore automatikisht, duke e bërë të lehtë navigimin."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("Bilanci Hapësirë"),
        "order": MessageLookupByLibrary.simpleMessage("Porosi"),
        "other": MessageLookupByLibrary.simpleMessage("Të tjera"),
        "otp": MessageLookupByLibrary.simpleMessage("Mbyll"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Nuk ka stok"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Pako"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Karakteristikat e Paketës"),
        "paid": MessageLookupByLibrary.simpleMessage("Paguar"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Shuma e Paguar"),
        "parties": MessageLookupByLibrary.simpleMessage("Pjesëmarrësit"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Lista e Partive"),
        "partyGST": MessageLookupByLibrary.simpleMessage("GST i palës"),
        "partyName": MessageLookupByLibrary.simpleMessage("Emri i Partisë"),
        "password": MessageLookupByLibrary.simpleMessage("Fjalëkalimi"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Fjalëkalimi dhe konfirmimi i fjalëkalimit nuk përputhen"),
        "passwordCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Fjalëkalimi nuk mund të jetë bosh"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("Fjalëkalimi nuk përputhet"),
        "payCash":
            MessageLookupByLibrary.simpleMessage("Paguani me Para të Gjendura"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("Paguhuni me bkash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Paguaj me Paypal"),
        "payeeName": MessageLookupByLibrary.simpleMessage("Emri i Pagesësit"),
        "payeeNumber":
            MessageLookupByLibrary.simpleMessage("Numri i Pagesësit"),
        "payment": MessageLookupByLibrary.simpleMessage("Pagesa"),
        "paymentAmount":
            MessageLookupByLibrary.simpleMessage("Shuma e Pagesës"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Pagesa e Kompletuar"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Udhëzime për Pagesën:"),
        "paymentMethod":
            MessageLookupByLibrary.simpleMessage("Metoda e Pagesës"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Lloji i Pagesës"),
        "pdfView": MessageLookupByLibrary.simpleMessage("Pamja PDF"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Informacion personal"),
        "phone": MessageLookupByLibrary.simpleMessage("Telefon"),
        "phoneNumber":
            MessageLookupByLibrary.simpleMessage("Numri i Telefonit"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Numri i telefonit është përdorur tashmë"),
        "phoneNumberIsNotValid": MessageLookupByLibrary.simpleMessage(
            "Numri i telefonit nuk është i vlefshëm"),
        "phoneNumberIsRequired": MessageLookupByLibrary.simpleMessage(
            "Numri i telefonit është i nevojshëm"),
        "pickAndUploadFile": MessageLookupByLibrary.simpleMessage(
            "Zgjidhni dhe ngarkoni skedarin"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("Zgjidh Datën e Përfundimit"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Zgjidh Datën e Fillimit"),
        "plan": MessageLookupByLibrary.simpleMessage("Plan"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("Ju lutemi shtoni sasinë"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Ju lutemi kontrolloni lidhjen tuaj me internetin"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Ju lutem lidheni printerin së pari"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Ju lutemi lidhni printerin tuaj Bluetooth"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Ju lutem shkruani një fjalëkalim më të madh"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Ju lutemi shkruani një fjalëkalim të konfirmuar"),
        "pleaseEnterAPassword": MessageLookupByLibrary.simpleMessage(
            "Ju lutemi shkruani një fjalëkalim"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Ju lutem shkruani një email të vlefshëm"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Ju lutem shkruani emrin"),
        "pleaseEnterPassword": MessageLookupByLibrary.simpleMessage(
            "Ju lutemi, shkruani fjalëkalimin"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Ju lutemi shkruani adresën tuaj të emailit më poshtë për të marrë Lidhjen e Rivendosjes së Fjalëkalimit."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Ju lutemi vendosni numrin e transaksionit"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("Ju lutem shkruani shumën"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Ju lutem zgjidhni një kategori së pari"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("Ju lutemi zgjidhni një plan"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Ju lutem zgjidhni kategorinë e biznesit"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Ju lutemi përdorni kodin e vlefshëm të blerjes për të përdorur aplikacionin"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Ndërtohet nga Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Financuar Nga"),
        "premiumCustomerSupport": MessageLookupByLibrary.simpleMessage(
            "Mbështetja Premium për Klientët"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Paketa Premium"),
        "previousPayAmounts": MessageLookupByLibrary.simpleMessage(
            "Shumët e Pagesave të Mëparshme"),
        "price": MessageLookupByLibrary.simpleMessage("çmimi"),
        "print": MessageLookupByLibrary.simpleMessage("Printo"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Opsioni i Printimit"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Politika e Privatësisë"),
        "product": MessageLookupByLibrary.simpleMessage("Produkti"),
        "productCode": MessageLookupByLibrary.simpleMessage("Kodi i Produktit"),
        "productCodeIsRequired": MessageLookupByLibrary.simpleMessage(
            "Kodi i produktit është i nevojshëm"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Kodi/Emri i Produktit"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Përshkrimi i Produktit"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Detajet e produktit"),
        "productList":
            MessageLookupByLibrary.simpleMessage("Lista e Produktit"),
        "productName": MessageLookupByLibrary.simpleMessage("Emri i Produktit"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Emri i produktit ekziston tashmë në këtë depo"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Emri i produktit është shtuar tashmë"),
        "productNameIsRequired": MessageLookupByLibrary.simpleMessage(
            "Emri i produktit është i nevojshëm"),
        "products": MessageLookupByLibrary.simpleMessage("Produkte"),
        "profile": MessageLookupByLibrary.simpleMessage("Profil"),
        "profileEdit":
            MessageLookupByLibrary.simpleMessage("Ndryshoni Profilin"),
        "profit": MessageLookupByLibrary.simpleMessage("Fitim"),
        "promo": MessageLookupByLibrary.simpleMessage("Promocioni"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Kodi i Promocionit"),
        "purchase": MessageLookupByLibrary.simpleMessage("Blerja"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("Alarmi i Blerjes"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Blerja e Konfirmuar"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Detajet e Blerjes"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Fatura e Blerjes"),
        "purchaseList":
            MessageLookupByLibrary.simpleMessage("Lista e Blerjeve"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Blerje Tani"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Bleni Paketën Premium"),
        "purchasePrice":
            MessageLookupByLibrary.simpleMessage("Çmimi i Blerjes"),
        "purchasePriceIsRequired": MessageLookupByLibrary.simpleMessage(
            "Çmimi i blerjes është i nevojshëm"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("Raporti i Blerjeve"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Raporti i Blerjes"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Raporte për blerjet"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("Kthimi i Blerjes"),
        "purchaseReturnReport": MessageLookupByLibrary.simpleMessage(
            "Raporti i Kthimit të Blerjeve"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Kalimi i Blerjes"),
        "qty": MessageLookupByLibrary.simpleMessage("Sasia"),
        "quantity": MessageLookupByLibrary.simpleMessage("Sasia"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Transaksione të Fundit"),
        "recivedThePin": MessageLookupByLibrary.simpleMessage("Merr Pin-in"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Numri i Referencës"),
        "register": MessageLookupByLibrary.simpleMessage("Regjistrohu"),
        "registering": MessageLookupByLibrary.simpleMessage("Regjistrimi"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("Borxhi i Mbetur"),
        "remove": MessageLookupByLibrary.simpleMessage("Hiq"),
        "reports": MessageLookupByLibrary.simpleMessage("Raportet"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Kërkesa është dërguar"),
        "resendCode": MessageLookupByLibrary.simpleMessage("Ridërgoni Kodin"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("Ridërgoni OTP-në: "),
        "retailer": MessageLookupByLibrary.simpleMessage("Pikëshitës"),
        "retur": MessageLookupByLibrary.simpleMessage("Kthim"),
        "returN": MessageLookupByLibrary.simpleMessage("Kthim"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("Shuma e Kthimit"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("Shuma e Kthimit"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("Sasia e Kthimit"),
        "revenue": MessageLookupByLibrary.simpleMessage("Të ardhurat"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Mbrojini të dhënat e biznesit tuaj pa mundim. Përditësimi ynë pa kufi Pos Saas POS përfshin kopjimin e të dhënave falas, duke siguruar që informacioni juaj i çmuar është i mbrojtur nga ngjarjet e papritura. Përparoni atë që është vërtetë e rëndësishme - rritjen e biznesit tuaj."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Shuma e Shitjes"),
        "saleDetails":
            MessageLookupByLibrary.simpleMessage("Detajet e Shitjes"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Çmimi i Shitjes"),
        "saleReports":
            MessageLookupByLibrary.simpleMessage("Raporti i Shitjeve"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Raporte për shitjet"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("Kthimi i Shitjes"),
        "saleReturnReport": MessageLookupByLibrary.simpleMessage(
            "Raporti i Kthimit të Shitjes"),
        "saleSetting":
            MessageLookupByLibrary.simpleMessage("Cilësimi i Shitjes"),
        "sales": MessageLookupByLibrary.simpleMessage("Shitjet"),
        "salesAndPurchaseReports": MessageLookupByLibrary.simpleMessage(
            "Raportet e shitjes dhe blerjes"),
        "salesList": MessageLookupByLibrary.simpleMessage("Lista e Shitjeve"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("Kthimi i Shitjes"),
        "save": MessageLookupByLibrary.simpleMessage("Ruaj"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Ruaj dhe Publiko"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("Ruaj Ndryshimet"),
        "saving": MessageLookupByLibrary.simpleMessage("Duke ruajtur"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("Skano kodin QR të produktit"),
        "search": MessageLookupByLibrary.simpleMessage("Kërko"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Kërkoni me kodin ose emrin e produktit"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("Shiko të gjitha kodet promo"),
        "select": MessageLookupByLibrary.simpleMessage("Zgjidh"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Zgjidhni një produkt për kthim"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Zgjidhni markën"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Zgjidhni kategorinë"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Zgjidh Kontakte"),
        "selectProductCategory": MessageLookupByLibrary.simpleMessage(
            "Zgjidhni kategorinë e produktit"),
        "selectShopCategory": MessageLookupByLibrary.simpleMessage(
            "Zgjidhni kategorinë e dyqanit"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Zgjidhni tatimin"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Zgjidhni llojin e tatimit"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("Zgjidhni njësinë"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Zgjidhni Variacionin: "),
        "seller": MessageLookupByLibrary.simpleMessage("Shitësi"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Shitjet nga"),
        "send": MessageLookupByLibrary.simpleMessage("Dërgo"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("Dërgo Email"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Dërgo Mesazh"),
        "sendResetLink": MessageLookupByLibrary.simpleMessage(
            "Dërgoni Lidhjen e Rivendosjes"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Dërgo SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Dërgo sms?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Dërgo mesazh në WhatsApp"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Dërgo Emailin Tënd"),
        "sendingEmail":
            MessageLookupByLibrary.simpleMessage("Dërgimi i Emailit"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Dërgimi i mesazhit"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Shërbimi/Dërgesa"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Vendos Profilin Tënd"),
        "setting": MessageLookupByLibrary.simpleMessage("Cilësimet"),
        "share": MessageLookupByLibrary.simpleMessage("Ndaj"),
        "shopGST": MessageLookupByLibrary.simpleMessage("GST i dyqanit"),
        "signIn": MessageLookupByLibrary.simpleMessage("Hyni"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("Hyni me email"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Nënshkrimi i Klientit"),
        "size": MessageLookupByLibrary.simpleMessage("Madhësia"),
        "skip": MessageLookupByLibrary.simpleMessage("Kalo"),
        "sms": MessageLookupByLibrary.simpleMessage("Sms"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Marketingu Social"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Na vjen keq, nuk keni leje për të aksesuar këtë shërbim"),
        "startDate": MessageLookupByLibrary.simpleMessage("Data e Fillimit"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Fillo Shitjen e Re"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage(
            "Filloni të shkruani për të kërkuar"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Qëndroni në krye të zhvillimeve teknologjike pa kosto të shtuara. Pos Saas POS Unlimited Upgrade ynë siguron që ju gjithmonë keni mjete dhe karakteristika të fundit në dorën tuaj, garantuar që biznesi juaj mbetet në përparim."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("Akoma e Papaguar"),
        "stock": MessageLookupByLibrary.simpleMessage("Stoku"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Stoku është i nevojshëm"),
        "stockList": MessageLookupByLibrary.simpleMessage("Lista e stoqeve"),
        "stocks": MessageLookupByLibrary.simpleMessage("Stoku"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Leja e ruajtjes është e nevojshme për të krijuar skedarin Excel"),
        "subTaxList":
            MessageLookupByLibrary.simpleMessage("Lista e Tatimeve Nën"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Tatimet Nën"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Nëntotali"),
        "submit": MessageLookupByLibrary.simpleMessage("Dërgo"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "Abonohuni në\\nYoutube-n tonë"),
        "subscription": MessageLookupByLibrary.simpleMessage("Abonimi"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Kryer me sukses"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Çregjistruar me sukses"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("U përditësua me sukses"),
        "supplier": MessageLookupByLibrary.simpleMessage("Furnizues"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("Emri i Furnizuesit"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("Kodi SWIFT"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Merrni një licensë drejtuese, kartë identiteti kombëtar ose pasaportë"),
        "takeaNidCardToCheckYourInformation": MessageLookupByLibrary.simpleMessage(
            "Merrni një kartë identiteti për të kontrolluar informacionin tuaj"),
        "tap": MessageLookupByLibrary.simpleMessage("Trokitni"),
        "tax": MessageLookupByLibrary.simpleMessage("Tatimi"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Grupi i taksave"),
        "taxPercentage":
            MessageLookupByLibrary.simpleMessage("Përqindja e Tatimit"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Norma e taksës"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Normat e taksave - Menaxhoni normat tuaja të taksave"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Raporti i taksave"),
        "taxType": MessageLookupByLibrary.simpleMessage("Lloji i tatimit"),
        "taxes": MessageLookupByLibrary.simpleMessage("Tatimet"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Kushtet dhe kushtet"),
        "termsOfUse":
            MessageLookupByLibrary.simpleMessage("Kushtet e Përdorimit"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Kushtet & Privatësia"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Ju faleminderit për Pagesën Tuaj të Borxhit"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Faleminderit"),
        "thankYouForYourPurchase": MessageLookupByLibrary.simpleMessage(
            "Ju faleminderit për blerjen tuaj"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "Llogaria tashmë ekziston për atë email"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Skedari Excel është shkarkuar tashmë"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Emri thotë të gjithë. Me Pos Saas POS Unlimited, nuk ka kufi për përdorimin tuaj. Pavarësisht nëse po përpunoni një dorëplote transaksione ose po përjetoni një rrjedhje të klientëve, mund të operoni me vetëbesim, duke ditur që nuk jeni të kufizuar nga kufijtë."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "Fjalëkalimi i dhënë është shumë i dobët"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Shitja do të fshihet dhe të gjitha të dhënat do të fshihen rreth kësaj blerjeje. A jeni të sigurt që dëshironi ta fshini këtë?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Shitja do të fshihet dhe të gjitha të dhënat do të fshihen rreth kësaj shitjeje. A jeni të sigurt që dëshironi ta fshini këtë?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Përdoruesi do të fshihet dhe të gjitha të dhënat do të fshihen nga llogaria juaj. Jeni të sigurt që dëshironi ta fshini këtë?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Përdoruesi do të fshihet dhe të gjitha të dhënat do të fshihen nga llogaria juaj. A jeni të sigurt që dëshironi të fshini këtë?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Shërbimet e palëve të treta"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Kjo kategori nuk mund të fshihet"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Ky Muaj)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Ky produkt është shtuar tashmë"),
        "title": MessageLookupByLibrary.simpleMessage("Titulli"),
        "titleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Titulli nuk mund të jetë bosh"),
        "to": MessageLookupByLibrary.simpleMessage("në"),
        "toDate": MessageLookupByLibrary.simpleMessage("Deri në Datë"),
        "today": MessageLookupByLibrary.simpleMessage("Sot"),
        "total": MessageLookupByLibrary.simpleMessage("Totali"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Shuma Totale"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Shuma Totale e Grumbulluar"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Totali i Borxheve"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("Shpenzimi Total"),
        "totalLoss":
            MessageLookupByLibrary.simpleMessage("Shuma totale e humbjes"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("Totali për të Paguar"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Çmimi Total"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("Produkte totale"),
        "totalProfit":
            MessageLookupByLibrary.simpleMessage("Shuma totale e fitimit"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("Blerja Totale"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Shuma Totale e Kthimit"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("Kthimet Totale"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Shitje Totale"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Stoku Total"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Vlera totale"),
        "totalVat": MessageLookupByLibrary.simpleMessage("TVSH Total"),
        "totals": MessageLookupByLibrary.simpleMessage("Totali: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Transaksioni"),
        "transactionId":
            MessageLookupByLibrary.simpleMessage("ID e Transaksionit"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Provo Përsëri"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Lloji"),
        "unitName": MessageLookupByLibrary.simpleMessage("Emri i Njësisë"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Çmimi për Njësi"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Çmimi për Njësi"),
        "units": MessageLookupByLibrary.simpleMessage("Njësitë"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Të pakufizuar"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Përdorimi pa Kufi"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Ondo çdo potencial të Pos Saas POS me sesione trajnimi të personalizuar të drejtuar nga ekipi ynë i ekspertëve. Nga themeloret deri te teknikat e avancuara, ne sigurojmë që jeni të aftë në përdorimin e çdo aspekti të sistemit për të optimizuar proceset e biznesit tuaj."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Të papaguara"),
        "update": MessageLookupByLibrary.simpleMessage("Përditëso"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Përditëso Kontaktin"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Përditëso Tani"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("Përditëso Produktin"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Përditësoni planin tuaj së pari, \\ndozita juaj ka përfunduar"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Përditësoni Profilin Tuaj"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Përditësoni profilin tuaj për të lidhur mjekun tuaj me përshtypje më të mirë"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Përditësoni profilin tuaj për të lidhur klientin tuaj me përshtypje më të mirë"),
        "updated": MessageLookupByLibrary.simpleMessage("Përditësuar"),
        "upload": MessageLookupByLibrary.simpleMessage("Ngarko"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Ngarko Dokumentin"),
        "uploadDone":
            MessageLookupByLibrary.simpleMessage("Ngarkimi është bërë"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Ngarko Dosjen"),
        "usbC": MessageLookupByLibrary.simpleMessage("Usb C"),
        "use": MessageLookupByLibrary.simpleMessage("Përdor"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("Përdorni Pos Saas"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Përdorimi i sistemit"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Përdoruesi është fshirë"),
        "userRole": MessageLookupByLibrary.simpleMessage("Roli i Përdoruesit"),
        "userRoleDetails": MessageLookupByLibrary.simpleMessage(
            "Detajet e Rolit të Përdoruesit"),
        "userTitle":
            MessageLookupByLibrary.simpleMessage("Titulli i Përdoruesit"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Titulli i përdoruesit nuk mund të jetë i zbrazët"),
        "value": MessageLookupByLibrary.simpleMessage("Vlera"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("TVSH nuk aplikohet"),
        "verifyOtp":
            MessageLookupByLibrary.simpleMessage("Po verifikohet OTP-ja"),
        "verifyPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Verifikoni Numrin e Telefonit"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Shiko të Gjitha"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("Shiko Detajet"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Klienti i ardhur pa ftesë"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Depo"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Magazina ekziston tashmë"),
        "warehouseList":
            MessageLookupByLibrary.simpleMessage("Lista e magazinave"),
        "warehouseName":
            MessageLookupByLibrary.simpleMessage("Emri i magazinës"),
        "warranty": MessageLookupByLibrary.simpleMessage("Garancia"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Kemi dërguar një email me udhëzime për të rivendosur fjalëkalimin te:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Mund të përdorim shërbimet e palëve të treta për të mbështetur funksionalitetin e aplikacionit tonë, si ofruesit e analizës dhe procesorët e pagesave. Këto shërbime e palëve të treta mund të mbledhin informacion rreth jush kur përdorni aplikacionin tonë. Ju lutemi vini re se nuk jemi përgjegjës për praktikat e mbrojtjes së privatësisë të këtyre shërbimeve të palëve të treta."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Ne marrim masa standarde të industrisë për të mbrojtur informacionin tuaj personal, përfshirë shifrime dhe ruajtjen e sigurt. Gjithashtu kufizojmë qasjen në informacionin tuaj vetëm për personelin e autorizuar."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Ne kuptojmë rëndësinë e operacioneve të padëmshme. Prandaj, mbështetja jonë 24 orëshe është e gatshme për t\'ju ndihmuar, për çdo pyetje të shpejtë ose shqetësim të gjerë. Lidhuni me ne në çdo kohë dhe në çdo vend përmes thirrjeve ose WhatsApp për të përjetuar shërbimin e pazëvendësueshëm për klientët."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Ne përdorim informacionin tuaj personal për t\'ju ofruar përvojën më të mirë të mundshme në aplikacionin tonë, duke përshtatur rekomandimet për përmbajtjen tuaj, lidhur ju me ekspertë dhe përmirësuar funksionalitetin e aplikacioneve tona. Mund të përdorim gjithashtu informacionin tuaj për të komunikuar me ju në lidhje me përditësime, promovime ose informacione të tjera në lidhje me aplikacionin tonë."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Ne do ta rishikojmë pagesën dhe do ta miratojmë brenda 1-2 orësh"),
        "weekly": MessageLookupByLibrary.simpleMessage("Javor"),
        "weight": MessageLookupByLibrary.simpleMessage("Pesha"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Çfarë ka të re"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Shitës me shumicë"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Çmimi për Shitje me Shumicë"),
        "wholesalePrice":
            MessageLookupByLibrary.simpleMessage("Çmimi me shumicë"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Shitës me shumicë"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Do të shtohet së shpejti"),
        "willExpireAt":
            MessageLookupByLibrary.simpleMessage("Do të skadojë në"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Shkruani mesazhin tuaj këtu"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("OTP i gabuar"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "U dhënë një fjalëkalim i gabuar për atë përdorues."),
        "yearly": MessageLookupByLibrary.simpleMessage("Vjetore"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Po, Fshije Përgjithmonë"),
        "youAreNotAValidUser": MessageLookupByLibrary.simpleMessage(
            "Ju nuk jeni një përdorues i vlefshëm"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Po përdorni"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Nuk mund të paguani më shumë se shuma e borxhit"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Keni marrë një email"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Jeni hyrë me sukses në llogarinë tuaj. Qëndroni me Pos Saas."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("Duhet të jepni leje"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Duhet të RILIDHNI në llogarinë tuaj."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Duhet të verifikoni identitetin tuaj para se të blini sms"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Mesazhi juaj mbetet"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Paketa Juaj"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Paketa juaj do të skadojë pas 5 ditësh")
      };
}
