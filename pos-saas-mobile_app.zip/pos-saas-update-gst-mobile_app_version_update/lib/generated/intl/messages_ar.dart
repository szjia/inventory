// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a ar locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'ar';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("متابعة"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("رقم GST"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("السعر القصوى للبيع"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("سعر البيع مطلوب"),
        "OK": MessageLookupByLibrary.simpleMessage("حسنا"),
        "POSsAAS":
            MessageLookupByLibrary.simpleMessage("نظام نقاط البيع السحابي"),
        "Paypal": MessageLookupByLibrary.simpleMessage("باي بال"),
        "PhNo": MessageLookupByLibrary.simpleMessage("رقم الهاتف"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("رقم تسلسلي"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("كود سويفت"),
        "Snacks": MessageLookupByLibrary.simpleMessage("وجبات خفيفة"),
        "TAX": MessageLookupByLibrary.simpleMessage("ضريبة"),
        "Uploading": MessageLookupByLibrary.simpleMessage("جارٍ التحميل"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("عنوان المستخدم"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "ستنتهي صلاحية باقتك اليوم\n\nيرجى الشراء مرة أخرى"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(أ) يتم توفير النظام فقط لغرض تيسير عمليات نقاط البيع والأنشطة ذات الصلة في عملك."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(أ) لاستخدام النظام، قد يُطلب منك إنشاء حساب. أنت توافق على تقديم معلومات دقيقة وحديثة وكاملة أثناء عملية التسجيل وتحديث هذه المعلومات للحفاظ على دقتها واكتمالها."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("حول التطبيق"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("معلومات عنا"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("قبول الشروط"),
        "accountName": MessageLookupByLibrary.simpleMessage("اسم الحساب"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("رقم الحساب"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("تسجيل الحساب"),
        "acton": MessageLookupByLibrary.simpleMessage("إجراء"),
        "add": MessageLookupByLibrary.simpleMessage("إضافة"),
        "addBrand": MessageLookupByLibrary.simpleMessage("إضافة علامة تجارية"),
        "addCategory": MessageLookupByLibrary.simpleMessage("إضافة فئة"),
        "addContact": MessageLookupByLibrary.simpleMessage("إضافة جهة اتصال"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("إضافة عميل"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("إضافة تسليم"),
        "addDescriptioN": MessageLookupByLibrary.simpleMessage("إضافة وصف"),
        "addDescription": MessageLookupByLibrary.simpleMessage("إضافة ملاحظة"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("إضافة خصم"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("إضافة معرف وثيقة"),
        "addDucument": MessageLookupByLibrary.simpleMessage("إضافة وثيقة"),
        "addExpense": MessageLookupByLibrary.simpleMessage("إضافة مصروف"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("إضافة فئة المصروف"),
        "addItems": MessageLookupByLibrary.simpleMessage("إضافة منتجات"),
        "addNew": MessageLookupByLibrary.simpleMessage("إضافة جديدة"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("إضافة عنوان جديد"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("إضافة منتج جديد"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("إضافة ضريبة جديدة"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "إضافة ضريبة جديدة مع نوع ضريبة واحد / متعدد"),
        "addNote": MessageLookupByLibrary.simpleMessage("إضافة ملاحظة"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("أضف المنتج أولاً"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("إضافة رمز ترويجي"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("إضافة شراء"),
        "addSales": MessageLookupByLibrary.simpleMessage("إضافة مبيعات"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("تمت الإضافة بنجاح"),
        "addUnit": MessageLookupByLibrary.simpleMessage("إضافة وحدة"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("إضافة دور المستخدم"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("تم الإضافة بنجاح"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("تمت إضافته إلى السلة"),
        "address": MessageLookupByLibrary.simpleMessage("العنوان"),
        "admin": MessageLookupByLibrary.simpleMessage("مدير"),
        "all": MessageLookupByLibrary.simpleMessage("الكل"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("جميع حلول الأعمال"),
        "alreadyAdded":
            MessageLookupByLibrary.simpleMessage("تمت إضافته بالفعل"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("موجود بالفعل"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("هل لديك حساب بالفعل"),
        "amount": MessageLookupByLibrary.simpleMessage("المبلغ"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "تم إرسال بريد إلكتروني\\nتحقق من صندوق الوارد الخاص بك"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "دعم تطبيق الأندرويد وآي أو إس"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("الضريبة المطبقة"),
        "apply": MessageLookupByLibrary.simpleMessage("تطبيق"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "هل أنت متأكد من حذف هذه الفاتورة؟"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "هل أنت متأكد من حذف هذه العملية؟"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "هل أنت متأكد من حذف هذا المستخدم؟"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "هل أنت متأكد أنك تريد حذف هذه الضريبة؟"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "هل أنت متأكد أنك تريد حذف مجموعة الضرائب هذه؟"),
        "areYouWantToDeleteThisWarehouse":
            MessageLookupByLibrary.simpleMessage("هل تريد حذف هذا المستودع؟"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "هل أنت متأكد من حذف هذا المستخدم؟"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("التوقيع المخول"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(ب) أنت مسؤول عن الحفاظ على سرية حسابك وكلمة المرور الخاصة بك وتقييد الوصول إلى حسابك. أنت تتحمل المسؤولية عن جميع الأنشطة التي تحدث تحت حسابك."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(ب) يجب أن تكون على الأقل 18 عامًا أو السن القانوني للبلوغ في اختصاصك لاستخدام النظام."),
        "backSide": MessageLookupByLibrary.simpleMessage("الجانب الخلفي"),
        "backToHome":
            MessageLookupByLibrary.simpleMessage("العودة إلى الصفحة الرئيسية"),
        "balance": MessageLookupByLibrary.simpleMessage("الرصيد"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("بنجلاديش"),
        "bank": MessageLookupByLibrary.simpleMessage("بنك"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("عملة حساب البنك"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("عملة الحساب البنكي"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("معلومات البنك"),
        "bankName": MessageLookupByLibrary.simpleMessage("اسم البنك"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("تحويل مصرفي"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("تم العثور على رمز الشريط"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("فاتورة"),
        "billTo": MessageLookupByLibrary.simpleMessage("فاتورة إلى"),
        "branchName": MessageLookupByLibrary.simpleMessage("اسم الفرع"),
        "brand": MessageLookupByLibrary.simpleMessage("العلامة التجارية"),
        "brandName":
            MessageLookupByLibrary.simpleMessage("اسم العلامة التجارية"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("تحميل جماعي"),
        "businessCategory": MessageLookupByLibrary.simpleMessage("فئة العمل"),
        "buy": MessageLookupByLibrary.simpleMessage("شراء"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("شراء الباقة المميزة"),
        "buySms": MessageLookupByLibrary.simpleMessage("شراء رسائل نصية"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "من خلال الوصول إلى أو استخدام نظام نقاط البيع (POS) (النظام) الذي توفره [اسم شركتك] (الشركة)، أنت توافق على الالتزام بهذه الشروط والأحكام. إذا لم توافق على هذه الشروط والأحكام، فلا تستخدم النظام."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(ج) أنت مسؤول عن ضمان أن وصولك واستخدامك للنظام يتماشى مع جميع القوانين واللوائح المعمول بها."),
        "cacel": MessageLookupByLibrary.simpleMessage("إلغاء"),
        "call": MessageLookupByLibrary.simpleMessage("اتصال"),
        "callForEmergencySupport":
            MessageLookupByLibrary.simpleMessage("اتصل للحصول على دعم طارئ"),
        "camera": MessageLookupByLibrary.simpleMessage("الكاميرا"),
        "cancel": MessageLookupByLibrary.simpleMessage("إلغاء"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("إلغاء جميع المنتجات"),
        "capacity": MessageLookupByLibrary.simpleMessage("السعة"),
        "card": MessageLookupByLibrary.simpleMessage("بطاقة"),
        "cash": MessageLookupByLibrary.simpleMessage("نقدًا"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("الفئات"),
        "category": MessageLookupByLibrary.simpleMessage("الفئة"),
        "categoryName": MessageLookupByLibrary.simpleMessage("اسم الفئة"),
        "categoryNameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("اسم الفئة موجود بالفعل"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("اسم الفئة"),
        "change": MessageLookupByLibrary.simpleMessage("تغيير؟"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("تغيير كلمة المرور"),
        "checkEmail":
            MessageLookupByLibrary.simpleMessage("تحقق من البريد الإلكتروني"),
        "choseACustomer": MessageLookupByLibrary.simpleMessage("اختر عميلاً"),
        "choseASupplier": MessageLookupByLibrary.simpleMessage("اختر موردًا"),
        "choseYourFeature": MessageLookupByLibrary.simpleMessage("اختر ميزاتك"),
        "clarence": MessageLookupByLibrary.simpleMessage("كلارنس"),
        "clickToConnect": MessageLookupByLibrary.simpleMessage("انقر للاتصال"),
        "close": MessageLookupByLibrary.simpleMessage("إغلاق"),
        "color": MessageLookupByLibrary.simpleMessage("اللون"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(مجموعة من الضرائب المتعددة)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("قريبًا"),
        "companyAddress": MessageLookupByLibrary.simpleMessage("عنوان الشركة"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("اسم الشركة والمتجر"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("اسم الشركة / العمل"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("اكتمال العملية"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("تأكيد كلمة المرور"),
        "confirmReturn": MessageLookupByLibrary.simpleMessage("تأكيد الإرجاع"),
        "congratulations": MessageLookupByLibrary.simpleMessage("تهانينا"),
        "contactUs": MessageLookupByLibrary.simpleMessage("اتصل بنا"),
        "continu": MessageLookupByLibrary.simpleMessage("متابعة"),
        "country": MessageLookupByLibrary.simpleMessage("البلد"),
        "create": MessageLookupByLibrary.simpleMessage("إنشاء"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("إنشاء حساب مجاني"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("تم الإنشاء والحفظ"),
        "currency": MessageLookupByLibrary.simpleMessage("العملة"),
        "currentStock": MessageLookupByLibrary.simpleMessage("المخزون الحالي"),
        "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
            "تخصيص فواتير العلامة التجارية"),
        "customer": MessageLookupByLibrary.simpleMessage("الزبون"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("تفاصيل العميل"),
        "customerGST": MessageLookupByLibrary.simpleMessage("GST العميل"),
        "customerName": MessageLookupByLibrary.simpleMessage("اسم العميل"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("المعاملات اليومية"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("نظرة عامة على لوحة التحكم"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("تم حفظ البيانات بنجاح"),
        "date": MessageLookupByLibrary.simpleMessage("التاريخ"),
        "day": MessageLookupByLibrary.simpleMessage("يوم"),
        "dealer": MessageLookupByLibrary.simpleMessage("تاجر"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("سعر التجزئة"),
        "defaultVATPercentage": MessageLookupByLibrary.simpleMessage(
            "نسبة ضريبة القيمة المضافة الافتراضية"),
        "delete": MessageLookupByLibrary.simpleMessage("يمسح"),
        "deleting": MessageLookupByLibrary.simpleMessage("جارٍ الحذف"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("عنوان التسليم"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("عناوين التسليم"),
        "deliveryCharge": MessageLookupByLibrary.simpleMessage("رسوم التوصيل"),
        "describtion": MessageLookupByLibrary.simpleMessage("الوصف"),
        "description": MessageLookupByLibrary.simpleMessage("وصف"),
        "descriptionCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "لا يمكن أن يكون الوصف فارغًا"),
        "details": MessageLookupByLibrary.simpleMessage("تفاصيل"),
        "discount": MessageLookupByLibrary.simpleMessage("خصم"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("عدم الإزعاج"),
        "done": MessageLookupByLibrary.simpleMessage("تم"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("تنزيل تنسيق Excel"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "تم التنزيل بنجاح في مجلد التنزيلات"),
        "due": MessageLookupByLibrary.simpleMessage("مستحق"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("مبلغ المستحق: "),
        "dueCollection": MessageLookupByLibrary.simpleMessage("جمع المستحقات"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("تقارير التحصيل المستحقة"),
        "dueList": MessageLookupByLibrary.simpleMessage("قائمة المستحقات"),
        "dueReports": MessageLookupByLibrary.simpleMessage("تقرير الديون"),
        "duration": MessageLookupByLibrary.simpleMessage("المدة"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("المدة: من"),
        "easyToUseMobilePos":
            MessageLookupByLibrary.simpleMessage("POS المحمول سهل الاستخدام"),
        "edit": MessageLookupByLibrary.simpleMessage("تحرير"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("تحرير فاتورة الشراء"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("تحرير فاتورة المبيعات"),
        "editSocailMedia": MessageLookupByLibrary.simpleMessage(
            "تحرير وسائل التواصل الاجتماعي"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("تم التحرير بنجاح"),
        "editTax": MessageLookupByLibrary.simpleMessage("تحرير الضريبة"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("تحرير مجموعة الضرائب"),
        "editWarehouse": MessageLookupByLibrary.simpleMessage("تحرير المستودع"),
        "email": MessageLookupByLibrary.simpleMessage("البريد الإلكتروني"),
        "emailAddress":
            MessageLookupByLibrary.simpleMessage("عنوان البريد الإلكتروني"),
        "emailCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "لا يمكن أن يكون البريد الإلكتروني فارغًا"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "تم إرسال البريد الإلكتروني! تحقق من صندوق الوارد الخاص بك"),
        "endDate": MessageLookupByLibrary.simpleMessage("تاريخ الانتهاء"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("يرجى إدخال مبلغ صحيح"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("أدخل خصمًا صالحًا"),
        "enterAValidPhoneNumber":
            MessageLookupByLibrary.simpleMessage("يرجى إدخال رقم هاتف صحيح"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("أدخل سعرًا صالحًا"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("أدخل كمية صالحة"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("أدخل العنوان"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("أدخل المبلغ"),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("أدخل اسم العلامة التجارية"),
        "enterCapacity": MessageLookupByLibrary.simpleMessage("أدخل السعة"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("أدخل اسم الفئة"),
        "enterColor": MessageLookupByLibrary.simpleMessage("أدخل اللون"),
        "enterCustomerGstNumber":
            MessageLookupByLibrary.simpleMessage("أدخل رقم GST للعميل"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("أدخل سعر التجزئة"),
        "enterDescription": MessageLookupByLibrary.simpleMessage("أدخل الوصف"),
        "enterDiscount": MessageLookupByLibrary.simpleMessage("أدخل الخصم"),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("أدخل تاريخ المصروف"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("أدخل العنوان بالكامل"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("أدخل رقم الفاتورة"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "أدخل كمية تنبيه انخفاض المخزون"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("أدخل اسم المصنع"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("أدخل محتوى الرسالة"),
        "enterMrpOrRetailerPirce":
            MessageLookupByLibrary.simpleMessage("أدخل السعر القصوى للبيع"),
        "enterName": MessageLookupByLibrary.simpleMessage("أدخل الاسم"),
        "enterNote": MessageLookupByLibrary.simpleMessage("أدخل ملاحظة"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("أدخل اسم الحفلة"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("أدخل رقم الهاتف"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "أدخل رمز المنتج أو قم بالمسح"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("أدخل اسم المنتج"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("أدخل سعر الشراء"),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("أدخل الرقم المرجعي"),
        "enterSize": MessageLookupByLibrary.simpleMessage("أدخل الحجم"),
        "enterStocks":
            MessageLookupByLibrary.simpleMessage("أدخل الكمية المتوفرة"),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("أدخل معدل الضريبة"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("أدخل معرف المعاملة"),
        "enterType": MessageLookupByLibrary.simpleMessage("أدخل النوع"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("أدخل عنوان المستخدم"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("يرجى إدخال مبلغ صحيح"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("أدخل اسم المستودع"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("أدخل الوزن"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("أدخل سعر الجملة"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("أدخل وصفك هنا"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("أدخل عنوان بريدك الإلكتروني"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "أدخل عنوان ردود الفعل الخاص بك"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("يرجى إدخال رقم GST الخاص بك"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("أدخل رقم هاتفك المحمول"),
        "enterYourName": MessageLookupByLibrary.simpleMessage("أدخل اسمك"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("أدخل رقم هاتفك"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("أدخل كلمة المرور الخاصة بك"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("أدخل رقم هاتفك"),
        "enterYourTransactionId":
            MessageLookupByLibrary.simpleMessage("أدخل معرف العملية الخاص بك"),
        "error": MessageLookupByLibrary.simpleMessage("خطأ"),
        "excTax": MessageLookupByLibrary.simpleMessage("غير شامل الضريبة"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("رافع Excel"),
        "exclusive": MessageLookupByLibrary.simpleMessage("حصري"),
        "expense": MessageLookupByLibrary.simpleMessage("مصروف"),
        "expenseCategory": MessageLookupByLibrary.simpleMessage("فئة المصروف"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("تاريخ المصروف"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("المصروف لـ"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("تقرير المصروفات"),
        "expireDate":
            MessageLookupByLibrary.simpleMessage("تاريخ انتهاء الصلاحية"),
        "expired": MessageLookupByLibrary.simpleMessage("منتهي الصلاحية"),
        "expiring": MessageLookupByLibrary.simpleMessage("تنتهي صلاحيتها"),
        "failedWithError": MessageLookupByLibrary.simpleMessage("فشل مع خطأ"),
        "fashion": MessageLookupByLibrary.simpleMessage("أزياء"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "الميزات هي الجزء الهام الذي يجعل Pos Saas مختلفًا عن الحلول التقليدية."),
        "feedBack": MessageLookupByLibrary.simpleMessage("ردود الفعل"),
        "firstName": MessageLookupByLibrary.simpleMessage("الاسم الأول"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("تابعنا على\nفيسبوك"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("تابعنا على\nتويتر"),
        "fontSide": MessageLookupByLibrary.simpleMessage("الجانب الأمامي"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("للاستخدام غير المحدود"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("نسيت كلمة المرور"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("نسيت كلمة المرور؟"),
        "formDate": MessageLookupByLibrary.simpleMessage("من تاريخ"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("نسخ احتياطي للبيانات مجاني"),
        "freeLifeTimeUpdate":
            MessageLookupByLibrary.simpleMessage("تحديث مدى الحياة مجانًا"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("الباقة المجانية"),
        "freePlan": MessageLookupByLibrary.simpleMessage("الباقة المجانية"),
        "from": MessageLookupByLibrary.simpleMessage("(من"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("مدفوع بالكامل"),
        "gallary": MessageLookupByLibrary.simpleMessage("المعرض"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("جارٍ إنشاء PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("احصل على رمز التحقق"),
        "govermentId": MessageLookupByLibrary.simpleMessage("بطاقة حكومية"),
        "guest": MessageLookupByLibrary.simpleMessage("زائر"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("ليس لديك حساب؟"),
        "history": MessageLookupByLibrary.simpleMessage("التاريخ"),
        "home": MessageLookupByLibrary.simpleMessage("الصفحة الرئيسية"),
        "howWeProtectYourInformation":
            MessageLookupByLibrary.simpleMessage("كيف نحمي معلوماتك"),
        "howWeUseYourInformation":
            MessageLookupByLibrary.simpleMessage("كيف نستخدم معلوماتك"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("التحقق من الهوية"),
        "image": MessageLookupByLibrary.simpleMessage("صورة"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("لا يمكن حذف InHouse"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("لا يمكن تحرير InHouse"),
        "inWord": MessageLookupByLibrary.simpleMessage("بالكلمات"),
        "incTax": MessageLookupByLibrary.simpleMessage("شامل الضريبة"),
        "inclusive": MessageLookupByLibrary.simpleMessage("شامل"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("زيادة المخزون"),
        "invNo": MessageLookupByLibrary.simpleMessage("رقم الفاتورة"),
        "invoice": MessageLookupByLibrary.simpleMessage("فاتورة"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("رقم الفاتورة"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("إعدادات الفاتورة"),
        "invoiceViewer": MessageLookupByLibrary.simpleMessage("عارض الفواتير"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("تمت إضافة المنتج"),
        "kg": MessageLookupByLibrary.simpleMessage("كيلوغرام"),
        "kycVerification": MessageLookupByLibrary.simpleMessage("تحقق KYC"),
        "language": MessageLookupByLibrary.simpleMessage("اللغة"),
        "lastName": MessageLookupByLibrary.simpleMessage("الكنية"),
        "ledger": MessageLookupByLibrary.simpleMessage("دفتر الحسابات"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("شراء مدى الحياة"),
        "link": MessageLookupByLibrary.simpleMessage("رابط"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("لينكد إن"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("دعم الدردشة المباشرة"),
        "loading": MessageLookupByLibrary.simpleMessage("جاري التحميل"),
        "logIn": MessageLookupByLibrary.simpleMessage("تسجيل الدخول"),
        "logOUt": MessageLookupByLibrary.simpleMessage("تسجيل الخروج"),
        "logOut": MessageLookupByLibrary.simpleMessage("تسجيل الخروج"),
        "login": MessageLookupByLibrary.simpleMessage("تسجيل الدخول"),
        "logo": MessageLookupByLibrary.simpleMessage("شعار"),
        "loss": MessageLookupByLibrary.simpleMessage("خسارة"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("خسارة / ربح"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("تفاصيل الخسارة / الربح"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("تقرير الربح والخسارة"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("تقارير الربح والخسارة"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("تنبيه انخفاض المخزون"),
        "maan": MessageLookupByLibrary.simpleMessage("مان"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "اترك انطباعًا دائمًا على عملائك من خلال فواتير مخصصة بعلامتك التجارية. تقدم ترقية غير محدودة ميزة فريدة من نوعها لتخصيص فواتيرك ، مما يضيف لمسة احترافية تعزز هويتك العلامية ويعزز ولاءة العملاء."),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("قم بإدارة عملك باستخدام"),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("تاريخ التصنيع"),
        "margin": MessageLookupByLibrary.simpleMessage("هامش"),
        "masterCard": MessageLookupByLibrary.simpleMessage("بطاقة ماستر"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("المصنع"),
        "message": MessageLookupByLibrary.simpleMessage("رسالة"),
        "messageHistory": MessageLookupByLibrary.simpleMessage("سجل الرسائل"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "تطبيق Pos Saas مجاني وسهل الاستخدام. في الواقع، إنه واحد من أفضل أنظمة POS في جميع أنحاء العالم."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas هو حلاً كاملاً للأعمال مع المخزون والحساب والمبيعات والمصاريف والخسارة / الربح."),
        "mobile": MessageLookupByLibrary.simpleMessage("هاتف"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("دفع عبر الهاتف"),
        "monthly": MessageLookupByLibrary.simpleMessage("شهريًا"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("مزيد من المعلومات"),
        "name": MessageLookupByLibrary.simpleMessage("أدخل اسمك"),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("الاسم موجود بالفعل"),
        "nameCantBeEmpty": MessageLookupByLibrary.simpleMessage(
            "لا يمكن أن يكون الاسم فارغًا"),
        "next": MessageLookupByLibrary.simpleMessage("التالي"),
        "noConnection": MessageLookupByLibrary.simpleMessage("لا يوجد اتصال"),
        "noData": MessageLookupByLibrary.simpleMessage("لا توجد بيانات"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("لا تتوفر بيانات"),
        "noDataFound": MessageLookupByLibrary.simpleMessage("لا توجد بيانات"),
        "noHistoryFound": MessageLookupByLibrary.simpleMessage("لا توجد سجلات"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("لم يتم العثور على منتج"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("لم يتم اختيار ضريبة فرعية"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("لا توجد عمليات"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "لم يتم العثور على مستخدم بهذا البريد الإلكتروني."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "لم يتم العثور على دور المستخدم"),
        "notActiveUser": MessageLookupByLibrary.simpleMessage("مستخدم غير نشط"),
        "notProvided": MessageLookupByLibrary.simpleMessage("لم يتم توفيره"),
        "note": MessageLookupByLibrary.simpleMessage("ملاحظة"),
        "notes": MessageLookupByLibrary.simpleMessage("ملاحظات"),
        "notification": MessageLookupByLibrary.simpleMessage("إشعار"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("تم إرسال OTP إلى"),
        "office": MessageLookupByLibrary.simpleMessage("مكتب"),
        "ok": MessageLookupByLibrary.simpleMessage("موافق"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "نظام نقاط البيع (POS) يحتوي على العديد من الوظائف، بما في ذلك تتبع المبيعات وإدارة المخزون."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "يساعد هذا النظام على تحسين عملياتك لصالح عملائك."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "يجب أن يبسط نظام POS لدينا العمليات اليومية تلقائيًا، مما يجعل التنقل سهلاً."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("الرصيد الافتتاحي"),
        "order": MessageLookupByLibrary.simpleMessage("الطلبيات"),
        "other": MessageLookupByLibrary.simpleMessage("أخرى"),
        "otp": MessageLookupByLibrary.simpleMessage("إغلاق"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("نفاد المخزون"),
        "pacakge": MessageLookupByLibrary.simpleMessage("حزمة"),
        "packageFeatures": MessageLookupByLibrary.simpleMessage("ميزات الباقة"),
        "paid": MessageLookupByLibrary.simpleMessage("المدفوع"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("المبلغ المدفوع"),
        "parties": MessageLookupByLibrary.simpleMessage("الأطراف"),
        "partiesList": MessageLookupByLibrary.simpleMessage("قائمة الأطراف"),
        "partyGST": MessageLookupByLibrary.simpleMessage("GST الطرف"),
        "partyName": MessageLookupByLibrary.simpleMessage("اسم الحفلة"),
        "password": MessageLookupByLibrary.simpleMessage("كلمة المرور"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "كلمة المرور وكلمة المرور المؤكدة لا تتطابق"),
        "passwordCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "لا يمكن أن تكون كلمة المرور فارغة"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("كلمة المرور غير مطابقة"),
        "payCash": MessageLookupByLibrary.simpleMessage("الدفع نقدًا"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash": MessageLookupByLibrary.simpleMessage("الدفع عبر bkash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("الدفع عبر Paypal"),
        "payeeName": MessageLookupByLibrary.simpleMessage("اسم المستفيد"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("رقم المستفيد"),
        "payment": MessageLookupByLibrary.simpleMessage("الدفع"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("مبلغ الدفع"),
        "paymentComplete": MessageLookupByLibrary.simpleMessage("اكتمال الدفع"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("تعليمات الدفع:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("طريقة الدفع"),
        "paymentType": MessageLookupByLibrary.simpleMessage("نوع الدفع"),
        "pdfView": MessageLookupByLibrary.simpleMessage("عرض PDF"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("المعلومات الشخصية"),
        "phone": MessageLookupByLibrary.simpleMessage("الهاتف"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("رقم الهاتف"),
        "phoneNumberAlreadyUsed":
            MessageLookupByLibrary.simpleMessage("رقم الهاتف مستخدم بالفعل"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("رقم الهاتف غير صحيح"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("رقم الهاتف مطلوب"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("اختر ورفع ملف"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("اختر تاريخ الانتهاء"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("اختر تاريخ البدء"),
        "plan": MessageLookupByLibrary.simpleMessage("خطة"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("يرجى إضافة كمية"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "الرجاء التحقق من اتصالك بالإنترنت"),
        "pleaseConnectThePrinterFirst":
            MessageLookupByLibrary.simpleMessage("يرجى توصيل الطابعة أولاً"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "يرجى توصيل طابعة Bluetooth الخاصة بك"),
        "pleaseEnterABiggerPassword":
            MessageLookupByLibrary.simpleMessage("يرجى إدخال كلمة مرور أكبر"),
        "pleaseEnterAConfirmPassword":
            MessageLookupByLibrary.simpleMessage("يرجى إدخال كلمة مرور تأكيد"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("الرجاء إدخال كلمة مرور"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "يرجى إدخال بريد إلكتروني صحيح"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("يرجى إدخال الاسم"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("يرجى إدخال كلمة المرور"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "الرجاء إدخال عنوان بريدك الإلكتروني أدناه لتلقي رابط إعادة تعيين كلمة المرور."),
        "pleaseEnterTransactionNumber":
            MessageLookupByLibrary.simpleMessage("يرجى إدخال رقم المعاملة"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("يرجى إدخال المبلغ"),
        "pleaseSelectACategoryFirst":
            MessageLookupByLibrary.simpleMessage("يرجى اختيار فئة أولاً"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("يرجى اختيار خطة"),
        "pleaseSelectBusinessCategory":
            MessageLookupByLibrary.simpleMessage("يرجى اختيار فئة العمل"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "يرجى استخدام كود الشراء الصالح لاستخدام التطبيق"),
        "powerdedByMobiPos": MessageLookupByLibrary.simpleMessage(
            "مدعوم بواسطة نظام النقاط السحابي"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("مدعوم بواسطة"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("دعم العملاء المميز"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("الباقة المميزة"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("المبالغ المدفوعة السابقة"),
        "price": MessageLookupByLibrary.simpleMessage("السعر"),
        "print": MessageLookupByLibrary.simpleMessage("طباعة"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("خيارات الطباعة"),
        "privacyPolicy": MessageLookupByLibrary.simpleMessage("سياسة الخصوصية"),
        "product": MessageLookupByLibrary.simpleMessage("منتج"),
        "productCode": MessageLookupByLibrary.simpleMessage("رمز المنتج"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("رمز المنتج مطلوب"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("كود / اسم المنتج"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("وصف المنتج"),
        "productDetails": MessageLookupByLibrary.simpleMessage("تفاصيل المنتج"),
        "productList": MessageLookupByLibrary.simpleMessage("قائمة المنتجات"),
        "productName": MessageLookupByLibrary.simpleMessage("اسم المنتج"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "اسم المنتج موجود بالفعل في هذا المستودع"),
        "productNameIsAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("اسم المنتج مضاف بالفعل"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("اسم المنتج مطلوب"),
        "products": MessageLookupByLibrary.simpleMessage("المنتجات"),
        "profile": MessageLookupByLibrary.simpleMessage("الملف الشخصي"),
        "profileEdit":
            MessageLookupByLibrary.simpleMessage("تحرير الملف الشخصي"),
        "profit": MessageLookupByLibrary.simpleMessage("ربح"),
        "promo": MessageLookupByLibrary.simpleMessage("ترويج"),
        "promoCode": MessageLookupByLibrary.simpleMessage("كود الخصم"),
        "purchase": MessageLookupByLibrary.simpleMessage("شراء"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage("إنذار الشراء"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("تأكيد الشراء"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("تفاصيل الشراء"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("فاتورة الشراء"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("قائمة الشراء"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("شراء الآن"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("شراء باقة المميزة"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("سعر الشراء"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("سعر الشراء مطلوب"),
        "purchaseRepoet": MessageLookupByLibrary.simpleMessage("تقرير الشراء"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("تقارير الشراء"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("تقارير الشراء"),
        "purchaseReturn": MessageLookupByLibrary.simpleMessage("إرجاع الشراء"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("تقرير إرجاع الشراء"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("انتقال الشراء"),
        "qty": MessageLookupByLibrary.simpleMessage("الكمية"),
        "quantity": MessageLookupByLibrary.simpleMessage("الكمية"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("المعاملات الأخ,,"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("استلام الرمز السري"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("الرقم المرجعي"),
        "register": MessageLookupByLibrary.simpleMessage("تسجيل"),
        "registering": MessageLookupByLibrary.simpleMessage("جاري التسجيل"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("المستحق المتبقي"),
        "remove": MessageLookupByLibrary.simpleMessage("إزالة"),
        "reports": MessageLookupByLibrary.simpleMessage("تقارير"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("تم إرسال الطلب"),
        "resendCode": MessageLookupByLibrary.simpleMessage("إعادة إرسال الرمز"),
        "resendOtp":
            MessageLookupByLibrary.simpleMessage("إعادة إرسال رمز التحقق: "),
        "retailer": MessageLookupByLibrary.simpleMessage("بائع التجزئة"),
        "retur": MessageLookupByLibrary.simpleMessage("إرجاع"),
        "returN": MessageLookupByLibrary.simpleMessage("إرجاع"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("مبلغ الإرجاع"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("مبلغ الإرجاع"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("كمية الإرجاع"),
        "revenue": MessageLookupByLibrary.simpleMessage("الإيرادات"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "حماية بيانات عملك بسهولة. تتضمن ترقية Pos Saas POS Unlimited نسخ احتياطي للبيانات مجانيًا ، مما يضمن حماية معلوماتك القيمة من أي أحداث غير متوقعة. ركز على ما يهم حقًا - نمو عملك."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("مبلغ البيع"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("تفاصيل البيع"),
        "salePrice": MessageLookupByLibrary.simpleMessage("سعر البيع"),
        "saleReports": MessageLookupByLibrary.simpleMessage("تقرير المبيعات"),
        "saleReportss": MessageLookupByLibrary.simpleMessage("تقارير البيع"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("إرجاع البيع"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("تقرير إرجاع البيع"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("إعدادات البيع"),
        "sales": MessageLookupByLibrary.simpleMessage("المبيعات"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("تقارير المبيعات والشراء"),
        "salesList": MessageLookupByLibrary.simpleMessage("قائمة المبيعات"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("إرجاع المبيعات"),
        "save": MessageLookupByLibrary.simpleMessage("حفظ"),
        "saveAndPublish": MessageLookupByLibrary.simpleMessage("حفظ ونشر"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("حفظ التغييرات"),
        "saving": MessageLookupByLibrary.simpleMessage("جارٍ الحفظ"),
        "scanProductQRCode": MessageLookupByLibrary.simpleMessage(
            "امسح رمز الاستجابة السريعة للمنتج"),
        "search": MessageLookupByLibrary.simpleMessage("بحث"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "البحث بواسطة كود أو اسم المنتج"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("عرض جميع كودات الخصم"),
        "select": MessageLookupByLibrary.simpleMessage("اختر"),
        "selectAProductForReturn":
            MessageLookupByLibrary.simpleMessage("اختر منتجًا للإرجاع"),
        "selectBrand":
            MessageLookupByLibrary.simpleMessage("اختر العلامة التجارية"),
        "selectCategory": MessageLookupByLibrary.simpleMessage("اختر فئة"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("اختر جهات الاتصال"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("اختر فئة المنتج"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("اختر فئة المتجر"),
        "selectTax": MessageLookupByLibrary.simpleMessage("اختر الضريبة"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("اختر نوع الضريبة"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("اختر الوحدة"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("اختر التغييرات:"),
        "seller": MessageLookupByLibrary.simpleMessage("بائع"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("يباع بواسطة"),
        "send": MessageLookupByLibrary.simpleMessage("إرسال"),
        "sendEmail":
            MessageLookupByLibrary.simpleMessage("إرسال بريد إلكتروني"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("إرسال الرسالة"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("إرسال رابط إعادة التعيين"),
        "sendSms": MessageLookupByLibrary.simpleMessage("إرسال رسالة نصية"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("إرسال رسالة نصية؟"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("إرسال رسالة واتساب"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("أرسل بريدك الإلكتروني"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage(
            "جارٍ إرسال البريد الإلكتروني"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("جاري إرسال الرسالة"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("الخدمة / الشحن"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("إعداد ملفك الشخصي"),
        "setting": MessageLookupByLibrary.simpleMessage("الإعدادات"),
        "share": MessageLookupByLibrary.simpleMessage("مشاركة"),
        "shopGST": MessageLookupByLibrary.simpleMessage("GST المتجر"),
        "signIn": MessageLookupByLibrary.simpleMessage("تسجيل الدخول"),
        "signInWithEmail": MessageLookupByLibrary.simpleMessage(
            "تسجيل الدخول باستخدام البريد الإلكتروني"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("توقيع العميل"),
        "size": MessageLookupByLibrary.simpleMessage("الحجم"),
        "skip": MessageLookupByLibrary.simpleMessage("تخطى"),
        "sms": MessageLookupByLibrary.simpleMessage("رسائل نصية"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "عذرًا، ليس لديك إذن للوصول إلى هذه الخدمة"),
        "startDate": MessageLookupByLibrary.simpleMessage("تاريخ البدء"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("بدء عملية بيع جديدة"),
        "startTypingToSearch":
            MessageLookupByLibrary.simpleMessage("ابدأ الكتابة للبحث"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "ابق على مقدمة التطورات التكنولوجية دون تكاليف إضافية. تأكد من أن لديك دائمًا أحدث الأدوات والميزات بيديك من خلال ترقية Pos Saas POS Unlimited ، مما يضمن أن تظل عملك متطورًا."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("ما زال غير مدفوع"),
        "stock": MessageLookupByLibrary.simpleMessage("المخزون"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("المخزون مطلوب"),
        "stockList": MessageLookupByLibrary.simpleMessage("قائمة المخزون"),
        "stocks": MessageLookupByLibrary.simpleMessage("المخزون"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "إذن التخزين مطلوب لإنشاء ملف Excel"),
        "subTaxList":
            MessageLookupByLibrary.simpleMessage("قائمة الضرائب الفرعية"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("الضرائب الفرعية"),
        "subTotal": MessageLookupByLibrary.simpleMessage("المجموع الفرعي"),
        "submit": MessageLookupByLibrary.simpleMessage("إرسال"),
        "subscribeToOurYoutube":
            MessageLookupByLibrary.simpleMessage("اشترك في\nيوتيوب"),
        "subscription": MessageLookupByLibrary.simpleMessage("اشتراك"),
        "successfullyDone": MessageLookupByLibrary.simpleMessage("تم بنجاح"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("تم تسجيل الخروج بنجاح"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("تم التحديث بنجاح"),
        "supplier": MessageLookupByLibrary.simpleMessage("مورد"),
        "supplierName": MessageLookupByLibrary.simpleMessage("اسم المورد"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("رمز SWIFT"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "قم بإحضار رخصة القيادة أو بطاقة الهوية الوطنية أو صورة جواز السفر"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "احضر بطاقة الهوية للتحقق من معلوماتك"),
        "tap": MessageLookupByLibrary.simpleMessage("اضغط"),
        "tax": MessageLookupByLibrary.simpleMessage("ضريبة"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("مجموعة الضرائب"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("نسبة الضريبة"),
        "taxRate": MessageLookupByLibrary.simpleMessage("معدل الضريبة"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "معدلات الضرائب - إدارة معدلات الضرائب الخاصة بك"),
        "taxReport": MessageLookupByLibrary.simpleMessage("تقرير الضرائب"),
        "taxType": MessageLookupByLibrary.simpleMessage("نوع الضريبة"),
        "taxes": MessageLookupByLibrary.simpleMessage("الضرائب"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("الشروط والأحكام"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("شروط الاستخدام"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("الشروط والخصوصية"),
        "thankYOuForYourDuePayment":
            MessageLookupByLibrary.simpleMessage("شكرًا لك على دفعتك المستحقة"),
        "thankYou": MessageLookupByLibrary.simpleMessage("شكرا لك"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("شكرًا لشرائك"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "الحساب موجود بالفعل لهذا البريد الإلكتروني"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage("تم تنزيل ملف Excel بالفعل"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "الاسم يقول كل شيء. مع Pos Saas POS Unlimited ، ليس هناك حد لاستخدامك. سواء كنت تقوم بمعالجة عدد قليل من العمليات أو تواجه اندفاعًا من العملاء ، يمكنك العمل بثقة ، علمًا أنك لا تقتصر عن الحدود."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "كلمة المرور المقدمة ضعيفة جدًا"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "سيتم حذف البيع وجميع البيانات المتعلقة بهذه الشراء. هل أنت متأكد من الحذف؟"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "سيتم حذف هذه العملية وجميع البيانات المتعلقة بها. هل أنت متأكد من الحذف؟"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "سيتم حذف المستخدم وسيتم حذف جميع البيانات من حسابك. هل أنت متأكد من حذف هذا؟"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "سيتم حذف المستخدم وجميع البيانات من حسابك. هل أنت متأكد من الحذف؟"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("خدمات الجهات الخارجية"),
        "thisCategoryCannotBeDeleted":
            MessageLookupByLibrary.simpleMessage("لا يمكن حذف هذه الفئة"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(هذا الشهر)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "هذا المنتج تمت إضافته بالفعل"),
        "title": MessageLookupByLibrary.simpleMessage("العنوان"),
        "titleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "لا يمكن أن يكون العنوان فارغًا"),
        "to": MessageLookupByLibrary.simpleMessage("إلى"),
        "toDate": MessageLookupByLibrary.simpleMessage("إلى تاريخ"),
        "today": MessageLookupByLibrary.simpleMessage("اليوم"),
        "total": MessageLookupByLibrary.simpleMessage("الإجمالي"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("المبلغ الإجمالي"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("إجمالي المجموع"),
        "totalDue": MessageLookupByLibrary.simpleMessage("إجمالي المستحق"),
        "totalExpense":
            MessageLookupByLibrary.simpleMessage("إجمالي المصروفات"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("إجمالي الخسارة"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("الإجمالي المستحق"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("السعر الإجمالي"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("إجمالي المنتجات"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("إجمالي الربح"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("إجمالي الشراء"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("إجمالي مبلغ الإرجاع"),
        "totalReturns":
            MessageLookupByLibrary.simpleMessage("إجمالي الإرجاعات"),
        "totalSale": MessageLookupByLibrary.simpleMessage("إجمالي المبيعات"),
        "totalStock": MessageLookupByLibrary.simpleMessage("إجمالي المخزون"),
        "totalValue": MessageLookupByLibrary.simpleMessage("القيمة الإجمالية"),
        "totalVat":
            MessageLookupByLibrary.simpleMessage("إجمالي القيمة المضافة"),
        "totals": MessageLookupByLibrary.simpleMessage("الإجمالي:"),
        "transaction": MessageLookupByLibrary.simpleMessage("عملية"),
        "transactionId": MessageLookupByLibrary.simpleMessage("معرف العملية"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("حاول مرة أخرى"),
        "twitter": MessageLookupByLibrary.simpleMessage("تويتر"),
        "type": MessageLookupByLibrary.simpleMessage("النوع"),
        "unitName": MessageLookupByLibrary.simpleMessage("اسم الوحدة"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("سعر الوحدة"),
        "units": MessageLookupByLibrary.simpleMessage("الوحدات"),
        "unlimited": MessageLookupByLibrary.simpleMessage("غير محدود"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("استخدام غير محدود"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "فتح الإمكانيات الكاملة لنظام Pos Saas POS من خلال جلسات تدريب شخصية تقودها فريق الخبراء لدينا. من الأساسيات إلى التقنيات المتقدمة ، نحن نضمن أنك ملم بجميع جوانب النظام لتحسين عمليات عملك."),
        "unpaid": MessageLookupByLibrary.simpleMessage("غير مدفوع"),
        "update": MessageLookupByLibrary.simpleMessage("تحديث"),
        "updateContact": MessageLookupByLibrary.simpleMessage("تحديث الاتصال"),
        "updateNow": MessageLookupByLibrary.simpleMessage("تحديث الآن"),
        "updateProduct": MessageLookupByLibrary.simpleMessage("تحديث المنتج"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "قم بتحديث خطتك أولاً، فقد تجاوزت حدك"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("تحديث ملفك الشخصي"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "قم بتحديث ملفك الشخصي لربط طبيبك بانطباع أفضل"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "قم بتحديث ملفك الشخصي للاتصال بعملائك بانطباع أفضل"),
        "updated": MessageLookupByLibrary.simpleMessage("تم التحديث"),
        "upload": MessageLookupByLibrary.simpleMessage("رفع"),
        "uploadDocument": MessageLookupByLibrary.simpleMessage("تحميل المستند"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("تم الرفع"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("تحميل ملف"),
        "upplier": MessageLookupByLibrary.simpleMessage("المورد"),
        "usbC": MessageLookupByLibrary.simpleMessage("يو إس بي سي"),
        "use": MessageLookupByLibrary.simpleMessage("استخدام"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("استخدم Pos Saas"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("استخدام النظام"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("تم حذف المستخدم"),
        "userRole": MessageLookupByLibrary.simpleMessage("دور المستخدم"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("تفاصيل دور المستخدم"),
        "userTitle": MessageLookupByLibrary.simpleMessage("عنوان المستخدم"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "لا يمكن أن يكون عنوان المستخدم فارغًا"),
        "value": MessageLookupByLibrary.simpleMessage("القيمة"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("لا تنطبق الضريبة"),
        "verifyOtp":
            MessageLookupByLibrary.simpleMessage("التحقق من رمز التحقق"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("التحقق من رقم الهاتف"),
        "viewAll": MessageLookupByLibrary.simpleMessage("عرض الكل"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("عرض التفاصيل"),
        "walkInCustomer": MessageLookupByLibrary.simpleMessage("زبون داخلي"),
        "warehouse": MessageLookupByLibrary.simpleMessage("مستودع"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("المستودع موجود بالفعل"),
        "warehouseList":
            MessageLookupByLibrary.simpleMessage("قائمة المستودعات"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("اسم المستودع"),
        "warranty": MessageLookupByLibrary.simpleMessage("ضمان"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "لقد أرسلنا رسالة بريد إلكتروني مع تعليمات حول كيفية إعادة تعيين كلمة المرور إلى:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "نحن قد نستخدم خدمات الجهات الخارجية لدعم وظائف تطبيقنا، مثل مزودي التحليلات ومعالجي الدفع. قد تقوم هذه الخدمات من الجهات الخارجية بجمع معلومات عنك عند استخدامك لتطبيقنا. يرجى ملاحظة أننا غير مسؤولين عن ممارسات الخصوصية لهذه الخدمات من الجهات الخارجية."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "نحن نتخذ تدابير قياسية في الصناعة لحماية معلوماتك الشخصية، بما في ذلك التشفير والتخزين الآمن. نحن أيضًا نقيد الوصول إلى معلوماتك للشخصيات المفوضة فقط."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "نحن نفهم أهمية العمليات السلسة. لهذا السبب ، يتوفر دعمنا على مدار الساعة لمساعدتك ، سواء كانت استفسارات سريعة أم مخاوف شاملة. اتصل بنا في أي وقت وفي أي مكان عبر المكالمة أو واتساب لتجربة خدمة العملاء غير المسبوقة."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "نستخدم معلوماتك الشخصية لتوفير أفضل تجربة ممكنة على تطبيقنا، بما في ذلك تخصيص توصيات المحتوى الخاصة بك، وربطك بالخبراء، وتحسين وظائف تطبيقاتنا. قد نستخدم أيضًا معلوماتك للتواصل معك بشأن التحديثات أو الترويجات أو المعلومات الأخرى ذات الصلة بتطبيقنا."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "سوف نقوم بمراجعة الدفع والموافقة عليه في غضون 1-2 ساعة"),
        "weekly": MessageLookupByLibrary.simpleMessage("أسبوعيًا"),
        "weight": MessageLookupByLibrary.simpleMessage("الوزن"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("الجديد"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("تاجر جملة"),
        "wholeSalePrice": MessageLookupByLibrary.simpleMessage("سعر الجملة"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("سعر الجملة"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("تاجر جملة"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("سيتم إضافته قريبًا"),
        "willExpireAt":
            MessageLookupByLibrary.simpleMessage("ستنتهي صلاحيتها في"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("اكتب رسالتك هنا"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("OTP غير صحيح"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "تم تقديم كلمة مرور خاطئة لهذا المستخدم."),
        "yearly": MessageLookupByLibrary.simpleMessage("سنويًا"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("نعم، احذف بشكل دائم"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("أنت مستخدم غير صالح"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("أنت تستخدم"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "لا يمكنك دفع أكثر من المستحق"),
        "youHaveGotAnEmail": MessageLookupByLibrary.simpleMessage(
            "لقد تلقيت رسالة بريد إلكتروني"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "لقد قمت بتسجيل الدخول بنجاح إلى حسابك. ابق مع Pos Saas ."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("يجب عليك منح الإذن"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "يجب عليك إعادة تسجيل الدخول إلى حسابك."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "تحتاج إلى التحقق من الهوية قبل شرائك للرسائل القصيرة"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("رسالتك تبقى"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("باقتك"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "سوف تنتهي صلاحية باقتك خلال 5 أيام")
      };
}
