// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a ro locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'ro';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Continuare"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("Număr GST"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("MRP este necesar"),
        "OK": MessageLookupByLibrary.simpleMessage("OK"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Ph.nr."),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("Cod SWIFT"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Gustări"),
        "TAX": MessageLookupByLibrary.simpleMessage("IMPOZIT"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Încărcare"),
        "UserTitle":
            MessageLookupByLibrary.simpleMessage("Titlul utilizatorului"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Your Package Will Expire Today\n\nPlease Purchase again"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) Sistemul este furnizat exclusiv în scopul facilitării tranzacțiilor de punct de vânzare și a activităților conexe în cadrul afacerii dumneavoastră."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) Pentru a utiliza Sistemul, este posibil să vi se solicite să creați un cont. Sunteți de acord să furnizați informații precise, actuale și complete în timpul procesului de înregistrare și să actualizați aceste informații pentru a le menține precise și complete."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("Despre aplicație"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Despre noi"),
        "acceptanceOfTerms": MessageLookupByLibrary.simpleMessage(
            "Acceptarea Termenilor și Condițiilor"),
        "accountName": MessageLookupByLibrary.simpleMessage("Numele contului"),
        "accountNumber":
            MessageLookupByLibrary.simpleMessage("Numărul contului"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Înregistrarea Contului"),
        "acton": MessageLookupByLibrary.simpleMessage("Acțiune"),
        "add": MessageLookupByLibrary.simpleMessage("Adaugă"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Adăugați marcă"),
        "addCategory":
            MessageLookupByLibrary.simpleMessage("Adăugați categorie"),
        "addContact": MessageLookupByLibrary.simpleMessage("Adăugați contact"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Adăugați client"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("Adăugați livrare"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Adaugă descriere"),
        "addDescription": MessageLookupByLibrary.simpleMessage("Adăugați notă"),
        "addDiscount":
            MessageLookupByLibrary.simpleMessage("Adăugați discount"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Add Document Id"),
        "addDucument": MessageLookupByLibrary.simpleMessage("Add Document"),
        "addExpense":
            MessageLookupByLibrary.simpleMessage("Adăugați cheltuială"),
        "addExpenseCategory": MessageLookupByLibrary.simpleMessage(
            "Adăugați categorie de cheltuieli"),
        "addItems": MessageLookupByLibrary.simpleMessage("Add Items"),
        "addNew": MessageLookupByLibrary.simpleMessage("Adaugă nou"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Adăugați o adresă nouă"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Adăugați un produs nou"),
        "addNewTax":
            MessageLookupByLibrary.simpleMessage("Adăugați un nou impozit"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Adăugați un nou impozit cu tip de impozit unic/multiple"),
        "addNote": MessageLookupByLibrary.simpleMessage("Adăugați notă"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Adăugați mai întâi produsul"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Adăugați cod promoțional"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Add Purchase"),
        "addSales": MessageLookupByLibrary.simpleMessage("Add Sales"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Adăugat cu succes"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Add Unit"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Adaugă rol de utilizator"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Adăugat cu succes"),
        "addedToCart": MessageLookupByLibrary.simpleMessage("Adăugat în coș"),
        "address": MessageLookupByLibrary.simpleMessage("Adresă"),
        "admin": MessageLookupByLibrary.simpleMessage("Admin"),
        "all": MessageLookupByLibrary.simpleMessage("Toate"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("All business solutions"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("Deja adăugat"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Deja există"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Deja aveți un cont"),
        "amount": MessageLookupByLibrary.simpleMessage("Sumă"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "Un email a fost trimis\\nVerifică-ți inbox-ul"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Suport pentru aplicații Android și iOS"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Impozit aplicabil"),
        "apply": MessageLookupByLibrary.simpleMessage("Aplicați"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Sunteți sigur că doriți să ștergeți această factură?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Sunteți sigur că doriți să ștergeți această vânzare?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Sunteți sigur că doriți să ștergeți acest utilizator?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Ești sigur că vrei să ștergi acest impozit?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Ești sigur că vrei să ștergi acest grup de impozite?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Vrei să ștergi acest depozit?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Sunteți sigur că doriți să ștergeți acest utilizator?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Semnătura autorizată"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Sunteți responsabil pentru menținerea confidențialității contului și parolei dumneavoastră și pentru restricționarea accesului la contul dumneavoastră. Vă asumați responsabilitatea pentru toate activitățile care au loc în cadrul contului dumneavoastră."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Trebuie să aveți cel puțin 18 ani sau vârsta majoratului legal în jurisdicția dumneavoastră pentru a utiliza Sistemul."),
        "backSide": MessageLookupByLibrary.simpleMessage("Back side"),
        "backToHome": MessageLookupByLibrary.simpleMessage("Back To Home"),
        "balance": MessageLookupByLibrary.simpleMessage("Balance"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladesh"),
        "bank": MessageLookupByLibrary.simpleMessage("Bancă"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Moneda contului bancar"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Moneda contului bancar"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Informații bancare"),
        "bankName": MessageLookupByLibrary.simpleMessage("Numele băncii"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("Transfer bancar"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Cod de bare găsit"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Factură"),
        "billTo": MessageLookupByLibrary.simpleMessage("De plată către"),
        "branchName": MessageLookupByLibrary.simpleMessage("Numele sucursalei"),
        "brand": MessageLookupByLibrary.simpleMessage("Marcă"),
        "brandName": MessageLookupByLibrary.simpleMessage("Nume marcă"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("Încărcare în masă"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Categorie de afaceri"),
        "buy": MessageLookupByLibrary.simpleMessage("Cumpără"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Buy Premium Plan"),
        "buySms": MessageLookupByLibrary.simpleMessage("Buy Sms"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Prin accesarea sau utilizarea Sistemului de Punct de Vânzare (POS) (denumit în continuare \"Sistemul\") furnizat de [Numele Companiei Dvs.] (\"Companie\"), sunteți de acord să fiți obligat de acești Termeni de Utilizare. Dacă nu sunteți de acord cu acești Termeni de Utilizare, vă rugăm să nu utilizați Sistemul."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Sunteți responsabil pentru asigurarea faptului că accesul și utilizarea Sistemului sunt conforme cu toate legile și reglementările aplicabile."),
        "cacel": MessageLookupByLibrary.simpleMessage("Anulare"),
        "call": MessageLookupByLibrary.simpleMessage("Apel"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "Sunați pentru suport de urgență"),
        "camera": MessageLookupByLibrary.simpleMessage("Camera"),
        "cancel": MessageLookupByLibrary.simpleMessage("Anulare"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Anulați toate produsele"),
        "capacity": MessageLookupByLibrary.simpleMessage("Capacitate"),
        "card": MessageLookupByLibrary.simpleMessage("Card"),
        "cash": MessageLookupByLibrary.simpleMessage("Numerar"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Categories"),
        "category": MessageLookupByLibrary.simpleMessage("Categorie"),
        "categoryName":
            MessageLookupByLibrary.simpleMessage("Numele categoriei"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "Numele categoriei există deja"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("Nume categorie"),
        "change": MessageLookupByLibrary.simpleMessage("Schimbare?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Change Password"),
        "checkEmail":
            MessageLookupByLibrary.simpleMessage("Verificați emailul"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Chose a Customer"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Chose a Supplier"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Choose your features"),
        "clarence": MessageLookupByLibrary.simpleMessage("Clarence"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Apăsați pentru a conecta"),
        "close": MessageLookupByLibrary.simpleMessage("Închideți"),
        "color": MessageLookupByLibrary.simpleMessage("Culoare"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(Combinație de multiple impozite)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("În curând"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Adresa companiei"),
        "companyAndShopName": MessageLookupByLibrary.simpleMessage(
            "Numele companiei și magazinului"),
        "companyBusinessName": MessageLookupByLibrary.simpleMessage(
            "Numele Companiei și Afacerii"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Complete Transaction"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Confirmare parolă"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Confirmați returnarea"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Felicitări"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Contact Us"),
        "continu": MessageLookupByLibrary.simpleMessage("Continuați"),
        "country": MessageLookupByLibrary.simpleMessage("Țară"),
        "create": MessageLookupByLibrary.simpleMessage("Creează"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Creați un cont gratuit"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Creat și salvat"),
        "currency": MessageLookupByLibrary.simpleMessage("Currency"),
        "currentStock": MessageLookupByLibrary.simpleMessage("Current Stock"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("Personalizare facturi"),
        "customer": MessageLookupByLibrary.simpleMessage("Customer"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Detalii client"),
        "customerGST": MessageLookupByLibrary.simpleMessage("GST Client"),
        "customerName": MessageLookupByLibrary.simpleMessage("Nume client"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Daily Transaction"),
        "dashBoardOverView": MessageLookupByLibrary.simpleMessage(
            "Prezentare Generală a Tabloului de Bord"),
        "dataSavedSuccessfully": MessageLookupByLibrary.simpleMessage(
            "Datele au fost salvate cu succes"),
        "date": MessageLookupByLibrary.simpleMessage("Dată"),
        "day": MessageLookupByLibrary.simpleMessage("Zi"),
        "dealer": MessageLookupByLibrary.simpleMessage("Distribuitor"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("Dealer Price"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("Procentaj TVA implicit"),
        "delete": MessageLookupByLibrary.simpleMessage("Șterge"),
        "deleting": MessageLookupByLibrary.simpleMessage("Ștergere"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Adresă de livrare"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Adrese de livrare"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Taxă de livrare"),
        "describtion": MessageLookupByLibrary.simpleMessage("Descriere"),
        "description": MessageLookupByLibrary.simpleMessage("Descriere"),
        "descriptionCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Descrierea nu poate fi goală"),
        "details": MessageLookupByLibrary.simpleMessage("Detalii"),
        "discount": MessageLookupByLibrary.simpleMessage("Reducere"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Do not disturb"),
        "done": MessageLookupByLibrary.simpleMessage("Finalizat"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Descărcați format Excel"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Descărcat cu succes în folderul de descărcări"),
        "due": MessageLookupByLibrary.simpleMessage("Datorie"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Suma datorată: "),
        "dueCollection":
            MessageLookupByLibrary.simpleMessage("Colectare datorii"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("Raport de colectare datorii"),
        "dueList": MessageLookupByLibrary.simpleMessage("Listă datorii"),
        "dueReports": MessageLookupByLibrary.simpleMessage("Due Report"),
        "duration": MessageLookupByLibrary.simpleMessage("Durată"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Durată: De la"),
        "easyToUseMobilePos":
            MessageLookupByLibrary.simpleMessage("Easy to use mobile pos"),
        "edit": MessageLookupByLibrary.simpleMessage("Editare"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Edit Purchase Invoice"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Edit Sales Invoice"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Editare rețele sociale"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Editare cu succes"),
        "editTax": MessageLookupByLibrary.simpleMessage("Editează impozitul"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Editează grupul de impozite"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("Editează depozitul"),
        "email": MessageLookupByLibrary.simpleMessage("Email"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("Adresă de email"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Emailul nu poate fi gol"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "Email trimis! Verificați căsuța poștală"),
        "endDate": MessageLookupByLibrary.simpleMessage("End Date"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Introduceți o sumă validă"),
        "enterAValidDiscount": MessageLookupByLibrary.simpleMessage(
            "Introduceți un discount valid"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Introduceți un număr de telefon valid"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Introduceți un preț valid"),
        "enterAValidQuantity": MessageLookupByLibrary.simpleMessage(
            "Introduceți o cantitate validă"),
        "enterAddress":
            MessageLookupByLibrary.simpleMessage("Introduceți adresa"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("Introduceți suma"),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Introduceți numele mărcii"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Introduceți capacitatea"),
        "enterCategoryName": MessageLookupByLibrary.simpleMessage(
            "Introduceți numele categoriei"),
        "enterColor":
            MessageLookupByLibrary.simpleMessage("Introduceți culoarea"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "Introduceți numărul GST al clientului"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Enter Dealer Price"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Introduceți descrierea"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("Enter Discount."),
        "enterExpenseDate": MessageLookupByLibrary.simpleMessage(
            "Introduceți data cheltuielii"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Introduceți adresa completă"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Enter Invoice Number"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Introduceți cantitatea de alertă de stoc scăzut"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Enter Manufacturer"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("Enter Message Content"),
        "enterMrpOrRetailerPirce":
            MessageLookupByLibrary.simpleMessage("Enter MRP/Retailer Price"),
        "enterName": MessageLookupByLibrary.simpleMessage("Introduceți numele"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Introduceți nota"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Introduceți numele părții"),
        "enterPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Introduceți numărul de telefon"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Introduceți codul produsului sau scanați"),
        "enterProductName": MessageLookupByLibrary.simpleMessage(
            "Introduceți numele produsului"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Enter Purchase Price."),
        "enterReferenceNumber": MessageLookupByLibrary.simpleMessage(
            "Introduceți numărul de referință"),
        "enterSize":
            MessageLookupByLibrary.simpleMessage("Introduceți mărimea"),
        "enterStocks":
            MessageLookupByLibrary.simpleMessage("Introduceți stocurile"),
        "enterTaxRate": MessageLookupByLibrary.simpleMessage(
            "Introduceți rata impozitului"),
        "enterTransactionId": MessageLookupByLibrary.simpleMessage(
            "Introduceți ID-ul tranzacției"),
        "enterType": MessageLookupByLibrary.simpleMessage("Introduceți tipul"),
        "enterUserTitle": MessageLookupByLibrary.simpleMessage(
            "Introduceți titlul utilizatorului"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Introduceți o sumă validă"),
        "enterWarehouseName": MessageLookupByLibrary.simpleMessage(
            "Introduceți numele depozitului"),
        "enterWeight":
            MessageLookupByLibrary.simpleMessage("Introduceți greutatea"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Enter Wholesale Price"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("Enter your description here"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "Introduceți adresa dvs. de email"),
        "enterYourFeedBackTitle":
            MessageLookupByLibrary.simpleMessage("Enter Your Feedback Tittle"),
        "enterYourGSTNumber": MessageLookupByLibrary.simpleMessage(
            "Introduceți numărul dvs. GST"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("Enter your mobile number"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Introduceți numele dvs."),
        "enterYourNumber": MessageLookupByLibrary.simpleMessage(
            "Introduceți numărul dvs. de telefon"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Introduceți parola dvs."),
        "enterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Introduceți numărul dvs. de telefon"),
        "enterYourTransactionId":
            MessageLookupByLibrary.simpleMessage("Enter your transaction id"),
        "error": MessageLookupByLibrary.simpleMessage("Eroare"),
        "excTax": MessageLookupByLibrary.simpleMessage("Impozit exclus"),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("Încărcător Excel"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Exclusiv"),
        "expense": MessageLookupByLibrary.simpleMessage("Cheltuieli"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Categorie cheltuieli"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Data cheltuielii"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Cheltuială pentru"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Raport cheltuieli"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Data expirării"),
        "expired": MessageLookupByLibrary.simpleMessage("Expirat"),
        "expiring": MessageLookupByLibrary.simpleMessage("Expirant"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("A eșuat cu eroare"),
        "fashion": MessageLookupByLibrary.simpleMessage("Modă"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Features are the important part which makes Pos Saas  different from traditional solutions."),
        "feedBack": MessageLookupByLibrary.simpleMessage("FeedBack"),
        "firstName": MessageLookupByLibrary.simpleMessage("Prenume"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Urmați-ne pe\\nFacebook"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Urmați-ne pe\\nTwitter"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Font Side"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("For unlimited usages"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Ați uitat parola"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Ați uitat parola?"),
        "formDate": MessageLookupByLibrary.simpleMessage("De la dată"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("Backup gratuit al datelor"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "Actualizare pe viață gratuită"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Free Package"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Free Plan"),
        "from": MessageLookupByLibrary.simpleMessage("(Din"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Plătit integral"),
        "gallary": MessageLookupByLibrary.simpleMessage("Galerie"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("Generare PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Obțineți OTP"),
        "govermentId": MessageLookupByLibrary.simpleMessage("Government Id"),
        "guest": MessageLookupByLibrary.simpleMessage("Guest"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Nu aveți un cont?"),
        "history": MessageLookupByLibrary.simpleMessage("History"),
        "home": MessageLookupByLibrary.simpleMessage("Acasă"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Cum Protejăm Informațiile Dumneavoastră"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Cum Utilizăm Informațiile Dumneavoastră"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Identity Verify"),
        "image": MessageLookupByLibrary.simpleMessage("Imagine"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("InHouse nu poate fi șters"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("InHouse nu poate fi editat"),
        "inWord": MessageLookupByLibrary.simpleMessage("În cuvinte"),
        "incTax": MessageLookupByLibrary.simpleMessage("Impozit inclus"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Inclusiv"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("Crește stocul"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Instrument"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Inv No."),
        "invoice": MessageLookupByLibrary.simpleMessage("Factură"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("Invoice Number"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Invoice Setting"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Vizualizator factură"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Item Added"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("KYC Verification"),
        "language": MessageLookupByLibrary.simpleMessage("Limba"),
        "lastName": MessageLookupByLibrary.simpleMessage("Nume de familie"),
        "ledger": MessageLookupByLibrary.simpleMessage("Jurnal"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Lifetime\nPurchase"),
        "link": MessageLookupByLibrary.simpleMessage("Link"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Asistență chat live"),
        "loading": MessageLookupByLibrary.simpleMessage("Încărcare"),
        "logIn": MessageLookupByLibrary.simpleMessage("Autentificare"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Log Out"),
        "logOut": MessageLookupByLibrary.simpleMessage("Deconectare"),
        "login": MessageLookupByLibrary.simpleMessage("Autentificare"),
        "logo": MessageLookupByLibrary.simpleMessage("Logo"),
        "loss": MessageLookupByLibrary.simpleMessage("Pierdere"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Pierdere/Profit"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Detalii pierdere/profit"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Raport pierdere/profit"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Rapoarte pierdere/profit"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Alerta de stoc scăzut"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Creați o impresie durabilă asupra clienților dvs. cu facturi personalizate. Actualizarea nelimitată oferă avantajul unic de a personaliza facturile dvs., adăugând o notă profesională care întărește identitatea mărcii dvs. și promovează loialitatea clienților."),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("Gestionați-vă afacerea cu"),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Data fabricației"),
        "margin": MessageLookupByLibrary.simpleMessage("Marjă"),
        "masterCard": MessageLookupByLibrary.simpleMessage("Card Master"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Manufacturer"),
        "message": MessageLookupByLibrary.simpleMessage("Mesaj"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Message History"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Pos Saas  app is free, easy to use. In fact, it\'s one of the best  POS systems around the world."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas  is a complete business solution with stock, account, sales, expense & loss/profit."),
        "mobile": MessageLookupByLibrary.simpleMessage("Mobil"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("Plată mobilă"),
        "monthly": MessageLookupByLibrary.simpleMessage("Monthly"),
        "moreInfo":
            MessageLookupByLibrary.simpleMessage("Mai multe informații"),
        "name": MessageLookupByLibrary.simpleMessage("Introduceți numele dvs."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Numele există deja"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("Numele nu poate fi gol"),
        "next": MessageLookupByLibrary.simpleMessage("Next"),
        "noConnection": MessageLookupByLibrary.simpleMessage("Fără conexiune"),
        "noData": MessageLookupByLibrary.simpleMessage("No Data"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Nu sunt date disponibile"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Nu s-au găsit date"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("No History Found!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Nu s-a găsit produs"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("Niciun subimpozit selectat"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("No Transaction Found!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Nu s-a găsit niciun utilizator pentru acea adresă de email."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "Niciun rol de utilizator găsit"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Utilizator inactiv"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Nu este furnizat"),
        "note": MessageLookupByLibrary.simpleMessage("Notă"),
        "notes": MessageLookupByLibrary.simpleMessage("note"),
        "notification": MessageLookupByLibrary.simpleMessage("Notificare"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP trimis la"),
        "office": MessageLookupByLibrary.simpleMessage("Birou"),
        "ok": MessageLookupByLibrary.simpleMessage("OK"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "Sistem POS care conține o gamă largă de funcționalități, inclusiv urmărirea vânzărilor și gestionarea inventarului."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Acest sistem vă ajută să îmbunătățiți operațiunile pentru clienții dumneavoastră."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Sistemul nostru POS ar trebui să simplifice automat operațiunile zilnice, facilitând navigarea."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("Sold de deschidere"),
        "order": MessageLookupByLibrary.simpleMessage("Comenzi"),
        "other": MessageLookupByLibrary.simpleMessage("Altele"),
        "otp": MessageLookupByLibrary.simpleMessage("Închide"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Stoc epuizat"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Pachet"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Package Features"),
        "paid": MessageLookupByLibrary.simpleMessage("Plătit"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Suma plătită"),
        "parties": MessageLookupByLibrary.simpleMessage("Părți"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Listă părți"),
        "partyGST": MessageLookupByLibrary.simpleMessage("GST Partid"),
        "partyName": MessageLookupByLibrary.simpleMessage("Nume parte"),
        "password": MessageLookupByLibrary.simpleMessage("Parolă"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Parola și confirmarea parolei nu se potrivesc"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Parola nu poate fi goală"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("Parola nu se potrivește"),
        "payCash": MessageLookupByLibrary.simpleMessage("Plătește în numerar"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash": MessageLookupByLibrary.simpleMessage("Pay with bkash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Pay with Paypal"),
        "payeeName": MessageLookupByLibrary.simpleMessage("Payee Name"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("Payee Number"),
        "payment": MessageLookupByLibrary.simpleMessage("Plată"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("Sumă plată"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Plată finalizată"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Payment Instruction:"),
        "paymentMethod":
            MessageLookupByLibrary.simpleMessage("Metodă de plată"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Tipul plății"),
        "pdfView": MessageLookupByLibrary.simpleMessage("Vizualizare PDF"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Informații personale"),
        "phone": MessageLookupByLibrary.simpleMessage("Telefon"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Număr de telefon"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Numărul de telefon este deja utilizat"),
        "phoneNumberIsNotValid": MessageLookupByLibrary.simpleMessage(
            "Numărul de telefon nu este valid"),
        "phoneNumberIsRequired": MessageLookupByLibrary.simpleMessage(
            "Numărul de telefon este necesar"),
        "pickAndUploadFile": MessageLookupByLibrary.simpleMessage(
            "Selectați și încărcați fișier"),
        "pickEndDate": MessageLookupByLibrary.simpleMessage("Pick End Date"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Pick Start Date"),
        "plan": MessageLookupByLibrary.simpleMessage("Plan"),
        "pleaseAddQuantity": MessageLookupByLibrary.simpleMessage(
            "Vă rugăm să adăugați cantitatea"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Vă rugăm să verificați conectivitatea la internet"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Vă rugăm să conectați mai întâi imprimanta"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Vă rugăm să conectați imprimanta Bluetooth"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Vă rugăm să introduceți o parolă mai lungă"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Vă rugăm să introduceți o parolă de confirmare"),
        "pleaseEnterAPassword": MessageLookupByLibrary.simpleMessage(
            "Vă rugăm să introduceți o parolă"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Vă rugăm să introduceți un email valid"),
        "pleaseEnterName": MessageLookupByLibrary.simpleMessage(
            "Vă rugăm să introduceți numele"),
        "pleaseEnterPassword": MessageLookupByLibrary.simpleMessage(
            "Te rugăm să introduci parola"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Vă rugăm să introduceți adresa dvs. de email mai jos pentru a primi linkul de resetare a parolei."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Vă rugăm să introduceți numărul de tranzacție"),
        "pleaseInterAmount": MessageLookupByLibrary.simpleMessage(
            "Vă rugăm să introduceți suma"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Vă rugăm să selectați mai întâi o categorie"),
        "pleaseSelectAPlan": MessageLookupByLibrary.simpleMessage(
            "Vă rugăm să selectați un plan"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Vă rugăm să selectați categoria de afaceri"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Vă rugăm să folosiți codul de achiziție valid pentru a utiliza aplicația"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Furnizat de Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Realizat de"),
        "premiumCustomerSupport": MessageLookupByLibrary.simpleMessage(
            "Suport premium pentru clienți"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Premium plan"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Previous Pay Amounts"),
        "price": MessageLookupByLibrary.simpleMessage("price"),
        "print": MessageLookupByLibrary.simpleMessage("Imprimare"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Printing Option"),
        "privacyPolicy": MessageLookupByLibrary.simpleMessage(
            "Politica de confidențialitate"),
        "product": MessageLookupByLibrary.simpleMessage("Produs"),
        "productCode": MessageLookupByLibrary.simpleMessage("Cod produs"),
        "productCodeIsRequired": MessageLookupByLibrary.simpleMessage(
            "Codul produsului este necesar"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Cod/Nume produs"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Descriere produs"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Detalii produs"),
        "productList": MessageLookupByLibrary.simpleMessage("Product List"),
        "productName": MessageLookupByLibrary.simpleMessage("Nume produs"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Numele produsului există deja în acest depozit"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Numele produsului este deja adăugat"),
        "productNameIsRequired": MessageLookupByLibrary.simpleMessage(
            "Numele produsului este necesar"),
        "products": MessageLookupByLibrary.simpleMessage("Produse"),
        "profile": MessageLookupByLibrary.simpleMessage("Profile"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("Editează profil"),
        "profit": MessageLookupByLibrary.simpleMessage("Profit"),
        "promo": MessageLookupByLibrary.simpleMessage("promo"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Promo Code"),
        "purchase": MessageLookupByLibrary.simpleMessage("Purchase"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("Alarmă de achiziții"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Achiziție confirmată"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Purchase Details"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Factură de achiziție"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("Purchase List"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Cumpărați acum"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Purchase Premium Plan"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("Preț achiziție"),
        "purchasePriceIsRequired": MessageLookupByLibrary.simpleMessage(
            "Prețul de achiziție este necesar"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("Purchase Report"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Purchase Price"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Raport de achiziții"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("Returnare achiziție"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("Raport returnare achiziție"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Tranzacție de achiziție"),
        "qty": MessageLookupByLibrary.simpleMessage("Qty"),
        "quantity": MessageLookupByLibrary.simpleMessage("Cantitate"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Tranzacții recente"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("Ați primit PIN-ul"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Număr de referință"),
        "register": MessageLookupByLibrary.simpleMessage("Înregistrare"),
        "registering": MessageLookupByLibrary.simpleMessage("Înregistrare"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("Datorie rămasă"),
        "remove": MessageLookupByLibrary.simpleMessage("Eliminare"),
        "reports": MessageLookupByLibrary.simpleMessage("Rapoarte"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Cererea a fost trimisă"),
        "resendCode": MessageLookupByLibrary.simpleMessage("Retrimiteți codul"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("Retrimiteți OTP: "),
        "retailer":
            MessageLookupByLibrary.simpleMessage("Comerciant cu amănuntul"),
        "retur": MessageLookupByLibrary.simpleMessage("Returnare"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("Return Amount"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("Return Amount"),
        "returnQTY":
            MessageLookupByLibrary.simpleMessage("Cantitate returnată"),
        "revenue": MessageLookupByLibrary.simpleMessage("Venituri"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Protejați datele afacerii dvs. fără efort. Actualizarea nelimitată Pos Saas POS include backup gratuit al datelor, asigurându-se că informațiile valoroase sunt protejate împotriva oricăror evenimente neprevăzute. Concentrați-vă asupra a ceea ce contează cu adevărat - creșterea afacerii dvs."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Sumă vânzare"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("Sale Details"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Sale Price"),
        "saleReports": MessageLookupByLibrary.simpleMessage("Sale Report"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Raport de vânzări"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("Returnare vânzare"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Raport returnare vânzare"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("Setări vânzare"),
        "sales": MessageLookupByLibrary.simpleMessage("Vânzări"),
        "salesAndPurchaseReports": MessageLookupByLibrary.simpleMessage(
            "Raporturi de Vânzări și Achiziții"),
        "salesList": MessageLookupByLibrary.simpleMessage("Sales List"),
        "salesReturn":
            MessageLookupByLibrary.simpleMessage("Returnare vânzare"),
        "save": MessageLookupByLibrary.simpleMessage("Salvați"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Save and Publish"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("Save Changes"),
        "saving": MessageLookupByLibrary.simpleMessage("Salvare"),
        "scanProductQRCode": MessageLookupByLibrary.simpleMessage(
            "Scanați codul QR al produsului"),
        "search": MessageLookupByLibrary.simpleMessage("Căutare"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Căutați după cod sau nume produs"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("See all promo codes"),
        "select": MessageLookupByLibrary.simpleMessage("Selectați"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Selectați un produs pentru returnare"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Selectați marca"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Selectați categoria"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Select Contacts"),
        "selectProductCategory": MessageLookupByLibrary.simpleMessage(
            "Selectați categoria produsului"),
        "selectShopCategory": MessageLookupByLibrary.simpleMessage(
            "Selectați categoria magazinului"),
        "selectTax":
            MessageLookupByLibrary.simpleMessage("Selectați impozitul"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Selectați tipul de impozit"),
        "selectUnit":
            MessageLookupByLibrary.simpleMessage("Selectați unitatea"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Selectați variații:"),
        "seller": MessageLookupByLibrary.simpleMessage("Vânzător"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Vândut de"),
        "send": MessageLookupByLibrary.simpleMessage("Send"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("Trimiteți email"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Send Message"),
        "sendResetLink": MessageLookupByLibrary.simpleMessage(
            "Trimiteți linkul de resetare"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Trimiteți SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Send sms?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Trimite mesaj WhatsApp"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Send Your Email"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage("Trimitere email"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Trimitere mesaj"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Serviciu/Transport"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Configurați-vă profilul"),
        "setting": MessageLookupByLibrary.simpleMessage("Setări"),
        "share": MessageLookupByLibrary.simpleMessage("Partajare"),
        "shopGST": MessageLookupByLibrary.simpleMessage("GST Magazin"),
        "signIn": MessageLookupByLibrary.simpleMessage("Autentificare"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("Autentificare cu email"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Semnătura clientului"),
        "size": MessageLookupByLibrary.simpleMessage("Mărime"),
        "skip": MessageLookupByLibrary.simpleMessage("Skip"),
        "sms": MessageLookupByLibrary.simpleMessage("Sms"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Marketing social"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Ne pare rău, nu aveți permisiunea de a accesa acest serviciu"),
        "startDate": MessageLookupByLibrary.simpleMessage("Start Date"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Începeți o vânzare nouă"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage(
            "Începeți să tastați pentru a căuta"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Rămâneți în fruntea avansurilor tehnologice fără costuri suplimentare. Actualizarea nelimitată Pos Saas POS asigură că aveți întotdeauna cele mai recente instrumente și funcționalități la îndemână, garantând că afacerea dvs. rămâne la cutting-edge."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("Încă neplătit"),
        "stock": MessageLookupByLibrary.simpleMessage("Stoc"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Stocul este necesar"),
        "stockList": MessageLookupByLibrary.simpleMessage("Listă de stoc"),
        "stocks": MessageLookupByLibrary.simpleMessage("Stocuri"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Permisiunea de stocare este necesară pentru a crea fișier Excel"),
        "subTaxList":
            MessageLookupByLibrary.simpleMessage("Lista subimpozitelor"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Subimpozite"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Subtotal"),
        "submit": MessageLookupByLibrary.simpleMessage("Submit"),
        "subscribeToOurYoutube":
            MessageLookupByLibrary.simpleMessage("Abonați-vă la\\nYoutube"),
        "subscription": MessageLookupByLibrary.simpleMessage("Subscription"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Finalizat cu succes"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Deconectat cu succes"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Actualizat cu succes"),
        "supplier": MessageLookupByLibrary.simpleMessage("Furnizor"),
        "supplierName": MessageLookupByLibrary.simpleMessage("Supplier Name"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("Cod SWIFT"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Take a driver\'s license, national identity card or passport photo"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "Take an identity card to check your information"),
        "tap": MessageLookupByLibrary.simpleMessage("Apăsați"),
        "tax": MessageLookupByLibrary.simpleMessage("Impozit"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Grup de impozit"),
        "taxPercentage":
            MessageLookupByLibrary.simpleMessage("Procentaj impozit"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Rata impozitului"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Rata impozitelor - Gestionează ratele tale de impozit"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Raport de impozit"),
        "taxType": MessageLookupByLibrary.simpleMessage("Tip impozit"),
        "taxes": MessageLookupByLibrary.simpleMessage("Impozite"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Termeni și condiții"),
        "termsOfUse":
            MessageLookupByLibrary.simpleMessage("Termeni de utilizare"),
        "termsPrivacy": MessageLookupByLibrary.simpleMessage(
            "Termeni și confidențialitate"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Vă mulțumim pentru plata datoriei"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Vă mulțumim"),
        "thankYouForYourPurchase": MessageLookupByLibrary.simpleMessage(
            "Vă mulțumim pentru achiziția dvs."),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "Contul există deja pentru acest email"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Fișierul Excel a fost deja descărcat"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Numele spune totul. Cu Pos Saas POS Unlimited, nu există nicio limitare a utilizării. Fie că procesați un număr mic de tranzacții sau aveți un val de clienți, puteți opera cu încredere, știind că nu sunteți limitat de constrângeri."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "Parola furnizată este prea slabă"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Vânzarea va fi ștearsă și toate datele legate de această achiziție vor fi șterse. Sunteți sigur că doriți să ștergeți aceasta?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Vânzarea va fi ștearsă și toate datele legate de această vânzare vor fi șterse. Sunteți sigur că doriți să ștergeți aceasta?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Utilizatorul va fi șters și toate datele vor fi șterse din contul dvs. Sunteți sigur că doriți să ștergeți acest lucru?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Utilizatorul va fi șters și toate datele vor fi eliminate din contul dvs. Sunteți sigur că doriți să ștergeți acesta?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Servicii de la Terți"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Această categorie nu poate fi ștearsă"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Această lună)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Acest produs a fost deja adăugat"),
        "title": MessageLookupByLibrary.simpleMessage("Title"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Titlul nu poate fi gol"),
        "to": MessageLookupByLibrary.simpleMessage("până la"),
        "toDate": MessageLookupByLibrary.simpleMessage("Până la dată"),
        "today": MessageLookupByLibrary.simpleMessage("Astăzi"),
        "total": MessageLookupByLibrary.simpleMessage("Total"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Suma totală"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Total colectat"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Total datorii"),
        "totalExpense":
            MessageLookupByLibrary.simpleMessage("Total cheltuieli"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Pierdere totală"),
        "totalPayable": MessageLookupByLibrary.simpleMessage("Total de plată"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Preț total"),
        "totalProducts": MessageLookupByLibrary.simpleMessage("Produse totale"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Profit total"),
        "totalPurchase":
            MessageLookupByLibrary.simpleMessage("Achiziție totală"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Suma totală returnată"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("Total returnări"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Total vânzări"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Total Stocks"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Valoare totală"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Total TVA"),
        "totals": MessageLookupByLibrary.simpleMessage("Total: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Transaction"),
        "transactionId": MessageLookupByLibrary.simpleMessage("Transaction Id"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Încercați din nou"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Tip"),
        "unitName": MessageLookupByLibrary.simpleMessage("Unit Name"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Preț unitar"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Preț unitar"),
        "units": MessageLookupByLibrary.simpleMessage("Unități"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Nelimitat"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Utilizare nelimitată"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Deblocarea potențialului complet al Pos Saas POS cu sesiuni de pregătire personalizate conduse de echipa noastră de experți. De la elementele de bază până la tehnici avansate, ne asigurăm că sunteți bine pregătit pentru a utiliza fiecare aspect al sistemului pentru a vă optimiza procesele de afaceri."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Neplătit"),
        "update": MessageLookupByLibrary.simpleMessage("Actualizare"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Actualizați contactul"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Update Now"),
        "updateProduct": MessageLookupByLibrary.simpleMessage("Update Product"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Actualizați mai întâi planul,\\n limita dvs. a fost depășită"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Update Your Profile"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Actualizați-vă profilul pentru a vă conecta medicul cu o impresie mai bună"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Update your profile to connect your customer with better impression"),
        "updated": MessageLookupByLibrary.simpleMessage("Actualizat"),
        "upload": MessageLookupByLibrary.simpleMessage("Încărcare"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Încărcați documentul"),
        "uploadDone":
            MessageLookupByLibrary.simpleMessage("Încărcare finalizată"),
        "uploadFile":
            MessageLookupByLibrary.simpleMessage("Încărcați fișierul"),
        "usbC": MessageLookupByLibrary.simpleMessage("Usb C"),
        "use": MessageLookupByLibrary.simpleMessage("Utilizați"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("Use Pos Saas"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Utilizarea Sistemului"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Utilizatorul a fost șters"),
        "userRole": MessageLookupByLibrary.simpleMessage("Rol de utilizator"),
        "userRoleDetails": MessageLookupByLibrary.simpleMessage(
            "Detalii despre rolul utilizatorului"),
        "userTitle":
            MessageLookupByLibrary.simpleMessage("Titlul utilizatorului"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Titlul utilizatorului nu poate fi gol"),
        "value": MessageLookupByLibrary.simpleMessage("Valoare"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("TVA nu se aplică"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("Verificare OTP"),
        "verifyPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Verificați numărul de telefon"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Vizualizați toate"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("View details"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Walk-in customer"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Depozit"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Depozitul există deja"),
        "warehouseList":
            MessageLookupByLibrary.simpleMessage("Lista depozitelor"),
        "warehouseName":
            MessageLookupByLibrary.simpleMessage("Numele depozitului"),
        "warranty": MessageLookupByLibrary.simpleMessage("Garanție"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Am trimis un email cu instrucțiuni privind resetarea parolei către:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Putem utiliza servicii de la terți pentru a sprijini funcționalitatea aplicației noastre, cum ar fi furnizorii de analize și procesatorii de plăți. Acești furnizori de servicii de la terți pot colecta informații despre dumneavoastră atunci când utilizați aplicația noastră. Vă rugăm să rețineți că nu suntem responsabili pentru practicile de confidențialitate ale acestor servicii de la terți."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Adoptăm măsuri standard ale industriei pentru a proteja informațiile dvs. personale, inclusiv criptarea și stocarea securizată. De asemenea, limităm accesul la informațiile dvs. doar pentru personalul autorizat."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Înțelegem importanța operațiunilor fără sudură. De aceea, suportul nostru non-stop este disponibil pentru a vă ajuta, fie că este vorba de o întrebare rapidă sau o problemă mai complexă. Conectați-vă cu noi oricând și oriunde, prin apel sau WhatsApp, pentru a experimenta un serviciu de neegalat."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Utilizăm informațiile dvs. personale pentru a vă oferi cea mai bună experiență posibilă în cadrul aplicației noastre, inclusiv pentru a personaliza recomandările de conținut, pentru a vă conecta cu experți și pentru a îmbunătăți funcționalitatea aplicației noastre. Putem folosi, de asemenea, informațiile dvs. pentru a vă comunica actualizări, promoții sau alte informații legate de aplicația noastră."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Vom revizui plata și o vom aproba în termen de 1-2 ore"),
        "weekly": MessageLookupByLibrary.simpleMessage("Săptămânal"),
        "weight": MessageLookupByLibrary.simpleMessage("Greutate"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Ce e nou"),
        "wholSeller":
            MessageLookupByLibrary.simpleMessage("Comerciant en-gros"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("WholeSale Price"),
        "wholesalePrice":
            MessageLookupByLibrary.simpleMessage("Preț angrosist"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Angrosist"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Va fi adăugat în curând"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Va expira la"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Write your message here"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("OTP greșit"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Parola greșită furnizată pentru acel utilizator."),
        "yearly": MessageLookupByLibrary.simpleMessage("Yearly"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Da, Ștergeți definitiv"),
        "youAreNotAValidUser": MessageLookupByLibrary.simpleMessage(
            "Nu sunteți un utilizator valid"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("You are using"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Nu puteți plăti mai mult decât suma datorată"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Ați primit un email"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Ați fost autentificat cu succes în contul dvs. Rămâneți cu Pos Saas."),
        "youHaveToGivePermission": MessageLookupByLibrary.simpleMessage(
            "Trebuie să oferi permisiunea"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Trebuie să vă RE-LOGAȚI în contul dvs."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "You need to identity verify before your buying sms"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Your message remains"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Your Package"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Your Package Will Expire in 5 Day")
      };
}
