// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a fa locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'fa';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("ادامه"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("شماره GST"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("قیمت پیشنهادی"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("قیمت خرده‌فروشی الزامی است"),
        "OK": MessageLookupByLibrary.simpleMessage("باشه"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("پی پل"),
        "PhNo": MessageLookupByLibrary.simpleMessage("شماره تلفن"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("کد SWIFT"),
        "Snacks": MessageLookupByLibrary.simpleMessage("اسنک"),
        "TAX": MessageLookupByLibrary.simpleMessage("مالیات"),
        "Uploading": MessageLookupByLibrary.simpleMessage("در حال بارگذاری"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("عنوان کاربر"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "بسته شما امروز منقضی خواهد شد\n\nلطفاً مجدداً خرید کنید"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(الف) سیستم تنها برای تسهیل تراکنش‌های نقطه فروش و فعالیت‌های مرتبط در کسب و کار شما ارائه شده است."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(الف) برای استفاده از سیستم، ممکن است لازم باشد حساب کاربری ایجاد کنید. شما موافقت می‌کنید که در طول فرآیند ثبت‌نام اطلاعات دقیق، کنونی و کامل را ارائه دهید و این اطلاعات را برای حفظ دقت و کمال به‌روز کنید."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("درباره اپلیکیشن"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("درباره ما"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("پذیرش شرایط"),
        "accountName": MessageLookupByLibrary.simpleMessage("نام حساب"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("شماره حساب"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("ثبت نام حساب کاربری"),
        "acton": MessageLookupByLibrary.simpleMessage("اقدام"),
        "add": MessageLookupByLibrary.simpleMessage("افزودن"),
        "addBrand": MessageLookupByLibrary.simpleMessage("افزودن برند"),
        "addCategory": MessageLookupByLibrary.simpleMessage("افزودن دسته‌بندی"),
        "addContact": MessageLookupByLibrary.simpleMessage("افزودن مخاطب"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("افزودن مشتری"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("افزودن تحویل"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("افزودن توضیحات"),
        "addDescription":
            MessageLookupByLibrary.simpleMessage("افزودن یادداشت"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("اضافه کردن تخفیف"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("افزودن شناسه مدرک"),
        "addDucument": MessageLookupByLibrary.simpleMessage("افزودن مدرک"),
        "addExpense": MessageLookupByLibrary.simpleMessage("افزودن هزینه"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("افزودن دسته هزینه"),
        "addItems": MessageLookupByLibrary.simpleMessage("افزودن موارد"),
        "addNew": MessageLookupByLibrary.simpleMessage("افزودن جدید"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("افزودن آدرس جدید"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("افزودن محصول جدید"),
        "addNewTax":
            MessageLookupByLibrary.simpleMessage("اضافه کردن مالیات جدید"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "اضافه کردن مالیات جدید با نوع مالیات واحد/چندگانه"),
        "addNote": MessageLookupByLibrary.simpleMessage("افزودن یادداشت"),
        "addProductFirst": MessageLookupByLibrary.simpleMessage(
            "اول باید محصول را اضافه کنید"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("اضافه کردن کد تخفیف"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("افزودن خرید"),
        "addSales": MessageLookupByLibrary.simpleMessage("افزودن فروش"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("افزوده شد با موفقیت"),
        "addUnit": MessageLookupByLibrary.simpleMessage("افزودن واحد"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("افزودن نقش کاربری"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("با موفقیت اضافه شد"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("به سبد خرید اضافه شد"),
        "address": MessageLookupByLibrary.simpleMessage("آدرس"),
        "admin": MessageLookupByLibrary.simpleMessage("مدیر"),
        "all": MessageLookupByLibrary.simpleMessage("همه"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("تمامی راهکارهای کسب و کار"),
        "alreadyAdded":
            MessageLookupByLibrary.simpleMessage("قبلاً اضافه شده است"),
        "alreadyExists":
            MessageLookupByLibrary.simpleMessage("قبلاً وجود دارد"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("قبلاً حساب کاربری دارید؟"),
        "amount": MessageLookupByLibrary.simpleMessage("مقدار"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "ایمیلی ارسال شده است\\nصندوق ورودی خود را بررسی کنید"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "پشتیبانی از اپلیکیشن‌های اندروید و iOS"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("مالیات قابل اجرا"),
        "apply": MessageLookupByLibrary.simpleMessage("اعمال"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "آیا مطمئن هستید که می‌خواهید این فاکتور را حذف کنید؟"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "آیا مطمئن هستید که می‌خواهید این فروش را حذف کنید؟"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "آیا مطمئن هستید که می‌خواهید این کاربر را حذف کنید؟"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "آیا مطمئن هستید که می‌خواهید این مالیات را حذف کنید؟"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "آیا مطمئن هستید که می‌خواهید این گروه مالیات را حذف کنید؟"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "آیا می‌خواهید این انبار را حذف کنید؟"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "آیا مطمئنید که می‌خواهید این کاربر را حذف کنید؟"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("امضای مجاز"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(ب) شما مسئول حفظ محرمانگی حساب و رمز عبور خود و محدود کردن دسترسی به حساب خود هستید. شما مسئولیت تمامی فعالیت‌هایی که تحت حساب شما انجام می‌شود را می‌پذیرید."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(ب) شما باید حداقل ۱۸ سال یا سن قانونی اکثریت در حوزه‌ی شما داشته باشید تا بتوانید از سیستم استفاده کنید."),
        "backSide": MessageLookupByLibrary.simpleMessage("پشت صفحه"),
        "backToHome": MessageLookupByLibrary.simpleMessage("بازگشت به خانه"),
        "balance": MessageLookupByLibrary.simpleMessage("موجودی"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("بنگلادش"),
        "bank": MessageLookupByLibrary.simpleMessage("بانک"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("ارز حساب بانکی"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("واحد پول حساب بانکی"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("اطلاعات بانکی"),
        "bankName": MessageLookupByLibrary.simpleMessage("نام بانک"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("انتقال بانکی"),
        "barcodeFound": MessageLookupByLibrary.simpleMessage("بارکد پیدا شد"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("فاکتور/صورتحساب"),
        "billTo": MessageLookupByLibrary.simpleMessage("صورتحساب به"),
        "branchName": MessageLookupByLibrary.simpleMessage("نام شعبه"),
        "brand": MessageLookupByLibrary.simpleMessage("برند"),
        "brandName": MessageLookupByLibrary.simpleMessage("نام برند"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("بارگذاری عمده"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("دسته‌بندی کسب و کار"),
        "buy": MessageLookupByLibrary.simpleMessage("خرید"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("خرید طرح پریمیوم"),
        "buySms": MessageLookupByLibrary.simpleMessage("خرید پیامک"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "با دسترسی یا استفاده از سیستم نقطه فروش (POS) («سیستم») ارائه شده توسط [نام شرکت شما] («شرکت»)، شما موافقت به تعهد به این شرایط استفاده می‌کنید. اگر با این شرایط موافق نیستید، از استفاده از سیستم خودداری کنید."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(ج) شما مسئول اطمینان از این هستید که دسترسی و استفاده شما از سیستم با تمام قوانین و مقررات معتبر رعایت می‌کند."),
        "call": MessageLookupByLibrary.simpleMessage("تماس"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "برای پشتیبانی اضطراری تماس بگیرید"),
        "camera": MessageLookupByLibrary.simpleMessage("دوربین"),
        "cancel": MessageLookupByLibrary.simpleMessage("لغو"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("لغو همه محصولات"),
        "capacity": MessageLookupByLibrary.simpleMessage("ظرفیت"),
        "card": MessageLookupByLibrary.simpleMessage("کارت"),
        "cash": MessageLookupByLibrary.simpleMessage("نقدی"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("دسته‌بندی‌ها"),
        "category": MessageLookupByLibrary.simpleMessage("دسته‌بندی"),
        "categoryName": MessageLookupByLibrary.simpleMessage("نام دسته"),
        "categoryNameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("نام دسته قبلاً وجود دارد"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("نام دسته"),
        "change": MessageLookupByLibrary.simpleMessage("تغییر؟"),
        "changePassword": MessageLookupByLibrary.simpleMessage("تغییر رمزعبور"),
        "checkEmail":
            MessageLookupByLibrary.simpleMessage("ایمیل را بررسی کنید"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("یک مشتری را انتخاب کنید"),
        "choseASupplier": MessageLookupByLibrary.simpleMessage(
            "یک تامین‌کننده را انتخاب کنید"),
        "choseYourFeature": MessageLookupByLibrary.simpleMessage(
            "ویژگی‌های خود را انتخاب کنید"),
        "clarence": MessageLookupByLibrary.simpleMessage("کلارنس"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("برای اتصال کلیک کنید"),
        "close": MessageLookupByLibrary.simpleMessage("بستن"),
        "color": MessageLookupByLibrary.simpleMessage("رنگ"),
        "combinationOfMultipleTaxes":
            MessageLookupByLibrary.simpleMessage("(ترکیب چندین مالیات)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("به زودی می‌آید"),
        "companyAddress": MessageLookupByLibrary.simpleMessage("آدرس شرکت"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("نام شرکت و فروشگاه"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("نام شرکت و کسب‌وکار"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("تکمیل تراکنش"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("تأیید رمزعبور"),
        "confirmReturn": MessageLookupByLibrary.simpleMessage("تأیید بازگشت"),
        "congratulations":
            MessageLookupByLibrary.simpleMessage("تبریک می‌گوییم"),
        "contactUs": MessageLookupByLibrary.simpleMessage("تماس با ما"),
        "country": MessageLookupByLibrary.simpleMessage("کشور"),
        "create": MessageLookupByLibrary.simpleMessage("ایجاد"),
        "createAFreeAccounts": MessageLookupByLibrary.simpleMessage(
            "حساب کاربری رایگان ایجاد کنید"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("ایجاد و ذخیره شد"),
        "currency": MessageLookupByLibrary.simpleMessage("واحد پولی"),
        "currentStock": MessageLookupByLibrary.simpleMessage("موجودی فعلی"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("برندسازی فاکتور سفارشی"),
        "customer": MessageLookupByLibrary.simpleMessage("مشتری"),
        "customerDetails": MessageLookupByLibrary.simpleMessage("جزئیات مشتری"),
        "customerGST": MessageLookupByLibrary.simpleMessage("GST مشتری"),
        "customerName": MessageLookupByLibrary.simpleMessage("نام مشتری"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("تراکنش روزانه"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("مروری بر داشبورد"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("داده با موفقیت ذخیره شد"),
        "date": MessageLookupByLibrary.simpleMessage("تاریخ"),
        "day": MessageLookupByLibrary.simpleMessage("روز"),
        "dealer": MessageLookupByLibrary.simpleMessage("نماینده"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("قیمت نماینده"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("درصد VAT پیش‌فرض"),
        "delete": MessageLookupByLibrary.simpleMessage("حذف"),
        "deleting": MessageLookupByLibrary.simpleMessage("در حال حذف"),
        "deliveryAddress": MessageLookupByLibrary.simpleMessage("آدرس تحویل"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("آدرس‌های تحویل"),
        "deliveryCharge": MessageLookupByLibrary.simpleMessage("هزینه تحویل"),
        "describtion": MessageLookupByLibrary.simpleMessage("توضیحات"),
        "description": MessageLookupByLibrary.simpleMessage("شرح"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("توضیحات نمی‌تواند خالی باشد"),
        "details": MessageLookupByLibrary.simpleMessage("جزئیات"),
        "discount": MessageLookupByLibrary.simpleMessage("تخفیف"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("مزاحم نشوید"),
        "done": MessageLookupByLibrary.simpleMessage("انجام شد"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("دانلود فرمت Excel"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "با موفقیت در پوشه دانلود دانلود شد"),
        "due": MessageLookupByLibrary.simpleMessage("بدهی"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("میزان بدهی: "),
        "dueCollection": MessageLookupByLibrary.simpleMessage("جمع‌آوری بدهی"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("گزارش‌های مطالبات معوق"),
        "dueList": MessageLookupByLibrary.simpleMessage("لیست بدهی"),
        "dueReports": MessageLookupByLibrary.simpleMessage("گزارش بدهی"),
        "duration": MessageLookupByLibrary.simpleMessage("مدت"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("مدت: از"),
        "easyToUseMobilePos":
            MessageLookupByLibrary.simpleMessage("پوز موبایلی آسان در استفاده"),
        "edit": MessageLookupByLibrary.simpleMessage("ویرایش"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("ویرایش فاکتور خرید"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("ویرایش فاکتور فروش"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("ویرایش رسانه‌های اجتماعی"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("ویرایش با موفقیت انجام شد"),
        "editTax": MessageLookupByLibrary.simpleMessage("ویرایش مالیات"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("ویرایش گروه مالیات"),
        "editWarehouse": MessageLookupByLibrary.simpleMessage("ویرایش انبار"),
        "email": MessageLookupByLibrary.simpleMessage("ایمیل"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("آدرس ایمیل"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("ایمیل نمی‌تواند خالی باشد"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "ایمیل ارسال شد! صندوق ورودی خود را بررسی کنید"),
        "endDate": MessageLookupByLibrary.simpleMessage("تاریخ پایان"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("مقدار معتبری وارد کنید"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("یک تخفیف معتبر وارد کنید"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "لطفاً یک شماره تلفن معتبر وارد کنید"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("یک قیمت معتبر وارد کنید"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("یک مقدار معتبر وارد کنید"),
        "enterAddress":
            MessageLookupByLibrary.simpleMessage("آدرس را وارد کنید"),
        "enterAmount":
            MessageLookupByLibrary.simpleMessage("مقدار را وارد کنید."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("نام برند را وارد کنید"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("ظرفیت را وارد کنید"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("نام دسته‌بندی را وارد کنید"),
        "enterColor": MessageLookupByLibrary.simpleMessage("رنگ را وارد کنید"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "شماره GST مشتری را وارد کنید"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("قیمت نماینده را وارد کنید"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("شرح را وارد کنید"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("تخفیف را وارد کنید."),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("تاریخ هزینه را وارد کنید"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("آدرس کامل را وارد کنید"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("شماره فاکتور را وارد کنید"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "مقدار هشدار موجودی کم را وارد کنید"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("تولیدکننده را وارد کنید"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("محتوای پیام را وارد کنید"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "قیمت پیشنهادی/خرده‌فروشی را وارد کنید"),
        "enterName": MessageLookupByLibrary.simpleMessage("نام را وارد کنید"),
        "enterNote":
            MessageLookupByLibrary.simpleMessage("یادداشت را وارد کنید"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("نام طرف را وارد کنید"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("شماره تلفن را وارد کنید"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "کد محصول را وارد کنید یا اسکن کنید"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("نام محصول را وارد کنید"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("قیمت خرید را وارد کنید."),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("شماره مرجع را وارد کنید"),
        "enterSize":
            MessageLookupByLibrary.simpleMessage("اندازه را وارد کنید"),
        "enterStocks":
            MessageLookupByLibrary.simpleMessage("موجودی را وارد کنید."),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("نرخ مالیات را وارد کنید"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("شناسه تراکنش را وارد کنید"),
        "enterType": MessageLookupByLibrary.simpleMessage("نوع را وارد کنید"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("عنوان کاربر را وارد کنید"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("مقدار معتبر وارد کنید"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("نام انبار را وارد کنید"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("وزن را وارد کنید"),
        "enterWholeSalePrice": MessageLookupByLibrary.simpleMessage(
            "قیمت عمده‌فروشی را وارد کنید"),
        "enterYourDescriptionHere": MessageLookupByLibrary.simpleMessage(
            "توضیحات خود را در اینجا وارد کنید"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("آدرس ایمیل خود را وارد کنید"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "عنوان بازخورد خود را وارد کنید"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("شماره GST خود را وارد کنید"),
        "enterYourMobileNumber": MessageLookupByLibrary.simpleMessage(
            "شماره موبایل خود را وارد کنید"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("نام خود را وارد کنید"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("شماره تلفن خود را وارد کنید"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("رمز عبور خود را وارد کنید"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("شماره تلفن خود را وارد کنید"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "شناسه تراکنش خود را وارد کنید"),
        "error": MessageLookupByLibrary.simpleMessage("خطا"),
        "excTax": MessageLookupByLibrary.simpleMessage("غیر شامل مالیات"),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("بارگذاری کننده Excel"),
        "exclusive": MessageLookupByLibrary.simpleMessage("مستثنی"),
        "expense": MessageLookupByLibrary.simpleMessage("هزینه"),
        "expenseCategory": MessageLookupByLibrary.simpleMessage("دسته هزینه"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("تاریخ هزینه"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("هزینه برای"),
        "expenseReport": MessageLookupByLibrary.simpleMessage("گزارش هزینه"),
        "expireDate": MessageLookupByLibrary.simpleMessage("تاریخ انقضا"),
        "expired": MessageLookupByLibrary.simpleMessage("منقضی شده"),
        "expiring": MessageLookupByLibrary.simpleMessage("در حال انقضا"),
        "facebok": MessageLookupByLibrary.simpleMessage("فیسبوک"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("با خطا مواجه شد"),
        "fashion": MessageLookupByLibrary.simpleMessage("مد"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "ویژگی‌ها بخش مهمی هستند که Pos Saas را از راه‌حل‌های سنتی متمایز می‌کند."),
        "feedBack": MessageLookupByLibrary.simpleMessage("بازخورد"),
        "firstName": MessageLookupByLibrary.simpleMessage("نام"),
        "followUsOnFacebook": MessageLookupByLibrary.simpleMessage(
            "ما را در\\nفیس‌بوک دنبال کنید"),
        "followUsOnTwitter": MessageLookupByLibrary.simpleMessage(
            "ما را در\\nتوییتر دنبال کنید"),
        "fontSide": MessageLookupByLibrary.simpleMessage("روی صفحه"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("برای استفاده نامحدود"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("فراموشی رمزعبور"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("رمزعبور را فراموش کرده‌اید؟"),
        "formDate": MessageLookupByLibrary.simpleMessage("از تاریخ"),
        "freeDataBackup": MessageLookupByLibrary.simpleMessage(
            "پشتیبان‌گیری از داده‌ها رایگان"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "به‌روزرسانی رایگان برای همیشه"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("بسته رایگان"),
        "freePlan": MessageLookupByLibrary.simpleMessage("طرح رایگان"),
        "from": MessageLookupByLibrary.simpleMessage("(از"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("کاملاً پرداخت شده"),
        "gallary": MessageLookupByLibrary.simpleMessage("گالری"),
        "generatingPDF":
            MessageLookupByLibrary.simpleMessage("در حال تولید PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("دریافت OTP"),
        "govermentId": MessageLookupByLibrary.simpleMessage("شناسه دولتی"),
        "guest": MessageLookupByLibrary.simpleMessage("مهمان"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("حساب کاربری ندارید؟"),
        "history": MessageLookupByLibrary.simpleMessage("تاریخچه"),
        "home": MessageLookupByLibrary.simpleMessage("خانه"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "چگونه از اطلاعات شما محافظت می‌کنیم"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "چگونه از اطلاعات شما استفاده می‌کنیم"),
        "identityVerify": MessageLookupByLibrary.simpleMessage("تأیید هویت"),
        "image": MessageLookupByLibrary.simpleMessage("تصویر"),
        "inHouseCantBeDelete": MessageLookupByLibrary.simpleMessage(
            "انبار داخلی نمی‌تواند حذف شود"),
        "inHouseCantBeEdited": MessageLookupByLibrary.simpleMessage(
            "انبار داخلی قابل ویرایش نیست"),
        "inWord": MessageLookupByLibrary.simpleMessage("به حروف"),
        "incTax": MessageLookupByLibrary.simpleMessage("شامل مالیات"),
        "inclusive": MessageLookupByLibrary.simpleMessage("شامل"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("افزایش موجودی"),
        "inistrument": MessageLookupByLibrary.simpleMessage("ابزار"),
        "instragram": MessageLookupByLibrary.simpleMessage("اینستاگرام"),
        "invNo": MessageLookupByLibrary.simpleMessage("شماره فاکتور"),
        "invoice": MessageLookupByLibrary.simpleMessage("فاکتور"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("شماره فاکتور"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("تنظیمات فاکتور"),
        "invoiceViewer": MessageLookupByLibrary.simpleMessage("بیننده فاکتور"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("مورد افزوده شد"),
        "kg": MessageLookupByLibrary.simpleMessage("کیلوگرم"),
        "kycVerification": MessageLookupByLibrary.simpleMessage("تأیید KYC"),
        "language": MessageLookupByLibrary.simpleMessage("زبان"),
        "lastName": MessageLookupByLibrary.simpleMessage("نام خانوادگی"),
        "ledger": MessageLookupByLibrary.simpleMessage("دفتر روزنامه"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("خرید مادام‌العمر"),
        "link": MessageLookupByLibrary.simpleMessage("پیوند"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("لینکداین"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("پشتیبانی چت زنده"),
        "loading": MessageLookupByLibrary.simpleMessage("در حال بارگذاری"),
        "logIn": MessageLookupByLibrary.simpleMessage("ورود"),
        "logOUt": MessageLookupByLibrary.simpleMessage("خروج"),
        "logOut": MessageLookupByLibrary.simpleMessage("خروج"),
        "login": MessageLookupByLibrary.simpleMessage("ورود"),
        "logo": MessageLookupByLibrary.simpleMessage("لوگو"),
        "loss": MessageLookupByLibrary.simpleMessage("ضرر"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("ضرر/سود"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("جزئیات ضرر/سود"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("گزارش ضرر/سود"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("گزارشات ضرر/سود"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("هشدار موجودی کم"),
        "maan": MessageLookupByLibrary.simpleMessage("مان"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "برای مشتریان خود تأثیری دائمی بگذارید با فاکتورهای دارای برند. ارتقاء نامحدود ما این امتیاز منحصر به فرد را ارائه می‌دهد که شما می‌توانید فاکتورهای خود را سفارشی کنید و لمس حرفه‌ای‌ای به آن اضافه کنید که هویت برند شما را تقویت کرده و وفاداری مشتری را تقویت می‌کند."),
        "manageYourBussinessWith": MessageLookupByLibrary.simpleMessage(
            "کسب و کار خود را با مدیریت کنید با"),
        "manufactureDate": MessageLookupByLibrary.simpleMessage("تاریخ تولید"),
        "margin": MessageLookupByLibrary.simpleMessage("حاشیه"),
        "masterCard": MessageLookupByLibrary.simpleMessage("کارت مستر"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("تولیدکننده"),
        "message": MessageLookupByLibrary.simpleMessage("پیام"),
        "messageHistory": MessageLookupByLibrary.simpleMessage("تاریخچه پیام"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "برنامه Pos Saas رایگان و آسان در استفاده است. در واقع، این یکی از بهترین سیستم‌های POS در سراسر دنیاست."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas یک راهکار کامل کسب و کار با مدیریت موجودی، حسابداری، فروش، هزینه و سود/زیان است."),
        "mobile": MessageLookupByLibrary.simpleMessage("موبایل"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("پرداخت موبایلی"),
        "monthly": MessageLookupByLibrary.simpleMessage("ماهیانه"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("اطلاعات بیشتر"),
        "name": MessageLookupByLibrary.simpleMessage("نام خود را وارد کنید."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("نام قبلاً وجود دارد"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("نام نمی‌تواند خالی باشد"),
        "next": MessageLookupByLibrary.simpleMessage("بعدی"),
        "noConnection": MessageLookupByLibrary.simpleMessage("بدون اتصال"),
        "noData":
            MessageLookupByLibrary.simpleMessage("هیچ داده‌ای موجود نیست"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("داده‌ای موجود نیست"),
        "noDataFound": MessageLookupByLibrary.simpleMessage("داده‌ای یافت نشد"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("تاریخچه‌ای یافت نشد!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("محصولی پیدا نشد"),
        "noSubTaxSelected": MessageLookupByLibrary.simpleMessage(
            "هیچ مالیات فرعی انتخاب نشده است"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("تراکنشی یافت نشد!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "هیچ کاربری با آن آدرس ایمیل یافت نشد."),
        "noUserRoleFound":
            MessageLookupByLibrary.simpleMessage("هیچ نقش کاربری یافت نشد"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("کاربر فعال نیست"),
        "notProvided": MessageLookupByLibrary.simpleMessage("ارائه نشده"),
        "note": MessageLookupByLibrary.simpleMessage("یادداشت"),
        "notes": MessageLookupByLibrary.simpleMessage("یادداشت‌ها"),
        "notification": MessageLookupByLibrary.simpleMessage("اطلاعیه"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP به"),
        "office": MessageLookupByLibrary.simpleMessage("دفتر"),
        "ok": MessageLookupByLibrary.simpleMessage("تایید"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS که حاوی تعداد زیادی از قابلیت‌هاست، شامل پیگیری فروش و مدیریت موجودی."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "این سیستم به شما کمک می‌کند عملکردهای خود را برای مشتریان خود بهبود ببخشید."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "سیستم POS ما باید عملیات روزانه را به صورت خودکار ساده کند و ناوبری را آسان کند."),
        "openingBalance": MessageLookupByLibrary.simpleMessage("موجودی اولیه"),
        "order": MessageLookupByLibrary.simpleMessage("سفارش‌ها"),
        "other": MessageLookupByLibrary.simpleMessage("دیگر"),
        "otp": MessageLookupByLibrary.simpleMessage("بستن"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("تمام شده"),
        "pacakge": MessageLookupByLibrary.simpleMessage("بسته"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("ویژگی‌های بسته"),
        "paid": MessageLookupByLibrary.simpleMessage("پرداخت شده"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("مبلغ پرداختی"),
        "parties": MessageLookupByLibrary.simpleMessage("طرف‌ها"),
        "partiesList": MessageLookupByLibrary.simpleMessage("لیست طرف‌ها"),
        "partyGST": MessageLookupByLibrary.simpleMessage("GST طرف"),
        "partyName": MessageLookupByLibrary.simpleMessage("نام طرف"),
        "password": MessageLookupByLibrary.simpleMessage("رمزعبور"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "گذرواژه و تأیید گذرواژه مطابقت ندارند"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("گذرواژه نمی‌تواند خالی باشد"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("گذرواژه مطابقت ندارد"),
        "payCash": MessageLookupByLibrary.simpleMessage("پرداخت نقدی"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash": MessageLookupByLibrary.simpleMessage("پرداخت با bKash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("پرداخت با Paypal"),
        "payeeName": MessageLookupByLibrary.simpleMessage("نام گیرنده وجه"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("شماره گیرنده وجه"),
        "payment": MessageLookupByLibrary.simpleMessage("پرداخت"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("مبلغ پرداخت"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("پرداخت تکمیل شد"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("دستورالعمل پرداخت:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("روش پرداخت"),
        "paymentType": MessageLookupByLibrary.simpleMessage("نوع پرداخت"),
        "pdfView": MessageLookupByLibrary.simpleMessage("نمایش PDF"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("اطلاعات شخصی"),
        "phone": MessageLookupByLibrary.simpleMessage("تلفن"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("شماره تلفن"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "شماره تلفن قبلاً استفاده شده است"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("شماره تلفن نامعتبر است"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("شماره تلفن الزامی است"),
        "pickAndUploadFile": MessageLookupByLibrary.simpleMessage(
            "فایل را انتخاب و بارگذاری کنید"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("تاریخ پایان را انتخاب کنید"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("تاریخ شروع را انتخاب کنید"),
        "plan": MessageLookupByLibrary.simpleMessage("طرح"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("لطفاً مقدار را اضافه کنید"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "لطفاً اتصال اینترنت خود را بررسی کنید"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "لطفاً ابتدا چاپگر را متصل کنید"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "لطفاً پرینتر بلوتوث خود را متصل کنید"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "لطفاً یک گذرواژه بزرگ‌تر وارد کنید"),
        "pleaseEnterAConfirmPassword":
            MessageLookupByLibrary.simpleMessage("لطفاً رمزعبور را تأیید کنید"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("لطفاً یک رمزعبور وارد کنید"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "لطفاً یک ایمیل معتبر وارد کنید"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("لطفاً نام را وارد کنید"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("لطفاً گذرواژه را وارد کنید"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "لطفاً آدرس ایمیل خود را برای دریافت لینک تنظیم مجدد رمزعبور وارد کنید."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "لطفاً شماره تراکنش را وارد کنید"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("لطفاً مقدار را وارد کنید"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "لطفاً ابتدا یک دسته‌بندی انتخاب کنید"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("لطفاً یک برنامه انتخاب کنید"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "لطفاً دسته‌بندی کسب و کار را انتخاب کنید"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "لطفاً از کد خرید معتبر برای استفاده از برنامه استفاده کنید"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("پشتیبانی توسط Pos Saas"),
        "poweredBy":
            MessageLookupByLibrary.simpleMessage("توسعه داده شده توسط"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("پشتیبانی ویژه مشتریان"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("طرح پریمیوم"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("مبالغ پرداختی قبلی"),
        "price": MessageLookupByLibrary.simpleMessage("قیمت"),
        "print": MessageLookupByLibrary.simpleMessage("چاپ"),
        "printingOption": MessageLookupByLibrary.simpleMessage("گزینه چاپ"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("سیاست حریم خصوصی"),
        "product": MessageLookupByLibrary.simpleMessage("محصول"),
        "productCode": MessageLookupByLibrary.simpleMessage("کد محصول"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("کد محصول الزامی است"),
        "productCodeName": MessageLookupByLibrary.simpleMessage("کد/نام محصول"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("توضیحات محصول"),
        "productDetails": MessageLookupByLibrary.simpleMessage("جزئیات محصول"),
        "productList": MessageLookupByLibrary.simpleMessage("لیست محصولات"),
        "productName": MessageLookupByLibrary.simpleMessage("نام محصول"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "نام محصول قبلاً در این انبار وجود دارد"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "نام محصول قبلاً اضافه شده است"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("نام محصول الزامی است"),
        "products": MessageLookupByLibrary.simpleMessage("محصولات"),
        "profile": MessageLookupByLibrary.simpleMessage("پروفایل"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("ویرایش پروفایل"),
        "profit": MessageLookupByLibrary.simpleMessage("سود"),
        "promo": MessageLookupByLibrary.simpleMessage("پرومو"),
        "promoCode": MessageLookupByLibrary.simpleMessage("کد تخفیف"),
        "purchase": MessageLookupByLibrary.simpleMessage("خرید"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage("هشدار خرید"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("خرید تأیید شده"),
        "purchaseDetails": MessageLookupByLibrary.simpleMessage("جزئیات خرید"),
        "purchaseInvoice": MessageLookupByLibrary.simpleMessage("فاکتور خرید"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("لیست خرید"),
        "purchaseNow":
            MessageLookupByLibrary.simpleMessage("همین حالا خرید کنید"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("خرید طرح پریمیوم"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("قیمت خرید"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("قیمت خرید الزامی است"),
        "purchaseRepoet": MessageLookupByLibrary.simpleMessage("گزارش خرید"),
        "purchaseReports": MessageLookupByLibrary.simpleMessage("گزارش خرید"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("گزارش‌های خرید"),
        "purchaseReturn": MessageLookupByLibrary.simpleMessage("بازگشت خرید"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("گزارش بازگشت خرید"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("انتقال خرید"),
        "qty": MessageLookupByLibrary.simpleMessage("تعداد"),
        "quantity": MessageLookupByLibrary.simpleMessage("تعداد"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("تراکنش‌های اخیر"),
        "recivedThePin": MessageLookupByLibrary.simpleMessage("پین دریافت شد"),
        "referenceNumber": MessageLookupByLibrary.simpleMessage("شماره مرجع"),
        "register": MessageLookupByLibrary.simpleMessage("ثبت نام"),
        "registering": MessageLookupByLibrary.simpleMessage("در حال ثبت‌نام"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("بدهی باقی‌مانده"),
        "remove": MessageLookupByLibrary.simpleMessage("حذف"),
        "reports": MessageLookupByLibrary.simpleMessage("گزارش‌ها"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("درخواست ارسال شده است"),
        "resendCode": MessageLookupByLibrary.simpleMessage("ارسال مجدد کد"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("ارسال مجدد OTP: "),
        "retailer": MessageLookupByLibrary.simpleMessage("خرده‌فروش"),
        "retur": MessageLookupByLibrary.simpleMessage("برگشت"),
        "returN": MessageLookupByLibrary.simpleMessage("بازگشت"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("مقدار برگشتی"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("مبلغ بازگشتی"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("مقدار بازگشت"),
        "revenue": MessageLookupByLibrary.simpleMessage("درآمد"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "بازگردانی آسان داده‌های کسب و کارتان. ارتقاء نامحدود Pos Saas POS شامل پشتیبان‌گیری رایگان از داده‌های شما است و اطمینان حاصل می‌شود که اطلاعات ارزشمند شما در برابر هر نوع وقوع ناگوار محافظت شود. بر روی آنچه واقعاً مهم است، یعنی رشد کسب و کارتان، تمرکز کنید."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("مبلغ فروش"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("جزئیات فروش"),
        "salePrice": MessageLookupByLibrary.simpleMessage("قیمت فروش"),
        "saleReports": MessageLookupByLibrary.simpleMessage("گزارش فروش"),
        "saleReportss": MessageLookupByLibrary.simpleMessage("گزارش‌های فروش"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("بازگشت فروش"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("گزارش بازگشت فروش"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("تنظیمات فروش"),
        "sales": MessageLookupByLibrary.simpleMessage("فروش"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("گزارش‌های فروش و خرید"),
        "salesList": MessageLookupByLibrary.simpleMessage("لیست فروش‌ها"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("بازگشت فروش"),
        "save": MessageLookupByLibrary.simpleMessage("ذخیره"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("ذخیره و انتشار"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("ذخیره تغییرات"),
        "saving": MessageLookupByLibrary.simpleMessage("در حال ذخیره‌سازی"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("بارکد QR محصول را اسکن کنید"),
        "search": MessageLookupByLibrary.simpleMessage("جستجو"),
        "searchByProductCodeOrName":
            MessageLookupByLibrary.simpleMessage("جستجو با کد یا نام محصول"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("مشاهده تمام کدهای تخفیف"),
        "select": MessageLookupByLibrary.simpleMessage("انتخاب"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "یک محصول برای بازگشت انتخاب کنید"),
        "selectBrand":
            MessageLookupByLibrary.simpleMessage("برند را انتخاب کنید"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("دسته‌بندی را انتخاب کنید"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("انتخاب مخاطبین"),
        "selectProductCategory": MessageLookupByLibrary.simpleMessage(
            "دسته‌بندی محصول را انتخاب کنید"),
        "selectShopCategory": MessageLookupByLibrary.simpleMessage(
            "دسته‌بندی فروشگاه را انتخاب کنید"),
        "selectTax":
            MessageLookupByLibrary.simpleMessage("مالیات را انتخاب کنید"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("نوع مالیات را انتخاب کنید"),
        "selectUnit":
            MessageLookupByLibrary.simpleMessage("واحد را انتخاب کنید"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("انتخاب تغییرات:"),
        "seller": MessageLookupByLibrary.simpleMessage("فروشنده"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("فروشنده"),
        "send": MessageLookupByLibrary.simpleMessage("ارسال"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("ارسال ایمیل"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("ارسال پیام"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("ارسال لینک تنظیم مجدد"),
        "sendSms": MessageLookupByLibrary.simpleMessage("ارسال پیامک"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("ارسال پیامک؟"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("ارسال پیام واتساپ"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("ارسال ایمیل شما"),
        "sendingEmail":
            MessageLookupByLibrary.simpleMessage("در حال ارسال ایمیل"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("در حال ارسال پیام"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("خدمات/حمل و نقل"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("پروفایل خود را تنظیم کنید"),
        "setting": MessageLookupByLibrary.simpleMessage("تنظیمات"),
        "share": MessageLookupByLibrary.simpleMessage("اشتراک‌گذاری"),
        "shopGST": MessageLookupByLibrary.simpleMessage("GST فروشگاه"),
        "signIn": MessageLookupByLibrary.simpleMessage("ورود"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("با ایمیل وارد شوید"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("امضای مشتری"),
        "size": MessageLookupByLibrary.simpleMessage("اندازه"),
        "skip": MessageLookupByLibrary.simpleMessage("رد کردن"),
        "sms": MessageLookupByLibrary.simpleMessage("پیامک"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("بازاریابی اجتماعی"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "متاسفیم، شما اجازه دسترسی به این سرویس را ندارید"),
        "startDate": MessageLookupByLibrary.simpleMessage("تاریخ شروع"),
        "startNewSale": MessageLookupByLibrary.simpleMessage("شروع فروش جدید"),
        "startTypingToSearch":
            MessageLookupByLibrary.simpleMessage("برای جستجو تایپ کنید"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "در جلوی پیشرفت‌های فناوری بمانید بدون هزینه اضافی. ارتقاء نامحدود Pos Saas POS ما تضمین می‌کند که همیشه آخرین ابزار و ویژگی‌ها در دسترس شما باشد و تضمین می‌شود که کسب و کار شما در جلوی رقبا قرار دارد."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("هنوز پرداخت نشده"),
        "stock": MessageLookupByLibrary.simpleMessage("موجودی"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("موجودی الزامی است"),
        "stockList": MessageLookupByLibrary.simpleMessage("لیست موجودی"),
        "stocks": MessageLookupByLibrary.simpleMessage("موجودی"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "اجازه ذخیره‌سازی برای ایجاد فایل Excel الزامی است"),
        "subTaxList":
            MessageLookupByLibrary.simpleMessage("لیست مالیات‌های فرعی"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("مالیات‌های فرعی"),
        "subTotal": MessageLookupByLibrary.simpleMessage("مجموع جزئی"),
        "submit": MessageLookupByLibrary.simpleMessage("ارسال"),
        "subscribeToOurYoutube":
            MessageLookupByLibrary.simpleMessage("به\\nیوتیوب ما مشترک شوید"),
        "subscription": MessageLookupByLibrary.simpleMessage("اشتراک"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("با موفقیت انجام شد"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("با موفقیت خارج شدید"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("با موفقیت به‌روزرسانی شد"),
        "supplier": MessageLookupByLibrary.simpleMessage("تامین‌کننده"),
        "supplierName": MessageLookupByLibrary.simpleMessage("نام تامین‌کننده"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("کد سوئیفت (SWIFT)"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "یک مدرک رانندگی، کارت ملی یا عکس پاسپورت ارائه دهید"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "یک کارت شناسایی برای بررسی اطلاعات خود ببرید"),
        "tap": MessageLookupByLibrary.simpleMessage("ضربه بزنید"),
        "tax": MessageLookupByLibrary.simpleMessage("مالیات"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("گروه مالیات"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("درصد مالیات"),
        "taxRate": MessageLookupByLibrary.simpleMessage("نرخ مالیات"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "نرخ‌های مالیاتی - مدیریت نرخ‌های مالیاتی شما"),
        "taxReport": MessageLookupByLibrary.simpleMessage("گزارش مالیات"),
        "taxType": MessageLookupByLibrary.simpleMessage("نوع مالیات"),
        "taxes": MessageLookupByLibrary.simpleMessage("مالیات‌ها"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("شرایط و ضوابط"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("شرایط استفاده"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("شرایط و حریم خصوصی"),
        "thankYOuForYourDuePayment":
            MessageLookupByLibrary.simpleMessage("از پرداخت بدهی شما متشکریم"),
        "thankYou": MessageLookupByLibrary.simpleMessage("متشکرم"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("از خرید شما متشکریم"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "حساب برای این ایمیل قبلاً وجود دارد"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "فایل Excel قبلاً دانلود شده است"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "نام همه چیز را می‌گوید. با Pos Saas POS بی‌نهایت، محدودیتی در استفاده شما وجود ندارد. برای مطالبه یک دسته تراکنش یا تجربه افزایش مشتریان مطمئن باشید که توسط محدودیت‌ها محدود نیستید."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "گذرواژه ارائه شده خیلی ضعیف است"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "فروش حذف خواهد شد و تمام داده‌های مربوط به این خرید حذف خواهد شد. آیا مطمئن هستید که می‌خواهید این را حذف کنید؟"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "فروش حذف خواهد شد و تمام داده‌های مربوط به این فروش حذف خواهد شد. آیا مطمئن هستید که می‌خواهید این را حذف کنید؟"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "کاربر حذف خواهد شد و تمام داده‌ها از حساب شما حذف می‌شود. آیا مطمئنید که می‌خواهید حذف کنید؟"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "کاربر حذف خواهد شد و تمام داده‌ها از حساب شما حذف خواهد شد. آیا مطمئن هستید که می‌خواهید این کار را انجام دهید؟"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("خدمات شرکت‌های سوم"),
        "thisCategoryCannotBeDeleted":
            MessageLookupByLibrary.simpleMessage("این دسته نمی‌تواند حذف شود"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(این ماه)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "این محصول قبلاً اضافه شده است"),
        "title": MessageLookupByLibrary.simpleMessage("عنوان"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("عنوان نمی‌تواند خالی باشد"),
        "to": MessageLookupByLibrary.simpleMessage("تا"),
        "toDate": MessageLookupByLibrary.simpleMessage("تا تاریخ"),
        "today": MessageLookupByLibrary.simpleMessage("امروز"),
        "total": MessageLookupByLibrary.simpleMessage("مجموع"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("مبلغ کل"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("مجموع جمع‌آوری شده"),
        "totalDue": MessageLookupByLibrary.simpleMessage("مجموع بدهی"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("مجموع هزینه"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("کل زیان"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("مجموع قابل پرداخت"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("قیمت کل"),
        "totalProducts": MessageLookupByLibrary.simpleMessage("کل محصولات"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("کل سود"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("کل خرید"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("مجموع مبلغ بازگشت"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("کل بازگشت‌ها"),
        "totalSale": MessageLookupByLibrary.simpleMessage("مجموع فروش"),
        "totalStock": MessageLookupByLibrary.simpleMessage("موجودی کل"),
        "totalValue": MessageLookupByLibrary.simpleMessage("مجموع ارزش"),
        "totalVat": MessageLookupByLibrary.simpleMessage("مجموع مالیات"),
        "totals": MessageLookupByLibrary.simpleMessage("مجموع: "),
        "transaction": MessageLookupByLibrary.simpleMessage("تراکنش"),
        "transactionId": MessageLookupByLibrary.simpleMessage("شناسه تراکنش"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("دوباره امتحان کنید"),
        "twitter": MessageLookupByLibrary.simpleMessage("توییتر"),
        "type": MessageLookupByLibrary.simpleMessage("نوع"),
        "unitName": MessageLookupByLibrary.simpleMessage("نام واحد"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("قیمت واحد"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("قیمت واحد"),
        "units": MessageLookupByLibrary.simpleMessage("واحد"),
        "unlimited": MessageLookupByLibrary.simpleMessage("نامحدود"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("استفاده نامحدود"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "پتانسیل کامل Pos Saas POS را با جلسات آموزش شخصی توسط تیم متخصص ما باز کنید. از مباحث ابتدایی تا تکنیک‌های پیشرفته، ما تضمین می‌کنیم که شما در استفاده از هر جنبه از سیستم برای بهینه‌سازی فرآیندهای کسب و کارتان ماهر شوید."),
        "unpaid": MessageLookupByLibrary.simpleMessage("پرداخت نشده"),
        "update": MessageLookupByLibrary.simpleMessage("به‌روزرسانی"),
        "updateContact": MessageLookupByLibrary.simpleMessage("بروزرسانی تماس"),
        "updateNow":
            MessageLookupByLibrary.simpleMessage("اکنون به‌روزرسانی کنید"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("به‌روزرسانی محصول"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "ابتدا طرح خود را به‌روزرسانی کنید، \nمحدودیت شما تمام شده است"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("به‌روزرسانی پروفایل شما"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "پروفایل خود را بروز کرده تا بهترین تاثیر را برای ارتباط با پزشک خود داشته باشید"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "پروفایل خود را به‌روز کنید تا با ارتباط بهتری با مشتریان ارتباط برقرار کنید"),
        "updated": MessageLookupByLibrary.simpleMessage("به‌روزرسانی شد"),
        "upload": MessageLookupByLibrary.simpleMessage("بارگذاری"),
        "uploadDocument": MessageLookupByLibrary.simpleMessage("آپلود مستند"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("بارگذاری انجام شد"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("آپلود فایل"),
        "upplier": MessageLookupByLibrary.simpleMessage("تامین‌کننده"),
        "usbC": MessageLookupByLibrary.simpleMessage("USB C"),
        "use": MessageLookupByLibrary.simpleMessage("استفاده"),
        "useMobiPos":
            MessageLookupByLibrary.simpleMessage("استفاده از Pos Saas"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("استفاده از سیستم"),
        "userIsDeleted": MessageLookupByLibrary.simpleMessage("کاربر حذف شد"),
        "userRole": MessageLookupByLibrary.simpleMessage("نقش کاربر"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("جزئیات نقش کاربر"),
        "userTitle": MessageLookupByLibrary.simpleMessage("عنوان کاربر"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "عنوان کاربر نمی‌تواند خالی باشد"),
        "value": MessageLookupByLibrary.simpleMessage("ارزش"),
        "vatDoesNotApply": MessageLookupByLibrary.simpleMessage(
            "مالیات بر ارزش افزوده اعمال نمی‌شود"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("تأیید OTP"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("تأیید شماره تلفن"),
        "viewAll": MessageLookupByLibrary.simpleMessage("نمایش همه"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("مشاهده جزئیات"),
        "walkInCustomer": MessageLookupByLibrary.simpleMessage("مشتری حضوری"),
        "warehouse": MessageLookupByLibrary.simpleMessage("انبار"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("انبار قبلاً وجود دارد"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("لیست انبار"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("نام انبار"),
        "warranty": MessageLookupByLibrary.simpleMessage("گارانتی"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "ما یک ایمیل حاوی دستورالعمل برای تنظیم مجدد رمزعبور به آدرس زیر ارسال کرده‌ایم:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "ممکن است از خدمات شرکت‌های سوم برای پشتیبانی از عملکرد اپلیکیشن ما، مانند ارائه‌دهندگان تجزیه و تحلیل و پردازندگان پرداخت استفاده کنیم. این خدمات شرکت‌های سوم ممکن است اطلاعاتی در مورد شما جمع‌آوری کنند هنگامی که از اپلیکیشن ما استفاده می‌کنید. لطفاً توجه داشته باشید که ما مسئولیت رفتارهای حریم خصوصی این خدمات شرکت‌های سوم را نداریم."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "ما اقدامات استاندارد صنعتی را برای حفاظت از اطلاعات شخصی شما اعمال می‌کنیم، شامل رمزنگاری و ذخیره سازی امن است. همچنین دسترسی به اطلاعات شما را فقط برای پرسنل مجاز محدود می‌کنیم."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "ما اهمیت عملیات بدون دلایل درگیری را می‌فهمیم. به همین دلیل پشتیبانی 24 ساعته ما برای کمک به شما در هر زمانی که نیاز دارید، سوال سریع یا مشکل کامل، در دسترس است. با ما در هر زمان و هر مکان از طریق تماس یا واتساپ تماس بگیرید تا تجربه‌ای بی‌نظیر از خدمات مشتری داشته باشید."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "ما از اطلاعات شخصی شما برای ارائه بهترین تجربه ممکن در اپلیکیشن ما استفاده می‌کنیم، از جمله شخصی‌سازی توصیه‌های محتوا، اتصال شما با کارشناسان و بهبود عملکرد اپلیکیشن ما. ممکن است همچنین از اطلاعات شما برای ارتباط با شما در مورد به‌روزرسانی‌ها، تبلیغات و یا سایر اطلاعات مرتبط با اپلیکیشن ما استفاده کنیم."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "ما پرداخت را بررسی کرده و در عرض ۱-۲ ساعت تأیید خواهیم کرد"),
        "weekly": MessageLookupByLibrary.simpleMessage("هفتگی"),
        "weight": MessageLookupByLibrary.simpleMessage("وزن"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("جدید چیست"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("عمده‌فروش"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("قیمت عمده‌فروشی"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("قیمت عمده"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("عمده‌فروش"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("به زودی اضافه خواهد شد"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("در تاریخ انقضا"),
        "writeYourMessageHere": MessageLookupByLibrary.simpleMessage(
            "پیام خود را در اینجا بنویسید"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("OTP نادرست"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "رمزعبور اشتباه برای آن کاربر ارائه شده است."),
        "yearly": MessageLookupByLibrary.simpleMessage("سالیانه"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("بله، به طور دائم حذف کن"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("شما کاربر معتبر نیستید"),
        "youAreUsing":
            MessageLookupByLibrary.simpleMessage("شما در حال استفاده از"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "نمی‌توانید بیشتر از مبلغ معوقه پرداخت کنید"),
        "youHaveGotAnEmail": MessageLookupByLibrary.simpleMessage(
            "شما یک ایمیل دریافت کرده‌اید"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "شما با موفقیت وارد حساب کاربری خود شده‌اید. با Pos Saas همراه باشید."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("شما باید اجازه دهید"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "شما باید مجددا وارد حساب کاربری خود شوید."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "شما باید قبل از خرید تأیید هویت کنید"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("پیام شما باقی می‌ماند"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("بسته شما"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "بسته شما تا 5 روز دیگر منقضی می‌شود")
      };
}
