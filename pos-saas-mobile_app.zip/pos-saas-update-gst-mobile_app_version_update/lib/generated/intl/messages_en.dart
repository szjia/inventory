// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a en locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'en';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Continue"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("GST Number"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("MRP is required"),
        "OK": MessageLookupByLibrary.simpleMessage("OK"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Ph.no"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT Code"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Snacks"),
        "TAX": MessageLookupByLibrary.simpleMessage("TAX"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Uploading"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("User Title"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Your Package Will Expire Today\n\nPlease Purchase again"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) The System is provided solely for the\npurpose of facilitating point of sale\ntransactions andrelatedactivities in your\nbusiness."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) To use the System, you may be\nrequired to create an account. You\nagree to provide accurate, current, and\ncomplete information during\nthe registration process and toupdate\nsuchinformationto keep itaccurate\nand complete."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("About App"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("About us"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Acceptance of Terms"),
        "accountName": MessageLookupByLibrary.simpleMessage("Account Name"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("Account Number"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Account Registration"),
        "acton": MessageLookupByLibrary.simpleMessage("Acton"),
        "add": MessageLookupByLibrary.simpleMessage("Add"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Add Brand"),
        "addCategory": MessageLookupByLibrary.simpleMessage("Add Category"),
        "addContact": MessageLookupByLibrary.simpleMessage("Add Contact"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Add Customer"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("Add Delivery"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Add Description"),
        "addDescription": MessageLookupByLibrary.simpleMessage("Add note"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Add Discount"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Add Document Id"),
        "addDucument": MessageLookupByLibrary.simpleMessage("Add Document"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Add Expense"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Add Expense Category"),
        "addItems": MessageLookupByLibrary.simpleMessage("Add Items"),
        "addNew": MessageLookupByLibrary.simpleMessage("Add New"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Add New Address"),
        "addNewProduct": MessageLookupByLibrary.simpleMessage("Add Product"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("Add New Tax"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Add New Tax with single/multiple Tax type"),
        "addNote": MessageLookupByLibrary.simpleMessage("Add Note"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Add product first"),
        "addPromoCode": MessageLookupByLibrary.simpleMessage("Add Promo Code"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Add Purchase"),
        "addSales": MessageLookupByLibrary.simpleMessage("Add Sales"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Added Successful"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Add Unit"),
        "addUserRole": MessageLookupByLibrary.simpleMessage("Add User Role"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Added Successfully"),
        "addedToCart": MessageLookupByLibrary.simpleMessage("Added To Cart"),
        "address": MessageLookupByLibrary.simpleMessage("Address"),
        "admin": MessageLookupByLibrary.simpleMessage("Admin"),
        "all": MessageLookupByLibrary.simpleMessage("All"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("All business solutions"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("Already Added"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Already Exists"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Already Have An Accounts"),
        "amount": MessageLookupByLibrary.simpleMessage("Amount"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "An Email has been sent\\nCheck your inbox"),
        "androidIOSAppSupport":
            MessageLookupByLibrary.simpleMessage("Android & iOS App Support"),
        "applicableTax": MessageLookupByLibrary.simpleMessage("Applicable Tax"),
        "apply": MessageLookupByLibrary.simpleMessage("Apply"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Are you sure to delete this invoice"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Are you sure to delete this sale"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Are you sure to delete this user"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Are you sure want to delete this Tax"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Are you sure want to delete this Tax Group"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Are you want to delete this warehouse"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Are you sure to delete this user?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Authorized Signature"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) You are responsible for\nmaintainingthe confidentiality of your\naccount and password andfor restricting\naccess to your account. You accept\nresponsibility for all activities that\noccur under your account."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) You must be at least 18 years old or the\nlegal age of majority in your jurisdiction to\nuse the System."),
        "backSide": MessageLookupByLibrary.simpleMessage("Back side"),
        "backToHome": MessageLookupByLibrary.simpleMessage("Back To Home"),
        "balance": MessageLookupByLibrary.simpleMessage("Balance"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladesh"),
        "bank": MessageLookupByLibrary.simpleMessage("Bank"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Bank Account Currency"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Bank Account Currency"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Bank Information"),
        "bankName": MessageLookupByLibrary.simpleMessage("Bank Name"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("Bank Transfer"),
        "barcodeFound": MessageLookupByLibrary.simpleMessage("Barcode found"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Bill/Invoice"),
        "billTo": MessageLookupByLibrary.simpleMessage("Bill To"),
        "branchName": MessageLookupByLibrary.simpleMessage("Branch Name"),
        "brand": MessageLookupByLibrary.simpleMessage("Brand"),
        "brandName": MessageLookupByLibrary.simpleMessage("Brand Name"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("Bulk \nUpload"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Business Category"),
        "buy": MessageLookupByLibrary.simpleMessage("Buy"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Buy Premium Plan"),
        "buySms": MessageLookupByLibrary.simpleMessage("Buy Sms"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "By accessing or using the Point of Sale (POS) System (the \"System\") provided by [Your Company Name] (\"Company\"), you agree to be bound by these Terms of Use. If you do not agree to these Terms of Use, do not use the System."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) You are responsible for ensuring that your\naccess to and use of the System is in\ncompliance with all applicable laws and\nregulations."),
        "cacel": MessageLookupByLibrary.simpleMessage("Cancel"),
        "call": MessageLookupByLibrary.simpleMessage("Call"),
        "callForEmergencySupport":
            MessageLookupByLibrary.simpleMessage("Call For Emergency Support"),
        "camera": MessageLookupByLibrary.simpleMessage("Camera"),
        "cancel": MessageLookupByLibrary.simpleMessage("Cancel"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Cancel All Product"),
        "capacity": MessageLookupByLibrary.simpleMessage("Capacity"),
        "card": MessageLookupByLibrary.simpleMessage("Card"),
        "cash": MessageLookupByLibrary.simpleMessage("Cash"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Categories"),
        "category": MessageLookupByLibrary.simpleMessage("Category"),
        "categoryName": MessageLookupByLibrary.simpleMessage("Category Name"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "Category Name Already Exists"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("Category Name"),
        "change": MessageLookupByLibrary.simpleMessage("Change?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Change Password"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("Check Email"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Chose a Customer"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Chose a Supplier"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Choose your features"),
        "clarence": MessageLookupByLibrary.simpleMessage("Clarence"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Click to connect"),
        "close": MessageLookupByLibrary.simpleMessage("Close"),
        "color": MessageLookupByLibrary.simpleMessage("Color"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(Combination of multiple taxes)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Coming Soon"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Company Address"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Company & Shop Name"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("Company & Business Name"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Complete Transaction"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Confirm Password"),
        "confirmReturn": MessageLookupByLibrary.simpleMessage("Confirm return"),
        "congratulations":
            MessageLookupByLibrary.simpleMessage("Congratulations"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Contact Us"),
        "continu": MessageLookupByLibrary.simpleMessage("Continue"),
        "country": MessageLookupByLibrary.simpleMessage("Country"),
        "create": MessageLookupByLibrary.simpleMessage("Create"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Create a Free Account"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Created and Saved"),
        "currency": MessageLookupByLibrary.simpleMessage("Currency"),
        "currentStock": MessageLookupByLibrary.simpleMessage("Current Stock"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("Custom Invoice Branding"),
        "customer": MessageLookupByLibrary.simpleMessage("Customer"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Customer Details"),
        "customerGST": MessageLookupByLibrary.simpleMessage("Customer GST"),
        "customerName": MessageLookupByLibrary.simpleMessage("Customer Name"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Daily Transaction"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Dashboard Overview"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Data Saved Successfully"),
        "date": MessageLookupByLibrary.simpleMessage("Date"),
        "day": MessageLookupByLibrary.simpleMessage("Day"),
        "dealer": MessageLookupByLibrary.simpleMessage("Dealer"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("Dealer Price"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("Default VAT percentage"),
        "delete": MessageLookupByLibrary.simpleMessage("Delete"),
        "deleting": MessageLookupByLibrary.simpleMessage("Deleting"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Delivery Address"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Delivery Addresses"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Delivery Charge"),
        "describtion": MessageLookupByLibrary.simpleMessage("Description"),
        "description": MessageLookupByLibrary.simpleMessage("Description"),
        "descriptionCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Description can\\\'n be empty"),
        "details": MessageLookupByLibrary.simpleMessage("Details"),
        "discount": MessageLookupByLibrary.simpleMessage("Discount"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Do not disturb"),
        "done": MessageLookupByLibrary.simpleMessage("Done"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Download Excel Format"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Downloaded successfully in download folder"),
        "due": MessageLookupByLibrary.simpleMessage("Due"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Due Amount: "),
        "dueCollection": MessageLookupByLibrary.simpleMessage("Due Collection"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("Due Collection Reports"),
        "dueList": MessageLookupByLibrary.simpleMessage("Due List"),
        "dueReports": MessageLookupByLibrary.simpleMessage("Due Report"),
        "duration": MessageLookupByLibrary.simpleMessage("Duration"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Duration: From"),
        "easyToUseMobilePos":
            MessageLookupByLibrary.simpleMessage("Easy to use mobile pos"),
        "edit": MessageLookupByLibrary.simpleMessage("Edit"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Edit Purchase Invoice"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Edit Sales Invoice"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Edit Social Media"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Edit Successfully"),
        "editTax": MessageLookupByLibrary.simpleMessage("Edit Tax"),
        "editTaxGroup": MessageLookupByLibrary.simpleMessage("Edit Tax Group"),
        "editWarehouse": MessageLookupByLibrary.simpleMessage("Edit Warehouse"),
        "email": MessageLookupByLibrary.simpleMessage("Email"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("Email Address"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Email can\\\'n be empty"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "Email Sent! Check your Inbox"),
        "endDate": MessageLookupByLibrary.simpleMessage("End Date"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Enter a valid Amount"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Enter a valid Discount"),
        "enterAValidPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Enter a valid phone number"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Enter a valid price"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("Enter a valid quantity"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("Enter Address"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("Enter Amount."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Enter Brand Name"),
        "enterCapacity": MessageLookupByLibrary.simpleMessage("Enter Capacity"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Enter Category Name"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Enter Color"),
        "enterCustomerGstNumber":
            MessageLookupByLibrary.simpleMessage("Enter customer gst number"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Enter Dealer Price"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Enter Description"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("Enter Discount."),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Enter Expense Date"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Enter Full Address"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Enter Invoice Number"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Enter Low Stock Alert Quantity"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Enter Manufacturer"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("Enter Message Content"),
        "enterMrpOrRetailerPirce":
            MessageLookupByLibrary.simpleMessage("Enter MRP/Retailer Price"),
        "enterName": MessageLookupByLibrary.simpleMessage("Enter Name"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Enter Note"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Enter Party Name"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Enter Phone Number"),
        "enterProductCodeOrScan":
            MessageLookupByLibrary.simpleMessage("Enter Product Code Or Scan"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Enter Product Name"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Enter Purchase Price."),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("Enter Reference Number"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Enter Size"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("Enter Stocks."),
        "enterTaxRate": MessageLookupByLibrary.simpleMessage("Enter Tax rate"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("Enter Transaction Id"),
        "enterType": MessageLookupByLibrary.simpleMessage("Enter Type"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("Enter user title"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Enter Valid Amount"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Enter Warehouse Name"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Enter Weight"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Enter Wholesale Price"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("Enter your description here"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("Enter Your Email Address"),
        "enterYourFeedBackTitle":
            MessageLookupByLibrary.simpleMessage("Enter Your Feedback Tittle"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Enter your GST Number"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("Enter your mobile number"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Enter Your Name"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("Enter your phone number"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Enter your password"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Enter Your Phone Number"),
        "enterYourTransactionId":
            MessageLookupByLibrary.simpleMessage("Enter your transaction id"),
        "error": MessageLookupByLibrary.simpleMessage("Error"),
        "excTax": MessageLookupByLibrary.simpleMessage("Exc. Tax"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("Excel Uploader"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Exclusive"),
        "expense": MessageLookupByLibrary.simpleMessage("Expense"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Expense Category"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Expense Date"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Expense For"),
        "expenseReport": MessageLookupByLibrary.simpleMessage("Expense Report"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Expire Date"),
        "expired": MessageLookupByLibrary.simpleMessage("Expired"),
        "expiring": MessageLookupByLibrary.simpleMessage("Expiring"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Failed with Error"),
        "fashion": MessageLookupByLibrary.simpleMessage("Fashion"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Features are the important part which makes Pos Saas  different from traditional solutions."),
        "feedBack": MessageLookupByLibrary.simpleMessage("FeedBack"),
        "firstName": MessageLookupByLibrary.simpleMessage("First Name"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Follow Us On\\nFacebook"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Follow Us On\\nTwitter"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Font Side"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("For unlimited usages"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Forgot password"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Forgot Password?"),
        "formDate": MessageLookupByLibrary.simpleMessage("From Date"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("Free Data Backup"),
        "freeLifeTimeUpdate":
            MessageLookupByLibrary.simpleMessage("Free Lifetime Update"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Free Package"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Free Plan"),
        "from": MessageLookupByLibrary.simpleMessage("(From"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Fully Paid"),
        "gallary": MessageLookupByLibrary.simpleMessage("Gallery"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("Generating PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Get Otp"),
        "govermentId": MessageLookupByLibrary.simpleMessage("Government Id"),
        "guest": MessageLookupByLibrary.simpleMessage("Guest"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Haven\'t any account?"),
        "history": MessageLookupByLibrary.simpleMessage("History"),
        "home": MessageLookupByLibrary.simpleMessage("Home"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "How We Protect Your Information"),
        "howWeUseYourInformation":
            MessageLookupByLibrary.simpleMessage("How We Use Your Information"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Identity Verify"),
        "image": MessageLookupByLibrary.simpleMessage("Image"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("InHouse can\\\'t be delete"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("InHouse can\'t be edited"),
        "inWord": MessageLookupByLibrary.simpleMessage("In Word"),
        "incTax": MessageLookupByLibrary.simpleMessage("Inc. tax"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Inclusive"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("Increase Stock"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Instrument"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Inv No."),
        "invoice": MessageLookupByLibrary.simpleMessage("Invoice"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("Invoice Number"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Invoice Setting"),
        "invoiceViewer": MessageLookupByLibrary.simpleMessage("Invoice Viewer"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Item Added"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("KYC Verification"),
        "language": MessageLookupByLibrary.simpleMessage("Language"),
        "lastName": MessageLookupByLibrary.simpleMessage("Last Name"),
        "ledger": MessageLookupByLibrary.simpleMessage("Ledger"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Lifetime\nPurchase"),
        "link": MessageLookupByLibrary.simpleMessage("Link"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Live Chat Support"),
        "loading": MessageLookupByLibrary.simpleMessage("Loading"),
        "logIn": MessageLookupByLibrary.simpleMessage("LogIn"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Log Out"),
        "logOut": MessageLookupByLibrary.simpleMessage("Log out"),
        "login": MessageLookupByLibrary.simpleMessage("Log In"),
        "logo": MessageLookupByLibrary.simpleMessage("Logo"),
        "loss": MessageLookupByLibrary.simpleMessage("Loss"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Loss/Profit"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Loss/Profit Details"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Loss/Profit Report"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Loss/Profit Reports"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Low Stock Alert"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Make a lasting impression on your customers with branded invoices. Our Unlimited Upgrade offers the unique advantage of customizing your invoices, adding a professional touch that reinforces your brand identity and fosters customer loyalty."),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("Manage your business with "),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Manufacture Date"),
        "margin": MessageLookupByLibrary.simpleMessage("Margin"),
        "masterCard": MessageLookupByLibrary.simpleMessage("Master card"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Manufacturer"),
        "message": MessageLookupByLibrary.simpleMessage("Message"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Message History"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Pos Saas  app is free, easy to use. In fact, it\'s one of the best  POS systems around the world."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas  is a complete business solution with stock, account, sales, expense & loss/profit."),
        "mobile": MessageLookupByLibrary.simpleMessage("Mobile"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("Mobile Payment"),
        "monthly": MessageLookupByLibrary.simpleMessage("Monthly"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("More Info"),
        "name": MessageLookupByLibrary.simpleMessage("Enter Your Name."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Name  Already Exists"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("Name can\\\'t be empty"),
        "next": MessageLookupByLibrary.simpleMessage("Next"),
        "noConnection": MessageLookupByLibrary.simpleMessage("No Connection"),
        "noData": MessageLookupByLibrary.simpleMessage("No Data"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("No data available"),
        "noDataFound": MessageLookupByLibrary.simpleMessage("No Data Found"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("No History Found!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("No product Found"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("No Sub Tax selected"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("No Transaction Found!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "No user found for that email."),
        "noUserRoleFound":
            MessageLookupByLibrary.simpleMessage("No User Role Found"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Not Active User"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Not Provided"),
        "note": MessageLookupByLibrary.simpleMessage("Note"),
        "notes": MessageLookupByLibrary.simpleMessage("notes"),
        "notification": MessageLookupByLibrary.simpleMessage("Notification"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP sent to"),
        "office": MessageLookupByLibrary.simpleMessage("Office"),
        "ok": MessageLookupByLibrary.simpleMessage("Ok"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS that contains a great deal of functionality, including sales tracking, inventory management."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "This system helps you improve your operations for your customers."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Our POS system should simplify daily operations automatically, making it easy to navigate."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("Opening Balance "),
        "order": MessageLookupByLibrary.simpleMessage("Orders"),
        "other": MessageLookupByLibrary.simpleMessage("Other"),
        "otp": MessageLookupByLibrary.simpleMessage("Close"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Out of Stock"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Package"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Package Features"),
        "paid": MessageLookupByLibrary.simpleMessage("Paid"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Paid Amount"),
        "parties": MessageLookupByLibrary.simpleMessage("Parties"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Parties List"),
        "partyGST": MessageLookupByLibrary.simpleMessage("Party GST"),
        "partyName": MessageLookupByLibrary.simpleMessage("Party Name"),
        "password": MessageLookupByLibrary.simpleMessage("Password"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Password and confirm password does not match"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Password can\\\'t be empty"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("Password Not mach"),
        "payCash": MessageLookupByLibrary.simpleMessage("Pay Cash"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash": MessageLookupByLibrary.simpleMessage("Pay with bkash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Pay with Paypal"),
        "payeeName": MessageLookupByLibrary.simpleMessage("Payee Name"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("Payee Number"),
        "payment": MessageLookupByLibrary.simpleMessage("Payment"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("Payment Amount"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Payment Complete"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Payment Instruction:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("Payment Method"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Payment Type"),
        "pdfView": MessageLookupByLibrary.simpleMessage("Pdf View"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Personal Information"),
        "phone": MessageLookupByLibrary.simpleMessage("Phone"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Phone Number"),
        "phoneNumberAlreadyUsed":
            MessageLookupByLibrary.simpleMessage("Phone Number Already Used"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("Phone number is not valid"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("Phone Number is required"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("Pick and Upload File"),
        "pickEndDate": MessageLookupByLibrary.simpleMessage("Pick End Date"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Pick Start Date"),
        "plan": MessageLookupByLibrary.simpleMessage("Plan"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("Please add quantity"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Please check your internet connectivity"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Please Connect The Printer First"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Please connect your bluetooth Printer"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Please enter a bigger password"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Please Enter A Confirm Password"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("Please enter a password"),
        "pleaseEnterAValidEmail":
            MessageLookupByLibrary.simpleMessage("Please enter a valid email"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Please Enter Name"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("Please Enter Password"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Please enter your email address below to receive password Reset Link."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Please Enter Transaction Number"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("please Inter Amount"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Please select a category first"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("Please Select a Plan"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Please Select Business Category"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Please use the valid purchase code to use the app"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Powered By Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Powered By"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Premium Customer Support"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Premium plan"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Previous Pay Amounts"),
        "price": MessageLookupByLibrary.simpleMessage("price"),
        "print": MessageLookupByLibrary.simpleMessage("Print"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Printing Option"),
        "privacyPolicy": MessageLookupByLibrary.simpleMessage("Privacy Policy"),
        "product": MessageLookupByLibrary.simpleMessage("Product"),
        "productCode": MessageLookupByLibrary.simpleMessage("Product Code"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("Product Code is Required"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Product code/Name"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Product Description"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Product Details"),
        "productList": MessageLookupByLibrary.simpleMessage("Product List"),
        "productName": MessageLookupByLibrary.simpleMessage("Product Name"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Product Name already exists in this warehouse"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Product name is already added"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("Product name is required"),
        "products": MessageLookupByLibrary.simpleMessage("Products"),
        "profile": MessageLookupByLibrary.simpleMessage("Profile"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("Profile Edit"),
        "profit": MessageLookupByLibrary.simpleMessage("Profit"),
        "promo": MessageLookupByLibrary.simpleMessage("promo"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Promo Code"),
        "purchase": MessageLookupByLibrary.simpleMessage("Purchase"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage("Purchase Alarm"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Purchase Confirmed"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Purchase Details"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Purchase Invoice"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("Purchase List"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Purchase Now"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Purchase Premium Plan"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("Purchase Price"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("Purchase Price is required"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("Purchase Report"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Purchase Price"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Purchase Reports"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("Purchase Return"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("Purchase Return Report"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Purchase Transition"),
        "qty": MessageLookupByLibrary.simpleMessage("Qty"),
        "quantity": MessageLookupByLibrary.simpleMessage("Quantity"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Recent Transactions"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("Received The pin"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Reference Number"),
        "register": MessageLookupByLibrary.simpleMessage("Register"),
        "registering": MessageLookupByLibrary.simpleMessage("Registering"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("Remaining Due"),
        "remove": MessageLookupByLibrary.simpleMessage("Remove"),
        "reports": MessageLookupByLibrary.simpleMessage("Reports"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Request has been send"),
        "resendCode": MessageLookupByLibrary.simpleMessage("Resend Code"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("Resend OTP : "),
        "retailer": MessageLookupByLibrary.simpleMessage("Retailer"),
        "retur": MessageLookupByLibrary.simpleMessage("Return"),
        "returN": MessageLookupByLibrary.simpleMessage("Return"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("Return Amount"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("Return Amount"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("Return QTY"),
        "revenue": MessageLookupByLibrary.simpleMessage("Revenue"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Safeguard your business data effortlessly. Our Pos Saas POS Unlimited Upgrade includes free data backup, ensuring your valuable information is protected against any unforeseen events. Focus on what truly matters - your business growth."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Sale Amount"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("Sale Details"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Sale Price"),
        "saleReports": MessageLookupByLibrary.simpleMessage("Sale Report"),
        "saleReportss": MessageLookupByLibrary.simpleMessage("Sale Reports"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("Sale return"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Sale Return Report"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("Sale Setting"),
        "sales": MessageLookupByLibrary.simpleMessage("Sales"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("Sale & Purchase Reports"),
        "salesList": MessageLookupByLibrary.simpleMessage("Sales List"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("Sales Return"),
        "save": MessageLookupByLibrary.simpleMessage("Save"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Save and Publish"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("Save Changes"),
        "saving": MessageLookupByLibrary.simpleMessage("Saving"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("Scan product QR code"),
        "search": MessageLookupByLibrary.simpleMessage("Search"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Search by product code or name"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("See all promo codes"),
        "select": MessageLookupByLibrary.simpleMessage("Select"),
        "selectAProductForReturn":
            MessageLookupByLibrary.simpleMessage("Select a product for return"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Select Brand"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Select Category"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Select Contacts"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("Select Product Category"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("Select Shop Category"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Select Tax"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Select Tax type"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("Select Unit"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Select Variation: "),
        "seller": MessageLookupByLibrary.simpleMessage("Seller"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Sells By"),
        "send": MessageLookupByLibrary.simpleMessage("Send"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("Send Email"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Send Message"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("Send Reset Link"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Send Sms"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Send sms?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Send whatsapp message"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Send Your Email"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage("Sending Email"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Sending message"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Service/Shipping"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Setup Your Profile"),
        "setting": MessageLookupByLibrary.simpleMessage("Setting"),
        "share": MessageLookupByLibrary.simpleMessage("Share"),
        "shopGST": MessageLookupByLibrary.simpleMessage("Shop GST"),
        "signIn": MessageLookupByLibrary.simpleMessage("Sign In"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("Sign in with email"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Signature of Customer"),
        "size": MessageLookupByLibrary.simpleMessage("Size"),
        "skip": MessageLookupByLibrary.simpleMessage("Skip"),
        "sms": MessageLookupByLibrary.simpleMessage("Sms"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Social Marketing"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Sorry, you have no permission to access this service"),
        "startDate": MessageLookupByLibrary.simpleMessage("Start Date"),
        "startNewSale": MessageLookupByLibrary.simpleMessage("Start New Sale"),
        "startTypingToSearch":
            MessageLookupByLibrary.simpleMessage("Start typing to search"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Stay at the forefront of technological advancements without any extra costs. Our Pos Saas POS Unlimited Upgrade ensures that you always have the latest tools and features at your fingertips, guaranteeing your business remains cutting-edge."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("Still Unpaid"),
        "stock": MessageLookupByLibrary.simpleMessage("Stock"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Stock is required"),
        "stockList": MessageLookupByLibrary.simpleMessage("Stock List"),
        "stocks": MessageLookupByLibrary.simpleMessage("Stocks"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Storage permission is required to create Excel file"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("Sub Tax List"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Sub Taxes"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Sub Total"),
        "submit": MessageLookupByLibrary.simpleMessage("Submit"),
        "subscribeToOurYoutube":
            MessageLookupByLibrary.simpleMessage("Subscribe To Our\\nYoutube"),
        "subscription": MessageLookupByLibrary.simpleMessage("Subscription"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Successfully Done"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Successfully Logged Out"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Successfully Updated"),
        "supplier": MessageLookupByLibrary.simpleMessage("Supplier"),
        "supplierName": MessageLookupByLibrary.simpleMessage("Supplier Name"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT Code"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Take a driver\'s license, national identity card or passport photo"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "Take an identity card to check your information"),
        "tap": MessageLookupByLibrary.simpleMessage("Tap"),
        "tax": MessageLookupByLibrary.simpleMessage("Tax"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Tax Group"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("Tax Percentage"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Tax rate"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Tax rates- Manage your Tax rates"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Tax Report"),
        "taxType": MessageLookupByLibrary.simpleMessage("Tax Type"),
        "taxes": MessageLookupByLibrary.simpleMessage("Taxes"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Terms and Conditions"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("Terms of use"),
        "termsPrivacy": MessageLookupByLibrary.simpleMessage("Terms & Privacy"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Thank You For Your DUe Payment"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Thank You"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Thank You for your purchase"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "The account already exists for that email"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "The Excel file has already been downloaded"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "The name says it all. With Pos Saas POS Unlimited, there\'s no cap on your usage. Whether you\'re processing a handful of transactions or experiencing a rush of customers, you can operate with confidence, knowing you\'re not constrained by limits"),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "The password provided is too weak"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "The sale will be deleted and all the data will be deleted about this purchase.Are you sure to delete this"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "The sale will be deleted and all the data will be deleted about this sale.Are you sure to delete this"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "The user will be deleted and all the data will be deleted from your account.Are you sure to delete this?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "The user will be deleted and all the data will be deleted from your account.Are you sure to delete this"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Third-Party Services"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "This category Cannot be deleted"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(This Month)"),
        "thisProductAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("This Product Already added"),
        "title": MessageLookupByLibrary.simpleMessage("Title"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Title can\'n be empty"),
        "to": MessageLookupByLibrary.simpleMessage("to"),
        "toDate": MessageLookupByLibrary.simpleMessage("To Date"),
        "today": MessageLookupByLibrary.simpleMessage("Today"),
        "total": MessageLookupByLibrary.simpleMessage("Total"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Total Amount"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Total Collected"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Total Due"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("Total Expense"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Total Loss"),
        "totalPayable": MessageLookupByLibrary.simpleMessage("Total Payable"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Total Price"),
        "totalProducts": MessageLookupByLibrary.simpleMessage("Total Products"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Total Profit"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("Total Purchase"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Total Return Amount"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("Total returns"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Total Sale"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Total Stocks"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Total value"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Total Vat"),
        "totals": MessageLookupByLibrary.simpleMessage("Total: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Transaction"),
        "transactionId": MessageLookupByLibrary.simpleMessage("Transaction Id"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Try Again"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Type"),
        "unitName": MessageLookupByLibrary.simpleMessage("Unit Name"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Unit Price"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Unit Price"),
        "units": MessageLookupByLibrary.simpleMessage("Units"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Unlimited"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Unlimited Usage"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Unlock the full potential of Pos Saas POS with personalized training sessions led by our expert team. From the basics to advanced techniques, we ensure you\'re well-versed in utilizing every facet of the system to optimize your business processes."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Unpaid"),
        "update": MessageLookupByLibrary.simpleMessage("Update"),
        "updateContact": MessageLookupByLibrary.simpleMessage("Update Contact"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Update Now"),
        "updateProduct": MessageLookupByLibrary.simpleMessage("Update Product"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Update your plan first,\\nyour limit is over"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Update Your Profile"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Update your profile to connect your doctor with better impression"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Update your profile to connect your customer with better impression"),
        "updated": MessageLookupByLibrary.simpleMessage("Updated"),
        "upload": MessageLookupByLibrary.simpleMessage("Upload"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Upload Document"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("Upload Done"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Upload File"),
        "upplier": MessageLookupByLibrary.simpleMessage("Supplier"),
        "usbC": MessageLookupByLibrary.simpleMessage("Usb C"),
        "use": MessageLookupByLibrary.simpleMessage("Use"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("Use Pos Saas"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Use of the system"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("User is deleted"),
        "userRole": MessageLookupByLibrary.simpleMessage("User Role"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("User Role Details"),
        "userTitle": MessageLookupByLibrary.simpleMessage("User Title"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "User title can\\\'n be empty"),
        "value": MessageLookupByLibrary.simpleMessage("Value"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("Vat Doesn\\\'t Apply"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("Verifying OTP"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Verify Phone Number"),
        "viewAll": MessageLookupByLibrary.simpleMessage("View All"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("View details"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Walk-in customer"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Warehouse"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Warehouse  Already Exists"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("Warehouse List"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("Warehouse Name"),
        "warranty": MessageLookupByLibrary.simpleMessage("Warranty"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "We Have Send An Email with instructions on how to reset password to:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "We may use third-party services to support our app\'s functionality, such as analytics providers and payment processors. These third-party services may collect information about you when you use our app. Please note that we are not responsible for the privacy practices of these third-party services."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "We take industry-standard measures to protect your personal information, including encryption and secure storage. We also limit access to your information to authorized personnel only."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            " We understand the importance of seamless operations. That\'s why our round-the-clock support is available to assist you, whether it\'s a quick query or a comprehensive concern. Connect with us anytime, anywhere via call or WhatsApp to experience unrivaled customer service."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "We use your personal information to provide you with the best possible experience on our app, including to personalize your content recomme ndations, connect you with experts, and improve our apps functionality. We may also use your information to communicate with you about updates, promotions, or other information related to our app."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "We will review the payment & approve it within 1-2 hours"),
        "weekly": MessageLookupByLibrary.simpleMessage("Weekly"),
        "weight": MessageLookupByLibrary.simpleMessage("Weight"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("What\'s New"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Wholesaler"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("WholeSale Price"),
        "wholesalePrice":
            MessageLookupByLibrary.simpleMessage("Wholesale price"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Wholesaler"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Will be Added Soon"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Will Expire at"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Write your message here"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("Wrong OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Wrong password provided for that user."),
        "yearly": MessageLookupByLibrary.simpleMessage("Yearly"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Yes, Delete Forever"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("You Are Not A Valid User"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("You are using"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "You can\\\'t pay more then due"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("You Have Got An Email"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "You are successfully login into your account. Stay with Pos Saas ."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("You Have To Give Permission"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "You have to RE-LOGIN on your account."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "You need to identity verify before your buying sms"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Your message remains"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Your Package"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Your Package Will Expire in 5 Day")
      };
}
