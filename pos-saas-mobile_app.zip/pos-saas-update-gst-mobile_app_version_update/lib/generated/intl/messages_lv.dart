// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a lv locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'lv';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Turpināt"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("GST numurs"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("MRP ir nepieciešams"),
        "OK": MessageLookupByLibrary.simpleMessage("Labi"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Ph.nr."),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT kods"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Uzkodas"),
        "TAX": MessageLookupByLibrary.simpleMessage("NODOKLIS"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Augšupielādēšana"),
        "UserTitle":
            MessageLookupByLibrary.simpleMessage("Lietotāja nosaukums"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Jūsu pakete beigsies šodien\n\nLūdzu, iegādājieties to vēlreiz"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) Sistēma tiek nodrošināta tikai, lai atvieglotu tirdzniecības vietas darījumus un saistītās aktivitātes jūsu biznesā."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) Lai izmantotu Sistēmu, iespējams, jums būs jāizveido konts. Jūs piekrītat sniegt precīzu, aktuālu un pilnīgu informāciju reģistrācijas procesā un atjaunināt šo informāciju, lai tā būtu precīza un pilnīga."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("Par lietotni"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Par mums"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Noteikumu pieņemšana"),
        "accountName": MessageLookupByLibrary.simpleMessage("Kontu nosaukums"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("Kontu numurs"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Konta reģistrācija"),
        "acton": MessageLookupByLibrary.simpleMessage("Darbība"),
        "add": MessageLookupByLibrary.simpleMessage("Pievienot"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Pievienot zīmolu"),
        "addCategory":
            MessageLookupByLibrary.simpleMessage("Pievienot kategoriju"),
        "addContact":
            MessageLookupByLibrary.simpleMessage("Pievienot kontaktu"),
        "addCustomer":
            MessageLookupByLibrary.simpleMessage("Pievienot klientu"),
        "addDelivery":
            MessageLookupByLibrary.simpleMessage("Pievienot piegādi"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Pievienot aprakstu"),
        "addDescription":
            MessageLookupByLibrary.simpleMessage("Pievienot piezīmi"),
        "addDiscount":
            MessageLookupByLibrary.simpleMessage("Pievienot atlaidi"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Pievienot dokumenta ID"),
        "addDucument":
            MessageLookupByLibrary.simpleMessage("Pievienot dokumentu"),
        "addExpense":
            MessageLookupByLibrary.simpleMessage("Pievienot izdevumus"),
        "addExpenseCategory": MessageLookupByLibrary.simpleMessage(
            "Pievienot izdevumu kategoriju"),
        "addItems": MessageLookupByLibrary.simpleMessage("Pievienot preces"),
        "addNew": MessageLookupByLibrary.simpleMessage("Pievienot jaunu"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Pievienot jaunu adresi"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Pievienot produktu"),
        "addNewTax":
            MessageLookupByLibrary.simpleMessage("Pievienot jaunu nodokli"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Pievienot jaunu nodokli ar vienu/dažādiem nodokļu veidiem"),
        "addNote": MessageLookupByLibrary.simpleMessage("Pievienot piezīmi"),
        "addProductFirst": MessageLookupByLibrary.simpleMessage(
            "Vispirms pievienojiet produktu"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Pievienot akcijas kodu"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Pievienot iegādi"),
        "addSales": MessageLookupByLibrary.simpleMessage("Pievienot pārdošanu"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Veiksmīgi pievienots"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Pievienot vienību"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Pievienot lietotāja lomu"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Pievienots veiksmīgi"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("Pievienots grozam"),
        "address": MessageLookupByLibrary.simpleMessage("Adrese"),
        "admin": MessageLookupByLibrary.simpleMessage("Admins"),
        "all": MessageLookupByLibrary.simpleMessage("Visi"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("Visi biznesa risinājumi"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("Jau pievienots"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Jau eksistē"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Jau ir konts"),
        "amount": MessageLookupByLibrary.simpleMessage("Summa"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "Uz jūsu e-pastu ir nosūtīta ziņa. Pārbaudiet savu iesūtnes"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Android un iOS lietotnes atbalsts"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Piemērojamais nodoklis"),
        "apply": MessageLookupByLibrary.simpleMessage("Pieteikt"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Vai tiešām vēlaties dzēst šo rēķinu?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Vai tiešām vēlaties dzēst šo pārdošanu?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Vai tiešām vēlaties dzēst šo lietotāju?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Vai tiešām vēlaties dzēst šo nodokli?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Vai tiešām vēlaties dzēst šo nodokļu grupu?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Vai tiešām vēlaties dzēst šo noliktavu?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Vai tiešām vēlaties dzēst šo lietotāju?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Pilnvarota paraksts"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Jūs esat atbildīgs par savu konta un paroles konfidencialitātes uzturēšanu un piekļuves ierobežošanu jūsu kontam. Jūs piekrītat atbildībai par visām darbībām, kas notiek jūsu kontā."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Jums jābūt vismaz 18 gadus vecam vai likumīgā vecumā jūsu jurisdikcijā, lai izmantotu Sistēmu."),
        "backSide": MessageLookupByLibrary.simpleMessage("Aizmugure"),
        "backToHome": MessageLookupByLibrary.simpleMessage("Atpakaļ uz sākumu"),
        "balance": MessageLookupByLibrary.simpleMessage("Bilance"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladeša"),
        "bank": MessageLookupByLibrary.simpleMessage("Banka"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Bankas konta valūta"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Bankas konta valūta"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Bankas informācija"),
        "bankName": MessageLookupByLibrary.simpleMessage("Bankas nosaukums"),
        "bankTransfer":
            MessageLookupByLibrary.simpleMessage("Bankas pārskaitījums"),
        "barcodeFound": MessageLookupByLibrary.simpleMessage("Barkods atrasts"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Rēķins/Rēķins"),
        "billTo": MessageLookupByLibrary.simpleMessage("Rēķins uz"),
        "branchName":
            MessageLookupByLibrary.simpleMessage("Filiales nosaukums"),
        "brand": MessageLookupByLibrary.simpleMessage("Zīmols"),
        "brandName": MessageLookupByLibrary.simpleMessage("Zīmola nosaukums"),
        "bulkUpload":
            MessageLookupByLibrary.simpleMessage("Masveida \nAugšupielāde"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Uzņēmumu kategorija"),
        "buy": MessageLookupByLibrary.simpleMessage("Pirkt"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Iegādāties Premium plānu"),
        "buySms": MessageLookupByLibrary.simpleMessage("Iegādāties SMS"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Piekļūstot vai izmantojot tirdzniecības vietas (POS) sistēmu (turpmāk \"Sistēma\"), ko nodrošina [Jūsu uzņēmuma nosaukums] (\"Uzņēmums\"), jūs piekrītat šiem lietošanas noteikumiem. Ja jūs nepiekrītat šiem lietošanas noteikumiem, nelietojiet Sistēmu."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Jūs esat atbildīgs par to, lai jūsu piekļuve un Sistēmas izmantošana atbilst visiem piemērojamajiem likumiem un noteikumiem."),
        "cacel": MessageLookupByLibrary.simpleMessage("Atcelt"),
        "call": MessageLookupByLibrary.simpleMessage("Zvanīt"),
        "callForEmergencySupport":
            MessageLookupByLibrary.simpleMessage("Zvaniet ārkārtas atbalstam"),
        "camera": MessageLookupByLibrary.simpleMessage("Kamera"),
        "cancel": MessageLookupByLibrary.simpleMessage("Atcelt"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Atcelt visus produktus"),
        "capacity": MessageLookupByLibrary.simpleMessage("Jauda"),
        "card": MessageLookupByLibrary.simpleMessage("Karte"),
        "cash": MessageLookupByLibrary.simpleMessage("Nauda"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Kategorijas"),
        "category": MessageLookupByLibrary.simpleMessage("Kategorija"),
        "categoryName":
            MessageLookupByLibrary.simpleMessage("Kategorijas nosaukums"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "Kategorijas nosaukums jau eksistē"),
        "cateogryName":
            MessageLookupByLibrary.simpleMessage("Kategorijas nosaukums"),
        "change": MessageLookupByLibrary.simpleMessage("Mainīt?"),
        "changePassword": MessageLookupByLibrary.simpleMessage("Mainīt paroli"),
        "checkEmail":
            MessageLookupByLibrary.simpleMessage("Pārbaudiet e-pastu"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Izvēlieties klientu"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Izvēlieties piegādātāju"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Izvēlieties savas funkcijas"),
        "clarence": MessageLookupByLibrary.simpleMessage("Atlaide"),
        "clickToConnect": MessageLookupByLibrary.simpleMessage(
            "Noklikšķiniet, lai savienotu"),
        "close": MessageLookupByLibrary.simpleMessage("Aizvērt"),
        "color": MessageLookupByLibrary.simpleMessage("Krāsa"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(Dažādu nodokļu kombinācija)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Drīzumā"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Uzņēmuma adrese"),
        "companyAndShopName": MessageLookupByLibrary.simpleMessage(
            "Uzņēmuma un veikala nosaukums"),
        "companyBusinessName": MessageLookupByLibrary.simpleMessage(
            "Uzņēmuma un biznesa nosaukums"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Pabeigt transakciju"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Apstipriniet paroli"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Apstipriniet atgriešanu"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Apsveicam"),
        "contactUs":
            MessageLookupByLibrary.simpleMessage("Sazinieties ar mums"),
        "continu": MessageLookupByLibrary.simpleMessage("Turpināt"),
        "country": MessageLookupByLibrary.simpleMessage("Valsts"),
        "create": MessageLookupByLibrary.simpleMessage("Izveidot"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Izveidot bezmaksas kontu"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Izveidots un saglabāts"),
        "currency": MessageLookupByLibrary.simpleMessage("Valūta"),
        "currentStock":
            MessageLookupByLibrary.simpleMessage("Pašreizējais krājums"),
        "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
            "Pielāgota rēķinu zīmola identitāte"),
        "customer": MessageLookupByLibrary.simpleMessage("Klients"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Klienta detaļas"),
        "customerGST": MessageLookupByLibrary.simpleMessage("Klienta GST"),
        "customerName": MessageLookupByLibrary.simpleMessage("Klienta vārds"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Ikdienas darījums"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Darbības pārskats"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Dati veiksmīgi saglabāti"),
        "date": MessageLookupByLibrary.simpleMessage("Datums"),
        "day": MessageLookupByLibrary.simpleMessage("Diena"),
        "dealer": MessageLookupByLibrary.simpleMessage("Dīleris"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("Dīlera cena"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("Noklusējuma PVN procents"),
        "delete": MessageLookupByLibrary.simpleMessage("Dzēst"),
        "deleting": MessageLookupByLibrary.simpleMessage("Dzēšana"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Piegādes adrese"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Piegādes adreses"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Piegādes maksa"),
        "describtion": MessageLookupByLibrary.simpleMessage("Apraksts"),
        "description": MessageLookupByLibrary.simpleMessage("Apraksts"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Apraksts nevar būt tukšs"),
        "details": MessageLookupByLibrary.simpleMessage("Detaļas"),
        "discount": MessageLookupByLibrary.simpleMessage("Atlaide"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Nepārtrauciet"),
        "done": MessageLookupByLibrary.simpleMessage("Izpildīts"),
        "downloadExcelFormat": MessageLookupByLibrary.simpleMessage(
            "Lejupielādējiet Excel formātu"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Veiksmīgi lejupielādēts lejupielāžu mapē"),
        "due": MessageLookupByLibrary.simpleMessage("Jāmaksā"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Parādu summa: "),
        "dueCollection": MessageLookupByLibrary.simpleMessage("Parādu vākšana"),
        "dueCollectionReports": MessageLookupByLibrary.simpleMessage(
            "Parādsaistību iekasēšanas ziņojumi"),
        "dueList": MessageLookupByLibrary.simpleMessage("Parādu saraksts"),
        "dueReports": MessageLookupByLibrary.simpleMessage("Parāda pārskats"),
        "duration": MessageLookupByLibrary.simpleMessage("Ilgums"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Ilgums: No"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "Viegli lietojams mobilais POS"),
        "edit": MessageLookupByLibrary.simpleMessage("Rediģēt"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Rediģēt iepirkumu rēķinu"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Rediģēt pārdošanas rēķinu"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Rediģēt sociālos medijus"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Veiksmīgi rediģēts"),
        "editTax": MessageLookupByLibrary.simpleMessage("Rediģēt nodokli"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Rediģēt nodokļu grupu"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("Rediģēt noliktavu"),
        "email": MessageLookupByLibrary.simpleMessage("E-pasts"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("E-pasta adrese"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("E-pasts nevar būt tukšs"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "E-pasts nosūtīts! Pārbaudiet savu iesūtnes"),
        "endDate": MessageLookupByLibrary.simpleMessage("Beigu datums"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Ievadiet derīgu summu"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Ievadiet derīgu atlaidi"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Ievadiet derīgu telefona numuru"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Ievadiet derīgu cenu"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("Ievadiet derīgu daudzumu"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("Ievadiet adresi"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("Ievadiet summu."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Ievadiet zīmola nosaukumu"),
        "enterCapacity": MessageLookupByLibrary.simpleMessage("Ievadiet jaudu"),
        "enterCategoryName": MessageLookupByLibrary.simpleMessage(
            "Ievadiet kategorijas nosaukumu"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Ievadiet krāsu"),
        "enterCustomerGstNumber":
            MessageLookupByLibrary.simpleMessage("Ievadiet klienta GST numuru"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Ievadiet dīlera cenu"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Ievadiet aprakstu"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("Ievadiet atlaidi."),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Ievadiet izdevumu datumu"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Ievadiet pilnu adresi"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Ievadiet rēķina numuru"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Ievadiet zems krājumu brīdinājuma daudzumu"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Ievadiet ražotāju"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("Ievadiet ziņojuma saturu"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "Ievadiet MRP/mazumtirgotāja cenu"),
        "enterName": MessageLookupByLibrary.simpleMessage("Ievadiet vārdu"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Ievadiet piezīmi"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Ievadiet partijas nosaukumu"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Ievadiet tālruņa numuru"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Ievadiet produkta kodu vai skenējiet"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Ievadiet produkta nosaukumu"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Ievadiet iegādes cenu."),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("Ievadiet atsauces numuru"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Ievadiet izmēru"),
        "enterStocks":
            MessageLookupByLibrary.simpleMessage("Ievadiet krājumus."),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Ievadiet nodokļa likmi"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("Ievadiet darījuma ID"),
        "enterType": MessageLookupByLibrary.simpleMessage("Ievadiet veidu"),
        "enterUserTitle": MessageLookupByLibrary.simpleMessage(
            "Ievadiet lietotāja nosaukumu"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Ievadiet derīgu summu"),
        "enterWarehouseName": MessageLookupByLibrary.simpleMessage(
            "Ievadiet noliktavas nosaukumu"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Ievadiet svaru"),
        "enterWholeSalePrice": MessageLookupByLibrary.simpleMessage(
            "Ievadiet vairumtirdzniecības cenu"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("Ievadiet savu aprakstu šeit"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "Ievadiet savu e-pasta adresi"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "Ievadiet savas atsauksmes nosaukumu"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Ievadiet savu GST numuru"),
        "enterYourMobileNumber": MessageLookupByLibrary.simpleMessage(
            "Ievadiet savu mobilā tālruņa numuru"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Ievadiet savu vārdu"),
        "enterYourNumber": MessageLookupByLibrary.simpleMessage(
            "Ievadiet savu tālruņa numuru"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Ievadiet savu paroli"),
        "enterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Ievadiet savu tālruņa numuru"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "Ievadiet savu transakcijas ID"),
        "error": MessageLookupByLibrary.simpleMessage("Kļūda"),
        "excTax": MessageLookupByLibrary.simpleMessage("Bez nodokļa"),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("Excel augšupielādētājs"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Nesatur"),
        "expense": MessageLookupByLibrary.simpleMessage("Izdevumi"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Izdevumu kategorija"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Izdevumu datums"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Izdevumi par"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Izdevumu pārskats"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Derīguma datums"),
        "expired": MessageLookupByLibrary.simpleMessage("Beidzies"),
        "expiring":
            MessageLookupByLibrary.simpleMessage("Derīguma termiņš beidzas"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Neizdevās ar kļūdu"),
        "fashion": MessageLookupByLibrary.simpleMessage("Mode"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Funkcijas ir svarīga daļa, kas atšķir POS SaaS no tradicionālajām risinājumiem."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Atsauksmes"),
        "firstName": MessageLookupByLibrary.simpleMessage("Vārds"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Sekojiet mums Facebook"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Sekojiet mums Twitter"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Priekšpuse"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("Neierobežotai lietošanai"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Aizmirsāt paroli"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Aizmirsāt paroli?"),
        "formDate": MessageLookupByLibrary.simpleMessage("No datuma"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("Bezmaksas datu dublēšana"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "Bezmaksas mūža atjauninājums"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Bezmaksas pakete"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Bezmaksas plāns"),
        "from": MessageLookupByLibrary.simpleMessage("(No"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Pilnībā apmaksāts"),
        "gallary": MessageLookupByLibrary.simpleMessage("Galerija"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("PDF ģenerēšana"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Saņemt OTP"),
        "govermentId": MessageLookupByLibrary.simpleMessage("Valdības ID"),
        "guest": MessageLookupByLibrary.simpleMessage("Viesis"),
        "havenotAnAccounts": MessageLookupByLibrary.simpleMessage("Nav konta?"),
        "history": MessageLookupByLibrary.simpleMessage("Vēsture"),
        "home": MessageLookupByLibrary.simpleMessage("Sākums"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Kā mēs aizsargājam jūsu informāciju"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Kā mēs izmantojam jūsu informāciju"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Identitātes verifikācija"),
        "image": MessageLookupByLibrary.simpleMessage("Attēls"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("Iekšējais nevar tikt dzēsts"),
        "inHouseCantBeEdited": MessageLookupByLibrary.simpleMessage(
            "Iekšējais nevar tikt rediģēts"),
        "inWord": MessageLookupByLibrary.simpleMessage("Vārdos"),
        "incTax": MessageLookupByLibrary.simpleMessage("Iekļ. nodoklis"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Iekļauts"),
        "increaseStock":
            MessageLookupByLibrary.simpleMessage("Palielināt krājumus"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Instruments"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Rēķins Nr."),
        "invoice": MessageLookupByLibrary.simpleMessage("Rēķins"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("Rēķina numurs"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Rēķina iestatījumi"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Rēķinu skatītājs"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Prece pievienota"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("KYC Verifikācija"),
        "language": MessageLookupByLibrary.simpleMessage("Valoda"),
        "lastName": MessageLookupByLibrary.simpleMessage("Uzvārds"),
        "ledger": MessageLookupByLibrary.simpleMessage("Grāmatvedība"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Mūža pirkums"),
        "link": MessageLookupByLibrary.simpleMessage("Saite"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport": MessageLookupByLibrary.simpleMessage(
            "Tiešsaistes tērzēšanas atbalsts"),
        "loading": MessageLookupByLibrary.simpleMessage("Ielādējas"),
        "logIn": MessageLookupByLibrary.simpleMessage("Pieslēgties"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Iziet"),
        "logOut": MessageLookupByLibrary.simpleMessage("Izrakstīties"),
        "login": MessageLookupByLibrary.simpleMessage("Pierakstīties"),
        "logo": MessageLookupByLibrary.simpleMessage("Logo"),
        "loss": MessageLookupByLibrary.simpleMessage("Zaudējums"),
        "lossOrProfit":
            MessageLookupByLibrary.simpleMessage("Zaudējumi / Peļņa"),
        "lossOrProfitDetails": MessageLookupByLibrary.simpleMessage(
            "Zaudējumu / Peļņas detalizācija"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Zaudējumu/peļņas pārskats"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Zaudējumu/peļņas pārskati"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Zems krājumu brīdinājums"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Izveidojiet paliekošu iespaidu uz saviem klientiem ar zīmola rēķiniem. Mūsu neierobežotais atjauninājums piedāvā unikālu priekšrocību pielāgot jūsu rēķinus, pievienojot profesionālu pieskārienu, kas nostiprina jūsu zīmola identitāti un veicina klientu lojalitāti."),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("Pārvaldiet savu biznesu ar "),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Ražošanas datums"),
        "margin": MessageLookupByLibrary.simpleMessage("Piemaksa"),
        "masterCard": MessageLookupByLibrary.simpleMessage("MasterCard"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Ražotājs"),
        "message": MessageLookupByLibrary.simpleMessage("Ziņojums"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Ziņojumu vēsture"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "POS SaaS lietotne ir bezmaksas, viegli lietojama. Patiesībā tā ir viena no labākajām POS sistēmām visā pasaulē."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "POS SaaS ir pilnīgs biznesa risinājums ar krājumiem, grāmatvedību, pārdošanu, izdevumiem un peļņu/zaudējumiem."),
        "mobile": MessageLookupByLibrary.simpleMessage("Mobilais"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("Mobilā maksa"),
        "monthly": MessageLookupByLibrary.simpleMessage("Mēnesī"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("Vairāk informācijas"),
        "name": MessageLookupByLibrary.simpleMessage("Ievadiet savu vārdu."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Nosaukums jau eksistē"),
        "nameCantBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Nosaukumam nedrīkst būt tukša vērtība"),
        "next": MessageLookupByLibrary.simpleMessage("Nākamais"),
        "noConnection": MessageLookupByLibrary.simpleMessage("Nav savienojuma"),
        "noData": MessageLookupByLibrary.simpleMessage("Nav datu"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Nav pieejamu datu"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Dati netika atrasti"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("Nav atrasta vēsture!"),
        "noProductFound": MessageLookupByLibrary.simpleMessage(
            "Nav atrasts neviens produkts"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("Nav izvēlēts apakšnodoklis"),
        "noTransactionFound": MessageLookupByLibrary.simpleMessage(
            "Nav atrasta neviena transakcija!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Nav lietotāja, kas atbilst šai e-pasta adresei."),
        "noUserRoleFound":
            MessageLookupByLibrary.simpleMessage("Nav atrasta lietotāja loma"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Neaktīvs lietotājs"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Nav sniegts"),
        "note": MessageLookupByLibrary.simpleMessage("Piezīme"),
        "notes": MessageLookupByLibrary.simpleMessage("Piezīmes"),
        "notification": MessageLookupByLibrary.simpleMessage("Paziņojums"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP nosūtīts uz"),
        "office": MessageLookupByLibrary.simpleMessage("Birojs"),
        "ok": MessageLookupByLibrary.simpleMessage("Labi"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS, kas ietver daudz funkcionalitātes, tostarp pārdošanas uzskaiti un krājumu pārvaldību."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Šī sistēma palīdz jums uzlabot jūsu darbību pret klientiem."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Mūsu POS sistēmai jāatvieglo ikdienas operācijas automātiski, padarot to viegli saprotamu."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("Atvēršanas bilance"),
        "order": MessageLookupByLibrary.simpleMessage("Pasūtījumi"),
        "other": MessageLookupByLibrary.simpleMessage("Cits"),
        "otp": MessageLookupByLibrary.simpleMessage("Aizvērt"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Nav krājumā"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Pakalpojums"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Paketes funkcijas"),
        "paid": MessageLookupByLibrary.simpleMessage("Samaksāts"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Samaksātā summa"),
        "parties": MessageLookupByLibrary.simpleMessage("Puses"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Partiju saraksts"),
        "partyGST": MessageLookupByLibrary.simpleMessage("Puses GST"),
        "partyName": MessageLookupByLibrary.simpleMessage("Partijas nosaukums"),
        "password": MessageLookupByLibrary.simpleMessage("Parole"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Parole un apstiprinājuma parole nesakrīt"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Parole nevar būt tukša"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("Parole nesakrīt"),
        "payCash": MessageLookupByLibrary.simpleMessage("Maksāt skaidrā naudā"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash": MessageLookupByLibrary.simpleMessage("Maksāt ar Bkash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Maksāt ar Paypal"),
        "payeeName": MessageLookupByLibrary.simpleMessage("Saņēmēja vārds"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("Saņēmēja numurs"),
        "payment": MessageLookupByLibrary.simpleMessage("Maksājums"),
        "paymentAmount":
            MessageLookupByLibrary.simpleMessage("Maksājuma summa"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Maksājums pabeigts"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Maksājuma norādījumi:"),
        "paymentMethod":
            MessageLookupByLibrary.simpleMessage("Maksāšanas metode"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Maksājuma veids"),
        "pdfView": MessageLookupByLibrary.simpleMessage("PDF skats"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Personīgā informācija"),
        "phone": MessageLookupByLibrary.simpleMessage("Telefons"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Tālruņa numurs"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Telefona numurs jau tiek izmantots"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("Telefona numurs nav derīgs"),
        "phoneNumberIsRequired": MessageLookupByLibrary.simpleMessage(
            "Telefona numurs ir nepieciešams"),
        "pickAndUploadFile": MessageLookupByLibrary.simpleMessage(
            "Atlasiet un augšupielādējiet failu"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("Izvēlieties beigu datumu"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Izvēlieties sākuma datumu"),
        "plan": MessageLookupByLibrary.simpleMessage("Plāns"),
        "pleaseAddQuantity": MessageLookupByLibrary.simpleMessage(
            "Lūdzu, pievienojiet daudzumu"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Lūdzu, pārbaudiet savu interneta savienojamību"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Lūdzu, vispirms pieslēdziet printeri"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Lūdzu, savienojiet savu Bluetooth printeri"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Lūdzu, ievadiet garāku paroli"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Lūdzu, ievadiet apstiprinājuma paroli"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("Lūdzu, ievadiet paroli"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Lūdzu, ievadiet derīgu e-pastu"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Lūdzu, ievadiet vārdu"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("Lūdzu, ievadiet paroli"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Lūdzu, ievadiet savu e-pasta adresi, lai saņemtu paroles atiestatīšanas saiti."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Lūdzu, ievadiet darījuma numuru"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("Lūdzu, ievadiet summu"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Lūdzu, vispirms izvēlieties kategoriju"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("Lūdzu, izvēlieties plānu"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Lūdzu, izvēlieties uzņēmuma kategoriju"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Lūdzu, izmantojiet derīgu pirkuma kodu, lai izmantotu lietotni"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Attiecīgi darbina Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Izstrādāts ar"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Premium klientu atbalsts"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Premium plāns"),
        "previousPayAmounts": MessageLookupByLibrary.simpleMessage(
            "Iepriekšējās maksājumu summas"),
        "price": MessageLookupByLibrary.simpleMessage("Cena"),
        "print": MessageLookupByLibrary.simpleMessage("Drukāt"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Drukāšanas opcija"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Privātuma politika"),
        "product": MessageLookupByLibrary.simpleMessage("Produkts"),
        "productCode": MessageLookupByLibrary.simpleMessage("Produkta kods"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("Produkta kods ir obligāts"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Produkta kods/nosaukums"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Produkta apraksts"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Produkta detaļas"),
        "productList":
            MessageLookupByLibrary.simpleMessage("Produktu saraksts"),
        "productName":
            MessageLookupByLibrary.simpleMessage("Produkta nosaukums"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Produkta nosaukums jau pastāv šajā noliktavā"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Produkta nosaukums jau ir pievienots"),
        "productNameIsRequired": MessageLookupByLibrary.simpleMessage(
            "Produkta nosaukums ir obligāts"),
        "products": MessageLookupByLibrary.simpleMessage("Produkti"),
        "profile": MessageLookupByLibrary.simpleMessage("Profils"),
        "profileEdit":
            MessageLookupByLibrary.simpleMessage("Profila rediģēšana"),
        "profit": MessageLookupByLibrary.simpleMessage("Peļņa"),
        "promo": MessageLookupByLibrary.simpleMessage("Akcija"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Akcijas kods"),
        "purchase": MessageLookupByLibrary.simpleMessage("Iepirkums"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("Pirkuma trauksme"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Pirkums apstiprināts"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Iepirkumu detaļas"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Pirkuma rēķins"),
        "purchaseList":
            MessageLookupByLibrary.simpleMessage("Iepirkumu saraksts"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Iegādāties tagad"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Iegādāties Premium plānu"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("Iegādes cena"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("Iegādes cena ir obligāta"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("Iepirkumu pārskats"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Iepirkumu cena"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Pirkumu ziņojumi"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("Pirkuma atgriešana"),
        "purchaseReturnReport": MessageLookupByLibrary.simpleMessage(
            "Pirkuma atgriešanas pārskats"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Pirkuma pāreja"),
        "qty": MessageLookupByLibrary.simpleMessage("Daudzums"),
        "quantity": MessageLookupByLibrary.simpleMessage("Daudzums"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Nesenās transakcijas"),
        "recivedThePin": MessageLookupByLibrary.simpleMessage("Saņēmis PIN"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Atsauces numurs"),
        "register": MessageLookupByLibrary.simpleMessage("Reģistrēties"),
        "registering": MessageLookupByLibrary.simpleMessage("Reģistrēšana"),
        "remainingDue":
            MessageLookupByLibrary.simpleMessage("Atlikušais parāds"),
        "remove": MessageLookupByLibrary.simpleMessage("Noņemt"),
        "reports": MessageLookupByLibrary.simpleMessage("Pārskati"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Pieprasījums ir nosūtīts"),
        "resendCode":
            MessageLookupByLibrary.simpleMessage("Nosūtīt kodu atkārtoti"),
        "resendOtp":
            MessageLookupByLibrary.simpleMessage("Nosūtīt OTP atkārtoti: "),
        "retailer": MessageLookupByLibrary.simpleMessage("Mazumtirgotājs"),
        "retur": MessageLookupByLibrary.simpleMessage("Atgriezt"),
        "returN": MessageLookupByLibrary.simpleMessage("Atgriezt"),
        "returnAMount":
            MessageLookupByLibrary.simpleMessage("Atgrieziet summu"),
        "returnAmount":
            MessageLookupByLibrary.simpleMessage("Atgriežamā summa"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("Atgriezt daudzumu"),
        "revenue": MessageLookupByLibrary.simpleMessage("Ieņēmumi"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Aizsargājiet savu biznesa datu bez piepūles. Mūsu Pos Saas POS neierobežotais atjauninājums ietver bezmaksas datu dublēšanu, nodrošinot, ka jūsu vērtīgā informācija ir aizsargāta pret jebkādām neparedzētām situācijām. Koncentrējieties uz to, kas patiesi ir svarīgi - jūsu uzņēmuma izaugsmi."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Pārdošanas summa"),
        "saleDetails":
            MessageLookupByLibrary.simpleMessage("Pārdošanas detaļas"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Pārdošanas cena"),
        "saleReports":
            MessageLookupByLibrary.simpleMessage("Pārdošanas pārskats"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Pārdošanas ziņojumi"),
        "saleReturn":
            MessageLookupByLibrary.simpleMessage("Pārdošanas atgriešana"),
        "saleReturnReport": MessageLookupByLibrary.simpleMessage(
            "Pārdošanas atgriešanas pārskats"),
        "saleSetting":
            MessageLookupByLibrary.simpleMessage("Pārdošanas iestatījumi"),
        "sales": MessageLookupByLibrary.simpleMessage("Pārdošana"),
        "salesAndPurchaseReports": MessageLookupByLibrary.simpleMessage(
            "Pārdošanas un pirkumu pārskati"),
        "salesList":
            MessageLookupByLibrary.simpleMessage("Pārdošanas saraksts"),
        "salesReturn":
            MessageLookupByLibrary.simpleMessage("Pārdošanas atgriešana"),
        "save": MessageLookupByLibrary.simpleMessage("Saglabāt"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Saglabāt un publicēt"),
        "saveChanges":
            MessageLookupByLibrary.simpleMessage("Saglabāt izmaiņas"),
        "saving": MessageLookupByLibrary.simpleMessage("Saglabāšana"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("Skenējiet produkta QR kodu"),
        "search": MessageLookupByLibrary.simpleMessage("Meklēt"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Meklēt pēc produkta koda vai nosaukuma"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("Skatīt visus akcijas kodus"),
        "select": MessageLookupByLibrary.simpleMessage("Izvēlēties"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Izvēlieties produktu atgriešanai"),
        "selectBrand":
            MessageLookupByLibrary.simpleMessage("Izvēlieties zīmolu"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Izvēlieties kategoriju"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Izvēlieties kontaktus"),
        "selectProductCategory": MessageLookupByLibrary.simpleMessage(
            "Izvēlieties produkta kategoriju"),
        "selectShopCategory": MessageLookupByLibrary.simpleMessage(
            "Izvēlieties veikala kategoriju"),
        "selectTax":
            MessageLookupByLibrary.simpleMessage("Izvēlieties nodokli"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Izvēlieties nodokļu veidu"),
        "selectUnit":
            MessageLookupByLibrary.simpleMessage("Izvēlieties vienību"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Izvēlieties variāciju: "),
        "seller": MessageLookupByLibrary.simpleMessage("Pārdevējs"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Pārdod"),
        "send": MessageLookupByLibrary.simpleMessage("Sūtīt"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("Sūtīt e-pastu"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Nosūtīt ziņu"),
        "sendResetLink": MessageLookupByLibrary.simpleMessage(
            "Nosūtīt atiestatīšanas saiti"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Sūtīt SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Nosūtīt SMS?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Sūtīt WhatsApp ziņu"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Nosūtiet savu e-pastu"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage("Sūtot e-pastu"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Ziņas sūtīšana"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Pakalpojums/Piegāde"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Iestatiet savu profilu"),
        "setting": MessageLookupByLibrary.simpleMessage("Iestatījums"),
        "share": MessageLookupByLibrary.simpleMessage("Kopīgot"),
        "shopGST": MessageLookupByLibrary.simpleMessage("Veikala GST"),
        "signIn": MessageLookupByLibrary.simpleMessage("Pierakstīties"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("Pierakstīties ar e-pastu"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Klienta paraksts"),
        "size": MessageLookupByLibrary.simpleMessage("Izmērs"),
        "skip": MessageLookupByLibrary.simpleMessage("Izlaist"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Sociālā mārketinga"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Atvainojiet, jums nav atļauts piekļūt šai pakalpojumam"),
        "startDate": MessageLookupByLibrary.simpleMessage("Sākuma datums"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Sākt jaunu pārdošanu"),
        "startTypingToSearch":
            MessageLookupByLibrary.simpleMessage("Sāciet rakstīt, lai meklētu"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Palieciet tehnoloģiju attīstības priekšgalā bez papildu izmaksām. Mūsu Pos Saas POS neierobežotais atjauninājums nodrošina, ka jums vienmēr ir jaunākie rīki un funkcijas, kas garantē jūsu uzņēmuma modernitāti."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("Vēl neapmaksāts"),
        "stock": MessageLookupByLibrary.simpleMessage("Krājumi"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Krājums ir obligāts"),
        "stockList": MessageLookupByLibrary.simpleMessage("Krājumu saraksts"),
        "stocks": MessageLookupByLibrary.simpleMessage("Krājumi"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Nepieciešama krātuves atļauja, lai izveidotu Excel failu"),
        "subTaxList":
            MessageLookupByLibrary.simpleMessage("Apakšnodokļu saraksts"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Apakšnodokļi"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Pats kopējais"),
        "submit": MessageLookupByLibrary.simpleMessage("Iesniegt"),
        "subscribeToOurYoutube":
            MessageLookupByLibrary.simpleMessage("Parakstieties mūsu Youtube"),
        "subscription": MessageLookupByLibrary.simpleMessage("Abonements"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Veiksmīgi pabeigts"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Veiksmīgi izrakstījies"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Veiksmīgi atjaunināts"),
        "supplier": MessageLookupByLibrary.simpleMessage("Piegādātājs"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("Piegādātāja nosaukums"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT kods"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Veiciet vadītāja apliecības, nacionālās identitātes kartes vai pases fotoattēlu"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "Izņemiet identitātes karti, lai pārbaudītu savu informāciju"),
        "tap": MessageLookupByLibrary.simpleMessage("Pieskāriens"),
        "tax": MessageLookupByLibrary.simpleMessage("Nodoklis"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Nodokļu grupa"),
        "taxPercentage":
            MessageLookupByLibrary.simpleMessage("Nodokļa procents"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Nodokļa likme"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Nodokļu likmes - pārvaldiet savas nodokļu likmes"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Nodokļu pārskats"),
        "taxType": MessageLookupByLibrary.simpleMessage("Nodokļa veids"),
        "taxes": MessageLookupByLibrary.simpleMessage("Nodokļi"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Noteikumi un nosacījumi"),
        "termsOfUse":
            MessageLookupByLibrary.simpleMessage("Lietošanas noteikumi"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Noteikumi un Privātums"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Paldies par jūsu parāda maksājumu"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Paldies"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Paldies par jūsu pirkumu"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "Konts jau pastāv šim e-pastam"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Excel fails jau ir lejupielādēts"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Nosaukums saka visu. Ar Pos Saas POS neierobežotu nav ierobežojumu jūsu lietošanā. Neatkarīgi no tā, vai jūs apstrādājat dažus darījumus vai piedzīvojat klientu plūsmu, jūs varat darboties ar pārliecību, zinot, ka jūs neesat ierobežots."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "Norādītā parole ir pārāk vāja"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Pārdošana tiks dzēsta un visi dati par šo pirkumu tiks dzēsti. Vai tiešām vēlaties dzēst šo?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Pārdošana tiks dzēsta un visi dati par šo pārdošanu tiks dzēsti. Vai tiešām vēlaties dzēst šo?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Lietotājs tiks dzēsts, un visi dati tiks dzēsti no jūsu konta. Vai tiešām vēlaties dzēst šo?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Lietotājs tiks dzēsts un visi dati tiks dzēsti no jūsu konta. Vai tiešām vēlaties dzēst šo?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Trešo pušu pakalpojumi"),
        "thisCategoryCannotBeDeleted":
            MessageLookupByLibrary.simpleMessage("Šo kategoriju nevar dzēst"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Šomēnes)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Šis produkts jau ir pievienots"),
        "title": MessageLookupByLibrary.simpleMessage("Nosaukums"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Virsraksts nevar būt tukšs"),
        "to": MessageLookupByLibrary.simpleMessage("līdz"),
        "toDate": MessageLookupByLibrary.simpleMessage("Līdz datumam"),
        "today": MessageLookupByLibrary.simpleMessage("Šodien"),
        "total": MessageLookupByLibrary.simpleMessage("Kopā"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Kopējā summa"),
        "totalCollected": MessageLookupByLibrary.simpleMessage("Kopā savākts"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Kopējais parāds"),
        "totalExpense":
            MessageLookupByLibrary.simpleMessage("Kopējie izdevumi"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Kopējais zaudējums"),
        "totalPayable": MessageLookupByLibrary.simpleMessage("Kopējā summa"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Kopējā cena"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("Kopējais produktu skaits"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Kopējais peļņa"),
        "totalPurchase":
            MessageLookupByLibrary.simpleMessage("Kopējais pirkums"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Kopējā atgriezuma summa"),
        "totalReturns":
            MessageLookupByLibrary.simpleMessage("Kopējais atgriezumu skaits"),
        "totalSale":
            MessageLookupByLibrary.simpleMessage("Kopējais pārdošanas apjoms"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Kopējais krājums"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Kopējā vērtība"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Kopējais PVN"),
        "totals": MessageLookupByLibrary.simpleMessage("Kopā: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Transakcija"),
        "transactionId":
            MessageLookupByLibrary.simpleMessage("Transakcijas ID"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Mēģināt vēlreiz"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Tips"),
        "unitName": MessageLookupByLibrary.simpleMessage("Vienības nosaukums"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Vienības cena"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Vienības cena"),
        "units": MessageLookupByLibrary.simpleMessage("Vienības"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Neierobežots"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Neierobežota lietošana"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Atklājiet pilnu Pos Saas POS potenciālu ar personalizētām apmācību sesijām, ko vada mūsu ekspertu komanda. No pamatiem līdz uzlabotām tehnikām mēs nodrošinām, ka jūs esat labi pārzinoši katrā sistēmas aspektā, lai optimizētu jūsu uzņēmuma procesus."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Nepiemaksāts"),
        "update": MessageLookupByLibrary.simpleMessage("Atjaunināt"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Atjaunot kontaktu"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Atjaunināt tagad"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("Atjaunināt produktu"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Pirmkārt, atjauniniet savu plānu, jo jūsu limits ir pārsniegts"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Atjaunināt savu profilu"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Atjauniniet savu profilu, lai sazinātos ar savu ārstu ar labāku iespaidu"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Atjauniniet savu profilu, lai labāk savienotu savus klientus"),
        "updated": MessageLookupByLibrary.simpleMessage("Atjaunots"),
        "upload": MessageLookupByLibrary.simpleMessage("Augšupielādēt"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Augšupielādēt dokumentu"),
        "uploadDone":
            MessageLookupByLibrary.simpleMessage("Augšupielāde pabeigta"),
        "uploadFile":
            MessageLookupByLibrary.simpleMessage("Augšupielādēt failu"),
        "upplier": MessageLookupByLibrary.simpleMessage("Piegādātājs"),
        "usbC": MessageLookupByLibrary.simpleMessage("USB C"),
        "use": MessageLookupByLibrary.simpleMessage("Izmanto"),
        "useMobiPos":
            MessageLookupByLibrary.simpleMessage("Izmantojiet POS SaaS"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Sistēmas izmantošana"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Lietotājs ir dzēsts"),
        "userRole": MessageLookupByLibrary.simpleMessage("Lietotāja loma"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("Lietotāja lomu detaļas"),
        "userTitle":
            MessageLookupByLibrary.simpleMessage("Lietotāja nosaukums"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Lietotāja nosaukumam nedrīkst būt tukša vērtība"),
        "value": MessageLookupByLibrary.simpleMessage("Vērtība"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("PVN neattiecas"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("Pārbaudīt OTP"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Pārbaudīt tālruņa numuru"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Skatīt visu"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("Skatīt detaļas"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Iegādātājs, kas ienācis"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Noliktava"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Noliktava jau eksistē"),
        "warehouseList":
            MessageLookupByLibrary.simpleMessage("Noliktavu saraksts"),
        "warehouseName":
            MessageLookupByLibrary.simpleMessage("Noliktavas nosaukums"),
        "warranty": MessageLookupByLibrary.simpleMessage("Garantija"),
        "weHaveSendAnEmailwithInstructions":
            MessageLookupByLibrary.simpleMessage(
                "Mēs esam nosūtījuši e-pastu ar norādījumiem par paroli uz:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Mēs varam izmantot trešo pušu pakalpojumus, lai atbalstītu mūsu lietotnes funkcionalitāti, piemēram, analītikas pakalpojumu sniedzējus un maksājumu apstrādātājus. Šie trešo pušu pakalpojumi var vākt informāciju par jums, kad izmantojat mūsu lietotni. Lūdzu, ņemiet vērā, ka mēs neesam atbildīgi par šo trešo pušu pakalpojumu privātuma praksi."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Mēs veicam nozares standartiem atbilstošus pasākumus, lai aizsargātu jūsu personas informāciju, tostarp šifrēšanu un drošu uzglabāšanu. Mēs arī ierobežojam piekļuvi jūsu informācijai tikai autorizētajam personālam."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Mēs saprotam nevainojamas darbības nozīmīgumu. Tāpēc mūsu diennakts atbalsts ir pieejams, lai palīdzētu jums, vai tas būtu ātrs jautājums vai visaptveroša problēma. Sazinieties ar mums jebkurā laikā, jebkur, zvanot vai izmantojot WhatsApp, lai piedzīvotu nepārspējamu klientu apkalpošanu."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Mēs izmantojam jūsu personas informāciju, lai nodrošinātu jums labāko iespējamo pieredzi mūsu lietotnē, tostarp personalizētu saturu, saistību ar ekspertiem un mūsu lietotnes funkcionalitātes uzlabošanu. Mēs varam arī izmantot jūsu informāciju, lai sazinātos ar jums par atjauninājumiem, akcijām vai citu informāciju, kas saistīta ar mūsu lietotni."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Mēs pārskatīsim maksājumu un apstiprināsim to 1-2 stundu laikā"),
        "weekly": MessageLookupByLibrary.simpleMessage("Nedēļā"),
        "weight": MessageLookupByLibrary.simpleMessage("Svars"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Kas jauns"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Vairumtirgotājs"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Vairumtirdzniecības cena"),
        "wholesalePrice":
            MessageLookupByLibrary.simpleMessage("Vairumtirdzniecības cena"),
        "wholesaler": MessageLookupByLibrary.simpleMessage(
            "Vairumtirdzniecības tirgotājs"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Tiks pievienots drīzumā"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Beigsies"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Rakstiet savu ziņu šeit"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("Nepareizs OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Nepareiza parole, kas norādīta šim lietotājam."),
        "yearly": MessageLookupByLibrary.simpleMessage("Gada"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Jā, dzēst uz visiem laikiem"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("Jūs neesat derīgs lietotājs"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Jūs izmantojat"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Jūs nevarat samaksāt vairāk par parādu"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Jums ir saņemts e-pasts"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Jūs veiksmīgi pieslēdzāties savam kontam. Palieciet kopā ar Pos Saas."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("Jums ir jādod atļauja"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Jums jāveic atkārtota pieslēgšanās jūsu kontam."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Jums jāveic identitātes verifikācija pirms SMS iegādes"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Jūsu ziņas atlikums"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Jūsu pakete"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Jūsu pakete beigsies pēc 5 dienām")
      };
}
