// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a am locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'am';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("ቀጥሉ"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("GST ቁጥር"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("ዋጋ የእድል"),
        "MRPIsRequired": MessageLookupByLibrary.simpleMessage("MRP ያስፈልጋል"),
        "OK": MessageLookupByLibrary.simpleMessage("እሺ"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("ፔይፐል"),
        "PhNo": MessageLookupByLibrary.simpleMessage("ስልክ ቁጥር"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("የSWIFT ኮድ"),
        "Snacks": MessageLookupByLibrary.simpleMessage("ማቅለሻዎች"),
        "TAX": MessageLookupByLibrary.simpleMessage("ታክስ"),
        "Uploading": MessageLookupByLibrary.simpleMessage("በማስገባት ላይ"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("የተጠቃሚ ርዕስ"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "የእርስዎ ጥቅም ዛሬ ይወጣል\n\nእባክዎ እንደገና ግዢ ይደርሱ"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) የስርዓቱ አገልግሎት የሚያነሳበት ዋነኛ የማዕከል ሽያጭ ግብአቶችን እና ተመንግስት አላባበት ነው።"),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) የስርዓቱ ይጠበቃሉ ወይም ይጠበቃሉ ሊያንሱ ለመነሳት ቢያንስ ይጠበቃሉ። እንዲሁም ትንሽ እና ወይም በታውቀው የመዝግብ ወቀት ይቀርበን።"),
        "aboutApp": MessageLookupByLibrary.simpleMessage("ስለ አፕሊኬሽን"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("ስለ እኛ"),
        "acceptanceOfTerms": MessageLookupByLibrary.simpleMessage("የውል ተቀባይነት"),
        "accountName": MessageLookupByLibrary.simpleMessage("የባንክ አካውንት ስም"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("የባንክ አካውንት ቁጥር"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("የአካውንት መዝግብ"),
        "acton": MessageLookupByLibrary.simpleMessage("ድርጅት"),
        "add": MessageLookupByLibrary.simpleMessage("ያክሉ"),
        "addBrand": MessageLookupByLibrary.simpleMessage("የእንደ ባለቤት ምርት ይጨምሩ"),
        "addCategory": MessageLookupByLibrary.simpleMessage("ክፍል ይጨምር"),
        "addContact": MessageLookupByLibrary.simpleMessage("የተገናኝ መጨረሻ"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("ደንበኛ ይጨምሩ"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("ወደዚያ ይጨምሩ"),
        "addDescriptioN": MessageLookupByLibrary.simpleMessage("አቀራረብ ያክሉ"),
        "addDescription": MessageLookupByLibrary.simpleMessage("ማስታወቂያ ይጨምሩ"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("ቅናሽ ያክሉ"),
        "addDocumentId": MessageLookupByLibrary.simpleMessage("የመረጃ መለያ ይጨምሩ"),
        "addDucument": MessageLookupByLibrary.simpleMessage("መረጃ ይጨምሩ"),
        "addExpense": MessageLookupByLibrary.simpleMessage("ወጪ ይጨምሩ"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("ወጪ የምድብ ይጨምሩ"),
        "addItems": MessageLookupByLibrary.simpleMessage("እቃዎች ይጨምር"),
        "addNew": MessageLookupByLibrary.simpleMessage("አዲስ ያክሉ"),
        "addNewAddress": MessageLookupByLibrary.simpleMessage("አዲስ አድራሻ ይጨምሩ"),
        "addNewProduct": MessageLookupByLibrary.simpleMessage("አዲስ ምርት ይጨምር"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("አዲስ ግብር አክል"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "አዲስ ግብር አክል ወይም በአብራሪ ግብር አክል"),
        "addNote": MessageLookupByLibrary.simpleMessage("ማስታወቂያ ይጨምሩ"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("የምርት ይጨምሩ በመጀመሪያ"),
        "addPromoCode": MessageLookupByLibrary.simpleMessage("የታወቀ ኮድ ያክሉ"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("ግዢ ይጨምር"),
        "addSales": MessageLookupByLibrary.simpleMessage("የሽያጭ ይጨምሩ"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("በሚስጥር ተጨማሪ ለተገናኝ"),
        "addUnit": MessageLookupByLibrary.simpleMessage("አቀማመጥ ይጨምር"),
        "addUserRole": MessageLookupByLibrary.simpleMessage("የተጠቃሚ ድርጅት ጨምር"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("በተሳካ ሁኔታ ተጨምሯል"),
        "addedToCart": MessageLookupByLibrary.simpleMessage("ወታደድ ተጨምሮ"),
        "address": MessageLookupByLibrary.simpleMessage("አድራሻ"),
        "admin": MessageLookupByLibrary.simpleMessage("አስተዳደር"),
        "all": MessageLookupByLibrary.simpleMessage("አሉ"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("የንግድ መፍትሔዎች"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("ቀይ ተወዳጅ"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("ቀድሞ አለ"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("የተመዘገበ አካውንት አለዎት"),
        "amount": MessageLookupByLibrary.simpleMessage("መጠን"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage("ኢሜይል ተላክቷል\\nይመልከቱ በዚያ"),
        "androidIOSAppSupport":
            MessageLookupByLibrary.simpleMessage("የአንድሮይድ እና iOS አፕ ድጋፍ"),
        "applicableTax": MessageLookupByLibrary.simpleMessage("የታክስ ስለሚሰጥ"),
        "apply": MessageLookupByLibrary.simpleMessage("ይግቡ"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "ይህ የመለኪያ ማስወገድ እንደተባለ ይቅርታ ይኑሩ"),
        "areYouSureToDeleteThisSale":
            MessageLookupByLibrary.simpleMessage("ይህን ሽያጭ ማስወገድ ትችላለህ?"),
        "areYouSureToDeleteThisUser":
            MessageLookupByLibrary.simpleMessage("ይህን ተጠቃሚ ማጥፋት ይደረግዎት ነው?"),
        "areYouSureWantToDeleteThisTax":
            MessageLookupByLibrary.simpleMessage("ይህ ግብር ለማስወገድ ይወዳድሩ?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage("ይህ የግብር ዡርዝ ለማስወገድ ይወዳድሩ?"),
        "areYouWantToDeleteThisWarehouse":
            MessageLookupByLibrary.simpleMessage("ይህ የእቃ መዝገብ ለማስወገድ ይወዳድሩ?"),
        "areYourSureDeleteThisUser":
            MessageLookupByLibrary.simpleMessage("ይህ ተጠቃሚ እንደተለውጥ እርግጥ ነን?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("የተፈቃደ ፊርማ"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) ይህ ላይ ወንድማ ወይም ታማኝ ይኖርበታል ይህ ወይም ይቀርበን። እንዲሁም ይህ ወይም አይደል ትህባይን ወይም ላይ ይቀርበን።"),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) እርስዎ ቢያንስ 18 ዓመት ወይም በዚያ ዙርያ ተመን የአካል ዕድሜ ማይታወቀው ወደ ስርዓቱ ማዋል ይጠበቃሉ።"),
        "backSide": MessageLookupByLibrary.simpleMessage("የኋላ ይዕዘብ"),
        "backToHome": MessageLookupByLibrary.simpleMessage("ወደ ዋና ገጽ ይመለሱ"),
        "balance": MessageLookupByLibrary.simpleMessage("የቀሪ ገንዘብ"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("ባንጋልዳሽ"),
        "bank": MessageLookupByLibrary.simpleMessage("ባንክ"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("የባንክ መዋቅር ገንዘብ"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("የባንክ አካውንት ገንዘብ"),
        "bankInformation": MessageLookupByLibrary.simpleMessage("የባንክ መረጃ"),
        "bankName": MessageLookupByLibrary.simpleMessage("የባንክ ስም"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("የባንክ ቅድመ ክፍያ"),
        "barcodeFound": MessageLookupByLibrary.simpleMessage("ባርኮድ ተገኝቷል"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("ወረቀት/መዋጮ"),
        "billTo": MessageLookupByLibrary.simpleMessage("ወንጀል ይደርስ"),
        "branchName": MessageLookupByLibrary.simpleMessage("የቅርንጫፍ ስም"),
        "brand": MessageLookupByLibrary.simpleMessage("የባለስልጣን"),
        "brandName": MessageLookupByLibrary.simpleMessage("የባለቤት ስም"),
        "bulkUpload":
            MessageLookupByLibrary.simpleMessage("ወቅታዊ እንደ እቃ እና ወዘተ"),
        "businessCategory": MessageLookupByLibrary.simpleMessage("የድርጅት ምድብ"),
        "buy": MessageLookupByLibrary.simpleMessage("ግድይ"),
        "buyPremiumPlan": MessageLookupByLibrary.simpleMessage("ፕሪምየም እቅድ ይግዙ"),
        "buySms": MessageLookupByLibrary.simpleMessage("SMS ይግዙ"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "በ[የእርስዎ የኩባንያ ስም] (\"ኩባንያ\") የቀረበውን የማዕከል ሽያጭ (POS) ስርዓት (\"ስርዓት\") በመግባት ወይም በመጠቀም ይህን የውል ይተገኝ እንደምትፈልጉ በእቃ ይሆን ነው። ከዚህ የውል በሚወድም ነገር አንበብ እንኖራችሁ፣ እነሆ፣ ይህን ስርዓት አትጠቀሙ።"),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) እርስዎ ወይም የእንደዚያ እንዲሁ ወቅታዊ ማስታወቂያ የእይታ ይኖረን።"),
        "cacel": MessageLookupByLibrary.simpleMessage("ይሰርዝ"),
        "call": MessageLookupByLibrary.simpleMessage("ይደውሉ"),
        "callForEmergencySupport":
            MessageLookupByLibrary.simpleMessage("ለአደገ ድጋፍ ይደውሉ"),
        "camera": MessageLookupByLibrary.simpleMessage("ካሜራ"),
        "cancel": MessageLookupByLibrary.simpleMessage("ይወግዱ"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("አጠቃላይ ምርቶችን ይቅርታ"),
        "capacity": MessageLookupByLibrary.simpleMessage("ትንበያ"),
        "card": MessageLookupByLibrary.simpleMessage("ካርድ"),
        "cash": MessageLookupByLibrary.simpleMessage("ገንዘብ"),
        "cashFree": MessageLookupByLibrary.simpleMessage("ገንዘብ ነፃ"),
        "categories": MessageLookupByLibrary.simpleMessage("ክፍልዎች"),
        "category": MessageLookupByLibrary.simpleMessage("ክፍል"),
        "categoryName": MessageLookupByLibrary.simpleMessage("የክፍል ስም"),
        "categoryNameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("የክፍል ስም ተወስኗል"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("የምድብ ስም"),
        "change": MessageLookupByLibrary.simpleMessage("ለውጥ?"),
        "changePassword": MessageLookupByLibrary.simpleMessage("የይለፍ ቃል ይለውጡ"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("ኢሜይል ይፈትሹ"),
        "choseACustomer": MessageLookupByLibrary.simpleMessage("የደንበኛ ምርጫ"),
        "choseASupplier": MessageLookupByLibrary.simpleMessage("የእቃ ይምረጡ"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("የተለያዩ ምርጫዎችን ይምረጡ"),
        "clarence": MessageLookupByLibrary.simpleMessage("ይማርለዋል"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("ወደ መገናኛ ለመገናኘት ይጫኑ"),
        "close": MessageLookupByLibrary.simpleMessage("ዝግባ"),
        "color": MessageLookupByLibrary.simpleMessage("ቀለም"),
        "combinationOfMultipleTaxes":
            MessageLookupByLibrary.simpleMessage("(የብዙ ግብሮች አቀራረብ)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("ወዲያው እንደሚመጣ"),
        "companyAddress": MessageLookupByLibrary.simpleMessage("የኩባንያ አድራሻ"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("የኩባንያ እና የዕቃ ስም"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("የኩባንያ እና የንግድ ስም"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("ግብይትን ይጨርሱ"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("የይለፍ ቃል ይረጋግጡ"),
        "confirmReturn": MessageLookupByLibrary.simpleMessage("የመመለስ ማረጋገጫ"),
        "congratulations": MessageLookupByLibrary.simpleMessage("እንኳን ወደ ወጣ"),
        "contactUs": MessageLookupByLibrary.simpleMessage("እባኮትን ያነጋግሩን"),
        "continu": MessageLookupByLibrary.simpleMessage("መቀጣጠር"),
        "country": MessageLookupByLibrary.simpleMessage("አገር"),
        "create": MessageLookupByLibrary.simpleMessage("ይፍጠሩ"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("ነፃ አካውንት ይፍጠሩ"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("የተፈጥሮ እና የተቀመጠ"),
        "currency": MessageLookupByLibrary.simpleMessage("ገንዘብ"),
        "currentStock": MessageLookupByLibrary.simpleMessage("ወቅታዊ የእቃ ገንቢ"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("የተለያዩ እንቅስቃሴ የክትትል ባለቤት"),
        "customer": MessageLookupByLibrary.simpleMessage("ደንበኛ"),
        "customerDetails": MessageLookupByLibrary.simpleMessage("የደንበኛ ዝርዝር"),
        "customerGST": MessageLookupByLibrary.simpleMessage("የደንበኛ ግስት"),
        "customerName": MessageLookupByLibrary.simpleMessage("የደንበኛ ስም"),
        "dailyTransaciton": MessageLookupByLibrary.simpleMessage("የዕለት ግብአቶች"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("ዳሽቦርድ አጠቃላይ"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("መረጃ በሚሳተፍ ተያይዞ ተሳክቷል"),
        "date": MessageLookupByLibrary.simpleMessage("ቀን"),
        "day": MessageLookupByLibrary.simpleMessage("ቀን"),
        "dealer": MessageLookupByLibrary.simpleMessage("የዕቃ ወረዳ"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("የሻጭ ዋጋ"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("መደበኛ VAT መቶኛ"),
        "delete": MessageLookupByLibrary.simpleMessage("ማጥፋት"),
        "deleting": MessageLookupByLibrary.simpleMessage("ማስወገድ"),
        "deliveryAddress": MessageLookupByLibrary.simpleMessage("የደረሰኝ አድራሻ"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("የመደብር አድራሻዎች"),
        "deliveryCharge": MessageLookupByLibrary.simpleMessage("መዋጮ ጭነት"),
        "describtion": MessageLookupByLibrary.simpleMessage("መግለጫ"),
        "description": MessageLookupByLibrary.simpleMessage("መግለጫ"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("መግለጫ ባዶ ማድረግ አልቻልኩም"),
        "details": MessageLookupByLibrary.simpleMessage("ዝርዝር"),
        "discount": MessageLookupByLibrary.simpleMessage("ቅናሽ"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("አታነሱ"),
        "done": MessageLookupByLibrary.simpleMessage("ተጠናቀቀ"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("ኤክሴል ፎርማት ይውሰዱ"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "በዳውንሎድ ፎልደር ውስጥ በተቀባ ማስመዝገብ ውስጥ ተወርዷል"),
        "due": MessageLookupByLibrary.simpleMessage("ወርቅ"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("ወርቅ መጠን: "),
        "dueCollection": MessageLookupByLibrary.simpleMessage("ወርቅ ማከማቻ"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("የዕቅፍ ስብስብ ሪፖርት"),
        "dueList": MessageLookupByLibrary.simpleMessage("የወርቅ ዝርዝር"),
        "dueReports": MessageLookupByLibrary.simpleMessage("የታበደ ዘገባ"),
        "duration": MessageLookupByLibrary.simpleMessage("የጊዜ አቀማመጥ"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("ወቅታዊ እስከ"),
        "easyToUseMobilePos":
            MessageLookupByLibrary.simpleMessage("ቀላል ለማጠቀም የሞባይል POS"),
        "edit": MessageLookupByLibrary.simpleMessage("ማሻሻያ"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("የግዢ ክፍያ እንደገና ይከታተሉ"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("የሽያጭ ክፍያ እንደገና ይከታተሉ"),
        "editSocailMedia": MessageLookupByLibrary.simpleMessage("እንቅስቃሴ ማሻሻያ"),
        "editSuccessfully": MessageLookupByLibrary.simpleMessage("በስኬት ይለውጡ"),
        "editTax": MessageLookupByLibrary.simpleMessage("ግብር ይነሳ"),
        "editTaxGroup": MessageLookupByLibrary.simpleMessage("የግብር ዡርዝ ይለውጡ"),
        "editWarehouse": MessageLookupByLibrary.simpleMessage("የእቃ መዝገብ ይለውጡ"),
        "email": MessageLookupByLibrary.simpleMessage("ኢሜይል"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("የኢሜይል አድራሻ"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("ኢሜይል አይነሱም"),
        "emailSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage("ኢሜይል ተላክቷል! እባኮት በይለፍ ይመልከቱ"),
        "endDate": MessageLookupByLibrary.simpleMessage("የአጠቃቀም ቀን"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("ትክክለኛ የገንዘብ መጠን ይምረጡ"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("እባኮት ታዋቂ ቅናሽ ይክፈቱ"),
        "enterAValidPhoneNumber":
            MessageLookupByLibrary.simpleMessage("ትክክለኛ የስልክ ቁጥር ይገቡ"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("ትክክለኛ ዋጋ ይገቡ"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("ትክክለኛ ብዛት ይገቡ"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("አድራሻን ይግቡ"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("መጠን ይግቡ።"),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("የባለስልጣን ስም አስገባ"),
        "enterCapacity": MessageLookupByLibrary.simpleMessage("ትንበያ አስገባ"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("የክፍል ስም አስገባ"),
        "enterColor": MessageLookupByLibrary.simpleMessage("ቀለም አስገባ"),
        "enterCustomerGstNumber":
            MessageLookupByLibrary.simpleMessage("የደንበኛ  GST ቁጥር ይገቡ"),
        "enterDealerPrice": MessageLookupByLibrary.simpleMessage("የሻጭ ዋጋ አስገባ"),
        "enterDescription": MessageLookupByLibrary.simpleMessage("መግለጫ ይክፈቱ"),
        "enterDiscount": MessageLookupByLibrary.simpleMessage("ቅናሽ አስገባ."),
        "enterExpenseDate": MessageLookupByLibrary.simpleMessage("የወጪ ቀን ይገቡ"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("አጠቃላይ አድራሻን ይግቡ"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("የክፍያ ቁጥር ይንቀባ"),
        "enterLowStockAlertQuantity":
            MessageLookupByLibrary.simpleMessage("ዝቅተኛ የእቃ ማስጠንቀቂያ ብዛት ይክፈቱ"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("የምርት አምራች አስገባ"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("የመልእክት ይዝርዝር"),
        "enterMrpOrRetailerPirce":
            MessageLookupByLibrary.simpleMessage("ዋጋ የእድል/የመረጃ ዋጋ አስገባ"),
        "enterName": MessageLookupByLibrary.simpleMessage("ስም ይገቡ"),
        "enterNote": MessageLookupByLibrary.simpleMessage("ማስታወቂያ ይገቡ"),
        "enterPartyName": MessageLookupByLibrary.simpleMessage("የወገን ስም ይገቡ"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("የስልክ ቁጥርን ይግቡ"),
        "enterProductCodeOrScan":
            MessageLookupByLibrary.simpleMessage("የምርት ኮድ አስገባ ወይም ይታይ"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("የምርት ስም አስገባ"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("የግዢ ዋጋ አስገባ."),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("የግምገማ ቁጥር ይገቡ"),
        "enterSize": MessageLookupByLibrary.simpleMessage("መጠን አስገባ"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("ማእከል አስገባ."),
        "enterTaxRate": MessageLookupByLibrary.simpleMessage("ግብር ደረጃ ይገቡ"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("የሂደት መለያ አስገባ"),
        "enterType": MessageLookupByLibrary.simpleMessage("ዓይነት አስገባ"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("የተጠቃሚ ርዕስ ይውስጡ"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("ትክክለኛ የገንዘብ መጠን ይምረጡ"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("የእቃ መዝገብ ስም ይግቡ"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("ውጤት አስገባ"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("የገበያ ዋጋ አስገባ"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("እባክዎን ዝርዝር ይግቡ"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("ኢሜይል አድራሻዎን ይገባ"),
        "enterYourFeedBackTitle":
            MessageLookupByLibrary.simpleMessage("የእርግጠኝ መልእክትዎን ይግቡ"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("የእርስዎን GST ቁጥር ይገቡ"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("እባክዎን የሞባይል ቁጥርዎን ይግቡ"),
        "enterYourName": MessageLookupByLibrary.simpleMessage("ስምዎን ይገቡ"),
        "enterYourNumber": MessageLookupByLibrary.simpleMessage("የስልክ ቁጥር ይገባ"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("የእርስዎን የይለፍ ቃል ይውስጡ"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("የስልክ ቁጥርዎን ይግቡ"),
        "enterYourTransactionId":
            MessageLookupByLibrary.simpleMessage("እባክዎን የግብይት መለያዎን ይግቡ"),
        "error": MessageLookupByLibrary.simpleMessage("ስህተት"),
        "excTax": MessageLookupByLibrary.simpleMessage("ከታክስ ይለያ"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("ኤክሴል ማስመዝገብ"),
        "exclusive": MessageLookupByLibrary.simpleMessage("የተለየ"),
        "expense": MessageLookupByLibrary.simpleMessage("ወጪ"),
        "expenseCategory": MessageLookupByLibrary.simpleMessage("የወጪ ምድብ"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("የወጪ ቀን"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("የወጪ ዓላማ"),
        "expenseReport": MessageLookupByLibrary.simpleMessage("የወጪ ሪፖርት"),
        "expireDate": MessageLookupByLibrary.simpleMessage("የማብቂያ ቀን"),
        "expired": MessageLookupByLibrary.simpleMessage("የተሰርየ"),
        "expiring": MessageLookupByLibrary.simpleMessage("እየተቀጠረ"),
        "facebok": MessageLookupByLibrary.simpleMessage("ፌስቡክ"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("በስህተት ውስጥ አይታወቅም"),
        "fashion": MessageLookupByLibrary.simpleMessage("ፋሽን"),
        "featureAreTheImportant":
            MessageLookupByLibrary.simpleMessage("አርክ ወይም ተጨማሪ ነገር ባህርያ ይኖራል"),
        "feedBack": MessageLookupByLibrary.simpleMessage("እንደገና እንድ ተወዳድር"),
        "firstName": MessageLookupByLibrary.simpleMessage("የመጀመሪያ ስም"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("በፌስቡክ ይከተሉን"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("በትዊተር ይከተሉን"),
        "fontSide": MessageLookupByLibrary.simpleMessage("የፊደል ይዕዘብ"),
        "forUnlimitedUses": MessageLookupByLibrary.simpleMessage("ለወይዘት ገላጭ"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("የይለፍ ቃል አለመታየት"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("የይለፍ ቃል አለመታየት?"),
        "formDate": MessageLookupByLibrary.simpleMessage("ከቀን"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("ነፃ ዳታ ባክን ይደረግ"),
        "freeLifeTimeUpdate":
            MessageLookupByLibrary.simpleMessage("ነፃ የሕይወት እንደገና እንድንድር"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("ነጻ ፓኬጅ"),
        "freePlan": MessageLookupByLibrary.simpleMessage("ነጻ እቅድ"),
        "from": MessageLookupByLibrary.simpleMessage("(ከ"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("በሙሉ ተከፍሏል"),
        "gallary": MessageLookupByLibrary.simpleMessage("ጋለሪ"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("PDF እንደሚፈጥር"),
        "getOtp": MessageLookupByLibrary.simpleMessage("OTP ይቀበሉ"),
        "govermentId": MessageLookupByLibrary.simpleMessage("የመንግስት መለያ"),
        "guest": MessageLookupByLibrary.simpleMessage("እንግዳ"),
        "havenotAnAccounts": MessageLookupByLibrary.simpleMessage("መለያ የለዎትም?"),
        "history": MessageLookupByLibrary.simpleMessage("ታሪክ"),
        "home": MessageLookupByLibrary.simpleMessage("ቤት"),
        "howWeProtectYourInformation":
            MessageLookupByLibrary.simpleMessage("የእንደምን ዝርዝር የእንደምን"),
        "howWeUseYourInformation":
            MessageLookupByLibrary.simpleMessage("የእንደምን አካውንትዎን እንደ ተጠቃሚ"),
        "identityVerify": MessageLookupByLibrary.simpleMessage("መለያ ማረጋገጫ"),
        "image": MessageLookupByLibrary.simpleMessage("ይህ"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("ውስጥ አይወገድም"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("ውስጥ አይታወቅም"),
        "inWord": MessageLookupByLibrary.simpleMessage("በቃል"),
        "incTax": MessageLookupByLibrary.simpleMessage("ከታክስ ጋር"),
        "inclusive": MessageLookupByLibrary.simpleMessage("አካባቢ"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("እቃ ያገኙ"),
        "inistrument": MessageLookupByLibrary.simpleMessage("መሳሪያ"),
        "instragram": MessageLookupByLibrary.simpleMessage("እንስተራግም"),
        "invNo": MessageLookupByLibrary.simpleMessage("በይበይ"),
        "invoice": MessageLookupByLibrary.simpleMessage("የገንዘብ ይዘት"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("የክፍያ ቁጥር"),
        "invoiceSetting": MessageLookupByLibrary.simpleMessage("የኢንቮይስ ማስተካከያ"),
        "invoiceViewer": MessageLookupByLibrary.simpleMessage("የገንዘብ ይዘት እይታ"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("እቃ ተጨምሯል"),
        "kg": MessageLookupByLibrary.simpleMessage("ኪ.ግ"),
        "kycVerification": MessageLookupByLibrary.simpleMessage("KYC ማረጋገጫ"),
        "language": MessageLookupByLibrary.simpleMessage("ቋንቋ"),
        "lastName": MessageLookupByLibrary.simpleMessage("የመጨረሻ ስም"),
        "ledger": MessageLookupByLibrary.simpleMessage("ላይይ መዝገብ"),
        "lifeTimePurchase": MessageLookupByLibrary.simpleMessage("የንደበተር ግዢ"),
        "link": MessageLookupByLibrary.simpleMessage("አድራሻ"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("ሊንክድኢን"),
        "liveChatSupport": MessageLookupByLibrary.simpleMessage("ቀረጻ ድጋፍ"),
        "loading": MessageLookupByLibrary.simpleMessage("በሂደት ላይ"),
        "logIn": MessageLookupByLibrary.simpleMessage("ግባ"),
        "logOUt": MessageLookupByLibrary.simpleMessage("ወደ ውጭ ይውጡ"),
        "logOut": MessageLookupByLibrary.simpleMessage("ውስጥ ወደ ውስጥ ይገቡ"),
        "login": MessageLookupByLibrary.simpleMessage("ይግቡ"),
        "logo": MessageLookupByLibrary.simpleMessage("አርማ"),
        "loss": MessageLookupByLibrary.simpleMessage("እንቅስቃሴ"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("እንቅስቃሴ/ትርፍ"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("እንቅስቃሴ/ትርፍ ዝርዝር"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("ጉዳት/ትርፍ ሪፖርት"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("ጉዳት/ትርፍ ሪፖርቶች"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("ዝቅተኛ የእቃ ማስጠንቀቂያ"),
        "maan": MessageLookupByLibrary.simpleMessage("ማን"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "ይህን ለማስታወቂያ በአንዳንድ ወይም ወደ ቀጥታ ይለምን።"),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("ከእናንተ ጋር የወጪዎን እና ወጪዎን ይቀበሉ"),
        "manufactureDate": MessageLookupByLibrary.simpleMessage("የምርት ቀን"),
        "margin": MessageLookupByLibrary.simpleMessage("ወገን"),
        "masterCard": MessageLookupByLibrary.simpleMessage("ማስተር ካርድ"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("የምርት አምራች"),
        "message": MessageLookupByLibrary.simpleMessage("መልእክት"),
        "messageHistory": MessageLookupByLibrary.simpleMessage("የመልእክት ታሪክ"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "POS SaaS አፕ ይቀርባል፣ ወደገና ለመጠቀም ቀላል ነው፣ እውነት እንደዚህ ምርጥ እንደሆነ ይገናኝ"),
        "mobiPosIsaCompleteBusinesSolution":
            MessageLookupByLibrary.simpleMessage(
                "POS SaaS አስቀድሞ ይሰራል፣ ውድድር ፣ ገንዘብ ወዘይለ ሳይኖራቸው ይኖሩ"),
        "mobile": MessageLookupByLibrary.simpleMessage("ሞባይል"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("የሞባይል ክፍያ"),
        "monthly": MessageLookupByLibrary.simpleMessage("ወርሃዊ"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("በተጨማሪ መረጃ"),
        "name": MessageLookupByLibrary.simpleMessage("የእርስዎን ስም ይግቡ።"),
        "nameAlreadyExists": MessageLookupByLibrary.simpleMessage("ስም ተወስኗል"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("ስም መስክ አልቻልኩም"),
        "next": MessageLookupByLibrary.simpleMessage("ቀጣይ"),
        "noConnection": MessageLookupByLibrary.simpleMessage("የባይ አይታወቅ"),
        "noData": MessageLookupByLibrary.simpleMessage("የለም"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("የሚገኝ ውሂብ ይቀርባል"),
        "noDataFound": MessageLookupByLibrary.simpleMessage("ምንም ውሂብ አልተገኘም"),
        "noHistoryFound": MessageLookupByLibrary.simpleMessage("ታሪክ አልተገኘም!"),
        "noProductFound": MessageLookupByLibrary.simpleMessage("የምርት የማይታወቅ"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("አንዱም ንዑስ ግብር አልተመረጠም"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("ግብይት አልተገኘም!"),
        "noUserFoundForThatEmail":
            MessageLookupByLibrary.simpleMessage("የዚያ ኢሜይል የተጠቃሚ አልተገኘም።"),
        "noUserRoleFound":
            MessageLookupByLibrary.simpleMessage("የተጠቃሚ ድርጅት አልተገኘም"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("አሁን አይቀጥሉም ተጠቃሚ"),
        "notProvided": MessageLookupByLibrary.simpleMessage("አልተሰጠም"),
        "note": MessageLookupByLibrary.simpleMessage("ማስታወቂያ"),
        "notes": MessageLookupByLibrary.simpleMessage("ማስታወሻ"),
        "notification": MessageLookupByLibrary.simpleMessage("ማሳወቂያ"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP ወደ"),
        "office": MessageLookupByLibrary.simpleMessage("ቢሮ"),
        "ok": MessageLookupByLibrary.simpleMessage("እሺ"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "ከአንዱ የዳር ወይም ወይም ይቅርታ ስለሚደርስ በአቅጣጫ ውስጥ ይቀይሩ።"),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "ይህ የሚይል እንዲሁም ወይም ይቀይሩ ይኖርበታል ይወዳሉ።"),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "የአንዱ አብዛኛው ወይም ከነአንዱ ወይም ይቀይሩ።"),
        "openingBalance": MessageLookupByLibrary.simpleMessage("የመነሻ ባለሞያ"),
        "order": MessageLookupByLibrary.simpleMessage("ትእዛዝ"),
        "other": MessageLookupByLibrary.simpleMessage("ሌላ"),
        "otp": MessageLookupByLibrary.simpleMessage("ይዘት"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("በእቃ ውስጥ የለም"),
        "pacakge": MessageLookupByLibrary.simpleMessage("ፓኬጅ"),
        "packageFeatures": MessageLookupByLibrary.simpleMessage("የፓኬጅ ባህርያዎች"),
        "paid": MessageLookupByLibrary.simpleMessage("የተከፈለ"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("የተከፈለ መጠን"),
        "parties": MessageLookupByLibrary.simpleMessage("ወገኖች"),
        "partiesList": MessageLookupByLibrary.simpleMessage("የወገኖች ዝርዝር"),
        "partyGST": MessageLookupByLibrary.simpleMessage("የፓርቲ ግስት"),
        "partyName": MessageLookupByLibrary.simpleMessage("የወገን ስም"),
        "password": MessageLookupByLibrary.simpleMessage("የይለፍ ቃል"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "የይለፍ ቃል እና የማረጋገጫ ይለፍ ቃል አይለወጡም"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("የይለፍ ቃል አይነሱም"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("የይለፍ ቃል አይደለም"),
        "payCash": MessageLookupByLibrary.simpleMessage("ገንዘብ አክብሮት"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash": MessageLookupByLibrary.simpleMessage("በቢካሽ ይክፈሉ"),
        "payWithPaypal": MessageLookupByLibrary.simpleMessage("በPaypal ክፍያ"),
        "payeeName": MessageLookupByLibrary.simpleMessage("የክፍያ የተቀበይት ስም"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("የክፍያ የተቀበይት ቁጥር"),
        "payment": MessageLookupByLibrary.simpleMessage("ክፍያ"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("የክፍያ መጠን"),
        "paymentComplete": MessageLookupByLibrary.simpleMessage("ክፍያ የተወሰነ"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("የክፍያ መመሪያ:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("የክፍያ ዘዴ"),
        "paymentType": MessageLookupByLibrary.simpleMessage("የክፍያ አይነት"),
        "pdfView": MessageLookupByLibrary.simpleMessage("PDF እይታ"),
        "personalInformation": MessageLookupByLibrary.simpleMessage("የግል መረጃ"),
        "phone": MessageLookupByLibrary.simpleMessage("ስልክ"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("የስልክ ቁጥር"),
        "phoneNumberAlreadyUsed":
            MessageLookupByLibrary.simpleMessage("የስልክ ቁጥር ይጠቀምባታል"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("የስልክ ቁጥር ይቅርታ አይደለም"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("የስልክ ቁጥር ይኖርበታል"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("ፋይል ይምረጡ እና ይማረጡ"),
        "pickEndDate": MessageLookupByLibrary.simpleMessage("የአጠቃቀም ቀን ይምረጡ"),
        "pickStartDate": MessageLookupByLibrary.simpleMessage("የጀምሪያ ቀን ይምረጡ"),
        "plan": MessageLookupByLibrary.simpleMessage("እቅድ"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("እባኮትን ብዛት ይጨምሩ"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage("እባክዎ የአይን ገንቢን ይመልከቱ"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "እባኮትን በመጀመሪያ የእቃ በርካታውን ያገናኝ"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage("እባክዎ የብሉቱዝ ፕሬንተርዎን ያገናኙ"),
        "pleaseEnterABiggerPassword":
            MessageLookupByLibrary.simpleMessage("እባክዎ ወፍጮ የይለፍ ቃል ይገቡ"),
        "pleaseEnterAConfirmPassword":
            MessageLookupByLibrary.simpleMessage("እባክዎ የይለፍ ቃል ይረጋግጡ"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("እባክዎ የይለፍ ቃል ይገባ"),
        "pleaseEnterAValidEmail":
            MessageLookupByLibrary.simpleMessage("እባክዎ ትክክለኛ ኢሜይል ይገቡ"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("እባኮትን ስም ይምረጡ"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("የይለፍ ቃል ይግቡ"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "እባክዎ የይለፍ ቃል እንዲያውቁ ኢሜይል አድራሻ ያስገቡ።"),
        "pleaseEnterTransactionNumber":
            MessageLookupByLibrary.simpleMessage("እባኮትን የገንዘብ እቅድ ቁጥር ይገቡ"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("እባኮትን የገንዘብ መጠን ይግቡ"),
        "pleaseSelectACategoryFirst":
            MessageLookupByLibrary.simpleMessage("እባኮትን የምድብ በመጀመሪያ ይምረጡ"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("እባኮትን እቅድ ይምረጡ"),
        "pleaseSelectBusinessCategory":
            MessageLookupByLibrary.simpleMessage("እባክዎ የንግድ ምድብ ይምረጡ"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage("እባኮትን ወቅታዊ ግዢ ኮድ ይጠቀሙ"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("በMobiPos የተሠራ"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("የተሰራ በ"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("ፕሪምየም ደንበኛ ድጋፍ"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("ፕሪምየም እቅድ"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("የወቅታዊ የክፍያ መጠን"),
        "price": MessageLookupByLibrary.simpleMessage("ዋጋ"),
        "print": MessageLookupByLibrary.simpleMessage("ማቅረብ"),
        "printingOption": MessageLookupByLibrary.simpleMessage("የመታት አማራጭ"),
        "privacyPolicy": MessageLookupByLibrary.simpleMessage("የግል ይዘት"),
        "product": MessageLookupByLibrary.simpleMessage("ምርት"),
        "productCode": MessageLookupByLibrary.simpleMessage("የምርት ኮድ"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("የምርት ኮድ ይባላል"),
        "productCodeName": MessageLookupByLibrary.simpleMessage("የምርት ኮድ/ስም"),
        "productDescription": MessageLookupByLibrary.simpleMessage("የምርት መግለጫ"),
        "productDetails": MessageLookupByLibrary.simpleMessage("የምርት ዝርዝር"),
        "productList": MessageLookupByLibrary.simpleMessage("የምርት ዝርዝር"),
        "productName": MessageLookupByLibrary.simpleMessage("የምርት ስም"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage("የምርት ስም በዚህ የመደብር አካባቢ አለ"),
        "productNameIsAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("የምርት ስም አስቀድሞ ተጨመረ"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("የምርት ስም ያስፈልጋል"),
        "products": MessageLookupByLibrary.simpleMessage("ምርቶች"),
        "profile": MessageLookupByLibrary.simpleMessage("መገናኛ"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("ፕሮፋይል እንደገና ማድረግ"),
        "profit": MessageLookupByLibrary.simpleMessage("ትርፍ"),
        "promo": MessageLookupByLibrary.simpleMessage("ማስታወቂያ"),
        "promoCode": MessageLookupByLibrary.simpleMessage("የተወዳዳሪ ኮድ"),
        "purchase": MessageLookupByLibrary.simpleMessage("ግዢ"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage("የግዢ ማስታወቂያ"),
        "purchaseConfirmed": MessageLookupByLibrary.simpleMessage("ግዢ የተረጋገጠ"),
        "purchaseDetails": MessageLookupByLibrary.simpleMessage("የግዢ ዝርዝር"),
        "purchaseInvoice": MessageLookupByLibrary.simpleMessage("ግዢ የክፍያ ቅጽ"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("የግዢ ዝርዝር"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("አሁን ግዢ"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("ፕሪምየም እቅድ ይግዙ"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("የግዢ ዋጋ"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("የግዢ ዋጋ ይምረጡ"),
        "purchaseRepoet": MessageLookupByLibrary.simpleMessage("የግዢ ዘገባ"),
        "purchaseReports": MessageLookupByLibrary.simpleMessage("የግዢ ዘገባ"),
        "purchaseReportss": MessageLookupByLibrary.simpleMessage("የግዢ ሪፖርት"),
        "purchaseReturn": MessageLookupByLibrary.simpleMessage("የግዥ መመለስ"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("የግዢ መመለስ ሪፖርት"),
        "purchaseTransition": MessageLookupByLibrary.simpleMessage("የግዥ ሂደት"),
        "qty": MessageLookupByLibrary.simpleMessage("ብዛት"),
        "quantity": MessageLookupByLibrary.simpleMessage("መጠን"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("ወቅታዊ ግብይቶች"),
        "recivedThePin": MessageLookupByLibrary.simpleMessage("PIN ተቀባ"),
        "referenceNumber": MessageLookupByLibrary.simpleMessage("የግምገማ ቁጥር"),
        "register": MessageLookupByLibrary.simpleMessage("መመዝገብ"),
        "registering": MessageLookupByLibrary.simpleMessage("መዝግብ"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("የቀረው ወርቅ"),
        "remove": MessageLookupByLibrary.simpleMessage("ይሰርዝ"),
        "reports": MessageLookupByLibrary.simpleMessage("ሪፖርቶች"),
        "requestHasBeenSend": MessageLookupByLibrary.simpleMessage("እቅድ ተልኳል"),
        "resendCode": MessageLookupByLibrary.simpleMessage("ኮድ ይዘምው"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("OTP ይዘምው :"),
        "retailer": MessageLookupByLibrary.simpleMessage("የዕቃ ሻጭ"),
        "retur": MessageLookupByLibrary.simpleMessage("እንደገና መመለስ"),
        "returN": MessageLookupByLibrary.simpleMessage("መመለስ"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("ወደ ወገን ይመለሱ"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("ወደ ቤት ይመለሱ"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("የመመለስ ብዛት"),
        "revenue": MessageLookupByLibrary.simpleMessage("ገቢ"),
        "safeGuardYourBusinessDate":
            MessageLookupByLibrary.simpleMessage("የውስጥ መረጃዎች ላይ ያንብቡ።"),
        "saleAmount": MessageLookupByLibrary.simpleMessage("የሽያጭ መጠን"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("የሽያጭ ዝርዝር"),
        "salePrice": MessageLookupByLibrary.simpleMessage("የሽያጭ ዋጋ"),
        "saleReports": MessageLookupByLibrary.simpleMessage("የሽያጭ ዘገባ"),
        "saleReportss": MessageLookupByLibrary.simpleMessage("የሽያጭ ሪፖርት"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("የሽያጭ መመለስ"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("የሽያጭ መመለስ ሪፖርት"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("የሽያጭ ቅንብር"),
        "sales": MessageLookupByLibrary.simpleMessage("ሽያጭ"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("ሽያጭ እና ግዢ ሪፖርቶች"),
        "salesList": MessageLookupByLibrary.simpleMessage("የሽያጭ ዝርዝር"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("የሽያጭ መመለስ"),
        "save": MessageLookupByLibrary.simpleMessage("ይቀመጡ"),
        "saveAndPublish": MessageLookupByLibrary.simpleMessage("አስቀምጥ እና ይወቅ"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("ለውጦችን ይቀርብ"),
        "saving": MessageLookupByLibrary.simpleMessage("ይህ ይቀርባል"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("የምርት QR ኮድ ይገብሩ"),
        "search": MessageLookupByLibrary.simpleMessage("ፈልግ"),
        "searchByProductCodeOrName":
            MessageLookupByLibrary.simpleMessage("በየምርት ኮድ ወይም ስም ይፈልጉ"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("ሁሉንም የተወዳዳሪ ኮድ ይመልከቱ"),
        "select": MessageLookupByLibrary.simpleMessage("ይምረጡ"),
        "selectAProductForReturn":
            MessageLookupByLibrary.simpleMessage("እቃ ለመመለስ ይምረጡ"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("ብራንድ ይምረጡ"),
        "selectCategory": MessageLookupByLibrary.simpleMessage("የምድብ ይምረጡ"),
        "selectContacts": MessageLookupByLibrary.simpleMessage("እባክዎን ይምረጡ"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("የምርት ዝርዝር ይምረጡ"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("የመውዕድ ምድብ ይምረጡ"),
        "selectTax": MessageLookupByLibrary.simpleMessage("የታክስ ይምረጡ"),
        "selectTaxType": MessageLookupByLibrary.simpleMessage("የታክስ ዓይነት ይምረጡ"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("አንድ ይምረጡ"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("ተለዋዋጭ ይምረጡ: "),
        "seller": MessageLookupByLibrary.simpleMessage("ሻጭ"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("በምርት ማስታወቂያ"),
        "send": MessageLookupByLibrary.simpleMessage("ይላኩ"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("ኢሜይል ይላኩ"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("መልእክት ይላኩ"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("የይለፍ ቃል ወይዘም ለንቃት"),
        "sendSms": MessageLookupByLibrary.simpleMessage("SMS ይላኩ"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("ስልክ መልእክት ይላኩ?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("ወይዘረ መልእክት ላክ"),
        "sendYOurEmail": MessageLookupByLibrary.simpleMessage("ኢሜይልዎን ይላኩ"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage("ኢሜይል እንደምታላክ"),
        "sendingMessage": MessageLookupByLibrary.simpleMessage("መልዕክት እየተላከ"),
        "serviceShipping": MessageLookupByLibrary.simpleMessage("አገልግሎት/መላኪያ"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("የእርስዎን ፕሮፋይል ይዘምው"),
        "setting": MessageLookupByLibrary.simpleMessage("ቅንብር"),
        "share": MessageLookupByLibrary.simpleMessage("አጋራ"),
        "shopGST": MessageLookupByLibrary.simpleMessage("የመሸጫ ግስት"),
        "signIn": MessageLookupByLibrary.simpleMessage("ገባ"),
        "signInWithEmail": MessageLookupByLibrary.simpleMessage("በኢሜይል ገባ"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("የደንበኛ ፊርማ"),
        "size": MessageLookupByLibrary.simpleMessage("መጠን"),
        "skip": MessageLookupByLibrary.simpleMessage("ተወው"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing": MessageLookupByLibrary.simpleMessage("ማህበራዊ ገንቢ"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage("እቅፍ ይወድቁ ይከናወን"),
        "startDate": MessageLookupByLibrary.simpleMessage("የጀምሪያ ቀን"),
        "startNewSale": MessageLookupByLibrary.simpleMessage("አዲስ ሽያጭ ይጀምሩ"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage("አይገባው"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "ወደ ዋነኛው የቴክኖሎጂ ማስታወቂያ ይቀርቡ። የእኛ የPOS SaaS POS የወደድን ይስማማ የእንዳትወን መሣሪያዎች አቅም ያለውን ይቅርታ ይደርስዋል።"),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("እስከ አልተከፍልም"),
        "stock": MessageLookupByLibrary.simpleMessage("ዝቅተኛ የእቃ"),
        "stockIsRequired": MessageLookupByLibrary.simpleMessage("እንደ ዝርዝር ትይይ"),
        "stockList": MessageLookupByLibrary.simpleMessage("የእቃ ዝርዝር"),
        "stocks": MessageLookupByLibrary.simpleMessage("ማእከል"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "ኤክሴል ፋይል ለመፍጠር የእንደ መዳብ ፈቃድ ያስፈልጋል"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("ንዑስ ግብር ዝርዝር"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("ንዑስ ግብር"),
        "subTotal": MessageLookupByLibrary.simpleMessage("የአንደኛ ዋጋ"),
        "submit": MessageLookupByLibrary.simpleMessage("ይላኩ"),
        "subscribeToOurYoutube":
            MessageLookupByLibrary.simpleMessage("በዩቱብ ይመዝገቡ"),
        "subscription": MessageLookupByLibrary.simpleMessage("እንደ ወር"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("በተሳካ መንገድ ተከናውኗል"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("በተሳካ ሁኔታ ወደ ውስጥ ተመለስከ"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("በስኬት ይዘንተው"),
        "supplier": MessageLookupByLibrary.simpleMessage("አቅራቢ"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("የእቃ እቃ የመረጃ ይምረጡ"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT ኮድ"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "የታኪያ መንግስት ወይም የአንዳንድ የማህበረሰብ መለያ ፎቶ ይውረዱ"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage("መለያ ካርድ ይውረዱ እና መረጃዎን ይይዘዉ"),
        "tap": MessageLookupByLibrary.simpleMessage("መጭነት"),
        "tax": MessageLookupByLibrary.simpleMessage("ግብር"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("የግብር ዡርዝ"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("ግብር በመቶ አነስ"),
        "taxRate": MessageLookupByLibrary.simpleMessage("ግብር ደረጃ"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "የግብር ዋጋዎች - የግብር ዋጋዎችዎን ያስተዳድሩ"),
        "taxReport": MessageLookupByLibrary.simpleMessage("የግብር ሪፖርት"),
        "taxType": MessageLookupByLibrary.simpleMessage("የታክስ ዓይነት"),
        "taxes": MessageLookupByLibrary.simpleMessage("ታክስ"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("ውሎች እና ሁኔታዎች"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("የተጠቃሚነት ይዘት"),
        "termsPrivacy": MessageLookupByLibrary.simpleMessage("የውልና የግለሰቦች መረጃ"),
        "thankYOuForYourDuePayment":
            MessageLookupByLibrary.simpleMessage("እናመሰግናለን የተከፈለውን ወርቅ"),
        "thankYou": MessageLookupByLibrary.simpleMessage("እናመሰግናለን"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("ምርትዎን እናመሰግናለን"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage("ለዚያ ኢሜይል አካውንት ያለው ነው"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage("ኤክሴል ፋይል በማስመዝገብ ላይ ተወርዷል"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "የመድረሻ ይህን አለበለይ። ይህ አለውና፣ ወደ ወርድ በለይ ተግባር አንዳንድ ይቅርታ ይሆናል።"),
        "thePasswordProvidedIsTooWeak":
            MessageLookupByLibrary.simpleMessage("የተሰጠው የይለፍ ቃል ወይዘ ይታወቃል"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "የሻጭ እና አንደኛ ይወገዳል እና ማስመዝገባው ከዚህ ጊዜ ወደሚለው ይደርሳል።"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "ሽያጭ ይሰረዝና ስለዚህ ያለው ማህደር ይሰረዝ ይችላል። ይህን ሽያጭ ማስወገድ ይችላል?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "ተጠቃሚው ይበውጥ ይሆናል እና ይህን ይወዳድሩ። ይህን እንደተለውጥ እርግጥ ነን?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "ተጠቃሚው ይሠርዝ ይሆናል እና ሁሉም ውሂብ ከእርስዎ መረጃ ይሠርዝ። ይህን ይሠርዝ ይደረግዎት ነው?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("ሶፍትዌር ሃርድዌር ወይም አገልግሎቶች"),
        "thisCategoryCannotBeDeleted":
            MessageLookupByLibrary.simpleMessage("ይህ ክፍል ማስወገድ አይቻልም"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(ይህ ወር)"),
        "thisProductAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("ይህ ምርት ይተወው"),
        "title": MessageLookupByLibrary.simpleMessage("አርእስት"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("ጽሁፍ ባዶ ማድረግ አልቻልኩም"),
        "to": MessageLookupByLibrary.simpleMessage("እስከ"),
        "toDate": MessageLookupByLibrary.simpleMessage("ወደ ቀን"),
        "today": MessageLookupByLibrary.simpleMessage("ዛሬ"),
        "total": MessageLookupByLibrary.simpleMessage("ጠቅላላ"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("ዋጋ መጠን"),
        "totalCollected": MessageLookupByLibrary.simpleMessage("ድምር ድምቀት"),
        "totalDue": MessageLookupByLibrary.simpleMessage("ጠቅላላ ወርቅ"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("ጠቅላላ ወጪ"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("አጠቃላይ እንደ ስልት"),
        "totalPayable": MessageLookupByLibrary.simpleMessage("አጠቃላይ የማይከፈል"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("አጠቃላይ ዋጋ"),
        "totalProducts": MessageLookupByLibrary.simpleMessage("አጠቃላይ ምርቶች"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("አጠቃላይ ትርፍ"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("ድምር ግዢ"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("አጠቃላይ የመመለስ ብዛት"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("ድምር መመለስ"),
        "totalSale": MessageLookupByLibrary.simpleMessage("አጠቃላይ ሽያጭ"),
        "totalStock": MessageLookupByLibrary.simpleMessage("የእቃ ጠቅላላ ይዘት"),
        "totalValue": MessageLookupByLibrary.simpleMessage("ጠቅላላ ዋጋ"),
        "totalVat": MessageLookupByLibrary.simpleMessage("አጠቃላይ VAT"),
        "totals": MessageLookupByLibrary.simpleMessage("ጠቅላላ: "),
        "transaction": MessageLookupByLibrary.simpleMessage("ግብይት"),
        "transactionId": MessageLookupByLibrary.simpleMessage("የግብይት መለያ"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("እንደገና ይሞክሩ"),
        "twitter": MessageLookupByLibrary.simpleMessage("ትዊተር"),
        "type": MessageLookupByLibrary.simpleMessage("ዓይነት"),
        "unitName": MessageLookupByLibrary.simpleMessage("የአቀማመጥ ስም"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("አንድ ዋጋ"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("የአንድ ዋጋ"),
        "units": MessageLookupByLibrary.simpleMessage("አቀማመጥ"),
        "unlimited": MessageLookupByLibrary.simpleMessage("አንድ አይደለም"),
        "unlimitedUsage": MessageLookupByLibrary.simpleMessage("የከባድ ተጠቃሚ"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "የPOS SaaS POS መልክ የተለያዩ መምርምም ይይቅርታ እንዳወርቅ ይወደዱ።"),
        "unpaid": MessageLookupByLibrary.simpleMessage("ያልተከፈለ"),
        "update": MessageLookupByLibrary.simpleMessage("እንደገና መሻሻል"),
        "updateContact": MessageLookupByLibrary.simpleMessage("የገናኙ መረጃ ይሻሽሉ"),
        "updateNow": MessageLookupByLibrary.simpleMessage("አሁን ይዘው"),
        "updateProduct": MessageLookupByLibrary.simpleMessage("ምርት ይዘው"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "የእቅድዎን በመጀመሪያ ይዘጋጁ፣ የእድልዎ ከተገኘው በላይ ነው"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("የመረጃ መገናኛዎትን ይዘው"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "የእርስዎን ፕሮፋይል ይዘምው እንደዚህ እንዲያስቀድም"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "የመረጃ መገናኛዎትን ይዘው በዚህ ምርት አንዱ ይታወቃል"),
        "updated": MessageLookupByLibrary.simpleMessage("የተሻሻለ"),
        "upload": MessageLookupByLibrary.simpleMessage("ይማረጡ"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("የማስገባት ስነ ስርዓት"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("ይማረጡ ተወዳጅ"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("ፋይል ማስገባት"),
        "upplier": MessageLookupByLibrary.simpleMessage("አቅራቢ"),
        "usbC": MessageLookupByLibrary.simpleMessage("USB C"),
        "use": MessageLookupByLibrary.simpleMessage("እንደ ምርት ይጠቀሙ"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("POS SaaS ይጠቀሙ"),
        "useOfTheSystem": MessageLookupByLibrary.simpleMessage("የስርዓቱ አገልግሎት"),
        "userIsDeleted": MessageLookupByLibrary.simpleMessage("ተጠቃሚ ይተው"),
        "userRole": MessageLookupByLibrary.simpleMessage("የተጠቃሚ ድርጅት"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("የተጠቃሚ አገልግሎት ዝርዝር"),
        "userTitle": MessageLookupByLibrary.simpleMessage("የተጠቃሚ ርዕስ"),
        "userTitleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("የተጠቃሚ ርዕስ አይቻልም"),
        "value": MessageLookupByLibrary.simpleMessage("ዋጋ"),
        "vatDoesNotApply": MessageLookupByLibrary.simpleMessage("ቫት ይኖርም"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("OTP ይመልከቱ"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("የስልክ ቁጥር ይመልከቱ"),
        "viewAll": MessageLookupByLibrary.simpleMessage("ሁሉንም ይመልከቱ"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("ዝርዝር ይመልከቱ"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("ወደ ውስጥ የሚገኙ ደንበኞች"),
        "warehouse": MessageLookupByLibrary.simpleMessage("የመደብር"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("የእቃ መዝገብ ተወስኗል"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("የእቃ መዝገብ"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("የእቃ መዝገብ ስም"),
        "warranty": MessageLookupByLibrary.simpleMessage("የተያያዘ ዕቃ"),
        "weHaveSendAnEmailwithInstructions":
            MessageLookupByLibrary.simpleMessage(
                "እባክዎ ወደ እባክዎ የሚገኙትን የወደፊት ዝርዝር አስቀድሞ እንዲህ አድርጉ።"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "እኛ ሶፍትዌር ወይም ይኖርበታል እና ወይም ይቀንቃሉ ወይም ይኖርበታል ወይም ይህን ወይም ወይም ይወዳሉ እንዲሁም ይህን ወይም ይቀይሩ ይቀይሩ።"),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "እኛ የእንደምን ተሳሳይ የአባብለት ዝርዝር ይቀንቃሉ፣ ይህ ይወዳሉ በዝርዝር ምንጭ ይኖርበታል ይወዳሉ እንዲሁም ወይም ይኖርበታል።"),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "በኩር አስቸጋሪ እና መካከለኛ ጥያቄ እንኳን በደንበኛ ድጋፍ እንዲያገኙ እናይነዋል። ለእኛ ከመረጃ ተነጥብ ወይም ወይንም ወደኋላ ይናገሩ።"),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "እኛ የእንደምን የእንደምን ዝርዝር ማሳወቅ እንደዋች ይወዳሉ፣ ሙሉው ይቀንቃሉ በንድር ይቀንቃሉ፣ እንዲሁም ወይም ይወዳሉ። ይህ ወይም ይህ ይቀይሩ ይኖርበታል ይህን የይቀንቃል።"),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "እኛ ክፍያውን እናወቅ ምንም በ1-2 ሰዓታት እንቅጽበ"),
        "weekly": MessageLookupByLibrary.simpleMessage("ሳምንታዊ"),
        "weight": MessageLookupByLibrary.simpleMessage("ውጤት"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("እንደሚያዳምጡ"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("ወረዳ ዋስትና"),
        "wholeSalePrice": MessageLookupByLibrary.simpleMessage("የገበያ ዋጋ"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("የምርት ዋጋ"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("ግዢ ደንበኛ"),
        "willBeAddedSoon": MessageLookupByLibrary.simpleMessage("በአጭር ጊዜ ይጨምር"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("በዚያ ይቀድማል"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("መልእክትዎን እዚህ ይጻፉ"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("ወሳኝ OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage("ወሳኝ የተጠቃሚ የይለፍ ቃል ተቀባ"),
        "yearly": MessageLookupByLibrary.simpleMessage("የዓመት"),
        "yesDeleteForever": MessageLookupByLibrary.simpleMessage("አዎን ወደ ዘርዳ"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("አንድ ወቅታዊ ተጠቃሚ አልነሱም"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("የምትጠቀሙ"),
        "youCanNotPayMoreThenDue":
            MessageLookupByLibrary.simpleMessage("የተገኘውን በላይ አትከፍሉ"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("እባክዎ ኢሜይል ተቀባ"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "ወደ አካውንትዎ በተሳካ ሁኔታ ግባን። Pos SaaS እንደተወዳጅ ይቀጥሉ።"),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("ፈቃድ ማቅረብ አለብዎት"),
        "youHaveToReLogin":
            MessageLookupByLibrary.simpleMessage("በይለፍ ቃል ማውረድ አለብዎት።"),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage("እባክዎን የመግዛት በፊት መለያ ይማረግጡ"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("መልእክትዎ ይቀርባል"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("የእርስዎ ፓኬጅ"),
        "yourPackageWillExpireinDay":
            MessageLookupByLibrary.simpleMessage("የእርስዎ ጥቅም በ5 ቀን ይወጣል")
      };
}
