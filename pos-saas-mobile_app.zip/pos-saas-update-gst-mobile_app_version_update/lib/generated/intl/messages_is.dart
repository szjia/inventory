// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a is locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'is';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Halda áfram"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("GST númer"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("MRP er nauðsynlegt"),
        "OK": MessageLookupByLibrary.simpleMessage("OK"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Símanúmer"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT Kóði"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Snarl"),
        "TAX": MessageLookupByLibrary.simpleMessage("SKATTUR"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Upphleðslur"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("Notandatitill"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Pakki þinn rennur út í dag\n\nVinsamlegast kaupið aftur"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) Kerfið er veitt einungis til þess að auðvelda sölutransaksjónir og tengdar aðgerðir í þínu fyrirtæki."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) Til að nota kerfið gætirðu verið krafinn um að búa til reikning. Þú samþykkir að veita nákvæmar, núverandi og heilar upplýsingar á skráningarferlinu og að uppfæra þessar upplýsingar til að halda þeim nákvæmum og heillum."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("Um forritið"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Um okkur"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Samþykki skilmála"),
        "accountName": MessageLookupByLibrary.simpleMessage("Reikningsnafn"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("Reikningsnúmer"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Skráning reiknings"),
        "acton": MessageLookupByLibrary.simpleMessage("Aðgerð"),
        "add": MessageLookupByLibrary.simpleMessage("Bæta við"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Bæta við merki"),
        "addCategory": MessageLookupByLibrary.simpleMessage("Bæta við flokk"),
        "addContact": MessageLookupByLibrary.simpleMessage("Bæta við tengilið"),
        "addCustomer":
            MessageLookupByLibrary.simpleMessage("Bæta við viðskiptavini"),
        "addDelivery":
            MessageLookupByLibrary.simpleMessage("Bæta við sendingu"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Bæta við lýsingu"),
        "addDescription":
            MessageLookupByLibrary.simpleMessage("Bæta við athugasemd"),
        "addDiscount":
            MessageLookupByLibrary.simpleMessage("Bæta við afslætti"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Bæta við skjalsnúmeri"),
        "addDucument": MessageLookupByLibrary.simpleMessage("Bæta við skjali"),
        "addExpense":
            MessageLookupByLibrary.simpleMessage("Bæta við útgjöldum"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Bæta við útgjaldaflokki"),
        "addItems": MessageLookupByLibrary.simpleMessage("Bæta við vörum"),
        "addNew": MessageLookupByLibrary.simpleMessage("Bæta nýju við"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Bæta við nýju heimilisfangi"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Bæta við nýrri vöru"),
        "addNewTax":
            MessageLookupByLibrary.simpleMessage("Bæta nýjum skatti við"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Bæta nýjum skatti við með einum/mörgum skatttegundum"),
        "addNote": MessageLookupByLibrary.simpleMessage("Bæta við athugasemd"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Bættu við vöru fyrst"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Bæta við kynningarkóða"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Bæta við kaupi"),
        "addSales": MessageLookupByLibrary.simpleMessage("Bæta við sölu"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Bætt við með góðum árangri"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Bæta við einingu"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Bæta notendahlutverki við"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Bætt við með góðum árangri"),
        "addedToCart": MessageLookupByLibrary.simpleMessage("Bætt í körfu"),
        "address": MessageLookupByLibrary.simpleMessage("Heimilisfang"),
        "admin": MessageLookupByLibrary.simpleMessage("Stjórnandi"),
        "all": MessageLookupByLibrary.simpleMessage("Allt"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("Allar viðskiptalausnir"),
        "alreadyAdded":
            MessageLookupByLibrary.simpleMessage("Nú þegar bætt við"),
        "alreadyExists":
            MessageLookupByLibrary.simpleMessage("Er nú þegar til"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Ertu með reikning?"),
        "amount": MessageLookupByLibrary.simpleMessage("Upphæð"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "Tölvupóstur hefur verið sendur\\nAthugaðu pósthólfið þitt"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Android & iOS forritastuðningur"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Gildandi skattur"),
        "apply": MessageLookupByLibrary.simpleMessage("Senda inn"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Ertu viss um að eyða þessari reikning?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Ertu viss um að eyða þessari sölu?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Ertu viss um að eyða þessum notanda?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Ertu viss um að þú viljir eyða þessum skatti?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Ertu viss um að þú viljir eyða þessum skattahópi?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Viltu eyða þessari vörugeymslu?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Ertu viss um að þú viljir eyða þessum notanda?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Vottuð undirskrift"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Þú berð ábyrgð á að viðhalda trúnaðinum á reikningi þínum og lykilorði og að takmarka aðgang að reikningi þínum. Þú samþykkir að bera ábyrgð á öllum aðgerðum sem eiga sér stað undir reikningi þínum."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Þú verður að vera að minnsta kosti 18 ára eða löglegur aldursmiðaður í þínu ríki til að nota kerfið."),
        "backSide": MessageLookupByLibrary.simpleMessage("Afturhlið"),
        "backToHome":
            MessageLookupByLibrary.simpleMessage("Til baka á heimasíðu"),
        "balance": MessageLookupByLibrary.simpleMessage("Eign"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladess"),
        "bank": MessageLookupByLibrary.simpleMessage("Banki"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Gjaldmiðill bankareiknings"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Bankareikningsmynt"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Bankaupplýsingar"),
        "bankName": MessageLookupByLibrary.simpleMessage("Bankanafn"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("Bankaflutningur"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Strikamerki fundið"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Reikningur/Vöru"),
        "billTo": MessageLookupByLibrary.simpleMessage("Reikna til"),
        "branchName": MessageLookupByLibrary.simpleMessage("Skrifstofunafn"),
        "brand": MessageLookupByLibrary.simpleMessage("Merki"),
        "brandName": MessageLookupByLibrary.simpleMessage("Merkiheiti"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("Massa\nUpphleðsla"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Viðskiptagrein"),
        "buy": MessageLookupByLibrary.simpleMessage("Kaupa"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Kaupa fyrirgreiðsluáætlun"),
        "buySms": MessageLookupByLibrary.simpleMessage("Kaupa SMS"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Með því að fá aðgang að eða nota sölukerfið (POS) sem er veitt af [Nafn fyrirtækisins þíns] (\"Fyrirtækið\"), samþykkir þú að vera bundinn af þessum skilmálum. Ef þú samþykkir ekki þessa skilmála, vinsamlegast ekki nota kerfið."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Þú berð ábyrgð á að tryggja að aðgangur þinn að og notkun á kerfinu sé í samræmi við allar viðeigandi lög og reglugerðir."),
        "cacel": MessageLookupByLibrary.simpleMessage("Hætta við"),
        "call": MessageLookupByLibrary.simpleMessage("Hringja"),
        "callForEmergencySupport":
            MessageLookupByLibrary.simpleMessage("Hringdu í neyðaraðstoð"),
        "camera": MessageLookupByLibrary.simpleMessage("Myndavél"),
        "cancel": MessageLookupByLibrary.simpleMessage("Afturkalla"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Afturkalla allar vörur"),
        "capacity": MessageLookupByLibrary.simpleMessage("Rúmmál"),
        "card": MessageLookupByLibrary.simpleMessage("Kort"),
        "cash": MessageLookupByLibrary.simpleMessage("Fé"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Félaus"),
        "categories": MessageLookupByLibrary.simpleMessage("Flokkar"),
        "category": MessageLookupByLibrary.simpleMessage("Flokkur"),
        "categoryName": MessageLookupByLibrary.simpleMessage("Flokksheiti"),
        "categoryNameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Flokksheiti er nú þegar til"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("Heiti flokks"),
        "change": MessageLookupByLibrary.simpleMessage("Breyta?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Breyta lykilorði"),
        "checkEmail":
            MessageLookupByLibrary.simpleMessage("Skoðaðu tölvupóstinn"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Veldu viðskiptavin"),
        "choseASupplier": MessageLookupByLibrary.simpleMessage("Veldu birgja"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Veldu eiginleika þína"),
        "clarence": MessageLookupByLibrary.simpleMessage("Cleareance"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Smelltu til að tengjast"),
        "close": MessageLookupByLibrary.simpleMessage("Loka"),
        "color": MessageLookupByLibrary.simpleMessage("Litur"),
        "combinationOfMultipleTaxes":
            MessageLookupByLibrary.simpleMessage("(Samsetning margra skatta)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Koma fljótlega"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Heimilisfang fyrirtækis"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Fyrirtæki & Verslunarnafn"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("Fyrirtæki og viðskipti nafn"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Ljúka transaksjón"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Staðfesta lykilorð"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Staðfesta skila"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Til hamingju"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Hafðu samband"),
        "continu": MessageLookupByLibrary.simpleMessage("Halda áfram"),
        "country": MessageLookupByLibrary.simpleMessage("Land"),
        "create": MessageLookupByLibrary.simpleMessage("Búa til"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Búðu til ókeypis reikning"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Búið til og vistað"),
        "currency": MessageLookupByLibrary.simpleMessage("Gjaldmiðill"),
        "currentStock":
            MessageLookupByLibrary.simpleMessage("Núverandi birgðir"),
        "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
            "Sérsniðið vörumerki reikninga"),
        "customer": MessageLookupByLibrary.simpleMessage("Viðskiptavinur"),
        "customerDetails": MessageLookupByLibrary.simpleMessage(
            "Skráningarupplýsingar viðskiptavinar"),
        "customerGST":
            MessageLookupByLibrary.simpleMessage("GST viðskiptavinar"),
        "customerName":
            MessageLookupByLibrary.simpleMessage("Nafn viðskiptavinar"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Dagleg viðskipti"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Yfirlit yfir stjórnborð"),
        "dataSavedSuccessfully": MessageLookupByLibrary.simpleMessage(
            "Gögnum vistað með góðum árangri"),
        "date": MessageLookupByLibrary.simpleMessage("Dagsetning"),
        "day": MessageLookupByLibrary.simpleMessage("Dagur"),
        "dealer": MessageLookupByLibrary.simpleMessage("Söluaðili"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("Söluaðila verð"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("Sjálfgefið VSK prósent"),
        "delete": MessageLookupByLibrary.simpleMessage("Eyða"),
        "deleting": MessageLookupByLibrary.simpleMessage("Fjarlægja"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Sendingarheimilisfang"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Afhendingarheimildir"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Sendingarkostnaður"),
        "describtion": MessageLookupByLibrary.simpleMessage("Lýsing"),
        "description": MessageLookupByLibrary.simpleMessage("Lýsing"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Lýsing má ekki vera tómt"),
        "details": MessageLookupByLibrary.simpleMessage("Upplýsingar"),
        "discount": MessageLookupByLibrary.simpleMessage("Afsláttur"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Truflaðu ekki"),
        "done": MessageLookupByLibrary.simpleMessage("Lokið"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Niðurhal Excel sniðs"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Niðurhölum lokið í niðurhalamöppu"),
        "due": MessageLookupByLibrary.simpleMessage("Skylda"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Skylda: "),
        "dueCollection": MessageLookupByLibrary.simpleMessage("Skuldasöfnun"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("Skýrslur um innheimtu"),
        "dueList": MessageLookupByLibrary.simpleMessage("Skuldaskrá"),
        "dueReports": MessageLookupByLibrary.simpleMessage("Skulda skýrslur"),
        "duration": MessageLookupByLibrary.simpleMessage("Tími"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Tímaskeið: Frá"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "Auðvelt í notkun farsíma POS"),
        "edit": MessageLookupByLibrary.simpleMessage("Breyta"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Breyta kaupafaktúru"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Breyta sölufaktúru"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Breyta samfélagsmiðlum"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Breyting tókst"),
        "editTax": MessageLookupByLibrary.simpleMessage("Breyta skatti"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Breyta skattahóp"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("Breyta vörugeymslu"),
        "email": MessageLookupByLibrary.simpleMessage("Netfang"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("Netfang"),
        "emailCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Tölvupóstur getur ekki verið tómur"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "Tölvupóstur sendur! Athugaðu pósthólfið þitt"),
        "endDate": MessageLookupByLibrary.simpleMessage("Lokadagur"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Sláðu inn gilt verð"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Sláðu inn gilt afslátt"),
        "enterAValidPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Sláðu inn gilt símanúmer"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Sláðu inn gilt verð"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("Sláðu inn gilt magn"),
        "enterAddress":
            MessageLookupByLibrary.simpleMessage("Sláðu inn heimilisfang"),
        "enterAmount":
            MessageLookupByLibrary.simpleMessage("Sláðu inn upphæð."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Sláðu inn merkiheiti"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Sláðu inn rúmmál"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Sláðu inn nafnið á flokk"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Sláðu inn lit"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "Sláðu inn GST númer viðskiptavinar"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Sláðu inn söluaðila verð"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Sláðu inn lýsingu"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("Sláðu inn afslátt."),
        "enterExpenseDate": MessageLookupByLibrary.simpleMessage(
            "Sláðu inn dagsetningu útgjalds"),
        "enterFullAddress": MessageLookupByLibrary.simpleMessage(
            "Sláðu inn fullt heimilisfang"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Sláðu inn faktúrunaúmer"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Sláðu inn lág birgða viðvörun magn"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Sláðu inn framleiðanda"),
        "enterMessageContent": MessageLookupByLibrary.simpleMessage(
            "Sláðu inn innihald skilaboða"),
        "enterMrpOrRetailerPirce":
            MessageLookupByLibrary.simpleMessage("Sláðu inn MRP/Smásöluverð"),
        "enterName": MessageLookupByLibrary.simpleMessage("Sláðu inn nafn"),
        "enterNote":
            MessageLookupByLibrary.simpleMessage("Sláðu inn athugasemd"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Sláðu inn nafn aðila"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Sláðu inn símanúmer"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Sláðu inn vörukóða eða skannaðu"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Sláðu inn nafnið á vöru"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Sláðu inn kaupsverð."),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("Sláðu inn tilvísunarnúmer"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Sláðu inn stærð"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("Sláðu inn lager."),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Sláðu inn skattprósentu"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("Sláðu inn viðskiptakóða"),
        "enterType": MessageLookupByLibrary.simpleMessage("Sláðu inn tegund"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("Sláðu inn notandatitil"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Sláðu inn gilt upphæð"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Sláðu inn nafn vörugeymslu"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Sláðu inn vigt"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Sláðu inn heildsöluverð"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("Sláðu inn lýsingu þína hér"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("Sláðu inn netfangið þitt"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "Sláðu inn titil á afturvirkni þína"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Sláðu inn GST númerið þitt"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("Sláðu inn símanúmerið þitt"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Sláðu inn nafnið þitt"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("Sláðu inn símanúmerið þitt"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Sláðu inn lykilorðið þitt"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Sláðu inn símanúmerið þitt"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "Sláðu inn transaksjón númerið þitt"),
        "error": MessageLookupByLibrary.simpleMessage("Villa"),
        "excTax": MessageLookupByLibrary.simpleMessage("Utan skatts"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("Excel hlaðari"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Einkaréttur"),
        "expense": MessageLookupByLibrary.simpleMessage("Kostnaður"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Útgjaldaflokkur"),
        "expenseDate":
            MessageLookupByLibrary.simpleMessage("Dagsetning útgjalds"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Útgjald fyrir"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Útgjaldaskýrsla"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Rennur út"),
        "expired": MessageLookupByLibrary.simpleMessage("Útrunnið"),
        "expiring": MessageLookupByLibrary.simpleMessage("Rennur út"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Mistókst með villu"),
        "fashion": MessageLookupByLibrary.simpleMessage("Föt"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Eiginleikar eru mikilvægur þáttur sem gerir POS SaaS frábrugðið hefðbundnum lausnum."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Afturvirkni"),
        "firstName": MessageLookupByLibrary.simpleMessage("Fyrsta nafn"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Fylgdu okkur á\\nFacebook"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Fylgdu okkur á\\nTwitter"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Fonthlið"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("Fyrir ótakmarkað notkun"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Gleymt lykilorði"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Gleymt lykilorði?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Frá dagsetningu"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("Ókeypis gagnaafritun"),
        "freeLifeTimeUpdate":
            MessageLookupByLibrary.simpleMessage("Ókeypis líftímasamsvörun"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Ókeypis pakkning"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Ókeypis áætlun"),
        "from": MessageLookupByLibrary.simpleMessage("(Frá"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Heilt greitt"),
        "gallary": MessageLookupByLibrary.simpleMessage("Myndasafn"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("Að búa til PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Fá OTP"),
        "govermentId": MessageLookupByLibrary.simpleMessage("Ríkisauðkenni"),
        "guest": MessageLookupByLibrary.simpleMessage("Gestur"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Ertu ekki með aðgang?"),
        "history": MessageLookupByLibrary.simpleMessage("Saga"),
        "home": MessageLookupByLibrary.simpleMessage("Heim"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Hvernig við verndum upplýsingar þínar"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Hvernig við notum upplýsingar þínar"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Identitetsstaðfesting"),
        "image": MessageLookupByLibrary.simpleMessage("Mynd"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("InHouse má ekki eyða"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("InHouse má ekki breyta"),
        "inWord": MessageLookupByLibrary.simpleMessage("Í orði"),
        "incTax": MessageLookupByLibrary.simpleMessage("Innifalið skattur"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Innifalið"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("Auka birgðir"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Tæki"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Fjöldi"),
        "invoice": MessageLookupByLibrary.simpleMessage("Reikningur"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("Faktúrunaúmer"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Faktúrustillingar"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Reikningur skoðari"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Vara bætt við"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("KYC staðfesting"),
        "language": MessageLookupByLibrary.simpleMessage("Tunga"),
        "lastName": MessageLookupByLibrary.simpleMessage("Síðasta nafn"),
        "ledger": MessageLookupByLibrary.simpleMessage("Bókhald"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Einstakt\nKaup"),
        "link": MessageLookupByLibrary.simpleMessage("Tengill"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Samtalsstuðningur"),
        "loading": MessageLookupByLibrary.simpleMessage("Hleð"),
        "logIn": MessageLookupByLibrary.simpleMessage("Innskráning"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Útskráning"),
        "logOut": MessageLookupByLibrary.simpleMessage("Skráðu út"),
        "login": MessageLookupByLibrary.simpleMessage("Innskrá"),
        "logo": MessageLookupByLibrary.simpleMessage("Merki"),
        "loss": MessageLookupByLibrary.simpleMessage("Tap"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Tap/Hagnaður"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Upplýsingar um Tap/Hagnað"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Taps/Gróða skýrsla"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Taps/Gróða skýrslur"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Lág birgða viðvörun"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Skapaðu varanlegan áhuga á viðskiptavinum þínum með merkingu á reikningum. Ótakmarkað uppfærslur okkar veita einstakt tækifæri til að sérsníða reikninga þína, bæta fagmannlega snertingu sem styrkir vörumerki þitt og eykur tryggð viðskiptavina."),
        "manageYourBussinessWith": MessageLookupByLibrary.simpleMessage(
            "Stjórnaðu fyrirtæki þínu með "),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Framleiðsludagsetning"),
        "margin": MessageLookupByLibrary.simpleMessage("Mörk"),
        "masterCard": MessageLookupByLibrary.simpleMessage("Master kort"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Framleiðandi"),
        "message": MessageLookupByLibrary.simpleMessage("Skilaboð"),
        "messageHistory": MessageLookupByLibrary.simpleMessage("Skilaboðasaga"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "POS SaaS forritið er ókeypis, auðvelt í notkun. Raunar, það er eitt af bestu POS kerfum í heiminum."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "POS SaaS er fullkomin viðskiptalausn með birgðum, reikningum, sölu, kostnaði & tapi/hagnaði."),
        "mobile": MessageLookupByLibrary.simpleMessage("Farsími"),
        "mobilePayment":
            MessageLookupByLibrary.simpleMessage("Farsímagreiðsla"),
        "monthly": MessageLookupByLibrary.simpleMessage("Mánaðarlega"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("Fleiri upplýsingar"),
        "name": MessageLookupByLibrary.simpleMessage("Sláðu inn nafnið þitt."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Nafn er nú þegar til"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("Nafn má ekki vera tómt"),
        "next": MessageLookupByLibrary.simpleMessage("Næsta"),
        "noConnection": MessageLookupByLibrary.simpleMessage("Engin tenging"),
        "noData": MessageLookupByLibrary.simpleMessage("Engin gögn"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Engar upplýsingar tiltækar"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Engin gögn fundust"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("Engin saga fannst!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Engin vara fannst"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("Engin undirskattur valin"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("Engin transaksjón fannst!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Enginn notandi fundinn fyrir það netfang."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "Ekkert notendahlutverk fundið"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Ekki virk notandi"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Ekki veitt"),
        "note": MessageLookupByLibrary.simpleMessage("Athugasemd"),
        "notes": MessageLookupByLibrary.simpleMessage("Athugasemdir"),
        "notification": MessageLookupByLibrary.simpleMessage("Tilkynning"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP sent til"),
        "office": MessageLookupByLibrary.simpleMessage("Skrifstofa"),
        "ok": MessageLookupByLibrary.simpleMessage("Ok"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS kerfi sem inniheldur mikið af virkni, þar á meðal söluveitingu, birgðastjórnun."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Þetta kerfi hjálpar þér að bæta aðgerðir þínar fyrir viðskiptavini þína."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Sölukerfið okkar ætti að einfalda daglegar aðgerðir sjálfkrafa, sem gerir það auðvelt að sigla."),
        "openingBalance": MessageLookupByLibrary.simpleMessage("Upphafsbalans"),
        "order": MessageLookupByLibrary.simpleMessage("Pantanir"),
        "other": MessageLookupByLibrary.simpleMessage("Annað"),
        "otp": MessageLookupByLibrary.simpleMessage("Loka"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Utan birgða"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Pakkning"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Pakkningar eiginleikar"),
        "paid": MessageLookupByLibrary.simpleMessage("Greitt"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Greidd upphæð"),
        "parties": MessageLookupByLibrary.simpleMessage("Partí"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Listi yfir aðila"),
        "partyGST": MessageLookupByLibrary.simpleMessage("Party GST"),
        "partyName": MessageLookupByLibrary.simpleMessage("Nafn aðila"),
        "password": MessageLookupByLibrary.simpleMessage("Lykilorð"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Lykilorð og staðfesting á lykilorði passa ekki"),
        "passwordCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Lykilorð getur ekki verið tómt"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("Lykilorð passar ekki"),
        "payCash": MessageLookupByLibrary.simpleMessage("Borga með reiðufé"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash": MessageLookupByLibrary.simpleMessage("Borga með bKash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Borga með Paypal"),
        "payeeName": MessageLookupByLibrary.simpleMessage("Nafn viðtakanda"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("Númer viðtakanda"),
        "payment": MessageLookupByLibrary.simpleMessage("Greiðsla"),
        "paymentAmount":
            MessageLookupByLibrary.simpleMessage("Greiðslufjárhæð"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Greiðsla lokið"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Greiðslu leiðbeiningar:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("Greiðsluaðferð"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Greiðslutegund"),
        "pdfView": MessageLookupByLibrary.simpleMessage("PDF skoðun"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Persónuupplýsingar"),
        "phone": MessageLookupByLibrary.simpleMessage("Sími"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Símanúmer"),
        "phoneNumberAlreadyUsed":
            MessageLookupByLibrary.simpleMessage("Símanúmer er þegar notað"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("Símanúmer er ekki gilt"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("Símanúmer er nauðsynlegt"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("Veldu og hlaðið skrá"),
        "pickEndDate": MessageLookupByLibrary.simpleMessage("Veldu lokadag"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Veldu upphafsdag"),
        "plan": MessageLookupByLibrary.simpleMessage("Áætlun"),
        "pleaseAddQuantity": MessageLookupByLibrary.simpleMessage(
            "Vinsamlegast bættu við magni"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Vinsamlegast athugaðu nettengingu þína"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Vinsamlegast tengdu prentarann fyrst"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Vinsamlegast tengdu Bluetooth prentarann þinn"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Vinsamlegast sláðu inn stærra lykilorð"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Vinsamlegast sláðu inn staðfestingarlykilorð"),
        "pleaseEnterAPassword": MessageLookupByLibrary.simpleMessage(
            "Vinsamlegast sláðu inn lykilorð"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Vinsamlegast sláðu inn gilt netfang"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Vinsamlegast sláðu inn nafn"),
        "pleaseEnterPassword": MessageLookupByLibrary.simpleMessage(
            "Vinsamlegast sláðu inn lykilorð"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Vinsamlegast sláðu inn netfangið hér að neðan til að fá tengil til að endurstilla lykilorð."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Vinsamlegast sláðu inn viðskiptanúmer"),
        "pleaseInterAmount": MessageLookupByLibrary.simpleMessage(
            "Vinsamlegast sláðu inn upphæð"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Vinsamlegast veldu flokk fyrst"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("Vinsamlegast veldu áætlun"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Vinsamlegast veldu viðskiptagátt"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Vinsamlegast notaðu gilt kaup kóða til að nota forritið"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Drifið af Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Stýrt af"),
        "premiumCustomerSupport": MessageLookupByLibrary.simpleMessage(
            "Faglegur viðskiptastuðningur"),
        "premiumPlan":
            MessageLookupByLibrary.simpleMessage("Fyrirgreiðsluáætlun"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Fyrri greiðslur"),
        "price": MessageLookupByLibrary.simpleMessage("Verð"),
        "print": MessageLookupByLibrary.simpleMessage("Prenta"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Prentvalkostir"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Persónuverndarstefna"),
        "product": MessageLookupByLibrary.simpleMessage("Vara"),
        "productCode": MessageLookupByLibrary.simpleMessage("Vörukóði"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("Vöru númer er nauðsynlegt"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Vöru kóði/Nafn"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Vöru lýsing"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Vöru upplýsingar"),
        "productList": MessageLookupByLibrary.simpleMessage("Vörulistar"),
        "productName": MessageLookupByLibrary.simpleMessage("Nafn vöru"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Vöruheiti er þegar til í þessu vörugeymslu"),
        "productNameIsAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("Vörunafn er þegar bætt við"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("Vöruheiti er nauðsynlegt"),
        "products": MessageLookupByLibrary.simpleMessage("Vörur"),
        "profile": MessageLookupByLibrary.simpleMessage("Prófíl"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("Breyta prófíli"),
        "profit": MessageLookupByLibrary.simpleMessage("Hagnaður"),
        "promo": MessageLookupByLibrary.simpleMessage("Sértilboð"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Tilboðskóði"),
        "purchase": MessageLookupByLibrary.simpleMessage("Kaup"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage("Kaupa viðvörun"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Kaup staðfest"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Kaupaupplýsingar"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Kaupareikningur"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("Kaupaskrá"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Kauptu núna"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Kaupa fyrirgreiðsluáætlun"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("Kaupsverð"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("Kaupa verð er nauðsynlegt"),
        "purchaseRepoet": MessageLookupByLibrary.simpleMessage("Kaupa skýrsla"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Kaupa skýrslur"),
        "purchaseReportss": MessageLookupByLibrary.simpleMessage("Kauprapport"),
        "purchaseReturn": MessageLookupByLibrary.simpleMessage("Kaupa skila"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("Kaupa skila skýrsla"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Kaupa umbreytingu"),
        "qty": MessageLookupByLibrary.simpleMessage("Magn"),
        "quantity": MessageLookupByLibrary.simpleMessage("Magn"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Nýlegar færslur"),
        "recivedThePin": MessageLookupByLibrary.simpleMessage("Móttakinn PIN"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Tilvísunarnúmer"),
        "register": MessageLookupByLibrary.simpleMessage("Skráðu þig"),
        "registering": MessageLookupByLibrary.simpleMessage("Skráning"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("Eftirstöðvar"),
        "remove": MessageLookupByLibrary.simpleMessage("Fjarlægja"),
        "reports": MessageLookupByLibrary.simpleMessage("Skýrslur"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Fyrirspurn hefur verið send"),
        "resendCode": MessageLookupByLibrary.simpleMessage("Endursenda kóða"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("Endursenda OTP: "),
        "retailer": MessageLookupByLibrary.simpleMessage("Smásali"),
        "retur": MessageLookupByLibrary.simpleMessage("Aftur"),
        "returN": MessageLookupByLibrary.simpleMessage("Skila"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("Skila fjárhæð"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("Skila upphæð"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("Skila magn"),
        "revenue": MessageLookupByLibrary.simpleMessage("Tekjur"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Verndaðu fyrirtækisgögnin þín auðveldlega. Ótakmarkað uppfærslur okkar á Pos Saas POS felur í sér ókeypis gagnaafritun, sem tryggir að dýrmæt upplýsingar þínar séu verndaðar gegn ófyrirséðum atburðum. Einbeittu þér að því sem skiptir máli - vexti fyrirtækisins þíns."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Söluupphæð"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("Söluskilyrði"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Söluverð"),
        "saleReports": MessageLookupByLibrary.simpleMessage("Söluskýrslur"),
        "saleReportss": MessageLookupByLibrary.simpleMessage("Sölu skýrslur"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("Sölu skila"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Sölu skila skýrsla"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("Sölu stilling"),
        "sales": MessageLookupByLibrary.simpleMessage("Sölu"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("Sölur & Kaup Skýrslur"),
        "salesList": MessageLookupByLibrary.simpleMessage("Söluskrá"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("Sölu skila"),
        "save": MessageLookupByLibrary.simpleMessage("Vista"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Vista og birta"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("Vista breytingar"),
        "saving": MessageLookupByLibrary.simpleMessage("Vista"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("Skannaðu QR kóða vöru"),
        "search": MessageLookupByLibrary.simpleMessage("Leita"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Leitaðu eftir vöru kóða eða nafni"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("Sjá öll tilboðskóða"),
        "select": MessageLookupByLibrary.simpleMessage("Velja"),
        "selectAProductForReturn":
            MessageLookupByLibrary.simpleMessage("Veldu vöru til að skila"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Veldu vörumerki"),
        "selectCategory": MessageLookupByLibrary.simpleMessage("Veldu flokk"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Veldu tengiliði"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("Veldu vöruflokki"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("Veldu verslunarkafla"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Veldu skatt"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Veldu skattaflokk"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("Veldu einingu"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Veldu afbrigði: "),
        "seller": MessageLookupByLibrary.simpleMessage("Seljandi"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Selja eftir"),
        "send": MessageLookupByLibrary.simpleMessage("Senda"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("Senda tölvupóst"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Senda skilaboð"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("Senda endurstillingartengil"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Senda SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Senda SMS?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Senda WhatsApp skilaboð"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Senda tölvupóstinn þinn"),
        "sendingEmail":
            MessageLookupByLibrary.simpleMessage("Sending tölvupósts"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Sending skilaboða"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Þjónusta/Sending"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Settu upp prófílinn þinn"),
        "setting": MessageLookupByLibrary.simpleMessage("Stillingar"),
        "share": MessageLookupByLibrary.simpleMessage("Deila"),
        "shopGST": MessageLookupByLibrary.simpleMessage("Verslunar GST"),
        "signIn": MessageLookupByLibrary.simpleMessage("Skráðu þig inn"),
        "signInWithEmail": MessageLookupByLibrary.simpleMessage(
            "Skráðu þig inn með tölvupósti"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Undirskrift viðskiptavinar"),
        "size": MessageLookupByLibrary.simpleMessage("Stærð"),
        "skip": MessageLookupByLibrary.simpleMessage("Sleppa"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Samfélagsmarkaðssetning"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Fyrirgefðu, þú hefur ekki heimild til að nálgast þessa þjónustu"),
        "startDate": MessageLookupByLibrary.simpleMessage("Upphafsdagur"),
        "startNewSale": MessageLookupByLibrary.simpleMessage("Byrja nýja sölu"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage(
            "Byrjaðu að skrifa til að leita"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Vertu í fararbroddi tækniframfara án aukakostnaðar. Ótakmarkað uppfærslur á Pos Saas POS tryggja að þú hafir alltaf nýjustu verkfæri og eiginleika í höndum þínum, sem tryggir að fyrirtækið þitt haldist á undan."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("Enn ógreitt"),
        "stock": MessageLookupByLibrary.simpleMessage("Birgðir"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Birgðir eru nauðsynlegar"),
        "stockList": MessageLookupByLibrary.simpleMessage("Birgðaskrá"),
        "stocks": MessageLookupByLibrary.simpleMessage("Vöruverð"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Geymsluréttindi eru nauðsynleg til að búa til Excel skrá"),
        "subTaxList":
            MessageLookupByLibrary.simpleMessage("Listi yfir undirskatta"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Undirskattur"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Afgreidd heild"),
        "submit": MessageLookupByLibrary.simpleMessage("Senda"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "Skráðu þig í okkar\\nYouTube"),
        "subscription": MessageLookupByLibrary.simpleMessage("Aðild"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Lokið með góðum árangri"),
        "successfullyLoggedOut": MessageLookupByLibrary.simpleMessage(
            "Skráðu þig út með góðum árangri"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Uppfærsla tókst"),
        "supplier": MessageLookupByLibrary.simpleMessage("Birgir"),
        "supplierName": MessageLookupByLibrary.simpleMessage("Fyrirtækisheiti"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT Kóði"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Taktu ljósmynd af ökuskírteini, þjóðarauðkennisvottorði eða vegabréfi"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "Taktu þjóðarauðkennisvottorð til að athuga upplýsingar þínar"),
        "tap": MessageLookupByLibrary.simpleMessage("Snerta"),
        "tax": MessageLookupByLibrary.simpleMessage("Skattur"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Skattahópur"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("Skattprósenta"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Skattprósenta"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Skattprósentur - Stjórnaðu skattprósentum þínum"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Skattaskýrsla"),
        "taxType": MessageLookupByLibrary.simpleMessage("Skattaflokk"),
        "taxes": MessageLookupByLibrary.simpleMessage("Skattar"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Skilmálar og skilyrði"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("Notkunarskilmálar"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Skilmálar & Persónuvernd"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Takk fyrir að greiða skuldirnar"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Takk fyrir"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Takk fyrir kaup"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "Reikningurinn er nú þegar til fyrir þessa tölvupóst"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Excel skráin hefur þegar verið niðurhalað"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Nafnið segir allt. Með Pos Saas POS Unlimited er engin takmörkun á notkun þinni. Hvort sem þú ert að vinna með nokkur skipti eða að upplifa skyndilega fjölgun viðskiptavina, geturðu starfað með sjálfstraust, vitandi að þú ert ekki takmarkaður af skilyrðum."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "Lykilorðið sem gefið var er of veikt"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Sala verður eytt og öll gögn um þessa kaup verða eytt. Eruð þið viss um að eyða þessu?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Sala verður eytt og öll gögn um þessa sölu verða eytt. Eruð þið viss um að eyða þessu?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Notandinn verður eytt og öll gögn verða fjarlægð úr reikningnum þínum. Eru þú viss um að þú viljir eyða þessu?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Notandinn verður eytt og öll gögn verða eytt úr reikningnum þínum. Eruð þú viss um að eyða þessu?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Þjónusta þriðja aðila"),
        "thisCategoryCannotBeDeleted":
            MessageLookupByLibrary.simpleMessage("Þessi flokkur má ekki eyða"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Þessi mánuður)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Þessi vara er nú þegar bætt við"),
        "title": MessageLookupByLibrary.simpleMessage("Titill"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Titill má ekki vera tómt"),
        "to": MessageLookupByLibrary.simpleMessage("til"),
        "toDate": MessageLookupByLibrary.simpleMessage("Til dagsetningar"),
        "today": MessageLookupByLibrary.simpleMessage("Í dag"),
        "total": MessageLookupByLibrary.simpleMessage("Heild"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Heildarupphæð"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Heildar safnað"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Heildarskylda"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("Heildarútgjöld"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Heildartap"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("Heildarfjárhæð til greiðslu"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Heildarverð"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("Heildarfjöldi vara"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Heildargróði"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("Heildarkaup"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Heild skila upphæð"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("Heildar skila"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Heildarsala"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Heildar birgðir"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Heildargildi"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Heildar VSK"),
        "totals": MessageLookupByLibrary.simpleMessage("Heild: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Transaksjón"),
        "transactionId":
            MessageLookupByLibrary.simpleMessage("Transaksjón númer"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Reyndu aftur"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Tegund"),
        "unitName": MessageLookupByLibrary.simpleMessage("Nafn einingar"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Verð á einingu"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Einingarverð"),
        "units": MessageLookupByLibrary.simpleMessage("Einingar"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Ótakmarkað"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Ótakmarkað notkun"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Opnaðu alla möguleika Pos Saas POS með persónulegum þjálfunarspjöllum sem stjórnað er af okkar sérfræðingateymi. Frá grunnhugmyndum til framhalds tækni, tryggjum við að þú sért vel kynntur í að nýta hverja hlið kerfisins til að hámarka aðgerðir fyrirtækisins þíns."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Ógreitt"),
        "update": MessageLookupByLibrary.simpleMessage("Uppfæra"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Uppfæra tengilið"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Uppfæra núna"),
        "updateProduct": MessageLookupByLibrary.simpleMessage("Uppfæra vöru"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Uppfærðu áætlunina þína fyrst,\\n takmörkin þín eru yfir"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Uppfæra prófílinn þinn"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Uppfærðu prófílinn þinn til að tengjast lækninum þínum með betri áhrifum"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Uppfærðu prófílinn þinn til að tengja betur við viðskiptavini"),
        "updated": MessageLookupByLibrary.simpleMessage("Uppfært"),
        "upload": MessageLookupByLibrary.simpleMessage("Hlaða upp"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Hlaða upp skjali"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("Upphlaða lokið"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Hlaða upp skrá"),
        "upplier": MessageLookupByLibrary.simpleMessage("Birgir"),
        "usbC": MessageLookupByLibrary.simpleMessage("Usb C"),
        "use": MessageLookupByLibrary.simpleMessage("Nota"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("Notaðu POS SaaS"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Notkun kerfisins"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Notandi er eytt"),
        "userRole": MessageLookupByLibrary.simpleMessage("Notendahlutverk"),
        "userRoleDetails": MessageLookupByLibrary.simpleMessage(
            "Upplýsingar um notendahlutverk"),
        "userTitle": MessageLookupByLibrary.simpleMessage("Notandatitill"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Notendanafnið má ekki vera tómt"),
        "value": MessageLookupByLibrary.simpleMessage("Gildi"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("VSK á við ekki"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("Staðfestir OTP"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Staðfestu símanúmer"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Skoða allt"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("Skoða nánar"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Gengur inn viðskiptavinur"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Vörugeymsla"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Vörugeymsla er nú þegar til"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("Vörugeymslulif"),
        "warehouseName":
            MessageLookupByLibrary.simpleMessage("Nafn vörugeymslu"),
        "warranty": MessageLookupByLibrary.simpleMessage("Ábyrgð"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Við höfum sent tölvupóst með leiðbeiningum um hvernig á að endurstilla lykilorð á:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Við gætum notað þjónustu þriðja aðila til að styðja virkni forritsins okkar, svo sem greiningaraðila og greiðslugjafa. Þessar þjónustu þriðja aðila gætu safnað upplýsingum um þig þegar þú notar forritið okkar. Vinsamlegast athugaðu að við berum ekki ábyrgð á persónuverndarvenjum þessara þjónustu þriðja aðila."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Við tökum iðnaðarstaðla að sér til að vernda persónuupplýsingar þínar, þar á meðal dulkóðun og örugga geymslu. Við takmörkum einnig aðgang að upplýsingum þínum við heimilaða starfsmenn einungis."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Við skiljum mikilvægi óslítandi aðgerða. Þess vegna er stuðningur okkar dyggaður allan sólarhringinn til að aðstoða þig, hvort sem það er fljótur fyrirspurn eða heildræn áhyggjur. Tengdu við okkur hvenær sem er, hvar sem er í gegnum síma eða WhatsApp til að upplifa óviðjafnanlegan þjónustu."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Við notum persónuupplýsingar þínar til að veita þér bestu mögulegu reynsluna á forritinu okkar, þar á meðal til að sérsníða efnisleiðbeiningar, tengja þig við sérfræðinga og bæta virkni forrita okkar. Við gætum einnig notað upplýsingarnar þínar til að hafa samband við þig um uppfærslur, kynningar eða aðrar upplýsingar tengdar forritinu okkar."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Við munum skoða greiðsluna & samþykkja það innan 1-2 klukkustunda"),
        "weekly": MessageLookupByLibrary.simpleMessage("Vikulega"),
        "weight": MessageLookupByLibrary.simpleMessage("Vigt"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Hvað er nýtt"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Heildsali"),
        "wholeSalePrice": MessageLookupByLibrary.simpleMessage("Heildsöluverð"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("Heildsöluverð"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Heildsali"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Verður bætt við fljótlega"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Rennur út á"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Skrifaðu skilaboðin þín hér"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("Rangt OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Rangt lykilorð gefið fyrir þann notanda."),
        "yearly": MessageLookupByLibrary.simpleMessage("Árlega"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Já, eyða að eilífu"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("Þú ert ekki gildur notandi"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Þú ert að nota"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Þú getur ekki greitt meira en skylt"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Þú hefur fengið tölvupóst"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Þú hefur skráð þig inn á reikninginn þinn. Vertu hjá Pos Saas."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("Þú verður að veita heimild"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Þú verður að skrá þig aftur inn á reikninginn þinn."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Þú þarft að staðfesta auðkenni áður en þú kaupir SMS"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Skilaboðin þín eru"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Pakkning þín"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Pakki þinn rennur út eftir 5 daga")
      };
}
