// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a de locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'de';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Fortfahren"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("GST-Nummer"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("UVP"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("UVP ist erforderlich"),
        "OK": MessageLookupByLibrary.simpleMessage("OK"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Tel. Nr."),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT-Code"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Snacks"),
        "TAX": MessageLookupByLibrary.simpleMessage("STEUER"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Hochladen"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("Benutzertitel"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Ihr Paket läuft heute ab\n\nBitte kaufen Sie erneut ein"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) Das System dient ausschließlich dazu, Point of Sale-Transaktionen und damit verbundene Aktivitäten in Ihrem Unternehmen zu erleichtern."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) Um das System zu verwenden, müssen Sie möglicherweise ein Konto erstellen. Sie erklären sich damit einverstanden, genaue, aktuelle und vollständige Informationen während des Registrierungsprozesses bereitzustellen und diese Informationen zu aktualisieren, um sie genau und vollständig zu halten."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("Über die App"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Über uns"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Akzeptanz der Bedingungen"),
        "accountName": MessageLookupByLibrary.simpleMessage("Kontoname"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("Kontonummer"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Kontoanmeldung"),
        "acton": MessageLookupByLibrary.simpleMessage("Aktion"),
        "add": MessageLookupByLibrary.simpleMessage("Hinzufügen"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Marke hinzufügen"),
        "addCategory":
            MessageLookupByLibrary.simpleMessage("Kategorie hinzufügen"),
        "addContact":
            MessageLookupByLibrary.simpleMessage("Kontakt hinzufügen"),
        "addCustomer":
            MessageLookupByLibrary.simpleMessage("Kunden hinzufügen"),
        "addDelivery":
            MessageLookupByLibrary.simpleMessage("Lieferung hinzufügen"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Beschreibung hinzufügen"),
        "addDescription":
            MessageLookupByLibrary.simpleMessage("Notiz hinzufügen"),
        "addDiscount":
            MessageLookupByLibrary.simpleMessage("Rabatt hinzufügen"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Dokument-ID hinzufügen"),
        "addDucument":
            MessageLookupByLibrary.simpleMessage("Dokument hinzufügen"),
        "addExpense":
            MessageLookupByLibrary.simpleMessage("Ausgabe hinzufügen"),
        "addExpenseCategory": MessageLookupByLibrary.simpleMessage(
            "Ausgabenkategorie hinzufügen"),
        "addItems": MessageLookupByLibrary.simpleMessage("Artikel hinzufügen"),
        "addNew": MessageLookupByLibrary.simpleMessage("Neu hinzufügen"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Neue Adresse hinzufügen"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Neues Produkt hinzufügen"),
        "addNewTax":
            MessageLookupByLibrary.simpleMessage("Neue Steuer hinzufügen"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Neue Steuer mit einzelner/mehrerer Steuerart hinzufügen"),
        "addNote": MessageLookupByLibrary.simpleMessage("Notiz hinzufügen"),
        "addProductFirst": MessageLookupByLibrary.simpleMessage(
            "Fügen Sie zuerst ein Produkt hinzu"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Promo-Code hinzufügen"),
        "addPurchase":
            MessageLookupByLibrary.simpleMessage("Einkauf hinzufügen"),
        "addSales": MessageLookupByLibrary.simpleMessage("Verkäufe hinzufügen"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Erfolgreich hinzugefügt"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Einheit hinzufügen"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Benutzerrolle hinzufügen"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Erfolgreich hinzugefügt"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("Zum Warenkorb hinzugefügt"),
        "address": MessageLookupByLibrary.simpleMessage("Adresse"),
        "admin": MessageLookupByLibrary.simpleMessage("Admin"),
        "all": MessageLookupByLibrary.simpleMessage("Alle"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("Alle Geschäftslösungen"),
        "alreadyAdded":
            MessageLookupByLibrary.simpleMessage("Bereits hinzugefügt"),
        "alreadyExists":
            MessageLookupByLibrary.simpleMessage("Existiert bereits"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Haben Sie bereits ein Konto"),
        "amount": MessageLookupByLibrary.simpleMessage("Betrag"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "Eine E-Mail wurde gesendet. Überprüfen Sie Ihr Postfach."),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Unterstützung für Android- und iOS-Apps"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Anwendbare Steuer"),
        "apply": MessageLookupByLibrary.simpleMessage("Anwenden"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Sind Sie sicher, dass Sie diese Rechnung löschen möchten?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Sind Sie sicher, dass Sie diesen Verkauf löschen möchten?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Sind Sie sicher, dass Sie diesen Benutzer löschen möchten?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Sind Sie sicher, dass Sie diese Steuer löschen möchten?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Sind Sie sicher, dass Sie diese Steuergruppe löschen möchten?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Möchten Sie dieses Lager löschen?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Sind Sie sicher, diesen Benutzer zu löschen?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Autorisierte Unterschrift"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Sie sind verantwortlich für die Wahrung der Vertraulichkeit Ihres Kontos und Ihres Passworts sowie für die Beschränkung des Zugriffs auf Ihr Konto. Sie übernehmen die Verantwortung für alle Aktivitäten, die unter Ihrem Konto stattfinden."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Sie müssen mindestens 18 Jahre alt sein oder das gesetzliche Alter der Volljährigkeit in Ihrer Gerichtsbarkeit erreicht haben, um das System zu verwenden."),
        "backSide": MessageLookupByLibrary.simpleMessage("Rückseite"),
        "backToHome":
            MessageLookupByLibrary.simpleMessage("Zurück zur Startseite"),
        "balance": MessageLookupByLibrary.simpleMessage("Saldo"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladesch"),
        "bank": MessageLookupByLibrary.simpleMessage("Bank"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Währung des Bankkontos"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Bankkontowährung"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Bankinformation"),
        "bankName": MessageLookupByLibrary.simpleMessage("Bankname"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("Banküberweisung"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Barcode gefunden"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Rechnung/Beleg"),
        "billTo": MessageLookupByLibrary.simpleMessage("Rechnung an"),
        "branchName": MessageLookupByLibrary.simpleMessage("Zweigstellenname"),
        "brand": MessageLookupByLibrary.simpleMessage("Marke"),
        "brandName": MessageLookupByLibrary.simpleMessage("Markenname"),
        "bulkUpload":
            MessageLookupByLibrary.simpleMessage("Massen-\nHochladen"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Unternehmenskategorie"),
        "buy": MessageLookupByLibrary.simpleMessage("Kaufen"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Premium-Plan kaufen"),
        "buySms": MessageLookupByLibrary.simpleMessage("SMS kaufen"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Durch den Zugriff auf oder die Verwendung des Point of Sale (POS) Systems (das \"System\"), bereitgestellt von [Ihrem Unternehmensnamen] (\"Unternehmen\"), stimmen Sie diesen Nutzungsbedingungen zu. Wenn Sie diesen Nutzungsbedingungen nicht zustimmen, verwenden Sie das System nicht."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Sie sind dafür verantwortlich, sicherzustellen, dass Ihr Zugriff auf das System und dessen Verwendung im Einklang mit allen geltenden Gesetzen und Vorschriften steht."),
        "cacel": MessageLookupByLibrary.simpleMessage("Abbrechen"),
        "call": MessageLookupByLibrary.simpleMessage("Anrufen"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "Rufen Sie an für Notfallunterstützung"),
        "camera": MessageLookupByLibrary.simpleMessage("Kamera"),
        "cancel": MessageLookupByLibrary.simpleMessage("Abbrechen"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Alle Produkte stornieren"),
        "capacity": MessageLookupByLibrary.simpleMessage("Kapazität"),
        "card": MessageLookupByLibrary.simpleMessage("Karte"),
        "cash": MessageLookupByLibrary.simpleMessage("Bargeld"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Kategorien"),
        "category": MessageLookupByLibrary.simpleMessage("Kategorie"),
        "categoryName": MessageLookupByLibrary.simpleMessage("Kategoriename"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "Kategoriename existiert bereits"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("Kategoriename"),
        "change": MessageLookupByLibrary.simpleMessage("Ändern?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Passwort ändern"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("E-Mail prüfen"),
        "choseYourFeature": MessageLookupByLibrary.simpleMessage(
            "Wählen Sie Ihre Funktionen aus"),
        "clarence": MessageLookupByLibrary.simpleMessage("Clarence"),
        "clickToConnect": MessageLookupByLibrary.simpleMessage(
            "Klicken Sie, um sich zu verbinden"),
        "close": MessageLookupByLibrary.simpleMessage("Schließen"),
        "color": MessageLookupByLibrary.simpleMessage("Farbe"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(Kombination mehrerer Steuern)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Kommt bald"),
        "companyAddress": MessageLookupByLibrary.simpleMessage("Firmenadresse"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Firmen- und Geschäftsname"),
        "companyBusinessName": MessageLookupByLibrary.simpleMessage(
            "Unternehmens- & Geschäftsname"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Transaktion abschließen"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Passwort bestätigen"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Rückgabe bestätigen"),
        "congratulations":
            MessageLookupByLibrary.simpleMessage("Herzlichen Glückwunsch"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Kontaktiere uns"),
        "continu": MessageLookupByLibrary.simpleMessage("Weiter"),
        "country": MessageLookupByLibrary.simpleMessage("Land"),
        "create": MessageLookupByLibrary.simpleMessage("Erstellen"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Kostenloses Konto erstellen"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Erstellt und gespeichert"),
        "currency": MessageLookupByLibrary.simpleMessage("Währung"),
        "currentStock":
            MessageLookupByLibrary.simpleMessage("Aktueller Lagerbestand"),
        "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
            "Benutzerdefinierte Rechnungsgestaltung"),
        "customer": MessageLookupByLibrary.simpleMessage("Kunde"),
        "customerDetails": MessageLookupByLibrary.simpleMessage("Kundendaten"),
        "customerGST": MessageLookupByLibrary.simpleMessage("Kunden-GST"),
        "customerName": MessageLookupByLibrary.simpleMessage("Kundenname"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Dashboard-Übersicht"),
        "dataSavedSuccessfully": MessageLookupByLibrary.simpleMessage(
            "Daten erfolgreich gespeichert"),
        "date": MessageLookupByLibrary.simpleMessage("Datum"),
        "day": MessageLookupByLibrary.simpleMessage("Tag"),
        "dealer": MessageLookupByLibrary.simpleMessage("Händler"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("Händlerpreis"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("Standard-Mehrwertsteuersatz"),
        "delete": MessageLookupByLibrary.simpleMessage("Löschen"),
        "deleting": MessageLookupByLibrary.simpleMessage("Löschen"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Lieferadresse"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Lieferadressen"),
        "deliveryCharge": MessageLookupByLibrary.simpleMessage("Liefergebühr"),
        "describtion": MessageLookupByLibrary.simpleMessage("Beschreibung"),
        "description": MessageLookupByLibrary.simpleMessage("Beschreibung"),
        "descriptionCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Beschreibung darf nicht leer sein"),
        "details": MessageLookupByLibrary.simpleMessage("Details"),
        "discount": MessageLookupByLibrary.simpleMessage("Rabatt"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Nicht stören"),
        "done": MessageLookupByLibrary.simpleMessage("Fertig"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Excel-Format herunterladen"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Erfolgreich im Download-Ordner heruntergeladen"),
        "due": MessageLookupByLibrary.simpleMessage("Fällig"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Fälliger Betrag: "),
        "dueCollection":
            MessageLookupByLibrary.simpleMessage("Fällige Sammlung"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("Fällige Inkassoberichte"),
        "dueList": MessageLookupByLibrary.simpleMessage("Fällige Liste"),
        "dueReports":
            MessageLookupByLibrary.simpleMessage("Offene Posten-Bericht"),
        "duration": MessageLookupByLibrary.simpleMessage("Dauer"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Dauer: Von"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "Einfach zu bedienendes mobiles POS-System"),
        "edit": MessageLookupByLibrary.simpleMessage("Bearbeiten"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Einkaufsrechnung bearbeiten"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Verkaufsrechnung bearbeiten"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Soziale Medien bearbeiten"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Erfolgreich bearbeitet"),
        "editTax": MessageLookupByLibrary.simpleMessage("Steuer bearbeiten"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Steuergruppe bearbeiten"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("Lager bearbeiten"),
        "email": MessageLookupByLibrary.simpleMessage("E-Mail"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("E-Mail-Adresse"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("E-Mail darf nicht leer sein"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "E-Mail gesendet! Überprüfen Sie Ihr Postfach"),
        "endDate": MessageLookupByLibrary.simpleMessage("Enddatum"),
        "enterAValidAmount": MessageLookupByLibrary.simpleMessage(
            "Geben Sie einen gültigen Betrag ein"),
        "enterAValidDiscount": MessageLookupByLibrary.simpleMessage(
            "Geben Sie einen gültigen Rabatt ein"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Geben Sie eine gültige Telefonnummer ein"),
        "enterAValidPrice": MessageLookupByLibrary.simpleMessage(
            "Geben Sie einen gültigen Preis ein"),
        "enterAValidQuantity": MessageLookupByLibrary.simpleMessage(
            "Geben Sie eine gültige Menge ein"),
        "enterAddress":
            MessageLookupByLibrary.simpleMessage("Adresse eingeben"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("Betrag eingeben."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Markennamen eingeben"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Kapazität eingeben"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Kategorienamen eingeben"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Farbe eingeben"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "Geben Sie die GST-Nummer des Kunden ein"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Händlerpreis eingeben"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Beschreibung eingeben"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("Rabatt eingeben."),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Ausgabedatum eingeben"),
        "enterFullAddress": MessageLookupByLibrary.simpleMessage(
            "Vollständige Adresse eingeben"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Rechnungsnummer eingeben"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Geben Sie die Menge für die Niedriger Lagerbestand Alarm ein"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Hersteller eingeben"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("Nachrichteninhalt eingeben"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "UVP/Einzelhandelspreis eingeben"),
        "enterName": MessageLookupByLibrary.simpleMessage("Name eingeben"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Notiz eingeben"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Parteinamen eingeben"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Telefonnummer eingeben"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Produktcode eingeben oder scannen"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Produktnamen eingeben"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Einkaufspreis eingeben."),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("Referenznummer eingeben"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Größe eingeben"),
        "enterStocks":
            MessageLookupByLibrary.simpleMessage("Bestände eingeben."),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Steuersatz eingeben"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("Transaktions-ID eingeben"),
        "enterType": MessageLookupByLibrary.simpleMessage("Typ eingeben"),
        "enterUserTitle": MessageLookupByLibrary.simpleMessage(
            "Geben Sie den Benutzertitel ein"),
        "enterValidAmount": MessageLookupByLibrary.simpleMessage(
            "Geben Sie einen gültigen Betrag ein"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Lagername eingeben"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Gewicht eingeben"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Großhandelspreis eingeben"),
        "enterYourDescriptionHere": MessageLookupByLibrary.simpleMessage(
            "Geben Sie hier Ihre Beschreibung ein"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "Geben Sie Ihre E-Mail-Adresse ein"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "Geben Sie den Feedback-Titel ein"),
        "enterYourGSTNumber": MessageLookupByLibrary.simpleMessage(
            "Geben Sie Ihre GST-Nummer ein"),
        "enterYourMobileNumber": MessageLookupByLibrary.simpleMessage(
            "Geben Sie Ihre Mobilnummer ein"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Geben Sie Ihren Namen ein"),
        "enterYourNumber": MessageLookupByLibrary.simpleMessage(
            "Geben Sie Ihre Telefonnummer ein"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Geben Sie Ihr Passwort ein"),
        "enterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Geben Sie Ihre Telefonnummer ein"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "Geben Sie Ihre Transaktions-ID ein"),
        "error": MessageLookupByLibrary.simpleMessage("Fehler"),
        "excTax": MessageLookupByLibrary.simpleMessage("Exkl. Steuer"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("Excel Uploader"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Exklusive"),
        "expense": MessageLookupByLibrary.simpleMessage("Ausgabe"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Ausgabenkategorie"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Ausgabedatum"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Ausgabe für"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Ausgabenbericht"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Ablaufdatum"),
        "expired": MessageLookupByLibrary.simpleMessage("Abgelaufen"),
        "expiring": MessageLookupByLibrary.simpleMessage("Läuft ab"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Fehler aufgetreten"),
        "fashion": MessageLookupByLibrary.simpleMessage("Mode"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Funktionen sind der wichtige Teil, der Pos Saas von traditionellen Lösungen unterscheidet."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Feedback"),
        "firstName": MessageLookupByLibrary.simpleMessage("Vorname"),
        "followUsOnFacebook": MessageLookupByLibrary.simpleMessage(
            "Folgen Sie uns auf\\nFacebook"),
        "followUsOnTwitter": MessageLookupByLibrary.simpleMessage(
            "Folgen Sie uns auf\\nTwitter"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Vorderseite"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("Für unbegrenzte Nutzungen"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Passwort vergessen"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Passwort vergessen?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Von Datum"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("Kostenlose Datensicherung"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "Kostenloses lebenslanges Update"),
        "freePacakge":
            MessageLookupByLibrary.simpleMessage("Kostenloses Paket"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Kostenloser Plan"),
        "from": MessageLookupByLibrary.simpleMessage("(Von"),
        "fullyPaid":
            MessageLookupByLibrary.simpleMessage("Vollständig bezahlt"),
        "gallary": MessageLookupByLibrary.simpleMessage("Galerie"),
        "generatingPDF":
            MessageLookupByLibrary.simpleMessage("PDF wird generiert"),
        "getOtp": MessageLookupByLibrary.simpleMessage("OTP erhalten"),
        "govermentId": MessageLookupByLibrary.simpleMessage("Regierungs-ID"),
        "guest": MessageLookupByLibrary.simpleMessage("Gast"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Noch keinen Account?"),
        "history": MessageLookupByLibrary.simpleMessage("Verlauf"),
        "home": MessageLookupByLibrary.simpleMessage("Startseite"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Wie wir Ihre Informationen schützen"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Wie wir Ihre Informationen verwenden"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Identität überprüfen"),
        "image": MessageLookupByLibrary.simpleMessage("Bild"),
        "inHouseCantBeDelete": MessageLookupByLibrary.simpleMessage(
            "InHouse kann nicht gelöscht werden"),
        "inHouseCantBeEdited": MessageLookupByLibrary.simpleMessage(
            "InHouse kann nicht bearbeitet werden"),
        "inWord": MessageLookupByLibrary.simpleMessage("In Worten"),
        "incTax": MessageLookupByLibrary.simpleMessage("Inkl. Steuer"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Inklusive"),
        "increaseStock":
            MessageLookupByLibrary.simpleMessage("Bestand erhöhen"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Instrument"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Rechnungs-Nr."),
        "invoice": MessageLookupByLibrary.simpleMessage("Rechnung"),
        "invoiceNumber":
            MessageLookupByLibrary.simpleMessage("Rechnungsnummer"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Rechnungseinstellung"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Rechnungsanzeige"),
        "itemAdded":
            MessageLookupByLibrary.simpleMessage("Artikel hinzugefügt"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("KYC-Verifizierung"),
        "language": MessageLookupByLibrary.simpleMessage("Sprache"),
        "lastName": MessageLookupByLibrary.simpleMessage("Nachname"),
        "ledger": MessageLookupByLibrary.simpleMessage("Buchhaltung"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Lebenslanger Kauf"),
        "link": MessageLookupByLibrary.simpleMessage("Link"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Live-Chat-Unterstützung"),
        "loading": MessageLookupByLibrary.simpleMessage("Lädt"),
        "logIn": MessageLookupByLibrary.simpleMessage("Anmelden"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Abmelden"),
        "logOut": MessageLookupByLibrary.simpleMessage("Abmelden"),
        "login": MessageLookupByLibrary.simpleMessage("Einloggen"),
        "logo": MessageLookupByLibrary.simpleMessage("Logo"),
        "loss": MessageLookupByLibrary.simpleMessage("Verlust"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Verlust/Gewinn"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Verlust/Gewinn-Details"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Verlust-/Gewinnbericht"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Verlust-/Gewinnberichte"),
        "lowStockAlert": MessageLookupByLibrary.simpleMessage(
            "Niedriger Lagerbestand Alarm"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Hinterlassen Sie einen bleibenden Eindruck bei Ihren Kunden mit gebrandeten Rechnungen. Unser Unlimited Upgrade bietet den einzigartigen Vorteil der Anpassung Ihrer Rechnungen und verleiht ihnen einen professionellen Touch, der Ihre Markenidentität stärkt und die Kundentreue fördert."),
        "manageYourBussinessWith": MessageLookupByLibrary.simpleMessage(
            "Verwalten Sie Ihr Geschäft mit"),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Herstellungsdatum"),
        "margin": MessageLookupByLibrary.simpleMessage("Marge"),
        "masterCard": MessageLookupByLibrary.simpleMessage("Mastercard"),
        "message": MessageLookupByLibrary.simpleMessage("Nachricht"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Nachrichtenverlauf"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Die Pos Saas-App ist kostenlos und einfach zu bedienen. Tatsächlich handelt es sich um eines der besten POS-Systeme weltweit."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas ist eine vollständige Geschäftslösung mit Lagerbestand, Konten, Verkauf, Ausgaben und Gewinn/Verlust."),
        "mobile": MessageLookupByLibrary.simpleMessage("Mobil"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("Mobile Zahlung"),
        "monthly": MessageLookupByLibrary.simpleMessage("Monatlich"),
        "moreInfo":
            MessageLookupByLibrary.simpleMessage("Weitere Informationen"),
        "name":
            MessageLookupByLibrary.simpleMessage("Geben Sie Ihren Namen ein."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Name existiert bereits"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("Name darf nicht leer sein"),
        "next": MessageLookupByLibrary.simpleMessage("Weiter"),
        "noConnection":
            MessageLookupByLibrary.simpleMessage("Keine Verbindung"),
        "noData": MessageLookupByLibrary.simpleMessage("Keine Daten"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Keine Daten verfügbar"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Keine Daten gefunden"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("Kein Verlauf gefunden!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Kein Produkt gefunden"),
        "noSubTaxSelected": MessageLookupByLibrary.simpleMessage(
            "Keine Untersteuer ausgewählt"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("Keine Transaktion gefunden!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Kein Benutzer mit dieser E-Mail-Adresse gefunden."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "Keine Benutzerrolle gefunden"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Nicht aktiver Benutzer"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Nicht angegeben"),
        "note": MessageLookupByLibrary.simpleMessage("Notiz"),
        "notes": MessageLookupByLibrary.simpleMessage("Notizen"),
        "notification":
            MessageLookupByLibrary.simpleMessage("Benachrichtigung"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP gesendet an"),
        "office": MessageLookupByLibrary.simpleMessage("Büro"),
        "ok": MessageLookupByLibrary.simpleMessage("OK"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS, das eine Vielzahl von Funktionen bietet, einschließlich Verkaufsverfolgung und Lagerverwaltung."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Dieses System hilft Ihnen, Ihre Abläufe für Ihre Kunden zu verbessern."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Unser POS-System sollte die täglichen Betriebsabläufe automatisch vereinfachen und die Navigation erleichtern."),
        "openingBalance": MessageLookupByLibrary.simpleMessage("Anfangssaldo"),
        "order": MessageLookupByLibrary.simpleMessage("Bestellungen"),
        "other": MessageLookupByLibrary.simpleMessage("Sonstiges"),
        "otp": MessageLookupByLibrary.simpleMessage("Schließen"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Nicht vorrätig"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Paket"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Paketfunktionen"),
        "paid": MessageLookupByLibrary.simpleMessage("Bezahlt"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Bezahlter Betrag"),
        "parties": MessageLookupByLibrary.simpleMessage("Parteien"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Parteienliste"),
        "partyGST": MessageLookupByLibrary.simpleMessage("Parteien-GST"),
        "partyName": MessageLookupByLibrary.simpleMessage("Parteiname"),
        "password": MessageLookupByLibrary.simpleMessage("Passwort"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Passwort und Bestätigung stimmen nicht überein"),
        "passwordCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Passwort darf nicht leer sein"),
        "passwordNotMach": MessageLookupByLibrary.simpleMessage(
            "Passwort stimmt nicht überein"),
        "payCash": MessageLookupByLibrary.simpleMessage("Bar bezahlen"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("Mit bKash bezahlen"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Mit Paypal bezahlen"),
        "payeeName": MessageLookupByLibrary.simpleMessage("Empfängername"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("Empfängernummer"),
        "payment": MessageLookupByLibrary.simpleMessage("Zahlung"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("Zahlungsbetrag"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Zahlung abgeschlossen"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Zahlungsanweisung:"),
        "paymentMethod":
            MessageLookupByLibrary.simpleMessage("Zahlungsmethode"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Zahlungsart"),
        "pdfView": MessageLookupByLibrary.simpleMessage("PDF-Ansicht"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Persönliche Informationen"),
        "phone": MessageLookupByLibrary.simpleMessage("Telefon"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Telefonnummer"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Telefonnummer bereits verwendet"),
        "phoneNumberIsNotValid": MessageLookupByLibrary.simpleMessage(
            "Die Telefonnummer ist nicht gültig"),
        "phoneNumberIsRequired": MessageLookupByLibrary.simpleMessage(
            "Telefonnummer ist erforderlich"),
        "pickAndUploadFile": MessageLookupByLibrary.simpleMessage(
            "Datei auswählen und hochladen"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("Enddatum auswählen"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Startdatum auswählen"),
        "plan": MessageLookupByLibrary.simpleMessage("Plan"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("Bitte Menge hinzufügen"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Bitte überprüfen Sie Ihre Internetverbindung"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Bitte verbinden Sie zuerst den Drucker"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Bitte verbinden Sie Ihren Bluetooth-Drucker"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Bitte geben Sie ein längeres Passwort ein"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Bitte geben Sie ein Bestätigungspasswort ein"),
        "pleaseEnterAPassword": MessageLookupByLibrary.simpleMessage(
            "Bitte geben Sie ein Passwort ein"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Bitte geben Sie eine gültige E-Mail-Adresse ein"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Bitte Namen eingeben"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("Bitte Passwort eingeben"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Bitte geben Sie Ihre E-Mail-Adresse unten ein, um den Link zum Zurücksetzen des Passworts zu erhalten."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Bitte Transaktionsnummer eingeben"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("Bitte Betrag eingeben"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Bitte wählen Sie zuerst eine Kategorie aus"),
        "pleaseSelectAPlan": MessageLookupByLibrary.simpleMessage(
            "Bitte wählen Sie einen Plan aus"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Bitte wählen Sie die Geschäftskategorie aus"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Bitte verwenden Sie den gültigen Kaufcode, um die App zu nutzen"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Powered By Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Bereitgestellt von"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Premium-Kundensupport"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Premium-Plan"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Vorherige Zahlungsbeträge"),
        "price": MessageLookupByLibrary.simpleMessage("Preis"),
        "print": MessageLookupByLibrary.simpleMessage("Drucken"),
        "printingOption": MessageLookupByLibrary.simpleMessage("Druckoption"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Datenschutzrichtlinie"),
        "product": MessageLookupByLibrary.simpleMessage("Produkt"),
        "productCode": MessageLookupByLibrary.simpleMessage("Produktcode"),
        "productCodeIsRequired": MessageLookupByLibrary.simpleMessage(
            "Produktcode ist erforderlich"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Produktcode/Name"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Produktbeschreibung"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Produktdetails"),
        "productList": MessageLookupByLibrary.simpleMessage("Produktliste"),
        "productName": MessageLookupByLibrary.simpleMessage("Produktname"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Produktname existiert bereits in diesem Lager"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Produktname ist bereits hinzugefügt"),
        "productNameIsRequired": MessageLookupByLibrary.simpleMessage(
            "Produktname ist erforderlich"),
        "products": MessageLookupByLibrary.simpleMessage("Produkte"),
        "profile": MessageLookupByLibrary.simpleMessage("Profil"),
        "profileEdit":
            MessageLookupByLibrary.simpleMessage("Profil bearbeiten"),
        "profit": MessageLookupByLibrary.simpleMessage("Gewinn"),
        "promo": MessageLookupByLibrary.simpleMessage("Werbung"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Aktionscode"),
        "purchase": MessageLookupByLibrary.simpleMessage("Einkauf"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage("Kaufalarm"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Kauf bestätigt"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Einkaufsdetails"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Einkaufsrechnung"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("Einkaufsliste"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Jetzt kaufen"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Premium-Plan kaufen"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("Einkaufspreis"),
        "purchasePriceIsRequired": MessageLookupByLibrary.simpleMessage(
            "Einkaufspreis ist erforderlich"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Einkaufsberichte"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Einkaufsberichte"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("Rückgabe kaufen"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("Rückgabe Bericht"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Kaufübergang"),
        "qty": MessageLookupByLibrary.simpleMessage("Menge"),
        "quantity": MessageLookupByLibrary.simpleMessage("Menge"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Letzte Transaktionen"),
        "recivedThePin": MessageLookupByLibrary.simpleMessage("PIN erhalten"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Referenznummer"),
        "register": MessageLookupByLibrary.simpleMessage("Registrieren"),
        "registering": MessageLookupByLibrary.simpleMessage("Registrieren"),
        "remainingDue":
            MessageLookupByLibrary.simpleMessage("Verbleibender Betrag fällig"),
        "remove": MessageLookupByLibrary.simpleMessage("Entfernen"),
        "reports": MessageLookupByLibrary.simpleMessage("Berichte"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Anfrage wurde gesendet"),
        "resendCode":
            MessageLookupByLibrary.simpleMessage("Code erneut senden"),
        "resendOtp":
            MessageLookupByLibrary.simpleMessage("OTP erneut senden: "),
        "retailer": MessageLookupByLibrary.simpleMessage("Einzelhändler"),
        "retur": MessageLookupByLibrary.simpleMessage("Rückgabe"),
        "returN": MessageLookupByLibrary.simpleMessage("Rückgabe"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("Rückgabebetrag"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("Rückgabemenge"),
        "revenue": MessageLookupByLibrary.simpleMessage("Einnahmen"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Schützen Sie Ihre Geschäftsdaten mühelos. Unsere Pos Saas POS Unlimited Upgrade enthält eine kostenlose Datensicherung, die Ihre wertvollen Informationen vor unerwarteten Ereignissen schützt. Konzentrieren Sie sich auf das, was wirklich wichtig ist - das Wachstum Ihres Unternehmens."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Verkaufsbetrag"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("Verkaufsdetails"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Verkaufspreis"),
        "saleReports": MessageLookupByLibrary.simpleMessage("Verkaufsbericht"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Verkaufsberichte"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("Verkaufsrückgabe"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Verkaufsrückgabebereicht"),
        "saleSetting":
            MessageLookupByLibrary.simpleMessage("Verkaufseinstellungen"),
        "sales": MessageLookupByLibrary.simpleMessage("Verkäufe"),
        "salesAndPurchaseReports": MessageLookupByLibrary.simpleMessage(
            "Verkaufs- und Einkaufsberichte"),
        "salesList": MessageLookupByLibrary.simpleMessage("Verkaufsliste"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("Verkaufsrückgabe"),
        "save": MessageLookupByLibrary.simpleMessage("Speichern"),
        "saveAndPublish": MessageLookupByLibrary.simpleMessage(
            "Speichern und veröffentlichen"),
        "saveChanges":
            MessageLookupByLibrary.simpleMessage("Änderungen speichern"),
        "saving": MessageLookupByLibrary.simpleMessage("Speichern"),
        "scanProductQRCode": MessageLookupByLibrary.simpleMessage(
            "Scannen Sie den Produkt-QR-Code"),
        "search": MessageLookupByLibrary.simpleMessage("Suche"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Suche nach Produktcode oder Name"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("Alle Aktionscodes anzeigen"),
        "select": MessageLookupByLibrary.simpleMessage("Auswählen"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Wählen Sie ein Produkt zur Rückgabe aus"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Marke auswählen"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Kategorie auswählen"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Kontakte auswählen"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("Produktkategorie auswählen"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("Shop-Kategorie auswählen"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Steuer auswählen"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Steuerart auswählen"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("Einheit auswählen"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Variante auswählen:"),
        "seller": MessageLookupByLibrary.simpleMessage("Verkäufer"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Verkauft von"),
        "send": MessageLookupByLibrary.simpleMessage("Senden"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("E-Mail senden"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Nachricht senden"),
        "sendResetLink": MessageLookupByLibrary.simpleMessage(
            "Link zum Zurücksetzen senden"),
        "sendSms": MessageLookupByLibrary.simpleMessage("SMS senden"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Sms senden?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("WhatsApp-Nachricht senden"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Ihre E-Mail senden"),
        "sendingEmail":
            MessageLookupByLibrary.simpleMessage("E-Mail wird gesendet"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Nachricht wird gesendet"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Service/Versand"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Profil einrichten"),
        "setting": MessageLookupByLibrary.simpleMessage("Einstellungen"),
        "share": MessageLookupByLibrary.simpleMessage("Teilen"),
        "shopGST": MessageLookupByLibrary.simpleMessage("Shop GST"),
        "signIn": MessageLookupByLibrary.simpleMessage("Anmelden"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("Mit E-Mail anmelden"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Unterschrift des Kunden"),
        "size": MessageLookupByLibrary.simpleMessage("Größe"),
        "skip": MessageLookupByLibrary.simpleMessage("Überspringen"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Sozialmarketing"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Es tut uns leid, Sie haben keine Berechtigung, auf diesen Dienst zuzugreifen"),
        "startDate": MessageLookupByLibrary.simpleMessage("Startdatum"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Neuen Verkauf starten"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage(
            "Beginnen Sie mit der Eingabe für die Suche"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Bleiben Sie an der Spitze der technologischen Fortschritte ohne zusätzliche Kosten. Unsere Pos Saas POS Unlimited Upgrade stellt sicher, dass Sie immer die neuesten Werkzeuge und Funktionen zur Hand haben und garantiert, dass Ihr Unternehmen auf dem neuesten Stand bleibt."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("Noch unbezahlte"),
        "stock": MessageLookupByLibrary.simpleMessage("Lager"),
        "stockIsRequired": MessageLookupByLibrary.simpleMessage(
            "Lagerbestand ist erforderlich"),
        "stockList": MessageLookupByLibrary.simpleMessage("Warenliste"),
        "stocks": MessageLookupByLibrary.simpleMessage("Bestände"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Speichermedium Berechtigung ist erforderlich, um eine Excel-Datei zu erstellen"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("Untersteuerliste"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Untersteuern"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Zwischensumme"),
        "submit": MessageLookupByLibrary.simpleMessage("Senden"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "Abonnieren Sie unseren\\nYoutube-Kanal"),
        "subscription": MessageLookupByLibrary.simpleMessage("Abonnement"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Erfolgreich abgeschlossen"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Erfolgreich abgemeldet"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Erfolgreich aktualisiert"),
        "supplier": MessageLookupByLibrary.simpleMessage("Lieferant"),
        "supplierName": MessageLookupByLibrary.simpleMessage("Lieferantenname"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT-Code"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Nehmen Sie einen Führerschein, Personalausweis oder Reisepass-Foto"),
        "takeaNidCardToCheckYourInformation": MessageLookupByLibrary.simpleMessage(
            "Nehmen Sie einen Personalausweis, um Ihre Informationen zu überprüfen"),
        "tap": MessageLookupByLibrary.simpleMessage("Tippen"),
        "tax": MessageLookupByLibrary.simpleMessage("Steuer"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Steuergruppe"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("Steuersatz"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Steuersatz"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Steuersätze - Verwalten Sie Ihre Steuersätze"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Steuerbericht"),
        "taxType": MessageLookupByLibrary.simpleMessage("Steuerart"),
        "taxes": MessageLookupByLibrary.simpleMessage("Steuern"),
        "termsAndConditions": MessageLookupByLibrary.simpleMessage(
            "Allgemeine Geschäftsbedingungen"),
        "termsOfUse":
            MessageLookupByLibrary.simpleMessage("Nutzungsbedingungen"),
        "termsPrivacy": MessageLookupByLibrary.simpleMessage(
            "Allgemeine Geschäftsbedingungen & Datenschutz"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Vielen Dank für Ihre fällige Zahlung"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Vielen Dank"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Vielen Dank für Ihren Kauf"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "Das Konto existiert bereits für diese E-Mail"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Die Excel-Datei wurde bereits heruntergeladen"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Der Name sagt alles. Mit Pos Saas POS Unlimited gibt es keine Begrenzung Ihrer Nutzung. Egal, ob Sie nur eine Handvoll Transaktionen bearbeiten oder einen Ansturm von Kunden erleben, Sie können mit Vertrauen arbeiten und wissen, dass Sie nicht durch Grenzen eingeschränkt sind."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "Das angegebene Passwort ist zu schwach"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Der Verkauf wird gelöscht und alle Daten zu diesem Kauf werden gelöscht. Sind Sie sicher, dass Sie dies löschen möchten?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Der Verkauf wird gelöscht und alle Daten zu diesem Verkauf werden gelöscht. Sind Sie sicher, dass Sie dies löschen möchten?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Der Benutzer wird gelöscht und alle Daten werden aus Ihrem Konto gelöscht. Sind Sie sicher, dass Sie dies löschen möchten?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Der Benutzer wird gelöscht und alle Daten werden aus Ihrem Konto gelöscht. Sind Sie sicher, dass Sie das löschen möchten?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Drittanbieterdienste"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Diese Kategorie kann nicht gelöscht werden"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Diesen Monat)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Dieses Produkt wurde bereits hinzugefügt"),
        "title": MessageLookupByLibrary.simpleMessage("Titel"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Titel darf nicht leer sein"),
        "to": MessageLookupByLibrary.simpleMessage("bis"),
        "toDate": MessageLookupByLibrary.simpleMessage("Bis Datum"),
        "today": MessageLookupByLibrary.simpleMessage("Heute"),
        "total": MessageLookupByLibrary.simpleMessage("Gesamt: "),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Gesamtbetrag"),
        "totalCollected": MessageLookupByLibrary.simpleMessage("Gesamtbetrag"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Gesamtbetrag fällig"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("Gesamtausgabe"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Gesamtverlust"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("Gesamtbetrag zu zahlen"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Gesamtpreis"),
        "totalProducts": MessageLookupByLibrary.simpleMessage("Gesamtprodukte"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Gesamtgewinn"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("Gesamtbetrag"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Gesamtrückgabebetrag"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("Gesamtrückgaben"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Gesamtumsatz"),
        "totalStock":
            MessageLookupByLibrary.simpleMessage("Gesamtlagerbestand"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Gesamtwert"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Gesamtsteuer"),
        "transaction": MessageLookupByLibrary.simpleMessage("Transaktion"),
        "transactionId":
            MessageLookupByLibrary.simpleMessage("Transaktions-ID"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Erneut versuchen"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Typ"),
        "unitName": MessageLookupByLibrary.simpleMessage("Einheitsname"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Stückpreis"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Einzelpreis"),
        "units": MessageLookupByLibrary.simpleMessage("Einheiten"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Unbegrenzt"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Unbegrenzte Nutzung"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Schalten Sie das volle Potenzial von Pos Saas POS mit personalisierten Schulungssitzungen unter der Leitung unseres Expertenteams frei. Von den Grundlagen bis zu fortgeschrittenen Techniken stellen wir sicher, dass Sie gut darin sind, jeden Aspekt des Systems zu nutzen, um Ihre Geschäftsprozesse zu optimieren."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Unbezahlt"),
        "update": MessageLookupByLibrary.simpleMessage("Aktualisieren"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Kontakt aktualisieren"),
        "updateNow":
            MessageLookupByLibrary.simpleMessage("Jetzt aktualisieren"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("Produkt aktualisieren"),
        "updateYourPlanFirstYourLimitIsOver": MessageLookupByLibrary.simpleMessage(
            "Aktualisieren Sie zuerst Ihren Plan,\\nIhr Limit ist überschritten"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Profil aktualisieren"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Aktualisieren Sie Ihr Profil, um eine bessere Verbindung zu Ihrem Arzt herzustellen."),
        "updated": MessageLookupByLibrary.simpleMessage("Aktualisiert"),
        "upload": MessageLookupByLibrary.simpleMessage("Hochladen"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Dokument hochladen"),
        "uploadDone":
            MessageLookupByLibrary.simpleMessage("Hochladen abgeschlossen"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Datei hochladen"),
        "upplier": MessageLookupByLibrary.simpleMessage("Lieferant"),
        "usbC": MessageLookupByLibrary.simpleMessage("USB C"),
        "use": MessageLookupByLibrary.simpleMessage("Verwenden"),
        "useMobiPos":
            MessageLookupByLibrary.simpleMessage("Pos Saas verwenden"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Verwendung des Systems"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Benutzer wurde gelöscht"),
        "userRole": MessageLookupByLibrary.simpleMessage("Benutzerrolle"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("Details zur Benutzerrolle"),
        "userTitle": MessageLookupByLibrary.simpleMessage("Benutzertitel"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Benutzertitel darf nicht leer sein"),
        "value": MessageLookupByLibrary.simpleMessage("Wert"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("USt. gilt nicht"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("OTP überprüfen"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Telefonnummer verifizieren"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Alle anzeigen"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("Details anzeigen"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Kunde ohne Termin"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Lager"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Lager existiert bereits"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("Lagerliste"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("Lagername"),
        "warranty": MessageLookupByLibrary.simpleMessage("Garantie"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Wir haben eine E-Mail mit Anweisungen zum Zurücksetzen des Passworts gesendet an:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Wir können Drittanbieterdienste zur Unterstützung der Funktionalität unserer App verwenden, wie zum Beispiel Analyseanbieter und Zahlungsabwickler. Diese Drittanbieterdienste können Informationen über Sie sammeln, wenn Sie unsere App verwenden. Beachten Sie, dass wir nicht für die Datenschutzpraktiken dieser Drittanbieterdienste verantwortlich sind."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Wir ergreifen branchenübliche Maßnahmen zum Schutz Ihrer persönlichen Informationen, einschließlich Verschlüsselung und sicherer Speicherung. Wir beschränken auch den Zugriff auf Ihre Informationen nur auf autorisiertes Personal."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Wir verstehen die Bedeutung reibungsloser Abläufe. Deshalb steht Ihnen unser rund um die Uhr verfügbarer Support zur Verfügung, sei es für eine schnelle Anfrage oder ein umfassendes Anliegen. Verbinden Sie sich jederzeit und überall mit uns per Anruf oder WhatsApp, um unvergleichlichen Kundenservice zu erleben."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Wir verwenden Ihre persönlichen Informationen, um Ihnen die bestmögliche Erfahrung in unserer App zu bieten, einschließlich der Personalisierung Ihrer Inhaltsempfehlungen, der Verbindung mit Experten und der Verbesserung der Funktionalität unserer App. Wir können Ihre Informationen auch verwenden, um Sie über Aktualisierungen, Promotionen oder andere mit unserer App zusammenhängende Informationen zu informieren."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Wir werden die Zahlung prüfen und innerhalb von 1-2 Stunden genehmigen"),
        "weekly": MessageLookupByLibrary.simpleMessage("Wöchentlich"),
        "weight": MessageLookupByLibrary.simpleMessage("Gewicht"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Neuigkeiten"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Großhändler"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Großhandelspreis"),
        "wholesalePrice":
            MessageLookupByLibrary.simpleMessage("Großhandelspreis"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Großhändler"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Wird bald hinzugefügt"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Läuft ab um"),
        "writeYourMessageHere": MessageLookupByLibrary.simpleMessage(
            "Schreiben Sie hier Ihre Nachricht"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("Falsches OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Falsches Passwort für diesen Benutzer angegeben."),
        "yearly": MessageLookupByLibrary.simpleMessage("Jährlich"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Ja, endgültig löschen"),
        "youAreNotAValidUser": MessageLookupByLibrary.simpleMessage(
            "Sie sind kein gültiger Benutzer"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Sie verwenden"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Sie können nicht mehr als den fälligen Betrag bezahlen"),
        "youHaveGotAnEmail": MessageLookupByLibrary.simpleMessage(
            "Sie haben eine E-Mail erhalten"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Sie haben sich erfolgreich in Ihrem Konto angemeldet. Bleiben Sie bei Pos Saas."),
        "youHaveToGivePermission": MessageLookupByLibrary.simpleMessage(
            "Sie müssen eine Genehmigung erteilen"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Sie müssen sich ERNEUT ANMELDEN in Ihrem Konto."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Sie müssen Ihre Identität überprüfen, bevor Sie kaufen"),
        "yourMessageRemains": MessageLookupByLibrary.simpleMessage(
            "Ihre Nachricht bleibt erhalten"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Ihr Paket"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Ihr Paket läuft in 5 Tagen ab")
      };
}
