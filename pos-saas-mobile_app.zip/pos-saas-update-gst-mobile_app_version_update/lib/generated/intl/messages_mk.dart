// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a mk locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'mk';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Продолжи"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("GST број"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("Препорачаната цена"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("MRP е задолжителен"),
        "OK": MessageLookupByLibrary.simpleMessage("ОК"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Тел. бр."),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("СЛ"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT Код"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Закуски"),
        "TAX": MessageLookupByLibrary.simpleMessage("ДАНОК"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Качување"),
        "UserTitle":
            MessageLookupByLibrary.simpleMessage("Титула на корисникот"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Вашиот пакет истекува денес\n\nВе молиме повторно купете"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(а) Системот е обезбеден исклучиво за целите на олеснување на трансакции на продажба и сродни активности во вашето деловно работење."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(а) За да го користите системот, може да биде потребно да создадете сметка. Согласувате да дадете точни, тековни и целосни информации за време на процесот на регистрација и да ги ажурирате тие информации за да останат точни и целосни."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("За апликацијата"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("За нас"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Прифаќање на условите"),
        "accountName": MessageLookupByLibrary.simpleMessage("Име на сметка"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("Број на сметка"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Регистрација на сметка"),
        "acton": MessageLookupByLibrary.simpleMessage("Дејствувај"),
        "add": MessageLookupByLibrary.simpleMessage("Додај"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Додај бренд"),
        "addCategory": MessageLookupByLibrary.simpleMessage("Додај категорија"),
        "addContact": MessageLookupByLibrary.simpleMessage("Додај контакт"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Додај клиент"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("Додај испорака"),
        "addDescriptioN": MessageLookupByLibrary.simpleMessage("Додај опис"),
        "addDescription": MessageLookupByLibrary.simpleMessage("Додај белешка"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Додадете попуст"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Додај ID на документ"),
        "addDucument": MessageLookupByLibrary.simpleMessage("Додај документ"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Додај расход"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Додај категорија на расход"),
        "addItems": MessageLookupByLibrary.simpleMessage("Додај стоки"),
        "addNew": MessageLookupByLibrary.simpleMessage("Додај ново"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Додај нова адреса"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Додај нов производ"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("Додај нов данок"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Додај нов данок со единечен/помножеен тип на данок"),
        "addNote": MessageLookupByLibrary.simpleMessage("Додај белешка"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Прво додајте производ"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Додадете промо код"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Додај купување"),
        "addSales": MessageLookupByLibrary.simpleMessage("Додадете продажби"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Успешно додадено"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Додај единица"),
        "addUserRole": MessageLookupByLibrary.simpleMessage("Додај улога"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Успешно додадено"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("Додадено во кошничката"),
        "address": MessageLookupByLibrary.simpleMessage("Адреса"),
        "admin": MessageLookupByLibrary.simpleMessage("Администратор"),
        "all": MessageLookupByLibrary.simpleMessage("Сите"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("Сите бизнис решенија"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("Веќе е додадено"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Веќе постои"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Веќе имате сметка"),
        "amount": MessageLookupByLibrary.simpleMessage("Износ"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "Испратена е е-пошта\\nПроверете ја вашата инбокс"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Поддршка за Android и iOS апликации"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Применлив данок"),
        "apply": MessageLookupByLibrary.simpleMessage("Применете"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Дали сте сигурни дека сакате да го избришете овој фатен"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Дали сте сигурни дека сакате да го избришете ова продажба"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Дали сте сигурни дека сакате да го избришете овој корисник?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Дали сте сигурни дека сакате да го избришете овој данок?"),
        "areYouSureWantToDeleteThisTaxGroup": MessageLookupByLibrary.simpleMessage(
            "Дали сте сигурни дека сакате да ја избришете оваа група на данок?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Дали сакате да го избришете ова складиште?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Дали сте сигурни дека сакате да го избришете овој корисник?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Овластен потпис"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(б) Вие сте одговорни за одржување на доверливоста на вашата сметка и лозинка и за ограничување на пристапот до вашата сметка. Прифаќате одговорност за сите активности што се одвиваат под вашата сметка."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(б) Морате да имате најмалку 18 години или легалната возраст на мнозинство во вашата надлежност за да го користите системот."),
        "backSide": MessageLookupByLibrary.simpleMessage("Задна страна"),
        "backToHome": MessageLookupByLibrary.simpleMessage(
            "Врати се на почетната страна"),
        "balance": MessageLookupByLibrary.simpleMessage("Балансирање"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Бангладеш"),
        "bank": MessageLookupByLibrary.simpleMessage("Банка"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Валута на банкарска сметка"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Валута на банкарска сметка"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Информации за банка"),
        "bankName": MessageLookupByLibrary.simpleMessage("Име на банка"),
        "bankTransfer":
            MessageLookupByLibrary.simpleMessage("Банкарски трансфер"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Баркодот е пронајден"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Сметка/Фактура"),
        "billTo": MessageLookupByLibrary.simpleMessage("Сметка за"),
        "branchName": MessageLookupByLibrary.simpleMessage("Име на филијала"),
        "brand": MessageLookupByLibrary.simpleMessage("Бренд"),
        "brandName": MessageLookupByLibrary.simpleMessage("Име на бренд"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("Масовно\nКачување"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Бизнис Категорија"),
        "buy": MessageLookupByLibrary.simpleMessage("Купи"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Купи премиум план"),
        "buySms": MessageLookupByLibrary.simpleMessage("Купи СМС"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Со пристапување или користење на системот за продажба (POS) обезбеден од [Вашето име на компанија] (\"Компанија\"), согласувате да бидете обврзани со овие услови за користење. Ако не се согласувате со овие услови за користење, не користете го системот."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(в) Вие сте одговорни за осигурување дека вашиот пристап до и користење на системот е во согласност со сите применливи закони и регулативи."),
        "cacel": MessageLookupByLibrary.simpleMessage("Откажи"),
        "call": MessageLookupByLibrary.simpleMessage("Повикај"),
        "callForEmergencySupport":
            MessageLookupByLibrary.simpleMessage("Повикајте за итна поддршка"),
        "camera": MessageLookupByLibrary.simpleMessage("Камера"),
        "cancel": MessageLookupByLibrary.simpleMessage("Откажи"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Откажи ги сите производи"),
        "capacity": MessageLookupByLibrary.simpleMessage("Капацитет"),
        "card": MessageLookupByLibrary.simpleMessage("Картичка"),
        "cash": MessageLookupByLibrary.simpleMessage("Готовина"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Категории"),
        "category": MessageLookupByLibrary.simpleMessage("Категорија"),
        "categoryName":
            MessageLookupByLibrary.simpleMessage("Име на категорија"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "Името на категоријата веќе постои"),
        "cateogryName":
            MessageLookupByLibrary.simpleMessage("Име на категорија"),
        "change": MessageLookupByLibrary.simpleMessage("Промена?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Промени ја лозинката"),
        "checkEmail":
            MessageLookupByLibrary.simpleMessage("Проверете ја е-поштата"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Изберете клиент"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Изберете добавувач"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Изберете ги вашите функции"),
        "clarence": MessageLookupByLibrary.simpleMessage("Распродажба"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Кликнете за да се поврзете"),
        "close": MessageLookupByLibrary.simpleMessage("Затвори"),
        "color": MessageLookupByLibrary.simpleMessage("Боја"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(Комбинација на повеќе даноци)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Скоро доаѓа"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Адреса на компанијата"),
        "companyAndShopName": MessageLookupByLibrary.simpleMessage(
            "Име на компанијата и продавницата"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("Име на компанијата и бизнис"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Заврши трансакција"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Потврди лозинка"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Потврди враќање"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Честитки"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Контактирајте не"),
        "continu": MessageLookupByLibrary.simpleMessage("Продолжи"),
        "country": MessageLookupByLibrary.simpleMessage("Држава"),
        "create": MessageLookupByLibrary.simpleMessage("Создај"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Создајте бесплатна сметка"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Создадено и зачувано"),
        "currency": MessageLookupByLibrary.simpleMessage("Валута"),
        "currentStock":
            MessageLookupByLibrary.simpleMessage("Тековен инвентар"),
        "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
            "Персонализирано брендирање на фактури"),
        "customer": MessageLookupByLibrary.simpleMessage("Клиент"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Детали за клиентот"),
        "customerGST": MessageLookupByLibrary.simpleMessage("GST на клиентот"),
        "customerName": MessageLookupByLibrary.simpleMessage("Име на клиентот"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Дневни трансакции"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Преглед на таблото"),
        "dataSavedSuccessfully": MessageLookupByLibrary.simpleMessage(
            "Податоците се успешно зачувани"),
        "date": MessageLookupByLibrary.simpleMessage("Датум"),
        "day": MessageLookupByLibrary.simpleMessage("Ден"),
        "dealer": MessageLookupByLibrary.simpleMessage("Дилер"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("Цена на дилер"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("Стандардна стапка на ДДВ"),
        "delete": MessageLookupByLibrary.simpleMessage("Избриши"),
        "deleting": MessageLookupByLibrary.simpleMessage("Бришење"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Адреса на испорака"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Адреси за испорака"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Такса за достава"),
        "describtion": MessageLookupByLibrary.simpleMessage("Опис"),
        "description": MessageLookupByLibrary.simpleMessage("Опис"),
        "descriptionCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Описот не може да биде празен"),
        "details": MessageLookupByLibrary.simpleMessage("Детали"),
        "discount": MessageLookupByLibrary.simpleMessage("Попуст"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Не вознемирувај"),
        "done": MessageLookupByLibrary.simpleMessage("Завршено"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Преземи Excel формат"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Успешно преземено во папката за преземања"),
        "due": MessageLookupByLibrary.simpleMessage("Долг"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Долг: "),
        "dueCollection":
            MessageLookupByLibrary.simpleMessage("Собирање на долгови"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("Извештаи за наплата"),
        "dueList": MessageLookupByLibrary.simpleMessage("Листа на долгови"),
        "dueReports":
            MessageLookupByLibrary.simpleMessage("Извештај за доспеано"),
        "duration": MessageLookupByLibrary.simpleMessage("Траење"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Траење: Од"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "Лесен за користење мобилен POS"),
        "edit": MessageLookupByLibrary.simpleMessage("Уреди"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Уреди фактура за купување"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Уреди фактура за продажба"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Уреди социјални медиуми"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Успешно изменето"),
        "editTax": MessageLookupByLibrary.simpleMessage("Измени данок"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Измени група на данок"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("Измени складиште"),
        "email": MessageLookupByLibrary.simpleMessage("Е-пошта"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("Е-пошта"),
        "emailCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Е-пошта не може да биде празна"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "E-mail испратен! Проверете ја вашата пошта"),
        "endDate": MessageLookupByLibrary.simpleMessage("Датум на завршување"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Внесете валиден износ"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Внесете валиден попуст"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Внесете валиден број на телефон"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Внесете валидна цена"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("Внесете валидна количина"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("Внесете адреса"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("Внесете износ."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Внесете име на бренд"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Внесете капацитет"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Внесете име на категорија"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Внесете боја"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "Внесете GST број на клиентот"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Внесете цена на дилер"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Внесете опис"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("Внесете попуст."),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Внесете датум на расход"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Внесете целосна адреса"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Внесете број на фактура"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Внесете количина за предупредување за ниски залихи"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Внесете производител"),
        "enterMessageContent": MessageLookupByLibrary.simpleMessage(
            "Внесете содржина на пораката"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "Внесете препорачаната цена/припадничка цена"),
        "enterName": MessageLookupByLibrary.simpleMessage("Внесете име"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Внесете белешка"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Внесете име на партијата"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Внесете број на телефон"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Внесете код на производ или скенирајте"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Внесете име на производ"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Внесете цена на купување."),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("Внесете референтен број"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Внесете големина"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("Внесете залихи."),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Внесете степен на данок"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("Внесете ID на трансакцијата"),
        "enterType": MessageLookupByLibrary.simpleMessage("Внесете тип"),
        "enterUserTitle": MessageLookupByLibrary.simpleMessage(
            "Внесете титула на корисникот"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Внесете валиден износ"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Внесете име на складиште"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Внесете тежина"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Внесете цена на големо"),
        "enterYourDescriptionHere": MessageLookupByLibrary.simpleMessage(
            "Внесете ја вашата опишна информација тука"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("Внесете ја вашата е-пошта"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "Внесете го вашиот наслов на повратна информација"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Внесете го вашиот GST број"),
        "enterYourMobileNumber": MessageLookupByLibrary.simpleMessage(
            "Внесете го вашиот мобилен број"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Внесете го вашето име"),
        "enterYourNumber": MessageLookupByLibrary.simpleMessage(
            "Внесете го вашиот телефонски број"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Внесете ја вашата лозинка"),
        "enterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Внесете го вашиот број на телефон"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "Внесете го вашиот ID на трансакцијата"),
        "error": MessageLookupByLibrary.simpleMessage("Грешка"),
        "excTax": MessageLookupByLibrary.simpleMessage("Искл. данок"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("ExcelUploader"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Исклучително"),
        "expense": MessageLookupByLibrary.simpleMessage("Трошок"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Категорија на расход"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Датум на расход"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Расход за"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Извештај за расход"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Дата на истек"),
        "expired": MessageLookupByLibrary.simpleMessage("Истечен"),
        "expiring": MessageLookupByLibrary.simpleMessage("Истекува"),
        "facebok": MessageLookupByLibrary.simpleMessage("Фејсбук"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Неуспешно со грешка"),
        "fashion": MessageLookupByLibrary.simpleMessage("Мода"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Функциите се важен дел кој го прави POS SaaS различен од традиционалните решенија."),
        "feedBack":
            MessageLookupByLibrary.simpleMessage("Повратна информација"),
        "firstName": MessageLookupByLibrary.simpleMessage("Име"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Следете нè на\\nФејсбук"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Следете нè на\\nТвитер"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Предна страна"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("За неограничена употреба"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Заборавена лозинка"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Заборавена лозинка?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Од датум"),
        "freeDataBackup": MessageLookupByLibrary.simpleMessage(
            "Бесплатно архивирање на податоци"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "Бесплатно ажурирање за цел живот"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Бесплатен пакет"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Бесплатен план"),
        "from": MessageLookupByLibrary.simpleMessage("(Од"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Целосно платено"),
        "gallary": MessageLookupByLibrary.simpleMessage("Галерија"),
        "generatingPDF":
            MessageLookupByLibrary.simpleMessage("Генерирање на PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Добијте OTP"),
        "govermentId": MessageLookupByLibrary.simpleMessage(
            "Државен идентификациски документ"),
        "guest": MessageLookupByLibrary.simpleMessage("Гостин"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Немате сметка?"),
        "history": MessageLookupByLibrary.simpleMessage("Историја"),
        "home": MessageLookupByLibrary.simpleMessage("Дома"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Како ги заштитуваме вашите информации"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Како ги користиме вашите информации"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Верификација на идентитет"),
        "image": MessageLookupByLibrary.simpleMessage("Слика"),
        "inHouseCantBeDelete": MessageLookupByLibrary.simpleMessage(
            "Во куќата не може да се избрише"),
        "inHouseCantBeEdited": MessageLookupByLibrary.simpleMessage(
            "Во куќата не може да се уреди"),
        "inWord": MessageLookupByLibrary.simpleMessage("Во зборови"),
        "incTax": MessageLookupByLibrary.simpleMessage("Вкл. данок"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Вклучително"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("Зголеми залиха"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Инструмент"),
        "instragram": MessageLookupByLibrary.simpleMessage("Инстаграм"),
        "invNo": MessageLookupByLibrary.simpleMessage("Бр. на фактура"),
        "invoice": MessageLookupByLibrary.simpleMessage("Фактура"),
        "invoiceNumber":
            MessageLookupByLibrary.simpleMessage("Број на фактура"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Поставки за фактура"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Прегледувач на фактури"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Стоката е додадена"),
        "kg": MessageLookupByLibrary.simpleMessage("Кг"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("KYC верификација"),
        "language": MessageLookupByLibrary.simpleMessage("Јазик"),
        "lastName": MessageLookupByLibrary.simpleMessage("Презиме"),
        "ledger": MessageLookupByLibrary.simpleMessage("Книги"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Животна\nКуповина"),
        "link": MessageLookupByLibrary.simpleMessage("Линк"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("Линкедин"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Поддршка во живо"),
        "loading": MessageLookupByLibrary.simpleMessage("Loading"),
        "logIn": MessageLookupByLibrary.simpleMessage("Најава"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Излогирај се"),
        "logOut": MessageLookupByLibrary.simpleMessage("Одјави се"),
        "login": MessageLookupByLibrary.simpleMessage("Влезете"),
        "logo": MessageLookupByLibrary.simpleMessage("Лого"),
        "loss": MessageLookupByLibrary.simpleMessage("Губиток"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Губиток/Профит"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Детали за губиток/профит"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Извештај за загуба/добивка"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Извештаи за загуба/добивка"),
        "lowStockAlert": MessageLookupByLibrary.simpleMessage(
            "Предупредување за ниски залихи"),
        "maan": MessageLookupByLibrary.simpleMessage("Ман"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Направете незаборавен впечаток на вашите клиенти со брендирани фактури. Нашиот Неограничен Упдате нуди уникатна предност на персонализирање на вашите фактури, додавајќи професионален печат што го зајакнува вашиот идентитет на брендот и поттикнува лојалност на клиентите."),
        "manageYourBussinessWith": MessageLookupByLibrary.simpleMessage(
            "Управувајте со вашиот бизнис со "),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Дата на производство"),
        "margin": MessageLookupByLibrary.simpleMessage("Маржа"),
        "masterCard": MessageLookupByLibrary.simpleMessage("Мастеркард"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Производител"),
        "message": MessageLookupByLibrary.simpleMessage("Порака"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Историја на пораки"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "POS SaaS апликацијата е бесплатна, лесна за користење. Всушност, тоа е еден од најдобрите POS системи во светот."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "POS SaaS е комплетно бизнис решение со инвентар, сметки, продажба, трошоци и загуба/добивка."),
        "mobile": MessageLookupByLibrary.simpleMessage("Мобилен"),
        "mobilePayment":
            MessageLookupByLibrary.simpleMessage("Мобилно плаќање"),
        "monthly": MessageLookupByLibrary.simpleMessage("Месечно"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("Повеќе информации"),
        "name": MessageLookupByLibrary.simpleMessage("Внесете го вашето име."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Името веќе постои"),
        "nameCantBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Името не може да биде празно"),
        "next": MessageLookupByLibrary.simpleMessage("Следно"),
        "noConnection": MessageLookupByLibrary.simpleMessage("Нема поврзување"),
        "noData": MessageLookupByLibrary.simpleMessage("Нема податоци"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Нема достапни податоци"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Нема пронајдени податоци"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("Нема пронајдена историја!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Нема пронајден производ"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("Нема избрано подданоци"),
        "noTransactionFound": MessageLookupByLibrary.simpleMessage(
            "Нема пронајдена трансакција!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Не е пронајден корисник за таа е-пошта."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "Не е најдена корисничка улога"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Неактивен корисник"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Не е обезбедено"),
        "note": MessageLookupByLibrary.simpleMessage("Белешка"),
        "notes": MessageLookupByLibrary.simpleMessage("Белешки"),
        "notification": MessageLookupByLibrary.simpleMessage("Уведување"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP испратен на"),
        "office": MessageLookupByLibrary.simpleMessage("Офис"),
        "ok": MessageLookupByLibrary.simpleMessage("Ок"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS кој содржи многу функционалности, вклучувајќи следење на продажбата, управување со инвентар."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Овој систем ви помага да ги подобрите вашите операции за вашите клиенти."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Нашиот POS систем треба да ги поедностави секојдневните операции автоматски, олеснувајќи го навигацијата."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("Отворање на салдо"),
        "order": MessageLookupByLibrary.simpleMessage("Нарачки"),
        "other": MessageLookupByLibrary.simpleMessage("Друго"),
        "otp": MessageLookupByLibrary.simpleMessage("Затвори"),
        "outOfStock":
            MessageLookupByLibrary.simpleMessage("Недостиг на залихи"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Пакет"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Карактеристики на пакетот"),
        "paid": MessageLookupByLibrary.simpleMessage("Платено"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Платен износ"),
        "parties": MessageLookupByLibrary.simpleMessage("Страни"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Список на партии"),
        "partyGST": MessageLookupByLibrary.simpleMessage("GST на страна"),
        "partyName": MessageLookupByLibrary.simpleMessage("Име на партијата"),
        "password": MessageLookupByLibrary.simpleMessage("Лозинка"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Лозинката и потврдата на лозинката не се совпаѓаат"),
        "passwordCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Лозинка не може да биде празна"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("Лозинката не се совпаѓа"),
        "payCash": MessageLookupByLibrary.simpleMessage("Плаќање во готово"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash": MessageLookupByLibrary.simpleMessage("Плати со Bkash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Плати со Paypal"),
        "payeeName": MessageLookupByLibrary.simpleMessage("Име на примачот"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("Број на примачот"),
        "payment": MessageLookupByLibrary.simpleMessage("Плаќање"),
        "paymentAmount":
            MessageLookupByLibrary.simpleMessage("Износ на плаќање"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Плаќањето е завршено"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Инструкции за плаќање:"),
        "paymentMethod":
            MessageLookupByLibrary.simpleMessage("Метод на плаќање"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Тип на плаќање"),
        "pdfView": MessageLookupByLibrary.simpleMessage("PDF преглед"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Лични информации"),
        "phone": MessageLookupByLibrary.simpleMessage("Телефон"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Број на телефон"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Бројот на телефон веќе се користи"),
        "phoneNumberIsNotValid": MessageLookupByLibrary.simpleMessage(
            "Бројот на телефон не е валиден"),
        "phoneNumberIsRequired": MessageLookupByLibrary.simpleMessage(
            "Бројот на телефон е потребен"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("Изберете и поставете фајл"),
        "pickEndDate": MessageLookupByLibrary.simpleMessage(
            "Изберете датум на завршување"),
        "pickStartDate": MessageLookupByLibrary.simpleMessage(
            "Изберете датум на започнување"),
        "plan": MessageLookupByLibrary.simpleMessage("План"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("Ве молиме додајте количина"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Ве молиме проверете ја вашата интернет конекција"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Ве молиме прво поврзете ја принтерот"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Ве молиме поврзете го вашиот Bluetooth печатач"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Ве молиме внесете поголема лозинка"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Ве молиме внесете потврдена лозинка"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("Ве молиме внесете лозинка"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Ве молиме внесете валидна е-пошта"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Ве молиме внесете име"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("Ве молиме внесете лозинка"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Ве молиме внесете ја вашата е-пошта подолу за да добиете линк за ресетирање на лозинка."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Ве молиме внесете број на трансакција"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("Ве молиме внесете износ"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Ве молиме прво изберете категорија"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("Ве молиме одберете план"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Ве молиме изберете бизнис категорија"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Ве молиме користете важен код за купување за да ја користите апликацијата"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Поддржано од Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Поддржано од"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Премиум поддршка за клиенти"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Премиум план"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Претходни износи на плаќање"),
        "price": MessageLookupByLibrary.simpleMessage("Цена"),
        "print": MessageLookupByLibrary.simpleMessage("Печати"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Опција за печатење"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Политика за приватност"),
        "product": MessageLookupByLibrary.simpleMessage("Производ"),
        "productCode": MessageLookupByLibrary.simpleMessage("Код на производ"),
        "productCodeIsRequired": MessageLookupByLibrary.simpleMessage(
            "Кодот на производот е потребен"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Код/Име на производот"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Опис на производот"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Детали за производот"),
        "productList":
            MessageLookupByLibrary.simpleMessage("Список на производи"),
        "productName": MessageLookupByLibrary.simpleMessage("Име на производ"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Името на производот веќе постои во овој склад"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Името на производот веќе е додадено"),
        "productNameIsRequired": MessageLookupByLibrary.simpleMessage(
            "Името на производот е потребно"),
        "products": MessageLookupByLibrary.simpleMessage("Производи"),
        "profile": MessageLookupByLibrary.simpleMessage("Профил"),
        "profileEdit":
            MessageLookupByLibrary.simpleMessage("Уредување на профил"),
        "profit": MessageLookupByLibrary.simpleMessage("Профит"),
        "promo": MessageLookupByLibrary.simpleMessage("Промо"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Промо код"),
        "purchase": MessageLookupByLibrary.simpleMessage("Купување"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("Уведување за купување"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Купувањето е потврдено"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Детали за купување"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Фактура за купување"),
        "purchaseList":
            MessageLookupByLibrary.simpleMessage("Листа на купувања"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Купи сега"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Купи премиум план"),
        "purchasePrice":
            MessageLookupByLibrary.simpleMessage("Цена на купување"),
        "purchasePriceIsRequired": MessageLookupByLibrary.simpleMessage(
            "Цената на купување е потребна"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("Извештај за купување"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Цена на купување"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Извештаи за купувања"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("Враќање на купување"),
        "purchaseReturnReport": MessageLookupByLibrary.simpleMessage(
            "Извештај за враќање на купување"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Преход на купување"),
        "qty": MessageLookupByLibrary.simpleMessage("Количина"),
        "quantity": MessageLookupByLibrary.simpleMessage("Количество"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Недавни трансакции"),
        "recivedThePin": MessageLookupByLibrary.simpleMessage("Примивте ПИН"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Референтен број"),
        "register": MessageLookupByLibrary.simpleMessage("Регистрирајте се"),
        "registering": MessageLookupByLibrary.simpleMessage("Регистрирање"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("Останат долг"),
        "remove": MessageLookupByLibrary.simpleMessage("Отстрани"),
        "reports": MessageLookupByLibrary.simpleMessage("Извештаи"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Барањето е испратено"),
        "resendCode":
            MessageLookupByLibrary.simpleMessage("Испрати повторно код"),
        "resendOtp":
            MessageLookupByLibrary.simpleMessage("Испрати повторно OTP:"),
        "retailer": MessageLookupByLibrary.simpleMessage("Реталер"),
        "retur": MessageLookupByLibrary.simpleMessage("Враќање"),
        "returN": MessageLookupByLibrary.simpleMessage("Враќање"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("Вратете сума"),
        "returnAmount":
            MessageLookupByLibrary.simpleMessage("Износ на враќање"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("Куќа за враќање"),
        "revenue": MessageLookupByLibrary.simpleMessage("Приход"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Заштитете ги вашите бизнис податоци без напор. Нашиот Pos Saas POS Неограничен Упдате вклучува бесплатно архивирање на податоци, осигурувајќи дека вашите вредни информации се заштитени од непредвидени настани. Фокусирајте се на она што навистина е важно - растот на вашиот бизнис."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Износ на продажба"),
        "saleDetails":
            MessageLookupByLibrary.simpleMessage("Детали за продажба"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Цена на продажба"),
        "saleReports":
            MessageLookupByLibrary.simpleMessage("Извештај за продажба"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Извештаи за продажби"),
        "saleReturn":
            MessageLookupByLibrary.simpleMessage("Враќање на продажба"),
        "saleReturnReport": MessageLookupByLibrary.simpleMessage(
            "Извештај за враќање на продажба"),
        "saleSetting":
            MessageLookupByLibrary.simpleMessage("Поставување на продажба"),
        "sales": MessageLookupByLibrary.simpleMessage("Продажби"),
        "salesAndPurchaseReports": MessageLookupByLibrary.simpleMessage(
            "Извештаи за продажба и набавка"),
        "salesList": MessageLookupByLibrary.simpleMessage("Листа на продажби"),
        "salesReturn":
            MessageLookupByLibrary.simpleMessage("Враќање на продажба"),
        "save": MessageLookupByLibrary.simpleMessage("Зачувај"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Зачувај и објави"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("Зачувај промени"),
        "saving": MessageLookupByLibrary.simpleMessage("Зачувување"),
        "scanProductQRCode": MessageLookupByLibrary.simpleMessage(
            "Скенирајте го QR кодот на производот"),
        "search": MessageLookupByLibrary.simpleMessage("Пребарај"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Пребарајте по код или име на производот"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("Видете ги сите промо кодови"),
        "select": MessageLookupByLibrary.simpleMessage("Изберете"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Изберете производ за враќање"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Изберете бренд"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Изберете категорија"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Изберете контакти"),
        "selectProductCategory": MessageLookupByLibrary.simpleMessage(
            "Изберете категорија на производи"),
        "selectShopCategory": MessageLookupByLibrary.simpleMessage(
            "Изберете категорија на продавница"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Изберете данок"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Изберете тип на данок"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("Изберете единица"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Изберете варијации: "),
        "seller": MessageLookupByLibrary.simpleMessage("Продавач"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Продава од"),
        "send": MessageLookupByLibrary.simpleMessage("Испрати"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("Испрати е-пошта"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Испрати порака"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("Испрати линк за ресетирање"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Испрати СМС"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Испратете СМС?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Испрати порака на whatsapp"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Испратете го вашиот е-маил"),
        "sendingEmail":
            MessageLookupByLibrary.simpleMessage("Испраќање на e-mail"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Испраќање на порака"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Услуга/Испорака"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Подесете го вашиот профил"),
        "setting": MessageLookupByLibrary.simpleMessage("Поставки"),
        "share": MessageLookupByLibrary.simpleMessage("Сподели"),
        "shopGST": MessageLookupByLibrary.simpleMessage("GST на продавница"),
        "signIn": MessageLookupByLibrary.simpleMessage("Најави се"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("Најави се со е-пошта"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Потпис на клиентот"),
        "size": MessageLookupByLibrary.simpleMessage("Големина"),
        "skip": MessageLookupByLibrary.simpleMessage("Прескокни"),
        "sms": MessageLookupByLibrary.simpleMessage("СМС"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Социјален маркетинг"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Жалиме, немате дозвола за пристап до оваа услуга"),
        "startDate":
            MessageLookupByLibrary.simpleMessage("Датум на започнување"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Започнете нова продажба"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage(
            "Започнете со типкање за да пребарате"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Останете на предниот план на технолошките напредоци без дополнителни трошоци. Нашиот Pos Saas POS Неограничен Упдате обезбедува дека секогаш ги имате најновите алатки и функционалности на дофат на раката, гарантирајќи дека вашето деловно работење останува модерно."),
        "stillUnpaid":
            MessageLookupByLibrary.simpleMessage("Се уште неплатено"),
        "stock": MessageLookupByLibrary.simpleMessage("Залиха"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Залиха е потребна"),
        "stockList": MessageLookupByLibrary.simpleMessage("Листа на залихи"),
        "stocks": MessageLookupByLibrary.simpleMessage("Залихи"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Дозвола за складирање е потребна за создавање на Excel фајл"),
        "subTaxList":
            MessageLookupByLibrary.simpleMessage("Список на подданоци"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Подданоци"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Вкупно без ДДВ"),
        "submit": MessageLookupByLibrary.simpleMessage("Испрати"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "Пријавете се на нашиот\\nЈутјуб"),
        "subscription": MessageLookupByLibrary.simpleMessage("Членство"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Успешно завршено"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Успешно одјавен"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Успешно ажурирано"),
        "supplier": MessageLookupByLibrary.simpleMessage("Добавувач"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("Име на добавувач"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT код"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Земете фотографија од возачка дозвола, национална лична карта или пасош"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "Земете лична карта за да ги проверите вашите информации"),
        "tap": MessageLookupByLibrary.simpleMessage("Допри"),
        "tax": MessageLookupByLibrary.simpleMessage("Данок"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Група на данок"),
        "taxPercentage":
            MessageLookupByLibrary.simpleMessage("Процент на данок"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Степен на данок"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Степени на данок - Управувајте со вашите степени на данок"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Извештај за данок"),
        "taxType": MessageLookupByLibrary.simpleMessage("Тип на данок"),
        "taxes": MessageLookupByLibrary.simpleMessage("Данци"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Услови и одредби"),
        "termsOfUse":
            MessageLookupByLibrary.simpleMessage("Услови за користење"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Услови и приватност"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Ви благодариме за вашето плаќање на долгот"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Ви благодарам"),
        "thankYouForYourPurchase": MessageLookupByLibrary.simpleMessage(
            "Ви благодариме за вашата куповина"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "Сметката веќе постои за таа е-пошта"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Excel фајлот веќе е преземен"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Името вели сè. Со Pos Saas POS Неограничен, нема ограничувања на вашата употреба. Без разлика дали обработувате неколку трансакции или доживувате навала на клиенти, можете да работите со доверба, знаејќи дека не сте ограничени од лимити."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "Лозинката што ја внесовте е премногу слаба"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Продавањето ќе биде избришано и сите податоци за ова купување ќе бидат избришани. Дали сте сигурни дека сакате да го избришете ова"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Продавањето ќе биде избришано и сите податоци за оваа продажба ќе бидат избришани. Дали сте сигурни дека сакате да го избришете ова"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Корисникот ќе биде избришан и сите податоци ќе бидат избришани од вашиот акаунт. Дали сте сигурни дека сакате да избришете?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Корисникот ќе биде избришан и сите податоци ќе бидат избришани од вашиот акаунт. Дали сте сигурни дека сакате да го избришете ова?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Услуги од трети лица"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Оваа категорија не може да се избрише"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Овој месец)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Овој производ веќе е додаден"),
        "title": MessageLookupByLibrary.simpleMessage("Наслов"),
        "titleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Насловот не може да биде празен"),
        "to": MessageLookupByLibrary.simpleMessage("до"),
        "toDate": MessageLookupByLibrary.simpleMessage("До датум"),
        "today": MessageLookupByLibrary.simpleMessage("Денес"),
        "total": MessageLookupByLibrary.simpleMessage("Вкупно"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Вкупен износ"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Вкупно собрано"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Вкупен долг"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("Вкупен расход"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Вкупна загуба"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("Вкупно за плаќање"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Вкупна цена"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("Вкупно производи"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Вкупна добивка"),
        "totalPurchase":
            MessageLookupByLibrary.simpleMessage("Вкупно купување"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Вкупен износ на враќање"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("Вкупно враќања"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Вкупна продажба"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Вкупен инвентар"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Вкупна вредност"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Вкупно ДДВ"),
        "totals": MessageLookupByLibrary.simpleMessage("Вкупно: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Трансакција"),
        "transactionId":
            MessageLookupByLibrary.simpleMessage("ID на трансакцијата"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Обидете се повторно"),
        "twitter": MessageLookupByLibrary.simpleMessage("Твитер"),
        "type": MessageLookupByLibrary.simpleMessage("Тип"),
        "unitName": MessageLookupByLibrary.simpleMessage("Име на единица"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Единична цена"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Цена по единица"),
        "units": MessageLookupByLibrary.simpleMessage("Единици"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Неп ограничен"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Неограничена употреба"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Отклучете го целосниот потенцијал на Pos Saas POS со персонализирани обуки водени од нашиот експертски тим. Од основите до напредни техники, се осигуруваме дека сте добро запознаени со користењето на секој аспект од системот за оптимизирање на вашите деловни процеси."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Неплатено"),
        "update": MessageLookupByLibrary.simpleMessage("Ажурирај"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Ажурирај контакт"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Ажурирај сега"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("Ажурирај производ"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Ажурирајте го вашиот план прво,\\вашата граница е надмината"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Ажурирај го вашиот профил"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Ажурирајте го вашиот профил за да го поврзете вашиот доктор со подобар впечаток"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Ажурирајте го вашиот профил за подобра поврзаност со клиентите"),
        "updated": MessageLookupByLibrary.simpleMessage("Ажурирано"),
        "upload": MessageLookupByLibrary.simpleMessage("Постави"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Прикачете документ"),
        "uploadDone":
            MessageLookupByLibrary.simpleMessage("Поставувањето заврши"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Прикачете фајл"),
        "upplier": MessageLookupByLibrary.simpleMessage("Добавувач"),
        "usbC": MessageLookupByLibrary.simpleMessage("Usb C"),
        "use": MessageLookupByLibrary.simpleMessage("Користи"),
        "useMobiPos":
            MessageLookupByLibrary.simpleMessage("Користете POS SaaS"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Користење на системот"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Корисникот е избришан"),
        "userRole": MessageLookupByLibrary.simpleMessage("Корисничка улога"),
        "userRoleDetails": MessageLookupByLibrary.simpleMessage(
            "Детали за улогата на корисникот"),
        "userTitle":
            MessageLookupByLibrary.simpleMessage("Титула на корисникот"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Насловот на корисникот не може да биде празен"),
        "value": MessageLookupByLibrary.simpleMessage("Вредност"),
        "vatDoesNotApply": MessageLookupByLibrary.simpleMessage("ДДВ не важи"),
        "verifyOtp":
            MessageLookupByLibrary.simpleMessage("Верификување на OTP"),
        "verifyPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Верификување на телефонскиот број"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Прегледајте сè"),
        "viewDetails":
            MessageLookupByLibrary.simpleMessage("Погледнете детали"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Клиент што доаѓа"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Склад"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Складиштето веќе постои"),
        "warehouseList":
            MessageLookupByLibrary.simpleMessage("Листа на складишта"),
        "warehouseName":
            MessageLookupByLibrary.simpleMessage("Име на складиште"),
        "warranty": MessageLookupByLibrary.simpleMessage("Гаранција"),
        "weHaveSendAnEmailwithInstructions":
            MessageLookupByLibrary.simpleMessage(
                "Испративме е-пошта со инструкции за ресетирање на лозинка на:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Можеме да користиме услуги од трети лица за поддршка на функционалноста на нашата апликација, како што се даватели на аналитика и процесори на плаќања. Овие услуги од трети лица можат да собираат информации за вас кога ја користите нашата апликација. Ве молиме запомнете дека не сме одговорни за практиките на приватност на овие услуги од трети лица."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Применуваме мерки за заштита на вашите лични информации во согласност со индустриските стандарди, вклучувајќи шифрирање и безбедно складирање. Исто така, го ограничуваме пристапот до вашите информации само на овластени лица."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Разбираме колку е важно да имате беспрекорни операции. Затоа нашата поддршка е достапна 24/7 за да ви помогне, без разлика дали се работи за брзо прашање или опширен проблем. Поврзете се со нас во било кое време, од било каде, преку повик или WhatsApp за да ја искусите без премецна услуга за клиенти."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Ги користиме вашите лични информации за да ви обезбедиме најдобро возможно искуство на нашата апликација, вклучувајќи ги и персонализираните препораки за содржини, поврзување со експерти и подобрување на функционалноста на нашата апликација. Можеме исто така да ги користиме вашите информации за да комуницираме со вас за ажурирања, промоции или други информации поврзани со нашата апликација."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Ќе ја прегледаме уплатата и ќе ја одобриме во рок од 1-2 часа"),
        "weekly": MessageLookupByLibrary.simpleMessage("Неделно"),
        "weight": MessageLookupByLibrary.simpleMessage("Тежина"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Што е ново"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Големопродажба"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Цена на големо"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("Даночна цена"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("На големо"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Скоро ќе биде додаден"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Ќе истече на"),
        "writeYourMessageHere": MessageLookupByLibrary.simpleMessage(
            "Напишете ја вашата порака тука"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("Неправилен OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Дадена е погрешна лозинка за тој корисник."),
        "yearly": MessageLookupByLibrary.simpleMessage("Годишно"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Да, избриши засекогаш"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("Вие не сте валиден корисник"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Вие користите"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Не можете да платите повеќе од должниот износ"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Добивте е-пошта"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Успешно се најдовте во вашиот акаунт. Останете со Pos Saas."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("Мора да дадете дозвола"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Морате повторно да се најавите на вашата сметка."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Морате да ја верификувате вашата идентичност пред да купите СМС"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Вашата порака останува"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Вашиот пакет"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Вашиот пакет ќе истече за 5 дена")
      };
}
