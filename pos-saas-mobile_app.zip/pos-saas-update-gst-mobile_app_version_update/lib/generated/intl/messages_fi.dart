// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a fi locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'fi';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Jatka"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("GST-numero"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("Myyntihinta"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("MRP on pakollinen"),
        "OK": MessageLookupByLibrary.simpleMessage("OK"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Puhelin nro"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT-koodi"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Välipalat"),
        "TAX": MessageLookupByLibrary.simpleMessage("VERO"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Ladataan"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("Käyttäjänimike"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Pakettisi vanhenee tänään\n\nOsta uudelleen, kiitos"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) Järjestelmä on tarkoitettu ainoastaan myyntipisteen transaktioiden ja niihin liittyvien toimintojen helpottamiseen yrityksessäsi."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) Järjestelmän käyttämiseksi saatetaan edellyttää käyttäjätilin luomista. Hyväksyt antavasi tarkat, ajantasaiset ja täydelliset tiedot rekisteröitymisprosessin aikana ja päivittäväsi kyseiset tiedot pysyäksesi tarkkoina ja täydellisinä."),
        "aboutApp":
            MessageLookupByLibrary.simpleMessage("Tietoja sovelluksesta"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Meistä"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Käyttöehtojen hyväksyminen"),
        "accountName": MessageLookupByLibrary.simpleMessage("Tilin nimi"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("Tilinumero"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Käyttäjätilin rekisteröinti"),
        "acton": MessageLookupByLibrary.simpleMessage("Toimi"),
        "add": MessageLookupByLibrary.simpleMessage("Lisää"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Lisää tuotemerkki"),
        "addCategory": MessageLookupByLibrary.simpleMessage("Lisää kategoria"),
        "addContact": MessageLookupByLibrary.simpleMessage("Lisää yhteystieto"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Lisää asiakas"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("Lisää toimitus"),
        "addDescriptioN": MessageLookupByLibrary.simpleMessage("Lisää kuvaus"),
        "addDescription":
            MessageLookupByLibrary.simpleMessage("Lisää huomautus"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Lisää alennus"),
        "addDocumentId": MessageLookupByLibrary.simpleMessage(
            "Lisää henkilötodistuksen numero"),
        "addDucument": MessageLookupByLibrary.simpleMessage("Lisää asiakirja"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Lisää kuluerä"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Lisää kulukategoria"),
        "addItems": MessageLookupByLibrary.simpleMessage("Lisää tuotteita"),
        "addNew": MessageLookupByLibrary.simpleMessage("Lisää uusi"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Lisää uusi osoite"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Lisää uusi tuote"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("Lisää uusi vero"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Lisää uusi vero yksinkertaisella/moninkertaisella verotyypillä"),
        "addNote": MessageLookupByLibrary.simpleMessage("Lisää huomautus"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Lisää tuote ensin"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Lisää alennuskoodi"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Lisää ostos"),
        "addSales": MessageLookupByLibrary.simpleMessage("Lisää myynti"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Lisätty onnistuneesti"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Lisää yksikkö"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Lisää käyttäjärooli"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Lisätty onnistuneesti"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("Lisätty ostoskoriin"),
        "address": MessageLookupByLibrary.simpleMessage("Osoite"),
        "admin": MessageLookupByLibrary.simpleMessage("Ylläpitäjä"),
        "all": MessageLookupByLibrary.simpleMessage("Kaikki"),
        "allBusinessSolution": MessageLookupByLibrary.simpleMessage(
            "Kaikki liiketoimintaratkaisut"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("On jo lisätty"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("On jo olemassa"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Onko sinulla jo tili?"),
        "amount": MessageLookupByLibrary.simpleMessage("Summa"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "Sähköposti on lähetetty. Tarkista saapuneet"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Tuki Android- ja iOS-sovelluksille"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Sovellettava vero"),
        "apply": MessageLookupByLibrary.simpleMessage("Käytä"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Oletko varma, että haluat poistaa tämän laskun?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Oletko varma, että haluat poistaa tämän myynnin?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Oletko varma, että haluat poistaa tämän käyttäjän?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Haluatko varmasti poistaa tämän veron?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Haluatko varmasti poistaa tämän veroryhmän?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Haluatko varmasti poistaa tämän varaston?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Haluatko varmasti poistaa tämän käyttäjän?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Valtuutetun allekirjoitus"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Sinä olet vastuussa käyttäjätilisi ja salasanasi luottamuksellisuuden ylläpitämisestä sekä käyttöoikeuden rajoittamisesta käyttäjätilillesi. Hyväksyt vastuun kaikista toiminnoista, jotka tapahtuvat käyttäjätilisi alaisuudessa."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Sinun tulee olla vähintään 18 vuotta täyttänyt tai laillisen enemmistöikäinen toimialueesi säännösten mukaan, jotta voit käyttää Järjestelmää."),
        "backSide": MessageLookupByLibrary.simpleMessage("Takapuoli"),
        "backToHome": MessageLookupByLibrary.simpleMessage("Takaisin kotiin"),
        "balance": MessageLookupByLibrary.simpleMessage("Saldo"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladesh"),
        "bank": MessageLookupByLibrary.simpleMessage("Pankki"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Pankkitilin valuutta"),
        "bankInformation": MessageLookupByLibrary.simpleMessage("Pankkitiedot"),
        "bankName": MessageLookupByLibrary.simpleMessage("Pankin nimi"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("Pankkisiirto"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Viivakoodi löydetty"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Lasku"),
        "billTo": MessageLookupByLibrary.simpleMessage("Laskutusosoite"),
        "branchName": MessageLookupByLibrary.simpleMessage("Sivuliikkeen nimi"),
        "brand": MessageLookupByLibrary.simpleMessage("Brändi"),
        "brandName": MessageLookupByLibrary.simpleMessage("Tuotemerkin nimi"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("Massalataus"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Liiketoiminnan kategoria"),
        "buy": MessageLookupByLibrary.simpleMessage("Osta"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Osta Premium-suunnitelma"),
        "buySms": MessageLookupByLibrary.simpleMessage("Osta tekstiviestejä"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Kun käytät myyntipisteen (POS) järjestelmää (\"Järjestelmä\"), joka on tarjottu [Yrityksesi Nimi] (\"Yritys\") toimesta, suostut noudattamaan näitä käyttöehtoja. Jos et hyväksy näitä käyttöehtoja, älä käytä Järjestelmää."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Sinä olet vastuussa siitä, että Järjestelmän käyttösi ja pääsysi siihen noudattavat kaikkia soveltuvia lakeja ja säädöksiä."),
        "cacel": MessageLookupByLibrary.simpleMessage("Peruuta"),
        "call": MessageLookupByLibrary.simpleMessage("Soita"),
        "callForEmergencySupport":
            MessageLookupByLibrary.simpleMessage("Soita hätätukea varten"),
        "camera": MessageLookupByLibrary.simpleMessage("Kamera"),
        "cancel": MessageLookupByLibrary.simpleMessage("Peruuta"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Peruuta kaikki tuotteet"),
        "capacity": MessageLookupByLibrary.simpleMessage("Kapasiteetti"),
        "card": MessageLookupByLibrary.simpleMessage("Kortti"),
        "cash": MessageLookupByLibrary.simpleMessage("Käteinen"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Kategoriat"),
        "category": MessageLookupByLibrary.simpleMessage("Kategoria"),
        "categoryName": MessageLookupByLibrary.simpleMessage("Kategorian nimi"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "Kategorian nimi on jo olemassa"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("Kategorian nimi"),
        "change": MessageLookupByLibrary.simpleMessage("Vaihda?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Vaihda salasana"),
        "checkEmail":
            MessageLookupByLibrary.simpleMessage("Tarkista sähköposti"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Valitse asiakas"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Valitse toimittaja"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Valitse ominaisuutesi"),
        "clarence": MessageLookupByLibrary.simpleMessage("Selvitys"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Yhdistä napsauttamalla"),
        "close": MessageLookupByLibrary.simpleMessage("Sulje"),
        "color": MessageLookupByLibrary.simpleMessage("Väri"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(Useiden verojen yhdistelmä)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Tulossa pian"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Yrityksen osoite"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Yritys- ja kauppanimi"),
        "companyBusinessName": MessageLookupByLibrary.simpleMessage(
            "Yrityksen ja liiketoiminnan nimi"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Täydennä tapahtuma"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Vahvista salasana"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Vahvista palautus"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Onnittelut"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Ota yhteyttä"),
        "continu": MessageLookupByLibrary.simpleMessage("Jatka"),
        "country": MessageLookupByLibrary.simpleMessage("Maa"),
        "create": MessageLookupByLibrary.simpleMessage("Luo"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Luo ilmainen tili"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Luotu ja tallennettu"),
        "currency": MessageLookupByLibrary.simpleMessage("Valuutta"),
        "currentStock":
            MessageLookupByLibrary.simpleMessage("Nykyinen varasto"),
        "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
            "Mukautettu laskutuksen brändäys"),
        "customer": MessageLookupByLibrary.simpleMessage("Asiakas"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Asiakastiedot"),
        "customerGST": MessageLookupByLibrary.simpleMessage("Asiakkaan GST"),
        "customerName": MessageLookupByLibrary.simpleMessage("Asiakkaan nimi"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Päivittäinen tapahtuma"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Kojelautan yleiskatsaus"),
        "dataSavedSuccessfully": MessageLookupByLibrary.simpleMessage(
            "Tiedot tallennettu onnistuneesti"),
        "date": MessageLookupByLibrary.simpleMessage("Päivämäärä"),
        "day": MessageLookupByLibrary.simpleMessage("Päivä"),
        "dealer": MessageLookupByLibrary.simpleMessage("Jälleenmyyjä"),
        "dealerPrice":
            MessageLookupByLibrary.simpleMessage("Jälleenmyyjän hinta"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("Oletus ALV-prosentti"),
        "delete": MessageLookupByLibrary.simpleMessage("Poista"),
        "deleting": MessageLookupByLibrary.simpleMessage("Poistaminen"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Toimitusosoite"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Toimitusosoitteet"),
        "deliveryCharge": MessageLookupByLibrary.simpleMessage("Toimituskulu"),
        "describtion": MessageLookupByLibrary.simpleMessage("Kuvaus"),
        "description": MessageLookupByLibrary.simpleMessage("Kuvaus"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Kuvaus ei voi olla tyhjää"),
        "details": MessageLookupByLibrary.simpleMessage("Tiedot"),
        "discount": MessageLookupByLibrary.simpleMessage("Alennus"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Älä häiritse"),
        "done": MessageLookupByLibrary.simpleMessage("Valmis"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Lataa Excel-muoto"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Ladattu onnistuneesti latauskansioon"),
        "due": MessageLookupByLibrary.simpleMessage("Maksamatta"),
        "dueAmount":
            MessageLookupByLibrary.simpleMessage("Maksamatta oleva summa: "),
        "dueCollection": MessageLookupByLibrary.simpleMessage(
            "Maksamattomien maksujen keräys"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("Erääntyneet perintäraportit"),
        "dueList": MessageLookupByLibrary.simpleMessage("Maksamattomat maksut"),
        "dueReports":
            MessageLookupByLibrary.simpleMessage("Maksamattomat raportit"),
        "duration": MessageLookupByLibrary.simpleMessage("Kesto"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Kesto: Alkaen"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "Helppokäyttöinen mobiilimaksupääte"),
        "edit": MessageLookupByLibrary.simpleMessage("Muokkaa"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Muokkaa ostolaskua"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Muokkaa myyntilaskua"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Muokkaa sosiaalista mediaa"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Muokkaus onnistui"),
        "editTax": MessageLookupByLibrary.simpleMessage("Muokkaa veroa"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Muokkaa veroryhmää"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("Muokkaa varastoa"),
        "email": MessageLookupByLibrary.simpleMessage("Sähköposti"),
        "emailAddress":
            MessageLookupByLibrary.simpleMessage("Sähköpostiosoite"),
        "emailCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Sähköpostiosoite ei voi olla tyhjää"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "Sähköposti lähetetty! Tarkista postilaatikkosi"),
        "endDate": MessageLookupByLibrary.simpleMessage("Lopetuspäivä"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Syötä voimassa oleva summa"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Anna voimassa oleva alennus"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Syötä voimassa oleva puhelinnumero"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Anna voimassa oleva hinta"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("Anna voimassa oleva määrä"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("Syötä osoite"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("Syötä määrä"),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Syötä tuotemerkin nimi"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Syötä kapasiteetti"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Syötä kategorian nimi"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Syötä väri"),
        "enterCustomerGstNumber":
            MessageLookupByLibrary.simpleMessage("Syötä asiakkaan GST-numero"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Syötä jälleenmyyjän hinta"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Syötä kuvaus"),
        "enterDiscount": MessageLookupByLibrary.simpleMessage("Syötä alennus."),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Syötä kulu pvm"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Syötä koko osoite"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Syötä laskun numero"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Syötä alhaisen varaston ilmoitusmäärä"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Syötä valmistaja"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("Kirjoita viestin sisältö"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "Syötä myyntihinta/jälleenmyyjän hinta"),
        "enterName": MessageLookupByLibrary.simpleMessage("Syötä nimi"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Syötä huomautus"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Syötä osapuolen nimi"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Syötä puhelinnumero"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Syötä tuotekoodi tai skannaa"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Syötä tuotteen nimi"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Syötä ostohinta."),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("Syötä viitenumero"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Syötä koko"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("Syötä varastot."),
        "enterTaxRate": MessageLookupByLibrary.simpleMessage("Syötä verokanta"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("Syötä tapahtumatunnus"),
        "enterType": MessageLookupByLibrary.simpleMessage("Syötä tyyppi"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("Syötä käyttäjänimike"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Syötä voimassa oleva summa"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Syötä varaston nimi"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Syötä paino"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Syötä tukkumyyntihinta"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("Kirjoita kuvaus tähän"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("Syötä sähköpostiosoitteesi"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "Kirjoita palautteesi otsikko"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Syötä GST-numerosi"),
        "enterYourMobileNumber": MessageLookupByLibrary.simpleMessage(
            "Kirjoita matkapuhelinnumerosi"),
        "enterYourName": MessageLookupByLibrary.simpleMessage("Syötä nimesi"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("Syötä puhelinnumerosi"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Syötä salasanasi"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Syötä puhelinnumerosi"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "Kirjoita tapahtumatunnuksesi"),
        "error": MessageLookupByLibrary.simpleMessage("Virhe"),
        "excTax": MessageLookupByLibrary.simpleMessage("Ilman veroa"),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("Excelin lataaja"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Ilman"),
        "expense": MessageLookupByLibrary.simpleMessage("Kulu"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Kulukategoria"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Kulu pvm"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Kulu kohteelle"),
        "expenseReport": MessageLookupByLibrary.simpleMessage("Kuluraportti"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Eräpäivä"),
        "expired": MessageLookupByLibrary.simpleMessage("Vanhentunut"),
        "expiring": MessageLookupByLibrary.simpleMessage("Vanhenee"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Epäsuorasti virhe"),
        "fashion": MessageLookupByLibrary.simpleMessage("Muoti"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Ominaisuudet ovat tärkeä osa, joka erottaa Pos Saas -ratkaisun perinteisistä vaihtoehdoista."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Palaute"),
        "firstName": MessageLookupByLibrary.simpleMessage("Etunimi"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Seuraa meitä Facebookissa"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Seuraa meitä Twitterissä"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Etupuoli"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("Rajattomaan käyttöön"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Unohtuiko salasana"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Unohditko salasanan?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Alkaen pvm"),
        "freeDataBackup": MessageLookupByLibrary.simpleMessage(
            "Ilmainen tietojen varmuuskopiointi"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Ilmainen paketti"),
        "freePlan":
            MessageLookupByLibrary.simpleMessage("Ilmainen suunnitelma"),
        "from": MessageLookupByLibrary.simpleMessage("(Alkaen"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Kokonaan maksettu"),
        "gallary": MessageLookupByLibrary.simpleMessage("Galleria"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("PDF:tä luodaan"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Hae vahvistuskoodi"),
        "govermentId":
            MessageLookupByLibrary.simpleMessage("Virallinen henkilötodistus"),
        "guest": MessageLookupByLibrary.simpleMessage("Vieras"),
        "havenotAnAccounts": MessageLookupByLibrary.simpleMessage("Ei tiliä?"),
        "history": MessageLookupByLibrary.simpleMessage("Historia"),
        "home": MessageLookupByLibrary.simpleMessage("Koti"),
        "howWeProtectYourInformation":
            MessageLookupByLibrary.simpleMessage("Miten suojaamme tietojasi"),
        "howWeUseYourInformation":
            MessageLookupByLibrary.simpleMessage("Miten käytämme tietojasi"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Henkilöllisyystarkistus"),
        "image": MessageLookupByLibrary.simpleMessage("Kuva"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("Sisäistä ei voi poistaa"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("Sisäistä ei voi muokata"),
        "inWord": MessageLookupByLibrary.simpleMessage("Sanoin"),
        "incTax": MessageLookupByLibrary.simpleMessage("Sis. vero"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Sisältäen"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("Lisää varastoa"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Maksuväline"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Laskun nro"),
        "invoice": MessageLookupByLibrary.simpleMessage("Lasku"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("Laskun numero"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Laskun asetukset"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Laskun katselija"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Tuote lisätty"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("KYC-tarkistus"),
        "language": MessageLookupByLibrary.simpleMessage("Kieli"),
        "lastName": MessageLookupByLibrary.simpleMessage("Sukunimi"),
        "ledger": MessageLookupByLibrary.simpleMessage("Päiväkirja"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Elinaikainen\nosto"),
        "link": MessageLookupByLibrary.simpleMessage("Linkki"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Live-chat-tuki"),
        "loading": MessageLookupByLibrary.simpleMessage("Ladataan"),
        "logIn": MessageLookupByLibrary.simpleMessage("Kirjaudu sisään"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Kirjaudu ulos"),
        "logOut": MessageLookupByLibrary.simpleMessage("Kirjaudu ulos"),
        "login": MessageLookupByLibrary.simpleMessage("Kirjaudu sisään"),
        "logo": MessageLookupByLibrary.simpleMessage("Logo"),
        "loss": MessageLookupByLibrary.simpleMessage("Tappio"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Tappio / Voitto"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Tappio / Voitto -tiedot"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Tappiovoitto raportti"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Tappiovoitto raportit"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Alhainen varastoilmoitus"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Tee kestävä vaikutus asiakkaisiisi brändättyjen laskujen avulla. Rajattoman päivityksen avulla voit räätälöidä laskusi ja lisätä ammattimaisen kosketuksen, joka vahvistaa brändisi identiteettiä ja edistää asiakasuskollisuutta."),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("Hallitse liiketoimintaasi"),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Valmistuspäivämäärä"),
        "margin": MessageLookupByLibrary.simpleMessage("Marginaali"),
        "masterCard": MessageLookupByLibrary.simpleMessage("MasterCard"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Valmistaja"),
        "message": MessageLookupByLibrary.simpleMessage("Viesti"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Viestihistoria"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Pos Saas -sovellus on ilmainen ja helppokäyttöinen. Itse asiassa se on yksi parhaista myyntipistejärjestelmistä maailmassa."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas on täydellinen liiketoimintaratkaisu varastonhallintaa, tilinpitoa, myyntiä, kuluja ja voitto/tappio -seurantaa varten."),
        "mobile": MessageLookupByLibrary.simpleMessage("Mobiili"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("Mobiilimaksu"),
        "monthly": MessageLookupByLibrary.simpleMessage("Kuukausi"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("Lisätietoja"),
        "name": MessageLookupByLibrary.simpleMessage("Syötä nimesi"),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Nimi on jo olemassa"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("Nimi ei voi olla tyhjää"),
        "next": MessageLookupByLibrary.simpleMessage("Seuraava"),
        "noConnection": MessageLookupByLibrary.simpleMessage("Ei yhteyttä"),
        "noData": MessageLookupByLibrary.simpleMessage("Ei tietoja"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Tietoja ei saatavilla"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Tietoja ei löytynyt"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("Ei löytynyt historiaa!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Tuotetta ei löytynyt"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("Ei alaverot valittu"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("Ei löytynyt tapahtumia!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Käyttäjää ei löytynyt tuolla sähköpostiosoitteella."),
        "noUserRoleFound":
            MessageLookupByLibrary.simpleMessage("Käyttäjäroolia ei löytynyt"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Ei aktiivinen käyttäjä"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Ei annettu"),
        "note": MessageLookupByLibrary.simpleMessage("Huomautus"),
        "notes": MessageLookupByLibrary.simpleMessage("Muistiinpanot"),
        "notification": MessageLookupByLibrary.simpleMessage("Ilmoitus"),
        "oTPSentTo":
            MessageLookupByLibrary.simpleMessage("OTP lähetetty osoitteeseen"),
        "office": MessageLookupByLibrary.simpleMessage("Toimisto"),
        "ok": MessageLookupByLibrary.simpleMessage("Ok"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS-järjestelmä, joka sisältää runsaasti toiminnallisuuksia, mukaan lukien myynnin seuranta ja varastonhallinta."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Tämä järjestelmä auttaa sinua parantamaan toimintojasi asiakkaittesi hyväksi."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "POS-järjestelmämme tulisi automaattisesti yksinkertaistaa päivittäisiä toimintoja, tehdä niiden navigoinnista helppoa."),
        "openingBalance": MessageLookupByLibrary.simpleMessage("Aloitussaldo"),
        "order": MessageLookupByLibrary.simpleMessage("Tilaukset"),
        "other": MessageLookupByLibrary.simpleMessage("Muut"),
        "otp": MessageLookupByLibrary.simpleMessage("Sulje"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Loppu varastosta"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Paketti"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Pakettiominaisuudet"),
        "paid": MessageLookupByLibrary.simpleMessage("Maksettu"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Maksettu summa"),
        "parties": MessageLookupByLibrary.simpleMessage("Osapuolet"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Osapuolten lista"),
        "partyGST": MessageLookupByLibrary.simpleMessage("Osapuolen GST"),
        "partyName": MessageLookupByLibrary.simpleMessage("Osapuolen nimi"),
        "password": MessageLookupByLibrary.simpleMessage("Salasana"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Salasana ja vahvistussalasana eivät täsmää"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Salasana ei voi olla tyhjää"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("Salasana ei täsmää"),
        "payCash": MessageLookupByLibrary.simpleMessage("Maksa käteisellä"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash": MessageLookupByLibrary.simpleMessage("Maksa bkashilla"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Maksa Paypalilla"),
        "payeeName": MessageLookupByLibrary.simpleMessage("Saajan nimi"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("Saajan numero"),
        "payment": MessageLookupByLibrary.simpleMessage("Maksu"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("Maksun määrä"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Maksu suoritettu"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Maksuohjeet:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("Maksutapa"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Maksutapa"),
        "pdfView": MessageLookupByLibrary.simpleMessage("Pdf-näyttö"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Henkilökohtaiset tiedot"),
        "phone": MessageLookupByLibrary.simpleMessage("Puhelin"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Puhelinnumero"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Puhelinnumero on jo käytössä"),
        "phoneNumberIsNotValid": MessageLookupByLibrary.simpleMessage(
            "Puhelinnumero ei ole voimassa"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("Puhelinnumero on pakollinen"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("Valitse ja lataa tiedosto"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("Valitse lopetuspäivä"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Valitse aloituspäivä"),
        "plan": MessageLookupByLibrary.simpleMessage("Suunnitelma"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("Ole hyvä ja lisää määrä"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage("Tarkista internet-yhteytesi"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Ole hyvä ja yhdistä tulostin ensin"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage("Yhdistä Bluetooth-tulostin"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Ole hyvä ja syötä suurempi salasana"),
        "pleaseEnterAConfirmPassword":
            MessageLookupByLibrary.simpleMessage("Syötä vahvistettu salasana"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("Syötä salasana"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Ole hyvä ja syötä voimassa oleva sähköpostiosoite"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Ole hyvä ja syötä nimi"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("Ole hyvä ja syötä salasana"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Syötä sähköpostiosoitteesi alle saadaksesi salasanan palautuslinkin."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Ole hyvä ja syötä transaktiotunnus"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("Ole hyvä ja syötä summa"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Ole hyvä ja valitse kategoria ensin"),
        "pleaseSelectAPlan": MessageLookupByLibrary.simpleMessage(
            "Ole hyvä ja valitse suunnitelma"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Ole hyvä ja valitse liiketoimintakategoria"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Ole hyvä ja käytä voimassa olevaa ostopäiväkoodia käyttääksesi sovellusta"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Toimii Pos Saas -palvelulla"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Tehostaa"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Premium-asiakastuki"),
        "premiumPlan":
            MessageLookupByLibrary.simpleMessage("Premium-suunnitelma"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Aiemmat maksutiedot"),
        "price": MessageLookupByLibrary.simpleMessage("hinta"),
        "print": MessageLookupByLibrary.simpleMessage("Tulosta"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Tulostusvaihtoehto"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Tietosuojakäytäntö"),
        "product": MessageLookupByLibrary.simpleMessage("Tuote"),
        "productCode": MessageLookupByLibrary.simpleMessage("Tuotekoodi"),
        "productCodeIsRequired": MessageLookupByLibrary.simpleMessage(
            "Tuotteen koodi on pakollinen"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Tuotekoodi/Nimi"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Tuotekuvaus"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Tuotteen tiedot"),
        "productList": MessageLookupByLibrary.simpleMessage("Tuotelista"),
        "productName": MessageLookupByLibrary.simpleMessage("Tuotteen nimi"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Tuotteen nimi on jo olemassa tässä varastossa"),
        "productNameIsAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("Tuotenimi on jo lisätty"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("Tuotteen nimi on pakollinen"),
        "products": MessageLookupByLibrary.simpleMessage("Tuotteet"),
        "profile": MessageLookupByLibrary.simpleMessage("Profiili"),
        "profileEdit":
            MessageLookupByLibrary.simpleMessage("Profiilin muokkaus"),
        "profit": MessageLookupByLibrary.simpleMessage("Voitto"),
        "promo": MessageLookupByLibrary.simpleMessage("tarjous"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Tarjouskoodi"),
        "purchase": MessageLookupByLibrary.simpleMessage("Osto"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage("Ostoilmoitus"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Osto vahvistettu"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Osto yksityiskohdat"),
        "purchaseInvoice": MessageLookupByLibrary.simpleMessage("Ostolasku"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("Ostolistat"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Osta nyt"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Osta Premium-suunnitelma"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("Ostohinta"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("Ostohinta on pakollinen"),
        "purchaseRepoet": MessageLookupByLibrary.simpleMessage("Osto raportti"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Osto raportit"),
        "purchaseReportss": MessageLookupByLibrary.simpleMessage("Ostotiedot"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("Oston palautus"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("Oston palautusraportti"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Ostosiirto"),
        "qty": MessageLookupByLibrary.simpleMessage("Määrä"),
        "quantity": MessageLookupByLibrary.simpleMessage("Määrä"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Viimeaikaiset tapahtumat"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("Pin-koodi vastaanotettu"),
        "referenceNumber": MessageLookupByLibrary.simpleMessage("Viitenumero"),
        "register": MessageLookupByLibrary.simpleMessage("Rekisteröidy"),
        "registering": MessageLookupByLibrary.simpleMessage("Rekisteröidään"),
        "remainingDue":
            MessageLookupByLibrary.simpleMessage("Maksamatta jäävä"),
        "remove": MessageLookupByLibrary.simpleMessage("Poista"),
        "reports": MessageLookupByLibrary.simpleMessage("Raportit"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Pyyntö on lähetetty"),
        "resendCode":
            MessageLookupByLibrary.simpleMessage("Lähetä koodi uudelleen"),
        "resendOtp": MessageLookupByLibrary.simpleMessage(
            "Lähetä vahvistuskoodi uudelleen: "),
        "retailer": MessageLookupByLibrary.simpleMessage("Jälleenmyyjä"),
        "retur": MessageLookupByLibrary.simpleMessage("Palautus"),
        "returN": MessageLookupByLibrary.simpleMessage("Palautus"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("Palautussumma"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("Palautussumma"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("Palautusmäärä"),
        "revenue": MessageLookupByLibrary.simpleMessage("Tulot"),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Myyntisumma"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("Myyntitiedot"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Myyntihinta"),
        "saleReports": MessageLookupByLibrary.simpleMessage("Myynti raportti"),
        "saleReportss": MessageLookupByLibrary.simpleMessage("Myyntiraportit"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("Myynnin palautus"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Myynnin palautusraportti"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("Myyntiasetukset"),
        "sales": MessageLookupByLibrary.simpleMessage("Myynti"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("Myynti- ja ostoraportit"),
        "salesList": MessageLookupByLibrary.simpleMessage("Myyntilistat"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("Myynnin palautus"),
        "save": MessageLookupByLibrary.simpleMessage("Tallenna"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Tallenna ja julkaise"),
        "saveChanges":
            MessageLookupByLibrary.simpleMessage("Tallenna muutokset"),
        "saving": MessageLookupByLibrary.simpleMessage("Tallennetaan"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("Skannaa tuotteen QR-koodi"),
        "search": MessageLookupByLibrary.simpleMessage("Haku"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Etsi tuotteen koodin tai nimen mukaan"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("Näytä kaikki tarjouskoodit"),
        "select": MessageLookupByLibrary.simpleMessage("Valitse"),
        "selectAProductForReturn":
            MessageLookupByLibrary.simpleMessage("Valitse palautettava tuote"),
        "selectBrand":
            MessageLookupByLibrary.simpleMessage("Valitse tuotemerkki"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Valitse kategoria"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Valitse yhteystiedot"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("Valitse tuotekategoria"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("Valitse kauppakategoria"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Valitse vero"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Valitse verotyyppi"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("Valitse yksikkö"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Valitse muunnelma: "),
        "seller": MessageLookupByLibrary.simpleMessage("Myyjä"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Myyjä"),
        "send": MessageLookupByLibrary.simpleMessage("Lähetä"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("Lähetä sähköpostia"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Lähetä viesti"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("Lähetä palautuslinkki"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Lähetä SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Lähetetäänkö SMS?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Lähetä WhatsApp-viesti"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Lähetä sähköpostisi"),
        "sendingEmail":
            MessageLookupByLibrary.simpleMessage("Lähetetään sähköpostia"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Lähetetään viestiä"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Palvelu/Lähetys"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Aseta profiili"),
        "setting": MessageLookupByLibrary.simpleMessage("Asetukset"),
        "share": MessageLookupByLibrary.simpleMessage("Jaa"),
        "shopGST": MessageLookupByLibrary.simpleMessage("Kaupan GST"),
        "signIn": MessageLookupByLibrary.simpleMessage("Kirjaudu sisään"),
        "signInWithEmail": MessageLookupByLibrary.simpleMessage(
            "Kirjaudu sisään sähköpostilla"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Asiakkaan allekirjoitus"),
        "size": MessageLookupByLibrary.simpleMessage("Koko"),
        "skip": MessageLookupByLibrary.simpleMessage("Ohita"),
        "sms": MessageLookupByLibrary.simpleMessage("Tekstiviesti"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Sosiaalinen markkinointi"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Anteeksi, sinulla ei ole lupaa käyttää tätä palvelua"),
        "startDate": MessageLookupByLibrary.simpleMessage("Aloituspäivä"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Aloita uusi myynti"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage(
            "Aloita kirjoittaminen hakeaksesi"),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("Vielä maksamatta"),
        "stock": MessageLookupByLibrary.simpleMessage("Varasto"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Varasto on pakollinen"),
        "stockList": MessageLookupByLibrary.simpleMessage("Varastoslista"),
        "stocks": MessageLookupByLibrary.simpleMessage("Varastot"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Tallennusoikeus on pakollinen Excel-tiedoston luomiseksi"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("Alaverolistat"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Alaverot"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Välisumma"),
        "submit": MessageLookupByLibrary.simpleMessage("Lähetä"),
        "subscribeToOurYoutube":
            MessageLookupByLibrary.simpleMessage("Tilaa YouTubestamme"),
        "subscription": MessageLookupByLibrary.simpleMessage("Tilaus"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Onnistuneesti suoritettu"),
        "successfullyLoggedOut": MessageLookupByLibrary.simpleMessage(
            "Olet kirjautunut ulos onnistuneesti"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Päivitys onnistui"),
        "supplier": MessageLookupByLibrary.simpleMessage("Toimittaja"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("Toimittajan nimi"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT-koodi"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Ota mukaan ajokortti, henkilökortti tai passikuva"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "Ota henkilökortti tarkistaaksesi tietosi"),
        "tap": MessageLookupByLibrary.simpleMessage("Napauta"),
        "tax": MessageLookupByLibrary.simpleMessage("Vero"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Veroryhmä"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("Veroprosentti"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Verokanta"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Verokannat - Hallitse verokantojasi"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Veroraportti"),
        "taxType": MessageLookupByLibrary.simpleMessage("Verotyyppi"),
        "taxes": MessageLookupByLibrary.simpleMessage("Verot"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Ehdot ja säännöt"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("Käyttöehdot"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Ehdot ja tietosuoja"),
        "thankYOuForYourDuePayment":
            MessageLookupByLibrary.simpleMessage("Kiitos maksustasi"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Kiitos"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Kiitos ostoksestasi"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "Tämä sähköpostiosoite on jo käytössä"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Excel-tiedosto on jo ladattu"),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "Antamasi salasana on liian heikko"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Myynti poistetaan ja kaikki tiedot tästä ostosta poistetaan. Oletko varma, että haluat poistaa tämän?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Myynti poistetaan ja kaikki tiedot tästä myynnistä poistetaan. Oletko varma, että haluat poistaa tämän?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Käyttäjä poistetaan ja kaikki tiedot poistetaan tililtäsi. Haluatko varmasti poistaa tämän?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Käyttäjä poistetaan ja kaikki tiedot poistetaan tililtäsi. Oletko varma, että haluat poistaa tämän?"),
        "thirdPartyServices": MessageLookupByLibrary.simpleMessage(
            "Kolmannen osapuolen palvelut"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Tätä kategoriaa ei voi poistaa"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Tämä kuukausi)"),
        "thisProductAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("Tämä tuote on jo lisätty"),
        "title": MessageLookupByLibrary.simpleMessage("Otsikko"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Otsikko ei voi olla tyhjää"),
        "to": MessageLookupByLibrary.simpleMessage("asti"),
        "toDate": MessageLookupByLibrary.simpleMessage("Päättyen pvm"),
        "today": MessageLookupByLibrary.simpleMessage("Tänään"),
        "total": MessageLookupByLibrary.simpleMessage("Yhteensä"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Kokonaissumma"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Yhteensä kerätty"),
        "totalDue":
            MessageLookupByLibrary.simpleMessage("Kaikki maksamattomat"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("Kokonaiskulut"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Kokonaiskuhka"),
        "totalPayable": MessageLookupByLibrary.simpleMessage("Kokonaisvelka"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Kokonaishinta"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("Yhteensä tuotteita"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Kokonaisvoitto"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("Yhteensä ostot"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Yhteensä palautettavaa"),
        "totalReturns":
            MessageLookupByLibrary.simpleMessage("Yhteensä palautuksia"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Kokonaismyynti"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Kokonaisvarasto"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Kokonaisarvo"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Kokonaisvero"),
        "totals": MessageLookupByLibrary.simpleMessage("Yhteensä: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Tapahtuma"),
        "transactionId":
            MessageLookupByLibrary.simpleMessage("Tapahtumatunnus"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Yritä uudelleen"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Tyyppi"),
        "unitName": MessageLookupByLibrary.simpleMessage("Yksikön nimi"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Yksikköhinta"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Yksikköhinta"),
        "units": MessageLookupByLibrary.simpleMessage("Yksiköt"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Rajoittamaton"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Rajoittamaton käyttö"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Avaa Pos Saas POS -järjestelmän täysi potentiaali henkilökohtaisten koulutussessioiden avulla, joita johtaa asiantuntijatiimimme. Perusteista edistyneisiin tekniikoihin varmistamme, että osaat hyödyntää järjestelmän jokaista näkökulmaa liiketoimintaprosessiesi optimoimiseksi."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Maksamatta"),
        "update": MessageLookupByLibrary.simpleMessage("Päivitä"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Päivitä yhteystieto"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Päivitä nyt"),
        "updateProduct": MessageLookupByLibrary.simpleMessage("Päivitä tuote"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Päivitä suunnitelmasi ensin,\\nrakkautesi on ohi"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Päivitä profiilisi"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Päivitä profiilisi yhdistääksesi lääkärisi paremmin"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Päivitä profiilisi yhdistääksesi asiakkaasi paremmin"),
        "updated": MessageLookupByLibrary.simpleMessage("Päivitetty"),
        "upload": MessageLookupByLibrary.simpleMessage("Lataa"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Lataa asiakirja"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("Lataus valmis"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Lataa tiedosto"),
        "upplier": MessageLookupByLibrary.simpleMessage("Toimittaja"),
        "usbC": MessageLookupByLibrary.simpleMessage("Usb C"),
        "use": MessageLookupByLibrary.simpleMessage("Käytä"),
        "useMobiPos":
            MessageLookupByLibrary.simpleMessage("Käytä Pos Saas -ratkaisua"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Järjestelmän käyttö"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Käyttäjä on poistettu"),
        "userRole": MessageLookupByLibrary.simpleMessage("Käyttäjärooli"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("Käyttäjäroolin tiedot"),
        "userTitle": MessageLookupByLibrary.simpleMessage("Käyttäjänimike"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Käyttäjän titteli ei voi olla tyhjää"),
        "value": MessageLookupByLibrary.simpleMessage("Arvo"),
        "vatDoesNotApply": MessageLookupByLibrary.simpleMessage("ALV ei koske"),
        "verifyOtp":
            MessageLookupByLibrary.simpleMessage("Vahvista vahvistuskoodi"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Vahvista puhelinnumero"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Näytä kaikki"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("Näytä tiedot"),
        "walkInCustomer": MessageLookupByLibrary.simpleMessage("Kävelyasiakas"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Varasto"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Varasto on jo olemassa"),
        "warehouseList":
            MessageLookupByLibrary.simpleMessage("Varastoluettelo"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("Varaston nimi"),
        "warranty": MessageLookupByLibrary.simpleMessage("Takuu"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Olemme lähettäneet sähköpostin ohjeilla salasanan palauttamiseksi osoitteeseen:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Voimme käyttää kolmannen osapuolen palveluita tukemaan sovelluksemme toiminnallisuutta, kuten analytiikkapalveluita ja maksunvälittäjiä. Nämä kolmannen osapuolen palvelut saattavat kerätä tietoja sinusta sovellustamme käyttäessäsi. Huomaa, että emme vastaa näiden kolmannen osapuolen palveluiden yksityisyyden suojaamisen käytännöistä."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Noudatamme teollisuusstandardeja tietojesi suojaamiseksi, mukaan lukien salaus ja turvallinen tallennus. Rajoitamme myös tietojesi käyttöoikeuden vain valtuutettuihin henkilöihin."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Käytämme henkilökohtaisia tietojasi tarjotaksemme sinulle parhaan mahdollisen kokemuksen sovelluksessamme, mukaan lukien sisältösuositusten räätälöimisen, yhteyden muodostamisen asiantuntijoihin ja sovelluksemme toiminnallisuuden parantamisen. Voimme myös käyttää tietojasi viestimiseen päivityksistä, tarjouksista tai muista sovellukseemme liittyvistä tiedoista."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Käymme maksun läpi ja hyväksymme sen 1-2 tunnin kuluessa"),
        "weekly": MessageLookupByLibrary.simpleMessage("Viikoittain"),
        "weight": MessageLookupByLibrary.simpleMessage("Paino"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Uutuudet"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Tukkumyyjä"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Tukkumyyntihinta"),
        "wholesalePrice":
            MessageLookupByLibrary.simpleMessage("Tukkumyyntihinta"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Tukkumyyjä"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Lisätään pian"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Vanhentuu"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Kirjoita viestisi tähän"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("Väärä OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Väärä salasana kyseiselle käyttäjälle."),
        "yearly": MessageLookupByLibrary.simpleMessage("Vuosi"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Kyllä, poista pysyvästi"),
        "youAreNotAValidUser": MessageLookupByLibrary.simpleMessage(
            "Et ole voimassa oleva käyttäjä"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Käytät"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Et voi maksaa enemmän kuin erääntynyt summa"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Sinulla on sähköposti"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Olet kirjautunut tilillesi onnistuneesti. Ole Pos Saas in kanssa."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("Sinun on annettava lupa"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Sinun on kirjauduttava uudelleen tilillesi."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Sinun on tarkistettava henkilöllisyytesi ennen ostoa"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Viestisi säilyy"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Pakettisi"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Pakettisi vanhenee 5 päivän kuluttua")
      };
}
