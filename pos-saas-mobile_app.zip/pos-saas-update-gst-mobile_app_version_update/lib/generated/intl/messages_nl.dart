// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a nl locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'nl';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Doorgaan"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("GST-nummer"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MPR"),
        "MRPIsRequired": MessageLookupByLibrary.simpleMessage("MRP is vereist"),
        "OK": MessageLookupByLibrary.simpleMessage("OK"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Ph.no"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT-code"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Tussendoortjes"),
        "TAX": MessageLookupByLibrary.simpleMessage("BELASTING"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Uploaden"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("Gebruikerstitel"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Uw Pakket Verloopt Vandaag\n\nKoop alstublieft opnieuw"),
        "aboutApp": MessageLookupByLibrary.simpleMessage("Over de app"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Over ons"),
        "accountName": MessageLookupByLibrary.simpleMessage("Rekeningnaam"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("Rekeningnummer"),
        "acton": MessageLookupByLibrary.simpleMessage("Actie"),
        "add": MessageLookupByLibrary.simpleMessage("Toevoegen"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Merk Toevoegen"),
        "addCategory":
            MessageLookupByLibrary.simpleMessage("Categorie Toevoegen"),
        "addContact": MessageLookupByLibrary.simpleMessage("Contact toevoegen"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Klant Toevoegen"),
        "addDelivery":
            MessageLookupByLibrary.simpleMessage("Levering toevoegen"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Voeg beschrijving toe"),
        "addDescription":
            MessageLookupByLibrary.simpleMessage("Notitie toevoegen"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Voeg korting toe"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Voeg Document Id Toe"),
        "addDucument":
            MessageLookupByLibrary.simpleMessage("Document Toevoegen"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Uitgave Toevoegen"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Uitgave Categorie Toevoegen"),
        "addItems": MessageLookupByLibrary.simpleMessage("Items toevoegen"),
        "addNew": MessageLookupByLibrary.simpleMessage("Voeg nieuw toe"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Nieuw adres toevoegen"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Nieuw Product Toevoegen"),
        "addNewTax":
            MessageLookupByLibrary.simpleMessage("Nieuwe belasting toevoegen"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Nieuwe belasting toevoegen met enkele/meerdere belastingtypes"),
        "addNote": MessageLookupByLibrary.simpleMessage("Notitie Toevoegen"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Voeg eerst een product toe"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Voeg promotiecode toe"),
        "addPurchase":
            MessageLookupByLibrary.simpleMessage("Aankoop toevoegen"),
        "addSales": MessageLookupByLibrary.simpleMessage("Verkoop Toevoegen"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Succesvol toegevoegd"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Eenheid toevoegen"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Gebruikersrol toevoegen"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Succesvol toegevoegd"),
        "addedToCart": MessageLookupByLibrary.simpleMessage(
            "Toegevoegd aan winkelwagentje"),
        "address": MessageLookupByLibrary.simpleMessage("Adres"),
        "admin": MessageLookupByLibrary.simpleMessage("Beheerder"),
        "all": MessageLookupByLibrary.simpleMessage("Alle"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("Alle zakelijke oplossingen"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("Al toegevoegd"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Bestaat al"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Heb je al een account?"),
        "amount": MessageLookupByLibrary.simpleMessage("Bedrag"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "Er is een e-mail verzonden.\\nControleer uw inbox"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Ondersteuning voor Android en iOS-app"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Toepasbare belasting"),
        "apply": MessageLookupByLibrary.simpleMessage("Toepassen"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Weet je zeker dat je deze factuur wilt verwijderen?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Weet je zeker dat je deze verkoop wilt verwijderen?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Weet u zeker dat u deze gebruiker wilt verwijderen?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Weet u zeker dat u deze belasting wilt verwijderen?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Weet u zeker dat u deze belastinggroep wilt verwijderen?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Wilt u dit magazijn verwijderen?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Weet je zeker dat je deze gebruiker wilt verwijderen?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Geautoriseerde handtekening"),
        "backSide": MessageLookupByLibrary.simpleMessage("Achterkant"),
        "backToHome":
            MessageLookupByLibrary.simpleMessage("Terug naar startpagina"),
        "balance": MessageLookupByLibrary.simpleMessage("Balans"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladesh"),
        "bank": MessageLookupByLibrary.simpleMessage("Bank"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Valuta van bankrekening"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Valuta bankrekening"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Bankinformatie"),
        "bankName": MessageLookupByLibrary.simpleMessage("Banknaam"),
        "bankTransfer":
            MessageLookupByLibrary.simpleMessage("Bankoverschrijving"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Barcode gevonden"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Factuur"),
        "billTo": MessageLookupByLibrary.simpleMessage("Factuur Aan"),
        "branchName": MessageLookupByLibrary.simpleMessage("Vestigingsnaam"),
        "brand": MessageLookupByLibrary.simpleMessage("Merk"),
        "brandName": MessageLookupByLibrary.simpleMessage("Merknaam"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("Bulk \nUploaden"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Bedrijfscategorie"),
        "buy": MessageLookupByLibrary.simpleMessage("Kopen"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Koop Premium Plan"),
        "buySms": MessageLookupByLibrary.simpleMessage("Koop Sms"),
        "cacel": MessageLookupByLibrary.simpleMessage("Annuleren"),
        "call": MessageLookupByLibrary.simpleMessage("Bellen"),
        "callForEmergencySupport":
            MessageLookupByLibrary.simpleMessage("Bel voor noodondersteuning"),
        "camera": MessageLookupByLibrary.simpleMessage("Camera"),
        "cancel": MessageLookupByLibrary.simpleMessage("Annuleren"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Annuleer alle producten"),
        "capacity": MessageLookupByLibrary.simpleMessage("Capaciteit"),
        "card": MessageLookupByLibrary.simpleMessage("Kaart"),
        "cash": MessageLookupByLibrary.simpleMessage("Contant"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Categorieën"),
        "category": MessageLookupByLibrary.simpleMessage("Categorie"),
        "categoryName": MessageLookupByLibrary.simpleMessage("Categorie naam"),
        "categoryNameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Categorie naam bestaat al"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("Categorienaam"),
        "change": MessageLookupByLibrary.simpleMessage("Wijzigen?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Wachtwoord wijzigen"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("Controleer e-mail"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Kies een klant"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Kies een leverancier"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Kies je functies"),
        "clarence": MessageLookupByLibrary.simpleMessage("Clarence"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Klik om te verbinden"),
        "close": MessageLookupByLibrary.simpleMessage("Sluiten"),
        "color": MessageLookupByLibrary.simpleMessage("Kleur"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(Combinatie van meerdere belastingen)"),
        "comingSoon":
            MessageLookupByLibrary.simpleMessage("Binnenkort beschikbaar"),
        "companyAddress": MessageLookupByLibrary.simpleMessage("Bedrijfsadres"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Bedrijfs- en winkelnaam"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("Bedrijfsnaam"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Transactie Voltooien"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Bevestig Wachtwoord"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Bevestig retour"),
        "congratulations":
            MessageLookupByLibrary.simpleMessage("Gefeliciteerd"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Neem contact op"),
        "continu": MessageLookupByLibrary.simpleMessage("Doorgaan"),
        "country": MessageLookupByLibrary.simpleMessage("Land"),
        "create": MessageLookupByLibrary.simpleMessage("Creëren"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Maak een gratis account aan"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Gemaakt en opgeslagen"),
        "currency": MessageLookupByLibrary.simpleMessage("Valuta"),
        "currentStock":
            MessageLookupByLibrary.simpleMessage("Huidige Voorraad"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("Aangepaste factuurbranding"),
        "customer": MessageLookupByLibrary.simpleMessage("Klant"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Klantgegevens"),
        "customerGST": MessageLookupByLibrary.simpleMessage("Klanten GST"),
        "customerName": MessageLookupByLibrary.simpleMessage("Klantnaam"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Dagelijkse transactie"),
        "dataSavedSuccessfully": MessageLookupByLibrary.simpleMessage(
            "Gegevens succesvol opgeslagen"),
        "date": MessageLookupByLibrary.simpleMessage("Datum"),
        "day": MessageLookupByLibrary.simpleMessage("Dag"),
        "dealer": MessageLookupByLibrary.simpleMessage("Handelaar"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("Handelaarsprijs"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("Standaard BTW-percentage"),
        "delete": MessageLookupByLibrary.simpleMessage("Verwijderen"),
        "deleting": MessageLookupByLibrary.simpleMessage("Verwijderen"),
        "deliveryAddress": MessageLookupByLibrary.simpleMessage("Bezorgadres"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Leveringsadressen"),
        "deliveryCharge": MessageLookupByLibrary.simpleMessage("Bezorgkosten"),
        "describtion": MessageLookupByLibrary.simpleMessage("Beschrijving"),
        "description": MessageLookupByLibrary.simpleMessage("Beschrijving"),
        "descriptionCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Beschrijving mag niet leeg zijn"),
        "details": MessageLookupByLibrary.simpleMessage("Details"),
        "discount": MessageLookupByLibrary.simpleMessage("Korting"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Niet storen"),
        "done": MessageLookupByLibrary.simpleMessage("Klaar"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Download Excel-indeling"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Succesvol gedownload in de downloadmap"),
        "due": MessageLookupByLibrary.simpleMessage("Te betalen"),
        "dueAmount":
            MessageLookupByLibrary.simpleMessage("Te betalen bedrag: "),
        "dueCollection": MessageLookupByLibrary.simpleMessage(
            "Inning van openstaande bedragen"),
        "dueCollectionReports": MessageLookupByLibrary.simpleMessage(
            "Rapporten openstaande betalingen"),
        "dueList": MessageLookupByLibrary.simpleMessage(
            "Lijst met openstaande bedragen"),
        "dueReports":
            MessageLookupByLibrary.simpleMessage("Rapport Te Betalen"),
        "duration": MessageLookupByLibrary.simpleMessage("Duur"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Duur: Van"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "Gemakkelijk te gebruiken mobiele kassa"),
        "edit": MessageLookupByLibrary.simpleMessage("Bewerken"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Aankoopfactuur Bewerken"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Verkoopfactuur Bewerken"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Sociale Media Bewerken"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Succesvol bewerkt"),
        "editTax": MessageLookupByLibrary.simpleMessage("Belasting bewerken"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Belastinggroep bewerken"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("Magazijn bewerken"),
        "email": MessageLookupByLibrary.simpleMessage("E-mail"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("E-mailadres"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("E-mail mag niet leeg zijn"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "E-mail verzonden! Controleer je inbox"),
        "endDate": MessageLookupByLibrary.simpleMessage("Einddatum"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Voer een geldig bedrag in"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Voer een geldige korting in"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Voer een geldig telefoonnummer in"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Voer een geldige prijs in"),
        "enterAValidQuantity": MessageLookupByLibrary.simpleMessage(
            "Voer een geldige hoeveelheid in"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("Voer adres in"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("Voer bedrag in"),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Voer Merknaam In"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Voer Capaciteit In"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Voer Categorienaam In"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Voer Kleur In"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "Voer het GST-nummer van de klant in"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Handelaarsprijs invoeren"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Voer beschrijving in"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("Korting invoeren"),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Voer de uitgavedatum in"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Voer volledig adres in"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Voer factuurnummer in"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Voer de hoeveelheid voor lage voorraad waarschuwing in"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Fabrikant invoeren"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("Voer berichtinhoud in"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "MPR/Detailhandelsprijs invoeren"),
        "enterName": MessageLookupByLibrary.simpleMessage("Voer naam in"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Voer notitie in"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Voer partijnaam in"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Voer telefoonnummer in"),
        "enterProductCodeOrScan":
            MessageLookupByLibrary.simpleMessage("Voer productcode in of scan"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Voer Productnaam In"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Inkoopprijs invoeren"),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("Voer referentienummer in"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Voer Maat In"),
        "enterStocks":
            MessageLookupByLibrary.simpleMessage("Voorraad invoeren"),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Voer belastingtarief in"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("Voer transactie-ID in"),
        "enterType": MessageLookupByLibrary.simpleMessage("Voer Type In"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("Voer gebruikerstitel in"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Voer een geldig bedrag in"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Voer magazijnnaam in"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Voer Gewicht In"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Groothandelsprijs invoeren"),
        "enterYourDescriptionHere": MessageLookupByLibrary.simpleMessage(
            "Voer hier uw beschrijving in"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("Voer je e-mailadres in"),
        "enterYourFeedBackTitle":
            MessageLookupByLibrary.simpleMessage("Voer uw feedbacktitel in"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Voer uw GST-nummer in"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("Voer uw mobiele nummer in"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Voer je naam in"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("Voer je telefoonnummer in"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Voer uw wachtwoord in"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Voer je telefoonnummer in"),
        "enterYourTransactionId":
            MessageLookupByLibrary.simpleMessage("Voer uw transactie-id in"),
        "error": MessageLookupByLibrary.simpleMessage("Fout"),
        "excTax": MessageLookupByLibrary.simpleMessage("Exclusief belasting"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("Excel uploader"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Exclusief"),
        "expense": MessageLookupByLibrary.simpleMessage("Uitgave"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Uitgave Categorie"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Uitgavedatum"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Uitgave Voor"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Uitgave Rapport"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Vervaldatum"),
        "expired": MessageLookupByLibrary.simpleMessage("Verlopen"),
        "expiring": MessageLookupByLibrary.simpleMessage("Verloopt"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Mislukt met fout"),
        "fashion": MessageLookupByLibrary.simpleMessage("Mode"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Functies zijn het belangrijke onderdeel dat Pos Saas onderscheidt van traditionele oplossingen."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Feedback"),
        "firstName": MessageLookupByLibrary.simpleMessage("Voornaam"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Volg ons op\\nFacebook"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Volg ons op\\nTwitter"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Voorkant"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("Voor onbeperkt gebruik"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Wachtwoord vergeten"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Wachtwoord vergeten?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Van Datum"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("Gratis gegevensback-up"),
        "freeLifeTimeUpdate":
            MessageLookupByLibrary.simpleMessage("Gratis levenslange update"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Gratis Pakket"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Gratis Plan"),
        "from": MessageLookupByLibrary.simpleMessage("(Van"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Volledig betaald"),
        "gallary": MessageLookupByLibrary.simpleMessage("Galerij"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("PDF genereren"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Ontvang OTP"),
        "govermentId":
            MessageLookupByLibrary.simpleMessage("Overheidsidentificatie"),
        "guest": MessageLookupByLibrary.simpleMessage("Gast"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Heb je geen account?"),
        "history": MessageLookupByLibrary.simpleMessage("Geschiedenis"),
        "home": MessageLookupByLibrary.simpleMessage("Home"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Identiteit Verifiëren"),
        "image": MessageLookupByLibrary.simpleMessage("Afbeelding"),
        "inHouseCantBeDelete": MessageLookupByLibrary.simpleMessage(
            "InHouse kan niet worden verwijderd"),
        "inHouseCantBeEdited": MessageLookupByLibrary.simpleMessage(
            "InHouse kan niet worden bewerkt"),
        "inWord": MessageLookupByLibrary.simpleMessage("In woorden"),
        "incTax": MessageLookupByLibrary.simpleMessage("Inclusief belasting"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Inclusief"),
        "increaseStock":
            MessageLookupByLibrary.simpleMessage("Verhoog voorraad"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Instrument"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Factuurnr."),
        "invoice": MessageLookupByLibrary.simpleMessage("Factuur"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("Factuurnummer"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Factuurinstelling"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Factuurweergave"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Item toegevoegd"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("KYC-verificatie"),
        "language": MessageLookupByLibrary.simpleMessage("Taal"),
        "lastName": MessageLookupByLibrary.simpleMessage("Achternaam"),
        "ledger": MessageLookupByLibrary.simpleMessage("Grootboek"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Levenslang\nKopen"),
        "link": MessageLookupByLibrary.simpleMessage("Link"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Live chat ondersteuning"),
        "loading": MessageLookupByLibrary.simpleMessage("Laden"),
        "logIn": MessageLookupByLibrary.simpleMessage("Inloggen"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Uitloggen"),
        "logOut": MessageLookupByLibrary.simpleMessage("Uitloggen"),
        "login": MessageLookupByLibrary.simpleMessage("Inloggen"),
        "logo": MessageLookupByLibrary.simpleMessage("Logo"),
        "loss": MessageLookupByLibrary.simpleMessage("Verlies"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Verlies/Winst"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Verlies/Winst Details"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Verlies/winstrapport"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Verlies/winstrapporten"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Lage voorraad waarschuwing"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Maak een blijvende indruk op uw klanten met op maat gemaakte facturen. Onze Unlimited Upgrade biedt het unieke voordeel van het aanpassen van uw facturen, wat een professionele uitstraling toevoegt die uw merkimago versterkt en klantenloyaliteit bevordert."),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("Beheer je bedrijf met"),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Productiedatum"),
        "margin": MessageLookupByLibrary.simpleMessage("Marge"),
        "masterCard": MessageLookupByLibrary.simpleMessage("Mastercard"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Fabrikant"),
        "message": MessageLookupByLibrary.simpleMessage("Bericht"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Berichtgeschiedenis"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Pos Saas-app is gratis en gemakkelijk te gebruiken. Sterker nog, het is een van de beste POS-systemen ter wereld."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas is een complete zakelijke oplossing met voorraad, rekeningen, verkoop, uitgaven en verlies/winst."),
        "mobile": MessageLookupByLibrary.simpleMessage("Mobiel"),
        "mobilePayment":
            MessageLookupByLibrary.simpleMessage("Mobiele betaling"),
        "monthly": MessageLookupByLibrary.simpleMessage("Maandelijks"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("Meer informatie"),
        "name": MessageLookupByLibrary.simpleMessage("Voer je naam in"),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Naam bestaat al"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("Naam mag niet leeg zijn"),
        "next": MessageLookupByLibrary.simpleMessage("Volgende"),
        "noConnection": MessageLookupByLibrary.simpleMessage("Geen verbinding"),
        "noData": MessageLookupByLibrary.simpleMessage("Geen Gegevens"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Geen gegevens beschikbaar"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Geen gegevens gevonden"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("Geen geschiedenis gevonden!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Geen product gevonden"),
        "noSubTaxSelected": MessageLookupByLibrary.simpleMessage(
            "Geen subbelasting geselecteerd"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("Geen transactie gevonden!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Geen gebruiker gevonden voor dat e-mailadres."),
        "noUserRoleFound":
            MessageLookupByLibrary.simpleMessage("Geen gebruikersrol gevonden"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Geen actieve gebruiker"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Niet opgegeven"),
        "note": MessageLookupByLibrary.simpleMessage("Notitie"),
        "notes": MessageLookupByLibrary.simpleMessage("Notities"),
        "notification": MessageLookupByLibrary.simpleMessage("Melding"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP verzonden naar"),
        "office": MessageLookupByLibrary.simpleMessage("Kantoor"),
        "ok": MessageLookupByLibrary.simpleMessage("Oké"),
        "openingBalance": MessageLookupByLibrary.simpleMessage("Startbalans"),
        "order": MessageLookupByLibrary.simpleMessage("Bestellingen"),
        "other": MessageLookupByLibrary.simpleMessage("Anders"),
        "otp": MessageLookupByLibrary.simpleMessage("Sluiten"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Niet op voorraad"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Pakket"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Pakket Functies"),
        "paid": MessageLookupByLibrary.simpleMessage("Betaald"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Betaald bedrag"),
        "parties": MessageLookupByLibrary.simpleMessage("Partijen"),
        "partiesList":
            MessageLookupByLibrary.simpleMessage("Lijst met partijen"),
        "partyGST": MessageLookupByLibrary.simpleMessage("Partij GST"),
        "partyName": MessageLookupByLibrary.simpleMessage("Partijnaam"),
        "password": MessageLookupByLibrary.simpleMessage("Wachtwoord"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Wachtwoord en bevestigingswachtwoord komen niet overeen"),
        "passwordCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Wachtwoord mag niet leeg zijn"),
        "passwordNotMach": MessageLookupByLibrary.simpleMessage(
            "Wachtwoord komt niet overeen"),
        "payCash": MessageLookupByLibrary.simpleMessage("Contant betalen"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("Betaal met bKash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Betaal met Paypal"),
        "payeeName": MessageLookupByLibrary.simpleMessage("Begunstigde Naam"),
        "payeeNumber":
            MessageLookupByLibrary.simpleMessage("Begunstigde Nummer"),
        "payment": MessageLookupByLibrary.simpleMessage("Betaling"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("Betaald Bedrag"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Betaling Voltooid"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Betalingsinstructies:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("Betaalmethode"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Betalingsmethode"),
        "pdfView": MessageLookupByLibrary.simpleMessage("Pdf-weergave"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Persoonlijke informatie"),
        "phone": MessageLookupByLibrary.simpleMessage("Telefoon"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Telefoonnummer"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Telefoonnummer is al in gebruik"),
        "phoneNumberIsNotValid": MessageLookupByLibrary.simpleMessage(
            "Telefoonnummer is niet geldig"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("Telefoonnummer is vereist"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("Kies en upload bestand"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("Selecteer einddatum"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Selecteer startdatum"),
        "plan": MessageLookupByLibrary.simpleMessage("Plan"),
        "pleaseAddQuantity": MessageLookupByLibrary.simpleMessage(
            "Voeg alstublieft hoeveelheid toe"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Controleer je internetverbinding"),
        "pleaseConnectThePrinterFirst":
            MessageLookupByLibrary.simpleMessage("Verbind eerst de printer"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Verbind alsjeblieft je Bluetooth-printer"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Voer een groter wachtwoord in"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Voer alstublieft een bevestigingswachtwoord in"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("Voer een wachtwoord in"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Voer een geldig e-mailadres in"),
        "pleaseEnterName": MessageLookupByLibrary.simpleMessage(
            "Voer alstublieft een naam in"),
        "pleaseEnterPassword": MessageLookupByLibrary.simpleMessage(
            "Voer a.u.b. het wachtwoord in"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Voer hieronder je e-mailadres in om een wachtwoordherstellink te ontvangen."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Voer alstublieft het transactienummer in"),
        "pleaseInterAmount": MessageLookupByLibrary.simpleMessage(
            "Voer alstublieft een bedrag in"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Selecteer eerst een categorie"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("Selecteer een plan"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Selecteer een bedrijfs categorie"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Gebruik de geldige aankoopcode om de app te gebruiken"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Aangedreven door Pos Saas"),
        "poweredBy":
            MessageLookupByLibrary.simpleMessage("Mogelijk gemaakt door"),
        "premiumCustomerSupport": MessageLookupByLibrary.simpleMessage(
            "Premium klantenondersteuning"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Premium Plan"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Eerdere betaalbedragen"),
        "price": MessageLookupByLibrary.simpleMessage("Prijs"),
        "print": MessageLookupByLibrary.simpleMessage("Afdrukken"),
        "printingOption": MessageLookupByLibrary.simpleMessage("Afdrukoptie"),
        "privacyPolicy": MessageLookupByLibrary.simpleMessage("Privacybeleid"),
        "product": MessageLookupByLibrary.simpleMessage("Product"),
        "productCode": MessageLookupByLibrary.simpleMessage("Productcode"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("Productcode is vereist"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Productcode/Naam"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Productbeschrijving"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Productdetails"),
        "productList": MessageLookupByLibrary.simpleMessage("Productlijst"),
        "productName": MessageLookupByLibrary.simpleMessage("Productnaam"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Productnaam bestaat al in dit magazijn"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Productnaam is al toegevoegd"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("Productnaam is vereist"),
        "products": MessageLookupByLibrary.simpleMessage("Producten"),
        "profile": MessageLookupByLibrary.simpleMessage("Profiel"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("Profiel bewerken"),
        "profit": MessageLookupByLibrary.simpleMessage("Winst"),
        "promo": MessageLookupByLibrary.simpleMessage("Promotie"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Promocode"),
        "purchase": MessageLookupByLibrary.simpleMessage("Aankoop"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage("Aankoop Alarm"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Aankoop Bevestigd"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Aankoopdetails"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Aankoopfactuur"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("Aankooplijst"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Nu kopen"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Koop Premium Plan"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("Inkoopprijs"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("Aankoopprijs is vereist"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("Aankooprapport"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Inkooprapporten"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Inkooprapporten"),
        "purchaseReturn": MessageLookupByLibrary.simpleMessage("Aankoopretour"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("Aankoopretourrapport"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Aankoopovergang"),
        "qty": MessageLookupByLibrary.simpleMessage("Aantal"),
        "quantity": MessageLookupByLibrary.simpleMessage("Hoeveelheid"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Recente transacties"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("De pin ontvangen"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Referentienummer"),
        "register": MessageLookupByLibrary.simpleMessage("Registreren"),
        "registering": MessageLookupByLibrary.simpleMessage("Registreren"),
        "remainingDue":
            MessageLookupByLibrary.simpleMessage("Resterende Te Betalen"),
        "remove": MessageLookupByLibrary.simpleMessage("Verwijderen"),
        "reports": MessageLookupByLibrary.simpleMessage("Rapporten"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Verzoek is verzonden"),
        "resendCode":
            MessageLookupByLibrary.simpleMessage("Code opnieuw verzenden"),
        "resendOtp":
            MessageLookupByLibrary.simpleMessage("Stuur OTP opnieuw: "),
        "retailer": MessageLookupByLibrary.simpleMessage("Winkelier"),
        "retur": MessageLookupByLibrary.simpleMessage("Terugkeer"),
        "returN": MessageLookupByLibrary.simpleMessage("Retour"),
        "returnAMount":
            MessageLookupByLibrary.simpleMessage("Terugbetalingsbedrag"),
        "returnAmount":
            MessageLookupByLibrary.simpleMessage("Terugbetalingsbedrag"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("Retourhoeveelheid"),
        "revenue": MessageLookupByLibrary.simpleMessage("Inkomsten"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Beveilig uw bedrijfsgegevens moeiteloos. Onze Pos Saas POS Unlimited Upgrade is inclusief gratis gegevensback-up, waardoor uw waardevolle informatie beschermd is tegen onvoorziene gebeurtenissen. Richt u op wat echt belangrijk is: de groei van uw bedrijf."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Verkoopbedrag"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("Verkoopdetails"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Verkoopprijs"),
        "saleReports": MessageLookupByLibrary.simpleMessage("Verkooprapport"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Verkooprapporten"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("Verkoopretour"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Verkoopretourrapport"),
        "saleSetting":
            MessageLookupByLibrary.simpleMessage("Verkoopinstelling"),
        "sales": MessageLookupByLibrary.simpleMessage("Verkopen"),
        "salesList": MessageLookupByLibrary.simpleMessage("Verkooplijst"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("Verkoop retour"),
        "save": MessageLookupByLibrary.simpleMessage("Opslaan"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Opslaan en publiceren"),
        "saveChanges":
            MessageLookupByLibrary.simpleMessage("Wijzigingen opslaan"),
        "saving": MessageLookupByLibrary.simpleMessage("Opslaan"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("Scan product QR-code"),
        "search": MessageLookupByLibrary.simpleMessage("Zoeken"),
        "searchByProductCodeOrName":
            MessageLookupByLibrary.simpleMessage("Zoek op productcode of naam"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("Bekijk alle promocodes"),
        "select": MessageLookupByLibrary.simpleMessage("Selecteer"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Selecteer een product voor retour"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Selecteer merk"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Selecteer categorie"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Contacten selecteren"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("Selecteer productcategorie"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("Selecteer winkelcategorie"),
        "selectTax":
            MessageLookupByLibrary.simpleMessage("Selecteer belasting"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Selecteer belastingtype"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("Selecteer eenheid"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Selecteer Variatie: "),
        "seller": MessageLookupByLibrary.simpleMessage("Verkoper"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Verkocht door"),
        "send": MessageLookupByLibrary.simpleMessage("Versturen"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("E-mail Verzenden"),
        "sendMessage":
            MessageLookupByLibrary.simpleMessage("Bericht verzenden"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("Stuur herstellink"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Sms Verzenden"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Sms verzenden?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Stuur WhatsApp-bericht"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Verstuur uw e-mail"),
        "sendingEmail":
            MessageLookupByLibrary.simpleMessage("E-mail verzenden"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Bericht verzenden"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Service/Verzending"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Stel je profiel in"),
        "setting": MessageLookupByLibrary.simpleMessage("Instellingen"),
        "share": MessageLookupByLibrary.simpleMessage("Delen"),
        "shopGST": MessageLookupByLibrary.simpleMessage("Winkel GST"),
        "signIn": MessageLookupByLibrary.simpleMessage("Inloggen"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("Inloggen met e-mail"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Handtekening van klant"),
        "size": MessageLookupByLibrary.simpleMessage("Maat"),
        "skip": MessageLookupByLibrary.simpleMessage("Overslaan"),
        "sms": MessageLookupByLibrary.simpleMessage("Sms"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Sociale Marketing"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Sorry, u heeft geen toestemming om deze service te gebruiken"),
        "startDate": MessageLookupByLibrary.simpleMessage("Startdatum"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Nieuwe Verkoop Starten"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage(
            "Begin met typen om te zoeken"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Blijf voorop lopen op het gebied van technologische ontwikkelingen zonder extra kosten. Onze Pos Saas POS Unlimited Upgrade zorgt ervoor dat u altijd de nieuwste tools en functies binnen handbereik hebt, waardoor uw bedrijf altijd cutting-edge blijft."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("Nog niet betaald"),
        "stock": MessageLookupByLibrary.simpleMessage("Voorraad"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Voorraad is vereist"),
        "stockList": MessageLookupByLibrary.simpleMessage("Voorraadlijst"),
        "stocks": MessageLookupByLibrary.simpleMessage("Voorraad"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Opslag toestemming is vereist om een Excel-bestand te maken"),
        "subTaxList":
            MessageLookupByLibrary.simpleMessage("Lijst van subbelastingen"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Subbelastingen"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Subtotaal"),
        "submit": MessageLookupByLibrary.simpleMessage("Verzenden"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "Abonneer je op onze\\nYoutube"),
        "subscription": MessageLookupByLibrary.simpleMessage("Abonnement"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Succesvol gedaan"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Succesvol uitgelogd"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Succesvol bijgewerkt"),
        "supplier": MessageLookupByLibrary.simpleMessage("Leverancier"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("Naam leverancier"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT-code"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Neem een ​​rijbewijs, identiteitskaart van de overheid of paspoortfoto"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "Neem een identiteitskaart om uw informatie te controleren"),
        "tap": MessageLookupByLibrary.simpleMessage("Tik"),
        "tax": MessageLookupByLibrary.simpleMessage("Belasting"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Belastinggroep"),
        "taxPercentage":
            MessageLookupByLibrary.simpleMessage("Belastingpercentage"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Belastingtarief"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Belastingtarieven - Beheer uw belastingtarieven"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Belastingrapport"),
        "taxType": MessageLookupByLibrary.simpleMessage("Belastingtype"),
        "taxes": MessageLookupByLibrary.simpleMessage("Belastingen"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Algemene voorwaarden"),
        "termsOfUse":
            MessageLookupByLibrary.simpleMessage("Gebruiksvoorwaarden"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Voorwaarden & Privacy"),
        "thankYOuForYourDuePayment":
            MessageLookupByLibrary.simpleMessage("Bedankt voor uw betaling"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Dank je"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Bedankt voor uw aankoop"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "Het account bestaat al voor dat e-mailadres"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Het Excel-bestand is al gedownload"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "De naam zegt het al. Met Pos Saas POS Unlimited is er geen limiet aan uw gebruik. Of u nu een handvol transacties verwerkt of te maken krijgt met een stroom van klanten, u kunt met vertrouwen opereren, wetende dat u niet beperkt wordt door limieten."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "Het opgegeven wachtwoord is te zwak"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "De verkoop zal worden verwijderd en alle gegevens over deze aankoop worden verwijderd. Weet je zeker dat je dit wilt verwijderen?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "De verkoop zal worden verwijderd en alle gegevens over deze verkoop worden verwijderd. Weet je zeker dat je dit wilt verwijderen?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "De gebruiker wordt verwijderd en alle gegevens worden uit je account verwijderd. Weet je zeker dat je dit wilt verwijderen?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "De gebruiker wordt verwijderd en alle gegevens worden van uw account verwijderd. Weet u zeker dat u dit wilt verwijderen?"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Deze categorie kan niet worden verwijderd"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Deze maand)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Dit product is al toegevoegd"),
        "title": MessageLookupByLibrary.simpleMessage("Titel"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Titel mag niet leeg zijn"),
        "to": MessageLookupByLibrary.simpleMessage("tot"),
        "toDate": MessageLookupByLibrary.simpleMessage("Tot Datum"),
        "today": MessageLookupByLibrary.simpleMessage("Vandaag"),
        "total": MessageLookupByLibrary.simpleMessage("Totaal"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Totaalbedrag"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Totaal verzameld"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Totaal Te Betalen"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("Totaal Uitgave"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Totaal verlies"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("Totaal Te Betalen"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Totale Prijs"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("Totaal aantal producten"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Totaal winst"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("Totaal aankoop"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Totaal retourbedrag"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("Totaal retouren"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Totale Verkoop"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Totaal Voorraad"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Totaalwaarde"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Totaal BTW"),
        "totals": MessageLookupByLibrary.simpleMessage("Totaal: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Transactie"),
        "transactionId": MessageLookupByLibrary.simpleMessage("Transactie-id"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Probeer opnieuw"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Type"),
        "unitName": MessageLookupByLibrary.simpleMessage("Naam eenheid"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Eenheidsprijs"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Prijs per eenheid"),
        "units": MessageLookupByLibrary.simpleMessage("Eenheden"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Onbeperkt"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Onbeperkt gebruik"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Ontgrendel het volledige potentieel van Pos Saas POS met gepersonaliseerde trainingssessies geleid door ons deskundige team. Van de basisprincipes tot geavanceerde technieken zorgen we ervoor dat u goed thuis bent in het gebruik van elk facet van het systeem om uw bedrijfsprocessen te optimaliseren."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Onbetaald"),
        "update": MessageLookupByLibrary.simpleMessage("Bijwerken"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Contact bijwerken"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Nu bijwerken"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("Product bijwerken"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Update eerst uw plan, uw limiet is overschreden"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Werk je profiel bij"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Werk je profiel bij om je arts te verbinden met een betere indruk"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Werk je profiel bij om je klant beter te kunnen verbinden"),
        "updated": MessageLookupByLibrary.simpleMessage("Bijgewerkt"),
        "upload": MessageLookupByLibrary.simpleMessage("Uploaden"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Document uploaden"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("Uploaden voltooid"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Bestand uploaden"),
        "usbC": MessageLookupByLibrary.simpleMessage("Usb C"),
        "use": MessageLookupByLibrary.simpleMessage("Gebruik"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("Gebruik Pos Saas"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Gebruiker is verwijderd"),
        "userRole": MessageLookupByLibrary.simpleMessage("Gebruikersrol"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("Gebruikersrol details"),
        "userTitle": MessageLookupByLibrary.simpleMessage("Gebruikerstitel"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Gebruikerstitel mag niet leeg zijn"),
        "value": MessageLookupByLibrary.simpleMessage("Waarde"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("BTW is niet van toepassing"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("OTP verifiëren"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Verifieer telefoonnummer"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Alles bekijken"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("Details bekijken"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Klant zonder afspraak"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Magazijn"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Magazijn bestaat al"),
        "warehouseList":
            MessageLookupByLibrary.simpleMessage("Lijst van magazijnen"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("Magazijnnaam"),
        "warranty": MessageLookupByLibrary.simpleMessage("Garantie"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "We hebben een e-mail gestuurd met instructies over hoe je het wachtwoord opnieuw kunt instellen naar:"),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Wij begrijpen het belang van naadloze bedrijfsvoering. Daarom is onze 24/7 ondersteuning beschikbaar om u te helpen, of het nu om een snelle vraag of een uitgebreide zorg gaat. Neem op elk moment, overal contact met ons op via telefoon of WhatsApp om ongeëvenaarde klantenservice te ervaren."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "We zullen de betaling beoordelen en deze binnen 1-2 uur goedkeuren"),
        "weekly": MessageLookupByLibrary.simpleMessage("Wekelijks"),
        "weight": MessageLookupByLibrary.simpleMessage("Gewicht"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Wat is nieuw"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Groothandelaar"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Groothandelsprijs"),
        "wholesalePrice":
            MessageLookupByLibrary.simpleMessage("Groothandelsprijs"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Groothandelaar"),
        "willBeAddedSoon": MessageLookupByLibrary.simpleMessage(
            "Zal binnenkort worden toegevoegd"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Verloopt op"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Schrijf hier uw bericht"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("Verkeerde OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Verkeerd wachtwoord ingevoerd voor die gebruiker."),
        "yearly": MessageLookupByLibrary.simpleMessage("Jaarlijks"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Ja, definitief verwijderen"),
        "youAreNotAValidUser": MessageLookupByLibrary.simpleMessage(
            "Je bent geen geldige gebruiker"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("U gebruikt"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "U kunt niet meer betalen dan verschuldigd"),
        "youHaveGotAnEmail": MessageLookupByLibrary.simpleMessage(
            "Je hebt een e-mail ontvangen"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Je bent succesvol ingelogd op je account. Blijf bij Pos Saas."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("U moet toestemming geven"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "U moet opnieuw inloggen op uw account."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Je moet je identiteit verifiëren voordat je sms koopt"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Uw bericht blijft"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Uw Pakket"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Uw Pakket Verloopt over 5 Dagen")
      };
}
