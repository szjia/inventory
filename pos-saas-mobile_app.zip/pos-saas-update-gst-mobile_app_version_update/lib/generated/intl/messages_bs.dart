// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a bs locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'bs';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Nastavi"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("Broj PDV-a"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MPV"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("MRP je obavezan"),
        "OK": MessageLookupByLibrary.simpleMessage("OK"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Br.tel"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT Kod"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Grickalice"),
        "TAX": MessageLookupByLibrary.simpleMessage("Porez"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Učitavanje"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("Naslov korisnika"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Vaš paket ističe danas\nMolimo kupite ponovo"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) Sistem je namijenjen isključivo za olakšavanje transakcija na tačkama prodaje i srodnih aktivnosti u vašem poslovanju."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) Da biste koristili Sistem, možda ćete morati kreirati nalog. Slažete se da ćete tokom procesa registracije pružiti tačne, trenutne i potpune informacije, i ažurirati takve informacije da biste ih održavali tačnim i potpunim."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("O aplikaciji"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("O nama"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Prihvatanje uslova"),
        "accountName": MessageLookupByLibrary.simpleMessage("Naziv računa"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("Broj računa"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Registracija naloga"),
        "acton": MessageLookupByLibrary.simpleMessage("Akcija"),
        "add": MessageLookupByLibrary.simpleMessage("Dodaj"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Dodaj brend"),
        "addCategory": MessageLookupByLibrary.simpleMessage("Dodaj kategoriju"),
        "addContact": MessageLookupByLibrary.simpleMessage("Dodaj kontakt"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Dodaj kupca"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("Dodaj dostavu"),
        "addDescriptioN": MessageLookupByLibrary.simpleMessage("Dodaj opis"),
        "addDescription":
            MessageLookupByLibrary.simpleMessage("Dodaj bilješku"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Dodajte popust"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Dodajte ID dokumenta"),
        "addDucument": MessageLookupByLibrary.simpleMessage("Dodaj dokument"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Dodaj trošak"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Dodaj kategoriju troška"),
        "addItems": MessageLookupByLibrary.simpleMessage("Dodaj artikle"),
        "addNew": MessageLookupByLibrary.simpleMessage("Dodaj novo"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Dodaj novu adresu"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Dodaj novi proizvod"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("Dodaj Novi Porez"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Dodaj Novi Porez sa jednim/više tipova poreza"),
        "addNote": MessageLookupByLibrary.simpleMessage("Dodaj bilješku"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Prvo dodajte proizvod"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Dodajte promo kod"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Dodaj kupovinu"),
        "addSales": MessageLookupByLibrary.simpleMessage("Dodaj prodaju"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Uspješno dodano"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Dodaj jedinicu"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Dodaj korisničku ulogu"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Uspješno dodano"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("Dodano u košaricu"),
        "address": MessageLookupByLibrary.simpleMessage("Adresa"),
        "admin": MessageLookupByLibrary.simpleMessage("Administrator"),
        "all": MessageLookupByLibrary.simpleMessage("Sve"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("Sva poslovna rješenja"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("Već dodano"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Već Postoji"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Već imate račun"),
        "amount": MessageLookupByLibrary.simpleMessage("Iznos"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "E-pošta je poslana\\nProvjerite pristiglu poštu"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Podrška za Android i iOS aplikacije"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Primjenjivi porez"),
        "apply": MessageLookupByLibrary.simpleMessage("Primijeni"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Jeste li sigurni da želite izbrisati ovu fakturu"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Jeste li sigurni da želite obrisati ovu prodaju"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Da li ste sigurni da želite izbrisati ovog korisnika"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Jeste li sigurni da želite izbrisati ovaj porez"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Jeste li sigurni da želite izbrisati ovu poresku grupu"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Da li želite izbrisati ovo skladište"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Jeste li sigurni da želite izbrisati ovog korisnika?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Ovlašteni Potpis"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Vi ste odgovorni za očuvanje povjerljivosti vašeg naloga i lozinke, i ograničavanje pristupa vašem nalogu. Prihvatate odgovornost za sve aktivnosti koje se dešavaju pod vašim nalogom."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Mora te imati najmanje 18 godina ili zakonsku punu godinu u svojoj nadležnosti da biste koristili Sistem."),
        "backSide": MessageLookupByLibrary.simpleMessage("Zadnja strana"),
        "backToHome":
            MessageLookupByLibrary.simpleMessage("Nazad na početnu stranicu"),
        "balance": MessageLookupByLibrary.simpleMessage("Bilans"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladeš"),
        "bank": MessageLookupByLibrary.simpleMessage("Banka"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Valuta Bankovnog Računa"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Valuta bankovnog računa"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Bankovni podaci"),
        "bankName": MessageLookupByLibrary.simpleMessage("Naziv banke"),
        "bankTransfer":
            MessageLookupByLibrary.simpleMessage("Bankovni Transfer"),
        "barcodeFound": MessageLookupByLibrary.simpleMessage("Barkod pronađen"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Račun/Faktura"),
        "billTo": MessageLookupByLibrary.simpleMessage("Platiti na"),
        "branchName": MessageLookupByLibrary.simpleMessage("Naziv podružnice"),
        "brand": MessageLookupByLibrary.simpleMessage("Brend"),
        "brandName": MessageLookupByLibrary.simpleMessage("Ime brenda"),
        "bulkUpload":
            MessageLookupByLibrary.simpleMessage("Masovno\nučitavanje"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Kategorija poslovanja"),
        "buy": MessageLookupByLibrary.simpleMessage("Kupi"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Kupite Premium plan"),
        "buySms": MessageLookupByLibrary.simpleMessage("Kupi SMS-ove"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Prilikom pristupa ili korištenja Sistema tačke prodaje (Point of Sale - POS) (\"Sistem\") koji obezbjeđuje [Naziv Vaše Kompanije] (\"Kompanija\"), slažete se da ste obavezani ovim Uslovima korištenja. Ako se ne slažete sa ovim Uslovima korištenja, nemojte koristiti Sistem."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Vi ste odgovorni za osiguranje da je vaš pristup i korištenje Sistema u skladu sa svim važećim zakonima i propisima."),
        "cacel": MessageLookupByLibrary.simpleMessage("Otkazati"),
        "call": MessageLookupByLibrary.simpleMessage("Poziv"),
        "callForEmergencySupport":
            MessageLookupByLibrary.simpleMessage("Pozovite za Hitnu Podršku"),
        "camera": MessageLookupByLibrary.simpleMessage("Kamera"),
        "cancel": MessageLookupByLibrary.simpleMessage("Otkaži"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Otkaži sve proizvode"),
        "capacity": MessageLookupByLibrary.simpleMessage("Kapacitet"),
        "card": MessageLookupByLibrary.simpleMessage("Kartica"),
        "cash": MessageLookupByLibrary.simpleMessage("Gotovina"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Kategorije"),
        "category": MessageLookupByLibrary.simpleMessage("Kategorija"),
        "categoryName":
            MessageLookupByLibrary.simpleMessage("Naziv kategorije"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "Naziv kategorije već postoji"),
        "cateogryName":
            MessageLookupByLibrary.simpleMessage("Naziv kategorije"),
        "change": MessageLookupByLibrary.simpleMessage("Promijeniti?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Promijeni lozinku"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("Provjeri email"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Izaberite kupca"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Izaberite dobavljača"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Izaberite svoje mogućnosti"),
        "clarence": MessageLookupByLibrary.simpleMessage("Klerens"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Kliknite za povezivanje"),
        "close": MessageLookupByLibrary.simpleMessage("Zatvori"),
        "color": MessageLookupByLibrary.simpleMessage("Boja"),
        "combinationOfMultipleTaxes":
            MessageLookupByLibrary.simpleMessage("(Kombinacija više poreza)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Uskoro"),
        "companyAddress": MessageLookupByLibrary.simpleMessage("Adresa tvrtke"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Naziv tvrtke i dućana"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("Ime Kompanije i Poslovanja"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Završi transakciju"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Potvrdi lozinku"),
        "confirmReturn": MessageLookupByLibrary.simpleMessage("Potvrdi povrat"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Čestitamo"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Kontaktirajte nas"),
        "continu": MessageLookupByLibrary.simpleMessage("Nastavi"),
        "country": MessageLookupByLibrary.simpleMessage("Država"),
        "create": MessageLookupByLibrary.simpleMessage("Kreiraj"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Kreirajte besplatan račun"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Kreirano i Sačuvano"),
        "currency": MessageLookupByLibrary.simpleMessage("Valuta"),
        "currentStock": MessageLookupByLibrary.simpleMessage("Trenutna zaliha"),
        "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
            "Prilagođeno označavanje računa"),
        "customer": MessageLookupByLibrary.simpleMessage("Kupac"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Detalji kupca"),
        "customerGST": MessageLookupByLibrary.simpleMessage("PDV kupca"),
        "customerName": MessageLookupByLibrary.simpleMessage("Ime kupca"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Dnevna transakcija"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Pregled nadzorne table"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Podaci su uspješno sačuvani"),
        "date": MessageLookupByLibrary.simpleMessage("Datum"),
        "day": MessageLookupByLibrary.simpleMessage("Dan"),
        "dealer": MessageLookupByLibrary.simpleMessage("Trgovac"),
        "dealerPrice":
            MessageLookupByLibrary.simpleMessage("Cijena za trgovca"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("Zadani postotak PDV-a"),
        "delete": MessageLookupByLibrary.simpleMessage("Obriši"),
        "deleting": MessageLookupByLibrary.simpleMessage("Brisanje"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Adresa dostave"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Adrese za dostavu"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Trošak dostave"),
        "describtion": MessageLookupByLibrary.simpleMessage("Opis"),
        "description": MessageLookupByLibrary.simpleMessage("Opis"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Opis ne može biti prazan"),
        "details": MessageLookupByLibrary.simpleMessage("Detalji"),
        "discount": MessageLookupByLibrary.simpleMessage("Popust"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Ne ometaj"),
        "done": MessageLookupByLibrary.simpleMessage("Završeno"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Preuzmi Excel format"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Uspješno preuzeto u mapu za preuzimanja"),
        "due": MessageLookupByLibrary.simpleMessage("Dug"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Iznos duga: "),
        "dueCollection": MessageLookupByLibrary.simpleMessage("Inkaso duga"),
        "dueCollectionReports": MessageLookupByLibrary.simpleMessage(
            "Izvještaji o dugu za naplatu"),
        "dueList": MessageLookupByLibrary.simpleMessage("Popis dugovanja"),
        "dueReports":
            MessageLookupByLibrary.simpleMessage("Izvještaji o dugovanjima"),
        "duration": MessageLookupByLibrary.simpleMessage("Trajanje"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Trajanje: Od"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "Jednostavan za korištenje mobilni POS"),
        "edit": MessageLookupByLibrary.simpleMessage("Uredi"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Uredi fakturu kupovine"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Uredi fakturu prodaje"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Uredi društvene medije"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Uspješno uređeno"),
        "editTax": MessageLookupByLibrary.simpleMessage("Uredi porez"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Uredi poresku grupu"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("Uredi skladište"),
        "email": MessageLookupByLibrary.simpleMessage("Email"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("Email Adresa"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Email ne može biti prazan"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "Email poslan! Provjerite inbox"),
        "endDate": MessageLookupByLibrary.simpleMessage("Krajnji datum"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Unesite važeći iznos"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Unesite važeći popust"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Unesite važeći broj telefona"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Unesite važeću cijenu"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("Unesite važeću količinu"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("Unesite adresu"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("Unesite iznos."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Unesite ime brenda"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Unesite kapacitet"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Unesite ime kategorije"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Unesite boju"),
        "enterCustomerGstNumber":
            MessageLookupByLibrary.simpleMessage("Unesite PDV broj kupca"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Unesite cijenu za trgovca"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Unesite opis"),
        "enterDiscount": MessageLookupByLibrary.simpleMessage("Unesite popust"),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Unesite datum troška"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Unesite punu adresu"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Unesite broj fakture"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Unesite količinu za upozorenje niske zalihe"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Unesite proizvođača"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("Unesite sadržaj poruke"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "Unesite MPV/cijenu za maloprodaju"),
        "enterName": MessageLookupByLibrary.simpleMessage("Unesite ime"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Unesite bilješku"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Unesite ime stranke"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Unesite broj telefona"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Unesite šifru proizvoda ili skenirajte"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Unesite ime proizvoda"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Unesite cijenu kupovine"),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("Unesite referentni broj"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Unesite veličinu"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("Unesite zalihe"),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Unesite poreznu stopu"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("Unesite ID transakcije"),
        "enterType": MessageLookupByLibrary.simpleMessage("Unesite tip"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("Unesite naslov korisnika"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Unesite važeći iznos"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Unesite naziv skladišta"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Unesite težinu"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Unesite cijenu veleprodaje"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("Unesite opis ovde"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("Unesite vašu email adresu"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "Unesite naslov povratnih informacija"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Unesite broj vašeg PDV-a"),
        "enterYourMobileNumber": MessageLookupByLibrary.simpleMessage(
            "Unesite svoj broj mobilnog telefona"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Unesite svoje ime"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("Unesite vaš broj telefona"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Unesite svoju lozinku"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Unesite vaš broj telefona"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "Unesite ID svoje transakcije"),
        "error": MessageLookupByLibrary.simpleMessage("Greška"),
        "excTax": MessageLookupByLibrary.simpleMessage("Isklj. porez"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("Excel Uploader"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Isključen"),
        "expense": MessageLookupByLibrary.simpleMessage("Trošak"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Kategorija troška"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Datum troška"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Trošak za"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Izvještaj o troškovima"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Datum isteka"),
        "expired": MessageLookupByLibrary.simpleMessage("Isteklo"),
        "expiring": MessageLookupByLibrary.simpleMessage("Ističe"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Neuspješno sa greškom"),
        "fashion": MessageLookupByLibrary.simpleMessage("Moda"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Mogućnosti su važan dio koji čini Pos Saas drugačijim od tradicionalnih rješenja."),
        "feedBack":
            MessageLookupByLibrary.simpleMessage("Povratne informacije"),
        "firstName": MessageLookupByLibrary.simpleMessage("Ime"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Pratite nas na Facebook-u"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Pratite nas na Twitter-u"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Prednja strana"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("Za neograničenu upotrebu"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Zaboravili ste lozinku"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Zaboravili ste lozinku?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Od datuma"),
        "freeDataBackup": MessageLookupByLibrary.simpleMessage(
            "Besplatno sigurnosno kopiranje podataka"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "Besplatno doživotno ažuriranje"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Besplatni paket"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Besplatni plan"),
        "from": MessageLookupByLibrary.simpleMessage("(Od"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Potpuno Plaćeno"),
        "gallary": MessageLookupByLibrary.simpleMessage("Galerija"),
        "generatingPDF":
            MessageLookupByLibrary.simpleMessage("Generisanje PDF-a"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Dobijte OTP"),
        "govermentId": MessageLookupByLibrary.simpleMessage("Vladin ID"),
        "guest": MessageLookupByLibrary.simpleMessage("Gost"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Nemate račun?"),
        "history": MessageLookupByLibrary.simpleMessage("Istorija"),
        "home": MessageLookupByLibrary.simpleMessage("Početna"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Kako štitimo vaše informacije"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Kako koristimo vaše informacije"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Verifikacija identiteta"),
        "image": MessageLookupByLibrary.simpleMessage("Slika"),
        "inHouseCantBeDelete": MessageLookupByLibrary.simpleMessage(
            "InHouse se ne može izbrisati"),
        "inHouseCantBeEdited": MessageLookupByLibrary.simpleMessage(
            "InHouse se ne može uređivati"),
        "inWord": MessageLookupByLibrary.simpleMessage("Riječima"),
        "incTax": MessageLookupByLibrary.simpleMessage("Uklj. porez"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Uključen"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("Povećaj zalihe"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Instrument"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Br. fakture"),
        "invoice": MessageLookupByLibrary.simpleMessage("Faktura"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("Broj fakture"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Podešavanje fakture"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Preglednik faktura"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Artikal dodan"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("Verifikacija KYC"),
        "language": MessageLookupByLibrary.simpleMessage("Jezik"),
        "lastName": MessageLookupByLibrary.simpleMessage("Prezime"),
        "ledger": MessageLookupByLibrary.simpleMessage("Knjigovodstvo"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Doživotna\nkupovina"),
        "link": MessageLookupByLibrary.simpleMessage("Link"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Podrška putem Chat-a"),
        "loading": MessageLookupByLibrary.simpleMessage("Učitavanje"),
        "logIn": MessageLookupByLibrary.simpleMessage("Prijava"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Odjava"),
        "logOut": MessageLookupByLibrary.simpleMessage("Odjava"),
        "login": MessageLookupByLibrary.simpleMessage("Prijava"),
        "logo": MessageLookupByLibrary.simpleMessage("Logo"),
        "loss": MessageLookupByLibrary.simpleMessage("Gubitak"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Gubitak/Dobit"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Detalji gubitka/dobiti"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Izvještaj o Gubitku/Profitu"),
        "lossProfitReports": MessageLookupByLibrary.simpleMessage(
            "Izvještaji o Gubitku/Profitu"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Upozorenje za nisku zalihu"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Ostavite trajan dojam na svoje klijente s personaliziranim računima. Naš Unlimited Upgrade nudi jedinstvenu prednost prilagođavanja vaših računa, dodajući profesionalni dodir koji jača vaš identitet marke i potiče vjernost kupaca."),
        "manageYourBussinessWith": MessageLookupByLibrary.simpleMessage(
            "Upravljajte vašim poslovanjem uz "),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Datum proizvodnje"),
        "margin": MessageLookupByLibrary.simpleMessage("Marža"),
        "masterCard": MessageLookupByLibrary.simpleMessage("Mastercard"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Proizvođač"),
        "message": MessageLookupByLibrary.simpleMessage("Poruka"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Istorija poruka"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Pos Saas aplikacija je besplatna i jednostavna za korištenje. Zapravo, to je jedan od najboljih POS sistema širom sveta."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas je potpuno poslovno rješenje sa zalihama, računima, prodajom, troškovima i gubicima/prihodom."),
        "mobile": MessageLookupByLibrary.simpleMessage("Mobilni"),
        "mobilePayment":
            MessageLookupByLibrary.simpleMessage("Mobilno plaćanje"),
        "monthly": MessageLookupByLibrary.simpleMessage("Mjesečno"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("Više informacija"),
        "name": MessageLookupByLibrary.simpleMessage("Unesite vaše ime."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Ime već postoji"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("Ime ne može biti prazno"),
        "next": MessageLookupByLibrary.simpleMessage("Sljedeći"),
        "noConnection": MessageLookupByLibrary.simpleMessage("Nema veze"),
        "noData": MessageLookupByLibrary.simpleMessage("Nema podataka"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Nema dostupnih podataka"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Podaci nisu pronađeni"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("Nema pronađene istorije!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Nije pronađen proizvod"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("Nije odabran pod-porez"),
        "noTransactionFound": MessageLookupByLibrary.simpleMessage(
            "Nema pronađenih transakcija!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Nema korisnika s tom email adresom."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "Nema pronađenih korisničkih uloga"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Nije Aktivni Korisnik"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Nije dostupno"),
        "note": MessageLookupByLibrary.simpleMessage("Bilješka"),
        "notes": MessageLookupByLibrary.simpleMessage("bilješke"),
        "notification": MessageLookupByLibrary.simpleMessage("Obavijest"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP poslan na"),
        "office": MessageLookupByLibrary.simpleMessage("Ured"),
        "ok": MessageLookupByLibrary.simpleMessage("U redu"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS sistem koji sadrži mnogo funkcionalnosti, uključujući praćenje prodaje i upravljanje inventarom."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Ovaj sistem vam pomaže da unaprijedite svoje operacije za svoje kupce."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Naš POS sistem treba automatski pojednostaviti svakodnevne operacije, čineći navigaciju lakom."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("Početno stanje"),
        "order": MessageLookupByLibrary.simpleMessage("Narudžbe"),
        "other": MessageLookupByLibrary.simpleMessage("Ostalo"),
        "otp": MessageLookupByLibrary.simpleMessage("Zatvori"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Nema na zalihi"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Paket"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Mogućnosti paketa"),
        "paid": MessageLookupByLibrary.simpleMessage("Plaćeno"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Uplaćeni iznos"),
        "parties": MessageLookupByLibrary.simpleMessage("Strane"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Lista stranaka"),
        "partyGST": MessageLookupByLibrary.simpleMessage("PDV stranke"),
        "partyName": MessageLookupByLibrary.simpleMessage("Ime stranke"),
        "password": MessageLookupByLibrary.simpleMessage("Lozinka"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Lozinka i potvrda lozinke se ne podudaraju"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Lozinka ne može biti prazna"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("Lozinka se ne podudara"),
        "payCash": MessageLookupByLibrary.simpleMessage("Platite gotovinom"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("Platite putem bkash-a"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Platite putem Paypala"),
        "payeeName": MessageLookupByLibrary.simpleMessage("Ime primaoca"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("Broj primaoca"),
        "payment": MessageLookupByLibrary.simpleMessage("Plaćanje"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("Iznos plaćanja"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Plaćanje završeno"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Instrukcije za plaćanje:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("Način Plaćanja"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Način plaćanja"),
        "pdfView": MessageLookupByLibrary.simpleMessage("PDF Pregled"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Lični podaci"),
        "phone": MessageLookupByLibrary.simpleMessage("Telefon"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Broj telefona"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Broj telefona je već iskorišten"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("Broj telefona nije važeći"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("Broj telefona je obavezan"),
        "pickAndUploadFile": MessageLookupByLibrary.simpleMessage(
            "Odaberite i učitajte datoteku"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("Izaberite krajnji datum"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Izaberite početni datum"),
        "plan": MessageLookupByLibrary.simpleMessage("Plan"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("Molimo dodajte količinu"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Molimo provjerite svoju internet vezu"),
        "pleaseConnectThePrinterFirst":
            MessageLookupByLibrary.simpleMessage("Molimo spojite printer prvo"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Molimo povežite svoj Bluetooth printer"),
        "pleaseEnterABiggerPassword":
            MessageLookupByLibrary.simpleMessage("Molimo unesite dužu lozinku"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Molimo unesite potvrdu lozinke"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("Molimo unesite lozinku"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Molimo unesite ispravan email"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Molimo unesite ime"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("Unesite lozinku"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Molimo unesite vašu email adresu u nastavku kako biste primili vezu za resetiranje lozinke."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Molimo unesite broj transakcije"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("Molimo unesite iznos"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Molimo odaberite kategoriju prvo"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("Molimo odaberite plan"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Molimo odaberite kategoriju poslovanja"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Molimo koristite važeći kod kupovine za korištenje aplikacije"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Pokreće Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Pokreće"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Premium korisnička podrška"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Premium plan"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Prethodni iznosi plaćanja"),
        "price": MessageLookupByLibrary.simpleMessage("Cijena"),
        "print": MessageLookupByLibrary.simpleMessage("Ispis"),
        "printingOption": MessageLookupByLibrary.simpleMessage("Opcije štampe"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Pravila privatnosti"),
        "product": MessageLookupByLibrary.simpleMessage("Proizvod"),
        "productCode": MessageLookupByLibrary.simpleMessage("Šifra proizvoda"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("Šifra proizvoda je obavezna"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Kod proizvoda/Naziv"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Opis Proizvoda"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Detalji o proizvodu"),
        "productList": MessageLookupByLibrary.simpleMessage("Lista proizvoda"),
        "productName": MessageLookupByLibrary.simpleMessage("Ime proizvoda"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Naziv proizvoda već postoji u ovom skladištu"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Naziv proizvoda je već dodat"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("Naziv proizvoda je obavezan"),
        "products": MessageLookupByLibrary.simpleMessage("Proizvodi"),
        "profile": MessageLookupByLibrary.simpleMessage("Profil"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("Uredi profil"),
        "profit": MessageLookupByLibrary.simpleMessage("Dobit"),
        "promo": MessageLookupByLibrary.simpleMessage("Promocija"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Promotivni kod"),
        "purchase": MessageLookupByLibrary.simpleMessage("Kupovina"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("Alarm za kupovinu"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Kupovina potvrđena"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Detalji kupovine"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Faktura za Kupovinu"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("Lista kupovina"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Kupite Sada"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Kupite Premium plan"),
        "purchasePrice":
            MessageLookupByLibrary.simpleMessage("Cijena kupovine"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("Cijena kupovine je obavezna"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("Izvještaj o kupovini"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Izvještaji o kupovini"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Izvještaji o kupovini"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("Povrat Kupovine"),
        "purchaseReturnReport": MessageLookupByLibrary.simpleMessage(
            "Izvještaj o Povratu Kupovine"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Kupovina Prijelaza"),
        "qty": MessageLookupByLibrary.simpleMessage("Količina"),
        "quantity": MessageLookupByLibrary.simpleMessage("Količina"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Nedavne transakcije"),
        "recivedThePin": MessageLookupByLibrary.simpleMessage("Primljen PIN"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Referentni broj"),
        "register": MessageLookupByLibrary.simpleMessage("Registracija"),
        "registering": MessageLookupByLibrary.simpleMessage("Registracija"),
        "remainingDue":
            MessageLookupByLibrary.simpleMessage("Preostalo dugovanje"),
        "remove": MessageLookupByLibrary.simpleMessage("Ukloni"),
        "reports": MessageLookupByLibrary.simpleMessage("Izvještaji"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Zahtjev je poslan"),
        "resendCode":
            MessageLookupByLibrary.simpleMessage("Ponovo pošalji kod"),
        "resendOtp":
            MessageLookupByLibrary.simpleMessage("Ponovo pošalji OTP: "),
        "retailer": MessageLookupByLibrary.simpleMessage("Maloprodavač"),
        "retur": MessageLookupByLibrary.simpleMessage("Povrat"),
        "returN": MessageLookupByLibrary.simpleMessage("Povrat"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("Iznos povrata"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("Iznos povrata"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("Povrat KOL"),
        "revenue": MessageLookupByLibrary.simpleMessage("Prihod"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Zaštitite podatke svog poslovanja bez napora. Naš Pos Saas POS Unlimited Upgrade uključuje besplatno sigurnosno kopiranje podataka, osiguravajući da su vaši dragocjeni podaci zaštićeni od neočekivanih događaja. Usredotočite se na ono što zaista vrijedi - rast vašeg poslovanja."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Iznos Prodaje"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("Detalji prodaje"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Cijena prodaje"),
        "saleReports":
            MessageLookupByLibrary.simpleMessage("Izvještaji o prodaji"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Izvještaji o prodaji"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("Povrat prodaje"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Izvještaj o Povratu Prodaje"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("Postavka Prodaje"),
        "sales": MessageLookupByLibrary.simpleMessage("Prodaja"),
        "salesAndPurchaseReports": MessageLookupByLibrary.simpleMessage(
            "Izvještaji o prodaji i kupovini"),
        "salesList": MessageLookupByLibrary.simpleMessage("Lista prodaja"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("Povrat Prodaje"),
        "save": MessageLookupByLibrary.simpleMessage("Spremi"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Spremi i objavi"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("Spremi promene"),
        "saving": MessageLookupByLibrary.simpleMessage("Čuvanje"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("Skenirajte QR kod proizvoda"),
        "search": MessageLookupByLibrary.simpleMessage("Pretraga"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Pretraži prema kodu proizvoda ili nazivu"),
        "seeAllPromoCode": MessageLookupByLibrary.simpleMessage(
            "Pogledaj sve promotivne kodove"),
        "select": MessageLookupByLibrary.simpleMessage("Odaberi"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Odaberite proizvod za povrat"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Odaberite brend"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Odaberite kategoriju"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Izaberite kontakte"),
        "selectProductCategory": MessageLookupByLibrary.simpleMessage(
            "Odaberite kategoriju proizvoda"),
        "selectShopCategory": MessageLookupByLibrary.simpleMessage(
            "Odaberite kategoriju trgovine"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Odaberite porez"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Odaberite tip poreza"),
        "selectUnit":
            MessageLookupByLibrary.simpleMessage("Odaberite jedinicu"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Izaberite varijaciju:"),
        "seller": MessageLookupByLibrary.simpleMessage("Prodavač"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Prodaje Po"),
        "send": MessageLookupByLibrary.simpleMessage("Pošalji"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("Pošalji email"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Pošaljite poruku"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("Pošalji vezu za resetiranje"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Pošalji SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Poslati SMS?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Pošalji WhatsApp poruku"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Pošaljite svoj email"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage("Slanje Email-a"),
        "sendingMessage": MessageLookupByLibrary.simpleMessage("Slanje poruke"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Servis/Dostava"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Postavite vaš profil"),
        "setting": MessageLookupByLibrary.simpleMessage("Postavke"),
        "share": MessageLookupByLibrary.simpleMessage("Dijeljenje"),
        "shopGST": MessageLookupByLibrary.simpleMessage("PDV trgovine"),
        "signIn": MessageLookupByLibrary.simpleMessage("Prijavi se"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("Prijavite se putem emaila"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Potpis Kupca"),
        "size": MessageLookupByLibrary.simpleMessage("Veličina"),
        "skip": MessageLookupByLibrary.simpleMessage("Preskoči"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Društveni marketing"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Nažalost, nemate dozvolu za pristup ovoj usluzi"),
        "startDate": MessageLookupByLibrary.simpleMessage("Početni datum"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Započni novu prodaju"),
        "startTypingToSearch":
            MessageLookupByLibrary.simpleMessage("Počnite kucati za pretragu"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Ostanite u samom vrhu tehnoloških dostignuća bez dodatnih troškova. Naš Pos Saas POS Unlimited Upgrade osigurava da uvijek imate najnovije alate i funkcionalnosti na dohvat ruke, čime se jamči da vaša tvrtka ostane najsuvremenija."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("Još Neplaćeno"),
        "stock": MessageLookupByLibrary.simpleMessage("Zaliha"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Zaliha je obavezna"),
        "stockList": MessageLookupByLibrary.simpleMessage("Lista zaliha"),
        "stocks": MessageLookupByLibrary.simpleMessage("Zalihe"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Dozvola za pohranu je potrebna za kreiranje Excel datoteke"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("Lista Pod-poreza"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Pod-porezi"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Međuzbir"),
        "submit": MessageLookupByLibrary.simpleMessage("Potvrdi"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "Pretplatite se na naš YouTube"),
        "subscription": MessageLookupByLibrary.simpleMessage("Pretplata"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Uspješno Završeno"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Uspješno Odjavljen"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Uspješno ažurirano"),
        "supplier": MessageLookupByLibrary.simpleMessage("Dobavljač"),
        "supplierName": MessageLookupByLibrary.simpleMessage("Ime dobavljača"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT kod"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Uzmite vozačku dozvolu, ličnu kartu ili pasošku fotografiju"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "Uzmite ličnu kartu kako biste provjerili vaše informacije"),
        "tap": MessageLookupByLibrary.simpleMessage("Tap"),
        "tax": MessageLookupByLibrary.simpleMessage("Porez"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Poreska grupa"),
        "taxPercentage":
            MessageLookupByLibrary.simpleMessage("Postotak Poreza"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Poreska stopa"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Poreske stope - Upravljajte svojim poreskim stopama"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Poreski izvještaj"),
        "taxType": MessageLookupByLibrary.simpleMessage("Tip poreza"),
        "taxes": MessageLookupByLibrary.simpleMessage("Porezi"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Uslovi i odredbe"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("Uvjeti korištenja"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Uslovi i Privatnost"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Hvala vam na vašem plaćanju duga"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Hvala"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Hvala vam na vašoj kupovini"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "Račun već postoji za ovu e-poštu"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Excel datoteka je već preuzeta"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Sve govori samo ime. S Pos Saas POS Unlimited nema ograničenja za vašu upotrebu. Bez obzira jesu li u pitanju nekoliko transakcija ili navala kupaca, možete raditi s povjerenjem, znajući da niste ograničeni limitima."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "Lozinka koju ste unijeli je preslaba"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Prodaja će biti izbrisana, a svi podaci o ovoj kupovini bit će izbrisani. Jeste li sigurni da želite obrisati ovo"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Prodaja će biti izbrisana, a svi podaci o ovoj prodaji bit će izbrisani. Jeste li sigurni da želite obrisati ovo"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Korisnik će biti izbrisan i svi podaci će biti izbrisani s vašeg računa. Jeste li sigurni da želite izbrisati ovo?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Korisnik će biti izbrisan i svi podaci će biti obrisani sa vašeg računa. Jeste li sigurni da želite obrisati"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Usluge trećih strana"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Ova kategorija se ne može izbrisati"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Ovaj Mjesec)"),
        "thisProductAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("Ovaj proizvod je već dodan"),
        "title": MessageLookupByLibrary.simpleMessage("Naslov"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Naslov ne može biti prazan"),
        "to": MessageLookupByLibrary.simpleMessage("do"),
        "toDate": MessageLookupByLibrary.simpleMessage("Do datuma"),
        "today": MessageLookupByLibrary.simpleMessage("Danas"),
        "total": MessageLookupByLibrary.simpleMessage("Ukupno"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Ukupan iznos"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Ukupno Prikupljeno"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Ukupno dugovanje"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("Ukupni troškovi"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Ukupni gubitak"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("Ukupno za plaćanje"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Ukupna cijena"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("Ukupan broj proizvoda"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Ukupna dobit"),
        "totalPurchase":
            MessageLookupByLibrary.simpleMessage("Ukupna Kupovina"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Ukupan Iznos Povrata"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("Ukupni povrati"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Ukupna prodaja"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Ukupna zalihа"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Ukupna vrijednost"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Ukupni PDV"),
        "totals": MessageLookupByLibrary.simpleMessage("Ukupno: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Transakcija"),
        "transactionId": MessageLookupByLibrary.simpleMessage("ID transakcije"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Pokušajte ponovo"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Tip"),
        "unitName": MessageLookupByLibrary.simpleMessage("Ime jedinice"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Cijena po komadu"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Jedinična Cijena"),
        "units": MessageLookupByLibrary.simpleMessage("Jedinice"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Neograničeno"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Neograničena upotreba"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Otključajte puni potencijal Pos Saas POS-a uz personalizirane edukativne sesije koje vodi naš stručni tim. Od osnovnih do naprednih tehnika, osiguravamo da ste dobro upućeni u korištenje svakog aspekta sustava kako biste optimizirali svoje poslovne procese."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Neplaćeno"),
        "update": MessageLookupByLibrary.simpleMessage("Ažuriraj"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Ažuriraj kontakt"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Ažuriraj sada"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("Ažuriraj proizvod"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Ažurirajte vaš plan prvo, vaš limit je istekao"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Ažurirajte svoj profil"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Ažurirajte svoj profil kako biste se bolje povezali s vašim doktorom"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Ažurirajte svoj profil kako biste bolje povezali kupce"),
        "updated": MessageLookupByLibrary.simpleMessage("Ažurirano"),
        "upload": MessageLookupByLibrary.simpleMessage("Učitaj"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Učitajte dokument"),
        "uploadDone":
            MessageLookupByLibrary.simpleMessage("Učitavanje završeno"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Učitajte datoteku"),
        "upplier": MessageLookupByLibrary.simpleMessage("Dobavljač"),
        "usbC": MessageLookupByLibrary.simpleMessage("Usb C"),
        "use": MessageLookupByLibrary.simpleMessage("Koristite"),
        "useMobiPos":
            MessageLookupByLibrary.simpleMessage("Koristite Pos Saas"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Korištenje sistema"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Korisnik je obrisan"),
        "userRole": MessageLookupByLibrary.simpleMessage("Korisnička uloga"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("Detalji korisničke uloge"),
        "userTitle": MessageLookupByLibrary.simpleMessage("Naslov korisnika"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Naslov korisnika ne može biti prazan"),
        "value": MessageLookupByLibrary.simpleMessage("Vrijednost"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("PDV se ne primjenjuje"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("Verifikacija OTP"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Potvrdi broj telefona"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Pogledaj sve"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("Pogledaj detalje"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Kupac bez naloga"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Skladište"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Skladište već postoji"),
        "warehouseList":
            MessageLookupByLibrary.simpleMessage("Lista skladišta"),
        "warehouseName":
            MessageLookupByLibrary.simpleMessage("Naziv skladišta"),
        "warranty": MessageLookupByLibrary.simpleMessage("Garancija"),
        "weHaveSendAnEmailwithInstructions":
            MessageLookupByLibrary.simpleMessage(
                "Poslali smo vam email sa uputama kako resetirati lozinku na:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Možemo koristiti usluge trećih strana za podršku funkcionalnosti naše aplikacije, kao što su pružaoci analitike i procesori plaćanja. Ove usluge trećih strana mogu prikupljati informacije o vama kada koristite našu aplikaciju. Napomena: nismo odgovorni za prakse privatnosti ovih usluga trećih strana."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Preduzimamo mjere koje su standardne u industriji kako bismo zaštitili vaše lične informacije, uključujući šifrovanje i sigurno skladištenje. Takođe ograničavamo pristup vašim informacijama samo ovlaštenom osoblju."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            " Razumijemo važnost besprijekornog poslovanja. Zato vam je naša podrška dostupna 24 sata dnevno kako bismo vam pomogli, bilo da je riječ o brzom upitu ili opsežnoj zabrinutosti. Povežite se s nama u bilo koje vrijeme, bilo gdje putem poziva ili WhatsApp-a kako biste doživjeli neusporedivu korisničku uslugu."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Koristimo vaše lične informacije kako bismo vam pružili najbolje moguće iskustvo našeg aplikacije, uključujući personalizaciju preporuka za sadržaj, povezivanje sa ekspertima i poboljšanje funkcionalnosti naših aplikacija. Takođe možemo koristiti vaše informacije kako bismo vas obavještavali o ažuriranjima, promocijama ili drugim informacijama vezanim za našu aplikaciju."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Pregledat ćemo uplatu i odobriti je u roku od 1-2 sata"),
        "weekly": MessageLookupByLibrary.simpleMessage("Sedmično"),
        "weight": MessageLookupByLibrary.simpleMessage("Težina"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Šta je novo"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Veleprodavač"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Cijena veleprodaje"),
        "wholesalePrice":
            MessageLookupByLibrary.simpleMessage("Veleprodajna cijena"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Veletrgovac"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Uskoro će biti dodano"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Istek će biti"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Napišite poruku ovde"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("Pogrešan OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Pogrešna lozinka je unesena za tog korisnika."),
        "yearly": MessageLookupByLibrary.simpleMessage("Godišnje"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Da, zauvijek izbriši"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("Niste važeći korisnik"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Koristite"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Ne možete platiti više nego što je dugovano"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Dobili ste email"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Uspješno ste se prijavili na svoj račun. Ostanite s Pos Saas -om."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("Morate dati dozvolu"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Morate ponovno se prijaviti na svoj račun."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Morate verifikovati identitet pre kupovine SMS-ova"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Vaša poruka ostaje"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Vaš paket"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Vaš paket će isteći za 5 dana")
      };
}
