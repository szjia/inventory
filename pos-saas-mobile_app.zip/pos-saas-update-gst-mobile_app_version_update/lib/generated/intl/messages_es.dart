// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a es locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'es';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Continuar"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("Número GST"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("El MRP es obligatorio"),
        "OK": MessageLookupByLibrary.simpleMessage("OK"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Tel. No."),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("Código SWIFT"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Snacks"),
        "TAX": MessageLookupByLibrary.simpleMessage("IMPUESTO"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Subiendo"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("Título de usuario"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Tu paquete expirará hoy\nPor favor, compra nuevamente"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) El Sistema se proporciona únicamente con el propósito de facilitar transacciones de punto de venta y actividades relacionadas en su negocio."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) Para utilizar el Sistema, es posible que deba crear una cuenta. Usted acepta proporcionar información precisa, actual y completa durante el proceso de registro y actualizar dicha información para mantenerla precisa y completa."),
        "aboutApp":
            MessageLookupByLibrary.simpleMessage("Acerca de la aplicación"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Sobre nosotros"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Aceptación de Términos"),
        "accountName":
            MessageLookupByLibrary.simpleMessage("Nombre de la cuenta"),
        "accountNumber":
            MessageLookupByLibrary.simpleMessage("Número de cuenta"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Registro de Cuenta"),
        "acton": MessageLookupByLibrary.simpleMessage("Acción"),
        "add": MessageLookupByLibrary.simpleMessage("Agregar"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Agregar Marca"),
        "addCategory":
            MessageLookupByLibrary.simpleMessage("Agregar Categoría"),
        "addContact": MessageLookupByLibrary.simpleMessage("Agregar Contacto"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Agregar Cliente"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("Agregar Entrega"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Agregar descripción"),
        "addDescription": MessageLookupByLibrary.simpleMessage("Agregar nota"),
        "addDiscount":
            MessageLookupByLibrary.simpleMessage("Agregar descuento"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Agregar ID de documento"),
        "addDucument":
            MessageLookupByLibrary.simpleMessage("Agregar Documento"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Agregar Gasto"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Agregar Categoría de Gasto"),
        "addItems": MessageLookupByLibrary.simpleMessage("Agregar Artículos"),
        "addNew": MessageLookupByLibrary.simpleMessage("Agregar nuevo"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Agregar Nueva Dirección"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Agregar Nuevo Producto"),
        "addNewTax":
            MessageLookupByLibrary.simpleMessage("Añadir Nuevo Impuesto"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Añadir Nuevo Impuesto con tipo de impuesto único/múltiple"),
        "addNote": MessageLookupByLibrary.simpleMessage("Agregar Nota"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Añade primero el producto"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Agregar código promocional"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Agregar Compra"),
        "addSales": MessageLookupByLibrary.simpleMessage("Agregar Ventas"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Agregado exitosamente"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Agregar Unidad"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Agregar rol de usuario"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Agregado exitosamente"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("Añadido al Carrito"),
        "address": MessageLookupByLibrary.simpleMessage("Dirección"),
        "admin": MessageLookupByLibrary.simpleMessage("Administrador"),
        "all": MessageLookupByLibrary.simpleMessage("Todo"),
        "allBusinessSolution": MessageLookupByLibrary.simpleMessage(
            "Todas las soluciones empresariales"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("Ya agregado"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Ya Existe"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Ya tienes una cuenta"),
        "amount": MessageLookupByLibrary.simpleMessage("Cantidad"),
        "anEmailHasBeenSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "Se ha enviado un correo electrónico.\\nVerifique su bandeja de entrada"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Soporte de aplicaciones para Android e iOS"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Impuesto aplicable"),
        "apply": MessageLookupByLibrary.simpleMessage("Aplicar"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "¿Estás seguro de eliminar esta factura?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "¿Estás seguro de eliminar esta venta?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "¿Estás seguro de que deseas eliminar este usuario?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "¿Está seguro de que desea eliminar este impuesto?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "¿Está seguro de que desea eliminar este grupo de impuestos?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "¿Está seguro de que desea eliminar este almacén?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "¿Estás seguro de eliminar a este usuario?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Firma Autorizada"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Usted es responsable de mantener la confidencialidad de su cuenta y contraseña, y de restringir el acceso a su cuenta. Acepta la responsabilidad de todas las actividades que ocurran bajo su cuenta."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Debe tener al menos 18 años de edad o la mayoría de edad legal en su jurisdicción para utilizar el Sistema."),
        "backSide": MessageLookupByLibrary.simpleMessage("Lado posterior"),
        "backToHome": MessageLookupByLibrary.simpleMessage("Volver a Inicio"),
        "balance": MessageLookupByLibrary.simpleMessage("Saldo"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladesh"),
        "bank": MessageLookupByLibrary.simpleMessage("Banco"),
        "bankAccountCurrency": MessageLookupByLibrary.simpleMessage(
            "Moneda de la Cuenta Bancaria"),
        "bankAccountingCurrecny": MessageLookupByLibrary.simpleMessage(
            "Moneda de la cuenta bancaria"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Información bancaria"),
        "bankName": MessageLookupByLibrary.simpleMessage("Nombre del banco"),
        "bankTransfer":
            MessageLookupByLibrary.simpleMessage("Transferencia Bancaria"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Código de barras encontrado"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Factura/Factura"),
        "billTo": MessageLookupByLibrary.simpleMessage("Facturar a"),
        "branchName":
            MessageLookupByLibrary.simpleMessage("Nombre de la sucursal"),
        "brand": MessageLookupByLibrary.simpleMessage("Marca"),
        "brandName": MessageLookupByLibrary.simpleMessage("Nombre de la Marca"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("Subida masiva"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Categoría de Negocio"),
        "buy": MessageLookupByLibrary.simpleMessage("Comprar"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Comprar plan premium"),
        "buySms": MessageLookupByLibrary.simpleMessage("Comprar SMS"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Al acceder o utilizar el Sistema de Punto de Venta (POS) (el \"Sistema\") proporcionado por [Nombre de su Empresa] (la \"Compañía\"), usted acepta quedar sujeto a estos Términos de Uso. Si no está de acuerdo con estos Términos de Uso, no utilice el Sistema."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Usted es responsable de asegurarse de que su acceso y uso del Sistema cumplan con todas las leyes y regulaciones aplicables."),
        "call": MessageLookupByLibrary.simpleMessage("Llamar"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "Llama para Soporte de Emergencia"),
        "camera": MessageLookupByLibrary.simpleMessage("Cámara"),
        "cancel": MessageLookupByLibrary.simpleMessage("Cancelar"),
        "cancelAllProduct": MessageLookupByLibrary.simpleMessage(
            "Cancelar todos los productos"),
        "capacity": MessageLookupByLibrary.simpleMessage("Capacidad"),
        "card": MessageLookupByLibrary.simpleMessage("Tarjeta"),
        "cash": MessageLookupByLibrary.simpleMessage("Efectivo"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Categorías"),
        "category": MessageLookupByLibrary.simpleMessage("Categoría"),
        "categoryName":
            MessageLookupByLibrary.simpleMessage("Nombre de la categoría"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "El nombre de la categoría ya existe"),
        "cateogryName":
            MessageLookupByLibrary.simpleMessage("Nombre de la Categoría"),
        "change": MessageLookupByLibrary.simpleMessage("¿Cambiar?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Cambiar Contraseña"),
        "checkEmail": MessageLookupByLibrary.simpleMessage(
            "Verificar Correo Electrónico"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Selecciona un Cliente"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Selecciona un Proveedor"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Elige tus características"),
        "clarence": MessageLookupByLibrary.simpleMessage("Clarence"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Haz clic para conectar"),
        "close": MessageLookupByLibrary.simpleMessage("Cerrar"),
        "color": MessageLookupByLibrary.simpleMessage("Color"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(Combinación de múltiples impuestos)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Próximamente"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Dirección de la Empresa"),
        "companyAndShopName": MessageLookupByLibrary.simpleMessage(
            "Nombre de la Empresa y Tienda"),
        "companyBusinessName": MessageLookupByLibrary.simpleMessage(
            "Nombre de la Empresa y Negocio"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Completar transacción"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Confirmar Contraseña"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Confirmar devolución"),
        "congratulations":
            MessageLookupByLibrary.simpleMessage("Felicitaciones"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Contáctanos"),
        "country": MessageLookupByLibrary.simpleMessage("País"),
        "create": MessageLookupByLibrary.simpleMessage("Crear"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Crea una Cuenta Gratis"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Creado y Guardado"),
        "currency": MessageLookupByLibrary.simpleMessage("Moneda"),
        "currentStock":
            MessageLookupByLibrary.simpleMessage("Inventario actual"),
        "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
            "Personalización de la marca de la factura"),
        "customer": MessageLookupByLibrary.simpleMessage("Cliente"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Detalles del Cliente"),
        "customerGST": MessageLookupByLibrary.simpleMessage("GST del cliente"),
        "customerName":
            MessageLookupByLibrary.simpleMessage("Nombre del Cliente"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Transacción Diaria"),
        "dashBoardOverView": MessageLookupByLibrary.simpleMessage(
            "Resumen del Panel de Control"),
        "dataSavedSuccessfully": MessageLookupByLibrary.simpleMessage(
            "Datos guardados exitosamente"),
        "date": MessageLookupByLibrary.simpleMessage("Fecha"),
        "day": MessageLookupByLibrary.simpleMessage("Día"),
        "dealer": MessageLookupByLibrary.simpleMessage("Distribuidor"),
        "dealerPrice":
            MessageLookupByLibrary.simpleMessage("Precio de Distribuidor"),
        "defaultVATPercentage": MessageLookupByLibrary.simpleMessage(
            "Porcentaje de IVA Predeterminado"),
        "delete": MessageLookupByLibrary.simpleMessage("Eliminar"),
        "deleting": MessageLookupByLibrary.simpleMessage("Eliminando"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Dirección de Entrega"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Direcciones de entrega"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Cargo de Entrega"),
        "describtion": MessageLookupByLibrary.simpleMessage("Descripción"),
        "description": MessageLookupByLibrary.simpleMessage("Descripción"),
        "descriptionCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "La descripción no puede estar vacía"),
        "details": MessageLookupByLibrary.simpleMessage("Detalles"),
        "discount": MessageLookupByLibrary.simpleMessage("Descuento"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("No molestar"),
        "done": MessageLookupByLibrary.simpleMessage("Hecho"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Descargar formato de Excel"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Descargado exitosamente en la carpeta de descargas"),
        "due": MessageLookupByLibrary.simpleMessage("Pendiente"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Monto Pendiente: "),
        "dueCollection":
            MessageLookupByLibrary.simpleMessage("Cobro de Pendientes"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("Informes de Cobro Pendiente"),
        "dueList": MessageLookupByLibrary.simpleMessage("Lista de Pendientes"),
        "dueReports": MessageLookupByLibrary.simpleMessage("Reporte de Deudas"),
        "duration": MessageLookupByLibrary.simpleMessage("Duración"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Duración: Desde"),
        "easyToUseMobilePos":
            MessageLookupByLibrary.simpleMessage("TPV móvil fácil de usar"),
        "edit": MessageLookupByLibrary.simpleMessage("Editar"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Editar Factura de Compra"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Editar Factura de Ventas"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Editar Redes Sociales"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Editado con éxito"),
        "editTax": MessageLookupByLibrary.simpleMessage("Editar impuesto"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Editar grupo de impuestos"),
        "editWarehouse": MessageLookupByLibrary.simpleMessage("Editar almacén"),
        "email": MessageLookupByLibrary.simpleMessage("Correo Electrónico"),
        "emailAddress": MessageLookupByLibrary.simpleMessage(
            "Dirección de Correo Electrónico"),
        "emailCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "El correo electrónico no puede estar vacío"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "¡Correo Enviado! Verifica tu Bandeja de Entrada"),
        "endDate": MessageLookupByLibrary.simpleMessage("Fecha de Fin"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Ingresa una cantidad válida"),
        "enterAValidDiscount": MessageLookupByLibrary.simpleMessage(
            "Introduce un Descuento Válido"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Ingresa un número de teléfono válido"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Introduce un precio válido"),
        "enterAValidQuantity": MessageLookupByLibrary.simpleMessage(
            "Introduce una cantidad válida"),
        "enterAddress":
            MessageLookupByLibrary.simpleMessage("Ingresa la Dirección"),
        "enterAmount":
            MessageLookupByLibrary.simpleMessage("Ingresa la Cantidad."),
        "enterBrandName": MessageLookupByLibrary.simpleMessage(
            "Ingresa el Nombre de la Marca"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Ingresa la Capacidad"),
        "enterCategoryName": MessageLookupByLibrary.simpleMessage(
            "Ingresa el Nombre de la Categoría"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Ingresa el Color"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "Ingresa el número GST del cliente"),
        "enterDealerPrice": MessageLookupByLibrary.simpleMessage(
            "Ingresa el Precio de Distribuidor"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Ingresa la descripción"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("Ingresa el Descuento."),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Ingresa la Fecha del Gasto"),
        "enterFullAddress": MessageLookupByLibrary.simpleMessage(
            "Ingresa la Dirección Completa"),
        "enterInvoiceNumber": MessageLookupByLibrary.simpleMessage(
            "Ingresa el Número de Factura"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Ingresa la cantidad de alerta de bajo stock"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Ingresa el Fabricante"),
        "enterMessageContent": MessageLookupByLibrary.simpleMessage(
            "Ingresar contenido del mensaje"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "Ingresa MRP/Precio Minorista"),
        "enterName": MessageLookupByLibrary.simpleMessage("Ingresa el Nombre"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Ingresa la Nota"),
        "enterPartyName": MessageLookupByLibrary.simpleMessage(
            "Ingresa el Nombre de la Parte"),
        "enterPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Ingresa el Número de Teléfono"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Ingresa el Código del Producto o Escanea"),
        "enterProductName": MessageLookupByLibrary.simpleMessage(
            "Ingresa el Nombre del Producto"),
        "enterPurchasePrice": MessageLookupByLibrary.simpleMessage(
            "Ingresa el Precio de Compra."),
        "enterReferenceNumber": MessageLookupByLibrary.simpleMessage(
            "Ingresa el Número de Referencia"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Ingresa el Tamaño"),
        "enterStocks":
            MessageLookupByLibrary.simpleMessage("Ingresa las Existencias."),
        "enterTaxRate": MessageLookupByLibrary.simpleMessage(
            "Introduzca la tasa de impuesto"),
        "enterTransactionId": MessageLookupByLibrary.simpleMessage(
            "Ingrese el ID de la transacción"),
        "enterType": MessageLookupByLibrary.simpleMessage("Ingresa el Tipo"),
        "enterUserTitle": MessageLookupByLibrary.simpleMessage(
            "Ingrese el título del usuario"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Ingresa una cantidad válida"),
        "enterWarehouseName": MessageLookupByLibrary.simpleMessage(
            "Introduzca el nombre del almacén"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Ingresa el Peso"),
        "enterWholeSalePrice": MessageLookupByLibrary.simpleMessage(
            "Ingresa el Precio al Por Mayor"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("Ingresa tu descripción aquí"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "Ingresa tu dirección de correo electrónico"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "Ingresa el Título de tu Comentario"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Ingresa tu número GST"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("Ingrese su número de móvil"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Ingresa tu Nombre"),
        "enterYourNumber": MessageLookupByLibrary.simpleMessage(
            "Ingresa tu número de teléfono"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Ingrese su contraseña"),
        "enterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Ingresa tu Número de Teléfono"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "Ingrese su ID de transacción"),
        "error": MessageLookupByLibrary.simpleMessage("Error"),
        "excTax": MessageLookupByLibrary.simpleMessage("Impuesto excluido"),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("Cargador de Excel"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Exclusivo"),
        "expense": MessageLookupByLibrary.simpleMessage("Gasto"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Categoría de Gasto"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Fecha del Gasto"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Gasto Para"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Reporte de Gastos"),
        "expireDate":
            MessageLookupByLibrary.simpleMessage("Fecha de caducidad"),
        "expired": MessageLookupByLibrary.simpleMessage("Expirado"),
        "expiring": MessageLookupByLibrary.simpleMessage("Expirando"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Error al registrar"),
        "fashion": MessageLookupByLibrary.simpleMessage("Moda"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Las características son la parte importante que diferencia a Pos Saas de las soluciones tradicionales."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Comentarios"),
        "firstName": MessageLookupByLibrary.simpleMessage("Primer Nombre"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Síguenos en\\nFacebook"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Síguenos en\\nTwitter"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Lado frontal"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("Para usos ilimitados"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Olvidé mi contraseña"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("¿Olvidaste tu contraseña?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Desde Fecha"),
        "freeDataBackup": MessageLookupByLibrary.simpleMessage(
            "Copia de seguridad de datos gratuita"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "Actualización gratuita de por vida"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Paquete gratuito"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Plan gratuito"),
        "from": MessageLookupByLibrary.simpleMessage("(De"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Total Pagado"),
        "gallary": MessageLookupByLibrary.simpleMessage("Galería"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("Generando PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Obtener OTP"),
        "govermentId": MessageLookupByLibrary.simpleMessage(
            "Documento de Identidad Gubernamental"),
        "guest": MessageLookupByLibrary.simpleMessage("Invitado"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("¿No tienes una cuenta?"),
        "history": MessageLookupByLibrary.simpleMessage("Historia"),
        "home": MessageLookupByLibrary.simpleMessage("Inicio"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Cómo Protegemos su Información"),
        "howWeUseYourInformation":
            MessageLookupByLibrary.simpleMessage("Cómo Usamos su Información"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Verificación de Identidad"),
        "image": MessageLookupByLibrary.simpleMessage("Imagen"),
        "inHouseCantBeDelete": MessageLookupByLibrary.simpleMessage(
            "No se puede eliminar en casa"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("No se puede editar en casa"),
        "inWord": MessageLookupByLibrary.simpleMessage("En Palabras"),
        "incTax": MessageLookupByLibrary.simpleMessage("Impuesto incluido"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Inclusivo"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("Aumentar stock"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Instrumento"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("No. de Factura"),
        "invoice": MessageLookupByLibrary.simpleMessage("Factura"),
        "invoiceNumber":
            MessageLookupByLibrary.simpleMessage("Número de Factura"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Configuración de Factura"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Visor de facturas"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Artículo Agregado"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("Verificación KYC"),
        "language": MessageLookupByLibrary.simpleMessage("Idioma"),
        "lastName": MessageLookupByLibrary.simpleMessage("Apellido"),
        "ledger": MessageLookupByLibrary.simpleMessage("Libro Mayor"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Compra de por vida"),
        "link": MessageLookupByLibrary.simpleMessage("Enlace"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Soporte de Chat en Vivo"),
        "loading": MessageLookupByLibrary.simpleMessage("Cargando"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Cerrar Sesión"),
        "logOut": MessageLookupByLibrary.simpleMessage("Cerrar sesión"),
        "login": MessageLookupByLibrary.simpleMessage("Iniciar Sesión"),
        "logo": MessageLookupByLibrary.simpleMessage("Logo"),
        "loss": MessageLookupByLibrary.simpleMessage("Pérdida"),
        "lossOrProfit":
            MessageLookupByLibrary.simpleMessage("Pérdida/Ganancia"),
        "lossOrProfitDetails": MessageLookupByLibrary.simpleMessage(
            "Detalles de Pérdida/Ganancia"),
        "lossProfitReport": MessageLookupByLibrary.simpleMessage(
            "Informe de Pérdidas/Ganancias"),
        "lossProfitReports": MessageLookupByLibrary.simpleMessage(
            "Informes de Pérdidas/Ganancias"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Alerta de bajo stock"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Deje una impresión duradera en sus clientes con facturas personalizadas. Nuestra Actualización ilimitada ofrece la ventaja única de personalizar sus facturas, agregando un toque profesional que refuerza la identidad de su marca y fomenta la lealtad del cliente."),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("Administra tu negocio con"),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Fecha de fabricación"),
        "margin": MessageLookupByLibrary.simpleMessage("Margen"),
        "masterCard": MessageLookupByLibrary.simpleMessage("Tarjeta Master"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Fabricante"),
        "message": MessageLookupByLibrary.simpleMessage("Mensaje"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Historial de Mensajes"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "La aplicación Pos Saas es gratuita y fácil de usar. De hecho, es uno de los mejores sistemas de TPV en todo el mundo."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas es una solución empresarial completa con inventario, cuentas, ventas, gastos y pérdidas/ganancias."),
        "mobile": MessageLookupByLibrary.simpleMessage("Móvil"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("Pago móvil"),
        "monthly": MessageLookupByLibrary.simpleMessage("Mensual"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("Más Información"),
        "name": MessageLookupByLibrary.simpleMessage("Ingresa tu Nombre."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("El nombre ya existe"),
        "nameCantBeEmpty": MessageLookupByLibrary.simpleMessage(
            "El nombre no puede estar vacío"),
        "next": MessageLookupByLibrary.simpleMessage("Siguiente"),
        "noConnection": MessageLookupByLibrary.simpleMessage("Sin Conexión"),
        "noData": MessageLookupByLibrary.simpleMessage("Sin datos"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("No hay datos disponibles"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("No se encontraron datos"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("¡No se encontró Historial!"),
        "noProductFound": MessageLookupByLibrary.simpleMessage(
            "No se encontró ningún producto"),
        "noSubTaxSelected": MessageLookupByLibrary.simpleMessage(
            "No se seleccionó ningún subimpuesto"),
        "noTransactionFound": MessageLookupByLibrary.simpleMessage(
            "¡No se encontró Transacción!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "No se encontró ningún usuario con ese correo electrónico."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "No se encontró el rol de usuario"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Usuario No Activo"),
        "notProvided": MessageLookupByLibrary.simpleMessage("No proporcionado"),
        "note": MessageLookupByLibrary.simpleMessage("Nota"),
        "notes": MessageLookupByLibrary.simpleMessage("Notas"),
        "notification": MessageLookupByLibrary.simpleMessage("Notificación"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP enviado a"),
        "office": MessageLookupByLibrary.simpleMessage("Oficina"),
        "ok": MessageLookupByLibrary.simpleMessage("Aceptar"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS que contiene una gran cantidad de funcionalidad, incluyendo seguimiento de ventas y gestión de inventario."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Este sistema le ayuda a mejorar sus operaciones para sus clientes."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Nuestro sistema POS debería simplificar automáticamente las operaciones diarias, facilitando la navegación."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("Saldo de Apertura"),
        "order": MessageLookupByLibrary.simpleMessage("Pedidos"),
        "other": MessageLookupByLibrary.simpleMessage("Otro"),
        "otp": MessageLookupByLibrary.simpleMessage("Cerrar"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Agotado"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Paquete"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Características del paquete"),
        "paid": MessageLookupByLibrary.simpleMessage("Pagado"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Monto Pagado"),
        "parties": MessageLookupByLibrary.simpleMessage("Partes"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Lista de Partes"),
        "partyGST": MessageLookupByLibrary.simpleMessage("GST de la parte"),
        "partyName": MessageLookupByLibrary.simpleMessage("Nombre de la Parte"),
        "password": MessageLookupByLibrary.simpleMessage("Contraseña"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "La contraseña y la contraseña de confirmación no coinciden"),
        "passwordCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "La contraseña no puede estar vacía"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("La contraseña no coincide"),
        "payCash": MessageLookupByLibrary.simpleMessage("Pagar en efectivo"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash": MessageLookupByLibrary.simpleMessage("Pagar con bKash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Pagar con Paypal"),
        "payeeName":
            MessageLookupByLibrary.simpleMessage("Nombre del beneficiario"),
        "payeeNumber":
            MessageLookupByLibrary.simpleMessage("Número del beneficiario"),
        "payment": MessageLookupByLibrary.simpleMessage("Pago"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("Monto del Pago"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Pago Completado"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Instrucciones de pago:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("Método de Pago"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Tipo de Pago"),
        "pdfView": MessageLookupByLibrary.simpleMessage("Vista PDF"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Información personal"),
        "phone": MessageLookupByLibrary.simpleMessage("Teléfono"),
        "phoneNumber":
            MessageLookupByLibrary.simpleMessage("Número de Teléfono"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Número de teléfono ya utilizado"),
        "phoneNumberIsNotValid": MessageLookupByLibrary.simpleMessage(
            "El número de teléfono no es válido"),
        "phoneNumberIsRequired": MessageLookupByLibrary.simpleMessage(
            "Se requiere número de teléfono"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("Seleccionar y subir archivo"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("Seleccionar Fecha de Fin"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Seleccionar Fecha de Inicio"),
        "plan": MessageLookupByLibrary.simpleMessage("Plan"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("Por favor, añade cantidad"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Por favor verifica tu conectividad a internet"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Por favor, conecta la impresora primero"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Por favor conecta tu impresora Bluetooth"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Por favor, ingresa una contraseña más grande"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Por favor ingresa una contraseña de confirmación"),
        "pleaseEnterAPassword": MessageLookupByLibrary.simpleMessage(
            "Por favor ingresa una contraseña"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Por favor, ingresa un correo electrónico válido"),
        "pleaseEnterName": MessageLookupByLibrary.simpleMessage(
            "Por favor, ingresa un nombre"),
        "pleaseEnterPassword": MessageLookupByLibrary.simpleMessage(
            "Por favor ingrese la contraseña"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Por favor ingresa tu dirección de correo electrónico a continuación para recibir el enlace de restablecimiento de contraseña."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Por favor, introduce el número de transacción"),
        "pleaseInterAmount": MessageLookupByLibrary.simpleMessage(
            "Por favor, ingresa la cantidad"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Por favor selecciona una categoría primero"),
        "pleaseSelectAPlan": MessageLookupByLibrary.simpleMessage(
            "Por favor, selecciona un plan"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Por favor selecciona la categoría de negocio"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Por favor, utiliza el código de compra válido para usar la aplicación"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Impulsado por Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Desarrollado Por"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Soporte premium al cliente"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Plan premium"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Montos de Pagos Anteriores"),
        "price": MessageLookupByLibrary.simpleMessage("Precio"),
        "print": MessageLookupByLibrary.simpleMessage("Imprimir"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Opción de Impresión"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Política de privacidad"),
        "product": MessageLookupByLibrary.simpleMessage("Producto"),
        "productCode":
            MessageLookupByLibrary.simpleMessage("Código de Producto"),
        "productCodeIsRequired": MessageLookupByLibrary.simpleMessage(
            "El código del producto es obligatorio"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Código/Nombre del producto"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Descripción del Producto"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Detalles del producto"),
        "productList":
            MessageLookupByLibrary.simpleMessage("Lista de Productos"),
        "productName":
            MessageLookupByLibrary.simpleMessage("Nombre del Producto"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "El nombre del producto ya existe en este almacén"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "El nombre del producto ya ha sido añadido"),
        "productNameIsRequired": MessageLookupByLibrary.simpleMessage(
            "El nombre del producto es obligatorio"),
        "products": MessageLookupByLibrary.simpleMessage("Productos"),
        "profile": MessageLookupByLibrary.simpleMessage("Perfil"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("Editar perfil"),
        "profit": MessageLookupByLibrary.simpleMessage("Ganancia"),
        "promo": MessageLookupByLibrary.simpleMessage("promoción"),
        "promoCode":
            MessageLookupByLibrary.simpleMessage("Código de Promoción"),
        "purchase": MessageLookupByLibrary.simpleMessage("Compra"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("Alarma de Compra"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Compra Confirmada"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Detalles de la Compra"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Factura de Compra"),
        "purchaseList":
            MessageLookupByLibrary.simpleMessage("Lista de Compras"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Comprar Ahora"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Comprar plan premium"),
        "purchasePrice":
            MessageLookupByLibrary.simpleMessage("Precio de Compra"),
        "purchasePriceIsRequired": MessageLookupByLibrary.simpleMessage(
            "El precio de compra es obligatorio"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("Reporte de Compra"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Reportes de Compra"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Informes de Compra"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("Devolución de Compra"),
        "purchaseReturnReport": MessageLookupByLibrary.simpleMessage(
            "Informe de Devolución de Compra"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Transacción de Compra"),
        "qty": MessageLookupByLibrary.simpleMessage("Ctd."),
        "quantity": MessageLookupByLibrary.simpleMessage("Cantidad"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Transacciones Recientes"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("Recibido el PIN"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Número de Referencia"),
        "register": MessageLookupByLibrary.simpleMessage("Registrarse"),
        "registering": MessageLookupByLibrary.simpleMessage("Registrando"),
        "remainingDue":
            MessageLookupByLibrary.simpleMessage("Pendiente Restante"),
        "remove": MessageLookupByLibrary.simpleMessage("Eliminar"),
        "reports": MessageLookupByLibrary.simpleMessage("Reportes"),
        "requestHasBeenSend": MessageLookupByLibrary.simpleMessage(
            "La solicitud ha sido enviada"),
        "resendCode": MessageLookupByLibrary.simpleMessage("Reenviar Código"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("Reenviar OTP: "),
        "retailer": MessageLookupByLibrary.simpleMessage("Minorista"),
        "retur": MessageLookupByLibrary.simpleMessage("Devolución"),
        "returN": MessageLookupByLibrary.simpleMessage("Devolución"),
        "returnAMount":
            MessageLookupByLibrary.simpleMessage("Monto de Devolución"),
        "returnAmount":
            MessageLookupByLibrary.simpleMessage("Monto de Devolución"),
        "returnQTY":
            MessageLookupByLibrary.simpleMessage("Cantidad de Devolución"),
        "revenue": MessageLookupByLibrary.simpleMessage("Ingresos"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Proteja los datos de su negocio sin esfuerzo. Nuestra Actualización ilimitada de Pos Saas POS incluye copias de seguridad gratuitas de datos, garantizando que su información valiosa esté protegida contra eventos imprevistos. Concéntrese en lo que realmente importa: el crecimiento de su negocio."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Monto de Venta"),
        "saleDetails":
            MessageLookupByLibrary.simpleMessage("Detalles de la Venta"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Precio de Venta"),
        "saleReports": MessageLookupByLibrary.simpleMessage("Reporte de Venta"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Informes de Venta"),
        "saleReturn":
            MessageLookupByLibrary.simpleMessage("Devolución de Venta"),
        "saleReturnReport": MessageLookupByLibrary.simpleMessage(
            "Informe de Devolución de Venta"),
        "saleSetting":
            MessageLookupByLibrary.simpleMessage("Configuración de Venta"),
        "sales": MessageLookupByLibrary.simpleMessage("Ventas"),
        "salesAndPurchaseReports": MessageLookupByLibrary.simpleMessage(
            "Informes de Ventas y Compras"),
        "salesList": MessageLookupByLibrary.simpleMessage("Lista de Ventas"),
        "salesReturn":
            MessageLookupByLibrary.simpleMessage("Devolución de Ventas"),
        "save": MessageLookupByLibrary.simpleMessage("Guardar"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Guardar y Publicar"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("Guardar Cambios"),
        "saving": MessageLookupByLibrary.simpleMessage("Guardando"),
        "scanProductQRCode": MessageLookupByLibrary.simpleMessage(
            "Escanea el código QR del producto"),
        "search": MessageLookupByLibrary.simpleMessage("Buscar"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Buscar por código o nombre del producto"),
        "seeAllPromoCode": MessageLookupByLibrary.simpleMessage(
            "Ver todos los códigos de promoción"),
        "select": MessageLookupByLibrary.simpleMessage("Seleccionar"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Selecciona un producto para devolver"),
        "selectBrand":
            MessageLookupByLibrary.simpleMessage("Seleccionar marca"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Seleccionar categoría"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Seleccionar Contactos"),
        "selectProductCategory": MessageLookupByLibrary.simpleMessage(
            "Seleccionar categoría de producto"),
        "selectShopCategory": MessageLookupByLibrary.simpleMessage(
            "Seleccionar categoría de tienda"),
        "selectTax":
            MessageLookupByLibrary.simpleMessage("Seleccionar impuesto"),
        "selectTaxType": MessageLookupByLibrary.simpleMessage(
            "Seleccionar tipo de impuesto"),
        "selectUnit":
            MessageLookupByLibrary.simpleMessage("Seleccionar unidad"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Seleccionar Variación: "),
        "seller": MessageLookupByLibrary.simpleMessage("Vendedor"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Vendidos Por"),
        "send": MessageLookupByLibrary.simpleMessage("Enviar"),
        "sendEmail":
            MessageLookupByLibrary.simpleMessage("Enviar Correo Electrónico"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Enviar Mensaje"),
        "sendResetLink": MessageLookupByLibrary.simpleMessage(
            "Enviar Enlace de Restablecimiento"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Enviar SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Enviar SMS?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Enviar mensaje por WhatsApp"),
        "sendYOurEmail": MessageLookupByLibrary.simpleMessage(
            "Enviar Tu Correo Electrónico"),
        "sendingEmail":
            MessageLookupByLibrary.simpleMessage("Enviando Correo Electrónico"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Enviando mensaje"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Servicio/Envío"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Configura tu Perfil"),
        "setting": MessageLookupByLibrary.simpleMessage("Configuración"),
        "share": MessageLookupByLibrary.simpleMessage("Compartir"),
        "shopGST": MessageLookupByLibrary.simpleMessage("GST de la tienda"),
        "signIn": MessageLookupByLibrary.simpleMessage("Iniciar sesión"),
        "signInWithEmail": MessageLookupByLibrary.simpleMessage(
            "Iniciar sesión con correo electrónico"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Firma del Cliente"),
        "size": MessageLookupByLibrary.simpleMessage("Tamaño"),
        "skip": MessageLookupByLibrary.simpleMessage("Omitir"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Marketing Social"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Lo sentimos, no tienes permiso para acceder a este servicio"),
        "startDate": MessageLookupByLibrary.simpleMessage("Fecha de Inicio"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Iniciar Nueva Venta"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage(
            "Comienza a escribir para buscar"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Permanezca a la vanguardia de los avances tecnológicos sin costos adicionales. Nuestra Actualización ilimitada de Pos Saas POS garantiza que siempre tenga las últimas herramientas y características a su alcance, garantizando que su negocio permanezca a la vanguardia."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("Aún No Pagado"),
        "stock": MessageLookupByLibrary.simpleMessage("Stock"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("El stock es obligatorio"),
        "stockList":
            MessageLookupByLibrary.simpleMessage("Lista de Inventario"),
        "stocks": MessageLookupByLibrary.simpleMessage("Existencias"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Se requiere permiso de almacenamiento para crear un archivo de Excel"),
        "subTaxList":
            MessageLookupByLibrary.simpleMessage("Lista de Subimpuestos"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Subimpuestos"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Subtotal"),
        "submit": MessageLookupByLibrary.simpleMessage("Enviar"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "Suscríbete a Nuestro\\nYoutube"),
        "subscription": MessageLookupByLibrary.simpleMessage("Suscripción"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Hecho con Éxito"),
        "successfullyLoggedOut": MessageLookupByLibrary.simpleMessage(
            "Has cerrado sesión con éxito"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Actualizado con éxito"),
        "supplier": MessageLookupByLibrary.simpleMessage("Proveedor"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("Nombre del Proveedor"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("Código SWIFT"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Toma una foto de la licencia de conducir, cédula de identidad o pasaporte"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "Lleve una tarjeta NID para verificar su información"),
        "tap": MessageLookupByLibrary.simpleMessage("Tocar"),
        "tax": MessageLookupByLibrary.simpleMessage("Impuesto"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Grupo de impuestos"),
        "taxPercentage":
            MessageLookupByLibrary.simpleMessage("Porcentaje de Impuesto"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Tasa de impuesto"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Tasas de impuestos - Administre sus tasas de impuestos"),
        "taxReport":
            MessageLookupByLibrary.simpleMessage("Informe de impuestos"),
        "taxType": MessageLookupByLibrary.simpleMessage("Tipo de impuesto"),
        "taxes": MessageLookupByLibrary.simpleMessage("Impuestos"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Términos y condiciones"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("Términos de uso"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Términos y Privacidad"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Gracias por tu pago pendiente"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Gracias"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Gracias por tu compra"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "La cuenta ya existe para ese correo electrónico"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "El archivo de Excel ya ha sido descargado"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "El nombre lo dice todo. Con Pos Saas POS Unlimited, no hay límite en su uso. Ya sea que esté procesando un puñado de transacciones o experimentando un aumento de clientes, puede operar con confianza, sabiendo que no tiene restricciones."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "La contraseña proporcionada es demasiado débil"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "La venta será eliminada y todos los datos sobre esta compra serán borrados. ¿Estás seguro de eliminar esto?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "La venta será eliminada y todos los datos sobre esta venta serán borrados. ¿Estás seguro de eliminar esto?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "El usuario será eliminado y todos los datos se borrarán de tu cuenta. ¿Estás seguro de eliminar esto?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "El usuario será eliminado y todos los datos serán eliminados de tu cuenta. ¿Estás seguro de que deseas eliminar esto?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Servicios de Terceros"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Esta categoría no se puede eliminar"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Este Mes)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Este producto ya ha sido agregado"),
        "title": MessageLookupByLibrary.simpleMessage("Título"),
        "titleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "El título no puede estar vacío"),
        "to": MessageLookupByLibrary.simpleMessage("a"),
        "toDate": MessageLookupByLibrary.simpleMessage("Hasta Fecha"),
        "today": MessageLookupByLibrary.simpleMessage("Hoy"),
        "total": MessageLookupByLibrary.simpleMessage("Total"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Monto Total"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Total Recaudado"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Total Pendiente"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("Gasto Total"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Pérdida total"),
        "totalPayable": MessageLookupByLibrary.simpleMessage("Total a Pagar"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Precio Total"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("Total de productos"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Ganancia total"),
        "totalPurchase":
            MessageLookupByLibrary.simpleMessage("Total de Compra"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Total de Devoluciones"),
        "totalReturns":
            MessageLookupByLibrary.simpleMessage("Total de devoluciones"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Total de Ventas"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Inventario total"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Valor total"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Total IVA"),
        "totals": MessageLookupByLibrary.simpleMessage("Total: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Transacción"),
        "transactionId":
            MessageLookupByLibrary.simpleMessage("ID de transacción"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Intentar de Nuevo"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Tipo"),
        "unitName": MessageLookupByLibrary.simpleMessage("Nombre de la Unidad"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Precio Unitario"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Precio Unitario"),
        "units": MessageLookupByLibrary.simpleMessage("Unidades"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Ilimitado"),
        "unlimitedUsage": MessageLookupByLibrary.simpleMessage("Uso ilimitado"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Desbloquee el potencial completo de Pos Saas POS con sesiones de capacitación personalizadas dirigidas por nuestro equipo de expertos. Desde lo básico hasta las técnicas avanzadas, nos aseguramos de que esté bien versado en la utilización de cada aspecto del sistema para optimizar sus procesos comerciales."),
        "unpaid": MessageLookupByLibrary.simpleMessage("No pagado"),
        "update": MessageLookupByLibrary.simpleMessage("Actualizar"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Actualizar Contacto"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Actualizar Ahora"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("Actualizar Producto"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Actualiza tu plan primero, tu límite ha sido alcanzado"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Actualizar Tu Perfil"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Actualiza tu perfil para conectar mejor con tu doctor"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Actualiza tu perfil para conectar mejor con tu cliente"),
        "updated": MessageLookupByLibrary.simpleMessage("Actualizado"),
        "upload": MessageLookupByLibrary.simpleMessage("Subir"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Cargar documento"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("Carga completada"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Cargar archivo"),
        "upplier": MessageLookupByLibrary.simpleMessage("Proveedor"),
        "usbC": MessageLookupByLibrary.simpleMessage("Usb C"),
        "use": MessageLookupByLibrary.simpleMessage("Usar"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("Usar Pos Saas"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Uso del Sistema"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Usuario eliminado"),
        "userRole": MessageLookupByLibrary.simpleMessage("Rol de usuario"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("Detalles del rol de usuario"),
        "userTitle": MessageLookupByLibrary.simpleMessage("Título de usuario"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "El título del usuario no puede estar vacío"),
        "value": MessageLookupByLibrary.simpleMessage("Valor"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("El IVA no se aplica"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("Verificando OTP"),
        "verifyPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Verificar Número de Teléfono"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Ver Todo"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("Ver Detalles"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Cliente sin Cita"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Almacén"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("El almacén ya existe"),
        "warehouseList":
            MessageLookupByLibrary.simpleMessage("Lista de almacenes"),
        "warehouseName":
            MessageLookupByLibrary.simpleMessage("Nombre del almacén"),
        "warranty": MessageLookupByLibrary.simpleMessage("Garantía"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Hemos enviado un correo electrónico con instrucciones sobre cómo restablecer la contraseña a:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Podemos utilizar servicios de terceros para respaldar la funcionalidad de nuestra aplicación, como proveedores de análisis y procesadores de pagos. Estos servicios de terceros pueden recopilar información sobre usted cuando utiliza nuestra aplicación. Tenga en cuenta que no somos responsables de las prácticas de privacidad de estos servicios de terceros."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Tomamos medidas estándar de la industria para proteger su información personal, incluyendo la encriptación y el almacenamiento seguro. También limitamos el acceso a su información solo al personal autorizado."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Entendemos la importancia de las operaciones sin problemas. Por eso, nuestro soporte las 24 horas del día está disponible para ayudarlo, ya sea una consulta rápida o una preocupación integral. Conéctese con nosotros en cualquier momento y en cualquier lugar a través de llamadas o WhatsApp para experimentar un servicio al cliente insuperable."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Utilizamos su información personal para proporcionarle la mejor experiencia posible en nuestra aplicación, incluyendo la personalización de recomendaciones de contenido, conectarlo con expertos y mejorar la funcionalidad de nuestra aplicación. También podemos utilizar su información para comunicarnos con usted acerca de actualizaciones, promociones u otra información relacionada con nuestra aplicación."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Revisaremos el pago y lo aprobaremos en 1-2 horas"),
        "weekly": MessageLookupByLibrary.simpleMessage("Semanal"),
        "weight": MessageLookupByLibrary.simpleMessage("Peso"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Novedades"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Mayorista"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Precio al Por Mayor"),
        "wholesalePrice":
            MessageLookupByLibrary.simpleMessage("Precio mayorista"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Mayorista"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Se añadirá pronto"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Expirará en"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Escribe tu mensaje aquí"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("OTP incorrecto"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Contraseña incorrecta proporcionada para ese usuario."),
        "yearly": MessageLookupByLibrary.simpleMessage("Anual"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Sí, Eliminar para Siempre"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("No eres un usuario válido"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Estás usando"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "No puedes pagar más que el adeudado"),
        "youHaveGotAnEmail": MessageLookupByLibrary.simpleMessage(
            "Has recibido un correo electrónico"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Has iniciado sesión correctamente en tu cuenta. Mantente con Pos Saas ."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("Debes dar permiso"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Debe VOLVER A INICIAR SESIÓN en su cuenta"),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Necesitas verificar tu identidad antes de comprar por SMS"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Tu mensaje permanece"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Tu paquete"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Tu paquete expirará en 5 días")
      };
}
