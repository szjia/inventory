// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a mr locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'mr';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("बिलप्लझ"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("सुरू ठेवा"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("GST नंबर"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("इयाझिको"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("एमआरपी"),
        "MRPIsRequired": MessageLookupByLibrary.simpleMessage("MRP आवश्यक आहे"),
        "OK": MessageLookupByLibrary.simpleMessage("ठीक आहे"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("पेपाल"),
        "PhNo": MessageLookupByLibrary.simpleMessage("फोन नं"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("रेझरपेय"),
        "SL": MessageLookupByLibrary.simpleMessage("स्ल"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT कोड"),
        "Snacks": MessageLookupByLibrary.simpleMessage("स्नॅक्स"),
        "TAX": MessageLookupByLibrary.simpleMessage("कर"),
        "Uploading": MessageLookupByLibrary.simpleMessage("अपलोड करत आहे"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("वापरकर्ता शीर्षक"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "तुमच्या पॅकेजची किंमत आज संपेल\n\nकृपया पुन्हा खरेदी करा"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) The System is provided solely for the\npurpose of facilitating point of sale\ntransactions andrelatedactivities in your\nbusiness."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) To use the System, you may be\nrequired to create an account. You\nagree to provide accurate, current, and\ncomplete information during\nthe registration process and toupdate\nsuchinformationto keep itaccurate\nand complete."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("अॅपच्या विषयी"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("आमच्या विषयी"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Acceptance of Terms"),
        "accountName": MessageLookupByLibrary.simpleMessage("खात्याचं नाव"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("खातेचं नंबर"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Account Registration"),
        "acton": MessageLookupByLibrary.simpleMessage("कृती"),
        "add": MessageLookupByLibrary.simpleMessage("अतिरिक्त करा"),
        "addBrand": MessageLookupByLibrary.simpleMessage("ब्रँड जोडा"),
        "addCategory": MessageLookupByLibrary.simpleMessage("श्रेणी जोडा"),
        "addContact": MessageLookupByLibrary.simpleMessage("संपर्क जोडा"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("ग्राहक जोडा"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("पोहचविणे जोडा"),
        "addDescriptioN": MessageLookupByLibrary.simpleMessage("वर्णन जोडा"),
        "addDescription": MessageLookupByLibrary.simpleMessage("टिप्पणी जोडा"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("सवलत जोडा"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("दस्तऐवज आयडी जोडा"),
        "addDucument": MessageLookupByLibrary.simpleMessage("दस्तऐवज जोडा"),
        "addExpense": MessageLookupByLibrary.simpleMessage("खर्च जोडा"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("खर्च श्रेणी जोडा"),
        "addItems": MessageLookupByLibrary.simpleMessage("आयटम जोडा"),
        "addNew": MessageLookupByLibrary.simpleMessage("नवीन जोडा"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("नवीन पत्ता जोडा"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("नवीन उत्पादन जोडा"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("नवीन कर जोडा"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "एकल/अनेक कर प्रकारांसह नवीन कर जोडा"),
        "addNote": MessageLookupByLibrary.simpleMessage("टिप्पणी जोडा"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("आधी उत्पादन जोडा"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("प्रमोशन कोड जोडा"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("खरेदी जोडा"),
        "addSales": MessageLookupByLibrary.simpleMessage("विक्री जोडा"),
        "addSuccessful": MessageLookupByLibrary.simpleMessage("सफळतेच जोडले"),
        "addUnit": MessageLookupByLibrary.simpleMessage("यूनिट जोडा"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("वापरकर्ता भूमिका जोडा"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("यशस्वीरित्या जोडले"),
        "addedToCart": MessageLookupByLibrary.simpleMessage("गाडीत जोडले"),
        "address": MessageLookupByLibrary.simpleMessage("पत्ता"),
        "admin": MessageLookupByLibrary.simpleMessage("व्यवस्थापक"),
        "all": MessageLookupByLibrary.simpleMessage("सर्व"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("सर्व व्यवसाय सोल्यूशन्स"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("आधीच जोडले"),
        "alreadyExists":
            MessageLookupByLibrary.simpleMessage("आधीच अस्तित्वात आहे"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("आधीच खाते आहेत का?"),
        "amount": MessageLookupByLibrary.simpleMessage("रक्कम"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "एक ईमेल पाठवण्यात आला आहे\\nतुमच्या इनबॉक्समध्ये तपासा"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "एंड्रॉइड आणि iOS अ‍ॅप समर्थन"),
        "applicableTax": MessageLookupByLibrary.simpleMessage("लागू कर"),
        "apply": MessageLookupByLibrary.simpleMessage("लागू करा"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "आपण ही चलन मिटविण्याची खात्री करता का?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "आपण या विक्री मिटवण्याची खात्री करता का?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "तुम्हाला हा वापरकर्ता हटवायचा आहे का?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "तुम्ही हा कर हटवू इच्छिता का?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "तुम्ही हा कर गट हटवू इच्छिता का?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "तुम्ही हे गोदाम हटवू इच्छिता का?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "तुम्हाला खात्री आहे कि तुम्ही ही वापरकर्ता हटवू इच्छिता?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("अधिकृत सही"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) You are responsible for\nmaintainingthe confidentiality of your\naccount and password andfor restricting\naccess to your account. You accept\nresponsibility for all activities that\noccur under your account."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) You must be at least 18 years old or the\nlegal age of majority in your jurisdiction to\nuse the System."),
        "backSide": MessageLookupByLibrary.simpleMessage("पाठीवरती दिशा"),
        "backToHome":
            MessageLookupByLibrary.simpleMessage("मुख्यपृष्ठावर परत जा"),
        "balance": MessageLookupByLibrary.simpleMessage("शिल्लक"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("बांग्लादेश"),
        "bank": MessageLookupByLibrary.simpleMessage("बँक"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("बँक खात्याची चलन"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("बँक खातेची मुद्रा"),
        "bankInformation": MessageLookupByLibrary.simpleMessage("बँक माहिती"),
        "bankName": MessageLookupByLibrary.simpleMessage("बँकचं नाव"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("बँक हस्तांतरण"),
        "barcodeFound": MessageLookupByLibrary.simpleMessage("बारकोड सापडला"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("बिल/चालान"),
        "billTo": MessageLookupByLibrary.simpleMessage("किंवा बिल"),
        "branchName": MessageLookupByLibrary.simpleMessage("शाखेचं नाव"),
        "brand": MessageLookupByLibrary.simpleMessage("ब्रँड"),
        "brandName": MessageLookupByLibrary.simpleMessage("ब्रँडचे नाव"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("गुच्छ अपलोड"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("व्यवसायिक वर्ग"),
        "buy": MessageLookupByLibrary.simpleMessage("खरेदी"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("प्रीमियम प्लॅन खरेदी करा"),
        "buySms": MessageLookupByLibrary.simpleMessage("SMS विका"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "By accessing or using the Point of Sale (POS) System (the \"System\") provided by [Your Company Name] (\"Company\"), you agree to be bound by these Terms of Use. If you do not agree to these Terms of Use, do not use the System."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) You are responsible for ensuring that your\naccess to and use of the System is in\ncompliance with all applicable laws and\nregulations."),
        "cacel": MessageLookupByLibrary.simpleMessage("रद्द करा"),
        "call": MessageLookupByLibrary.simpleMessage("कॉल"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "आपत्कालीन सहाय्याकरिता कॉल करा"),
        "camera": MessageLookupByLibrary.simpleMessage("कॅमेरा"),
        "cancel": MessageLookupByLibrary.simpleMessage("रद्द करा"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("सर्व उत्पादने रद्द करा"),
        "capacity": MessageLookupByLibrary.simpleMessage("क्षमता"),
        "card": MessageLookupByLibrary.simpleMessage("कार्ड"),
        "cash": MessageLookupByLibrary.simpleMessage("कॅश"),
        "cashFree": MessageLookupByLibrary.simpleMessage("कॅश फ्री"),
        "categories": MessageLookupByLibrary.simpleMessage("श्रेण्या"),
        "category": MessageLookupByLibrary.simpleMessage("श्रेणी"),
        "categoryName": MessageLookupByLibrary.simpleMessage("श्रेणीचे नाव"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "श्रेणीचे नाव आधीच अस्तित्वात आहे"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("श्रेणीचे नाव"),
        "change": MessageLookupByLibrary.simpleMessage("बदला?"),
        "changePassword": MessageLookupByLibrary.simpleMessage("पासवर्ड बदला"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("ईमेल तपासा"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("एक ग्राहक निवडा"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("एक दुकान निवडा"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("तुमच्या सुविधांची निवड करा"),
        "clarence": MessageLookupByLibrary.simpleMessage("क्लॅरेन्स"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("कनेक्ट करण्यासाठी क्लिक करा"),
        "close": MessageLookupByLibrary.simpleMessage("बंद"),
        "color": MessageLookupByLibrary.simpleMessage("रंग"),
        "combinationOfMultipleTaxes":
            MessageLookupByLibrary.simpleMessage("(अनेक करांचा संयोजन)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("लवकरच येत आहे"),
        "companyAddress": MessageLookupByLibrary.simpleMessage("कंपनीचा पत्ता"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("कंपनी आणि दुकानचे नाव"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("कंपनी आणि व्यवसायाचे नाव"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("व्यवहार पूर्ण करा"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("पासवर्ड कन्फर्म करा"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("परतावा निश्चित करा"),
        "congratulations": MessageLookupByLibrary.simpleMessage("अभिनंदन"),
        "contactUs": MessageLookupByLibrary.simpleMessage("आमसे संपर्क साधा"),
        "continu": MessageLookupByLibrary.simpleMessage("सुरू ठेवा"),
        "country": MessageLookupByLibrary.simpleMessage("देश"),
        "create": MessageLookupByLibrary.simpleMessage("निर्मिती करा"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("एक विनामूल्य खाता तयार करा"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("निर्मित आणि सेव्ह केले"),
        "currency": MessageLookupByLibrary.simpleMessage("मुद्रा"),
        "currentStock": MessageLookupByLibrary.simpleMessage("चालू स्टॉक"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("कस्टम चलन ब्रँडिंग"),
        "customer": MessageLookupByLibrary.simpleMessage("ग्राहक"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("ग्राहकाची माहिती"),
        "customerGST": MessageLookupByLibrary.simpleMessage("ग्राहक GST"),
        "customerName": MessageLookupByLibrary.simpleMessage("ग्राहकाचं नाव"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("दैनिक व्यवहार"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Dashboard Overview"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("डेटा यशस्वीरित्या जतन केला"),
        "date": MessageLookupByLibrary.simpleMessage("तारीख"),
        "day": MessageLookupByLibrary.simpleMessage("दिवस"),
        "dealer": MessageLookupByLibrary.simpleMessage("विक्रेता"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("डीलर किंमत"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("डिफॉल्ट VAT टक्केवारी"),
        "delete": MessageLookupByLibrary.simpleMessage("काढून टाका"),
        "deleting": MessageLookupByLibrary.simpleMessage("मिटविणे"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("पोहचविण्याचा पत्ता"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("वितरण पत्ते"),
        "deliveryCharge": MessageLookupByLibrary.simpleMessage("वितरण शुल्क"),
        "describtion": MessageLookupByLibrary.simpleMessage("वर्णन"),
        "description": MessageLookupByLibrary.simpleMessage("वर्णन"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("वर्णन रिकामे असू शकत नाही"),
        "details": MessageLookupByLibrary.simpleMessage("तपशील"),
        "discount": MessageLookupByLibrary.simpleMessage("सवलत"),
        "doNotDistrub":
            MessageLookupByLibrary.simpleMessage("अडचण देण्यात येत नाही"),
        "done": MessageLookupByLibrary.simpleMessage("झाले"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Excel स्वरूप डाउनलोड करा"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "डाउनलोड फोल्डरमध्ये यशस्वीरित्या डाउनलोड झाले"),
        "due": MessageLookupByLibrary.simpleMessage("बाकी"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("बाकी रक्कम: "),
        "dueCollection": MessageLookupByLibrary.simpleMessage("बाकी संग्रहण"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("बाकी संग्रह अहवाल"),
        "dueList": MessageLookupByLibrary.simpleMessage("बाकीची यादी"),
        "dueReports": MessageLookupByLibrary.simpleMessage("बाकी अहवाल"),
        "duration": MessageLookupByLibrary.simpleMessage("कालावधी"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("कालावधी: कडून"),
        "easyToUseMobilePos":
            MessageLookupByLibrary.simpleMessage("मोबाइल पॉझ वापरणे सोपे"),
        "edit": MessageLookupByLibrary.simpleMessage("संपादित करा"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("खरेदी चलन संपादित करा"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("विक्री चलन संपादित करा"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("सोशल मीडिया संपादित करा"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("संपादित यशस्वी"),
        "editTax": MessageLookupByLibrary.simpleMessage("कर संपादित करा"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("कर गट संपादित करा"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("गोदाम संपादित करा"),
        "email": MessageLookupByLibrary.simpleMessage("ईमेल"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("ईमेल पत्ता"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("ईमेल रिकामे असू शकत नाही"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "ईमेल पाठवले! आपला इनबॉक्स तपासा"),
        "endDate": MessageLookupByLibrary.simpleMessage("समाप्ती तारीख"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("वैध रक्कम प्रविष्ट करा"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("वैध सवलत प्रविष्ट करा"),
        "enterAValidPhoneNumber":
            MessageLookupByLibrary.simpleMessage("वैध फोन नंबर प्रविष्ट करा"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("वैध किंमत प्रविष्ट करा"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("वैध प्रमाण प्रविष्ट करा"),
        "enterAddress":
            MessageLookupByLibrary.simpleMessage("पत्ता प्रविष्ट करा"),
        "enterAmount":
            MessageLookupByLibrary.simpleMessage("रक्कम प्रविष्ट करा"),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("ब्रँडचे नाव प्रविष्ट करा"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("क्षमता प्रविष्ट करा"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("श्रेणीचे नाव प्रविष्ट करा"),
        "enterColor": MessageLookupByLibrary.simpleMessage("रंग प्रविष्ट करा"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "ग्राहकाचा GST नंबर प्रविष्ट करा"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("डीलर किंमत प्रविष्ट करा"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("वर्णन प्रविष्ट करा"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("सूट प्रविष्ट करा."),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("खर्च तारीख प्रविष्ट करा"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("पूर्ण पत्ता प्रविष्ट करा"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("चलन क्रमांक प्रविष्ट करा"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "कमी स्टॉक अलार्म रक्कम प्रविष्ट करा"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("निर्माता प्रविष्ट करा"),
        "enterMessageContent": MessageLookupByLibrary.simpleMessage(
            "संदेशाची सामग्री प्रविष्ट करा"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "एमआरपी / खुदरा किंमत प्रविष्ट करा"),
        "enterName": MessageLookupByLibrary.simpleMessage("नाव प्रविष्ट करा"),
        "enterNote":
            MessageLookupByLibrary.simpleMessage("टिप्पणी प्रविष्ट करा"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("पक्षाचं नाव प्रविष्ट करा"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("फोन नंबर प्रविष्ट करा"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "उत्पादन कोड प्रविष्ट करा किंवा स्कॅन करा"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("उत्पादनाचे नाव प्रविष्ट करा"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("खरेदी किंमत प्रविष्ट करा."),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("संदर्भ क्रमांक प्रविष्ट करा"),
        "enterSize": MessageLookupByLibrary.simpleMessage("आकार प्रविष्ट करा"),
        "enterStocks":
            MessageLookupByLibrary.simpleMessage("स्टॉक्स प्रविष्ट करा."),
        "enterTaxRate": MessageLookupByLibrary.simpleMessage("कर दर भरा"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("व्यवहार आयडी प्रविष्ट करा"),
        "enterType":
            MessageLookupByLibrary.simpleMessage("प्रकार प्रविष्ट करा"),
        "enterUserTitle": MessageLookupByLibrary.simpleMessage(
            "वापरकर्ता शीर्षक प्रविष्ट करा"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("वैध रक्कम प्रविष्ट करा"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("गोदामाचे नाव भरा"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("वजन प्रविष्ट करा"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("होलसेल किंमत प्रविष्ट करा"),
        "enterYourDescriptionHere": MessageLookupByLibrary.simpleMessage(
            "तुमच्या वर्णनाचे येथे प्रविष्ट करा"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "तुमचा ईमेल पत्ता प्रविष्ट करा"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "तुमच्या प्रतिसादाचा शीर्षक प्रविष्ट करा"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("तुमचा GST नंबर प्रविष्ट करा"),
        "enterYourMobileNumber": MessageLookupByLibrary.simpleMessage(
            "तुमचा मोबाइल नंबर प्रविष्ट करा"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("तुमचं नाव प्रविष्ट करा"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("तुमचा फोन नंबर प्रविष्ट करा"),
        "enterYourPassword": MessageLookupByLibrary.simpleMessage(
            "तुमचा संकेतशब्द प्रविष्ट करा"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("तुमचा फोन नंबर प्रविष्ट करा"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "तुमचा व्यवहार आयडी प्रविष्ट करा"),
        "error": MessageLookupByLibrary.simpleMessage("चूक"),
        "excTax": MessageLookupByLibrary.simpleMessage("अपवादित कर"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("Excel अपलोडर"),
        "exclusive": MessageLookupByLibrary.simpleMessage("विशिष्ट"),
        "expense": MessageLookupByLibrary.simpleMessage("खर्च"),
        "expenseCategory": MessageLookupByLibrary.simpleMessage("खर्च श्रेणी"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("खर्च तारीख"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("खर्च किंवा"),
        "expenseReport": MessageLookupByLibrary.simpleMessage("खर्च अहवाल"),
        "expireDate": MessageLookupByLibrary.simpleMessage("गुजरात तारीख"),
        "expired": MessageLookupByLibrary.simpleMessage("कालबाह्य"),
        "expiring": MessageLookupByLibrary.simpleMessage("संपणार आहे"),
        "facebok": MessageLookupByLibrary.simpleMessage("फेसबुक"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("त्रुटीने अपयशी"),
        "fashion": MessageLookupByLibrary.simpleMessage("फैशन"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "सुविधा त्या महत्त्वपूर्ण भाग आहेत ज्याने स्मार्ट बिजनेस वापरकर्त्यांना पारंपारिक सोल्यूशनपासून वेगवेगळ्या बनविल्या आहेत."),
        "feedBack": MessageLookupByLibrary.simpleMessage("प्रतिसाद"),
        "firstName": MessageLookupByLibrary.simpleMessage("पहिलं नाव"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("फेसबुकवर आम्हाला फॉलो करा"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("ट्विटरवर आम्हाला फॉलो करा"),
        "fontSide": MessageLookupByLibrary.simpleMessage("मुख्य दिशा"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("अमर्यादित वापरसाठी"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("पासवर्ड विसरलात"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("पासवर्ड विसरलात?"),
        "formDate": MessageLookupByLibrary.simpleMessage("तारीखपासून"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("मोफत डेटा संग्रहण"),
        "freeLifeTimeUpdate":
            MessageLookupByLibrary.simpleMessage("मोफत आयुष्य अपडेट"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("फ्री पॅकेज"),
        "freePlan": MessageLookupByLibrary.simpleMessage("फ्री प्लॅन"),
        "from": MessageLookupByLibrary.simpleMessage("(कडून"),
        "fullyPaid":
            MessageLookupByLibrary.simpleMessage("पूर्णपणे भरण्यात आले"),
        "gallary": MessageLookupByLibrary.simpleMessage("गॅलरी"),
        "generatingPDF":
            MessageLookupByLibrary.simpleMessage("पीडीएफ तयार करीत आहे"),
        "getOtp": MessageLookupByLibrary.simpleMessage("ओटीपी मिळवा"),
        "govermentId": MessageLookupByLibrary.simpleMessage("सरकारी ओळखपत्र"),
        "guest": MessageLookupByLibrary.simpleMessage("गेस्ट"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("तुमच्याकडे खाते नाही का?"),
        "history": MessageLookupByLibrary.simpleMessage("इतिहास"),
        "home": MessageLookupByLibrary.simpleMessage("होम"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "How We Protect Your Information"),
        "howWeUseYourInformation":
            MessageLookupByLibrary.simpleMessage("How We Use Your Information"),
        "identityVerify": MessageLookupByLibrary.simpleMessage("तपशील सत्यापन"),
        "image": MessageLookupByLibrary.simpleMessage("प्रतिमा"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("घरात हटवता येत नाही"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("घरात संपादित करता येत नाही"),
        "inWord": MessageLookupByLibrary.simpleMessage("शब्दात"),
        "incTax": MessageLookupByLibrary.simpleMessage("समाविष्ट कर"),
        "inclusive": MessageLookupByLibrary.simpleMessage("समावेशी"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("स्टॉक वाढवा"),
        "inistrument": MessageLookupByLibrary.simpleMessage("यंत्रिका"),
        "instragram": MessageLookupByLibrary.simpleMessage("इंस्टाग्राम"),
        "invNo": MessageLookupByLibrary.simpleMessage("चलन क्रमांक"),
        "invoice": MessageLookupByLibrary.simpleMessage("चलान"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("चलन क्रमांक"),
        "invoiceSetting": MessageLookupByLibrary.simpleMessage("चलन सेटिंग"),
        "invoiceViewer": MessageLookupByLibrary.simpleMessage("चलान दर्शक"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("आयटम जोडले आहे"),
        "kg": MessageLookupByLibrary.simpleMessage("किलोग्रॅम"),
        "kycVerification": MessageLookupByLibrary.simpleMessage("KYC सत्यापन"),
        "language": MessageLookupByLibrary.simpleMessage("भाषा"),
        "lastName": MessageLookupByLibrary.simpleMessage("आडनाव"),
        "ledger": MessageLookupByLibrary.simpleMessage("लेजर"),
        "lifeTimePurchase": MessageLookupByLibrary.simpleMessage("आजीवन खरेदी"),
        "link": MessageLookupByLibrary.simpleMessage("लिंक"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("लिंक्डइन"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("सक्रिय चॅट समर्थन"),
        "loading": MessageLookupByLibrary.simpleMessage("लोड करीत आहे"),
        "logIn": MessageLookupByLibrary.simpleMessage("लॉग इन करा"),
        "logOUt": MessageLookupByLibrary.simpleMessage("लॉग आउट"),
        "logOut": MessageLookupByLibrary.simpleMessage("लॉग आऊट"),
        "login": MessageLookupByLibrary.simpleMessage("लॉगिन"),
        "logo": MessageLookupByLibrary.simpleMessage("लोगो"),
        "loss": MessageLookupByLibrary.simpleMessage("नुकसान"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("नुकसान/नाफा"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("नुकसान/नाफा तपशील"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("नुकसान/नफा अहवाल"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("नुकसान/नफा अहवाला"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("कमी स्टॉक अलार्म"),
        "maan": MessageLookupByLibrary.simpleMessage("मान"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "ब्रँडेड इनव्हॉइससह तुमच्या ग्राहकांवर कायमची छाप पाडा. आमची अमर्यादित अपग्रेड तुमची इनव्हॉइस सानुकूलित करण्याचा अनोखा फायदा देते, एक व्यावसायिक स्पर्श जोडून जो तुमची ब्रँड ओळख अधिक मजबूत करते आणि ग्राहकांची निष्ठा वाढवते."),
        "manageYourBussinessWith": MessageLookupByLibrary.simpleMessage(
            "तुमच्या व्यवसायाची काळजी घ्या"),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("निर्मिती तारीख"),
        "margin": MessageLookupByLibrary.simpleMessage("मार्जिन"),
        "masterCard": MessageLookupByLibrary.simpleMessage("मास्टर कार्ड"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("निर्माता"),
        "message": MessageLookupByLibrary.simpleMessage("संदेश"),
        "messageHistory": MessageLookupByLibrary.simpleMessage("संदेश इतिहास"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "स्मार्ट बिजनेस अॅप विनामूल्य आहे, वापरण्यात सोपा आहे. वास्तविकपणे, आपल्याला त्याच्या प्रकारे व्यापारिक समस्यांसाठी एकमेव पीओएस प्रणाली आहे."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "स्मार्ट बिजनेस व्यवसाय सोल्यूशन आहे ज्यामध्ये स्टॉक, खाते, विक्री, खर्च आणि नुकसान / मुनाफा असतात."),
        "mobile": MessageLookupByLibrary.simpleMessage("मोबाइल"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("मोबाइल पेमेंट"),
        "monthly": MessageLookupByLibrary.simpleMessage("मासिक"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("अधिक माहिती"),
        "name": MessageLookupByLibrary.simpleMessage("तुमचं नाव प्रविष्ट करा"),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("नाव आधीच अस्तित्वात आहे"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("नाव रिक्त असू शकत नाही"),
        "next": MessageLookupByLibrary.simpleMessage("पुढे"),
        "noConnection":
            MessageLookupByLibrary.simpleMessage("कोणतीही कनेक्शन नाही"),
        "noData": MessageLookupByLibrary.simpleMessage("कोणतीही डेटा नाही"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("कोणतीही माहिती उपलब्ध नाही"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("कोणतीही माहिती सापडली नाही"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("कोणताही इतिहास सापडला नाही!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("कोणतेही उत्पादन सापडले नाही"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("कोणतीही उपकर निवडलेली नाही"),
        "noTransactionFound": MessageLookupByLibrary.simpleMessage(
            "कोणताही व्यवहार सापडला नाही!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "त्या ईमेलसाठी कोणत्याही वापरकर्ता सापडला नाही."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "कोणतीही वापरकर्ता भूमिका सापडली नाही"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("सक्रिय वापरकर्ता नाही"),
        "notProvided": MessageLookupByLibrary.simpleMessage("पुरवलेले नाही"),
        "note": MessageLookupByLibrary.simpleMessage("टिप्पणी"),
        "notes": MessageLookupByLibrary.simpleMessage("नोट्स"),
        "notification": MessageLookupByLibrary.simpleMessage("सूचना"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP पाठवले आहे"),
        "office": MessageLookupByLibrary.simpleMessage("कार्यालय"),
        "ok": MessageLookupByLibrary.simpleMessage("ठीक आहे"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS that contains a great deal of functionality, including sales tracking, inventory management."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "This system helps you improve your operations for your customers."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Our POS system should simplify daily operations automatically, making it easy to navigate."),
        "openingBalance": MessageLookupByLibrary.simpleMessage("आरंभीत शिल्लक"),
        "order": MessageLookupByLibrary.simpleMessage("ऑर्डर्स"),
        "other": MessageLookupByLibrary.simpleMessage("इतर"),
        "otp": MessageLookupByLibrary.simpleMessage("बंद करा"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("साठा संपला"),
        "pacakge": MessageLookupByLibrary.simpleMessage("पॅकेज"),
        "packageFeatures": MessageLookupByLibrary.simpleMessage("पॅकेज सुविधे"),
        "paid": MessageLookupByLibrary.simpleMessage("दिले"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("दिलेली रक्कम"),
        "parties": MessageLookupByLibrary.simpleMessage("पक्षे"),
        "partiesList": MessageLookupByLibrary.simpleMessage("पक्ष्याची यादी"),
        "partyGST": MessageLookupByLibrary.simpleMessage("पक्ष GST"),
        "partyName": MessageLookupByLibrary.simpleMessage("पक्षाचं नाव"),
        "password": MessageLookupByLibrary.simpleMessage("पासवर्ड"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "पासवर्ड आणि पुष्टी पासवर्ड जुळत नाहीत"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("पासवर्ड रिकामा असू शकत नाही"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("पासवर्ड जुळत नाही"),
        "payCash": MessageLookupByLibrary.simpleMessage("कॅश भरा"),
        "payStack": MessageLookupByLibrary.simpleMessage("पेयस्टॅक"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("Bkash सह पैसे द्या"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("पेपॅलसह पैसे द्या"),
        "payeeName":
            MessageLookupByLibrary.simpleMessage("पेमेंट प्राप्तकर्ता चे नाव"),
        "payeeNumber":
            MessageLookupByLibrary.simpleMessage("पेमेंट प्राप्तकर्ता ची नंबर"),
        "payment": MessageLookupByLibrary.simpleMessage("पेमेंट"),
        "paymentAmount":
            MessageLookupByLibrary.simpleMessage("पैसे देण्याची रक्कम"),
        "paymentComplete": MessageLookupByLibrary.simpleMessage("पेमेंट पूर्ण"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("पेमेंट मार्गदर्शन:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("देय पद्धत"),
        "paymentType": MessageLookupByLibrary.simpleMessage("पेमेंट प्रकार"),
        "pdfView": MessageLookupByLibrary.simpleMessage("पीडीएफ दृश्य"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("वैयक्तिक माहिती"),
        "phone": MessageLookupByLibrary.simpleMessage("फोन"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("फोन नंबर"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "फोन नंबर आधीच वापरण्यात आले आहे"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("फोन नंबर वैध नाही"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("फोन नंबर आवश्यक आहे"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("फाइल निवडा आणि अपलोड करा"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("समाप्ती तारीख निवडा"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("प्रारंभ तारीख निवडा"),
        "plan": MessageLookupByLibrary.simpleMessage("योजना"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("कृपया प्रमाण जोडा"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "कृपया आपली इंटरनेट कनेक्टिव्हिटी तपासा"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "कृपया प्रथम प्रिंटर कनेक्ट करा"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "कृपया आपला ब्लूटूथ प्रिंटर कनेक्ट करा"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "कृपया मोठा पासवर्ड प्रविष्ट करा"),
        "pleaseEnterAConfirmPassword":
            MessageLookupByLibrary.simpleMessage("कृपया पासवर्ड कन्फर्म करा"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("कृपया पासवर्ड प्रविष्ट करा"),
        "pleaseEnterAValidEmail":
            MessageLookupByLibrary.simpleMessage("कृपया वैध ईमेल प्रविष्ट करा"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("कृपया नाव प्रविष्ट करा"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("कृपया पासवर्ड भरा"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "कृपया आपला ईमेल पत्ता खालीलप्रमाणे पासवर्ड रीसेट लिंक प्राप्त करण्यासाठी प्रविष्ट करा."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "कृपया व्यवहार क्रमांक प्रविष्ट करा"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("कृपया रक्कम प्रविष्ट करा"),
        "pleaseSelectACategoryFirst":
            MessageLookupByLibrary.simpleMessage("कृपया प्रथम श्रेणी निवडा"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("कृपया एक योजना निवडा"),
        "pleaseSelectBusinessCategory":
            MessageLookupByLibrary.simpleMessage("कृपया व्यवसाय श्रेणी निवडा"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "कृपया अ‍ॅप वापरण्यासाठी वैध खरेदी कोड वापरा"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Pos Saas द्वारे संचालित"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("पॉवर्ड बाय"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("प्रीमियम ग्राहक समर्थन"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("प्रीमियम प्लॅन"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("मागील देयक रक्कमे"),
        "price": MessageLookupByLibrary.simpleMessage("किंमत"),
        "print": MessageLookupByLibrary.simpleMessage("प्रिंट करा"),
        "printingOption": MessageLookupByLibrary.simpleMessage("मुद्रण पर्याय"),
        "privacyPolicy": MessageLookupByLibrary.simpleMessage("गोपनीयता धोरण"),
        "product": MessageLookupByLibrary.simpleMessage("उत्पादन"),
        "productCode": MessageLookupByLibrary.simpleMessage("उत्पादन कोड"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("उत्पादन कोड आवश्यक आहे"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("उत्पादन कोड/नाव"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("उत्पादनाचे वर्णन"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("उत्पादनाचे तपशील"),
        "productList": MessageLookupByLibrary.simpleMessage("उत्पादन सूची"),
        "productName": MessageLookupByLibrary.simpleMessage("उत्पादनाचे नाव"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "उत्पादनाचे नाव आधीच या गोदामात अस्तित्वात आहे"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "उत्पादनाचे नाव आधीच जोडले गेले आहे"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("उत्पादनाचे नाव आवश्यक आहे"),
        "products": MessageLookupByLibrary.simpleMessage("उत्पादन"),
        "profile": MessageLookupByLibrary.simpleMessage("प्रोफाइल"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("प्रोफाइल संपादन"),
        "profit": MessageLookupByLibrary.simpleMessage("नाफा"),
        "promo": MessageLookupByLibrary.simpleMessage("प्रोमो"),
        "promoCode": MessageLookupByLibrary.simpleMessage("प्रोमो कोड"),
        "purchase": MessageLookupByLibrary.simpleMessage("खरेदी"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage("खरेदी संदेश"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("खरेदी पुष्टीकरण"),
        "purchaseDetails": MessageLookupByLibrary.simpleMessage("खरेदी तपशील"),
        "purchaseInvoice": MessageLookupByLibrary.simpleMessage("खरेदी चालान"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("खरेदी सूची"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("आता खरेदी करा"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("प्रीमियम प्लॅन खरेदी करा"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("खरेदी किंमत"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("खरेदी किंमत आवश्यक आहे"),
        "purchaseRepoet": MessageLookupByLibrary.simpleMessage("खरेदी अहवाल"),
        "purchaseReports": MessageLookupByLibrary.simpleMessage("खरेदी दर"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("किंवा दर अहवाल"),
        "purchaseReturn": MessageLookupByLibrary.simpleMessage("खरेदी परतावा"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("खरेदी परतावा अहवाल"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("खरेदी संक्रमण"),
        "qty": MessageLookupByLibrary.simpleMessage("मात्रा"),
        "quantity": MessageLookupByLibrary.simpleMessage("प्रमाण"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("अलीकडील व्यवहार"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("पिन प्राप्त झाला"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("संदर्भ क्रमांक"),
        "register": MessageLookupByLibrary.simpleMessage("नोंदणी करा"),
        "registering": MessageLookupByLibrary.simpleMessage("नोंदणी करत आहे"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("शिल्लक देयक"),
        "remove": MessageLookupByLibrary.simpleMessage("काढा"),
        "reports": MessageLookupByLibrary.simpleMessage("अहवाल"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("विनंती पाठवली गेली आहे"),
        "resendCode": MessageLookupByLibrary.simpleMessage("कोड पुन्हा पाठवा"),
        "resendOtp":
            MessageLookupByLibrary.simpleMessage("ओटीपी पुन्हा पाठवा:"),
        "retailer": MessageLookupByLibrary.simpleMessage("खुद्दार"),
        "retur": MessageLookupByLibrary.simpleMessage("परत"),
        "returN": MessageLookupByLibrary.simpleMessage("परतावा"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("परत किंमत"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("परत रक्कम"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("परतावा प्रमाण"),
        "revenue": MessageLookupByLibrary.simpleMessage("रुग्णाणी"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "तुमचा व्यवसाय डेटा सहजतेने सुरक्षित करा. आमच्या Pos Saas POS अमर्यादित अपग्रेडमध्ये विनामूल्य डेटा बॅकअप समाविष्ट आहे, आपली मौल्यवान माहिती कोणत्याही अनपेक्षित घटनांपासून संरक्षित आहे याची खात्री करून. खरोखर काय महत्त्वाचे आहे यावर लक्ष केंद्रित करा - तुमचा व्यवसाय वाढ."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("विक्री रक्कम"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("विक्री तपशील"),
        "salePrice": MessageLookupByLibrary.simpleMessage("विक्री किंमत"),
        "saleReports": MessageLookupByLibrary.simpleMessage("विक्री अहवाल"),
        "saleReportss": MessageLookupByLibrary.simpleMessage("विक्री अहवाल"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("विक्री परतावा"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("विक्री परतावा अहवाल"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("विक्री सेटिंग"),
        "sales": MessageLookupByLibrary.simpleMessage("विक्रय"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("Sale & Purchase Reports"),
        "salesList": MessageLookupByLibrary.simpleMessage("विक्री सूची"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("विक्री परतावा"),
        "save": MessageLookupByLibrary.simpleMessage("सेव्ह करा"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("जतन करा आणि प्रकाशित करा"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("बदल सेव्ह करा"),
        "saving": MessageLookupByLibrary.simpleMessage("जतन करीत आहे"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("उत्पादन QR कोड स्कॅन करा"),
        "search": MessageLookupByLibrary.simpleMessage("शोधा"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "उत्पादन कोड किंवा नावाद्वारे शोधा"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("सर्व प्रोमो कोड पहा"),
        "select": MessageLookupByLibrary.simpleMessage("निवडा"),
        "selectAProductForReturn":
            MessageLookupByLibrary.simpleMessage("परताव्यासाठी उत्पादन निवडा"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("ब्रँड निवडा"),
        "selectCategory": MessageLookupByLibrary.simpleMessage("श्रेणी निवडा"),
        "selectContacts": MessageLookupByLibrary.simpleMessage("संपर्क निवडा"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("उत्पादन श्रेणी निवडा"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("दुकान श्रेणी निवडा"),
        "selectTax": MessageLookupByLibrary.simpleMessage("कर निवडा"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("कर प्रकार निवडा"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("युनिट निवडा"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("पर्याय निवडा: "),
        "seller": MessageLookupByLibrary.simpleMessage("विक्रेता"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("विक्रीत"),
        "send": MessageLookupByLibrary.simpleMessage("पाठवा"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("ईमेल पाठवा"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("संदेश पाठवा"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("रीसेट लिंक पाठवा"),
        "sendSms": MessageLookupByLibrary.simpleMessage("एसएमएस पाठवा"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("SMS पाठवावे?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("व्हॉट्सअॅप संदेश पाठवा"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("तुमचा ईमेल पाठवा"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage("ईमेल पाठवत आहे"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("संदेश पाठवत आहे"),
        "serviceShipping": MessageLookupByLibrary.simpleMessage("सेवा/शिपिंग"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("तुमची प्रोफाइल सेट करा"),
        "setting": MessageLookupByLibrary.simpleMessage("सेटिंग्ज"),
        "share": MessageLookupByLibrary.simpleMessage("सामायिक करा"),
        "shopGST": MessageLookupByLibrary.simpleMessage("दुकान GST"),
        "signIn": MessageLookupByLibrary.simpleMessage("साइन इन करा"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("ईमेलसह साइन इन करा"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("ग्राहकाची सही"),
        "size": MessageLookupByLibrary.simpleMessage("आकार"),
        "skip": MessageLookupByLibrary.simpleMessage("वगळा"),
        "sms": MessageLookupByLibrary.simpleMessage("एसएमएस"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("सोशल मार्केटिंग"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "क्षमस्व, तुम्हाला या सेवेसाठी प्रवेशाची परवानगी नाही"),
        "startDate": MessageLookupByLibrary.simpleMessage("प्रारंभ तारीख"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("नवीन विक्रय सुरू करा"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage(
            "शोधण्याच्या सुरुवाती टाइप करा"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "कोणत्याही अतिरिक्त खर्चाशिवाय तांत्रिक प्रगतीमध्ये आघाडीवर रहा. आमचे Pos Saas POS अमर्यादित अपग्रेड तुमच्याकडे नेहमीच नवीनतम साधने आणि वैशिष्ट्ये तुमच्या बोटांच्या टोकावर असल्याची खात्री देते, तुमचा व्यवसाय अत्याधुनिक राहील याची हमी देते."),
        "stillUnpaid":
            MessageLookupByLibrary.simpleMessage("आणखी न भरण्यात आले"),
        "stock": MessageLookupByLibrary.simpleMessage("साठा"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("स्टॉक आवश्यक आहे"),
        "stockList": MessageLookupByLibrary.simpleMessage("स्टॉक सूची"),
        "stocks": MessageLookupByLibrary.simpleMessage("स्टॉक्स"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Excel फाइल तयार करण्यासाठी स्टोरेज परवानगी आवश्यक आहे"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("उपकर सूची"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("उपकर"),
        "subTotal": MessageLookupByLibrary.simpleMessage("उपकुल"),
        "submit": MessageLookupByLibrary.simpleMessage("सबमिट करा"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "आमच्या यूट्यूब चॅनेलला सदस्यता घ्या"),
        "subscription": MessageLookupByLibrary.simpleMessage("सब्सक्रिप्शन"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("यशस्वीरित्या झाले"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("यशस्वीरित्या लॉगआउट"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("यशस्वीरित्या अपडेटेड"),
        "supplier": MessageLookupByLibrary.simpleMessage("आपूर्तिकर्ता"),
        "supplierName": MessageLookupByLibrary.simpleMessage("आपले दुकान"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT कोड"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "एक ड्रायव्हर्स लायसन्स, राष्ट्रीय पहचानपत्र किंवा पासपोर्ट ची फोटो घ्या"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "तुमची माहिती तपासण्यासाठी एक ओळखपत्र घ्या"),
        "tap": MessageLookupByLibrary.simpleMessage("टॅप"),
        "tax": MessageLookupByLibrary.simpleMessage("कर"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("कर गट"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("कर टक्केवारी"),
        "taxRate": MessageLookupByLibrary.simpleMessage("कर दर"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "कर दर - तुमचे कर दर व्यवस्थापित करा"),
        "taxReport": MessageLookupByLibrary.simpleMessage("कर अहवाल"),
        "taxType": MessageLookupByLibrary.simpleMessage("कर प्रकार"),
        "taxes": MessageLookupByLibrary.simpleMessage("कर"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("अटी आणि शर्ती"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("वापराच्या अटी"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("अटी आणि गोपनीयता"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "आपल्या देयक भरल्याबद्दल धन्यवाद"),
        "thankYou": MessageLookupByLibrary.simpleMessage("धन्यवाद"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("आपल्या खरेदीसाठी धन्यवाद"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "त्या ईमेलसाठी खाते आधीच अस्तित्वात आहे"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Excel फाइल आधीच डाउनलोड झाली आहे"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "नाव हे सर्व सांगते. Pos Saas POS Unlimited सह, तुमच्या वापरावर कोणतीही मर्यादा नाही. तुम्ही मूठभर व्यवहारांवर प्रक्रिया करत असाल किंवा ग्राहकांची गर्दी अनुभवत असाल, तुमच्यावर मर्यादा येत नाहीत हे जाणून तुम्ही आत्मविश्वासाने काम करू शकता"),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "दिलेला पासवर्ड खूप कमजोर आहे"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "खरेदी मिटवली जाईल आणि याबद्दलचे सर्व डेटा मिटवले जाईल. आपण हे मिटवण्यास खात्री करता का?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "विक्री मिटवली जाईल आणि याबद्दलचे सर्व डेटा मिटवले जाईल. आपण हे मिटवण्यास खात्री करता का?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "वापरकर्ता हटवला जाईल आणि सर्व माहिती तुमच्या खात्यातून हटवली जाईल. तुम्ही खात्री आहे का की तुम्ही हे हटवू इच्छिता?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "वापरकर्ता हटवला जाईल आणि तुमच्या खात्यातील सर्व डेटा हटवला जाईल. तुम्हाला याची खात्री आहे का?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Third-Party Services"),
        "thisCategoryCannotBeDeleted":
            MessageLookupByLibrary.simpleMessage("हा श्रेणी हटवता येत नाही"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(या महिन्यात)"),
        "thisProductAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("हे उत्पादन आधीच जोडले आहे"),
        "title": MessageLookupByLibrary.simpleMessage("शीर्षक"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("शीर्षक रिकामे असू शकत नाही"),
        "to": MessageLookupByLibrary.simpleMessage("पर्यंत"),
        "toDate": MessageLookupByLibrary.simpleMessage("तारीखपर्यंत"),
        "today": MessageLookupByLibrary.simpleMessage("आज"),
        "total": MessageLookupByLibrary.simpleMessage("एकूण"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("एकूण रक्कम"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("एकूण जमा केलेले"),
        "totalDue": MessageLookupByLibrary.simpleMessage("एकूण देयक"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("एकूण खर्च"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("एकूण तोटा"),
        "totalPayable": MessageLookupByLibrary.simpleMessage("एकूण देयक"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("एकूण मूल्य"),
        "totalProducts": MessageLookupByLibrary.simpleMessage("एकूण उत्पादने"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("एकूण नफा"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("एकूण खरेदी"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("एकूण परतावा रक्कम"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("एकूण परताव्यां"),
        "totalSale": MessageLookupByLibrary.simpleMessage("एकूण विक्रय"),
        "totalStock": MessageLookupByLibrary.simpleMessage("एकूण स्टॉक्स"),
        "totalValue": MessageLookupByLibrary.simpleMessage("एकूण मूल्य"),
        "totalVat": MessageLookupByLibrary.simpleMessage("एकूण वॅट"),
        "totals": MessageLookupByLibrary.simpleMessage("एकूण: "),
        "transaction": MessageLookupByLibrary.simpleMessage("व्यवहार"),
        "transactionId": MessageLookupByLibrary.simpleMessage("व्यवहार आयडी"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("पुन्हा प्रयत्न करा"),
        "twitter": MessageLookupByLibrary.simpleMessage("ट्विटर"),
        "type": MessageLookupByLibrary.simpleMessage("प्रकार"),
        "unitName": MessageLookupByLibrary.simpleMessage("यूनिटचे नाव"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("एकक मूल्य"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("युनिट किंमत"),
        "units": MessageLookupByLibrary.simpleMessage("यूनिट्स"),
        "unlimited": MessageLookupByLibrary.simpleMessage("असीमित"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("अमर्यादित वापर"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "आमच्या तज्ञ टीमच्या नेतृत्वाखालील वैयक्तिक प्रशिक्षण सत्रांसह Pos Saas POS ची पूर्ण क्षमता अनलॉक करा. मूलभूत गोष्टींपासून ते प्रगत तंत्रांपर्यंत, आम्ही खात्री करतो की तुम्ही तुमच्या व्यवसाय प्रक्रियांना अनुकूल करण्यासाठी सिस्टमच्या प्रत्येक पैलूचा वापर करण्यात पारंगत आहात."),
        "unpaid": MessageLookupByLibrary.simpleMessage("बिल न भरलेला"),
        "update": MessageLookupByLibrary.simpleMessage("अद्यतनित करा"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("संपर्क अपडेट करा"),
        "updateNow": MessageLookupByLibrary.simpleMessage("आता अपडेट करा"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("उत्पादन अपडेट करा"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "तुमची योजना अद्ययावत करा, तुमची मर्यादा संपली आहे"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("तुमची प्रोफाइल अपडेट करा"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "तुमच्या डॉक्टरशी बेहतर परिप्रेक्ष्याने कनेक्ट कसे करावे यासाठी आपली प्रोफाइल अद्यतनित करा"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "आपल्या ग्राहकाशी बेहतर प्रतिष्ठाने कनेक्ट करण्यासाठी आपली प्रोफाइल अपडेट करा"),
        "updated": MessageLookupByLibrary.simpleMessage("अद्यतनित"),
        "upload": MessageLookupByLibrary.simpleMessage("अपलोड करा"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("दस्तऐवज अपलोड करा"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("अपलोड पूर्ण झाले"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("फाइल अपलोड करा"),
        "upplier": MessageLookupByLibrary.simpleMessage("आपूर्तिकर्ता"),
        "usbC": MessageLookupByLibrary.simpleMessage("यूएसबी सी"),
        "use": MessageLookupByLibrary.simpleMessage("वापरा"),
        "useMobiPos":
            MessageLookupByLibrary.simpleMessage("स्मार्ट बिजनेस वापरा"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Use of the system"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("वापरकर्ता हटवला गेला"),
        "userRole": MessageLookupByLibrary.simpleMessage("वापरकर्ता भूमिका"),
        "userRoleDetails": MessageLookupByLibrary.simpleMessage(
            "वापरकर्त्याच्या भूमिका तपशील"),
        "userTitle": MessageLookupByLibrary.simpleMessage("वापरकर्ता शीर्षक"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "वापरकर्ता शीर्षक रिक्त असू शकत नाही"),
        "value": MessageLookupByLibrary.simpleMessage("मूल्य"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("VAT लागू नाही"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("ओटीपी सत्यापन"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("फोन नंबर सत्यापित करा"),
        "viewAll": MessageLookupByLibrary.simpleMessage("सर्व पहा"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("तपशील पहा"),
        "walkInCustomer": MessageLookupByLibrary.simpleMessage("प्रवेश ग्राहक"),
        "warehouse": MessageLookupByLibrary.simpleMessage("गोदाम"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("गोदाम आधीच अस्तित्वात आहे"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("गोदाम सूची"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("गोदामाचे नाव"),
        "warranty": MessageLookupByLibrary.simpleMessage("वॉरंटी"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "आम्ही ईमेल पाठविले आहे, त्यात पासवर्ड रीसेट कसे करावे याबद्दल मार्गदर्शन आहे:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "We may use third-party services to support our app\'s functionality, such as analytics providers and payment processors. These third-party services may collect information about you when you use our app. Please note that we are not responsible for the privacy practices of these third-party services."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "We take industry-standard measures to protect your personal information, including encryption and secure storage. We also limit access to your information to authorized personnel only."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            " आम्ही अखंड ऑपरेशन्सचे महत्त्व समजतो. म्हणूनच आमचा चोवीस तास सपोर्ट तुम्हाला मदत करण्यासाठी उपलब्ध आहे, मग ती त्वरित क्वेरी असो किंवा सर्वसमावेशक चिंता असो. अतुलनीय ग्राहक सेवेचा अनुभव घेण्यासाठी कॉल किंवा WhatsApp द्वारे कधीही, कुठेही आमच्याशी कनेक्ट व्हा."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "We use your personal information to provide you with the best possible experience on our app, including to personalize your content recomme ndations, connect you with experts, and improve our apps functionality. We may also use your information to communicate with you about updates, promotions, or other information related to our app."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "आम्ही देयकाचे पुनरावलोकन करू आणि ते 1-2 तासांच्या आत मंजूर करू"),
        "weekly": MessageLookupByLibrary.simpleMessage("साप्ताहिक"),
        "weight": MessageLookupByLibrary.simpleMessage("वजन"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("काय नवं आहे"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("होलसेलर"),
        "wholeSalePrice": MessageLookupByLibrary.simpleMessage("होलसेल किंमत"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("थोक किंमत"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("थोक विक्रेता"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("लवकरच जोडले जाईल"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("कालबाह्य होईल"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("तुमचा संदेश येथे लिहा"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("चुकला OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "त्या वापरकर्त्यासाठी चुकीचा पासवर्ड प्रदान केला आहे."),
        "yearly": MessageLookupByLibrary.simpleMessage("वार्षिक"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("होय, कळवा काढा"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("आपण वैध वापरकर्ता नाही"),
        "youAreUsing":
            MessageLookupByLibrary.simpleMessage("तुम्ही वापरत आहात"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "तुम्ही देयापेक्षा अधिक पैसे देऊ शकत नाही"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("तुमचं ईमेल आलं आहे"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "तुम्ही सफलतेने आपल्या खात्यात लॉग इन केलं आहे. स्मार्ट बियाशरासह संवाद साधा."),
        "youHaveToGivePermission": MessageLookupByLibrary.simpleMessage(
            "तुम्हाला परवानगी द्यावी लागेल"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "तुम्हाला आपल्या खात्यात पुन्हा लॉग इन करायला आवश्यक आहे."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "तुमच्या खरेदीसाठी तुम्हाला तपशील सत्यापन करण्याची आवश्यकता आहे"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("तुमचा संदेश शेवटचा राहील"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("तुमचे पॅकेज"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "तुमच्या पॅकेजची किंमत 5 दिवसात संपली जाईल")
      };
}
