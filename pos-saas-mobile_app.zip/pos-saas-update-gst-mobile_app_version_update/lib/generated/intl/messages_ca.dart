// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a ca locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'ca';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Continuar"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("Número GST"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("Es requereix MRP"),
        "OK": MessageLookupByLibrary.simpleMessage("D\'acord"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Telèfon"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("Codi SWIFT"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Snacks"),
        "TAX": MessageLookupByLibrary.simpleMessage("IMPOST"),
        "Uploading": MessageLookupByLibrary.simpleMessage("S\'està pujant"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("Títol de l\'Usuari"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "El teu paquet caducarà avui\n\nSi us plau, compra de nou"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) El Sistema s\'ofereix exclusivament amb l\'objectiu de facilitar les transaccions de punt de venda i les activitats relacionades en el teu negoci."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) Per utilitzar el Sistema, pot ser que necessitis crear un compte. Acceptes proporcionar informació precisa, actual i completa durant el procés de registre i actualitzar aquesta informació per mantenir-la precisa i completa."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("Sobre l\'aplicació"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Sobre nosaltres"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Acceptació dels Termes"),
        "accountName": MessageLookupByLibrary.simpleMessage("Nom del compte"),
        "accountNumber":
            MessageLookupByLibrary.simpleMessage("Número de compte"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Registrament del Compte"),
        "acton": MessageLookupByLibrary.simpleMessage("Acció"),
        "add": MessageLookupByLibrary.simpleMessage("Afegir"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Afegir marca"),
        "addCategory": MessageLookupByLibrary.simpleMessage("Afegir categoria"),
        "addContact": MessageLookupByLibrary.simpleMessage("Afegir Contacte"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Afegir Client"),
        "addDelivery":
            MessageLookupByLibrary.simpleMessage("Afegir Lliurament"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Afegir descripció"),
        "addDescription": MessageLookupByLibrary.simpleMessage("Afegir Nota"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Afegir descompte"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Afegir ID de document"),
        "addDucument": MessageLookupByLibrary.simpleMessage("Afegir document"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Afegir Despesa"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Afegir Categoria de Despesa"),
        "addItems": MessageLookupByLibrary.simpleMessage("Afegir articles"),
        "addNew": MessageLookupByLibrary.simpleMessage("Afegir nou"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Afegir Nova Adreça"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Afegir producte"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("Afegir nou impost"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Afegir nou impost amb tipus d\'impost únic/múltiple"),
        "addNote": MessageLookupByLibrary.simpleMessage("Afegir Nota"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Afegiu primer el producte"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Afegir codi promocional"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Afegir compra"),
        "addSales": MessageLookupByLibrary.simpleMessage("Afegir vendes"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Afegit amb Èxit"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Afegir unitat"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Afegir Rol d\'Usuari"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Afegit correctament"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("Afegit a la cistella"),
        "address": MessageLookupByLibrary.simpleMessage("Adreça"),
        "admin": MessageLookupByLibrary.simpleMessage("Admin"),
        "all": MessageLookupByLibrary.simpleMessage("Tots"),
        "allBusinessSolution": MessageLookupByLibrary.simpleMessage(
            "Totes les solucions empresarials"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("Ja afegit"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Ja existeix"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Ja tens un Compte"),
        "amount": MessageLookupByLibrary.simpleMessage("Import"),
        "anEmailHasBeenSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "S\'ha enviat un correu electrònic\nComproveu la vostra safata d\'entrada"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Suport per Aplicacions Android i iOS"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Impost aplicable"),
        "apply": MessageLookupByLibrary.simpleMessage("Aplicar"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Esteu segur que voleu eliminar aquesta factura?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Esteu segur que voleu eliminar aquesta venda?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Estàs segur de voler eliminar aquest usuari?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Està segur que vol eliminar aquest impost?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Està segur que vol eliminar aquest grup d\'impostos?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Vol eliminar aquest magatzem?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Estàs segur de voler eliminar aquest usuari?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Signatura autoritzada"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Ets responsable de mantenir la confidencialitat del teu compte i contrasenya i de restringir l\'accés al teu compte. Acceptes la responsabilitat per totes les activitats que es duguin a terme sota el teu compte."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Has de tenir almenys 18 anys o l\'edat legal de majoria a la teva jurisdicció per utilitzar el Sistema."),
        "backSide": MessageLookupByLibrary.simpleMessage("Lateral posterior"),
        "backToHome":
            MessageLookupByLibrary.simpleMessage("Torna a la pàgina d\'inici"),
        "balance": MessageLookupByLibrary.simpleMessage("Balanç"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladesh"),
        "bank": MessageLookupByLibrary.simpleMessage("Banc"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Moneda del compte bancari"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Moneda del compte bancari"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Informació Bancària"),
        "bankName": MessageLookupByLibrary.simpleMessage("Nom del banc"),
        "bankTransfer":
            MessageLookupByLibrary.simpleMessage("Transferència bancària"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Codi de barra trobat"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Factura/Factura"),
        "billTo": MessageLookupByLibrary.simpleMessage("Facturar a"),
        "branchName": MessageLookupByLibrary.simpleMessage("Nom de l\'oficina"),
        "brand": MessageLookupByLibrary.simpleMessage("Marca"),
        "brandName": MessageLookupByLibrary.simpleMessage("Nom de la marca"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("Carrega en massa"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Categoria d\'Empresa"),
        "buy": MessageLookupByLibrary.simpleMessage("Comprar"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Compra el pla premium"),
        "buySms": MessageLookupByLibrary.simpleMessage("Comprar SMS"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "En accedir o utilitzar el sistema de punt de venda (POS) (el \"Sistema\") proporcionat per [Nom de la teva empresa] (\"Empresa\"), acceptes estar subjecte a aquests Termes d\'Ús. Si no acceptes aquests Termes d\'Ús, no utilitzis el Sistema."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Ets responsable d\'assegurar-te que el teu accés i ús del Sistema compleixi amb totes les lleis i regulacions aplicables."),
        "cacel": MessageLookupByLibrary.simpleMessage("Cancel·lar"),
        "call": MessageLookupByLibrary.simpleMessage("Trucar"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "Truqueu per a suport d\'emergència"),
        "camera": MessageLookupByLibrary.simpleMessage("Càmera"),
        "cancel": MessageLookupByLibrary.simpleMessage("Cancel·la"),
        "cancelAllProduct": MessageLookupByLibrary.simpleMessage(
            "Cancel·la tots els productes"),
        "capacity": MessageLookupByLibrary.simpleMessage("Capacitat"),
        "card": MessageLookupByLibrary.simpleMessage("Targeta"),
        "cash": MessageLookupByLibrary.simpleMessage("Efectiu"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Categories"),
        "category": MessageLookupByLibrary.simpleMessage("Categoria"),
        "categoryName":
            MessageLookupByLibrary.simpleMessage("Nom de la categoria"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "El nom de la categoria ja existeix"),
        "cateogryName":
            MessageLookupByLibrary.simpleMessage("Nom de la Categoria"),
        "change": MessageLookupByLibrary.simpleMessage("Canviar?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Canviar contrasenya"),
        "checkEmail": MessageLookupByLibrary.simpleMessage(
            "Comprova el correu electrònic"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Trieu un client"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Seleccioneu un proveïdor"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Trieu les vostres funcions"),
        "clarence": MessageLookupByLibrary.simpleMessage("Clarence"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Fes clic per connectar"),
        "close": MessageLookupByLibrary.simpleMessage("Tancar"),
        "color": MessageLookupByLibrary.simpleMessage("Color"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(Combinació de múltiples impostos)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Properament"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Adreça de l\'Empresa"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Nom de l\'Empresa i Botiga"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("Nom de l\'empresa i negoci"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Completa la transacció"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Confirma la Contrasenya"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Confirmeu el retorn"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Enhorabona"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Contacta\'ns"),
        "continu": MessageLookupByLibrary.simpleMessage("Continuar"),
        "country": MessageLookupByLibrary.simpleMessage("País"),
        "create": MessageLookupByLibrary.simpleMessage("Crear"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Crea un Compte Gratuït"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Creat i desat"),
        "currency": MessageLookupByLibrary.simpleMessage("Moneda"),
        "currentStock": MessageLookupByLibrary.simpleMessage("Estoc actual"),
        "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
            "Branding Personalitzat de Factures"),
        "customer": MessageLookupByLibrary.simpleMessage("Client"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Detalls del Client"),
        "customerGST": MessageLookupByLibrary.simpleMessage("GST del client"),
        "customerName": MessageLookupByLibrary.simpleMessage("Nom del Client"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Transacció diària"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Visió General del Tauler"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Dades desades correctament"),
        "date": MessageLookupByLibrary.simpleMessage("Data"),
        "day": MessageLookupByLibrary.simpleMessage("Dia"),
        "dealer": MessageLookupByLibrary.simpleMessage("Distribuïdor"),
        "dealerPrice":
            MessageLookupByLibrary.simpleMessage("Preu del distribuïdor"),
        "defaultVATPercentage": MessageLookupByLibrary.simpleMessage(
            "Percentatge de IVA per defecte"),
        "delete": MessageLookupByLibrary.simpleMessage("Eliminar"),
        "deleting": MessageLookupByLibrary.simpleMessage("Eliminant"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Adreça de Lliurament"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Adreces de lliurament"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Cost d\'enviament"),
        "describtion": MessageLookupByLibrary.simpleMessage("Descripció"),
        "description": MessageLookupByLibrary.simpleMessage("Descripció"),
        "descriptionCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "La descripció no pot estar buida"),
        "details": MessageLookupByLibrary.simpleMessage("Detalls"),
        "discount": MessageLookupByLibrary.simpleMessage("Descompte"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("No molestar"),
        "done": MessageLookupByLibrary.simpleMessage("Fet"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Descarregar format Excel"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Descarregat amb èxit a la carpeta de descàrregues"),
        "due": MessageLookupByLibrary.simpleMessage("Deute"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Import Degut: "),
        "dueCollection":
            MessageLookupByLibrary.simpleMessage("Recaptació de Deutes"),
        "dueCollectionReports": MessageLookupByLibrary.simpleMessage(
            "Informes de recaptació de deutes"),
        "dueList": MessageLookupByLibrary.simpleMessage("Llista de Deutes"),
        "dueReports": MessageLookupByLibrary.simpleMessage("Informe de deutes"),
        "duration": MessageLookupByLibrary.simpleMessage("Durada"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Durada: Des de"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "Fàcil d\'utilitzar mòbil POS"),
        "edit": MessageLookupByLibrary.simpleMessage("Editar"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Edita la factura de compra"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Edita la factura de venda"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Editar xarxes socials"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Editat amb èxit"),
        "editTax": MessageLookupByLibrary.simpleMessage("Editar impost"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Editar grup d\'impostos"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("Editar magatzem"),
        "email": MessageLookupByLibrary.simpleMessage("Correu electrònic"),
        "emailAddress":
            MessageLookupByLibrary.simpleMessage("Adreça de correu electrònic"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("L\'email no pot estar buit"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "Correu electrònic enviat! Comproveu la vostra safata d\'entrada"),
        "endDate": MessageLookupByLibrary.simpleMessage("Data de finalització"),
        "enterAValidAmount": MessageLookupByLibrary.simpleMessage(
            "Introdueix una quantitat vàlida"),
        "enterAValidDiscount": MessageLookupByLibrary.simpleMessage(
            "Introduïu un descompte vàlid"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Introdueix un número de telèfon vàlid"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Introduïu un preu vàlid"),
        "enterAValidQuantity": MessageLookupByLibrary.simpleMessage(
            "Introduïu una quantitat vàlida"),
        "enterAddress":
            MessageLookupByLibrary.simpleMessage("Introdueix l\'Adreça"),
        "enterAmount":
            MessageLookupByLibrary.simpleMessage("Introdueix l\'Import."),
        "enterBrandName": MessageLookupByLibrary.simpleMessage(
            "Introduïu el nom de la marca"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Introduïu la capacitat"),
        "enterCategoryName": MessageLookupByLibrary.simpleMessage(
            "Introduïu el nom de la categoria"),
        "enterColor":
            MessageLookupByLibrary.simpleMessage("Introduïu el color"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "Introdueix el número GST del client"),
        "enterDealerPrice": MessageLookupByLibrary.simpleMessage(
            "Introduïu el preu del distribuïdor"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Introduïu la descripció"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("Introduïu el descompte."),
        "enterExpenseDate": MessageLookupByLibrary.simpleMessage(
            "Introdueix la Data de Despesa"),
        "enterFullAddress": MessageLookupByLibrary.simpleMessage(
            "Introdueix l\'Adreça Completa"),
        "enterInvoiceNumber": MessageLookupByLibrary.simpleMessage(
            "Introduïu el número de factura"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Introduïu la quantitat d\'alerta de baix estoc"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Introduïu el fabricant"),
        "enterMessageContent": MessageLookupByLibrary.simpleMessage(
            "Introduïu el contingut del missatge"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "Introduïu el MRP/preu minorista"),
        "enterName": MessageLookupByLibrary.simpleMessage("Introdueix el Nom"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Introdueix la Nota"),
        "enterPartyName": MessageLookupByLibrary.simpleMessage(
            "Introdueix el Nom de la Part"),
        "enterPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Introdueix el Número de Telèfon"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Introduïu el codi del producte o escanegeu"),
        "enterProductName": MessageLookupByLibrary.simpleMessage(
            "Introduïu el nom del producte"),
        "enterPurchasePrice": MessageLookupByLibrary.simpleMessage(
            "Introduïu el preu de compra."),
        "enterReferenceNumber": MessageLookupByLibrary.simpleMessage(
            "Introdueix el Número de Referència"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Introduïu la mida"),
        "enterStocks":
            MessageLookupByLibrary.simpleMessage("Introduïu els stocks."),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Introduïu la taxa d\'impost"),
        "enterTransactionId": MessageLookupByLibrary.simpleMessage(
            "Introduïu l\'ID de transacció"),
        "enterType": MessageLookupByLibrary.simpleMessage("Introduïu el tipus"),
        "enterUserTitle": MessageLookupByLibrary.simpleMessage(
            "Introdueix el títol de l\'usuari"),
        "enterValidAmount": MessageLookupByLibrary.simpleMessage(
            "Introdueix una quantitat vàlida"),
        "enterWarehouseName": MessageLookupByLibrary.simpleMessage(
            "Introduïu el nom del magatzem"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Introduïu el pes"),
        "enterWholeSalePrice": MessageLookupByLibrary.simpleMessage(
            "Introduïu el preu de venda a l\'engròs"),
        "enterYourDescriptionHere": MessageLookupByLibrary.simpleMessage(
            "Introduïu la vostra descripció aquí"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "Introduïu la vostra adreça de correu electrònic"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "Introduïu el títol dels vostres comentaris"),
        "enterYourGSTNumber": MessageLookupByLibrary.simpleMessage(
            "Introdueix el teu número GST"),
        "enterYourMobileNumber": MessageLookupByLibrary.simpleMessage(
            "Introduïu el vostre número de mòbil"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Introdueix el Teu Nom"),
        "enterYourNumber": MessageLookupByLibrary.simpleMessage(
            "Introduïu el vostre número de telèfon"),
        "enterYourPassword": MessageLookupByLibrary.simpleMessage(
            "Introdueix la teva contrasenya"),
        "enterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Introdueix el Teu Número de Telèfon"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "Introduïu el vostre ID de transacció"),
        "error": MessageLookupByLibrary.simpleMessage("Error"),
        "excTax": MessageLookupByLibrary.simpleMessage("Impost exclòs"),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("Càrrega d\'Excel"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Excloent"),
        "expense": MessageLookupByLibrary.simpleMessage("Despeses"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Categoria de Despesa"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Data de Despesa"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Despesa per"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Informe de Despesa"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Data de caducitat"),
        "expired": MessageLookupByLibrary.simpleMessage("Caducat"),
        "expiring": MessageLookupByLibrary.simpleMessage("Caducant"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Fallat amb error"),
        "fashion": MessageLookupByLibrary.simpleMessage("Moda"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Les funcions són la part important que fa que POS SaaS sigui diferent de les solucions tradicionals."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Comentaris"),
        "firstName": MessageLookupByLibrary.simpleMessage("Nom"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Segueix-nos a\\nFacebook"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Segueix-nos a\\nTwitter"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Lateral frontal"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("Per a usos il·limitats"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Has oblidat la contrasenya"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Has oblidat la contrasenya?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Des de la Data"),
        "freeDataBackup": MessageLookupByLibrary.simpleMessage(
            "Còpia de Seguretat de Dades Gratuïta"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "Actualització Vitalícia Gratuïta"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Paquet gratuït"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Pla gratuït"),
        "from": MessageLookupByLibrary.simpleMessage("(Des de"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Totalment pagat"),
        "gallary": MessageLookupByLibrary.simpleMessage("Galeria"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("Generant PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Obtenir OTP"),
        "govermentId": MessageLookupByLibrary.simpleMessage("ID del govern"),
        "guest": MessageLookupByLibrary.simpleMessage("Convidat"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("No teniu cap compte?"),
        "history": MessageLookupByLibrary.simpleMessage("Història"),
        "home": MessageLookupByLibrary.simpleMessage("Inici"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Com Protegim la Teva Informació"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Com Fem Servir la Teva Informació"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Verificació d\'identitat"),
        "image": MessageLookupByLibrary.simpleMessage("Imatge"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("InHouse no pot ser eliminat"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("InHouse no pot ser editat"),
        "inWord": MessageLookupByLibrary.simpleMessage("En paraules"),
        "incTax": MessageLookupByLibrary.simpleMessage("Impost inclòs"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Inclusiu"),
        "increaseStock":
            MessageLookupByLibrary.simpleMessage("Augmentar estoc"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Instrument"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Núm. de factura"),
        "invoice": MessageLookupByLibrary.simpleMessage("Factura"),
        "invoiceNumber":
            MessageLookupByLibrary.simpleMessage("Número de factura"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Configuració de la factura"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Visor de factures"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Article afegit"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("Verificació KYC"),
        "language": MessageLookupByLibrary.simpleMessage("Llengua"),
        "lastName": MessageLookupByLibrary.simpleMessage("Cognom"),
        "ledger": MessageLookupByLibrary.simpleMessage("Llibre de comptes"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Compra Vitalícia"),
        "link": MessageLookupByLibrary.simpleMessage("Enllaç"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Suport de xat en viu"),
        "loading": MessageLookupByLibrary.simpleMessage("Carregant"),
        "logIn": MessageLookupByLibrary.simpleMessage("Iniciar Sessió"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Tancar sessió"),
        "logOut": MessageLookupByLibrary.simpleMessage("Tancar sessió"),
        "login": MessageLookupByLibrary.simpleMessage("Iniciar sessió"),
        "logo": MessageLookupByLibrary.simpleMessage("Logotip"),
        "loss": MessageLookupByLibrary.simpleMessage("Pèrdua"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Pèrdua/Benefici"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Detalls de Pèrdua/Benefici"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Informe de pèrdues/profit"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Informes de pèrdues/profit"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Alerta de baix estoc"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Fes una impressió duradora als teus clients amb factures personalitzades. La nostra actualització il·limitada ofereix l\'avantatge únic de personalitzar les teves factures, afegint un toc professional que reforça la teva identitat de marca i fomenta la fidelització dels clients."),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("Gestiona el teu negoci amb"),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Data de fabricació"),
        "margin": MessageLookupByLibrary.simpleMessage("Marge"),
        "masterCard": MessageLookupByLibrary.simpleMessage("Mastercard"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Fabricant"),
        "message": MessageLookupByLibrary.simpleMessage("Missatge"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Historial de missatges"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "L\'aplicació POS SaaS és gratuïta, fàcil d\'utilitzar. De fet, és un dels millors sistemes POS del món."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "POS SaaS és una solució empresarial completa amb estoc, comptes, vendes, despeses i pèrdues/beneficis."),
        "mobile": MessageLookupByLibrary.simpleMessage("Mòbil"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("Pagament mòbil"),
        "monthly": MessageLookupByLibrary.simpleMessage("Mensual"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("Més Informació"),
        "name": MessageLookupByLibrary.simpleMessage("Introdueix el Teu Nom."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("El nom ja existeix"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("El nom no pot estar buit"),
        "next": MessageLookupByLibrary.simpleMessage("Següent"),
        "noConnection": MessageLookupByLibrary.simpleMessage("Sense connexió"),
        "noData": MessageLookupByLibrary.simpleMessage("Sense dades"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("No hi ha dades disponibles"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("No s\'ha trobat cap dada"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("No s\'ha trobat historial!"),
        "noProductFound": MessageLookupByLibrary.simpleMessage(
            "No s\'ha trobat cap producte"),
        "noSubTaxSelected": MessageLookupByLibrary.simpleMessage(
            "No s\'ha seleccionat cap subimpost"),
        "noTransactionFound": MessageLookupByLibrary.simpleMessage(
            "No s\'ha trobat cap transacció!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "No s\'ha trobat cap usuari per aquesta adreça de correu electrònic."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "No s\'ha trobat cap Rol d\'Usuari"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Usuari no actiu"),
        "notProvided": MessageLookupByLibrary.simpleMessage("No proporcionat"),
        "note": MessageLookupByLibrary.simpleMessage("Nota"),
        "notes": MessageLookupByLibrary.simpleMessage("Notes"),
        "notification": MessageLookupByLibrary.simpleMessage("Notificació"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP enviat a"),
        "office": MessageLookupByLibrary.simpleMessage("Oficina"),
        "ok": MessageLookupByLibrary.simpleMessage("D\'acord"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS que conté una gran quantitat de funcionalitats, incloent el seguiment de vendes i la gestió d\'inventaris."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Aquest sistema t\'ajuda a millorar les teves operacions per als teus clients."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "El nostre sistema POS hauria de simplificar les operacions diàries automàticament, facilitant la navegació."),
        "openingBalance": MessageLookupByLibrary.simpleMessage("Saldo Inicial"),
        "order": MessageLookupByLibrary.simpleMessage("Comandes"),
        "other": MessageLookupByLibrary.simpleMessage("Altres"),
        "otp": MessageLookupByLibrary.simpleMessage("Tancar"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Sense estoc"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Paquet"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Funcions del paquet"),
        "paid": MessageLookupByLibrary.simpleMessage("Pagat"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Import Pagat"),
        "parties": MessageLookupByLibrary.simpleMessage("Partides"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Llista de Parts"),
        "partyGST": MessageLookupByLibrary.simpleMessage("GST de la part"),
        "partyName": MessageLookupByLibrary.simpleMessage("Nom de la Part"),
        "password": MessageLookupByLibrary.simpleMessage("Contrasenya"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "La contrasenya i la confirmació de la contrasenya no coincideixen"),
        "passwordCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "La contrasenya no pot estar buida"),
        "passwordNotMach": MessageLookupByLibrary.simpleMessage(
            "La contrasenya no coincideix"),
        "payCash": MessageLookupByLibrary.simpleMessage("Pagar en Efectiu"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash": MessageLookupByLibrary.simpleMessage("Paga amb bKash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Paga amb Paypal"),
        "payeeName":
            MessageLookupByLibrary.simpleMessage("Nom del beneficiari"),
        "payeeNumber":
            MessageLookupByLibrary.simpleMessage("Número del beneficiari"),
        "payment": MessageLookupByLibrary.simpleMessage("Pagament"),
        "paymentAmount":
            MessageLookupByLibrary.simpleMessage("Import del Pagament"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Pagament complet"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Instruccions de pagament:"),
        "paymentMethod":
            MessageLookupByLibrary.simpleMessage("Mètode de pagament"),
        "paymentType":
            MessageLookupByLibrary.simpleMessage("Tipus de Pagament"),
        "pdfView": MessageLookupByLibrary.simpleMessage("Visor PDF"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Informació personal"),
        "phone": MessageLookupByLibrary.simpleMessage("Telèfon"),
        "phoneNumber":
            MessageLookupByLibrary.simpleMessage("Número de Telèfon"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "El número de telèfon ja està en ús"),
        "phoneNumberIsNotValid": MessageLookupByLibrary.simpleMessage(
            "El número de telèfon no és vàlid"),
        "phoneNumberIsRequired": MessageLookupByLibrary.simpleMessage(
            "El número de telèfon és obligatori"),
        "pickAndUploadFile": MessageLookupByLibrary.simpleMessage(
            "Seleccionar i carregar fitxer"),
        "pickEndDate": MessageLookupByLibrary.simpleMessage(
            "Trieu la data de finalització"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Trieu la data d\'inici"),
        "plan": MessageLookupByLibrary.simpleMessage("Pla"),
        "pleaseAddQuantity": MessageLookupByLibrary.simpleMessage(
            "Si us plau, afegiu quantitat"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Si us plau, comproveu la vostra connectivitat a Internet"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Si us plau, connecta la impressora primer"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Si us plau, connecta la teva impressora Bluetooth"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Si us plau, introdueix una contrasenya més llarga"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Si us plau, Introdueix una Contrasenya de Confirmació"),
        "pleaseEnterAPassword": MessageLookupByLibrary.simpleMessage(
            "Si us plau, introduïu una contrasenya"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Si us plau, introdueix un email vàlid"),
        "pleaseEnterName": MessageLookupByLibrary.simpleMessage(
            "Si us plau, introdueix un nom"),
        "pleaseEnterPassword": MessageLookupByLibrary.simpleMessage(
            "Si us plau, introduïu la contrasenya"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Si us plau, introduïu la vostra adreça de correu electrònic a continuació per rebre l\'enllaç de restabliment de contrasenya."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Si us plau, introduïu el número de transacció"),
        "pleaseInterAmount": MessageLookupByLibrary.simpleMessage(
            "Si us plau, introdueix la quantitat"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Si us plau, selecciona primer una categoria"),
        "pleaseSelectAPlan": MessageLookupByLibrary.simpleMessage(
            "Si us plau, seleccioneu un pla"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Si us plau, selecciona una categoria de negoci"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Si us plau, utilitzeu el codi de compra vàlid per utilitzar l\'aplicació"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Desenvolupat per Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Desenvolupat per"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Suport Premium al Client"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Pla premium"),
        "previousPayAmounts": MessageLookupByLibrary.simpleMessage(
            "Quantitats pagades prèviament"),
        "price": MessageLookupByLibrary.simpleMessage("Preu"),
        "print": MessageLookupByLibrary.simpleMessage("Imprimir"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Opció d\'impressió"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Política de privacitat"),
        "product": MessageLookupByLibrary.simpleMessage("Producte"),
        "productCode":
            MessageLookupByLibrary.simpleMessage("Codi del producte"),
        "productCodeIsRequired": MessageLookupByLibrary.simpleMessage(
            "El codi del producte és obligatori"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Codi/nom del producte"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Descripció del producte"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Detalls del producte"),
        "productList":
            MessageLookupByLibrary.simpleMessage("Llista de productes"),
        "productName": MessageLookupByLibrary.simpleMessage("Nom del producte"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "El nom del producte ja existeix en aquest magatzem"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "El nom del producte ja s\'ha afegit"),
        "productNameIsRequired": MessageLookupByLibrary.simpleMessage(
            "El nom del producte és obligatori"),
        "products": MessageLookupByLibrary.simpleMessage("Productes"),
        "profile": MessageLookupByLibrary.simpleMessage("Perfil"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("Editar Perfil"),
        "profit": MessageLookupByLibrary.simpleMessage("Benefici"),
        "promo": MessageLookupByLibrary.simpleMessage("promo"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Codi promocional"),
        "purchase": MessageLookupByLibrary.simpleMessage("Compra"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("Alarma de compra"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Compra confirmada"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Detalls de compra"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Factura d\'adquisició"),
        "purchaseList":
            MessageLookupByLibrary.simpleMessage("Llista de compres"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Comprar ara"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Compra el pla premium"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("Preu de compra"),
        "purchasePriceIsRequired": MessageLookupByLibrary.simpleMessage(
            "El preu de compra és obligatori"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("Informe de compra"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Preu de compra"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Informes de compres"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("Retorn d\'adquisició"),
        "purchaseReturnReport": MessageLookupByLibrary.simpleMessage(
            "Informe de retorn d\'adquisicions"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Transició d\'adquisició"),
        "qty": MessageLookupByLibrary.simpleMessage("Quantitat"),
        "quantity": MessageLookupByLibrary.simpleMessage("Quantitat"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Transaccions Recents"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("He rebut el PIN"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Número de Referència"),
        "register": MessageLookupByLibrary.simpleMessage("Registrar-se"),
        "registering": MessageLookupByLibrary.simpleMessage("Registrant-se"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("Deute Restant"),
        "remove": MessageLookupByLibrary.simpleMessage("Eliminar"),
        "reports": MessageLookupByLibrary.simpleMessage("Informes"),
        "requestHasBeenSend": MessageLookupByLibrary.simpleMessage(
            "La sol·licitud ha estat enviada"),
        "resendCode": MessageLookupByLibrary.simpleMessage("Reenviar codi"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("Reenviar OTP:"),
        "retailer": MessageLookupByLibrary.simpleMessage("Minorista"),
        "retur": MessageLookupByLibrary.simpleMessage("Retorn"),
        "returN": MessageLookupByLibrary.simpleMessage("Retorn"),
        "returnAMount":
            MessageLookupByLibrary.simpleMessage("Quantitat de retorn"),
        "returnAmount":
            MessageLookupByLibrary.simpleMessage("Quantitat de retorn"),
        "returnQTY":
            MessageLookupByLibrary.simpleMessage("Quantitat de retorn"),
        "revenue": MessageLookupByLibrary.simpleMessage("Ingressos"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Protegeix les dades del teu negoci sense esforç. La nostra actualització il·limitada de Pos Saas POS inclou còpia de seguretat de dades gratuïta, assegurant que la teva informació valuosa estigui protegida contra qualsevol esdeveniment imprevist. Centra\'t en el que realment importa: el creixement del teu negoci."),
        "saleAmount":
            MessageLookupByLibrary.simpleMessage("Import de la venda"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("Detalls de venda"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Preu de venda"),
        "saleReports": MessageLookupByLibrary.simpleMessage("Informe de venda"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Informes de vendes"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("Retorn de venda"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Informe de retorn de vendes"),
        "saleSetting":
            MessageLookupByLibrary.simpleMessage("Configuració de vendes"),
        "sales": MessageLookupByLibrary.simpleMessage("Vendes"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("Informes de Vendes i Compra"),
        "salesList": MessageLookupByLibrary.simpleMessage("Llista de vendes"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("Retorn de vendes"),
        "save": MessageLookupByLibrary.simpleMessage("Desa"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Desa i publica"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("Desa els canvis"),
        "saving": MessageLookupByLibrary.simpleMessage("Desant"),
        "scanProductQRCode": MessageLookupByLibrary.simpleMessage(
            "Escaneja el codi QR del producte"),
        "search": MessageLookupByLibrary.simpleMessage("Cerca"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Cerca per codi o nom del producte"),
        "seeAllPromoCode": MessageLookupByLibrary.simpleMessage(
            "Veure tots els codis promocionals"),
        "select": MessageLookupByLibrary.simpleMessage("Seleccionar"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Seleccioneu un producte per retornar"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Selecciona marca"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Selecciona una categoria"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Selecciona contactes"),
        "selectProductCategory": MessageLookupByLibrary.simpleMessage(
            "Selecciona la categoria de productes"),
        "selectShopCategory": MessageLookupByLibrary.simpleMessage(
            "Selecciona la categoria de botiga"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Selecciona impost"),
        "selectTaxType": MessageLookupByLibrary.simpleMessage(
            "Selecciona el tipus d\'impost"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("Selecciona unitat"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Seleccioneu variació: "),
        "seller": MessageLookupByLibrary.simpleMessage("Venedor"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Venut per"),
        "send": MessageLookupByLibrary.simpleMessage("Enviar"),
        "sendEmail":
            MessageLookupByLibrary.simpleMessage("Enviar correu electrònic"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Enviar missatge"),
        "sendResetLink": MessageLookupByLibrary.simpleMessage(
            "Enviar enllaç de restabliment"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Enviar SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Enviar SMS?"),
        "sendWhatsappMessage": MessageLookupByLibrary.simpleMessage(
            "Envia un missatge per Whatsapp"),
        "sendYOurEmail": MessageLookupByLibrary.simpleMessage(
            "Envia el teu correu electrònic"),
        "sendingEmail":
            MessageLookupByLibrary.simpleMessage("Enviant correu electrònic"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Enviant missatge"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Servei/enviament"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Configura el teu perfil"),
        "setting": MessageLookupByLibrary.simpleMessage("Configuració"),
        "share": MessageLookupByLibrary.simpleMessage("Compartir"),
        "shopGST": MessageLookupByLibrary.simpleMessage("GST de la botiga"),
        "signIn": MessageLookupByLibrary.simpleMessage("Iniciar sessió"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("Iniciar sessió amb email"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Signatura del client"),
        "size": MessageLookupByLibrary.simpleMessage("Mida"),
        "skip": MessageLookupByLibrary.simpleMessage("Saltar"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Màrqueting social"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Ho sentim, no tens permís per accedir a aquest servei"),
        "startDate": MessageLookupByLibrary.simpleMessage("Data d\'inici"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Iniciar nova venda"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage(
            "Comenceu a escriure per cercar"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Mantingueu-vos a l\'avantguarda dels avenços tecnològics sense costos addicionals. La nostra actualització il·limitada de Pos Saas POS garanteix que sempre tingueu les últimes eines i funcions a la vostra disposició, garantint que el vostre negoci es mantingui al dia."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("Encara no pagat"),
        "stock": MessageLookupByLibrary.simpleMessage("Estoc"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("El stock és obligatori"),
        "stockList": MessageLookupByLibrary.simpleMessage("Llista d\'estoc"),
        "stocks": MessageLookupByLibrary.simpleMessage("Stocks"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Es requereix permís d\'emmagatzematge per crear el fitxer Excel"),
        "subTaxList":
            MessageLookupByLibrary.simpleMessage("Llista de subimpostos"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Subimpostos"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Subtotal"),
        "submit": MessageLookupByLibrary.simpleMessage("Enviar"),
        "subscribeToOurYoutube":
            MessageLookupByLibrary.simpleMessage("Subscriu-te a\\nYoutube"),
        "subscription": MessageLookupByLibrary.simpleMessage("Subscripció"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Realitzat amb èxit"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Sessió tancada amb èxit"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Actualitzat amb èxit"),
        "supplier": MessageLookupByLibrary.simpleMessage("Proveïdor"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("Nom del proveïdor"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("Codi SWIFT"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Fes una foto del carnet de conduir, el document d\'identitat nacional o el passaport"),
        "takeaNidCardToCheckYourInformation": MessageLookupByLibrary.simpleMessage(
            "Fes una foto del document d\'identitat per verificar la teva informació"),
        "tap": MessageLookupByLibrary.simpleMessage("Tocar"),
        "tax": MessageLookupByLibrary.simpleMessage("Impost"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Grup d\'impostos"),
        "taxPercentage":
            MessageLookupByLibrary.simpleMessage("Percentatge d\'impost"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Taxa d\'impost"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Taxa d\'impostos - Gestioneu les vostres taxes"),
        "taxReport":
            MessageLookupByLibrary.simpleMessage("Informe d\'impostos"),
        "taxType": MessageLookupByLibrary.simpleMessage("Tipus d\'impost"),
        "taxes": MessageLookupByLibrary.simpleMessage("Impostos"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Termes i condicions"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("Termes d\'ús"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Termes i privacitat"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Gràcies per la teva Pagament Degut"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Gràcies"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Gràcies per la seva compra"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "L\'account ja existeix per aquest correu electrònic"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "El fitxer Excel ja s\'ha descarregat"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "El nom ho diu tot. Amb Pos Saas POS Il·limitat, no hi ha límits en el teu ús. Tant si estàs processant un grapat de transaccions com si experimentes un allau de clients, pots operar amb confiança, sabent que no estàs restringit per límits."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "La contrasenya proporcionada és massa feble"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "La venda s\'eliminarà i s\'eliminaran totes les dades sobre aquesta compra. Esteu segur que voleu eliminar això?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "La venda s\'eliminarà i s\'eliminaran totes les dades sobre aquesta venda. Esteu segur que voleu eliminar això?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "L\'usuari serà eliminat i totes les dades seran eliminades del teu compte. Estàs segur de voler eliminar això?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "L\'usuari s\'eliminarà i totes les dades s\'eliminaran del teu compte. Estàs segur de voler eliminar-ho?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Serveis de Tercers"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Aquesta categoria no pot ser eliminada"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Aquest mes)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Aquest producte ja s\'ha afegit"),
        "title": MessageLookupByLibrary.simpleMessage("Títol"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("El títol no pot estar buit"),
        "to": MessageLookupByLibrary.simpleMessage("a"),
        "toDate": MessageLookupByLibrary.simpleMessage("Fins a la Data"),
        "today": MessageLookupByLibrary.simpleMessage("Avui"),
        "total": MessageLookupByLibrary.simpleMessage("Total"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Import Total"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Total recollit"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Total Degut"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("Despesa Total"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Pèrdua total"),
        "totalPayable": MessageLookupByLibrary.simpleMessage("Total a pagar"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Preu total"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("Total de productes"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Benefici total"),
        "totalPurchase":
            MessageLookupByLibrary.simpleMessage("Total d\'adquisicions"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Quantitat total de retorns"),
        "totalReturns":
            MessageLookupByLibrary.simpleMessage("Total de retorns"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Total de vendes"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Estoc total"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Valor total"),
        "totalVat": MessageLookupByLibrary.simpleMessage("IVA total"),
        "totals": MessageLookupByLibrary.simpleMessage("Total: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Transacció"),
        "transactionId":
            MessageLookupByLibrary.simpleMessage("ID de transacció"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Intenta-ho de nou"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Tipus"),
        "unitName": MessageLookupByLibrary.simpleMessage("Nom de la unitat"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Preu unitari"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Preu unitari"),
        "units": MessageLookupByLibrary.simpleMessage("Unitats"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Il·limitat"),
        "unlimitedUsage": MessageLookupByLibrary.simpleMessage("Ús Il·limitat"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Desbloqueja el ple potencial de Pos Saas POS amb sessions de formació personalitzades dirigides pel nostre equip d\'experts. Des dels conceptes bàsics fins a tècniques avançades, ens assegurem que estiguis ben format en l\'ús de cada aspecte del sistema per optimitzar els teus processos empresarials."),
        "unpaid": MessageLookupByLibrary.simpleMessage("No pagat"),
        "update": MessageLookupByLibrary.simpleMessage("Actualitzar"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Actualitzar Contacte"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Actualitza ara"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("Actualitzar producte"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Actualitza el teu pla primer,\\nla teva limitació ha acabat"),
        "updateYourProfile": MessageLookupByLibrary.simpleMessage(
            "Actualitzeu el vostre perfil"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Actualitza el teu perfil per connectar-te amb el teu metge amb millor impressió"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Actualitzeu el vostre perfil per connectar millor amb els vostres clients"),
        "updated": MessageLookupByLibrary.simpleMessage("Actualitzat"),
        "upload": MessageLookupByLibrary.simpleMessage("Carregar"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Puja el document"),
        "uploadDone":
            MessageLookupByLibrary.simpleMessage("Càrrega realitzada"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Puja el fitxer"),
        "upplier": MessageLookupByLibrary.simpleMessage("Proveïdor"),
        "usbC": MessageLookupByLibrary.simpleMessage("Usb C"),
        "use": MessageLookupByLibrary.simpleMessage("Utilitzar"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("Utilitza POS SaaS"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Ús del sistema"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("L\'usuari ha estat eliminat"),
        "userRole": MessageLookupByLibrary.simpleMessage("Rol de l\'Usuari"),
        "userRoleDetails": MessageLookupByLibrary.simpleMessage(
            "Detalls del rol de l\'usuari"),
        "userTitle": MessageLookupByLibrary.simpleMessage("Títol de l\'Usuari"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "El títol de l\'usuari no pot estar buit"),
        "value": MessageLookupByLibrary.simpleMessage("Valor"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("L\'IVA no s\'aplica"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("Verificant OTP"),
        "verifyPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Verifica el número de telèfon"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Veure Tots"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("Veure detalls"),
        "walkInCustomer": MessageLookupByLibrary.simpleMessage("Client a peu"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Magatzem"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("El magatzem ja existeix"),
        "warehouseList":
            MessageLookupByLibrary.simpleMessage("Llista de magatzems"),
        "warehouseName":
            MessageLookupByLibrary.simpleMessage("Nom del magatzem"),
        "warranty": MessageLookupByLibrary.simpleMessage("Garantia"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Hem enviat un correu electrònic amb instruccions sobre com restablir la contrasenya a:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Podem utilitzar serveis de tercers per donar suport a la funcionalitat de la nostra aplicació, com ara proveïdors d\'analítica i processadors de pagament. Tingues en compte que no som responsables de les pràctiques de privadesa d\'aquests serveis de tercers."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Prenem mesures estàndard de la indústria per protegir la teva informació personal, incloent xifrat i emmagatzematge segur. També limitem l\'accés a la teva informació només al personal autoritzat."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Entenem la importància d\'una operació fluïda. Per això, el nostre suport les 24 hores està disponible per ajudar-te, ja sigui amb una consulta ràpida o una preocupació més profunda. Connecta amb nosaltres en qualsevol moment i lloc a través de trucades o WhatsApp per experimentar un servei al client inigualable."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Fem servir la teva informació personal per oferir-te la millor experiència possible a la nostra aplicació, incloent la personalització de les teves recomanacions de contingut, la connexió amb experts i la millora de la funcionalitat de les nostres aplicacions. També podem utilitzar la teva informació per comunicar-nos amb tu sobre actualitzacions, promocions o altres informacions relacionades amb la nostra aplicació."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Revisarem el pagament i l\'aprovarà dins de 1-2 hores"),
        "weekly": MessageLookupByLibrary.simpleMessage("Setmanal"),
        "weight": MessageLookupByLibrary.simpleMessage("Pes"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Què Hi Ha de Nou"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Majorista"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Preu de venda a l\'engròs"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("Preu al major"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Majorista"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("S\'afegirà aviat"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Caducarà a"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Escriu el teu missatge aquí"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("OTP incorrecte"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Contrasenya incorrecta proporcionada per a aquest usuari."),
        "yearly": MessageLookupByLibrary.simpleMessage("Anual"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Sí, Elimina per Sempre"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("No sou un usuari vàlid"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Esteu utilitzant"),
        "youCanNotPayMoreThenDue":
            MessageLookupByLibrary.simpleMessage("No pots pagar més del deute"),
        "youHaveGotAnEmail": MessageLookupByLibrary.simpleMessage(
            "Has rebut un correu electrònic"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Has iniciat sessió amb èxit al teu compte. Roman amb Pos Saas."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("Heu de donar permís"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Has de tornar a iniciar sessió al teu compte."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Heu de verificar la vostra identitat abans de comprar SMS"),
        "yourMessageRemains": MessageLookupByLibrary.simpleMessage(
            "Els vostres missatges restants"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("El teu paquet"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "El teu paquet caducarà en 5 dies")
      };
}
