// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a et locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'et';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Jätka"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("GST number"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("MRP on kohustuslik"),
        "OK": MessageLookupByLibrary.simpleMessage("OK"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Ph.no"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT kood"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Snäkid"),
        "TAX": MessageLookupByLibrary.simpleMessage("Maks"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Laadimine"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("Kasutaja pealkiri"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Teie pakett aegub täna\n\nPalun osta uuesti"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) Süsteem on pakutud ainult\nmüügi- ja ostutehingute\nlihtsustamiseks ja sellega\nseotud tegevuste\nteostamiseks teie\näri raames."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) Süsteemi kasutamiseks peate võib-olla\nlooma konto. Te nõustute andma\ntäpset, ajakohast ja\ntäielikku teavet registreerimisprotsessi\najal ning värskendama\nseda teavet, et hoida see\ntäpsena ja täielikuna."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("Rakendusest"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Meist"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Tingimuste aktsepteerimine"),
        "accountName": MessageLookupByLibrary.simpleMessage("Konto nimi"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("Konto number"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Konto registreerimine"),
        "acton": MessageLookupByLibrary.simpleMessage("Tegevus"),
        "add": MessageLookupByLibrary.simpleMessage("Lisa"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Lisa bränd"),
        "addCategory": MessageLookupByLibrary.simpleMessage("Lisa kategooria"),
        "addContact": MessageLookupByLibrary.simpleMessage("Lisa kontakt"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Lisa klient"),
        "addDelivery":
            MessageLookupByLibrary.simpleMessage("Lisa kohaletoimetamine"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Lisa kirjeldus"),
        "addDescription": MessageLookupByLibrary.simpleMessage("Lisa märkus"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Lisa allahindlus"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Lisa dokumendi ID"),
        "addDucument": MessageLookupByLibrary.simpleMessage("Lisa dokument"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Lisa kulu"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Lisa kulu kategooria"),
        "addItems": MessageLookupByLibrary.simpleMessage("Lisa esemed"),
        "addNew": MessageLookupByLibrary.simpleMessage("Lisa uus"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Lisa uus aadress"),
        "addNewProduct": MessageLookupByLibrary.simpleMessage("Lisa toode"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("Lisa uus maks"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Lisa uus maks ühe/multiple maksutüübi jaoks"),
        "addNote": MessageLookupByLibrary.simpleMessage("Lisa märkus"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Lisage kõigepealt toode"),
        "addPromoCode": MessageLookupByLibrary.simpleMessage("Lisa sooduskood"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Lisa ost"),
        "addSales": MessageLookupByLibrary.simpleMessage("Lisa müük"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Lisamine õnnestus"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Lisa üksus"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Lisa kasutaja roll"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Lisatud edukalt"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("Lisatud ostukorvi"),
        "address": MessageLookupByLibrary.simpleMessage("Aadress"),
        "admin": MessageLookupByLibrary.simpleMessage("Admin"),
        "all": MessageLookupByLibrary.simpleMessage("Kõik"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("Kõik äri lahendused"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("Juba lisatud"),
        "alreadyExists":
            MessageLookupByLibrary.simpleMessage("Juba eksisteerib"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Konto on juba olemas"),
        "amount": MessageLookupByLibrary.simpleMessage("Summa"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "E-post on saadetud\\nKontrollige oma postkasti"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Android ja iOS rakenduse tugi"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Kohaldatav maks"),
        "apply": MessageLookupByLibrary.simpleMessage("Rakenda"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Kas olete kindel, et soovite selle arve kustutada?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Kas olete kindel, et soovite selle müügi kustutada?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Kas olete kindel, et soovite selle kasutaja kustutada?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Kas olete kindel, et soovite selle maksu kustutada"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Kas olete kindel, et soovite selle maksugrupi kustutada"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Kas soovite selle lao kustutada"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Kas olete kindel, et soovite selle kasutaja kustutada?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Volitatud allkiri"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Te olete vastutav oma\nkonto ja parooli konfidentsiaalsuse\nsäilitamise eest ning\njuurdepääsu piiramise eest\noma kontole. Te aktsepteerite\nvastutust kõikide tegevuste\nkohta, mis toimuvad teie\nkonto all."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Te peate olema vähemalt 18 aastat vana või teie jurisdiktsioonis kehtiva seadusliku täisea saavutamiseks, et kasutada süsteemi."),
        "backSide": MessageLookupByLibrary.simpleMessage("Tagumine külg"),
        "backToHome": MessageLookupByLibrary.simpleMessage("Tagasi avalehele"),
        "balance": MessageLookupByLibrary.simpleMessage("Saldo"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladesh"),
        "bank": MessageLookupByLibrary.simpleMessage("Pank"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Panga konto valuuta"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Panga konto valuuta"),
        "bankInformation": MessageLookupByLibrary.simpleMessage("Panga teave"),
        "bankName": MessageLookupByLibrary.simpleMessage("Panga nimi"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("Pangamakse"),
        "barcodeFound": MessageLookupByLibrary.simpleMessage("Barkood leitud"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Arve"),
        "billTo": MessageLookupByLibrary.simpleMessage("Arve"),
        "branchName": MessageLookupByLibrary.simpleMessage("Filiaali nimi"),
        "brand": MessageLookupByLibrary.simpleMessage("Bränd"),
        "brandName": MessageLookupByLibrary.simpleMessage("Brändi nimi"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("Hulgilaadimine"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Ärikategooria"),
        "buy": MessageLookupByLibrary.simpleMessage("Osta"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Osta Premium plaan"),
        "buySms": MessageLookupByLibrary.simpleMessage("Osta SMS"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Kasutades ja juurdepääsedes [Teie Ettevõtte Nimi] (\"Ettevõte\") pakutavale müügikoha (POS) süsteemile (\"Süsteem\"), nõustute olema seotud nende kasutustingimustega. Kui te ei nõustu nende kasutustingimustega, ärge kasutage süsteemi."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Te olete vastutav selle eest, et teie\njuurdepääs ja süsteemi kasutamine\noleks kooskõlas kõigi kehtivate\nseaduste ja regulatsioonidega."),
        "cacel": MessageLookupByLibrary.simpleMessage("Tühista"),
        "call": MessageLookupByLibrary.simpleMessage("Helista"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "Helistage hädaabitoe saamiseks"),
        "camera": MessageLookupByLibrary.simpleMessage("Kaamera"),
        "cancel": MessageLookupByLibrary.simpleMessage("Tühista"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Tühista kõik tooted"),
        "capacity": MessageLookupByLibrary.simpleMessage("Mahutavus"),
        "card": MessageLookupByLibrary.simpleMessage("Kaart"),
        "cash": MessageLookupByLibrary.simpleMessage("Sularaha"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Kategooriad"),
        "category": MessageLookupByLibrary.simpleMessage("Kategooria"),
        "categoryName": MessageLookupByLibrary.simpleMessage("Kategooria nimi"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "Kategooria nimi juba eksisteerib"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("Kategooria nimi"),
        "change": MessageLookupByLibrary.simpleMessage("Muuda?"),
        "changePassword": MessageLookupByLibrary.simpleMessage("Muuda parooli"),
        "checkEmail":
            MessageLookupByLibrary.simpleMessage("Kontrollige e-kirja"),
        "choseACustomer": MessageLookupByLibrary.simpleMessage("Vali klient"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Valige tarnija"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Valige oma omadused"),
        "clarence": MessageLookupByLibrary.simpleMessage("Selgitus"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Klõpsake, et ühendada"),
        "close": MessageLookupByLibrary.simpleMessage("Sulge"),
        "color": MessageLookupByLibrary.simpleMessage("Värv"),
        "combinationOfMultipleTaxes":
            MessageLookupByLibrary.simpleMessage("(Mitme maksu kombinatsioon)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Peagi tulekul"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Ettevõtte aadress"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Ettevõtte ja poe nimi"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("Ettevõtte ja äri nimi"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Täida tehing"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Kinnitage parool"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Kinnitage tagastus"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Palju õnne"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Kontaktige meid"),
        "continu": MessageLookupByLibrary.simpleMessage("Jätka"),
        "country": MessageLookupByLibrary.simpleMessage("Riik"),
        "create": MessageLookupByLibrary.simpleMessage("Loo"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Loo tasuta konto"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Loodud ja salvestatud"),
        "currency": MessageLookupByLibrary.simpleMessage("Valuuta"),
        "currentStock":
            MessageLookupByLibrary.simpleMessage("Praegune laoseis"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("Kohandatud arve bränding"),
        "customer": MessageLookupByLibrary.simpleMessage("Klient"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Kliendi andmed"),
        "customerGST": MessageLookupByLibrary.simpleMessage("Kliendi GST"),
        "customerName": MessageLookupByLibrary.simpleMessage("Kliendi nimi"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Igapäevane tehing"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Armatuurlaud"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Andmed salvestati edukalt"),
        "date": MessageLookupByLibrary.simpleMessage("Kuupäev"),
        "day": MessageLookupByLibrary.simpleMessage("Päev"),
        "dealer": MessageLookupByLibrary.simpleMessage("Edasimüüja"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("Kauplejahind"),
        "defaultVATPercentage": MessageLookupByLibrary.simpleMessage(
            "Vaikimisi käibemaksu protsent"),
        "delete": MessageLookupByLibrary.simpleMessage("Kustuta"),
        "deleting": MessageLookupByLibrary.simpleMessage("Kustutamine"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Kohaletoimetamise aadress"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Kohaletoimetamise aadressid"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Kohaletoimetamise tasu"),
        "describtion": MessageLookupByLibrary.simpleMessage("Kirjeldus"),
        "description": MessageLookupByLibrary.simpleMessage("Kirjeldus"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Kirjeldus ei saa olla tühi"),
        "details": MessageLookupByLibrary.simpleMessage("Üksikasjad"),
        "discount": MessageLookupByLibrary.simpleMessage("Soodustus"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Ära häiri"),
        "done": MessageLookupByLibrary.simpleMessage("Valmis"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Laadi alla Exceli vorming"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Allalaadimine õnnestus allalaadimiste kausta"),
        "due": MessageLookupByLibrary.simpleMessage("Maksmine"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Maksmise summa: "),
        "dueCollection":
            MessageLookupByLibrary.simpleMessage("Maksmise kogumine"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("Sissenõudmise aruanded"),
        "dueList": MessageLookupByLibrary.simpleMessage("Maksmise nimekiri"),
        "dueReports": MessageLookupByLibrary.simpleMessage("Maksmise raport"),
        "duration": MessageLookupByLibrary.simpleMessage("Kestus"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Kestus: Alates"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "Lihtne kasutada mobiilset POS-i"),
        "edit": MessageLookupByLibrary.simpleMessage("Muuda"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Muuda ostu arvet"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Muuda müügi arvet"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Muuda sotsiaalmeediat"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Edukas muutmine"),
        "editTax": MessageLookupByLibrary.simpleMessage("Muuda maksu"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Muuda maksugruppi"),
        "editWarehouse": MessageLookupByLibrary.simpleMessage("Muuda laod"),
        "email": MessageLookupByLibrary.simpleMessage("E-post"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("E-posti aadress"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("E-post ei tohi olla tühi"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "E-kiri saadetud! Kontrollige oma postkasti"),
        "endDate": MessageLookupByLibrary.simpleMessage("Lõppkuupäev"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Sisestage kehtiv summa"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Sisestage kehtiv soodustus"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Sisestage kehtiv telefoninumber"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Sisestage kehtiv hind"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("Sisestage kehtiv kogus"),
        "enterAddress":
            MessageLookupByLibrary.simpleMessage("Sisestage aadress"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("Sisestage summa."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Sisestage brändi nimi"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Sisestage mahutavus"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Sisestage kategooria nimi"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Sisestage värv"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "Sisestage kliendi GST number"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Sisestage kauplejahind"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Sisestage kirjeldus"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("Sisestage soodustus."),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Sisestage kulu kuupäev"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Sisestage täielik aadress"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Sisesta arve number"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Sisestage madala laoseisu teate kogus"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Sisestage tootja"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("Sisesta sõnumi sisu"),
        "enterMrpOrRetailerPirce":
            MessageLookupByLibrary.simpleMessage("Sisestage MRP/jaemüügihind"),
        "enterName": MessageLookupByLibrary.simpleMessage("Sisestage nimi"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Sisestage märkus"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Sisestage osalise nimi"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Sisestage telefoninumber"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Sisestage tootekood või skanneerige"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Sisestage toote nimi"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Sisestage ostuhind."),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("Sisestage viitenumber"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Sisestage suurus"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("Sisestage laod."),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Sisestage maksumäär"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("Sisestage tehingu ID"),
        "enterType": MessageLookupByLibrary.simpleMessage("Sisestage tüüp"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("Sisestage kasutaja pealkiri"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Sisestage kehtiv summa"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Sisestage lao nimi"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Sisestage kaal"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Sisestage hulgihind"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("Sisesta oma kirjeldus siia"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "Sisestage oma e-posti aadress"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "Sisesta oma tagasiside pealkiri"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Sisestage oma GST number"),
        "enterYourMobileNumber": MessageLookupByLibrary.simpleMessage(
            "Sisesta oma mobiiltelefoni number"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Sisestage oma nimi"),
        "enterYourNumber": MessageLookupByLibrary.simpleMessage(
            "Sisestage oma telefoninumber"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Sisestage oma parool"),
        "enterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Sisestage oma telefoninumber"),
        "enterYourTransactionId":
            MessageLookupByLibrary.simpleMessage("Sisesta oma tehingu ID"),
        "error": MessageLookupByLibrary.simpleMessage("Viga"),
        "excTax": MessageLookupByLibrary.simpleMessage("Väl. maks"),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("Exceli üleslaadija"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Välistav"),
        "expense": MessageLookupByLibrary.simpleMessage("Kulud"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Kulu kategooria"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Kulu kuupäev"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Kulu jaoks"),
        "expenseReport": MessageLookupByLibrary.simpleMessage("Kulu aruanne"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Aegumiskuupäev"),
        "expired": MessageLookupByLibrary.simpleMessage("Aegunud"),
        "expiring": MessageLookupByLibrary.simpleMessage("Aegumas"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Ebaõnnestus veaga"),
        "fashion": MessageLookupByLibrary.simpleMessage("Moe"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Omadused on oluline osa, mis muudab POS SaaS-i erinevaks traditsioonilistest lahendustest."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Tagasiside"),
        "firstName": MessageLookupByLibrary.simpleMessage("Eesnimi"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Jälgi meid Facebookis"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Jälgi meid Twitteris"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Eesmine külg"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("Piiramatu kasutamise jaoks"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Unustasite parooli"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Unustasite parooli?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Alates kuupäevast"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("Tasuta andmete varundamine"),
        "freeLifeTimeUpdate":
            MessageLookupByLibrary.simpleMessage("Tasuta eluaegne värskendus"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Tasuta pakett"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Tasuta plaan"),
        "from": MessageLookupByLibrary.simpleMessage("(Alates"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Täielikult tasutud"),
        "gallary": MessageLookupByLibrary.simpleMessage("Galerii"),
        "generatingPDF":
            MessageLookupByLibrary.simpleMessage("PDF-i genereerimine"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Hangi OTP"),
        "govermentId": MessageLookupByLibrary.simpleMessage("Valitsuse ID"),
        "guest": MessageLookupByLibrary.simpleMessage("Külastaja"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Pole veel kontot?"),
        "history": MessageLookupByLibrary.simpleMessage("Ajalugu"),
        "home": MessageLookupByLibrary.simpleMessage("Avaleht"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Kuidas me kaitseme teie teavet"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Kuidas me teie teavet kasutame"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Isiku kinnitamine"),
        "image": MessageLookupByLibrary.simpleMessage("Pilt"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("Majas ei saa kustutada"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("Majas ei saa muuta"),
        "inWord": MessageLookupByLibrary.simpleMessage("Sõnades"),
        "incTax": MessageLookupByLibrary.simpleMessage("Sis. maks"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Hõlmav"),
        "increaseStock":
            MessageLookupByLibrary.simpleMessage("Suurenda laoseisu"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Instrument"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Arve nr."),
        "invoice": MessageLookupByLibrary.simpleMessage("Arve"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("Arve number"),
        "invoiceSetting": MessageLookupByLibrary.simpleMessage("Arve seaded"),
        "invoiceViewer": MessageLookupByLibrary.simpleMessage("Arvevaataja"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Ese lisatud"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("KYC kinnitamine"),
        "language": MessageLookupByLibrary.simpleMessage("Keel"),
        "lastName": MessageLookupByLibrary.simpleMessage("Perekonnanimi"),
        "ledger": MessageLookupByLibrary.simpleMessage("Raamatupidamine"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Eluaegne\nOst"),
        "link": MessageLookupByLibrary.simpleMessage("Link"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Reaalajas vestluse tugi"),
        "loading": MessageLookupByLibrary.simpleMessage("Laadimine"),
        "logIn": MessageLookupByLibrary.simpleMessage("Logi sisse"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Logi välja"),
        "logOut": MessageLookupByLibrary.simpleMessage("Logi välja"),
        "login": MessageLookupByLibrary.simpleMessage("Logi sisse"),
        "logo": MessageLookupByLibrary.simpleMessage("Logo"),
        "loss": MessageLookupByLibrary.simpleMessage("Kahjum"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Kahjum/Tulu"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Kahjumi/Tulu üksikasjad"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Kahjumi/saagi aruanne"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Kahjumi/saagi aruanded"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Madala laoseisu teade"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Jätke oma klientidele püsiv mulje bränditud arvetega. Meie Piiramatu Uuendamine pakub ainulaadset eelist oma arvete kohandamiseks, lisades professionaalse puudutuse, mis tugevdab teie brändi identiteeti ja edendab kliendi lojaalsust."),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("Halda oma äri koos"),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Tootmiskuupäev"),
        "margin": MessageLookupByLibrary.simpleMessage("Marginaal"),
        "masterCard": MessageLookupByLibrary.simpleMessage("MasterCard"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Tootja"),
        "message": MessageLookupByLibrary.simpleMessage("Sõnum"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Sõnumite ajalugu"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "POS SaaS rakendus on tasuta, lihtne kasutada. Tegelikult on see üks parimaid POS-süsteeme maailmas."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "POS SaaS on täielik äriolukorra lahendus koos laoseisu, konto, müügi, kulu ja kasumi/kahjumi haldamisega."),
        "mobile": MessageLookupByLibrary.simpleMessage("Mobiil"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("Mobiilimakse"),
        "monthly": MessageLookupByLibrary.simpleMessage("Kuu"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("Rohkem teavet"),
        "name": MessageLookupByLibrary.simpleMessage("Sisestage oma nimi."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Nimi juba eksisteerib"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("Nimi ei tohi olla tühi"),
        "next": MessageLookupByLibrary.simpleMessage("Järgmine"),
        "noConnection": MessageLookupByLibrary.simpleMessage("Ei ühendust"),
        "noData": MessageLookupByLibrary.simpleMessage("Andmeid ei ole"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Andmed pole saadaval"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Andmeid ei leitud"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("Ajaloost ei leitud midagi!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Toodet ei leitud"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("Alamaksu ei ole valitud"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("Tehingut ei leitud!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Selle e-posti aadressi jaoks ei leitud kasutajat."),
        "noUserRoleFound":
            MessageLookupByLibrary.simpleMessage("Kasutaja rolli ei leitud"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Mitteaktiivne kasutaja"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Ei ole esitatud"),
        "note": MessageLookupByLibrary.simpleMessage("Märkus"),
        "notes": MessageLookupByLibrary.simpleMessage("Märkused"),
        "notification": MessageLookupByLibrary.simpleMessage("Teade"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP saadetud"),
        "office": MessageLookupByLibrary.simpleMessage("Kantselei"),
        "ok": MessageLookupByLibrary.simpleMessage("Ok"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS, mis sisaldab palju funktsioone, sealhulgas müügijälgimist, laohaldust."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "See süsteem aitab teil oma tegevust parandada teie klientide jaoks."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Meie POS-süsteem peaks automatiseerima igapäevaseid toiminguid, muutes navigeerimise lihtsaks."),
        "openingBalance": MessageLookupByLibrary.simpleMessage("Avabalanse "),
        "order": MessageLookupByLibrary.simpleMessage("Tellimused"),
        "other": MessageLookupByLibrary.simpleMessage("Muu"),
        "otp": MessageLookupByLibrary.simpleMessage("Sulge"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Laos pole"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Pakett"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Paketi omadused"),
        "paid": MessageLookupByLibrary.simpleMessage("Makstud"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Tasutud summa"),
        "parties": MessageLookupByLibrary.simpleMessage("Osalised"),
        "partiesList":
            MessageLookupByLibrary.simpleMessage("Osaliste nimekiri"),
        "partyGST": MessageLookupByLibrary.simpleMessage("Osaluse GST"),
        "partyName": MessageLookupByLibrary.simpleMessage("Osalise nimi"),
        "password": MessageLookupByLibrary.simpleMessage("Parool"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Parool ja parooli kinnitamine ei ühti"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Parool ei tohi olla tühi"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("Parool ei ühti"),
        "payCash": MessageLookupByLibrary.simpleMessage("Makse sularahas"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash": MessageLookupByLibrary.simpleMessage("Makse bkashiga"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Makse Paypaliga"),
        "payeeName": MessageLookupByLibrary.simpleMessage("Saaja nimi"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("Saaja number"),
        "payment": MessageLookupByLibrary.simpleMessage("Makse"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("Makse summa"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Makse lõpetatud"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Maksejuhised:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("Maksemeetod"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Makse liik"),
        "pdfView": MessageLookupByLibrary.simpleMessage("PDF vaade"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Isiklikud andmed"),
        "phone": MessageLookupByLibrary.simpleMessage("Telefon"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Telefoninumber"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Telefoninumber on juba kasutatud"),
        "phoneNumberIsNotValid": MessageLookupByLibrary.simpleMessage(
            "Telefoninumber ei ole kehtiv"),
        "phoneNumberIsRequired": MessageLookupByLibrary.simpleMessage(
            "Telefoninumber on kohustuslik"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("Valige ja laadige fail üles"),
        "pickEndDate": MessageLookupByLibrary.simpleMessage("Vali lõppkuupäev"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Vali alguskuupäev"),
        "plan": MessageLookupByLibrary.simpleMessage("Plaani"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("Palun lisage kogus"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Palun kontrollige oma internetiühendust"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Palun ühendage printer kõigepealt"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Palun ühendage oma Bluetooth-printer"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Palun sisestage pikem parool"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Palun sisestage kinnitatud parool"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("Palun sisestage parool"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Palun sisestage kehtiv e-post"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Palun sisestage nimi"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("Palun sisestage parool"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Palun sisestage allolev e-posti aadress, et saada parooli lähtestamise link."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Palun sisestage tehingu number"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("Palun sisestage summa"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Palun valige kõigepealt kategooria"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("Palun valige plaan"),
        "pleaseSelectBusinessCategory":
            MessageLookupByLibrary.simpleMessage("Palun valige ärikategooria"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Palun kasutage rakenduse kasutamiseks kehtivat ostukoodi"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Toetab Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Välja antud"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Premium klienditugi"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Premium plaan"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Eelnevad maksete summad"),
        "price": MessageLookupByLibrary.simpleMessage("Hind"),
        "print": MessageLookupByLibrary.simpleMessage("Prindi"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Prindivõimalus"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Privaatsuspoliitika"),
        "product": MessageLookupByLibrary.simpleMessage("Toode"),
        "productCode": MessageLookupByLibrary.simpleMessage("Tootekood"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("Toote kood on kohustuslik"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Toote kood/nimi"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Toote kirjeldus"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Toote detailid"),
        "productList": MessageLookupByLibrary.simpleMessage("Toodete loetelu"),
        "productName": MessageLookupByLibrary.simpleMessage("Toote nimi"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Toote nimi eksisteerib juba selles laos"),
        "productNameIsAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("Tootenimi on juba lisatud"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("Toote nimi on kohustuslik"),
        "products": MessageLookupByLibrary.simpleMessage("Tooted"),
        "profile": MessageLookupByLibrary.simpleMessage("Profiil"),
        "profileEdit":
            MessageLookupByLibrary.simpleMessage("Profiili redigeerimine"),
        "profit": MessageLookupByLibrary.simpleMessage("Tulu"),
        "promo": MessageLookupByLibrary.simpleMessage("Promo"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Kampaania kood"),
        "purchase": MessageLookupByLibrary.simpleMessage("Osta"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage("Ostu häire"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Ost kinnitatud"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Ostu detailid"),
        "purchaseInvoice": MessageLookupByLibrary.simpleMessage("Ostu arve"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("Ostu nimekiri"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Osta kohe"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Osta Premium plaan"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("Ostuhind"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("Ostuhind on kohustuslik"),
        "purchaseRepoet": MessageLookupByLibrary.simpleMessage("Ostu raport"),
        "purchaseReports": MessageLookupByLibrary.simpleMessage("Ostu hind"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Ostuaruanded"),
        "purchaseReturn": MessageLookupByLibrary.simpleMessage("Ostu tagastus"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("Ostu tagastuse aruanne"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Ostutehing"),
        "qty": MessageLookupByLibrary.simpleMessage("Kogus"),
        "quantity": MessageLookupByLibrary.simpleMessage("Kogus"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Viimased tehingud"),
        "recivedThePin": MessageLookupByLibrary.simpleMessage("Saadud PIN"),
        "referenceNumber": MessageLookupByLibrary.simpleMessage("Viitenumber"),
        "register": MessageLookupByLibrary.simpleMessage("Registreeri"),
        "registering": MessageLookupByLibrary.simpleMessage("Registreerimine"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("Jäänud maksmine"),
        "remove": MessageLookupByLibrary.simpleMessage("Eemalda"),
        "reports": MessageLookupByLibrary.simpleMessage("Aruanded"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Taotlus on saadetud"),
        "resendCode": MessageLookupByLibrary.simpleMessage("Saada kood uuesti"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("Saada OTP uuesti:"),
        "retailer": MessageLookupByLibrary.simpleMessage("Jaemüüja"),
        "retur": MessageLookupByLibrary.simpleMessage("Tagasta"),
        "returN": MessageLookupByLibrary.simpleMessage("Tagastus"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("Tagasta summa"),
        "returnAmount":
            MessageLookupByLibrary.simpleMessage("Tagasimakse summa"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("Tagastus kogus"),
        "revenue": MessageLookupByLibrary.simpleMessage("Tulu"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Kaitske oma ettevõtte andmeid vaevata. Meie POS Saas POS Piiramatu Uuendamine sisaldab tasuta andmete varundamist, tagades, et teie väärtuslik teave on kaitstud ettenägematute sündmuste eest. Keskenduge sellele, mis tõeliselt oluline - teie äri kasv."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Müügi summa"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("Müügi detailid"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Müügihind"),
        "saleReports": MessageLookupByLibrary.simpleMessage("Müügi raport"),
        "saleReportss": MessageLookupByLibrary.simpleMessage("Müügiraportid"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("Müügi tagastus"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Müügi tagastuse aruanne"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("Müügi seadistus"),
        "sales": MessageLookupByLibrary.simpleMessage("Müük"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("Müügi- ja ostuaruanded"),
        "salesList": MessageLookupByLibrary.simpleMessage("Müügi nimekiri"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("Müügitagastus"),
        "save": MessageLookupByLibrary.simpleMessage("Salvesta"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Salvesta ja avalda"),
        "saveChanges":
            MessageLookupByLibrary.simpleMessage("Salvesta muudatused"),
        "saving": MessageLookupByLibrary.simpleMessage("Salvestamine"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("Skaneeri toote QR-kood"),
        "search": MessageLookupByLibrary.simpleMessage("Otsi"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Otsige toote koodi või nime järgi"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("Vaata kõiki kampaania koode"),
        "select": MessageLookupByLibrary.simpleMessage("Vali"),
        "selectAProductForReturn":
            MessageLookupByLibrary.simpleMessage("Valige tagastamiseks toode"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Valige bränd"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Valige kategooria"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Vali kontaktid"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("Valige tootekategooria"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("Valige poekategooria"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Valige maks"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Valige maksu tüüp"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("Valige ühik"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Vali variatsioon:"),
        "seller": MessageLookupByLibrary.simpleMessage("Müüja"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Müüja"),
        "send": MessageLookupByLibrary.simpleMessage("Saada"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("Saada e-kiri"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Saada sõnum"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("Saada lähtestamise link"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Saada SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Saada sms?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Saada WhatsAppi sõnum"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Saada oma e-post"),
        "sendingEmail":
            MessageLookupByLibrary.simpleMessage("E-kirja saatmine"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Sõnumi saatmine"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Teenuse/transport"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Seadista oma profiil"),
        "setting": MessageLookupByLibrary.simpleMessage("Seaded"),
        "share": MessageLookupByLibrary.simpleMessage("Jaga"),
        "shopGST": MessageLookupByLibrary.simpleMessage("Poese GST"),
        "signIn": MessageLookupByLibrary.simpleMessage("Logi sisse"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("Logi sisse e-posti kaudu"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Kliendi allkiri"),
        "size": MessageLookupByLibrary.simpleMessage("Suurus"),
        "skip": MessageLookupByLibrary.simpleMessage("Jätka"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Sotsiaalne turundus"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Kahjuks ei ole teil õigust sellele teenusele ligi pääseda"),
        "startDate": MessageLookupByLibrary.simpleMessage("Alguskuupäev"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Alusta uut müüki"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage(
            "Alustage otsimiseks kirjutamist"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Püsige tehnoloogia arengus esirinnas ilma lisakuludeta. Meie POS Saas POS Piiramatu Uuendamine tagab, et teil on alati uusimad tööriistad ja funktsioonid käeulatuses, garantii, et teie ettevõte jääb esirinda."),
        "stillUnpaid":
            MessageLookupByLibrary.simpleMessage("Jätkuvalt tasumata"),
        "stock": MessageLookupByLibrary.simpleMessage("Laoseis"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Laoseis on kohustuslik"),
        "stockList": MessageLookupByLibrary.simpleMessage("Laovaru nimekiri"),
        "stocks": MessageLookupByLibrary.simpleMessage("Laod"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Salvestusluba on vajalik Exceli faili loomiseks"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("Alamaksu loetelu"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Alamaksud"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Vahekokku"),
        "submit": MessageLookupByLibrary.simpleMessage("Esita"),
        "subscribeToOurYoutube":
            MessageLookupByLibrary.simpleMessage("Telli meie YouTube\'i kanal"),
        "subscription": MessageLookupByLibrary.simpleMessage("Tellimus"),
        "successfullyDone": MessageLookupByLibrary.simpleMessage("Edukas"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Edukas välja logimine"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Edukas uuendus"),
        "supplier": MessageLookupByLibrary.simpleMessage("Tarnija"),
        "supplierName": MessageLookupByLibrary.simpleMessage("Tarnija nimi"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT kood"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Võtke juhiluba, rahvuslik identiteetkaart või pass"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "Võtke identiteetkaart oma teabe kontrollimiseks"),
        "tap": MessageLookupByLibrary.simpleMessage("Koputage"),
        "tax": MessageLookupByLibrary.simpleMessage("Maks"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Maksugrupp"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("Maksuprotsent"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Maksumäär"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Maksumäärad - Halda oma maksumäärasid"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Maksu aruanne"),
        "taxType": MessageLookupByLibrary.simpleMessage("Maksu tüüp"),
        "taxes": MessageLookupByLibrary.simpleMessage("Maksud"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Tingimused ja tingimused"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("Kasutustingimused"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Tingimused ja Privaatsus"),
        "thankYOuForYourDuePayment":
            MessageLookupByLibrary.simpleMessage("Aitäh teie makse eest"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Aitäh"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Aitäh Teie ostu eest"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "See konto eksisteerib juba selle e-posti jaoks"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Exceli fail on juba allalaaditud"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Nimi ütleb kõik. POS Saas POS Piiramatu puhul ei ole teie kasutamisel mingeid piire. Olgu teie tehingud väikesed või tunnete oma kliente massiliselt, saate kindlalt tegutseda, teades, et te ei ole piiratud."),
        "thePasswordProvidedIsTooWeak":
            MessageLookupByLibrary.simpleMessage("Antud parool on liiga nõrk"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Müük kustutatakse ja kõik selle ostuga seotud andmed kustutatakse. Kas olete kindel, et soovite selle kustutada?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Müük kustutatakse ja kõik selle müügiga seotud andmed kustutatakse. Kas olete kindel, et soovite selle kustutada?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Kasutaja kustutatakse ja kõik andmed kustutatakse teie kontolt. Kas olete kindel, et soovite selle kustutada?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Kasutaja kustutatakse ja kõik andmed kustutatakse teie kontolt. Kas olete kindel, et soovite selle kustutada?"),
        "thirdPartyServices": MessageLookupByLibrary.simpleMessage(
            "Kolmandate osapoolte teenused"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Seda kategooriat ei saa kustutada"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Sellel kuul)"),
        "thisProductAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("See toode on juba lisatud"),
        "title": MessageLookupByLibrary.simpleMessage("Pealkiri"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Pealkiri ei saa olla tühi"),
        "to": MessageLookupByLibrary.simpleMessage("kuni"),
        "toDate": MessageLookupByLibrary.simpleMessage("Kuni kuupäevani"),
        "today": MessageLookupByLibrary.simpleMessage("Täna"),
        "total": MessageLookupByLibrary.simpleMessage("Kokku"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Kokku summa"),
        "totalCollected": MessageLookupByLibrary.simpleMessage("Kokku kogutud"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Kokku maksmine"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("Kokku kulu"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Kokku kaotus"),
        "totalPayable": MessageLookupByLibrary.simpleMessage("Kokku maksta"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Kokkuhind"),
        "totalProducts": MessageLookupByLibrary.simpleMessage("Kokku tooteid"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Kokku kasum"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("Kokku ost"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Kokku tagastatav summa"),
        "totalReturns":
            MessageLookupByLibrary.simpleMessage("Kokku tagastused"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Kokku müük"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Kogusumma laoseis"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Koguväärtus"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Käibemaks kokku"),
        "totals": MessageLookupByLibrary.simpleMessage("Kokku: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Tehing"),
        "transactionId": MessageLookupByLibrary.simpleMessage("Tehingu ID"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Proovige uuesti"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Tüüp"),
        "unitName": MessageLookupByLibrary.simpleMessage("Üksuse nimi"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Ühikuhind"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Ühik hind"),
        "units": MessageLookupByLibrary.simpleMessage("Ühik"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Piiramatu"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Piiramatu kasutamine"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Avage POS Saas POS täielik potentsiaal isiklike koolituste abil, mida juhib meie ekspertmeeskond. Alustest kuni edasiste tehnikateni, tagame, et olete hästi kursis iga süsteemi aspekti kasutamisega oma äritegevuse protsesside optimeerimiseks."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Makse tegemata"),
        "update": MessageLookupByLibrary.simpleMessage("Uuenda"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Uuenda kontakti"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Uuenda nüüd"),
        "updateProduct": MessageLookupByLibrary.simpleMessage("Uuenda toodet"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Uuendage oma plaani,\\nkuna teie limiit on ületatud"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Uuenda oma profiili"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Uuenda oma profiili, et luua arstiga parem mulje"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Uuenda oma profiili, et luua oma klientidega paremat sidet"),
        "updated": MessageLookupByLibrary.simpleMessage("Uuendatud"),
        "upload": MessageLookupByLibrary.simpleMessage("Laadi üles"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Laadi üles dokument"),
        "uploadDone":
            MessageLookupByLibrary.simpleMessage("Üleslaadimine lõpetatud"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Laadi üles fail"),
        "upplier": MessageLookupByLibrary.simpleMessage("Tarnija"),
        "usbC": MessageLookupByLibrary.simpleMessage("USB C"),
        "use": MessageLookupByLibrary.simpleMessage("Kasutage"),
        "useMobiPos":
            MessageLookupByLibrary.simpleMessage("Kasutage POS SaaS-i"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Süsteemi kasutamine"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Kasutaja on kustutatud"),
        "userRole": MessageLookupByLibrary.simpleMessage("Kasutaja roll"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("Kasutaja rolli üksikasjad"),
        "userTitle": MessageLookupByLibrary.simpleMessage("Kasutaja pealkiri"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Kasutaja pealkiri ei tohi olla tühi"),
        "value": MessageLookupByLibrary.simpleMessage("Väärtus"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("Käibemaks ei kehti"),
        "verifyOtp":
            MessageLookupByLibrary.simpleMessage("Verifitseerimine OTP"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Kinnita telefoninumber"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Vaata kõiki"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("Vaata detaile"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Sisenenud klient"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Ladu"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Ladu juba eksisteerib"),
        "warehouseList":
            MessageLookupByLibrary.simpleMessage("Laoliste loetelu"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("Lao nimi"),
        "warranty": MessageLookupByLibrary.simpleMessage("Garantii"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Oleme saatnud e-kirja, milles on juhised parooli lähtestamiseks aadressile:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Võime kasutada kolmandate osapoolte teenuseid, et toetada meie rakenduse funktsionaalsust, nagu analüütika teenusepakkujad ja maksetöötlejad. Need kolmandate osapoolte teenused võivad koguda teie kohta teavet, kui kasutate meie rakendust. Palun pange tähele, et me ei vastuta nende kolmandate osapoolte teenuste privaatsustavade eest."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Kaitseme teie isikuandmeid tööstuse standarditele vastavate meetmetega, sealhulgas krüpteerimise ja turvalise salvestamisega. Samuti piirame teie teabe juurdepääsu ainult volitatud töötajatele."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Mõistame sujuvate toimingute tähtsust. Seetõttu on meie ööpäevaringne tugi alati saadaval, et aidata teid, olgu see siis kiire küsimus või ulatuslik mure. Ühenduge meiega igal ajal, igal pool telefoni või WhatsAppi kaudu, et kogeda ületamatut klienditeenindust."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Kasutame teie isikuandmeid, et pakkuda teile parimat võimalikku kogemust meie rakenduses, sealhulgas sisu soovituste kohandamiseks, ekspertidega ühenduse loomiseks ja meie rakenduse funktsionaalsuse parandamiseks. Samuti võime kasutada teie teavet, et suhelda teiega värskenduste, kampaaniate või muu teabe osas, mis on seotud meie rakendusega."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Me vaatame makse läbi ja kinnitame selle 1-2 tunni jooksul"),
        "weekly": MessageLookupByLibrary.simpleMessage("Iganädalane"),
        "weight": MessageLookupByLibrary.simpleMessage("Kaal"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Mis on uut"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Hulgimüüja"),
        "wholeSalePrice": MessageLookupByLibrary.simpleMessage("Hulgihind"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("Hulgihind"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Hulgimüüja"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Lisatakse peagi"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Aegub"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Kirjuta oma sõnum siia"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("Vale OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Vale parool on antud selle kasutaja jaoks."),
        "yearly": MessageLookupByLibrary.simpleMessage("Aastane"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Jah, kustuta igaveseks"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("Te ei ole kehtiv kasutaja"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Te kasutate"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Te ei saa maksta rohkem, kui on vajalik"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Olete saanud e-kirja"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Olete oma kontole edukalt sisse loginud. Jätkake Pos Saasiga."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("Te peate andma loa"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Te peate oma kontole uuesti sisse logima."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Enne SMS-ide ostmist peate oma isikut kinnitama"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Teie sõnum jääb"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Teie pakett"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Teie pakett aegub 5 päeva pärast")
      };
}
