// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a as locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'as';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("অগ্ৰসৰ"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("GST নম্বৰ"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("এমআৰপি"),
        "MRPIsRequired": MessageLookupByLibrary.simpleMessage("MRP আৱশ্যক"),
        "OK": MessageLookupByLibrary.simpleMessage("ঠিক আছে"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("প\'জ এছএএছ"),
        "Paypal": MessageLookupByLibrary.simpleMessage("পেপাল"),
        "PhNo": MessageLookupByLibrary.simpleMessage("ফোন নম্বৰ"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT কোড"),
        "Snacks": MessageLookupByLibrary.simpleMessage("স্নেকস"),
        "TAX": MessageLookupByLibrary.simpleMessage("কৰ"),
        "Uploading": MessageLookupByLibrary.simpleMessage("আপলোড হৈ আছে"),
        "UserTitle":
            MessageLookupByLibrary.simpleMessage("ব্যৱহাৰকাৰী শিৰোনাম"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "আপোনাৰ পেকেজ আজিৰে পৰা মুকলি হব\n\nকৃপয়া পুনৰ ক্ৰয় কৰক"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(ক) ছিষ্টেমটো কেৱল আপোনাৰ ব্যৱসায়ত পইণ্ট অৱ সেল লেনদেন আৰু সম্পর্কিত কাৰ্যকলাপ সহজ কৰাৰ উদ্দেশ্যে প্ৰদান কৰা হৈছে।"),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(ক) ছিষ্টেমটো ব্যৱহাৰ কৰিবলৈ আপুনি একাউণ্ট সৃষ্টি কৰাৰ বাবে বাধ্য হ\'ব পাৰে। আপুনি পঞ্জীয়নৰ সময়ছোৱাত সঠিক, বৰ্তমান, আৰু সম্পূৰ্ণ তথ্য প্ৰদান কৰিবলৈ একমত হয় আৰু সেই তথ্যটোক সঠিক আৰু সম্পূৰ্ণ ৰাখিবলৈ আপডেট কৰিব।"),
        "aboutApp": MessageLookupByLibrary.simpleMessage("এপৰ বিষয়ে"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("আমাৰ বিষয়ে"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("চুক্তিৰ গ্ৰহণযোগ্যতা"),
        "accountName": MessageLookupByLibrary.simpleMessage("অ্যাকাউণ্টৰ নাম"),
        "accountNumber":
            MessageLookupByLibrary.simpleMessage("অ্যাকাউণ্ট নম্বৰ"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("একাউণ্ট পঞ্জীয়ন"),
        "acton": MessageLookupByLibrary.simpleMessage("কাৰ্য্য"),
        "add": MessageLookupByLibrary.simpleMessage("যোগ কৰক"),
        "addBrand": MessageLookupByLibrary.simpleMessage("ব্ৰান্ড যোগ কৰক"),
        "addCategory": MessageLookupByLibrary.simpleMessage("শ্রেণী যোগ কৰক"),
        "addContact": MessageLookupByLibrary.simpleMessage("যোগাযোগ যোগ কৰক"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("গ্ৰাহক যোগ কৰক"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("ডেলিভাৰী যোগ কৰক"),
        "addDescriptioN": MessageLookupByLibrary.simpleMessage("বিৱৰণ যোগ কৰক"),
        "addDescription": MessageLookupByLibrary.simpleMessage("নোট যোগ কৰক"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("ছাড় যোগ কৰক"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("নথি আইডি যোগ কৰক"),
        "addDucument": MessageLookupByLibrary.simpleMessage("নথি যোগ কৰক"),
        "addExpense": MessageLookupByLibrary.simpleMessage("ব্যয় যোগ কৰক"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("ব্যয় শ্ৰেণী যোগ কৰক"),
        "addItems": MessageLookupByLibrary.simpleMessage("আইটেম যোগ কৰক"),
        "addNew": MessageLookupByLibrary.simpleMessage("নতুন যোগ কৰক"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("নতুন ঠিকনা যোগ কৰক"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("নতুন পণ্য যোগ কৰক"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("নতুন কৰ যোগ কৰক"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "একক বা বহু কৰ প্ৰকাৰৰ সৈতে নতুন কৰ যোগ কৰক"),
        "addNote": MessageLookupByLibrary.simpleMessage("টোপনীৰ যোগ কৰক"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("প্ৰথমে প্ৰযুক্ত যোগ কৰক"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("প্ৰমো কোড যোগ কৰক"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("ক্ৰয় যোগ কৰক"),
        "addSales": MessageLookupByLibrary.simpleMessage("বিক্ৰীৰ যোগ কৰক"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("সফলভাৱে যোগ কৰা হৈছে"),
        "addUnit": MessageLookupByLibrary.simpleMessage("একক যোগ কৰক"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("ব্যৱহাৰকাৰী ভূমিকা যোগ কৰক"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("সফলত যোগ কৰা হৈছে"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("কাৰ্টত যোগ কৰা হৈছে"),
        "address": MessageLookupByLibrary.simpleMessage("ঠিকনা"),
        "admin": MessageLookupByLibrary.simpleMessage("এডমিন"),
        "all": MessageLookupByLibrary.simpleMessage("সকল"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("সমস্ত ব্যৱসায়ৰ সমাধান"),
        "alreadyAdded":
            MessageLookupByLibrary.simpleMessage("ইতিমধ্যে যোগ কৰা হৈছে"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("ই ইতিমধ্যে আছে"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("আপোনাৰ ইতিমধ্যে একাউণ্ট আছে"),
        "amount": MessageLookupByLibrary.simpleMessage("মুঠ"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "এখন ইমেইল পঠোৱা হৈছে\nআপোনাৰ ইনবক্স চাওক"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "এণ্ড্ৰয়ড আৰু আইঅ\'ছ আপৰ সহায়"),
        "applicableTax": MessageLookupByLibrary.simpleMessage("প্ৰযোজ্য কৰ"),
        "apply": MessageLookupByLibrary.simpleMessage("আবেদন কৰক"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "আপুনি নিশ্চিত যে এই ইনভইচ অপসাৰণ কৰিব?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "আপুনি নিশ্চিত যে এই বিক্ৰী অপসাৰণ কৰিব?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "আপুনি নিশ্চিত যে এই ব্যৱহাৰকাৰীটো মচিব?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "আপুনি নিশ্চিত জানো এই কৰ মচি পেলাবলৈ?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "আপুনি নিশ্চিত জানো এই কৰ গোট মচি পেলাবলৈ?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "আপুনি নিশ্চিত জানো এই গুদাম মচি পেলাবলৈ?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "আপুনি কি এই ব্যৱহাৰকাৰী মচি পেলাবলৈ নিশ্চিত?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("অনুমোদিত স্বাক্ষৰ"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(খ) আপুনি আপোনাৰ একাউণ্ট আৰু পাছৱৰ্ডৰ গোপনীয়তা বজাই ৰখাৰ আৰু আপোনাৰ একাউণ্টলৈ প্ৰৱেশ সীমাবদ্ধ কৰাৰ বাবে দায়িত্বৱাহী। আপুনি আপোনাৰ একাউণ্টৰ অধীনত হোৱা সকলো কাৰ্যকলাপৰ বাবে দায়িত্ব গ্ৰহণ কৰে।"),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(খ) ছিষ্টেমটো ব্যৱহাৰ কৰিবলৈ আপুনি ১৮ বছৰৰ বা আপোনাৰ অধিক্ষেত্ৰৰ আইনগত বয়সৰ সৰ্বাধিক বয়সৰ পৰা কম নোহোৱা হ\'ব লাগিব।"),
        "backSide": MessageLookupByLibrary.simpleMessage("পিছফাল"),
        "backToHome": MessageLookupByLibrary.simpleMessage("গৃহলৈ উভতি যাওক"),
        "balance": MessageLookupByLibrary.simpleMessage("ব্যালেঞ্চ"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("বাংলাদেশ"),
        "bank": MessageLookupByLibrary.simpleMessage("ব্যাংক"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("ব্যাংক একাউন্ট মুদ্ৰা"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("ব্যাংক অ্যাকাউণ্ট মুদ্ৰা"),
        "bankInformation": MessageLookupByLibrary.simpleMessage("ব্যাংক তথ্য"),
        "bankName": MessageLookupByLibrary.simpleMessage("ব্যাংকৰ নাম"),
        "bankTransfer":
            MessageLookupByLibrary.simpleMessage("ব্যাংক স্থানান্তৰ"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("বারকোড পোৱা গৈছে"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("বিল/ইনভইচ"),
        "billTo": MessageLookupByLibrary.simpleMessage("বিল"),
        "branchName": MessageLookupByLibrary.simpleMessage("শাখাৰ নাম"),
        "brand": MessageLookupByLibrary.simpleMessage("ব্ৰান্ড"),
        "brandName": MessageLookupByLibrary.simpleMessage("ব্ৰান্ড নাম"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("বাল্ক\nআপলোড"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("বিজনেছ শ্ৰেণী"),
        "buy": MessageLookupByLibrary.simpleMessage("কিনক"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("প্ৰিমিয়াম প্‌ল্যান কিনক"),
        "buySms": MessageLookupByLibrary.simpleMessage("এছএমএছ কিনক"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "আপুনি [আপোনাৰ কোম্পানীৰ নাম] দ্বাৰা প্ৰদান কৰা পইণ্ট অৱ সেল (POS) ছিষ্টেম (\"ছিষ্টেম\")ত প্ৰৱেশ কৰি বা ব্যৱহাৰ কৰি, আপুনি এই ব্যৱহাৰৰ চৰ্তবোৰৰ সৈতে বন্ধনবদ্ধ হ\'বলৈ একমত হয়। যদি আপুনি এই ব্যৱহাৰৰ চৰ্তবোৰৰ সৈতে একমত নহয়, তেনেহলে ছিষ্টেমটো ব্যৱহাৰ নকৰিব।"),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(গ) আপোনাৰ ছিষ্টেমলৈ প্ৰৱেশ আৰু ব্যৱহাৰ সকলো প্ৰযোজ্য আইন আৰু নিয়মৰ সৈতে সঙ্গত হয় তাৰ নিশ্চিতকৰণৰ বাবে আপোনাৰ দ্বায়িত্ব।"),
        "cacel": MessageLookupByLibrary.simpleMessage("বাতিল কৰক"),
        "call": MessageLookupByLibrary.simpleMessage("কল"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "এমাৰ্জেন্সী সহায়ৰ বাবে কল কৰক"),
        "camera": MessageLookupByLibrary.simpleMessage("কেমেৰা"),
        "cancel": MessageLookupByLibrary.simpleMessage("বাতিল কৰক"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("সকল উৎপাদক বাতিল কৰক"),
        "capacity": MessageLookupByLibrary.simpleMessage("ক্ষমতা"),
        "card": MessageLookupByLibrary.simpleMessage("কাৰ্ড"),
        "cash": MessageLookupByLibrary.simpleMessage("নগদ"),
        "cashFree": MessageLookupByLibrary.simpleMessage("ক্যাশ মুক্ত"),
        "categories": MessageLookupByLibrary.simpleMessage("শ্রেণীসমূহ"),
        "category": MessageLookupByLibrary.simpleMessage("শ্রেণী"),
        "categoryName": MessageLookupByLibrary.simpleMessage("শ্ৰেণী নাম"),
        "categoryNameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("শ্ৰেণী নাম ইতিমধ্যে আছে"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("শ্ৰেণীৰ নাম"),
        "change": MessageLookupByLibrary.simpleMessage("বদলাব?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("পাছৱৰ্ড সলনি কৰক"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("ইমেইল চেক কৰক"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("এখন গ্ৰাহক বাচি লওক"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("এটা যোগানকাৰী বাচনি কৰক"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("আপোনাৰ বৈশিষ্ট্য বাচি লওক"),
        "clarence": MessageLookupByLibrary.simpleMessage("মুক্তি"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("সংযোগ কৰিবলৈ ক্লিক কৰক"),
        "close": MessageLookupByLibrary.simpleMessage("বন্ধ কৰক"),
        "color": MessageLookupByLibrary.simpleMessage("ৰঙ"),
        "combinationOfMultipleTaxes":
            MessageLookupByLibrary.simpleMessage("(একাধিক কৰৰ সংমিশ্ৰণ)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("শীঘ্ৰে আহিব"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("কাম্পানীৰ ঠিকনা"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("কাম্পানী আৰু দোকানৰ নাম"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("কোম্পানী আৰু ব্যৱসায়ৰ নাম"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("লেনদেন সম্পূৰ্ণ কৰক"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("পাছৰ সংকেত নিশ্চিত কৰক"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("উভতি নিশ্চিত কৰক"),
        "congratulations": MessageLookupByLibrary.simpleMessage("অভিনন্দন"),
        "contactUs":
            MessageLookupByLibrary.simpleMessage("আমাৰ সৈতে যোগাযোগ কৰক"),
        "continu": MessageLookupByLibrary.simpleMessage("অগ্ৰসৰণ"),
        "country": MessageLookupByLibrary.simpleMessage("দেশ"),
        "create": MessageLookupByLibrary.simpleMessage("তৈয়াৰ কৰক"),
        "createAFreeAccounts": MessageLookupByLibrary.simpleMessage(
            "এটা বিনামূলীয়া একাউণ্ট বনাওক"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("সৃষ্টি কৰা আৰু সংৰক্ষণ কৰা"),
        "currency": MessageLookupByLibrary.simpleMessage("মুদ্ৰা"),
        "currentStock": MessageLookupByLibrary.simpleMessage("বৰ্তমান ষ্টক"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("কাষ্টম ইনভয়চ ব্ৰেণ্ডিং"),
        "customer": MessageLookupByLibrary.simpleMessage("গ্ৰাহক"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("গ্ৰাহকৰ বিৱৰণ"),
        "customerGST": MessageLookupByLibrary.simpleMessage("গ্ৰাহক GST"),
        "customerName": MessageLookupByLibrary.simpleMessage("গ্ৰাহকৰ নাম"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("দৈনিক লেনদেন"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("ডেশ্বব’ৰ্ড পৰ্যালোচনা"),
        "dataSavedSuccessfully": MessageLookupByLibrary.simpleMessage(
            "তথ্য সফলতাৰে সংৰক্ষণ কৰা হৈছে"),
        "date": MessageLookupByLibrary.simpleMessage("তাৰিখ"),
        "day": MessageLookupByLibrary.simpleMessage("দিন"),
        "dealer": MessageLookupByLibrary.simpleMessage("বিক্ৰেতা"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("ডীলাৰ মূল্য"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("ডিফল্ট VAT শতাংশ"),
        "delete": MessageLookupByLibrary.simpleMessage("মচি দিয়া"),
        "deleting": MessageLookupByLibrary.simpleMessage("অপসাৰণ কৰা হৈছে"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("ডেলিভাৰী ঠিকনা"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("ডেলিভাৰী ঠিকনা"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("ডেলিভাৰী মাচুল"),
        "describtion": MessageLookupByLibrary.simpleMessage("বিৱৰণ"),
        "description": MessageLookupByLibrary.simpleMessage("বিৱৰণ"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("বিৱৰণ খালী নোহোৱা উচিত"),
        "details": MessageLookupByLibrary.simpleMessage("বিৱৰণ"),
        "discount": MessageLookupByLibrary.simpleMessage("ছাড়"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("ব্যাঘাত নিদিব"),
        "done": MessageLookupByLibrary.simpleMessage("সম্পন্ন"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Excel ফৰ্মেট ডাউনলোড কৰক"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "ডাউনলোড ফোল্ডাৰত সফলভাৱে ডাউনলোড হৈছে"),
        "due": MessageLookupByLibrary.simpleMessage("বকেয়া"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("বকেয়া ৰাশি: "),
        "dueCollection": MessageLookupByLibrary.simpleMessage("বকেয়া সংগ্ৰহ"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("দেউতালিপি ৰিপৰ্ট"),
        "dueList": MessageLookupByLibrary.simpleMessage("বকেয়া তালিকা"),
        "dueReports": MessageLookupByLibrary.simpleMessage("বাকী প্ৰতিবেদন"),
        "duration": MessageLookupByLibrary.simpleMessage("কাল"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("সময়কাল: থেকে"),
        "easyToUseMobilePos":
            MessageLookupByLibrary.simpleMessage("ব্যৱহাৰলৈ সহজ ম\'বাইল পছ"),
        "edit": MessageLookupByLibrary.simpleMessage("সম্পাদনা কৰক"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("ক্ৰয় ইনভইচ সম্পাদনা কৰক"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("বিক্ৰী ইনভইচ সম্পাদনা কৰক"),
        "editSocailMedia": MessageLookupByLibrary.simpleMessage(
            "ছ\'চিয়েল মিডিয়া সম্পাদনা কৰক"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("সফলভাবে সম্পাদনা কৰা হৈছে"),
        "editTax": MessageLookupByLibrary.simpleMessage("কৰ সম্পাদনা কৰক"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("কৰ গোট সম্পাদনা কৰক"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("গুদাম সম্পাদনা কৰক"),
        "email": MessageLookupByLibrary.simpleMessage("ইমেইল"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("ইমেইল ঠিকনা"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("ইমেইল খালী নহ\'ব পাৰে"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "ইমেইল পঠোৱা হৈছে! আপোনাৰ ইনবক্স চাওক"),
        "endDate": MessageLookupByLibrary.simpleMessage("শেষৰ তাৰিখ"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("এটা বৈধ পৰিমাণ প্ৰবিষ্ট কৰক"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("এক বৈধ ছাড় প্ৰৱিষ্ট কৰক"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "এটা বৈধ ফোন নম্বৰ প্ৰবিষ্ট কৰক"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("এটা বৈধ মূল্য প্ৰৱিষ্ট কৰক"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("এটা বৈধ পৰিমাণ প্ৰৱিষ্ট কৰক"),
        "enterAddress":
            MessageLookupByLibrary.simpleMessage("ঠিকনা প্ৰৱিষ্ট কৰক"),
        "enterAmount":
            MessageLookupByLibrary.simpleMessage("ৰাশি প্ৰৱিষ্ট কৰক।"),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("ব্ৰান্ড নাম প্রবিষ্ট কৰক"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("ক্ষমতা প্রবিষ্ট কৰক"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("শ্রেণী নাম প্রবিষ্ট কৰক"),
        "enterColor": MessageLookupByLibrary.simpleMessage("ৰঙ প্রবিষ্ট কৰক"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "গ্ৰাহকৰ GST নম্বৰ প্ৰবিষ্ট কৰক"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("ডীলাৰ মূল্য প্রবিষ্ট কৰক"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("বিৱৰণ প্ৰৱিষ্ট কৰক"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("ছাড় প্রবিষ্ট কৰক।"),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("ব্যয়ৰ তাৰিখ প্রবিষ্ট কৰক"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("সম্পূৰ্ণ ঠিকনা প্ৰৱিষ্ট কৰক"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("ইনভইচ নম্বৰ প্ৰৱিষ্ট কৰক"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "কম ষ্টক সতৰ্কতা পৰিমাণ প্ৰৱিষ্ট কৰক"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("উৎপাদক প্রবিষ্ট কৰক"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("বার্তা সামগ্ৰী প্ৰৱিষ্ট কৰক"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "এমআৰপি/বিক্ৰেতাৰ মূল্য প্রবিষ্ট কৰক"),
        "enterName": MessageLookupByLibrary.simpleMessage("নাম প্রবিষ্ট কৰক"),
        "enterNote": MessageLookupByLibrary.simpleMessage("টোপনী প্রবিষ্ট কৰক"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("পক্ষৰ নাম প্ৰৱিষ্ট কৰক"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("ফোন নম্বৰ প্ৰৱিষ্ট কৰক"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "পণ্যের কোড প্রবিষ্ট কৰক বা স্কেন কৰক"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("পণ্যের নাম প্রবিষ্ট কৰক"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("ক্ৰয় মূল্য প্রবিষ্ট কৰক।"),
        "enterReferenceNumber": MessageLookupByLibrary.simpleMessage(
            "ৰেফাৰেন্স সংখ্যা প্রবিষ্ট কৰক"),
        "enterSize": MessageLookupByLibrary.simpleMessage("আকাৰ প্রবিষ্ট কৰক"),
        "enterStocks":
            MessageLookupByLibrary.simpleMessage("ষ্টক প্রবিষ্ট কৰক।"),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("কৰৰ হাৰ প্ৰৱিষ্ট কৰক"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("লেনদেন ID প্রবেশ কৰক"),
        "enterType":
            MessageLookupByLibrary.simpleMessage("প্ৰকাৰ প্রবিষ্ট কৰক"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("ব্যৱহাৰকাৰী শিৰোনাম লিখক"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("বৈধ পৰিমাণ প্ৰবিষ্ট কৰক"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("গুদাম নাম প্ৰৱিষ্ট কৰক"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("ওজন প্রবিষ্ট কৰক"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("সামগ্ৰিক মূল্য প্রবিষ্ট কৰক"),
        "enterYourDescriptionHere": MessageLookupByLibrary.simpleMessage(
            "আপোনাৰ বিৱৰণ ইয়াত প্ৰৱিষ্ট কৰক"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "আপোনাৰ ইমেইল ঠিকনা প্রবেশ কৰক"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "আপোনাৰ মতামতৰ শিৰোনাম প্ৰৱিষ্ট কৰক"),
        "enterYourGSTNumber": MessageLookupByLibrary.simpleMessage(
            "আপোনাৰ GST নম্বৰ প্ৰবিষ্ট কৰক"),
        "enterYourMobileNumber": MessageLookupByLibrary.simpleMessage(
            "আপোনাৰ ম\'বাইল নম্বৰ প্ৰৱিষ্ট কৰক"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("আপোনাৰ নাম প্ৰৱিষ্ট কৰক"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("আপোনাৰ ফোন নম্বৰ প্ৰবেশ কৰক"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("আপোনাৰ পাছৱৰ্ড লিখক"),
        "enterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "আপোনাৰ ফোন নম্বৰ প্ৰৱিষ্ট কৰক"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "আপোনাৰ লেনদেন আইডি প্ৰৱিষ্ট কৰক"),
        "error": MessageLookupByLibrary.simpleMessage("ভুল"),
        "excTax": MessageLookupByLibrary.simpleMessage("এক্সক্লুড. কৰ"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("Excel আপলোডাৰ"),
        "exclusive": MessageLookupByLibrary.simpleMessage("বিচ্ছিন্ন"),
        "expense": MessageLookupByLibrary.simpleMessage("ব্যয়"),
        "expenseCategory": MessageLookupByLibrary.simpleMessage("ব্যয় শ্ৰেণী"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("ব্যয়ৰ তাৰিখ"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("ব্যয়ৰ বাবে"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("ব্যয় প্ৰতিবেদন"),
        "expireDate":
            MessageLookupByLibrary.simpleMessage("মেয়াদ শেষ হোৱাৰ তাৰিখ"),
        "expired": MessageLookupByLibrary.simpleMessage("মেয়াদ শেষ"),
        "expiring": MessageLookupByLibrary.simpleMessage("মেয়াদ শেষ হৈছে"),
        "facebok": MessageLookupByLibrary.simpleMessage("ফেচবুক"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("ভুলৰ সৈতে বিফল"),
        "fashion": MessageLookupByLibrary.simpleMessage("ফেচন"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "বৈশিষ্ট্যবোৰ হৈছে সেই গুৰুত্বপূর্ণ অংশ যি পছ SaaS ক পৰম্পৰাগত সমাধানৰ পৰা ভিন্ন কৰে।"),
        "feedBack": MessageLookupByLibrary.simpleMessage("মতামত"),
        "firstName": MessageLookupByLibrary.simpleMessage("প্ৰথম নাম"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("আমাক ফেচবুকত অনুসৰণ কৰক"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("আমাক টুইটাৰত অনুসৰণ কৰক"),
        "fontSide": MessageLookupByLibrary.simpleMessage("ফন্ট পৃষ্ঠ"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("অসীম ব্যৱহাৰৰ বাবে"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("পাছৱৰ্ড পাহৰিছেনে?"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("পাছৱৰ্ড পাহৰিছে?"),
        "formDate": MessageLookupByLibrary.simpleMessage("তাৰিখৰ পৰা"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("মুক্ত তথ্য ব্যাকআপ"),
        "freeLifeTimeUpdate":
            MessageLookupByLibrary.simpleMessage("মুক্ত জীৱনৰ আপডেট"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("নিখৰ্চ পেকেজ"),
        "freePlan": MessageLookupByLibrary.simpleMessage("নিখৰ্চ প্‌ল্যান"),
        "from": MessageLookupByLibrary.simpleMessage("(থেকে"),
        "fullyPaid":
            MessageLookupByLibrary.simpleMessage("সম্পূৰ্ণভাৱে পৰিশোধিত"),
        "gallary": MessageLookupByLibrary.simpleMessage("গেলাৰী"),
        "generatingPDF":
            MessageLookupByLibrary.simpleMessage("PDF উৎপাদন কৰা হৈছে"),
        "getOtp": MessageLookupByLibrary.simpleMessage("OTP লওক"),
        "govermentId": MessageLookupByLibrary.simpleMessage("ৰাজ্য আইডি"),
        "guest": MessageLookupByLibrary.simpleMessage("অতিথি"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("আপোনাৰ কোনো একাউণ্ট নাই?"),
        "history": MessageLookupByLibrary.simpleMessage("ইতিহাস"),
        "home": MessageLookupByLibrary.simpleMessage("বাড়ী"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "আমরা আপোনাৰ তথ্য কেনেকৈ সুৰক্ষিত কৰোঁ"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "আমরা আপোনাৰ তথ্য কেনেকৈ ব্যৱহাৰ কৰোঁ"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("পৰিচয় প্ৰমাণীকৰণ"),
        "image": MessageLookupByLibrary.simpleMessage("ছবি"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("ইন-হাউচ মচি পেলাব নোৱাৰি"),
        "inHouseCantBeEdited": MessageLookupByLibrary.simpleMessage(
            "ইন-হাউচ সম্পাদনা কৰিব নোৱাৰি"),
        "inWord": MessageLookupByLibrary.simpleMessage("শব্দত"),
        "incTax": MessageLookupByLibrary.simpleMessage("ইনক্লুড. কৰ"),
        "inclusive": MessageLookupByLibrary.simpleMessage("সন্মিলিত"),
        "increaseStock":
            MessageLookupByLibrary.simpleMessage("ষ্টক বৃদ্ধি কৰক"),
        "inistrument": MessageLookupByLibrary.simpleMessage("যন্ত্ৰ"),
        "instragram": MessageLookupByLibrary.simpleMessage("ইনষ্টাগ্ৰাম"),
        "invNo": MessageLookupByLibrary.simpleMessage("ইনভ নং।"),
        "invoice": MessageLookupByLibrary.simpleMessage("চিট"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("ইনভইচ নম্বৰ"),
        "invoiceSetting": MessageLookupByLibrary.simpleMessage("ইনভইচ সেৱা"),
        "invoiceViewer": MessageLookupByLibrary.simpleMessage("চিট প্ৰদৰ্শক"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("আইটেম যোগ কৰা হৈছে"),
        "kg": MessageLookupByLibrary.simpleMessage("কেজি"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("KYC প্ৰমাণীকৰণ"),
        "language": MessageLookupByLibrary.simpleMessage("ভাষা"),
        "lastName": MessageLookupByLibrary.simpleMessage("অন্তিম নাম"),
        "ledger": MessageLookupByLibrary.simpleMessage("লেনদেন"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("লাইফটাইম\nক্ৰয়"),
        "link": MessageLookupByLibrary.simpleMessage("লিংক"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("লিংকডইন"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("লাইভ চ্যাট সহায়"),
        "loading": MessageLookupByLibrary.simpleMessage("লোড হৈ আছে"),
        "logIn": MessageLookupByLibrary.simpleMessage("লগইন"),
        "logOUt": MessageLookupByLibrary.simpleMessage("লগ আউট"),
        "logOut": MessageLookupByLibrary.simpleMessage("লগ আউট"),
        "login": MessageLookupByLibrary.simpleMessage("লগ ইন কৰক"),
        "logo": MessageLookupByLibrary.simpleMessage("লোগো"),
        "loss": MessageLookupByLibrary.simpleMessage("ক্ষতি"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("ক্ষতি/লাভ"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("ক্ষতি/লাভৰ বিবৰণ"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("লোকচান/লাভ প্ৰতিবেদন"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("লোকচান/লাভ প্ৰতিবেদন"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("কম ষ্টক সতৰ্কতা"),
        "maan": MessageLookupByLibrary.simpleMessage("মান"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "আপোনাৰ গ্ৰাহকসকলৰ ওপৰত এটা স্থায়ী প্ৰভাৱ সৃষ্টি কৰক ব্ৰেণ্ডেড ইনভয়চৰ সৈতে। আমাৰ Unlimited Upgrade তেওঁলোকৰ কাষ্টমাইজ কৰাৰ এক বিশেষ সুবিধা প্ৰদান কৰে, যিয়ে আপোনাৰ ব্ৰেণ্ডৰ পৰিচয় প্ৰতিস্থাপন কৰে আৰু গ্ৰাহক বিশ্বাসকে উৎসাহিত কৰে।"),
        "manageYourBussinessWith": MessageLookupByLibrary.simpleMessage(
            "আপোনাৰ ব্যৱসায় ব্যৱস্থাপনা কৰক "),
        "manufactureDate": MessageLookupByLibrary.simpleMessage("উৎপাদন তাৰিখ"),
        "margin": MessageLookupByLibrary.simpleMessage("মাৰ্জিন"),
        "masterCard": MessageLookupByLibrary.simpleMessage("মাষ্টাৰ কাৰ্ড"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("উৎপাদক"),
        "message": MessageLookupByLibrary.simpleMessage(" বাৰ্তা"),
        "messageHistory": MessageLookupByLibrary.simpleMessage("বার্তা ইতিহাস"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "পছ SaaS এপ নিখৰ্চ, ব্যৱহাৰ কৰিবলৈ সহজ। বাস্তৱতে, ই বিশ্বৰ এটি আটাইতকৈ ভাল পছ প্ৰণালী।"),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "পছ SaaS হৈছে এটা সম্পূৰ্ণ ব্যৱসায় সমাধান য\'ত ষ্টক, একাউন্ট, বিক্ৰী, খৰচ আৰু লোকচান/লাভ থাকে।"),
        "mobile": MessageLookupByLibrary.simpleMessage("ম\'বাইল"),
        "mobilePayment":
            MessageLookupByLibrary.simpleMessage("ম\'বাইল পেমেণ্ট"),
        "monthly": MessageLookupByLibrary.simpleMessage("মাহে মাহে"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("অধিক তথ্য"),
        "name":
            MessageLookupByLibrary.simpleMessage("আপোনাৰ নাম প্ৰৱিষ্ট কৰক।"),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("নাম ইতিমধ্যে আছে"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("নাম খালী কৰিব নোৱাৰিব"),
        "next": MessageLookupByLibrary.simpleMessage("পৰৱৰ্তী"),
        "noConnection": MessageLookupByLibrary.simpleMessage("কোনো সংযোগ নাই"),
        "noData": MessageLookupByLibrary.simpleMessage("ডেটা নাই"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("কোনো তথ্য উপলব্ধ নাই"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("কোনো ডাটা পোৱা নগ\'ল"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("কোনো ইতিহাস পোৱা নগ\'ল!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("কোনো প্ৰযুক্ত পোৱা নগ\'ল"),
        "noSubTaxSelected": MessageLookupByLibrary.simpleMessage(
            "কোনো উপ কৰ বাচনি কৰা হোৱা নাই"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("কোনো লেনদেন পোৱা নগ\'ল!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "সেই ইমেইলৰ বাবে কোনো ব্যৱহাৰকাৰী পোৱা হোৱা নাই।"),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "কোনো ব্যৱহাৰকাৰী ভূমিকা পোৱা নগ\'ল"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("সক্রিয় ব্যৱহাৰকাৰী নহয়"),
        "notProvided": MessageLookupByLibrary.simpleMessage("প্ৰদান কৰা নাই"),
        "note": MessageLookupByLibrary.simpleMessage("টোপনী"),
        "notes": MessageLookupByLibrary.simpleMessage("নোট"),
        "notification": MessageLookupByLibrary.simpleMessage("অৱগতী"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP পঠিওৱা হৈছে"),
        "office": MessageLookupByLibrary.simpleMessage("অফিচ"),
        "ok": MessageLookupByLibrary.simpleMessage("ঠিক আছে"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS য\'ত বিক্ৰী অনুসৰণ, ষ্টক ব্যৱস্থাপনা আদি কাৰ্যসূচী সহ একাধিক কাৰ্যপদ্ধতি আছে।"),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "এই ছিষ্টেমে আপোনাৰ গ্ৰাহকসকলৰ বাবে আপোনাৰ কাৰ্যকলাপ উন্নত কৰাত সহায় কৰে।"),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "আমাৰ POS ছিষ্টেমে দৈনিক কাৰ্যকলাপ সহজ কৰি দিব লাগিব, যিয়ে আপোনাৰ বাবে নেভিগেট কৰা সহজ কৰি তোলে।"),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("আৰম্ভণি ব্যালেন্স"),
        "order": MessageLookupByLibrary.simpleMessage("অৰ্ডাৰ"),
        "other": MessageLookupByLibrary.simpleMessage("অন্যান্য"),
        "otp": MessageLookupByLibrary.simpleMessage("বন্ধ কৰক"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("ষ্টকত নাই"),
        "pacakge": MessageLookupByLibrary.simpleMessage("পেকেজ"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("পেকেজৰ বৈশিষ্ট্য"),
        "paid": MessageLookupByLibrary.simpleMessage("পৰিশোধিত"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("পৰিশোধিত ৰাশি"),
        "parties": MessageLookupByLibrary.simpleMessage("পাৰ্টীসমূহ"),
        "partiesList": MessageLookupByLibrary.simpleMessage("পক্ষৰ তালিকা"),
        "partyGST": MessageLookupByLibrary.simpleMessage("পাৰ্টি GST"),
        "partyName": MessageLookupByLibrary.simpleMessage("পক্ষৰ নাম"),
        "password": MessageLookupByLibrary.simpleMessage("পাছৱৰ্ড"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "পাছৱাৰ্ড আৰু নিশ্চিত কৰা পাছৱাৰ্ড মিলা নগ\'ল"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("পাছৱৰ্ড খালী নহ\'ব পাৰে"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("পাছৱৰ্ড মেচ নহয়"),
        "payCash": MessageLookupByLibrary.simpleMessage("নগদ পৰিশোধ কৰক"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("বিকাশৰ সৈতে পেমেণ্ট কৰক"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("পে\' পলৰ জৰিয়তে পে\' কৰক"),
        "payeeName": MessageLookupByLibrary.simpleMessage("পেমী নাম"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("পেমী নম্বৰ"),
        "payment": MessageLookupByLibrary.simpleMessage("পৰিশোধ"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("পে\'মেন্টৰ মুঠ"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("পৰিশোধ সম্পূৰ্ণ"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("পেমেণ্টৰ নিৰ্দেশনা:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("পেমেণ্ট পদ্ধতি"),
        "paymentType": MessageLookupByLibrary.simpleMessage("পৰিশোধৰ প্ৰকাৰ"),
        "pdfView": MessageLookupByLibrary.simpleMessage("PDF দৃশ্য"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("ব্যক্তিগত তথ্য"),
        "phone": MessageLookupByLibrary.simpleMessage("ফোন"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("ফোন নম্বৰ"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "ফোন নম্বৰ ইতিমধ্যে ব্যৱহৃত হৈছে"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("ফোন নম্বৰ বৈধ নহয়"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("ফোন নম্বৰ আৱশ্যক"),
        "pickAndUploadFile": MessageLookupByLibrary.simpleMessage(
            "ফাইল বাছনি কৰক আৰু আপলোড কৰক"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("শেষৰ তাৰিখ বাচি লওক"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("আৰম্ভৰ তাৰিখ বাচি লওক"),
        "plan": MessageLookupByLibrary.simpleMessage("যোজনা"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("দয়া কৰি পৰিমাণ যোগ কৰক"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "আপোনাৰ ইন্টাৰনেট সংযোগ পৰীক্ষা কৰক"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "দয়া কৰি প্ৰথমত প্ৰিণ্টাৰ সংযোগ কৰক"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "অনুগ্ৰহ কৰি আপোনাৰ ব্লুটুথ মুদ্ৰক সংযোগ কৰক"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "দয়া কৰি এটি বৃহৎ পাছৱৰ্ড প্ৰবিষ্ট কৰক"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "দয়া কৰি এটা পাছৰ সংকেত নিশ্চিত কৰক"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("এক পাসৱৰ্ড প্রবেশ কৰক"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "দয়া কৰি এটা বৈধ ইমেইল প্ৰবিষ্ট কৰক"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("দয়া কৰি নাম প্ৰবিষ্ট কৰক"),
        "pleaseEnterPassword": MessageLookupByLibrary.simpleMessage(
            "অনুগ্ৰহ কৰি পাছৱাৰ্ড প্ৰৱিষ্ট কৰক"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "পাছৱৰ্ড ৰিছেট লিংক পোৱাৰ বাবে তলত আপোনাৰ ইমেইল ঠিকনা প্ৰবেশ কৰক।"),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "অনুগ্ৰহ কৰি লেনদেন নম্বৰ প্ৰৱিষ্ট কৰক"),
        "pleaseInterAmount": MessageLookupByLibrary.simpleMessage(
            "দয়া কৰি পৰিমাণ প্ৰবিষ্ট কৰক"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "দয়া কৰি প্ৰথমে এটা শ্ৰেণী বাচি লওক"),
        "pleaseSelectAPlan": MessageLookupByLibrary.simpleMessage(
            "অনুগ্ৰহ কৰি এখন পৰিকল্পনা বাচন কৰক"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "দয়া কৰি ব্যৱসায়ৰ শ্ৰেণী বাচি লওক"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "অনুগ্ৰহ কৰি প্ৰৱিষ্ট কোড ব্যৱহাৰ কৰক"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("MobiPos দ্বাৰা শক্তিত"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("শক্তি দিয়া"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("প্ৰিমিয়াম গ্ৰাহক সহায়"),
        "premiumPlan":
            MessageLookupByLibrary.simpleMessage("প্ৰিমিয়াম প্‌ল্যান"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("পূৰ্বৰ পেমেণ্টৰ পৰিমাণ"),
        "price": MessageLookupByLibrary.simpleMessage("মূল্য"),
        "print": MessageLookupByLibrary.simpleMessage("মুদ্রণ"),
        "printingOption": MessageLookupByLibrary.simpleMessage("ছাপাৰ বিকল্প"),
        "privacyPolicy": MessageLookupByLibrary.simpleMessage("গোপনীয়তা নীতি"),
        "product": MessageLookupByLibrary.simpleMessage("পণ্য"),
        "productCode": MessageLookupByLibrary.simpleMessage("পণ্যের কোড"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("উৎপাদক কোড আৱশ্যক"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("প্ৰযুক্ত কোড/নাম"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("প্ৰযুক্ত বিৱৰণ"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("প্ৰযুক্ত বিৱৰণ"),
        "productList": MessageLookupByLibrary.simpleMessage("পণ্যের তালিকা"),
        "productName": MessageLookupByLibrary.simpleMessage("পণ্যের নাম"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "উৎপাদকৰ নাম ইতিমধ্যে এই গুদামত আছে"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "প্ৰযুক্ত নাম আগতে যোগ কৰা হৈছে"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("উৎপাদকৰ নাম আৱশ্যক"),
        "products": MessageLookupByLibrary.simpleMessage("উৎপাদক"),
        "profile": MessageLookupByLibrary.simpleMessage("প্ৰ\'ফাইল"),
        "profileEdit":
            MessageLookupByLibrary.simpleMessage("প্ৰোফাইল সম্পাদনা"),
        "profit": MessageLookupByLibrary.simpleMessage("লাভ"),
        "promo": MessageLookupByLibrary.simpleMessage("প্ৰমো"),
        "promoCode": MessageLookupByLibrary.simpleMessage("প্ৰমো কোড"),
        "purchase": MessageLookupByLibrary.simpleMessage("ক্ৰয়"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage("ক্ৰয়ৰ সংকেত"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("ক্ৰয় নিশ্চিত কৰা হৈছে"),
        "purchaseDetails": MessageLookupByLibrary.simpleMessage("ক্ৰয়ৰ বিৱৰণ"),
        "purchaseInvoice": MessageLookupByLibrary.simpleMessage("ক্ৰয় ইনভইচ"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("ক্ৰয়ৰ তালিকা"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("এতিয়াই কিনক"),
        "purchasePremiumPlan": MessageLookupByLibrary.simpleMessage(
            "প্ৰিমিয়াম প্‌ল্যান ক্ৰয় কৰক"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("ক্ৰয় মূল্য"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("ক্ৰয় মূল্য আৱশ্যক"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("ক্ৰয় প্ৰতিবেদন"),
        "purchaseReports": MessageLookupByLibrary.simpleMessage("ক্ৰয়ৰ মূল্য"),
        "purchaseReportss": MessageLookupByLibrary.simpleMessage("কিনো ৰিপৰ্ট"),
        "purchaseReturn": MessageLookupByLibrary.simpleMessage("ক্ৰয় উভতি"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("ক্ৰয় উভতি প্ৰতিবেদন"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("ক্ৰয় স্থানান্তৰ"),
        "qty": MessageLookupByLibrary.simpleMessage("মাত্ৰা"),
        "quantity": MessageLookupByLibrary.simpleMessage("পরিমাণ"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("সাম্প্ৰতিক লেনদেন"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("পিন গ্ৰহণ কৰা হৈছে"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("ৰেফাৰেন্স সংখ্যা"),
        "register": MessageLookupByLibrary.simpleMessage("নিবন্ধন কৰক"),
        "registering": MessageLookupByLibrary.simpleMessage("নিবন্ধন কৰাছে"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("বাকী মাকৰ"),
        "remove": MessageLookupByLibrary.simpleMessage("অপসাৰণ"),
        "reports": MessageLookupByLibrary.simpleMessage("প্ৰতিবেদন"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("অনুৰোধ পঠোৱা হৈছে"),
        "resendCode": MessageLookupByLibrary.simpleMessage("কোড পুনৰ পঠাও"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("OTP পুনৰ পঠাও : "),
        "retailer": MessageLookupByLibrary.simpleMessage("খুচুৰা বিক্ৰেতা"),
        "retur": MessageLookupByLibrary.simpleMessage("ফিৰাই দিয়ক"),
        "returN": MessageLookupByLibrary.simpleMessage("উভতি"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("ফিৰাই দিয়ক"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("ফিৰতি পৰিমাণ"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("উভতি পৰিমাণ"),
        "revenue": MessageLookupByLibrary.simpleMessage("আয়"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "আপোনাৰ ব্যৱসায়ৰ তথ্য নিৰাপত্তা দিয়া সৰল। আমাৰ Pos SaaS POS Unlimited Upgrade মুক্ত তথ্য ব্যাকআপ অন্তর্ভুক্ত কৰে, যিয়ে আপোনাৰ মূল্যবান তথ্য যিকোনো অনাকাংক্ষিত ঘটনাৰ পৰা সুৰক্ষিত কৰে। আপুনি যে প্ৰকৃততে গুৰুত্ব দিয়া উচিত - আপোনাৰ ব্যৱসায়ৰ বৃদ্ধিত।"),
        "saleAmount": MessageLookupByLibrary.simpleMessage("বিক্ৰী পৰিমাণ"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("বিক্ৰীৰ বিৱৰণ"),
        "salePrice": MessageLookupByLibrary.simpleMessage("বিক্ৰী মূল্য"),
        "saleReports":
            MessageLookupByLibrary.simpleMessage("বিক্ৰীৰ প্ৰতিবেদন"),
        "saleReportss": MessageLookupByLibrary.simpleMessage("বিক্ৰী ৰিপৰ্ট"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("বিক্ৰী উভতি"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("বিক্ৰী উভতি প্ৰতিবেদন"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("বিক্ৰী ছেটিং"),
        "sales": MessageLookupByLibrary.simpleMessage("বিক্ৰী"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("বিক্ৰী আৰু ক্ৰয় ৰিপৰ্ট"),
        "salesList": MessageLookupByLibrary.simpleMessage("বিক্ৰী তালিকা"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("বিক্ৰী উভতি"),
        "save": MessageLookupByLibrary.simpleMessage("সংৰক্ষণ কৰক"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("সংৰক্ষণ আৰু প্ৰকাশ কৰক"),
        "saveChanges":
            MessageLookupByLibrary.simpleMessage("পৰিবৰ্তন সুৰক্ষিত কৰক"),
        "saving": MessageLookupByLibrary.simpleMessage("সংৰক্ষণ কৰা হৈছে"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("প্ৰযুক্ত QR কোড স্কেন কৰক"),
        "search": MessageLookupByLibrary.simpleMessage("অনুসন্ধান কৰক"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "প্ৰযুক্ত কোড বা নাম দ্বাৰা সন্ধান কৰক"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("সমস্ত প্ৰমো কোড চাওক"),
        "select": MessageLookupByLibrary.simpleMessage("বাচনি কৰক"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "উভতি দিবলৈ এটা প্ৰযুক্ত বাচনি কৰক"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("ব্রেণ্ড বাচি লওক"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("শ্ৰেণী বাচি লওক"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("যোগাযোগ বাচি লওক"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("উৎপাদকৰ শ্ৰেণী বাচি লওক"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("দোকান শ্ৰেণী বাচি লওক"),
        "selectTax": MessageLookupByLibrary.simpleMessage("কৰ বাচি লওক"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("কৰ প্ৰকাৰ বাচি লওক"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("একক বাচি লওক"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("বৈচিত্র্য বাচনি কৰক: "),
        "seller": MessageLookupByLibrary.simpleMessage("বিক্ৰেতা"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("বিক্ৰী কৰিছে"),
        "send": MessageLookupByLibrary.simpleMessage("পঠিয়াও"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("ই-মেইল পঠিয়াও"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("বার্তা পঠিয়াব"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("ৰিছেট লিংক পঠিয়াও"),
        "sendSms": MessageLookupByLibrary.simpleMessage("ছএমএছ পঠিয়াও"),
        "sendSmsw":
            MessageLookupByLibrary.simpleMessage("এছএমএছ পঠিয়াব নেকি?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("WhatsApp বাৰ্তা পঠিওৱা"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("আপোনাৰ ইমেইল পঠিয়াব"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage("ইমেইল পঠাইছে"),
        "sendingMessage": MessageLookupByLibrary.simpleMessage("বার্তা পঠাইছে"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("ছাৰ্ভিছ/শিপিং"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("আপোনাৰ প্ৰোফাইল স্থাপন কৰক"),
        "setting": MessageLookupByLibrary.simpleMessage("ছেটিং"),
        "share": MessageLookupByLibrary.simpleMessage("ভাগ দিব"),
        "shopGST": MessageLookupByLibrary.simpleMessage("দোকান GST"),
        "signIn": MessageLookupByLibrary.simpleMessage("সাইন ইন কৰক"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("ইমেইলৰ সৈতে সাইন ইন কৰক"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("গ্ৰাহকৰ স্বাক্ষৰ"),
        "size": MessageLookupByLibrary.simpleMessage("আকাৰ"),
        "skip": MessageLookupByLibrary.simpleMessage("মিছা"),
        "sms": MessageLookupByLibrary.simpleMessage("এছএমএছ"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("ছ\'চিয়েল মাৰ্কেটিং"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "দয়া কৰি, আপোনাৰ এই সেৱালৈ প্ৰৱেশ কৰিবলৈ অনুমতি নাই"),
        "startDate": MessageLookupByLibrary.simpleMessage("আৰম্ভৰ তাৰিখ"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("নতুন বিক্ৰী আৰম্ভ কৰক"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage(
            "অনুসন্ধান কৰিবলৈ টাইপ কৰা আৰম্ভ কৰক"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "অতি আধুনিক প্রযুক্তি উন্নয়নৰ শীৰ্ষত থাকক বিনামূল্যে। আমাৰ POS SaaS Unlimited Upgrade নিশ্চিত কৰে যে আপুনি সদায় আপোনাৰ আঙুলিৰ পৰা সৰ্বাধিক সঁজুলি আৰু বৈশিষ্ট্য পাব, আপোনাৰ ব্যৱসায়ক কাটিং-এজৰ পৰা আঁতৰোৱা নহয়।"),
        "stillUnpaid":
            MessageLookupByLibrary.simpleMessage("এযাবৎ পৰিশোধিত নহয়"),
        "stock": MessageLookupByLibrary.simpleMessage("ষ্টক"),
        "stockIsRequired": MessageLookupByLibrary.simpleMessage("ষ্টক আৱশ্যক"),
        "stockList": MessageLookupByLibrary.simpleMessage("ষ্টক তালিকা"),
        "stocks": MessageLookupByLibrary.simpleMessage("ষ্টক"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Excel ফাইল সৃষ্টি কৰিবলৈ সঞ্চয় অনুমতি আৱশ্যক"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("উপ কৰৰ তালিকা"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("উপ কৰ"),
        "subTotal": MessageLookupByLibrary.simpleMessage("উপমুঠ"),
        "submit": MessageLookupByLibrary.simpleMessage("জমা কৰক"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "আমাৰ ইউটিউব চেনেলত সদস্যতা গ্ৰহণ কৰক"),
        "subscription": MessageLookupByLibrary.simpleMessage("সাবস্ক্ৰিপচন"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("সফলভাৱে কৰা হৈছে"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("সফলভাবে লগ আউট"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("সফলভাবে আপডেট কৰা হৈছে"),
        "supplier": MessageLookupByLibrary.simpleMessage("যোগান দাতা"),
        "supplierName": MessageLookupByLibrary.simpleMessage("যোগানকাৰীৰ নাম"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT কোড"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "ড্ৰাইভাৰৰ লাইচেঞ্চ, ৰাষ্ট্ৰীয় পৰিচয় পত্ৰ বা পাছপ\'ৰ্টৰ ফটো তুলক"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "আপোনাৰ তথ্য পৰীক্ষাৰ বাবে এখন পৰিচয় পত্ৰৰ চিত্ৰ তুলক"),
        "tap": MessageLookupByLibrary.simpleMessage("টাপ"),
        "tax": MessageLookupByLibrary.simpleMessage("কৰ"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("কৰ গোট"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("কৰ শতাংশ"),
        "taxRate": MessageLookupByLibrary.simpleMessage("কৰৰ হাৰ"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "কৰৰ হাৰ - আপোনাৰ কৰৰ হাৰ পৰিচালনা কৰক"),
        "taxReport": MessageLookupByLibrary.simpleMessage("কৰ প্রতিবেদন"),
        "taxType": MessageLookupByLibrary.simpleMessage("কৰৰ প্ৰকাৰ"),
        "taxes": MessageLookupByLibrary.simpleMessage("কৰ"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("শর্ত আৰু শর্তাবলী"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("ব্যৱহাৰৰ শর্তসমূহ"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("শর্ত আৰু গোপনীয়তা"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "আপোনাৰ মাকৰ পে\'মেন্টৰ বাবে ধন্যবাদ"),
        "thankYou": MessageLookupByLibrary.simpleMessage("ধন্যবাদ"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("আপোনাৰ ক্ৰয়ৰ বাবে ধন্যবাদ"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "এই ইমেইলৰ বাবে একাউণ্ট ইতিমধ্যে আছে"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Excel ফাইল আগতে ডাউনলোড কৰা হৈছে"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "নামেই সকলো কথাটো কয়। Pos SaaS POS Unlimitedৰ সৈতে, আপোনাৰ ব্যৱহাৰলৈ কোনো সীমা নাই। আপুনি কিছু লেনদেন প্ৰক্ৰিয়া কৰোঁ বা গ্ৰাহকৰ মেটাতোৰ ব্যৱহাৰ কৰা হলেও, আপোনাৰ নিশ্চয়তা থাকে যে আপুনি সীমাবদ্ধতাৰ দ্বাৰা সংকুচিত নহ\'ব।"),
        "thePasswordProvidedIsTooWeak":
            MessageLookupByLibrary.simpleMessage("দিয়া পাছৱাৰ্ড খুব দুর্বল"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "বিক্ৰী অপসাৰণ কৰা হ\'ব আৰু এই ক্ৰয়ৰ বিষয়ে সকলো তথ্য অপসাৰণ কৰা হ\'ব। আপুনি নিশ্চিত যে অপসাৰণ কৰিব?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "বিক্ৰী অপসাৰণ কৰা হ\'ব আৰু এই বিক্ৰীৰ বিষয়ে সকলো তথ্য অপসাৰণ কৰা হ\'ব। আপুনি নিশ্চিত যে অপসাৰণ কৰিব?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "ব্যৱহাৰকাৰী মচি পেলোৱা হ\'ব আৰু সকলো তথ্য আপোনাৰ একাউণ্টৰ পৰা মচি পেলোৱা হ\'ব। আপুনি কি এইটো মচি পেলাবলৈ নিশ্চিত?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "ব্যৱহাৰকাৰীটো মচি দিয়া হ\'ব আৰু আপোনাৰ একাউণ্টৰ পৰা সকলো তথ্য মচি দিয়া হ\'ব। আপুনি নিশ্চিত?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("তৃতীয়-পৰায়ণ সেৱাসমূহ"),
        "thisCategoryCannotBeDeleted":
            MessageLookupByLibrary.simpleMessage("এই শ্ৰেণী মচি পেলাব নোৱাৰি"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(এই মাহ)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "এই উৎপাদক ইতিমধ্যে যোগ কৰা হৈছে"),
        "title": MessageLookupByLibrary.simpleMessage("শিৰোনাম"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("শিৰোনাম খালী নোহোৱা উচিত"),
        "to": MessageLookupByLibrary.simpleMessage("লৈ"),
        "toDate": MessageLookupByLibrary.simpleMessage("তাৰিখলৈ"),
        "today": MessageLookupByLibrary.simpleMessage("আজিৰে"),
        "total": MessageLookupByLibrary.simpleMessage("মুঠ"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("মুঠ ৰাশি"),
        "totalCollected": MessageLookupByLibrary.simpleMessage("মুঠ সংগৃহীত"),
        "totalDue": MessageLookupByLibrary.simpleMessage("মুঠ মাকৰ"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("মুঠ ব্যয়"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("মুঠ ক্ষতি"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("মুঠ পৰিশোধ কৰিব লাগিব"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("মুঠ মূল্য"),
        "totalProducts": MessageLookupByLibrary.simpleMessage("মুঠ উৎপাদক"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("মুঠ লাভ"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("মুঠ ক্ৰয়"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("মুঠ উভতি পৰিমাণ"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("মুঠ উভতি"),
        "totalSale": MessageLookupByLibrary.simpleMessage("মুঠ বিক্ৰী"),
        "totalStock": MessageLookupByLibrary.simpleMessage("মুঠ ষ্টক"),
        "totalValue": MessageLookupByLibrary.simpleMessage("মুঠ মান"),
        "totalVat": MessageLookupByLibrary.simpleMessage("মুঠ ভ্যাট"),
        "totals": MessageLookupByLibrary.simpleMessage("মুঠ: "),
        "transaction": MessageLookupByLibrary.simpleMessage("লেনদেন"),
        "transactionId": MessageLookupByLibrary.simpleMessage("লেনদেন আইডি"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("পুনৰ চেষ্টা কৰক"),
        "twitter": MessageLookupByLibrary.simpleMessage("টুইটার"),
        "type": MessageLookupByLibrary.simpleMessage("প্ৰকাৰ"),
        "unitName": MessageLookupByLibrary.simpleMessage("এককৰ নাম"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("একক মূল্য"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("একক মূল্য"),
        "units": MessageLookupByLibrary.simpleMessage("একক"),
        "unlimited": MessageLookupByLibrary.simpleMessage("অসীম"),
        "unlimitedUsage": MessageLookupByLibrary.simpleMessage("অসীম ব্যৱহাৰ"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Pos SaaS POSৰ সম্পূৰ্ণ সম্ভাৱনা উন্মুক্ত কৰক ব্যক্তিগত প্ৰশিক্ষণ সেশ্যনৰে যাক আমাৰ বিশেষজ্ঞ দল নেতৃত্ব দিব। মূল বিষয়বোৰৰ পৰা উন্নত কৌশললৈ, আমি নিশ্চিত কৰো যে আপুনি ছিষ্টেমৰ প্ৰতিটো দিশ ব্যৱহাৰ কৰিবলৈ ভালকৈ জানিব।"),
        "unpaid": MessageLookupByLibrary.simpleMessage("অবৈতন"),
        "update": MessageLookupByLibrary.simpleMessage("আপডেট কৰক"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("যোগাযোগৰ তথ্য হালনাগাদ কৰক"),
        "updateNow":
            MessageLookupByLibrary.simpleMessage("এতিয়া হালনাগাদ কৰক"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("পণ্য হালনাগাদ কৰক"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "আপোনাৰ পৰিকল্পনা প্ৰথমে আপডেট কৰক,\\nআপোনাৰ সীমা অতিক্ৰম হৈছে"),
        "updateYourProfile": MessageLookupByLibrary.simpleMessage(
            "আপোনাৰ প্ৰ\'ফাইল হালনাগাদ কৰক"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "আপোনাৰ ডাক্তারৰ সৈতে ভাল প্ৰভাৱৰ বাবে আপোনাৰ প্ৰোফাইল আপডেট কৰক"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "উত্তম প্ৰতিমূৰ্তিৰ সৈতে গ্ৰাহকক সংযোগ কৰিবলৈ আপোনাৰ প্ৰ\'ফাইল হালনাগাদ কৰক"),
        "updated": MessageLookupByLibrary.simpleMessage("আপডেট কৰা হৈছে"),
        "upload": MessageLookupByLibrary.simpleMessage("আপলোড কৰক"),
        "uploadDocument": MessageLookupByLibrary.simpleMessage("নথি আপলোড কৰক"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("আপলোড সম্পন্ন"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("ফাইল আপলোড কৰক"),
        "upplier": MessageLookupByLibrary.simpleMessage("যোগান দাতা"),
        "usbC": MessageLookupByLibrary.simpleMessage("USB C"),
        "use": MessageLookupByLibrary.simpleMessage("ব্যৱহাৰ কৰক"),
        "useMobiPos":
            MessageLookupByLibrary.simpleMessage("পছ SaaS ব্যৱহাৰ কৰক"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("ছিষ্টেমৰ ব্যৱহাৰ"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("ব্যৱহাৰকাৰী মচি দিয়া হৈছে"),
        "userRole": MessageLookupByLibrary.simpleMessage("ব্যৱহাৰকাৰী ভূমিকা"),
        "userRoleDetails": MessageLookupByLibrary.simpleMessage(
            "ব্যৱহাৰকাৰী ভুমিকা বিস্তারিত"),
        "userTitle":
            MessageLookupByLibrary.simpleMessage("ব্যৱহাৰকাৰী শিৰোনাম"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "ব্যৱহাৰকাৰীৰ শিৰোনাম খালী হ\'ব নোৱাৰিব"),
        "value": MessageLookupByLibrary.simpleMessage("মান"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("ভ্যাট প্ৰযোজ্য নহয়"),
        "verifyOtp":
            MessageLookupByLibrary.simpleMessage("OTP পৰীক্ষা কৰা হৈছে"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("ফোন নম্বৰ পৰীক্ষা কৰক"),
        "viewAll": MessageLookupByLibrary.simpleMessage("সমূহ দেখুন"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("বিৱৰণ চাওক"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("ফুটপাথে গ্ৰাহক"),
        "warehouse": MessageLookupByLibrary.simpleMessage("গুদাম"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("গুদাম ইতিমধ্যে আছে"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("গুদামৰ তালিকা"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("গুদাম নাম"),
        "warranty": MessageLookupByLibrary.simpleMessage("গেৰেণ্টী"),
        "weHaveSendAnEmailwithInstructions":
            MessageLookupByLibrary.simpleMessage(
                "পাছৱৰ্ড ৰিছেট কৰিবলৈ নিৰ্দেশনাৰ সৈতে আমি এটি ইমেইল পঠিয়াইছে:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "আমরা আমাৰ ছিষ্টেমৰ কার্যক্ষমতা সমৰ্থন কৰিবলৈ তৃতীয়-পৰায়ণ সেৱাসমূহ ব্যৱহাৰ কৰিব পাৰো, যেনে বিশ্লেষণ প্ৰদানকাৰী আৰু পেমেন্ট প্ৰসেসৰ। এই তৃতীয়-পৰায়ণ সেৱাসমূহে আপোনাৰ ছিষ্টেম ব্যৱহাৰ কৰাৰ সময়ছোৱাত আপোনাৰ বিষয়ে তথ্য সংগ্ৰহ কৰিব পাৰে। অনুগ্ৰহ কৰি লক্ষ্য কৰক যে এই তৃতীয়-পৰায়ণ সেৱাসমূহৰ গোপনীয়তা প্ৰক্ৰিয়াৰ বাবে আমি দায়িত্বৱাহী নহয়।"),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "আমরা আপোনাৰ ব্যক্তিগত তথ্য সুৰক্ষিত কৰিবলৈ উদ্যোগ-মানৰ ব্যৱস্থা গ্ৰহণ কৰোঁ, যেনে এনক্ৰিপশ্যন আৰু সুৰক্ষিত সংৰক্ষণ। আমিও আপোনাৰ তথ্যৰ প্ৰৱেশক অনুমোদিত কৰ্মচাৰীৰ বাবে মাত্ৰ সীমাবদ্ধ কৰোঁ।"),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "আমরা নিৰবচ্ছিন্ন কার্যকলাপৰ গুৰুত্ব বুজো। সেইকাৰণে, আমাৰ ২৪/৭ সহায় উপলব্ধ হৈছে আপোনাক সহায় কৰিবলৈ, সেউজীয়া প্ৰশ্ন বা বিস্তৃত চিন্তা থাকিলেও। যিকোনো সময়ত, যিকোনো ঠাইত আমালৈ কল অথবা WhatsAppৰ মাধ্যমে সংযোগ কৰক যাতে অনন্য গ্ৰাহক সেৱাৰ অভিজ্ঞতা লাভ কৰিব পাৰে।"),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "আমরা আপোনাৰ ব্যক্তিগত তথ্য ব্যৱহাৰ কৰি আপোনাৰ বাবে সৰ্বশ্ৰেষ্ঠ অভিজ্ঞতা প্ৰদান কৰো, যেনে আপোনাৰ বিষয়বস্তুৰ সুপারিশ ব্যক্তিগতকৰণ, বিশেষজ্ঞৰ সৈতে সংযোগ স্থাপন কৰা, আৰু আমাৰ ছিষ্টেমৰ কার্যক্ষমতা উন্নত কৰা। আমিও আপুনি আপডেট, প্ৰচাৰ, বা আমাৰ ছিষ্টেমৰ সৈতে সম্পর্কিত অন্যান্য তথ্যৰ বিষয়ে আপোনাৰ সৈতে যোগাযোগ কৰিবলৈ আপোনাৰ তথ্য ব্যৱহাৰ কৰিব পাৰো।"),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "আমিয়ে পেমেন্ট পৰ্যালোচনা কৰিব আৰু ১-২ ঘণ্টাৰ ভিতৰত অনুমোদন কৰিব"),
        "weekly": MessageLookupByLibrary.simpleMessage("সাপ্তাহিক"),
        "weight": MessageLookupByLibrary.simpleMessage("ওজন"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("নতুন কি"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("হোলচে\'লাৰ"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("সামগ্ৰিক মূল্য"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("খুচুৰা মূল্য"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("থোক বেপাৰী"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("শীঘ্ৰে যোগ কৰা হ\'ব"),
        "willExpireAt":
            MessageLookupByLibrary.simpleMessage("এই সময়ত মেয়াদ শেষ হ\'ব"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("আপোনাৰ বাৰ্তা ইয়াত লিখক"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("ভুল OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "সেই ব্যৱহাৰকাৰীৰ বাবে ভুল পাছৱৰ্ড প্ৰদান কৰা হৈছে।"),
        "yearly": MessageLookupByLibrary.simpleMessage("বার্ষিক"),
        "yesDeleteForever": MessageLookupByLibrary.simpleMessage(
            "হয়, চিৰদিনৰ বাবে মচি পেলাওক"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("আপুনি বৈধ ব্যৱহাৰকাৰী নহয়"),
        "youAreUsing":
            MessageLookupByLibrary.simpleMessage("আপুনি ব্যৱহাৰ কৰি আছে"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "আপুনি মেচনৰকৈ বেছি পেমেণ্ট কৰিব নোৱাৰিব"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("আপোনাৰ এটি ইমেইল আহিছে"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "আপুনি সফলতাৰে আপোনাৰ একাউণ্টত লগ ইন কৰিছে। পছ ছাসৰ সৈতে থাকক।"),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("আপোনাক অনুমতি দিব লাগিব"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "আপোনাক আপোনাৰ একাউণ্টত পুনৰ লগইন কৰিব লাগিব।"),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "আপুনি ক্ৰয় কৰাৰ আগতে পৰিচয় প্ৰমাণীকৰণ কৰিব লাগিব"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("আপোনাৰ বাৰ্তা বাকী আছে"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("আপোনাৰ পেকেজ"),
        "yourPackageWillExpireinDay":
            MessageLookupByLibrary.simpleMessage("আপোনাৰ পেকেজ ৫ দিনত মুকলি হব")
      };
}
