// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a km locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'km';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("បន្ត"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("លេខ GST"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("តម្លៃលក់ធាតុពេញលេញ"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("MRP ត្រូវការពិត"),
        "OK": MessageLookupByLibrary.simpleMessage("យល់ព្រម"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("លេខទូរស័ព្ទ"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("កូដ SWIFT"),
        "Snacks": MessageLookupByLibrary.simpleMessage("អាហារសាមញ្ញ"),
        "TAX": MessageLookupByLibrary.simpleMessage("ពន្ធ"),
        "Uploading": MessageLookupByLibrary.simpleMessage("កំពុងផ្ទុក"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("ចំណងជើងអ្នកប្រើ"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "កញ្ចប់របស់អ្នកនឹងផុតកំណត់ថ្ងៃនេះ\n\nសូមទិញម្តងទៀត"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) The System is provided solely for the\npurpose of facilitating point of sale\ntransactions andrelatedactivities in your\nbusiness."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) To use the System, you may be\nrequired to create an account. You\nagree to provide accurate, current, and\ncomplete information during\nthe registration process and toupdate\nsuchinformationto keep itaccurate\nand complete."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("អំពីកម្មវិធី"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("អំពីពួកយើង"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Acceptance of Terms"),
        "accountName": MessageLookupByLibrary.simpleMessage("ឈ្មោះ គណនី"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("លេខ គណនី"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Account Registration"),
        "acton": MessageLookupByLibrary.simpleMessage("សកម្មភាព"),
        "add": MessageLookupByLibrary.simpleMessage("បន្ថែម"),
        "addBrand": MessageLookupByLibrary.simpleMessage("បន្ថែមម៉ាក"),
        "addCategory": MessageLookupByLibrary.simpleMessage("បន្ថែមប្រភេទ"),
        "addContact": MessageLookupByLibrary.simpleMessage("បន្ថែមទំនាក់ទំនង"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("បន្ថែមអតិថិជន"),
        "addDelivery":
            MessageLookupByLibrary.simpleMessage("បន្ថែមការដឹកជញ្ជូន"),
        "addDescriptioN": MessageLookupByLibrary.simpleMessage("បន្ថែមសង្ខេប"),
        "addDescription":
            MessageLookupByLibrary.simpleMessage("បន្ថែមកំណត់សម្គាល់"),
        "addDiscount":
            MessageLookupByLibrary.simpleMessage("បន្ថែមការបញ្ចុះតម្លៃ"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("បន្ថែមលេខសម្គាល់ឯកសារ"),
        "addDucument": MessageLookupByLibrary.simpleMessage("បន្ថែមឯកសារ"),
        "addExpense": MessageLookupByLibrary.simpleMessage("បន្ថែមចំណាយ"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("បន្ថែមប្រភេទចំណាយ"),
        "addItems": MessageLookupByLibrary.simpleMessage("បន្ថែមធាតុ"),
        "addNew": MessageLookupByLibrary.simpleMessage("បន្ថែមថ្មី"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("បន្ថែមអាសយដ្ឋានថ្មី"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("បន្ថែមផលិតផលថ្មី"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("បន្ថែមពន្ធថ្មី"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "បន្ថែមពន្ធថ្មីជាមួយពន្ធតែមួយ/ច្រើន"),
        "addNote": MessageLookupByLibrary.simpleMessage("បន្ថែមកំណត់ចំណាំ"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("សូមបន្ថែមផលិតផលមុន"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("បន្ថែមកូដការផ្សព្វផ្សាយ"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("បន្ថែមការទិញ"),
        "addSales": MessageLookupByLibrary.simpleMessage("បន្ថែមការលក់"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("បានបន្ថែមដោយ ជគជ័យ"),
        "addUnit": MessageLookupByLibrary.simpleMessage("បន្ថែមឯកតា"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("បានបន្ថែមដោយជោគជ័យ"),
        "addedToCart": MessageLookupByLibrary.simpleMessage("បានបន្ថែមទៅកុមរ"),
        "address": MessageLookupByLibrary.simpleMessage("អាសយដ្ឋាន"),
        "admin": MessageLookupByLibrary.simpleMessage("អ្នកគ្រប់គ្រង"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("ជំនួយអាជីវកម្មទាំងអស់"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("បានបន្ថែមរួចហើយ"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("មានរួចហើយ"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("មានគណនីរួចហើយ"),
        "amount": MessageLookupByLibrary.simpleMessage("ចំនួន"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "អ៊ីមែលបានផ្ញើហើយ។ សូមពិនិត្យប្រអប់អ៊ីមែលរបស់អ្នក"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "គាំទ្រកម្មវិធី Android & iOS"),
        "applicableTax": MessageLookupByLibrary.simpleMessage("ពន្ធអនុវត្ត"),
        "apply": MessageLookupByLibrary.simpleMessage("អនុវត្ត"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "តើអ្នកប្រាកដថាជាចង់លុបវិក្កយបត្រនេះទេ?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "តើអ្នកប្រាកដថាតើអ្នកចង់លុបការលក់នេះទេ?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "តើអ្នកប្រាកដថាចង់លុបអ្នកប្រើប្រាស់នេះទេ?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "តើអ្នកប្រាកដជាចង់លុបពន្ធនេះទេ?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "តើអ្នកប្រាកដជាចង់លុបក្រុមពន្ធនេះទេ?"),
        "areYouWantToDeleteThisWarehouse":
            MessageLookupByLibrary.simpleMessage("តើអ្នកចង់លុបឃ្លាំងនេះទេ?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "តើអ្នកប្រាកដជាចង់លុបអ្នកប្រើប្រាស់នេះមែនទេ?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("ហត្ថលេខាដែលមានអំណាច"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) You are responsible for\nmaintainingthe confidentiality of your\naccount and password andfor restricting\naccess to your account. You accept\nresponsibility for all activities that\noccur under your account."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) You must be at least 18 years old or the\nlegal age of majority in your jurisdiction to\nuse the System."),
        "backSide": MessageLookupByLibrary.simpleMessage("ខ្នាតក្រោយ"),
        "backToHome": MessageLookupByLibrary.simpleMessage("ត្រលប់ទៅទំព័រដើម"),
        "balance": MessageLookupByLibrary.simpleMessage("តុល្យភាព"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("បង់ក្លាដែស"),
        "bank": MessageLookupByLibrary.simpleMessage("ធនាគារ"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("ប្រាក់រូបិយប័ណ្ណគណនីធនាគារ"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("រូបិយប័ណ្ណគណនីធនាគារ"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("ព័ត៌មានធនាគារ"),
        "bankName": MessageLookupByLibrary.simpleMessage("ឈ្មោះ របស់ ធនាគារ"),
        "bankTransfer":
            MessageLookupByLibrary.simpleMessage("បញ្ជូនប្រាក់ធនាគារ"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("រកឃើញកូដអេឡិចត្រូនិច"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("វិក្កយបត្រ"),
        "billTo": MessageLookupByLibrary.simpleMessage("វិក្កយបត្រទៅ"),
        "branchName": MessageLookupByLibrary.simpleMessage("ឈ្មោះសាខា"),
        "brand": MessageLookupByLibrary.simpleMessage("ម៉ាក"),
        "brandName": MessageLookupByLibrary.simpleMessage("ឈ្មោះម៉ាក"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("បញ្ចូលតាមផ្ទាំងធំ"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("ប្រភេទអាជីវកម្ម"),
        "buy": MessageLookupByLibrary.simpleMessage("ទិញ"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("ទិញកញ្ចប់ពិសេស"),
        "buySms": MessageLookupByLibrary.simpleMessage("ទិញ SMS"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "By accessing or using the Point of Sale (POS) System (the \"System\") provided by [Your Company Name] (\"Company\"), you agree to be bound by these Terms of Use. If you do not agree to these Terms of Use, do not use the System."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) You are responsible for ensuring that your\naccess to and use of the System is in\ncompliance with all applicable laws and\nregulations."),
        "cacel": MessageLookupByLibrary.simpleMessage("បោះបង់"),
        "call": MessageLookupByLibrary.simpleMessage("ហៅ"),
        "callForEmergencySupport":
            MessageLookupByLibrary.simpleMessage("ហៅសម្រាប់ការជួយឱ្យប្រញាប់"),
        "camera": MessageLookupByLibrary.simpleMessage("កាមេរ៉ា"),
        "cancel": MessageLookupByLibrary.simpleMessage("បោះបង់"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("បោះបង់ផលិតផលទាំងអស់"),
        "capacity": MessageLookupByLibrary.simpleMessage("មានអានុភាព"),
        "card": MessageLookupByLibrary.simpleMessage("កាត"),
        "cash": MessageLookupByLibrary.simpleMessage("សាច់ប្រាក់"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("ប្រភេទ"),
        "category": MessageLookupByLibrary.simpleMessage("ប្រភេទ"),
        "categoryName": MessageLookupByLibrary.simpleMessage("ឈ្មោះក្រុម"),
        "categoryNameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("ឈ្មោះក្រុមមានរួចហើយ"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("ឈ្មោះប្រភេទ"),
        "change": MessageLookupByLibrary.simpleMessage("ផ្លាស់ប្តូរ?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("ប្តូរពាក្យសម្ងាត់"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("ពិនិត្យរូបសង្ឃឹម"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("ជ្រើសរើសអតិថិជន"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("ជ្រើសរើសអ្នកផ្គត់ផ្គង់"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("ជ្រើសរើសលក្ខណៈពិសេសរបស់អ្នក"),
        "clarence": MessageLookupByLibrary.simpleMessage("កាតានិយម"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("ចុចដើម្បីតភ្ជាប់"),
        "close": MessageLookupByLibrary.simpleMessage("បិទ"),
        "color": MessageLookupByLibrary.simpleMessage("ពណ៌"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(ការប្រមូលផ្ដុំរវាងពន្ធច្រើន)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("កំពុងមកដល់"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("អាសយដ្ឋានក្រុមហ៊ុន"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("ឈ្មោះក្រុមហ៊ុន និងហាង"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("ឈ្មោះក្រុមហ៊ុន និងអាជីវកម្ម"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("បញ្ចប់ការប្រតិបត្តិការ"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("បញ្ជាក់ពាក្យសម្ងាត់"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("បញ្ជាក់ការត្រឡប់"),
        "congratulations": MessageLookupByLibrary.simpleMessage("អបអរសាទរ"),
        "contactUs": MessageLookupByLibrary.simpleMessage("ទាក់ទង​មក​ពួក​យើង"),
        "continu": MessageLookupByLibrary.simpleMessage("បន្ត"),
        "country": MessageLookupByLibrary.simpleMessage("ប្រទេស"),
        "create": MessageLookupByLibrary.simpleMessage("បង្កើត"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("បង្កើតគណនីសំរាប់ឥតគិតថ្លៃ"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("បានបង្កើតនិងរក្សាទុក"),
        "currency": MessageLookupByLibrary.simpleMessage("រូបិយប័ណ្ណ"),
        "currentStock":
            MessageLookupByLibrary.simpleMessage("ស្តុកបច្ចុប្បន្ន"),
        "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
            "ការដាក់ស្លាកសញ្ញាវិក្កយបត្រផ្ទាល់ខ្លួន"),
        "customer": MessageLookupByLibrary.simpleMessage("អតិថិជន"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("ព័ត៌មានអតិថិជន"),
        "customerGST": MessageLookupByLibrary.simpleMessage("GST អតិថិជន"),
        "customerName": MessageLookupByLibrary.simpleMessage("ឈ្មោះអតិថិជន"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("ការប្រតិបត្តិទៅថ្ងៃរំលស់"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Dashboard Overview"),
        "dataSavedSuccessfully": MessageLookupByLibrary.simpleMessage(
            "ទិន្នន័យត្រូវបានរក្សាទុកដោយជោគជ័យ"),
        "date": MessageLookupByLibrary.simpleMessage("កាលបរិច្ឆេទ"),
        "day": MessageLookupByLibrary.simpleMessage("ថ្ងៃ"),
        "dealer": MessageLookupByLibrary.simpleMessage("អ្នកលក់ដុំ"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("តម្លៃកាលកំណើត"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("ភាគរយ VAT ដើម"),
        "delete": MessageLookupByLibrary.simpleMessage("លុប"),
        "deleting": MessageLookupByLibrary.simpleMessage("កំពុងលុប"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("អាសយដ្ឋានដឹកជញ្ជូន"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("អាស័យដ្ឋានដឹកជញ្ជូន"),
        "deliveryCharge": MessageLookupByLibrary.simpleMessage("ថ្លៃដឹកជញ្ជូន"),
        "describtion": MessageLookupByLibrary.simpleMessage("ការពិពណ៌នា"),
        "description": MessageLookupByLibrary.simpleMessage("ការពិពណ៌នា"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("ការពិពណ៌នាមិនអាចសូន្យ"),
        "details": MessageLookupByLibrary.simpleMessage("ព័ត៌មានលម្អិត"),
        "discount": MessageLookupByLibrary.simpleMessage("បញ្ចុះតម្លៃ"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("កុំបរិច្ឆេទចូល"),
        "done": MessageLookupByLibrary.simpleMessage("បានបញ្ចប់"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("ទាញយកទម្រង់ Excel"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "បានទាញយកដោយជោគជ័យនៅក្នុងថតទាញយក"),
        "due": MessageLookupByLibrary.simpleMessage("បំណុល"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("ចំនួនបំណុល: "),
        "dueCollection":
            MessageLookupByLibrary.simpleMessage("ការបំណុលប្រភេទកំណើតទេ"),
        "dueCollectionReports": MessageLookupByLibrary.simpleMessage(
            "របាយការណ៍ការបង់ប្រាក់កំពុងដំណើរការ"),
        "dueList": MessageLookupByLibrary.simpleMessage("បញ្ជីបំណុល"),
        "dueReports":
            MessageLookupByLibrary.simpleMessage("របាយការទូទាត់បំណុល"),
        "duration": MessageLookupByLibrary.simpleMessage("រយៈពេល"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("រយៈពេល៖ ពី"),
        "easyToUseMobilePos":
            MessageLookupByLibrary.simpleMessage("មធ្យោបាយទូរស័ព្ទល្មើសិន"),
        "edit": MessageLookupByLibrary.simpleMessage("កែប្រែ"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("កែសម្រួលវិក្កយបត្រការទិញ"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("កែសម្រួលវិក្កយបត្រការលក់"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("កែសម្រួលព័ត៌មានសាធារណៈ"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("កែប្រែបានជោគជ័យ"),
        "editTax": MessageLookupByLibrary.simpleMessage("កែប្រែពន្ធ"),
        "editTaxGroup": MessageLookupByLibrary.simpleMessage("កែប្រែក្រុមពន្ធ"),
        "editWarehouse": MessageLookupByLibrary.simpleMessage("កែប្រែឃ្លាំង"),
        "email": MessageLookupByLibrary.simpleMessage("អ៊ីម៉ែល"),
        "emailAddress":
            MessageLookupByLibrary.simpleMessage("អាស័យដ្ឋានអ៊ីម៉ែល"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("អ៊ីមែលមិនអាចទទេបានទេ"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "អ៊ីមែលបានផ្ញើ! សូមពិនិត្យប្រអប់អ៊ីមែលរបស់អ្នក"),
        "endDate": MessageLookupByLibrary.simpleMessage("កាលបរិច្ឆេទ​បញ្ចប់"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("សូមបញ្ចូលចំនួនដែលត្រឹមត្រូវ"),
        "enterAValidDiscount": MessageLookupByLibrary.simpleMessage(
            "បញ្ចូលការបញ្ចុះតម្លៃមានសុពលភាព"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "សូមបញ្ចូលលេខទូរស័ព្ទមួយដែលត្រឹមត្រូវ"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("បញ្ចូលតម្លៃដែលមានសុពលភាព"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("បញ្ចូលចំនួនដែលមានសុពលភាព"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("បញ្ចូលអាសយដ្ឋាន"),
        "enterAmount":
            MessageLookupByLibrary.simpleMessage("បញ្ចូលចំនួនទឹកប្រាក់។"),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("បញ្ចូលឈ្មោះម៉ាក"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("បញ្ចូលមានអានុភាព"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("បញ្ចូលឈ្មោះប្រភេទ"),
        "enterColor": MessageLookupByLibrary.simpleMessage("បញ្ចូលពណ៌"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "សូមបញ្ចូលលេខ GST របស់អតិថិជន"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("បញ្ចូលតម្លៃកាលកំណើត"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("បញ្ចូលការពិពណ៌នា"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("បញ្ចូលបញ្ចុះតម្លៃ។"),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("បញ្ចូលកាលបរិច្ឆេទចំណាយ"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("បញ្ចូលអាសយដ្ឋានពេញ"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("បញ្ចូលលេខវិក្កយបត្រ"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "បញ្ចូលបរិមាណការជូនដំណឹងស្តុកទាប"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("បញ្ចូលក្រុមហ៊ុនផលិត"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("បញ្ចូលមាតិការសារ"),
        "enterMrpOrRetailerPirce":
            MessageLookupByLibrary.simpleMessage("បញ្ចូលតម្លៃលក់ធាតុពេញលេញ"),
        "enterName": MessageLookupByLibrary.simpleMessage("បញ្ចូលឈ្មោះ"),
        "enterNote": MessageLookupByLibrary.simpleMessage("បញ្ចូលកំណត់សម្គាល់"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("បញ្ចូលឈ្មោះក្រុមហ៊ុន"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("បញ្ចូលលេខទូរស័ព្ទ"),
        "enterProductCodeOrScan":
            MessageLookupByLibrary.simpleMessage("បញ្ចូលលេខកូដផលិតផល ឬ ស្កេន"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("បញ្ចូលឈ្មោះផលិតផល"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("បញ្ចូលតម្លៃទិញ។"),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("បញ្ចូលលេខយោង"),
        "enterSize": MessageLookupByLibrary.simpleMessage("បញ្ចូលទំហំ"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("បញ្ចូលស្តុក។"),
        "enterTaxRate": MessageLookupByLibrary.simpleMessage("បញ្ចូលអត្រាពន្ធ"),
        "enterTransactionId": MessageLookupByLibrary.simpleMessage(
            "បញ្ចូលលេខសម្គាល់ប្រតិបត្តិការ"),
        "enterType": MessageLookupByLibrary.simpleMessage("បញ្ចូលប្រភេទ"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("បញ្ចូលចំណងជើងអ្នកប្រើ"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("សូមបញ្ចូលចំនួនដែលត្រឹមត្រូវ"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("បញ្ចូលឈ្មោះឃ្លាំង"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("បញ្ចូលទំងន់"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("បញ្ចូលតម្លៃដឹកជញ្ជូន"),
        "enterYourDescriptionHere": MessageLookupByLibrary.simpleMessage(
            "បញ្ចូលការពិពណ៌នារបស់អ្នកនៅទីនេះ"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "បញ្ចូលអាស័យដ្ឋានអ៊ីម៉ែលរបស់អ្នក"),
        "enterYourFeedBackTitle":
            MessageLookupByLibrary.simpleMessage("បញ្ចូលចំណងជើងយោបល់របស់អ្នក"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("សូមបញ្ចូលលេខ GST របស់អ្នក"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("បញ្ចូលលេខទូរសព្ទ"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("បញ្ចូលឈ្មោះរបស់អ្នក"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("បញ្ចូលលេខទូរស័ព្ទរបស់អ្នក"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("បញ្ចូលពាក្យសម្ងាត់របស់អ្នក"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("បញ្ចូលលេខទូរស័ព្ទរបស់អ្នក"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "បញ្ចូលលេខសម្គាល់ការប្រតិបត្តិការរបស់អ្នក"),
        "error": MessageLookupByLibrary.simpleMessage("កំហុស"),
        "excTax": MessageLookupByLibrary.simpleMessage("មិនរួមមានពន្ធ"),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("អ្នកបញ្ចូល Excel"),
        "exclusive": MessageLookupByLibrary.simpleMessage("បំបែក"),
        "expense": MessageLookupByLibrary.simpleMessage("ការចំណាយ"),
        "expenseCategory": MessageLookupByLibrary.simpleMessage("ប្រភេទចំណាយ"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("កាលបរិច្ឆេទចំណាយ"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("ចំណាយសម្រាប់"),
        "expenseReport": MessageLookupByLibrary.simpleMessage("របាយការណ៍ចំណាយ"),
        "expireDate":
            MessageLookupByLibrary.simpleMessage("កាលបរិច្ឆេទផុតកំណត់"),
        "expired": MessageLookupByLibrary.simpleMessage("ផុតកំណត់"),
        "expiring": MessageLookupByLibrary.simpleMessage("នឹងផុតកំណត់"),
        "facebok": MessageLookupByLibrary.simpleMessage("ហ្វេសប៊ុក"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("បានបរាជ័យជាមួយកំហុស"),
        "fashion": MessageLookupByLibrary.simpleMessage("ស្ថាបត្យករ"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "លក្ខណៈពិសេសជាផ្នែកសំខាន់ដែលធ្វើឱ្យ Pos Saas  ខូចទុកពីការដោះស្រាយប្រើលក្ខណៈពិសេសចាប់ពីដំណោះស្រាយធម្មជាតិ។"),
        "feedBack": MessageLookupByLibrary.simpleMessage("មតិអ្នកផ្តល់យោបល់"),
        "firstName": MessageLookupByLibrary.simpleMessage("នាមខ្លួន"),
        "followUsOnFacebook": MessageLookupByLibrary.simpleMessage(
            "អនុវត្តឱ្យយើងនៅលើ\nហ្វេសប៊ុក"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("អនុវត្តឱ្យយើងនៅលើ\nទ្វីត"),
        "fontSide": MessageLookupByLibrary.simpleMessage("ខ្នាតពីមុខ"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("សម្រាប់ការប្រើចំនួនមិនកំណត់"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("ភ្លេចពាក្យសំងាត់"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("ភ្លេចពាក្យសំងាត់?"),
        "formDate": MessageLookupByLibrary.simpleMessage("ពីកាលបរិច្ឆេទ"),
        "freeDataBackup": MessageLookupByLibrary.simpleMessage(
            "ការបម្រុងទុកទិន្នន័យឥតគិតថ្លៃ"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "ការធ្វើបច្ចុប្បន្ន អារម្មណ៍ សរុបដោយឥតគិតថ្លៃ"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("កញ្ចប់ឥតគិតថ្លៃ"),
        "freePlan": MessageLookupByLibrary.simpleMessage("កម្មវិធីឥតគិតថ្លៃ"),
        "from": MessageLookupByLibrary.simpleMessage("(ពី"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("បានបង់ប្រាក់ពេញ"),
        "gallary": MessageLookupByLibrary.simpleMessage("រូបភាព"),
        "generatingPDF":
            MessageLookupByLibrary.simpleMessage("កំពុងបង្កើត PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("ទទួល OTP"),
        "govermentId":
            MessageLookupByLibrary.simpleMessage("អត្តសញ្ញាណប័ណ្ណរដ្ឋ"),
        "guest": MessageLookupByLibrary.simpleMessage("ភ្ញៀវ"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("មិនមានគណនីទេ?"),
        "history": MessageLookupByLibrary.simpleMessage("ប្រវត្តិ"),
        "home": MessageLookupByLibrary.simpleMessage("ទំព័រដើម"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "How We Protect Your Information"),
        "howWeUseYourInformation":
            MessageLookupByLibrary.simpleMessage("How We Use Your Information"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("ផ្ទៀងផ្ទាត់ការសម្គាល់"),
        "image": MessageLookupByLibrary.simpleMessage("រូបភាព"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("ក្នុងបន្ទប់មិនអាចលុបបាន"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("ក្នុងបន្ទប់មិនអាចកែប្រែបាន"),
        "inWord": MessageLookupByLibrary.simpleMessage("នៅក្នុងពាក្យ"),
        "incTax": MessageLookupByLibrary.simpleMessage("រួមមានពន្ធ"),
        "inclusive": MessageLookupByLibrary.simpleMessage("រួមបញ្ចូល"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("បន្ថែមស្តុក"),
        "inistrument": MessageLookupByLibrary.simpleMessage("ឧបករណ៍"),
        "instragram": MessageLookupByLibrary.simpleMessage("អង្គរាំង"),
        "invNo": MessageLookupByLibrary.simpleMessage("លេខវិក្កយបត្រ"),
        "invoice": MessageLookupByLibrary.simpleMessage("វិក័យប័ត្រ"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("លេខវិក្កយបត្រ"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("ការកំណត់វិក្កយបត្រ"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("អ្នកមើលវិក័យប័ត្រ"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("ធាតុត្រឡប់ចូល"),
        "kg": MessageLookupByLibrary.simpleMessage("គីឡូក្រាម"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("ការផ្ទៀងផ្ទាត់ KYC"),
        "language": MessageLookupByLibrary.simpleMessage("ភាសា"),
        "lastName": MessageLookupByLibrary.simpleMessage("នាមត្រកូល"),
        "ledger": MessageLookupByLibrary.simpleMessage("ទិន្នន័យប័ណ្ណ"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("ទិញរយៈពេលឆាប់ៗ"),
        "link": MessageLookupByLibrary.simpleMessage("តំណ"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("បង្កើតឥតគិតថ្លៃ"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("ការគាំទ្រជាតិការផ្ទាល់"),
        "loading": MessageLookupByLibrary.simpleMessage("កំពុងផ្ទុក"),
        "logIn": MessageLookupByLibrary.simpleMessage("ចូល"),
        "logOUt": MessageLookupByLibrary.simpleMessage("ចាកចេញ"),
        "logOut": MessageLookupByLibrary.simpleMessage("ចាកចេញ"),
        "login": MessageLookupByLibrary.simpleMessage("ចូល"),
        "logo": MessageLookupByLibrary.simpleMessage("រូបសញ្ញា"),
        "loss": MessageLookupByLibrary.simpleMessage("ប្រាក់ចំណាញ"),
        "lossOrProfit":
            MessageLookupByLibrary.simpleMessage("ការចំណាញ / ប្រាក់ចំណាញ"),
        "lossOrProfitDetails": MessageLookupByLibrary.simpleMessage(
            "ព័ត៌មានលំអិតការចំណាញ / ប្រាក់ចំណាញ"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("របាយការណ៍ខាត/ផល"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("របាយការណ៍ខាត/ផល"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("ការជូនដំណឹងស្តុកទាប"),
        "maan": MessageLookupByLibrary.simpleMessage("មាន"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "ធ្វើឱ្យមានការចាប់អារម្មណ៍យូរអង្វែងលើអតិថិជនរបស់អ្នកជាមួយនឹងវិក្កយបត្រដែលមានម៉ាក។ ការអាប់ដេតគ្មានដែនកំណត់របស់យើងផ្តល់នូវអត្ថប្រយោជន៍ពិសេសនៃការកែប្រែវិក្កយបត្ររបស់អ្នកតាមបំណង ដោយបន្ថែមការប៉ះប្រកបដោយវិជ្ជាជីវៈដែលពង្រឹងអត្តសញ្ញាណម៉ាករបស់អ្នក និងជំរុញភាពស្មោះត្រង់របស់អតិថិជន។"),
        "manageYourBussinessWith": MessageLookupByLibrary.simpleMessage(
            "គ្រប់គ្រងអាជីវកម្មរបស់អ្នកជាមួយ"),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("កាលបរិច្ឆេទផលិត"),
        "margin": MessageLookupByLibrary.simpleMessage("ស្នង"),
        "masterCard": MessageLookupByLibrary.simpleMessage("កាតឥណទាន"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("ក្រុមហ៊ុនផលិត"),
        "message": MessageLookupByLibrary.simpleMessage("សារ"),
        "messageHistory": MessageLookupByLibrary.simpleMessage("ប្រវត្តិសារ"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "កម្មវិធី Pos Saas គឺឥតគិតថ្លៃ និងមានការប្រើយន្តជាធម្មជាតិល្អ។ ជាកូនទៅកាន់ប្រព័ន្ធបញ្ជារចូលទៅទូរស័ព្ទលើពិភពពីរប៉ាក់ស្រីនៅក្នុងពិភពពិសោធន៍នៅក្នុងព័ត៌មានជាបន្តរកម្មបច្ចេកទេសទៅលើពិភពពិសោធន៍តាមតម្រូវការសហគមន៍។"),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "កម្មវិធី Pos Saas គឺជំនួយអាជីវកម្មព័ត៌មានដើម្បីកន្លងមែននៅក្នុងអស់ការជ្រើសរើសពិភពពិសោធន៍របស់អ្នក។"),
        "mobile": MessageLookupByLibrary.simpleMessage("ទូរស័ព្ទចល័ត"),
        "mobilePayment":
            MessageLookupByLibrary.simpleMessage("បង់ប្រាក់ទូរស័ព្ទចល័ត"),
        "monthly": MessageLookupByLibrary.simpleMessage("ប្រចាំខែ"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("ព័ត៌មានបន្ថែម"),
        "name": MessageLookupByLibrary.simpleMessage("បញ្ចូលឈ្មោះរបស់អ្នក។"),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("ឈ្មោះមានរួចហើយ"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("ឈ្មោះមិនអាចទទេ"),
        "next": MessageLookupByLibrary.simpleMessage("បន្ទាប់"),
        "noConnection": MessageLookupByLibrary.simpleMessage("គ្មានការតភ្ជាប់"),
        "noData": MessageLookupByLibrary.simpleMessage("គ្មានទិន្នន័យ"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("មិនមានទិន្នន័យទេ"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("មិនមានទិន្នន័យអ្វីមួយទេ"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("រកមិនឃើញប្រវត្តិសារ!"),
        "noProductFound": MessageLookupByLibrary.simpleMessage("មិនមានផលិតផល"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("មិនមានពន្ធរងបានជ្រើស"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("រកមិនឃើញប្រតិបត្តិការ!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "រកមិនឃើញអ្នកប្រើប្រាស់សម្រាប់អ៊ីម៉ែលនេះទេ។"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("អ្នកប្រើមិនមានសកម្មភាព"),
        "notProvided": MessageLookupByLibrary.simpleMessage("មិនបានផ្តល់"),
        "note": MessageLookupByLibrary.simpleMessage("ចំណាំ"),
        "notes": MessageLookupByLibrary.simpleMessage("កំណត់ចំណាំ"),
        "notification": MessageLookupByLibrary.simpleMessage("ការជូនដំណឹង"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP បានផ្ញើទៅ"),
        "office": MessageLookupByLibrary.simpleMessage("ការិយាល័យ"),
        "ok": MessageLookupByLibrary.simpleMessage("ព្រម"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS that contains a great deal of functionality, including sales tracking, inventory management."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "This system helps you improve your operations for your customers."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Our POS system should simplify daily operations automatically, making it easy to navigate."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("សមតុល្យការចាប់ផ្ដើម"),
        "order": MessageLookupByLibrary.simpleMessage("បញ្ជាទិញ"),
        "other": MessageLookupByLibrary.simpleMessage("ផ្សេងទៀត"),
        "otp": MessageLookupByLibrary.simpleMessage("បិទ"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("ស្តុកអស់"),
        "pacakge": MessageLookupByLibrary.simpleMessage("កញ្ចប់"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("លក្ខណៈពិសេសកញ្ចប់"),
        "paid": MessageLookupByLibrary.simpleMessage("បង់ប្រាក់"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("ចំនួនបង់ប្រាក់"),
        "parties": MessageLookupByLibrary.simpleMessage("បញ្ជីឈ្មោះ"),
        "partiesList": MessageLookupByLibrary.simpleMessage("បញ្ជីឈ្មោះ"),
        "partyGST": MessageLookupByLibrary.simpleMessage("លេខ GST នៃភាគី"),
        "partyName": MessageLookupByLibrary.simpleMessage("ឈ្មោះក្រុមហ៊ុន"),
        "password": MessageLookupByLibrary.simpleMessage("ពាក្យសំងាត់"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "ពាក្យសម្ងាត់ និងពាក្យសម្ងាត់ដែលអនុម័តមិនគ្នា"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("ពាក្យសម្ងាត់មិនអាចទទេបានទេ"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("ពាក្យសម្ងាត់មិនត្រូវគ្នា"),
        "payCash": MessageLookupByLibrary.simpleMessage("ទូទាត់បាត់"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash": MessageLookupByLibrary.simpleMessage("បង់ជាមួយ bKash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("បង់ជាមួយ Paypal"),
        "payeeName": MessageLookupByLibrary.simpleMessage("ឈ្មោះអ្នកទទួល"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("លេខទទួល"),
        "payment": MessageLookupByLibrary.simpleMessage("ការទូទាត់"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("ចំនួនការទូទាត់"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("បញ្ចប់ការទូទាត់"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("ការណែនាំការទូទាត់:"),
        "paymentMethod":
            MessageLookupByLibrary.simpleMessage("វិធីសាស្រ្តបង់ប្រាក់"),
        "paymentType":
            MessageLookupByLibrary.simpleMessage("ប្រភេទការបង់ប្រាក់"),
        "pdfView": MessageLookupByLibrary.simpleMessage("មើល PDF"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("ព័ត៌មានផ្ទាល់ខ្លួន"),
        "phone": MessageLookupByLibrary.simpleMessage("ទូរស័ព្ទ"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("លេខទូរស័ព្ទ"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "លេខទូរស័ព្ទបានប្រើប្រាស់រួចហើយ"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("លេខទូរស័ព្ទមិនត្រឹមត្រូវ"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("លេខទូរស័ព្ទត្រូវការព័ត៌មាន"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("ជ្រើសរើសនិងបញ្ចូលឯកសារ"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("ជ្រើសរើសកាលបរិច្ឆេទ​បញ្ចប់"),
        "pickStartDate": MessageLookupByLibrary.simpleMessage(
            "ជ្រើសរើសកាលបរិច្ឆេទ​ចាប់ផ្តើម"),
        "plan": MessageLookupByLibrary.simpleMessage("ផែនការ"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("សូមបន្ថែមបរិមាណ"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "សូមពិនិត្យការភ្ជាប់អ៊ីនធឺណិតរបស់អ្នក"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "សូមភ្ជាប់ម៉ាស៊ីនបោះពុម្ពជាមុន"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "សូមភ្ជាប់ម៉ាស៊ីនបោះពុម្ព Bluetooth របស់អ្នក"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "សូមបញ្ចូលពាក្យសម្ងាត់មួយដែលធំជាងនេះ"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "សូមបញ្ចូលពាក្យសម្ងាត់ការបញ្ជាក់"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("សូមបញ្ចូលពាក្យសំងាត់"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "សូមបញ្ចូលអ៊ីមែលមួយដែលត្រឹមត្រូវ"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("សូមបញ្ចូលឈ្មោះ"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("សូមបញ្ចូលពាក្យសម្ងាត់"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "សូមបញ្ចូលអាស័យដ្ឋានអ៊ីម៉ែលរបស់អ្នកនៅខាងក្រោមដើម្បីទទួលតែតំណលសំងាត់ឡើងវិញ។"),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "សូមបញ្ចូលលេខប្រតិបត្តិការនេះ"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("សូមបញ្ចូលចំនួន"),
        "pleaseSelectACategoryFirst":
            MessageLookupByLibrary.simpleMessage("សូមជ្រើសប្រភេទមុន"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("សូមជ្រើសរើសផែនការ"),
        "pleaseSelectBusinessCategory":
            MessageLookupByLibrary.simpleMessage("សូមជ្រើសជួរប្រភេទអាជីវកម្ម"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "សូមប្រើកូដទិញដែលមានសុពលភាពដើម្បីប្រើកម្មវិធី"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("ដោយអនុញ្ញាតិដោយ Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("ចេញពី"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("គាំទ្រអតិថិជនចូល"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("កម្មវិធីពិសេស"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("ចំនួនទូទាត់មុន"),
        "price": MessageLookupByLibrary.simpleMessage("តម្លៃ"),
        "print": MessageLookupByLibrary.simpleMessage("បោះពុម្ព"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("ជម្រើសបោះពុម្ព"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("គោលការណ៍ ភាព ឯកជន"),
        "product": MessageLookupByLibrary.simpleMessage("ផលិតផល"),
        "productCode": MessageLookupByLibrary.simpleMessage("លេខកូដផលិតផល"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("កូដផលិតផលត្រូវការពិត"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("កូដ/ឈ្មោះផលិតផល"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("ការពិពណ៌នាផលិតផល"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("ព័ត៌មានលម្អិតផលិតផល"),
        "productList": MessageLookupByLibrary.simpleMessage("បញ្ជីផលិតផល"),
        "productName": MessageLookupByLibrary.simpleMessage("ឈ្មោះផលិតផល"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "ឈ្មោះផលិតផលមាននៅក្នុង Depo នេះរួចហើយ"),
        "productNameIsAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("ឈ្មោះផលិតផលបានបន្ថែមរួចហើយ"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("ឈ្មោះផលិតផលត្រូវការពិត"),
        "products": MessageLookupByLibrary.simpleMessage("ផលិតផល"),
        "profile": MessageLookupByLibrary.simpleMessage("ទម្រង់"),
        "profit": MessageLookupByLibrary.simpleMessage("ប្រាក់ចំណាញ"),
        "promo": MessageLookupByLibrary.simpleMessage("ប៉ូតុក"),
        "promoCode": MessageLookupByLibrary.simpleMessage("លេខកូដបញ្ចុះតម្លៃ"),
        "purchase": MessageLookupByLibrary.simpleMessage("ការទិញ"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage("មានបញ្ជូនទំនិញ"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("បញ្ជាក់ទិញទំនិញ"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("ព័ត៌មានការទិញ"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("វិក្កយបត្រទិញ"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("បញ្ជីការទិញ"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("ទិញឥឡូវ"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("ទិញកញ្ចប់ពិសេស"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("តម្លៃទិញ"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("តម្លៃទិញត្រូវការពិត"),
        "purchaseRepoet": MessageLookupByLibrary.simpleMessage("របាយការទិញ"),
        "purchaseReports": MessageLookupByLibrary.simpleMessage("របាយការទិញ"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("របាយការណ៍ការទិញ"),
        "purchaseReturn": MessageLookupByLibrary.simpleMessage("ការបង្វិលទិញ"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("របាយការណ៍សងវិក្កយបត្រ"),
        "purchaseTransition": MessageLookupByLibrary.simpleMessage("បញ្ចីទិញ"),
        "qty": MessageLookupByLibrary.simpleMessage("បរិមាណ"),
        "quantity": MessageLookupByLibrary.simpleMessage("បរិមាណ"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("ប្រតិបត្តការថ្មីៗ"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("បានទទួលលេខកូដ PIN"),
        "referenceNumber": MessageLookupByLibrary.simpleMessage("លេខយោង"),
        "register": MessageLookupByLibrary.simpleMessage("ចុះឈ្មោះ"),
        "registering": MessageLookupByLibrary.simpleMessage("កំពុងចុះឈ្មោះ"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("បំណុលនៅសល់"),
        "remove": MessageLookupByLibrary.simpleMessage("យកចេញ"),
        "reports": MessageLookupByLibrary.simpleMessage("របាយការណ៍"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("សំណើបានផ្ញើ"),
        "resendCode": MessageLookupByLibrary.simpleMessage("ផ្ញើរកូដឡើងវិញ"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("ផ្ញើរ OTP ឡើងវិញ: "),
        "retailer": MessageLookupByLibrary.simpleMessage("អ្នកលក់រាយ"),
        "retur": MessageLookupByLibrary.simpleMessage("ត្រឡប់វិញ"),
        "returN": MessageLookupByLibrary.simpleMessage("ត្រឡប់"),
        "returnAMount":
            MessageLookupByLibrary.simpleMessage("ចំនួនទឹកប្រាក់ត្រឡប់វិញ"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("ចំនួនត្រឡប់វិញ"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("បរិមាណត្រឡប់"),
        "revenue": MessageLookupByLibrary.simpleMessage("ប្រាក់ចំណូល"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "ការពារទិន្នន័យអាជីវកម្មរបស់អ្នកដោយមិនពិបាក។ Pos Saas POS Unlimited Upgrade របស់យើងរួមបញ្ចូលទាំងការបម្រុងទុកទិន្នន័យដោយឥតគិតថ្លៃ ដោយធានាថាព័ត៌មានដ៏មានតម្លៃរបស់អ្នកត្រូវបានការពារប្រឆាំងនឹងព្រឹត្តិការណ៍ដែលមិនបានមើលឃើញទុកជាមុនណាមួយ។ ផ្តោតលើអ្វីដែលសំខាន់ - កំណើនអាជីវកម្មរបស់អ្នក។"),
        "saleAmount": MessageLookupByLibrary.simpleMessage("ចំនួនលក់"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("ព័ត៌មានការលក់"),
        "salePrice": MessageLookupByLibrary.simpleMessage("តម្លៃលក់"),
        "saleReports": MessageLookupByLibrary.simpleMessage("របាយការលក់"),
        "saleReportss": MessageLookupByLibrary.simpleMessage("របាយការណ៍ការលក់"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("សងការលក់"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("របាយការណ៍សងការលក់"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("កំណត់ការលក់"),
        "sales": MessageLookupByLibrary.simpleMessage("ការលក់"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("Sale & Purchase Reports"),
        "salesList": MessageLookupByLibrary.simpleMessage("បញ្ជីការលក់"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("ការសងការលក់"),
        "save": MessageLookupByLibrary.simpleMessage("រក្សាទុក"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("រក្សាទុកនិងបោះពុម្ព"),
        "saveChanges":
            MessageLookupByLibrary.simpleMessage("រក្សាទុកការផ្លាស់ប្ដូរ"),
        "saving": MessageLookupByLibrary.simpleMessage("ការកូន"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("ស្កេន QR code ផលិតផល"),
        "search": MessageLookupByLibrary.simpleMessage("ស្វែងរក"),
        "searchByProductCodeOrName":
            MessageLookupByLibrary.simpleMessage("ស្វែងរកតាមកូដឬឈ្មោះផលិតផល"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("មើលលេខកូដបញ្ចុះតម្លៃទាំងអស់"),
        "select": MessageLookupByLibrary.simpleMessage("ជ្រើសរើស"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "សូមជ្រើសរើសផលិតផលសម្រាប់ត្រឡប់"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("ជ្រើសម៉ាក"),
        "selectCategory": MessageLookupByLibrary.simpleMessage("ជ្រើសប្រភេទ"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("ជ្រើសរើសទំនាក់ទំនង"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("ជ្រើសប្រភេទផលិតផល"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("ជ្រើសប្រភេទហាង"),
        "selectTax": MessageLookupByLibrary.simpleMessage("ជ្រើសពន្ធ"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("ជ្រើសប្រភេទពន្ធ"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("ជ្រើសឯកតា"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("ជ្រើសរើសការផ្លាស់ប្តូរ: "),
        "seller": MessageLookupByLibrary.simpleMessage("អ្នកលក់"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("លក់ដោយ"),
        "send": MessageLookupByLibrary.simpleMessage("ផ្ញើ"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("ផ្ញើអ៊ីមែល"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("ផ្ញើសារ"),
        "sendResetLink": MessageLookupByLibrary.simpleMessage("ផ្ញើតំណឡើងវិញ"),
        "sendSms":
            MessageLookupByLibrary.simpleMessage("ផ្ញើសារចូលទៅសារុកចិត្ត"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("ផ្ញើ SMS?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("ផ្ញើសារប្រព័ន្ធWhatsapp"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("ផ្ញើអ៊ីមែលរបស់អ្នក"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage("កំពុងផ្ញើអ៊ីមែល"),
        "sendingMessage": MessageLookupByLibrary.simpleMessage("កំពុងផ្ញើសារ"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("សេវាកម្ម/ការដឹកជញ្ជូន"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("កំណត់រូបសង្ខេបរបស់អ្នក"),
        "setting": MessageLookupByLibrary.simpleMessage("ការកំណត់"),
        "share": MessageLookupByLibrary.simpleMessage("ចែករំលែក"),
        "shopGST": MessageLookupByLibrary.simpleMessage("លេខ GST របស់ហាង"),
        "signIn": MessageLookupByLibrary.simpleMessage("ចុះឈ្មោះ"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("ចុះឈ្មោះជាមួយអ៊ីមែល"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("ហត្ថលេខារបស់អតិថិជន"),
        "size": MessageLookupByLibrary.simpleMessage("ទំហំ"),
        "skip": MessageLookupByLibrary.simpleMessage("រំលង"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("ចែករំលែកអំពីផលិតផលតាមតម្លៃ"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "សូមអភ័យទោស, អ្នកមិនមានសិទ្ធិចូលដំណើរការទៅកាន់សេវាអនុស្សាវរីយ៍នេះទេ"),
        "startDate":
            MessageLookupByLibrary.simpleMessage("កាលបរិច្ឆេទ​ចាប់ផ្តើម"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("ចាប់ផ្តើមការលក់ថ្មី"),
        "startTypingToSearch":
            MessageLookupByLibrary.simpleMessage("ចាប់ផ្ដើមវាស្វែងរក"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "ស្ថិត នៅជួរ មុខ នៃការរីក ចម្រើន ផ្នែក បច្ចេកវិទ្យា ដោយ មិនមាន ការ ចំណាយ បន្ថែម អ្វី ឡើយ។ Pos Saas POS Unlimited Upgrade របស់យើងធានាថាអ្នកតែងតែមានឧបករណ៍ និងមុខងារចុងក្រោយបំផុតនៅចុងម្រាមដៃរបស់អ្នក ដោយធានាថាអាជីវកម្មរបស់អ្នកនៅតែទំនើបទាន់សម័យ។"),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("នៅតែអត់បានបង់"),
        "stock": MessageLookupByLibrary.simpleMessage("ស្តុក"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("ស្តុកត្រូវការពិត"),
        "stockList": MessageLookupByLibrary.simpleMessage("បញ្ជីស្តុក"),
        "stocks": MessageLookupByLibrary.simpleMessage("ស្តុក"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "សិទ្ធិការផ្ទុកត្រូវការសម្រាប់បង្កើតឯកសារ Excel"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("បញ្ជីពន្ធរង"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("ពន្ធរង"),
        "subTotal": MessageLookupByLibrary.simpleMessage("សរុបរង"),
        "submit": MessageLookupByLibrary.simpleMessage("ដាក់ស្នើ"),
        "subscribeToOurYoutube":
            MessageLookupByLibrary.simpleMessage("ជាវមកកាន់\nយូធូបរបស់យើង"),
        "subscription": MessageLookupByLibrary.simpleMessage("ការជាវ"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("បានបញ្ចប់ដោយជោគជ័យ"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("ចាកចេញដោយជោគជ័យ"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("បានធ្វើបច្ចុប្បន្នភាពជោគជ័យ"),
        "supplier": MessageLookupByLibrary.simpleMessage("អ្នកផ្គត់ផ្គង់"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("ឈ្មោះអ្នកផ្គត់ផ្គង់"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("លេខ កូដ រហ័ស"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "យករូបភាពអានឡើងវិញមានសញ្ញារបស់គុណប៉ាក់ស្រីឬរូបភាពប័ណ្ណអត្តសញ្ញារដ្ឋឬរូបភាពលិខិតប៉ុណ្ណោះ"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "ទាញរូបសញ្ញាប័ណ្ណប្រើដើម្បីពិនិត្យព័ត៌មានរបស់អ្នក"),
        "tap": MessageLookupByLibrary.simpleMessage("ចុច"),
        "tax": MessageLookupByLibrary.simpleMessage("ពន្ធ"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("ក្រុមពន្ធ"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("ភាគរយពន្ធ"),
        "taxRate": MessageLookupByLibrary.simpleMessage("អត្រាពន្ធ"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "អត្រាពន្ធ - គ្រប់គ្រងអត្រាពន្ធរបស់អ្នក"),
        "taxReport": MessageLookupByLibrary.simpleMessage("របាយការណ៍ពន្ធ"),
        "taxType": MessageLookupByLibrary.simpleMessage("ប្រភេទពន្ធ"),
        "taxes": MessageLookupByLibrary.simpleMessage("ពន្ធ"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("កណ្តាល និងលក្ខខណ្ឌ"),
        "termsOfUse":
            MessageLookupByLibrary.simpleMessage("ល័ក្ខខ័ណ្ឌនៃការប្រើប្រាស់"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("ល័ក្ខខ័ណ្ឌ និងភាពឯកជន"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "អរគុណចំពោះការទូទាត់បំណុលរបស់អ្នក"),
        "thankYou": MessageLookupByLibrary.simpleMessage("សូមអរគុណ"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("អរគុណចំពោះការទិញរបស់អ្នក"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "គណនីមានរួចហើយសម្រាប់អ៊ីមែលនោះ"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "ឯកសារ Excel ត្រូវបានទាញយករួចហើយ"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "ឈ្មោះនិយាយទាំងអស់។ ជាមួយនឹង Pos Saas POS Unlimited វាមិនមានដែនកំណត់លើការប្រើប្រាស់របស់អ្នកទេ។ មិនថាអ្នកកំពុងដំណើរការប្រតិបត្តិការមួយក្តាប់តូច ឬជួបប្រទះនឹងការប្រញាប់ប្រញាល់របស់អតិថិជននោះទេ អ្នកអាចធ្វើប្រតិបត្តិការដោយទំនុកចិត្ត ដោយដឹងថាអ្នកមិនត្រូវបានរឹតបន្តឹងដោយដែនកំណត់"),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "ពាក្យសម្ងាត់ដែលផ្ដល់មានខ្សែរខ្សោយពេក"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "ការលក់នឹងត្រូវបានលុប និងទិន្នន័យទាំងអស់នឹងត្រូវលុបអំពីការទិញនេះ។ តើអ្នកប្រាកដថាជាចង់លុបមែនទេ?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "ការលក់នឹងត្រូវបានលុប និងទិន្នន័យទាំងអស់នឹងត្រូវបានលុប។ តើអ្នកប្រាកដថាដែលអ្នកចង់លុបវាទេ?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "អ្នកប្រើនឹងត្រូវបានលុបហើយទិន្នន័យទាំងអស់នឹងត្រូវបានលុបពីគណនីរបស់អ្នក។ តើអ្នកប្រាកដចង់លុបវានៅដែរទេ?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "អ្នកប្រើប្រាស់នឹងត្រូវលុប និងទិន្នន័យទាំងអស់នឹងត្រូវលុបចេញពីគណនីរបស់អ្នក។ តើអ្នកប្រាកដថាចង់លុបវាទេ?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Third-Party Services"),
        "thisCategoryCannotBeDeleted":
            MessageLookupByLibrary.simpleMessage("ក្រុមនេះមិនអាចលុបបាន"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(ខែនេះ)"),
        "thisProductAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("ផលិតផលនេះបានបន្ថែមរួចហើយ"),
        "title": MessageLookupByLibrary.simpleMessage("ចំណងជើង"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("ចំណងជើងមិនអាចសូន្យ"),
        "to": MessageLookupByLibrary.simpleMessage("ដល់"),
        "toDate": MessageLookupByLibrary.simpleMessage("ទៅកាលបរិច្ឆេទ"),
        "today": MessageLookupByLibrary.simpleMessage("ថ្ងៃនេះ"),
        "total": MessageLookupByLibrary.simpleMessage("សរុប"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("ចំនួនសរុប"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("សរុបដែលបានប្រមូល"),
        "totalDue": MessageLookupByLibrary.simpleMessage("បំណុលសរុប"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("ចំនួនចំណាយសរុប"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("ខាតសរុប"),
        "totalPayable": MessageLookupByLibrary.simpleMessage("សរុបដែលត្រូវបង់"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("តម្លៃសរុប"),
        "totalProducts": MessageLookupByLibrary.simpleMessage("ផលិតផលសរុប"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("ប្រាក់ចំណេញសរុប"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("ចំនួនទិញសរុប"),
        "totalReturnAmount": MessageLookupByLibrary.simpleMessage(
            "ចំនួនទឹកប្រាក់ដែលត្រូវត្រឡប់"),
        "totalReturns":
            MessageLookupByLibrary.simpleMessage("សរុបការសងវិក្កយបត្រ"),
        "totalSale": MessageLookupByLibrary.simpleMessage("ចំនួនលក់សរុប"),
        "totalStock": MessageLookupByLibrary.simpleMessage("ស្តុកសរុប"),
        "totalValue": MessageLookupByLibrary.simpleMessage("តម្លៃសរុប"),
        "totalVat": MessageLookupByLibrary.simpleMessage("អាករពន្ធ"),
        "totals": MessageLookupByLibrary.simpleMessage("សរុប: "),
        "transaction": MessageLookupByLibrary.simpleMessage("ប្រតិបត្តិការ"),
        "transactionId":
            MessageLookupByLibrary.simpleMessage("លេខសម្គាល់ការប្រតិបត្តិការ"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("ព្យាយាមម្តងទៀត"),
        "twitter": MessageLookupByLibrary.simpleMessage("ក្រុមហ៊ុនអក្សរតូច"),
        "type": MessageLookupByLibrary.simpleMessage("ប្រភេទ"),
        "unitName": MessageLookupByLibrary.simpleMessage("ឈ្មោះឯកតា"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("តម្លៃឯកតា"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("តម្លៃត្រួតពិនិត្យ"),
        "units": MessageLookupByLibrary.simpleMessage("ឯកតា"),
        "unlimited": MessageLookupByLibrary.simpleMessage("អន្ដរាយ"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("ការប្រើប្រាស់មិនមានកំណត់ទេ។"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "ដោះសោសក្តានុពលពេញលេញនៃ Pos Saas POS ជាមួយនឹងវគ្គបណ្តុះបណ្តាលផ្ទាល់ខ្លួនដែលដឹកនាំដោយក្រុមអ្នកជំនាញរបស់យើង។ ពីមូលដ្ឋានគ្រឹះរហូតដល់បច្ចេកទេសកម្រិតខ្ពស់ យើងធានាថាអ្នកពិតជាស្ទាត់ជំនាញក្នុងការប្រើប្រាស់គ្រប់ផ្នែកនៃប្រព័ន្ធ ដើម្បីបង្កើនប្រសិទ្ធភាពដំណើរការអាជីវកម្មរបស់អ្នក។"),
        "unpaid": MessageLookupByLibrary.simpleMessage("មិនបានបង់ប្រាក់"),
        "update": MessageLookupByLibrary.simpleMessage("ធ្វើបច្ចុប្បន្នភាព"),
        "updateContact": MessageLookupByLibrary.simpleMessage(
            "ធ្វើបច្ចុប្បន្នភាពទំនាក់ទំនង"),
        "updateNow":
            MessageLookupByLibrary.simpleMessage("ធ្វើបច្ចុប្បន្នភាពឥឡូវនេះ"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("ធ្វើបច្ចុប្បន្នភាពផលិតផល"),
        "updateYourPlanFirstYourLimitIsOver": MessageLookupByLibrary.simpleMessage(
            "សូមធ្វើបច្ចុប្បន្នភាពគម្រោងរបស់អ្នកមុនសូមធ្វើការ,\\nការកំណត់របស់អ្នកអស់ហើយ"),
        "updateYourProfile": MessageLookupByLibrary.simpleMessage(
            "ធ្វើបច្ចុប្បន្នភាពទម្រង់របស់អ្នក"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "ធ្វើបច្ចុប្បន្នភាពរូបសង្ខេបរបស់អ្នកដើម្បីភ្ជាប់អ្នកជាមួយអ្នកវេជ្ជបណ្ឌិតរបស់អ្នកបានល្អបំផុត"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "ធ្វើបច្ចុប្បន្នភាពទម្រង់របស់អ្នកដើម្បីតភ្ជាប់អតិថិជនរបស់អ្នកជាមួយការផ្អាកលើអក្សរប្រសិទ្ធភាពល្អក្នុងការប្រតិបត្តិ"),
        "updated": MessageLookupByLibrary.simpleMessage("បានកែប្រែ"),
        "upload": MessageLookupByLibrary.simpleMessage("បញ្ចូល"),
        "uploadDocument": MessageLookupByLibrary.simpleMessage("ផ្ទុកឯកសារឡើង"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("បញ្ចូលរួចរាល់"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("ផ្ទុកឯកសារឡើង"),
        "upplier": MessageLookupByLibrary.simpleMessage("អ្នកផ្គត់ផ្គង់"),
        "usbC": MessageLookupByLibrary.simpleMessage("Usb C"),
        "use": MessageLookupByLibrary.simpleMessage("ប្រើ"),
        "useMobiPos":
            MessageLookupByLibrary.simpleMessage("ប្រើកម្មវិធី Pos Saas"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Use of the system"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("អ្នកប្រើប្រាស់ត្រូវបានលុប"),
        "userRoleDetails": MessageLookupByLibrary.simpleMessage(
            "ព័ត៌មានលម្អិតអំពីតួនាទីអ្នកប្រើប្រាស់"),
        "userTitle": MessageLookupByLibrary.simpleMessage("ចំណងជើងអ្នកប្រើ"),
        "userTitleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("ចំណងជើងអ្នកប្រើមិនអាចទទេ"),
        "value": MessageLookupByLibrary.simpleMessage("តម្លៃ"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("ពន្ធ VAT មិនអាចអនុវត្តបាន"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("ផ្ទៀងផ្ទាត់ OTP"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("ផ្ទៀងផ្ទាត់លេខទូរស័ព្ទ"),
        "viewAll": MessageLookupByLibrary.simpleMessage("មើលទាំងអស់"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("មើលព័ត៌មាន"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("អតិថិជនមកធ្វើការ"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Depo"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("ឃ្លាំងមានរួចហើយ"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("បញ្ជីឃ្លាំង"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("ឈ្មោះឃ្លាំង"),
        "warranty": MessageLookupByLibrary.simpleMessage("ការធានា"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "យើងបានផ្ញើររូបសង្ឃឹមជាមួយការណែនាំរបស់របស់អ្នកក្នុងការកំណត់ពាក្យសំងាត់ទៅកាន់:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "We may use third-party services to support our app\'s functionality, such as analytics providers and payment processors. These third-party services may collect information about you when you use our app. Please note that we are not responsible for the privacy practices of these third-party services."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "We take industry-standard measures to protect your personal information, including encryption and secure storage. We also limit access to your information to authorized personnel only."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            " យើងយល់ពីសារៈសំខាន់នៃប្រតិបត្តិការគ្មានថ្នេរ។ នោះហើយជាមូលហេតុដែលការគាំទ្រពេញម៉ោងរបស់យើងគឺអាចរកបានដើម្បីជួយអ្នក មិនថាវាជាសំណួររហ័ស ឬកង្វល់ដ៏ទូលំទូលាយនោះទេ។ ភ្ជាប់ជាមួយយើងគ្រប់ពេលវេលា គ្រប់ទីកន្លែង តាមរយៈការហៅទូរសព្ទ ឬ WhatsApp ដើម្បីទទួលបានបទពិសោធន៍សេវាកម្មអតិថិជនដែលមិនអាចប្រៀបផ្ទឹមបាន។"),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "We use your personal information to provide you with the best possible experience on our app, including to personalize your content recomme ndations, connect you with experts, and improve our apps functionality. We may also use your information to communicate with you about updates, promotions, or other information related to our app."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "យើងនឹងពិនិត្យប្រាក់កក់ហើយអនុម័តវាក្នុងរយៈពេល ១-២ ម៉ោង"),
        "weekly": MessageLookupByLibrary.simpleMessage("ប្រចាំសប្តាហ៍"),
        "weight": MessageLookupByLibrary.simpleMessage("ទំងន់"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("អ្វីដែលថ្មី"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("អ្នកលក់លើស"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("តម្លៃដឹកជញ្ជូន"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("តម្លៃលក់ដុំ"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("អ្នកគ្រប់គ្រង"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("នឹងត្រូវបន្ថែមឆាប់ៗនេះ"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("នឹងផុតកំណត់នៅ"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("សរសេរសាររបស់អ្នកនៅទីនេះ"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("OTP មិនត្រឹមត្រូវ"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "ពាក្យសំងាត់ខុសច្បាប់សម្រាប់អ្នកប្រើប្រាស់នេះ។"),
        "yearly": MessageLookupByLibrary.simpleMessage("ប្រចាំឆ្នាំ"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("បាទ, លុបរហូតជារៀង"),
        "youAreNotAValidUser": MessageLookupByLibrary.simpleMessage(
            "អ្នកមិនមែនជាអ្នកប្រើដែលមានសុពលភាពទេ"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("អ្នកកំពុងប្រើ"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "អ្នកមិនអាចបង់ប្រាក់ច្រើនជាងចំនួនដែលត្រូវបានកំណត់"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("អ្នកបានទទួលរូបសង្ឃឹមតែមួយ"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "អ្នកបានចូលប្រើប្រាស់បានជោគជ័យ។ សូមនៅជាមួយនឹង Pos Saas"),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("អ្នកត្រូវផ្ដល់សិទ្ធិ"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "អ្នកត្រូវចូល ឡត្ថូរ លេខ គណនីរបស់អ្នកម្តងមួយ"),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "អ្នកត្រូវការបញ្ជាក់ការសម្គាល់មុនពេលអ្នកទិញ SMS"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("សាររបស់អ្នកនឹងនៅសល់"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("កញ្ចប់របស់អ្នក"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "កញ្ចប់របស់អ្នកនឹងផុតកំណត់ក្នុង 5 ថ្ងៃ")
      };
}
