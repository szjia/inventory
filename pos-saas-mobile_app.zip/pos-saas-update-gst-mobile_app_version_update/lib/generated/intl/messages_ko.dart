// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a ko locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'ko';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("계속"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("GST 번호"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("소매 가격"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("최종 소비자 가격(MRP)은 필수입니다"),
        "OK": MessageLookupByLibrary.simpleMessage("확인"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("페이팔"),
        "PhNo": MessageLookupByLibrary.simpleMessage("전화번호"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT 코드"),
        "Snacks": MessageLookupByLibrary.simpleMessage("간식"),
        "TAX": MessageLookupByLibrary.simpleMessage("세금"),
        "Uploading": MessageLookupByLibrary.simpleMessage("업로드 중"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("사용자 제목"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage("패키지가 오늘 만료됩니다.\n\n다시 구매해주세요"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) The System is provided solely for the\npurpose of facilitating point of sale\ntransactions andrelatedactivities in your\nbusiness."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) To use the System, you may be\nrequired to create an account. You\nagree to provide accurate, current, and\ncomplete information during\nthe registration process and toupdate\nsuchinformationto keep itaccurate\nand complete."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("앱 정보"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("회사 소개"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Acceptance of Terms"),
        "accountName": MessageLookupByLibrary.simpleMessage("계좌명"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("계좌 번호"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Account Registration"),
        "acton": MessageLookupByLibrary.simpleMessage("행동"),
        "add": MessageLookupByLibrary.simpleMessage("추가"),
        "addBrand": MessageLookupByLibrary.simpleMessage("브랜드 추가"),
        "addCategory": MessageLookupByLibrary.simpleMessage("카테고리 추가"),
        "addContact": MessageLookupByLibrary.simpleMessage("연락처 추가"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("고객 추가"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("배송 추가"),
        "addDescriptioN": MessageLookupByLibrary.simpleMessage("설명 추가"),
        "addDescription": MessageLookupByLibrary.simpleMessage("노트 추가"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("할인 추가"),
        "addDocumentId": MessageLookupByLibrary.simpleMessage("문서 ID 추가"),
        "addDucument": MessageLookupByLibrary.simpleMessage("문서 추가"),
        "addExpense": MessageLookupByLibrary.simpleMessage("지출 추가"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("지출 카테고리 추가"),
        "addItems": MessageLookupByLibrary.simpleMessage("품목 추가"),
        "addNew": MessageLookupByLibrary.simpleMessage("새로 추가"),
        "addNewAddress": MessageLookupByLibrary.simpleMessage("새 주소 추가"),
        "addNewProduct": MessageLookupByLibrary.simpleMessage("새 제품 추가"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("새 세금 추가"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage("단일/다중 세금 유형으로 새 세금 추가"),
        "addNote": MessageLookupByLibrary.simpleMessage("노트 추가"),
        "addProductFirst": MessageLookupByLibrary.simpleMessage("먼저 제품을 추가하세요"),
        "addPromoCode": MessageLookupByLibrary.simpleMessage("프로모션 코드 추가"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("구매 추가"),
        "addSales": MessageLookupByLibrary.simpleMessage("판매 추가"),
        "addSuccessful": MessageLookupByLibrary.simpleMessage("성공적으로 추가됨"),
        "addUnit": MessageLookupByLibrary.simpleMessage("단위 추가"),
        "addUserRole": MessageLookupByLibrary.simpleMessage("사용자 역할 추가"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("성공적으로 추가되었습니다"),
        "addedToCart": MessageLookupByLibrary.simpleMessage("장바구니에 추가됨"),
        "address": MessageLookupByLibrary.simpleMessage("주소"),
        "admin": MessageLookupByLibrary.simpleMessage("관리자"),
        "all": MessageLookupByLibrary.simpleMessage("모두"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("모든 비즈니스 솔루션"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("이미 추가되었습니다"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("이미 존재함"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("이미 계정이 있으신가요"),
        "amount": MessageLookupByLibrary.simpleMessage("금액"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "이메일이 전송되었습니다.\\n받은 편지함을 확인하십시오"),
        "androidIOSAppSupport":
            MessageLookupByLibrary.simpleMessage("안드로이드 및 iOS 앱 지원"),
        "applicableTax": MessageLookupByLibrary.simpleMessage("적용 가능한 세금"),
        "apply": MessageLookupByLibrary.simpleMessage("적용"),
        "areYouSureToDeleteThisInvoice":
            MessageLookupByLibrary.simpleMessage("이 청구서를 삭제하시겠습니까?"),
        "areYouSureToDeleteThisSale":
            MessageLookupByLibrary.simpleMessage("이 판매를 삭제하시겠습니까?"),
        "areYouSureToDeleteThisUser":
            MessageLookupByLibrary.simpleMessage("이 사용자를 삭제하시겠습니까?"),
        "areYouSureWantToDeleteThisTax":
            MessageLookupByLibrary.simpleMessage("이 세금을 삭제하시겠습니까?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage("이 세금 그룹을 삭제하시겠습니까?"),
        "areYouWantToDeleteThisWarehouse":
            MessageLookupByLibrary.simpleMessage("이 창고를 삭제하시겠습니까?"),
        "areYourSureDeleteThisUser":
            MessageLookupByLibrary.simpleMessage("이 사용자를 삭제하시겠습니까?"),
        "authorizedSignature": MessageLookupByLibrary.simpleMessage("승인 서명"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) You are responsible for\nmaintainingthe confidentiality of your\naccount and password andfor restricting\naccess to your account. You accept\nresponsibility for all activities that\noccur under your account."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) You must be at least 18 years old or the\nlegal age of majority in your jurisdiction to\nuse the System."),
        "backSide": MessageLookupByLibrary.simpleMessage("뒷면"),
        "backToHome": MessageLookupByLibrary.simpleMessage("홈으로 돌아가기"),
        "balance": MessageLookupByLibrary.simpleMessage("잔액"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("방글라데시"),
        "bank": MessageLookupByLibrary.simpleMessage("은행"),
        "bankAccountCurrency": MessageLookupByLibrary.simpleMessage("은행 계좌 통화"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("은행 계좌 통화"),
        "bankInformation": MessageLookupByLibrary.simpleMessage("은행 정보"),
        "bankName": MessageLookupByLibrary.simpleMessage("은행 이름"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("은행 송금"),
        "barcodeFound": MessageLookupByLibrary.simpleMessage("바코드 발견됨"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("청구서/송장"),
        "billTo": MessageLookupByLibrary.simpleMessage("청구처"),
        "branchName": MessageLookupByLibrary.simpleMessage("지점 이름"),
        "brand": MessageLookupByLibrary.simpleMessage("브랜드"),
        "brandName": MessageLookupByLibrary.simpleMessage("브랜드 이름"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("대량 업로드"),
        "businessCategory": MessageLookupByLibrary.simpleMessage("사업 카테고리"),
        "buy": MessageLookupByLibrary.simpleMessage("구매"),
        "buyPremiumPlan": MessageLookupByLibrary.simpleMessage("프리미엄 플랜 구매"),
        "buySms": MessageLookupByLibrary.simpleMessage("SMS 구매"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "By accessing or using the Point of Sale (POS) System (the \"System\") provided by [Your Company Name] (\"Company\"), you agree to be bound by these Terms of Use. If you do not agree to these Terms of Use, do not use the System."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) You are responsible for ensuring that your\naccess to and use of the System is in\ncompliance with all applicable laws and\nregulations."),
        "cacel": MessageLookupByLibrary.simpleMessage("취소"),
        "call": MessageLookupByLibrary.simpleMessage("전화"),
        "callForEmergencySupport":
            MessageLookupByLibrary.simpleMessage("긴급 지원을 위해 전화하세요"),
        "camera": MessageLookupByLibrary.simpleMessage("카메라"),
        "cancel": MessageLookupByLibrary.simpleMessage("취소"),
        "cancelAllProduct": MessageLookupByLibrary.simpleMessage("모든 제품 취소"),
        "capacity": MessageLookupByLibrary.simpleMessage("용량"),
        "card": MessageLookupByLibrary.simpleMessage("카드"),
        "cash": MessageLookupByLibrary.simpleMessage("현금"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("카테고리"),
        "category": MessageLookupByLibrary.simpleMessage("카테고리"),
        "categoryName": MessageLookupByLibrary.simpleMessage("카테고리 이름"),
        "categoryNameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("카테고리 이름이 이미 존재합니다"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("카테고리 이름"),
        "change": MessageLookupByLibrary.simpleMessage("변경"),
        "changePassword": MessageLookupByLibrary.simpleMessage("비밀번호 변경"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("이메일 확인"),
        "choseACustomer": MessageLookupByLibrary.simpleMessage("고객 선택"),
        "choseASupplier": MessageLookupByLibrary.simpleMessage("공급업체 선택"),
        "choseYourFeature": MessageLookupByLibrary.simpleMessage("기능 선택"),
        "clarence": MessageLookupByLibrary.simpleMessage("클래런스"),
        "clickToConnect": MessageLookupByLibrary.simpleMessage("연결하려면 클릭"),
        "close": MessageLookupByLibrary.simpleMessage("닫기"),
        "color": MessageLookupByLibrary.simpleMessage("색상"),
        "combinationOfMultipleTaxes":
            MessageLookupByLibrary.simpleMessage("(복수 세금의 조합)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("곧 출시됩니다"),
        "companyAddress": MessageLookupByLibrary.simpleMessage("회사 주소"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("회사 및 가게 이름"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("회사 및 사업 이름"),
        "completeTransaction": MessageLookupByLibrary.simpleMessage("거래 완료"),
        "confirmPassword": MessageLookupByLibrary.simpleMessage("비밀번호 확인"),
        "confirmReturn": MessageLookupByLibrary.simpleMessage("반품 확인"),
        "congratulations": MessageLookupByLibrary.simpleMessage("축하합니다"),
        "contactUs": MessageLookupByLibrary.simpleMessage("문의하기"),
        "continu": MessageLookupByLibrary.simpleMessage("계속"),
        "country": MessageLookupByLibrary.simpleMessage("국가"),
        "create": MessageLookupByLibrary.simpleMessage("생성"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("무료 계정 만들기"),
        "createdAndSaved": MessageLookupByLibrary.simpleMessage("생성 및 저장됨"),
        "currency": MessageLookupByLibrary.simpleMessage("통화"),
        "currentStock": MessageLookupByLibrary.simpleMessage("현재 재고"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("맞춤 송장 브랜딩"),
        "customer": MessageLookupByLibrary.simpleMessage("고객"),
        "customerDetails": MessageLookupByLibrary.simpleMessage("고객 세부 정보"),
        "customerGST": MessageLookupByLibrary.simpleMessage("고객 GST"),
        "customerName": MessageLookupByLibrary.simpleMessage("고객 이름"),
        "dailyTransaciton": MessageLookupByLibrary.simpleMessage("일일 거래"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Dashboard Overview"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("데이터가 성공적으로 저장되었습니다"),
        "date": MessageLookupByLibrary.simpleMessage("날짜"),
        "day": MessageLookupByLibrary.simpleMessage("일"),
        "dealer": MessageLookupByLibrary.simpleMessage("유통업자"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("유통 가격"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("기본 VAT 비율"),
        "delete": MessageLookupByLibrary.simpleMessage("삭제"),
        "deleting": MessageLookupByLibrary.simpleMessage("삭제 중"),
        "deliveryAddress": MessageLookupByLibrary.simpleMessage("배송 주소"),
        "deliveryAddresses": MessageLookupByLibrary.simpleMessage("배송 주소"),
        "deliveryCharge": MessageLookupByLibrary.simpleMessage("배송료"),
        "describtion": MessageLookupByLibrary.simpleMessage("설명"),
        "description": MessageLookupByLibrary.simpleMessage("설명"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("설명은 비어 있을 수 없습니다"),
        "details": MessageLookupByLibrary.simpleMessage("세부 사항"),
        "discount": MessageLookupByLibrary.simpleMessage("할인"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("방해 금지"),
        "done": MessageLookupByLibrary.simpleMessage("완료"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Excel 형식 다운로드"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage("다운로드 폴더에 성공적으로 다운로드되었습니다"),
        "due": MessageLookupByLibrary.simpleMessage("미납"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("미납 금액: "),
        "dueCollection": MessageLookupByLibrary.simpleMessage("미납 수금"),
        "dueCollectionReports": MessageLookupByLibrary.simpleMessage("미수금 보고서"),
        "dueList": MessageLookupByLibrary.simpleMessage("미납 목록"),
        "dueReports": MessageLookupByLibrary.simpleMessage("미지급 보고서"),
        "duration": MessageLookupByLibrary.simpleMessage("기간"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("기간: 시작"),
        "easyToUseMobilePos":
            MessageLookupByLibrary.simpleMessage("사용하기 쉬운 모바일 POS"),
        "edit": MessageLookupByLibrary.simpleMessage("편집"),
        "editPurchaseInvoice": MessageLookupByLibrary.simpleMessage("구매 송장 편집"),
        "editSalesInvoice": MessageLookupByLibrary.simpleMessage("판매 송장 편집"),
        "editSocailMedia": MessageLookupByLibrary.simpleMessage("소셜 미디어 수정"),
        "editSuccessfully": MessageLookupByLibrary.simpleMessage("수정 성공"),
        "editTax": MessageLookupByLibrary.simpleMessage("세금 수정"),
        "editTaxGroup": MessageLookupByLibrary.simpleMessage("세금 그룹 수정"),
        "editWarehouse": MessageLookupByLibrary.simpleMessage("창고 수정"),
        "email": MessageLookupByLibrary.simpleMessage("이메일"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("이메일 주소"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("이메일을 입력하지 않았습니다"),
        "emailSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage("이메일이 전송되었습니다! 받은 편지함을 확인하세요"),
        "endDate": MessageLookupByLibrary.simpleMessage("종료 날짜"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("유효한 금액을 입력해 주세요"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("유효한 할인을 입력하세요"),
        "enterAValidPhoneNumber":
            MessageLookupByLibrary.simpleMessage("유효한 전화번호를 입력해 주세요"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("유효한 가격을 입력하세요"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("유효한 수량을 입력하세요"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("주소를 입력하세요"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("금액을 입력하세요."),
        "enterBrandName": MessageLookupByLibrary.simpleMessage("브랜드 이름을 입력하세요"),
        "enterCapacity": MessageLookupByLibrary.simpleMessage("용량을 입력하세요"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("카테고리 이름을 입력하세요"),
        "enterColor": MessageLookupByLibrary.simpleMessage("색상을 입력하세요"),
        "enterCustomerGstNumber":
            MessageLookupByLibrary.simpleMessage("고객 GST 번호 입력"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("유통 가격을 입력하세요"),
        "enterDescription": MessageLookupByLibrary.simpleMessage("설명을 입력해 주세요"),
        "enterDiscount": MessageLookupByLibrary.simpleMessage("할인을 입력하세요"),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("지출 날짜를 입력하세요"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("전체 주소를 입력하세요"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("송장 번호를 입력하세요"),
        "enterLowStockAlertQuantity":
            MessageLookupByLibrary.simpleMessage("저재고 알림 수량 입력"),
        "enterManufacturer": MessageLookupByLibrary.simpleMessage("제조사를 입력하세요"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("메시지 내용 입력"),
        "enterMrpOrRetailerPirce":
            MessageLookupByLibrary.simpleMessage("소매 가격을 입력하세요"),
        "enterName": MessageLookupByLibrary.simpleMessage("이름을 입력하세요"),
        "enterNote": MessageLookupByLibrary.simpleMessage("노트를 입력하세요"),
        "enterPartyName": MessageLookupByLibrary.simpleMessage("거래처 이름을 입력하세요"),
        "enterPhoneNumber": MessageLookupByLibrary.simpleMessage("전화번호를 입력하세요"),
        "enterProductCodeOrScan":
            MessageLookupByLibrary.simpleMessage("제품 코드를 입력하거나 스캔하세요"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("제품 이름을 입력하세요"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("구매 가격을 입력하세요"),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("참조 번호를 입력하세요"),
        "enterSize": MessageLookupByLibrary.simpleMessage("사이즈를 입력하세요"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("재고를 입력하세요"),
        "enterTaxRate": MessageLookupByLibrary.simpleMessage("세율 입력"),
        "enterTransactionId": MessageLookupByLibrary.simpleMessage("거래 ID 입력"),
        "enterType": MessageLookupByLibrary.simpleMessage("유형을 입력하세요"),
        "enterUserTitle": MessageLookupByLibrary.simpleMessage("사용자 제목 입력"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("유효한 금액을 입력해 주세요"),
        "enterWarehouseName": MessageLookupByLibrary.simpleMessage("창고 이름 입력"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("무게를 입력하세요"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("도매 가격을 입력하세요"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("여기에 설명 입력"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("이메일 주소를 입력하세요"),
        "enterYourFeedBackTitle":
            MessageLookupByLibrary.simpleMessage("피드백 제목 입력"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("귀하의 GST 번호를 입력해 주세요"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("휴대폰 번호 입력"),
        "enterYourName": MessageLookupByLibrary.simpleMessage("이름을 입력하세요"),
        "enterYourNumber": MessageLookupByLibrary.simpleMessage("전화번호를 입력하세요"),
        "enterYourPassword": MessageLookupByLibrary.simpleMessage("비밀번호 입력"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("전화번호를 입력하세요"),
        "enterYourTransactionId":
            MessageLookupByLibrary.simpleMessage("거래 ID 입력"),
        "error": MessageLookupByLibrary.simpleMessage("오류"),
        "excTax": MessageLookupByLibrary.simpleMessage("제외 세금"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("Excel 업로더"),
        "exclusive": MessageLookupByLibrary.simpleMessage("제외"),
        "expense": MessageLookupByLibrary.simpleMessage("지출"),
        "expenseCategory": MessageLookupByLibrary.simpleMessage("지출 카테고리"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("지출 날짜"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("지출 대상"),
        "expenseReport": MessageLookupByLibrary.simpleMessage("지출 보고서"),
        "expireDate": MessageLookupByLibrary.simpleMessage("유효 기간"),
        "expired": MessageLookupByLibrary.simpleMessage("만료됨"),
        "expiring": MessageLookupByLibrary.simpleMessage("만료 예정"),
        "facebok": MessageLookupByLibrary.simpleMessage("페이스북"),
        "failedWithError": MessageLookupByLibrary.simpleMessage("오류 발생"),
        "fashion": MessageLookupByLibrary.simpleMessage("패션"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "기능은 Pos Sale를 전통적인 솔루션과 차별화하는 중요한 부분입니다."),
        "feedBack": MessageLookupByLibrary.simpleMessage("피드백"),
        "firstName": MessageLookupByLibrary.simpleMessage("이름"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("페이스북에서 팔로우하세요"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("트위터에서 팔로우하세요"),
        "fontSide": MessageLookupByLibrary.simpleMessage("앞면"),
        "forUnlimitedUses": MessageLookupByLibrary.simpleMessage("무제한 사용을 위해"),
        "forgotPassword": MessageLookupByLibrary.simpleMessage("비밀번호를 잊으셨나요"),
        "forgotPasswords": MessageLookupByLibrary.simpleMessage("비밀번호를 잊으셨나요?"),
        "formDate": MessageLookupByLibrary.simpleMessage("시작 날짜"),
        "freeDataBackup": MessageLookupByLibrary.simpleMessage("무료 데이터 백업"),
        "freeLifeTimeUpdate":
            MessageLookupByLibrary.simpleMessage("무료 평생 업데이트"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("무료 패키지"),
        "freePlan": MessageLookupByLibrary.simpleMessage("무료 플랜"),
        "from": MessageLookupByLibrary.simpleMessage("(부터"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("완전 결제됨"),
        "gallary": MessageLookupByLibrary.simpleMessage("갤러리"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("PDF 생성 중"),
        "getOtp": MessageLookupByLibrary.simpleMessage("OTP 받기"),
        "govermentId": MessageLookupByLibrary.simpleMessage("정부 신분증"),
        "guest": MessageLookupByLibrary.simpleMessage("손님"),
        "havenotAnAccounts": MessageLookupByLibrary.simpleMessage("계정이 없으신가요?"),
        "history": MessageLookupByLibrary.simpleMessage("기록"),
        "home": MessageLookupByLibrary.simpleMessage("홈"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "How We Protect Your Information"),
        "howWeUseYourInformation":
            MessageLookupByLibrary.simpleMessage("How We Use Your Information"),
        "identityVerify": MessageLookupByLibrary.simpleMessage("신원 확인"),
        "image": MessageLookupByLibrary.simpleMessage("이미지"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("내부 항목은 삭제할 수 없습니다"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("내부 항목은 수정할 수 없습니다"),
        "inWord": MessageLookupByLibrary.simpleMessage("단어로"),
        "incTax": MessageLookupByLibrary.simpleMessage("포함 세금"),
        "inclusive": MessageLookupByLibrary.simpleMessage("포함"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("재고 증가"),
        "inistrument": MessageLookupByLibrary.simpleMessage("기구"),
        "instragram": MessageLookupByLibrary.simpleMessage("인스타그램"),
        "invNo": MessageLookupByLibrary.simpleMessage("송장 번호"),
        "invoice": MessageLookupByLibrary.simpleMessage("송장"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("송장 번호"),
        "invoiceSetting": MessageLookupByLibrary.simpleMessage("송장 설정"),
        "invoiceViewer": MessageLookupByLibrary.simpleMessage("송장 뷰어"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("품목 추가됨"),
        "kg": MessageLookupByLibrary.simpleMessage("킬로그램"),
        "kycVerification": MessageLookupByLibrary.simpleMessage("KYC 확인"),
        "language": MessageLookupByLibrary.simpleMessage("언어"),
        "lastName": MessageLookupByLibrary.simpleMessage("성"),
        "ledger": MessageLookupByLibrary.simpleMessage("원장"),
        "lifeTimePurchase": MessageLookupByLibrary.simpleMessage("평생 구매"),
        "link": MessageLookupByLibrary.simpleMessage("링크"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("링크드인"),
        "liveChatSupport": MessageLookupByLibrary.simpleMessage("실시간 채팅 지원"),
        "loading": MessageLookupByLibrary.simpleMessage("로딩 중"),
        "logIn": MessageLookupByLibrary.simpleMessage("로그인"),
        "logOUt": MessageLookupByLibrary.simpleMessage("로그아웃"),
        "logOut": MessageLookupByLibrary.simpleMessage("로그아웃"),
        "login": MessageLookupByLibrary.simpleMessage("로그인"),
        "logo": MessageLookupByLibrary.simpleMessage("로고"),
        "loss": MessageLookupByLibrary.simpleMessage("손실"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("손익"),
        "lossOrProfitDetails": MessageLookupByLibrary.simpleMessage("손익 상세 내역"),
        "lossProfitReport": MessageLookupByLibrary.simpleMessage("손실/이익 보고서"),
        "lossProfitReports": MessageLookupByLibrary.simpleMessage("손실/이익 보고서"),
        "lowStockAlert": MessageLookupByLibrary.simpleMessage("저재고 알림"),
        "maan": MessageLookupByLibrary.simpleMessage("마안"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "맞춤 송장을 사용하여 고객에게 지속적인 인상을 남기세요. 우리의 무제한 업그레이드는 브랜드 정체성을 강화하고 고객 충성을 유발하는 전문적인 송장을 추가하는 독특한 이점을 제공합니다."),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("비즈니스를 관리하세요 "),
        "manufactureDate": MessageLookupByLibrary.simpleMessage("제조일"),
        "margin": MessageLookupByLibrary.simpleMessage("마진"),
        "masterCard": MessageLookupByLibrary.simpleMessage("마스터 카드"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("제조사"),
        "message": MessageLookupByLibrary.simpleMessage("메시지"),
        "messageHistory": MessageLookupByLibrary.simpleMessage("메시지 기록"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Pos Sale 앱은 무료이며 사용하기 쉽습니다. 실제로 전 세계에서 가장 좋은 POS 시스템 중 하나입니다."),
        "mobiPosIsaCompleteBusinesSolution":
            MessageLookupByLibrary.simpleMessage(
                "Pos Sale는 재고, 계정, 판매, 비용 및 손익을 포함한 완벽한 비즈니스 솔루션입니다."),
        "mobile": MessageLookupByLibrary.simpleMessage("모바일"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("모바일 결제"),
        "monthly": MessageLookupByLibrary.simpleMessage("월간"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("추가 정보"),
        "name": MessageLookupByLibrary.simpleMessage("이름을 입력하세요."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("이미 존재하는 이름입니다"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("이름은 비워둘 수 없습니다"),
        "next": MessageLookupByLibrary.simpleMessage("다음"),
        "noConnection": MessageLookupByLibrary.simpleMessage("연결 없음"),
        "noData": MessageLookupByLibrary.simpleMessage("데이터 없음"),
        "noDataAvailable": MessageLookupByLibrary.simpleMessage("데이터 없음"),
        "noDataFound": MessageLookupByLibrary.simpleMessage("데이터가 없습니다"),
        "noHistoryFound": MessageLookupByLibrary.simpleMessage("기록이 없습니다!"),
        "noProductFound": MessageLookupByLibrary.simpleMessage("제품을 찾을 수 없습니다"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("선택된 하위 세금 없음"),
        "noTransactionFound": MessageLookupByLibrary.simpleMessage("거래가 없습니다!"),
        "noUserFoundForThatEmail":
            MessageLookupByLibrary.simpleMessage("해당 이메일에 대한 사용자를 찾을 수 없습니다."),
        "noUserRoleFound":
            MessageLookupByLibrary.simpleMessage("사용자 역할을 찾을 수 없음"),
        "notActiveUser": MessageLookupByLibrary.simpleMessage("활성 사용자 아님"),
        "notProvided": MessageLookupByLibrary.simpleMessage("제공되지 않음"),
        "note": MessageLookupByLibrary.simpleMessage("노트"),
        "notes": MessageLookupByLibrary.simpleMessage("메모"),
        "notification": MessageLookupByLibrary.simpleMessage("알림"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP가 전송되었습니다"),
        "office": MessageLookupByLibrary.simpleMessage("사무실"),
        "ok": MessageLookupByLibrary.simpleMessage("확인"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS that contains a great deal of functionality, including sales tracking, inventory management."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "This system helps you improve your operations for your customers."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Our POS system should simplify daily operations automatically, making it easy to navigate."),
        "openingBalance": MessageLookupByLibrary.simpleMessage("초기 잔고"),
        "order": MessageLookupByLibrary.simpleMessage("주문"),
        "other": MessageLookupByLibrary.simpleMessage("기타"),
        "otp": MessageLookupByLibrary.simpleMessage("닫기"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("재고 없음"),
        "pacakge": MessageLookupByLibrary.simpleMessage("패키지"),
        "packageFeatures": MessageLookupByLibrary.simpleMessage("패키지 기능"),
        "paid": MessageLookupByLibrary.simpleMessage("지불됨"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("지불된 금액"),
        "parties": MessageLookupByLibrary.simpleMessage("거래처"),
        "partiesList": MessageLookupByLibrary.simpleMessage("거래처 목록"),
        "partyGST": MessageLookupByLibrary.simpleMessage("상대방 GST"),
        "partyName": MessageLookupByLibrary.simpleMessage("거래처 이름"),
        "password": MessageLookupByLibrary.simpleMessage("비밀번호"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage("비밀번호와 확인 비밀번호가 일치하지 않습니다"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("비밀번호를 입력하지 않았습니다"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("비밀번호가 일치하지 않습니다"),
        "payCash": MessageLookupByLibrary.simpleMessage("현금 결제"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash": MessageLookupByLibrary.simpleMessage("bkash로 결제"),
        "payWithPaypal": MessageLookupByLibrary.simpleMessage("Paypal로 결제"),
        "payeeName": MessageLookupByLibrary.simpleMessage("수취인 이름"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("수취인 번호"),
        "payment": MessageLookupByLibrary.simpleMessage("지불"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("지불 금액"),
        "paymentComplete": MessageLookupByLibrary.simpleMessage("결제 완료"),
        "paymentInstructions": MessageLookupByLibrary.simpleMessage("결제 안내:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("지불 방법"),
        "paymentType": MessageLookupByLibrary.simpleMessage("지불 유형"),
        "pdfView": MessageLookupByLibrary.simpleMessage("PDF 보기"),
        "personalInformation": MessageLookupByLibrary.simpleMessage("개인 정보"),
        "phone": MessageLookupByLibrary.simpleMessage("전화"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("전화번호"),
        "phoneNumberAlreadyUsed":
            MessageLookupByLibrary.simpleMessage("전화번호가 이미 사용되었습니다"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("전화번호가 유효하지 않습니다"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("전화번호는 필수입니다"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("파일 선택 및 업로드"),
        "pickEndDate": MessageLookupByLibrary.simpleMessage("종료 날짜 선택"),
        "pickStartDate": MessageLookupByLibrary.simpleMessage("시작 날짜 선택"),
        "plan": MessageLookupByLibrary.simpleMessage("계획"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("수량을 추가해 주세요"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage("인터넷 연결 상태를 확인해주세요"),
        "pleaseConnectThePrinterFirst":
            MessageLookupByLibrary.simpleMessage("먼저 프린터를 연결해 주세요"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage("블루투스 프린터를 연결해주세요"),
        "pleaseEnterABiggerPassword":
            MessageLookupByLibrary.simpleMessage("더 긴 비밀번호를 입력해 주세요"),
        "pleaseEnterAConfirmPassword":
            MessageLookupByLibrary.simpleMessage("비밀번호 확인을 입력하세요"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("비밀번호를 입력해주세요"),
        "pleaseEnterAValidEmail":
            MessageLookupByLibrary.simpleMessage("유효한 이메일을 입력해 주세요"),
        "pleaseEnterName": MessageLookupByLibrary.simpleMessage("이름을 입력해 주세요"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("비밀번호를 입력하십시오"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "비밀번호 재설정 링크를 받으려면 이메일 주소를 입력해주세요."),
        "pleaseEnterTransactionNumber":
            MessageLookupByLibrary.simpleMessage("거래 번호를 입력하세요"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("금액을 입력해 주세요"),
        "pleaseSelectACategoryFirst":
            MessageLookupByLibrary.simpleMessage("먼저 카테고리를 선택해 주세요"),
        "pleaseSelectAPlan": MessageLookupByLibrary.simpleMessage("계획을 선택하세요"),
        "pleaseSelectBusinessCategory":
            MessageLookupByLibrary.simpleMessage("비즈니스 카테고리를 선택해 주세요"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage("앱을 사용하려면 유효한 구매 코드를 사용하세요"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Pos Saas 제공"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("제공됨"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("프리미엄 고객 지원"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("프리미엄 플랜"),
        "previousPayAmounts": MessageLookupByLibrary.simpleMessage("이전 지불 금액"),
        "price": MessageLookupByLibrary.simpleMessage("가격"),
        "print": MessageLookupByLibrary.simpleMessage("인쇄"),
        "printingOption": MessageLookupByLibrary.simpleMessage("인쇄 옵션"),
        "privacyPolicy": MessageLookupByLibrary.simpleMessage("개인 정보 보호 정책"),
        "product": MessageLookupByLibrary.simpleMessage("제품"),
        "productCode": MessageLookupByLibrary.simpleMessage("제품 코드"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("제품 코드는 필수입니다"),
        "productCodeName": MessageLookupByLibrary.simpleMessage("제품 코드/이름"),
        "productDescription": MessageLookupByLibrary.simpleMessage("제품 설명"),
        "productDetails": MessageLookupByLibrary.simpleMessage("제품 세부 사항"),
        "productList": MessageLookupByLibrary.simpleMessage("제품 목록"),
        "productName": MessageLookupByLibrary.simpleMessage("제품 이름"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage("이 창고에 이미 제품 이름이 존재합니다"),
        "productNameIsAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("제품 이름이 이미 추가되었습니다"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("제품 이름은 필수입니다"),
        "products": MessageLookupByLibrary.simpleMessage("제품"),
        "profile": MessageLookupByLibrary.simpleMessage("프로필"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("프로필 편집"),
        "profit": MessageLookupByLibrary.simpleMessage("이익"),
        "promo": MessageLookupByLibrary.simpleMessage("프로모션"),
        "promoCode": MessageLookupByLibrary.simpleMessage("프로모션 코드"),
        "purchase": MessageLookupByLibrary.simpleMessage("구매"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage("구매 알림"),
        "purchaseConfirmed": MessageLookupByLibrary.simpleMessage("구매 확인됨"),
        "purchaseDetails": MessageLookupByLibrary.simpleMessage("구매 세부 정보"),
        "purchaseInvoice": MessageLookupByLibrary.simpleMessage("구매 송장"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("구매 목록"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("지금 구매"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("프리미엄 플랜 구매"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("구매 가격"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("구매 가격은 필수입니다"),
        "purchaseRepoet": MessageLookupByLibrary.simpleMessage("구매 보고서"),
        "purchaseReports": MessageLookupByLibrary.simpleMessage("구매 보고서"),
        "purchaseReportss": MessageLookupByLibrary.simpleMessage("구매 보고서"),
        "purchaseReturn": MessageLookupByLibrary.simpleMessage("구매 반품"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("구매 반품 보고서"),
        "purchaseTransition": MessageLookupByLibrary.simpleMessage("구매 전환"),
        "qty": MessageLookupByLibrary.simpleMessage("수량"),
        "quantity": MessageLookupByLibrary.simpleMessage("수량"),
        "recentTransactions": MessageLookupByLibrary.simpleMessage("최근 거래"),
        "recivedThePin": MessageLookupByLibrary.simpleMessage("핀을 받음"),
        "referenceNumber": MessageLookupByLibrary.simpleMessage("참조 번호"),
        "register": MessageLookupByLibrary.simpleMessage("등록"),
        "registering": MessageLookupByLibrary.simpleMessage("등록 중"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("미납 잔액"),
        "remove": MessageLookupByLibrary.simpleMessage("제거"),
        "reports": MessageLookupByLibrary.simpleMessage("보고서"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("요청이 전송되었습니다"),
        "resendCode": MessageLookupByLibrary.simpleMessage("코드 재전송"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("OTP 재전송: "),
        "retailer": MessageLookupByLibrary.simpleMessage("소매업자"),
        "retur": MessageLookupByLibrary.simpleMessage("반품"),
        "returN": MessageLookupByLibrary.simpleMessage("반품"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("환불 금액"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("환불 금액"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("반품 수량"),
        "revenue": MessageLookupByLibrary.simpleMessage("수익"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "비즈니스 데이터를 손쉽게 보호하세요. Pos Saas POS 무제한 업그레이드에는 무료 데이터 백업이 포함되어 소중한 정보가 예기치 않은 사건에 대비하여 보호됩니다. 진정 중요한 것에 집중하세요 - 비즈니스 성장."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("판매 금액"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("판매 세부 정보"),
        "salePrice": MessageLookupByLibrary.simpleMessage("판매 가격"),
        "saleReports": MessageLookupByLibrary.simpleMessage("판매 보고서"),
        "saleReportss": MessageLookupByLibrary.simpleMessage("판매 보고서"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("판매 반품"),
        "saleReturnReport": MessageLookupByLibrary.simpleMessage("판매 반품 보고서"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("판매 설정"),
        "sales": MessageLookupByLibrary.simpleMessage("판매"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("Sale & Purchase Reports"),
        "salesList": MessageLookupByLibrary.simpleMessage("판매 목록"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("판매 반품"),
        "save": MessageLookupByLibrary.simpleMessage("저장"),
        "saveAndPublish": MessageLookupByLibrary.simpleMessage("저장 및 게시"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("변경 사항 저장"),
        "saving": MessageLookupByLibrary.simpleMessage("저장 중"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("제품 QR 코드를 스캔하세요"),
        "search": MessageLookupByLibrary.simpleMessage("검색"),
        "searchByProductCodeOrName":
            MessageLookupByLibrary.simpleMessage("제품 코드 또는 이름으로 검색"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("모든 프로모션 코드 보기"),
        "select": MessageLookupByLibrary.simpleMessage("선택"),
        "selectAProductForReturn":
            MessageLookupByLibrary.simpleMessage("반품할 제품을 선택하세요"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("브랜드 선택"),
        "selectCategory": MessageLookupByLibrary.simpleMessage("카테고리 선택"),
        "selectContacts": MessageLookupByLibrary.simpleMessage("연락처 선택"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("제품 카테고리 선택"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("상점 카테고리를 선택해 주세요"),
        "selectTax": MessageLookupByLibrary.simpleMessage("세금 선택"),
        "selectTaxType": MessageLookupByLibrary.simpleMessage("세금 유형 선택"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("단위 선택"),
        "selectvariations": MessageLookupByLibrary.simpleMessage("변형 선택: "),
        "seller": MessageLookupByLibrary.simpleMessage("판매자"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("판매자"),
        "send": MessageLookupByLibrary.simpleMessage("보내기"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("이메일 보내기"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("메시지 전송"),
        "sendResetLink": MessageLookupByLibrary.simpleMessage("재설정 링크 보내기"),
        "sendSms": MessageLookupByLibrary.simpleMessage("SMS 보내기"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("SMS 전송?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("WhatsApp 메시지 보내기"),
        "sendYOurEmail": MessageLookupByLibrary.simpleMessage("이메일 보내기"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage("이메일 전송 중"),
        "sendingMessage": MessageLookupByLibrary.simpleMessage("메시지 전송 중"),
        "serviceShipping": MessageLookupByLibrary.simpleMessage("서비스/배송"),
        "setUpYourProfile": MessageLookupByLibrary.simpleMessage("프로필 설정"),
        "setting": MessageLookupByLibrary.simpleMessage("설정"),
        "share": MessageLookupByLibrary.simpleMessage("공유"),
        "shopGST": MessageLookupByLibrary.simpleMessage("상점 GST"),
        "signIn": MessageLookupByLibrary.simpleMessage("로그인"),
        "signInWithEmail": MessageLookupByLibrary.simpleMessage("이메일로 로그인"),
        "signatureOfCustomer": MessageLookupByLibrary.simpleMessage("고객 서명"),
        "size": MessageLookupByLibrary.simpleMessage("사이즈"),
        "skip": MessageLookupByLibrary.simpleMessage("건너뛰기"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing": MessageLookupByLibrary.simpleMessage("소셜 마케팅"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage("죄송합니다, 이 서비스에 접근할 권한이 없습니다"),
        "startDate": MessageLookupByLibrary.simpleMessage("시작 날짜"),
        "startNewSale": MessageLookupByLibrary.simpleMessage("새 판매 시작"),
        "startTypingToSearch":
            MessageLookupByLibrary.simpleMessage("검색하려면 입력을 시작하세요"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "추가 비용 없이 기술 발전의 선두에 머무르세요. 우리의 Pos Saas POS 무제한 업그레이드를 통해 언제나 최신 도구와 기능을 손에 넣어 비즈니스가 최첨단 유지되도록 보장합니다."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("아직 미결제"),
        "stock": MessageLookupByLibrary.simpleMessage("재고"),
        "stockIsRequired": MessageLookupByLibrary.simpleMessage("재고는 필수입니다"),
        "stockList": MessageLookupByLibrary.simpleMessage("재고 목록"),
        "stocks": MessageLookupByLibrary.simpleMessage("재고"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Excel 파일을 생성하려면 저장소 권한이 필요합니다"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("하위 세금 목록"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("하위 세금"),
        "subTotal": MessageLookupByLibrary.simpleMessage("소계"),
        "submit": MessageLookupByLibrary.simpleMessage("제출"),
        "subscribeToOurYoutube":
            MessageLookupByLibrary.simpleMessage("유튜브에서 구독하세요"),
        "subscription": MessageLookupByLibrary.simpleMessage("구독"),
        "successfullyDone": MessageLookupByLibrary.simpleMessage("성공적으로 완료됨"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("성공적으로 로그아웃됨"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("성공적으로 업데이트되었습니다"),
        "supplier": MessageLookupByLibrary.simpleMessage("공급업체"),
        "supplierName": MessageLookupByLibrary.simpleMessage("공급업체 이름"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT 코드"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "운전 면허증, 주민등록증 또는 여권 사진을 가져와 주세요"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage("정보 확인을 위해 신분증을 가져와 주세요"),
        "tap": MessageLookupByLibrary.simpleMessage("탭"),
        "tax": MessageLookupByLibrary.simpleMessage("세금"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("세금 그룹"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("세금 비율"),
        "taxRate": MessageLookupByLibrary.simpleMessage("세율"),
        "taxRatesManageYourTaxRates":
            MessageLookupByLibrary.simpleMessage("세율 - 세율 관리"),
        "taxReport": MessageLookupByLibrary.simpleMessage("세금 보고서"),
        "taxType": MessageLookupByLibrary.simpleMessage("세금 유형"),
        "taxes": MessageLookupByLibrary.simpleMessage("세금"),
        "termsAndConditions": MessageLookupByLibrary.simpleMessage("이용 약관"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("이용 약관"),
        "termsPrivacy": MessageLookupByLibrary.simpleMessage("약관 및 개인정보처리방침"),
        "thankYOuForYourDuePayment":
            MessageLookupByLibrary.simpleMessage("미납 결제 감사합니다"),
        "thankYou": MessageLookupByLibrary.simpleMessage("감사합니다"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("구매해 주셔서 감사합니다"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage("해당 이메일에 이미 계정이 존재합니다"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage("Excel 파일이 이미 다운로드되었습니다"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "이름이 모든 것을 말합니다. Pos Saas POS 무제한을 사용하면 사용량에 제한이 없습니다. 소수의 거래를 처리하거나 고객 급증을 경험하더라도 제한에 구애받지 않고 확신을 가지고 운영할 수 있습니다."),
        "thePasswordProvidedIsTooWeak":
            MessageLookupByLibrary.simpleMessage("제공된 비밀번호가 너무 약합니다"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "판매가 삭제되며 이 구매에 대한 모든 데이터가 삭제됩니다. 정말 삭제하시겠습니까?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "판매가 삭제되며 이 판매에 대한 모든 데이터가 삭제됩니다. 정말 삭제하시겠습니까?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "사용자가 삭제되며 모든 데이터가 계정에서 삭제됩니다. 정말 삭제하시겠습니까?"),
        "theUserWillBeDeletedAndAllTheData":
            MessageLookupByLibrary.simpleMessage(
                "사용자가 삭제되며 모든 데이터가 귀하의 계정에서 삭제됩니다. 정말로 삭제하시겠습니까?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Third-Party Services"),
        "thisCategoryCannotBeDeleted":
            MessageLookupByLibrary.simpleMessage("이 카테고리는 삭제할 수 없습니다"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(이번 달)"),
        "thisProductAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("이 제품은 이미 추가되었습니다"),
        "title": MessageLookupByLibrary.simpleMessage("제목"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("제목은 비어 있을 수 없습니다"),
        "to": MessageLookupByLibrary.simpleMessage("까지)"),
        "toDate": MessageLookupByLibrary.simpleMessage("종료 날짜"),
        "today": MessageLookupByLibrary.simpleMessage("오늘"),
        "total": MessageLookupByLibrary.simpleMessage("총"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("총 금액"),
        "totalCollected": MessageLookupByLibrary.simpleMessage("총 수집된 금액"),
        "totalDue": MessageLookupByLibrary.simpleMessage("총 미납"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("총 지출"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("총 손실"),
        "totalPayable": MessageLookupByLibrary.simpleMessage("총 지불 금액"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("총 가격"),
        "totalProducts": MessageLookupByLibrary.simpleMessage("총 제품 수"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("총 이익"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("총 구매"),
        "totalReturnAmount": MessageLookupByLibrary.simpleMessage("총 반품 금액"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("총 반품"),
        "totalSale": MessageLookupByLibrary.simpleMessage("총 판매액"),
        "totalStock": MessageLookupByLibrary.simpleMessage("총 재고"),
        "totalValue": MessageLookupByLibrary.simpleMessage("총 가치"),
        "totalVat": MessageLookupByLibrary.simpleMessage("총 부가세"),
        "totals": MessageLookupByLibrary.simpleMessage("합계: "),
        "transaction": MessageLookupByLibrary.simpleMessage("거래"),
        "transactionId": MessageLookupByLibrary.simpleMessage("거래 ID"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("다시 시도"),
        "twitter": MessageLookupByLibrary.simpleMessage("트위터"),
        "type": MessageLookupByLibrary.simpleMessage("유형"),
        "unitName": MessageLookupByLibrary.simpleMessage("단위 이름"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("단가"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("단가"),
        "units": MessageLookupByLibrary.simpleMessage("단위"),
        "unlimited": MessageLookupByLibrary.simpleMessage("무제한"),
        "unlimitedUsage": MessageLookupByLibrary.simpleMessage("무제한 사용"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "우리의 전문 팀이 주도하는 맞춤 교육 세션으로 Pos Saas POS의 모든 측면을 최적화하여 비즈니스 프로세스를 향상시킬 수 있도록 Pos Saas POS의 모든 잠재력을 발휘하세요. 기본부터 고급 기술까지, 우리는 시스템의 모든 측면을 숙지하도록 보장합니다."),
        "unpaid": MessageLookupByLibrary.simpleMessage("미납"),
        "update": MessageLookupByLibrary.simpleMessage("업데이트"),
        "updateContact": MessageLookupByLibrary.simpleMessage("연락처 업데이트"),
        "updateNow": MessageLookupByLibrary.simpleMessage("지금 업데이트"),
        "updateProduct": MessageLookupByLibrary.simpleMessage("제품 업데이트"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage("먼저 계획을 업데이트하세요, 한도가 초과되었습니다"),
        "updateYourProfile": MessageLookupByLibrary.simpleMessage("프로필 업데이트"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "의사와 더 나은 인상으로 연결하려면 프로필을 업데이트하세요"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "고객과 더 나은 인상으로 연결하려면 프로필을 업데이트하세요"),
        "updated": MessageLookupByLibrary.simpleMessage("업데이트됨"),
        "upload": MessageLookupByLibrary.simpleMessage("업로드"),
        "uploadDocument": MessageLookupByLibrary.simpleMessage("문서 업로드"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("업로드 완료"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("파일 업로드"),
        "upplier": MessageLookupByLibrary.simpleMessage("공급업체"),
        "usbC": MessageLookupByLibrary.simpleMessage("USB C"),
        "use": MessageLookupByLibrary.simpleMessage("사용"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("Pos Sale 사용"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Use of the system"),
        "userIsDeleted": MessageLookupByLibrary.simpleMessage("사용자가 삭제되었습니다"),
        "userRole": MessageLookupByLibrary.simpleMessage("사용자 역할"),
        "userRoleDetails": MessageLookupByLibrary.simpleMessage("사용자 역할 상세정보"),
        "userTitle": MessageLookupByLibrary.simpleMessage("사용자 제목"),
        "userTitleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("사용자 제목은 비워둘 수 없습니다"),
        "value": MessageLookupByLibrary.simpleMessage("값"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("부가세가 적용되지 않습니다"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("OTP 확인 중"),
        "verifyPhoneNumber": MessageLookupByLibrary.simpleMessage("전화번호 확인"),
        "viewAll": MessageLookupByLibrary.simpleMessage("모두 보기"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("세부 정보 보기"),
        "walkInCustomer": MessageLookupByLibrary.simpleMessage("입점 고객"),
        "warehouse": MessageLookupByLibrary.simpleMessage("창고"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("창고가 이미 존재합니다"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("창고 목록"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("창고 이름"),
        "warranty": MessageLookupByLibrary.simpleMessage("보증"),
        "weHaveSendAnEmailwithInstructions":
            MessageLookupByLibrary.simpleMessage(
                "비밀번호 재설정 안내 이메일을 다음 주소로 전송했습니다:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "We may use third-party services to support our app\'s functionality, such as analytics providers and payment processors. These third-party services may collect information about you when you use our app. Please note that we are not responsible for the privacy practices of these third-party services."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "We take industry-standard measures to protect your personal information, including encryption and secure storage. We also limit access to your information to authorized personnel only."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "우리는 원활한 운영의 중요성을 이해합니다. 그래서 24시간 지원이 빠른 질문이나 포괄적인 우려에 도움을 드릴 수 있도록 언제 어디서나 연락할 수 있도록 제공됩니다. 우리와 언제 어디서나 전화 또는 WhatsApp을 통해 연락하여 비할 무엇이든 경험하세요."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "We use your personal information to provide you with the best possible experience on our app, including to personalize your content recomme ndations, connect you with experts, and improve our apps functionality. We may also use your information to communicate with you about updates, promotions, or other information related to our app."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "우리는 결제를 검토하고 1-2시간 내에 승인할 것입니다"),
        "weekly": MessageLookupByLibrary.simpleMessage("주간"),
        "weight": MessageLookupByLibrary.simpleMessage("무게"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("새로운 기능"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("도매상"),
        "wholeSalePrice": MessageLookupByLibrary.simpleMessage("도매 가격"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("도매가"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("도매상"),
        "willBeAddedSoon": MessageLookupByLibrary.simpleMessage("곧 추가됩니다"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("만료 예정일"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("메시지를 입력하세요"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("잘못된 OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage("해당 사용자의 잘못된 비밀번호를 입력했습니다."),
        "yearly": MessageLookupByLibrary.simpleMessage("연간"),
        "yesDeleteForever": MessageLookupByLibrary.simpleMessage("예, 영구 삭제"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("유효한 사용자가 아닙니다"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("사용 중인 것:"),
        "youCanNotPayMoreThenDue":
            MessageLookupByLibrary.simpleMessage("미납액보다 더 지불할 수 없습니다"),
        "youHaveGotAnEmail": MessageLookupByLibrary.simpleMessage("이메일을 받았습니다"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "계정에 성공적으로 로그인했습니다. Pos Sale와 함께하세요."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("권한을 부여해야 합니다"),
        "youHaveToReLogin":
            MessageLookupByLibrary.simpleMessage("계정을 다시 로그인해야 합니다."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage("구매하기 전에 신원 확인이 필요합니다"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("메시지가 남아 있습니다"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("귀하의 패키지"),
        "yourPackageWillExpireinDay":
            MessageLookupByLibrary.simpleMessage("패키지가 5일 후에 만료됩니다")
      };
}
