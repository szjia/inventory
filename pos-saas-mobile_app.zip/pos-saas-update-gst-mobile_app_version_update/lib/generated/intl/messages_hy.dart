// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a hy locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'hy';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Շարունակել"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("GST համար"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("MRP-ն պարտադիր է"),
        "OK": MessageLookupByLibrary.simpleMessage("Լավ"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("PayPal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Հեռ. N:"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT Կոդ"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Խորտիկներ"),
        "TAX": MessageLookupByLibrary.simpleMessage("ՀԱԿ"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Բեռնվում է"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("Օգտվողի վերնագիր"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Ձեր փաթեթը կավարտվի այսօր\n\nԽնդրում ենք կրկին գնել"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(ա) Համակարգը տրամադրվում է բացառապես ձեր բիզնեսում վաճառքի կետերի գործարքների և դրանց հետ կապված գործունեության facilitation-ի նպատակով."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(ա) Համակարգը օգտագործելու համար, դուք կարող եք պահանջվել ստեղծել հաշիվ: Դուք համաձայնվում եք գրանցման գործընթացի ընթացքում տալ ճշգրիտ, ընթացիկ և ամբողջական տեղեկատվություն և թարմացնել այդ տեղեկատվությունը, որպեսզի այն շարունակի լինել ճշգրիտ և ամբողջական."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("Նկարագրություն"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Մեր մասին"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Պայմանների ընդունում"),
        "accountName":
            MessageLookupByLibrary.simpleMessage("Հաշվեհամարի անուն"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("Հաշվեհամար"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Հաշվի գրանցում"),
        "acton": MessageLookupByLibrary.simpleMessage("Գործողություն"),
        "add": MessageLookupByLibrary.simpleMessage("Ավելացնել"),
        "addBrand":
            MessageLookupByLibrary.simpleMessage("Ավելացնել ապրանքանիշ"),
        "addCategory":
            MessageLookupByLibrary.simpleMessage("Ավելացնել կատեգորիա"),
        "addContact": MessageLookupByLibrary.simpleMessage("Ավելացնել կոնտակտ"),
        "addCustomer":
            MessageLookupByLibrary.simpleMessage("Ավելացնել հաճախորդ"),
        "addDelivery":
            MessageLookupByLibrary.simpleMessage("Ավելացնել առաքում"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Ավելացնել նկարագրություն"),
        "addDescription":
            MessageLookupByLibrary.simpleMessage("Ավելացնել նշում"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Ավելացնել զեղչ"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Ավելացնել փաստաթղթի ID"),
        "addDucument":
            MessageLookupByLibrary.simpleMessage("Ավելացնել փաստաթուղթ"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Ավելացնել ծախս"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Ավելացնել ծախսի կատեգորիա"),
        "addItems": MessageLookupByLibrary.simpleMessage("Ավելացնել ապրանքներ"),
        "addNew": MessageLookupByLibrary.simpleMessage("Ավելացնել նոր"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Ավելացնել նոր հասցե"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Ավելացնել նոր ապրանք"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("Ավելացնել նոր հարկ"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Ավելացնել նոր հարկ մեկ/բազմաթիվ հարկի տեսակով"),
        "addNote": MessageLookupByLibrary.simpleMessage("Ավելացնել նշում"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Սկզբում ավելացրեք ապրանքը"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Ավելացնել գովազդային կոդ"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Ավելացնել գնում"),
        "addSales": MessageLookupByLibrary.simpleMessage("Ավելացնել վաճառքներ"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Ավելացվել է հաջողությամբ"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Ավելացնել միավոր"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Ավելացնել օգտվողի դերը"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Ավելացվել է հաջողությամբ"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("Ավելացվել է զամբյուղին"),
        "address": MessageLookupByLibrary.simpleMessage("Հասցե"),
        "admin": MessageLookupByLibrary.simpleMessage("Ադմին"),
        "all": MessageLookupByLibrary.simpleMessage("Ամեն ինչ"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("Բոլոր բիզնես լուծումները"),
        "alreadyAdded":
            MessageLookupByLibrary.simpleMessage("Ավելի վաղ ավելացված"),
        "alreadyExists":
            MessageLookupByLibrary.simpleMessage("Այլևս գոյություն ունի"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Պատրաստի հաշիվ ունեք"),
        "amount": MessageLookupByLibrary.simpleMessage("Գումար"),
        "anEmailHasBeenSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "Էլ. նամակ է ուղարկվել\\nԽնդրում ենք ստուգել ձեր մուտքային փոստը"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Android և iOS հավելվածի աջակցություն"),
        "applicableTax": MessageLookupByLibrary.simpleMessage("Կիրառելի հարկ"),
        "apply": MessageLookupByLibrary.simpleMessage("Դիմել"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Դուք վստահ եք, որ ցանկանում եք հեռացնել այս հաշիվը"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Դուք վստահ եք, որ ցանկանում եք հեռացնել այս վաճառքը"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Հավաստի՞ եք, որ ցանկանում եք հեռացնել այս օգտվողին"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Հանգիստ եք ցանկանում ջնջել այս հարկը"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Հանգիստ եք ցանկանում ջնջել այս հարկային խմբի"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Դուք ցանկանում եք ջնջել այս պահեստը"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Հիմա՞ եք վստահ, որ ցանկանում եք հեռացնել այս օգտագործողին?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Հաստատված ստորագրություն"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(բ) Դուք պատասխանատու եք ձեր հաշվի և գաղտնաբառի գաղտնիությունը պահպանելու և ձեր հաշվի մուտքը սահմանափակելու համար. Դուք ընդունում եք պատասխանատվությունը ձեր հաշվի տակ տեղի ունեցող բոլոր գործունեությունների համար."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(բ) Դուք պետք է լինեք առնվազն 18 տարեկան կամ ձեր իրավասության մեջ օրինական մեծության տարիքի, որպեսզի օգտագործեք Համակարգը."),
        "backSide": MessageLookupByLibrary.simpleMessage("Հետին կողմ"),
        "backToHome":
            MessageLookupByLibrary.simpleMessage("Վերադառնալ գլխավոր էջ"),
        "balance": MessageLookupByLibrary.simpleMessage("Հաշիվ"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Բանգլադեշ"),
        "bank": MessageLookupByLibrary.simpleMessage("Բանկ"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Բանկային հաշվի արժույթ"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Բանկային հաշվի արժույթ"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Բանկային տեղեկություններ"),
        "bankName": MessageLookupByLibrary.simpleMessage("Բանկի անվանում"),
        "bankTransfer":
            MessageLookupByLibrary.simpleMessage("Բանկային փոխանցում"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Բարակոդը գտնվել է"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Հաշիվ/Հաշիվ"),
        "billTo": MessageLookupByLibrary.simpleMessage("Մեծամասնությունը"),
        "branchName":
            MessageLookupByLibrary.simpleMessage("Դեպոզիտային անվանում"),
        "brand": MessageLookupByLibrary.simpleMessage("Ապրանքանիշ"),
        "brandName": MessageLookupByLibrary.simpleMessage("Ապրանքանիշի անուն"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("Մեծածախ\nԲեռնման"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Բիզնես կատեգորիա"),
        "buy": MessageLookupByLibrary.simpleMessage("Գնել"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Գնել պրեմիում պլան"),
        "buySms": MessageLookupByLibrary.simpleMessage("Գնել SMS"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Մուտք գործելով կամ օգտագործելով [Ձեր ընկերության անունը] (\"Ընկերություն\") կողմից տրամադրվող Վաճառքի կետ (POS) համակարգը (\"Համակարգ\"), դուք համաձայնվում եք այս Օգտագործման պայմաններին: Եթե ​​դուք համաձայն չեք այս Օգտագործման պայմաններին, ապա մի օգտագործեք Համակարգը."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(գ) Դուք պատասխանատու եք ապահովելու, որ ձեր մուտքը դեպի Համակարգ և դրա օգտագործումը համապատասխանում է բոլոր կիրառելի օրենքներին և կանոնակարգերին."),
        "cacel": MessageLookupByLibrary.simpleMessage("Չեղարկել"),
        "call": MessageLookupByLibrary.simpleMessage("Զանգել"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "Զանգահարեք արտակարգ աջակցության համար"),
        "camera": MessageLookupByLibrary.simpleMessage("Կարամա"),
        "cancel": MessageLookupByLibrary.simpleMessage("Չեղարկել"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Չեղարկել բոլոր ապրանքները"),
        "capacity": MessageLookupByLibrary.simpleMessage("Հզորություն"),
        "card": MessageLookupByLibrary.simpleMessage("Քարտ"),
        "cash": MessageLookupByLibrary.simpleMessage("Գումար"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Կատեգորիաներ"),
        "category": MessageLookupByLibrary.simpleMessage("Կատեգորիա"),
        "categoryName":
            MessageLookupByLibrary.simpleMessage("Կատեգորիայի անվանում"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "Կատեգորիայի անվանումը արդեն գոյություն ունի"),
        "cateogryName":
            MessageLookupByLibrary.simpleMessage("Կատեգորիայի անուն"),
        "change": MessageLookupByLibrary.simpleMessage("Փոխել?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Փոխել գաղտնաբառը"),
        "checkEmail":
            MessageLookupByLibrary.simpleMessage("Ստուգեք էլ. նամակը"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Ընտրել հաճախորդ"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Ընտրեք մատակարար"),
        "choseYourFeature": MessageLookupByLibrary.simpleMessage(
            "Ընտրեք ձեր հնարավորությունները"),
        "clarence": MessageLookupByLibrary.simpleMessage("Նվազագույն"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Սեղմեք միանալու համար"),
        "close": MessageLookupByLibrary.simpleMessage("Փակել"),
        "color": MessageLookupByLibrary.simpleMessage("Գույն"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(Բազմաթիվ հարկերի համակցություն)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Շուտով"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Ընկերության հասցե"),
        "companyAndShopName": MessageLookupByLibrary.simpleMessage(
            "Ընկերության և խանութի անունը"),
        "companyBusinessName": MessageLookupByLibrary.simpleMessage(
            "Ընկերության և բիզնեսի անունը"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Գործարքը ավարտել"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Հաստատեք գաղտնաբառը"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Հաստատեք վերադարձը"),
        "congratulations":
            MessageLookupByLibrary.simpleMessage("Ի շնորհավորանք"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Կապ մեզ հետ"),
        "continu": MessageLookupByLibrary.simpleMessage("Շարունակել"),
        "country": MessageLookupByLibrary.simpleMessage("Երկիր"),
        "create": MessageLookupByLibrary.simpleMessage("Ստեղծել"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Ստեղծեք անվճար հաշիվ"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Ստեղծվել և պահպանվել"),
        "currency": MessageLookupByLibrary.simpleMessage("Արժույթ"),
        "currentStock": MessageLookupByLibrary.simpleMessage("Ընթացիկ պահեստ"),
        "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
            "Անձնական հաշիվների բրենդավորում"),
        "customer": MessageLookupByLibrary.simpleMessage("Հաճախորդ"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Հաճախորդի տվյալները"),
        "customerGST": MessageLookupByLibrary.simpleMessage("Հաճախորդի GST"),
        "customerName": MessageLookupByLibrary.simpleMessage("Հաճախորդի անուն"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Օրվա գործարքներ"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Վահանակի տեսություն"),
        "dataSavedSuccessfully": MessageLookupByLibrary.simpleMessage(
            "Տվյալները հաջողությամբ պահպանվել են"),
        "date": MessageLookupByLibrary.simpleMessage(" tarikh"),
        "day": MessageLookupByLibrary.simpleMessage("Օր"),
        "dealer": MessageLookupByLibrary.simpleMessage("Վաճառող"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("Մատակարարի գին"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("Նախնական VAT տոկոսը"),
        "delete": MessageLookupByLibrary.simpleMessage("Ջնջել"),
        "deleting": MessageLookupByLibrary.simpleMessage("Հեռացում"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Առաքման հասցե"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Առաքման հասցեներ"),
        "deliveryCharge": MessageLookupByLibrary.simpleMessage("Առաքման վճար"),
        "describtion": MessageLookupByLibrary.simpleMessage("Նկարագրություն"),
        "description": MessageLookupByLibrary.simpleMessage("Նկարագրություն"),
        "descriptionCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Նկարագրությունը չի կարող լինել դատարկ"),
        "details": MessageLookupByLibrary.simpleMessage("Մանրամասները"),
        "discount": MessageLookupByLibrary.simpleMessage("Զեղչ"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Մի անհանգստացեք"),
        "done": MessageLookupByLibrary.simpleMessage("Ավարտվեց"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Ներբեռնեք Excel ձևաչափը"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Ներբեռնվել է հաջողությամբ ներբեռնման ֆոլդերում"),
        "due": MessageLookupByLibrary.simpleMessage("Պարտք"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Պարտքի գումարը։"),
        "dueCollection":
            MessageLookupByLibrary.simpleMessage("Պարտքի հավաքում"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("Տեղի կուտակման զեկույցներ"),
        "dueList": MessageLookupByLibrary.simpleMessage("Պարտքերի ցուցակ"),
        "dueReports":
            MessageLookupByLibrary.simpleMessage("Պարտք հաշվետվություն"),
        "duration": MessageLookupByLibrary.simpleMessage("Տևողություն"),
        "durationFrom":
            MessageLookupByLibrary.simpleMessage("Արագություն: Մեկնարկից"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "Լավ օգտագործվող շարժական POS"),
        "edit": MessageLookupByLibrary.simpleMessage("Խմբագրել"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Խմբագրել գնումների հաշիվ"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Խմբագրել վաճառքի հաշիվ"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Խմբագրել սոցիալական մեդիա"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Հաջողությամբ խմբագրվել է"),
        "editTax": MessageLookupByLibrary.simpleMessage("Խմբագրել հարկը"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Խմբագրել հարկային խումբը"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("Խմբագրել պահեստը"),
        "email": MessageLookupByLibrary.simpleMessage("Էլ. նամակ"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("Էլ. հասցե"),
        "emailCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Էլ. հասցեն չի կարող լինել դատարկ"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "Էլ. Փոստը ուղարկված է! Ստուգեք ձեր մուտքի տուփը"),
        "endDate": MessageLookupByLibrary.simpleMessage("Ավարտի ամսաթիվ"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Մուտքագրեք վավեր գումար"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Մուտքագրեք գործող զեղչ"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Մուտքագրեք վավեր հեռախոսահամար"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Մուտքագրեք գործող գին"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("Մուտքագրեք գործող քանակ"),
        "enterAddress":
            MessageLookupByLibrary.simpleMessage("Մուտքագրեք հասցեն"),
        "enterAmount":
            MessageLookupByLibrary.simpleMessage("Մուտքագրեք գումարը։"),
        "enterBrandName": MessageLookupByLibrary.simpleMessage(
            "Մուտքագրեք ապրանքանիշի անունը"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Մուտքագրեք հզորությունը"),
        "enterCategoryName": MessageLookupByLibrary.simpleMessage(
            "Մուտքագրեք կատեգորիայի անունը"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Մուտքագրեք գույնը"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "Մուտքագրեք հաճախորդի GST համար"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Մուտքագրեք մատակարարի գինը"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Մուտքագրեք նկարագրությունը"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("Մուտքագրեք զեղչ։"),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Մուտքագրեք ծախսի ամսաթիվը"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Մուտքագրեք ամբողջ հասցեն"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Մուտքագրեք հաշվի համար"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Մուտքագրեք նվազագույն պաշարների ահազանգի քանակը"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Մուտքագրեք արտադրողը"),
        "enterMessageContent": MessageLookupByLibrary.simpleMessage(
            "Մուտքագրեք հաղորդագրության պարունակությունը"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "Մուտքագրեք MRP/Տեղափոխման գին"),
        "enterName": MessageLookupByLibrary.simpleMessage("Մուտքագրեք անունը"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Մուտքագրեք նշումը"),
        "enterPartyName": MessageLookupByLibrary.simpleMessage(
            "Մուտքագրեք կուսակցության անունը"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Մուտքագրեք հեռախոսահամարը"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Մուտքագրեք ապրանքի կոդը կամ սկանեք"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Մուտքագրեք ապրանքի անունը"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Մուտքագրեք գնման գինը։"),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("Մուտքագրեք հղման համար"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Մուտքագրեք չափը"),
        "enterStocks":
            MessageLookupByLibrary.simpleMessage("Մուտքագրեք պաշարներ։"),
        "enterTaxRate": MessageLookupByLibrary.simpleMessage(
            "Մուտքագրեք հարկի տոկոսադրույքը"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("Մուտքագրեք գործարքի ID"),
        "enterType": MessageLookupByLibrary.simpleMessage("Մուտքագրեք տեսակը"),
        "enterUserTitle": MessageLookupByLibrary.simpleMessage(
            "Մուտքագրեք օգտվողի վերնագիրը"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Մուտքագրեք վավեր գումար"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Մուտքագրեք պահեստի անունը"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Մուտքագրեք քաշը"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Մուտքագրեք հունական գինը"),
        "enterYourDescriptionHere": MessageLookupByLibrary.simpleMessage(
            "Մուտքագրեք ձեր նկարագրությունը այստեղ"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("Մուտքագրեք ձեր էլ. հասցեն"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "Մուտքագրեք ձեր մեկնաբանության վերնագիրը"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Մուտքագրեք ձեր GST համար"),
        "enterYourMobileNumber": MessageLookupByLibrary.simpleMessage(
            "Մուտքագրեք ձեր բջջային համարը"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Մուտքագրեք ձեր անունը"),
        "enterYourNumber": MessageLookupByLibrary.simpleMessage(
            "Մուտքագրեք ձեր հեռախոսահամարը"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Մուտքագրեք ձեր գաղտնաբառը"),
        "enterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Մուտքագրեք ձեր հեռախոսահամարը"),
        "enterYourTransactionId":
            MessageLookupByLibrary.simpleMessage("Մուտքագրեք ձեր գործարքի ID"),
        "error": MessageLookupByLibrary.simpleMessage("Սխալ"),
        "excTax": MessageLookupByLibrary.simpleMessage("Չհաշված հարկ"),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("Excel-ներբեռնող"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Չհաշված"),
        "expense": MessageLookupByLibrary.simpleMessage("Ծախս"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Ծախսի կատեգորիա"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Ծախսի ամսաթիվ"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Ծախսը"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Ծախսերի հաշվետվություն"),
        "expireDate": MessageLookupByLibrary.simpleMessage(
            "վավերականության ավարտի ամսաթիվ"),
        "expired":
            MessageLookupByLibrary.simpleMessage("Վավերականության ավարտվել է"),
        "expiring":
            MessageLookupByLibrary.simpleMessage("Վավերականության ավարտ"),
        "facebok": MessageLookupByLibrary.simpleMessage("Ֆեյսբուք"),
        "failedWithError": MessageLookupByLibrary.simpleMessage(
            "Հաջողությունը սխալով է ավարտվել"),
        "fashion": MessageLookupByLibrary.simpleMessage("Ֆիրմային"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Հնարավորությունները կարևոր մասն են, որոնք դարձնում են POS SaaS-ը տարբեր ավանդական լուծումներից:"),
        "feedBack": MessageLookupByLibrary.simpleMessage("Մեկնաբանություն"),
        "firstName": MessageLookupByLibrary.simpleMessage("Առաջին անուն"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Հետևեք մեզ Facebook-ում"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Հետևեք մեզ Twitter-ում"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Առջևի կողմ"),
        "forUnlimitedUses": MessageLookupByLibrary.simpleMessage(
            "Անսահմանակի օգտագործման համար"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Մոռացե՞լ եք գաղտնաբառը"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Մոռացե՞լ եք գաղտնաբառը?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Մեկնարկի ամսաթիվ"),
        "freeDataBackup": MessageLookupByLibrary.simpleMessage(
            "Անվճար տվյալների պահուստավորում"),
        "freeLifeTimeUpdate":
            MessageLookupByLibrary.simpleMessage("Անվճար կյանքի թարմացում"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Անվճար փաթեթ"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Անվճար պլան"),
        "from": MessageLookupByLibrary.simpleMessage("(Մեկնարկ"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Լրիվ վճարված"),
        "gallary": MessageLookupByLibrary.simpleMessage("Լուսանկարների ալբոմ"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("PDF ստեղծում"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Գտնել OTP"),
        "govermentId":
            MessageLookupByLibrary.simpleMessage("Արդարադատության ID"),
        "guest": MessageLookupByLibrary.simpleMessage("Անհատական"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Ոչ մեկի հաշվառված չունեք?"),
        "history": MessageLookupByLibrary.simpleMessage("Պատմություն"),
        "home": MessageLookupByLibrary.simpleMessage("Տուն"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Ինչպես ենք պաշտպանում ձեր տեղեկատվությունը"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Ինչպես ենք օգտագործում ձեր տեղեկատվությունը"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Ինքնության հաստատում"),
        "image": MessageLookupByLibrary.simpleMessage("Նկար"),
        "inHouseCantBeDelete": MessageLookupByLibrary.simpleMessage(
            "Արտոնությունները չեն կարող ջնջվել"),
        "inHouseCantBeEdited": MessageLookupByLibrary.simpleMessage(
            "Արտոնությունները չեն կարող խմբագրվել"),
        "inWord": MessageLookupByLibrary.simpleMessage("Բառով"),
        "incTax": MessageLookupByLibrary.simpleMessage("Ներառյալ հարկ"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Ներառյալ"),
        "increaseStock":
            MessageLookupByLibrary.simpleMessage("Ավելացնել պաշար"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Գործիք"),
        "instragram": MessageLookupByLibrary.simpleMessage("Ինստագրամ"),
        "invNo": MessageLookupByLibrary.simpleMessage("Պատվերի համար։"),
        "invoice": MessageLookupByLibrary.simpleMessage("Հաշիվ"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("Հաշվի համար"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Հաշվի կարգավորում"),
        "invoiceViewer": MessageLookupByLibrary.simpleMessage("Հաշվի դիտորդ"),
        "itemAdded":
            MessageLookupByLibrary.simpleMessage("Ապրանքն ավելացված է"),
        "kg": MessageLookupByLibrary.simpleMessage("կգ"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("KYC հաստատում"),
        "language": MessageLookupByLibrary.simpleMessage("Լեզու"),
        "lastName": MessageLookupByLibrary.simpleMessage("Վերջին անուն"),
        "ledger": MessageLookupByLibrary.simpleMessage("Գրապահոց"),
        "lifeTimePurchase": MessageLookupByLibrary.simpleMessage("Առաջարկում"),
        "link": MessageLookupByLibrary.simpleMessage("Հղում"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport": MessageLookupByLibrary.simpleMessage(
            "Բջջային զրույցի աջակցություն"),
        "loading": MessageLookupByLibrary.simpleMessage("Բեռնվում է"),
        "logIn": MessageLookupByLibrary.simpleMessage("Մուտք"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Ելք"),
        "logOut": MessageLookupByLibrary.simpleMessage("Դուրս գալ"),
        "login": MessageLookupByLibrary.simpleMessage("Մուտք"),
        "logo": MessageLookupByLibrary.simpleMessage("Լոգո"),
        "loss": MessageLookupByLibrary.simpleMessage("Տեմագրված"),
        "lossOrProfit":
            MessageLookupByLibrary.simpleMessage("Տեմագրված/Պաշտպանված"),
        "lossOrProfitDetails": MessageLookupByLibrary.simpleMessage(
            "Տեմագրված/Պաշտպանված մանրամասներ"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Նվազում/շահույթ զեկույց"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Նվազում/շահույթ զեկույցներ"),
        "lowStockAlert": MessageLookupByLibrary.simpleMessage(
            "Նվազագույն պաշարների ահազանգ"),
        "maan": MessageLookupByLibrary.simpleMessage("Ման"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Կատարեք lasting տպավորություն ձեր հաճախորդների վրա բրենդավորված հաշիվներով: Մեր Անվճար թարմացումը առաջարկում է անհատականացված հաշիվներ, որոնք լրացնում են պրոֆեսիոնալ պատկերը, որը reinforces ձեր բրենդի նույնականացումը և առաջացնում է հաճախորդների հավատարմություն."),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("Կառավարեք ձեր բիզնեսը "),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("արտադրության ամսաթիվ"),
        "margin": MessageLookupByLibrary.simpleMessage("Խավ"),
        "masterCard": MessageLookupByLibrary.simpleMessage("MasterCard"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Արտադրող"),
        "message": MessageLookupByLibrary.simpleMessage("Հաղորդագրություն"),
        "messageHistory": MessageLookupByLibrary.simpleMessage(
            "Հաղորդագրությունների պատմություն"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "POS SaaS ծրագիրը անվճար է, հեշտ է օգտագործել։ Իրականում, դա աշխարհի լավագույն POS համակարգերից մեկն է:"),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "POS SaaS-ը ամբողջական բիզնես լուծում է՝ բաժին, հաշվետվություն, վաճառք, ծախս և կորուստ/հասույթ:"),
        "mobile": MessageLookupByLibrary.simpleMessage("Մոբայլ"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("Մոբայլ վճարում"),
        "monthly": MessageLookupByLibrary.simpleMessage("Ամսական"),
        "moreInfo":
            MessageLookupByLibrary.simpleMessage("Լրացուցիչ տեղեկություններ"),
        "name": MessageLookupByLibrary.simpleMessage("Մուտքագրեք ձեր անունը։"),
        "nameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "Անվան մեջ արդեն գոյություն ունի"),
        "nameCantBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Անունը չի կարող լինել դատարկ"),
        "next": MessageLookupByLibrary.simpleMessage("Հաջորդ"),
        "noConnection": MessageLookupByLibrary.simpleMessage("Չկա կապ"),
        "noData": MessageLookupByLibrary.simpleMessage("Տվյալներ չկան"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Տվյալներ չկան"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Տվյալներ չեն գտնվել"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("Պատմություն չի գտնվել!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Ապրանք չի գտնվել"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("Երկրային հարկեր չեն ընտրված"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("Գործարք չի գտնվել!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Այդ էլ. հասցեով օգտագործող չի գտնվել"),
        "noUserRoleFound":
            MessageLookupByLibrary.simpleMessage("Օգտվողի դերում չեն գտվել"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Անգործունակ օգտագործող"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Չի տրամադրվել"),
        "note": MessageLookupByLibrary.simpleMessage("Նշում"),
        "notes": MessageLookupByLibrary.simpleMessage("Նշումներ"),
        "notification": MessageLookupByLibrary.simpleMessage("Ծանուցում"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP-ը ուղարկվել է"),
        "office": MessageLookupByLibrary.simpleMessage("Գործարան"),
        "ok": MessageLookupByLibrary.simpleMessage("Լավ"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS, որը պարունակում է մեծ քանակությամբ գործառույթներ, այդ թվում՝ վաճառքների հետագծում, պաշարների կառավարում:"),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Այս համակարգը օգնում է ձեզ բարելավել ձեր գործունեությունը ձեր հաճախորդների համար."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Մեր POS համակարգը պետք է հեշտացնի օրական գործողությունները ինքնաբերաբար՝ հեշտությամբ նավարկելով:"),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("Բացման մնացորդ"),
        "order": MessageLookupByLibrary.simpleMessage("Պատվեր"),
        "other": MessageLookupByLibrary.simpleMessage("Այլ"),
        "otp": MessageLookupByLibrary.simpleMessage("Փակել"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Չկա պաշարում"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Փաթեթ"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Փաթեթի հնարավորություններ"),
        "paid": MessageLookupByLibrary.simpleMessage("Վճարված"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Վճարված գումար"),
        "parties": MessageLookupByLibrary.simpleMessage("Կուսակցություններ"),
        "partiesList":
            MessageLookupByLibrary.simpleMessage("Կուսակցությունների ցուցակ"),
        "partyGST": MessageLookupByLibrary.simpleMessage("Կողմի GST"),
        "partyName":
            MessageLookupByLibrary.simpleMessage("Կուսակցության անուն"),
        "password": MessageLookupByLibrary.simpleMessage("Գաղտնաբառ"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Գաղտնաբառն ու հաստատման գաղտնաբառը չեն համընկնում"),
        "passwordCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Գաղտնաբառը չի կարող լինել դատարկ"),
        "passwordNotMach": MessageLookupByLibrary.simpleMessage(
            "Գաղտնաբառը չի համապատասխանում"),
        "payCash": MessageLookupByLibrary.simpleMessage("Վճարել կանխիկ"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash": MessageLookupByLibrary.simpleMessage("Վճարել bkash-ով"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Վճարել Paypal-ով"),
        "payeeName":
            MessageLookupByLibrary.simpleMessage("Վճարման ստացողի անուն"),
        "payeeNumber":
            MessageLookupByLibrary.simpleMessage("Վճարման ստացողի համարը"),
        "payment": MessageLookupByLibrary.simpleMessage("Վճար"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("Վճարման գումար"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Վճարն ավարտված է"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Վճարման հրահանգներ:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("Վճարման մեթոդ"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Վճարման տեսակը"),
        "pdfView": MessageLookupByLibrary.simpleMessage("PDF դիտում"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Անձնական տեղեկություններ"),
        "phone": MessageLookupByLibrary.simpleMessage("Հեռախոս"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Հեռախոսահամար"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Հեռախոսահամարը արդեն օգտագործված է"),
        "phoneNumberIsNotValid": MessageLookupByLibrary.simpleMessage(
            "Հեռախոսահամարը չի համապատասխանում"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("Հեռախոսահամարը պարտադիր է"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("Ընտրեք և ներբեռնեք ֆայլը"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("Ընտրել ավարտի ամսաթիվ"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Ընտրել սկիզբի ամսաթիվ"),
        "plan": MessageLookupByLibrary.simpleMessage("Ծրագրի"),
        "pleaseAddQuantity": MessageLookupByLibrary.simpleMessage(
            "Խնդրում ենք ավելացնել քանակը"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Խնդրում ենք ստուգել ձեր ինտերնետ կապը"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Խնդրում ենք առաջինը միացնել տպիչը"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Խնդրում ենք միացնել ձեր Bluetooth տպիչը"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Խնդրում ենք մուտքագրել ավելի երկար գաղտնաբառ"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Խնդրում ենք մուտքագրել հաստատող գաղտնաբառը"),
        "pleaseEnterAPassword": MessageLookupByLibrary.simpleMessage(
            "Խնդրում ենք մուտքագրել գաղտնաբառ"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Խնդրում ենք մուտքագրել վավեր էլ. հասցե"),
        "pleaseEnterName": MessageLookupByLibrary.simpleMessage(
            "Խնդրում ենք մուտքագրել անուն"),
        "pleaseEnterPassword": MessageLookupByLibrary.simpleMessage(
            "Խնդրում ենք մուտքագրել գաղտնաբառը"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Խնդրում ենք մուտքագրել ձեր էլ. հասցեն ներքևում՝ գաղտնաբառը վերականգնելու հղում ստանալու համար:"),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Խնդրում ենք մուտքագրել գործարքի համարը"),
        "pleaseInterAmount": MessageLookupByLibrary.simpleMessage(
            "Խնդրում ենք մուտքագրել գումար"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Խնդրում ենք նախ ընտրել կատեգորիա"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("Խնդրում ենք ընտրել պլան"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Խնդրում ենք ընտրել բիզնեսի կատեգորիա"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Խնդրում ենք օգտագործել գործող գնման կոդը՝ ծրագրի օգտագործման համար"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Հատուկ ՄոբիՊոս-ի կողմից"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Հզորացված է"),
        "premiumCustomerSupport": MessageLookupByLibrary.simpleMessage(
            "Պремիум հաճախորդների աջակցություն"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Պրեմիում պլան"),
        "previousPayAmounts": MessageLookupByLibrary.simpleMessage(
            "Մ sebelumnya վճարային գումարներ"),
        "price": MessageLookupByLibrary.simpleMessage("Գին"),
        "print": MessageLookupByLibrary.simpleMessage("Տպել"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Տպագրության ընտրանք"),
        "privacyPolicy": MessageLookupByLibrary.simpleMessage(
            "Հետաքրքրության քաղաքականություն"),
        "product": MessageLookupByLibrary.simpleMessage("Ապրանք"),
        "productCode": MessageLookupByLibrary.simpleMessage("Ապրանքի կոդ"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("Ապրանքի կոդը պարտադիր է"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Ապրանքի կոդ/անուն"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Ապրանքի նկարագրություն"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Ապրանքի մանրամասները"),
        "productList": MessageLookupByLibrary.simpleMessage("Ապրանքների ցանկ"),
        "productName": MessageLookupByLibrary.simpleMessage("Ապրանքի անուն"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Ապրանքի անունը արդեն գոյություն ունի այս պահեստում"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Ապրանքի անունը արդեն ավելացված է"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("Ապրանքի անունը պարտադիր է"),
        "products": MessageLookupByLibrary.simpleMessage("Ապրանքներ"),
        "profile": MessageLookupByLibrary.simpleMessage("Պրոֆիլ"),
        "profileEdit":
            MessageLookupByLibrary.simpleMessage("Մասնագիտական խմբագրում"),
        "profit": MessageLookupByLibrary.simpleMessage("Պաշտպանված"),
        "promo": MessageLookupByLibrary.simpleMessage("Հրապարակում"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Պրոմո կոդ"),
        "purchase": MessageLookupByLibrary.simpleMessage("Գնում"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage("Գնումների ալար"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Գնումները հաստատված են"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Գնումների մանրամասները"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Գնումների հաշիվ"),
        "purchaseList":
            MessageLookupByLibrary.simpleMessage("Գնումների ցուցակ"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Գնել հիմա"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Գնել պրեմիում պլան"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("Գնումների գին"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("Գնումների գինը պարտադիր է"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("Գնումների հաշվետվություն"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Գնումների հաշվետվություն"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Գնումների զեկույցներ"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("Գնումների վերադարձ"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("Գնումների վերադարձի զեկույց"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Գնումների փոխանցում"),
        "qty": MessageLookupByLibrary.simpleMessage("Քանակ"),
        "quantity": MessageLookupByLibrary.simpleMessage("Քանակ"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Վերջին գործարքները"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("Ստացվեց PIN կոդը"),
        "referenceNumber": MessageLookupByLibrary.simpleMessage("Հղման համար"),
        "register": MessageLookupByLibrary.simpleMessage("Գրանցվել"),
        "registering": MessageLookupByLibrary.simpleMessage("Գրանցվում է"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("Մնացած պարտք"),
        "remove": MessageLookupByLibrary.simpleMessage("Հեռացնել"),
        "reports": MessageLookupByLibrary.simpleMessage("Հաշվետվություններ"),
        "requestHasBeenSend": MessageLookupByLibrary.simpleMessage(
            "Հայտարարությունը ուղարկվել է"),
        "resendCode":
            MessageLookupByLibrary.simpleMessage("Նորից ուղարկել կոդը"),
        "resendOtp":
            MessageLookupByLibrary.simpleMessage("Նորից ուղարկել OTP:"),
        "retailer": MessageLookupByLibrary.simpleMessage("Մանրածախ վաճառող"),
        "retur": MessageLookupByLibrary.simpleMessage("Վերադարձ"),
        "returN": MessageLookupByLibrary.simpleMessage("Վերադարձ"),
        "returnAMount":
            MessageLookupByLibrary.simpleMessage("Վերադարձի գումար"),
        "returnAmount":
            MessageLookupByLibrary.simpleMessage("Վերադարձման գումար"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("Վերադարձի քանակ"),
        "revenue": MessageLookupByLibrary.simpleMessage("Ամբողջ եկամուտ"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Անհանգստացրեք ձեր բիզնեսի տվյալները առանց դժվարության: Մեր Pos Saas POS Անվճար թարմացումը ներառում է անվճար տվյալների պահուստավորում, ապահովելով, որ ձեր արժեքավոր տեղեկությունները պաշտպանված են ցանկացած կանխատեսված դեպքերից: Կենտրոնացեք այն, ինչ իսկապես կարևոր է՝ ձեր բիզնեսի աճը."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Վաճառքի գումար"),
        "saleDetails":
            MessageLookupByLibrary.simpleMessage("Վաճառքի մանրամասները"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Վաճառքի գին"),
        "saleReports":
            MessageLookupByLibrary.simpleMessage("Վաճառքի հաշվետվություն"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Վաճառքների զեկույցներ"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("Վաճառքի վերադարձ"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Վաճառքի վերադարձի զեկույց"),
        "saleSetting":
            MessageLookupByLibrary.simpleMessage("Վաճառքի կարգավորում"),
        "sales": MessageLookupByLibrary.simpleMessage("Վաճառքներ"),
        "salesAndPurchaseReports": MessageLookupByLibrary.simpleMessage(
            "Վաճառքների և գնման հաշվետվություններ"),
        "salesList": MessageLookupByLibrary.simpleMessage("Վաճառքների ցուցակ"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("Վաճառքի վերադարձ"),
        "save": MessageLookupByLibrary.simpleMessage("Պահպանել"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Պահպանել և հրատարակել"),
        "saveChanges":
            MessageLookupByLibrary.simpleMessage("Պահպանել փոփոխությունները"),
        "saving": MessageLookupByLibrary.simpleMessage("Պահպանել"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("Սկանեք ապրանքի QR կոդը"),
        "search": MessageLookupByLibrary.simpleMessage("Որոնել"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Որոնեք ապրանքի կոդով կամ անվանումով"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("Տեսնել բոլոր պրոմո կոդերը"),
        "select": MessageLookupByLibrary.simpleMessage("Ընտրել"),
        "selectAProductForReturn":
            MessageLookupByLibrary.simpleMessage("Ընտրեք վերադարձի ապրանքը"),
        "selectBrand":
            MessageLookupByLibrary.simpleMessage("Ընտրեք ապրանքանիշ"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Ընտրեք կատեգորիա"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Ընտրել կոնտակտներ"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("Ընտրեք ապրանքի կատեգորիա"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("Ընտրեք խանութի կատեգորիա"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Ընտրեք հարկ"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Ընտրեք հարկի տեսակը"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("Ընտրեք միավոր"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Ընտրեք փոփոխություն: "),
        "seller": MessageLookupByLibrary.simpleMessage("Վաճառող"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Վաճառվել է"),
        "send": MessageLookupByLibrary.simpleMessage("Ուղարկել"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("Ուղարկել էլ. նամակ"),
        "sendMessage":
            MessageLookupByLibrary.simpleMessage("Ուղարկել հաղորդագրություն"),
        "sendResetLink": MessageLookupByLibrary.simpleMessage(
            "Ուղարկել վերականգնման հղումը"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Ուղարկել SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Ուղարկել SMS?"),
        "sendWhatsappMessage": MessageLookupByLibrary.simpleMessage(
            "Ուղարկել WhatsApp հաղորդագրություն"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Ուղարկել ձեր էլ. հասցեն"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage("Դեպո ուղարկում"),
        "sendingMessage": MessageLookupByLibrary.simpleMessage(
            "Հաղորդագրություն ուղարկվում է"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Ծառայություն/Տեղափոխում"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Հաստատեք ձեր պրոֆիլը"),
        "setting": MessageLookupByLibrary.simpleMessage("Հարմարանք"),
        "share": MessageLookupByLibrary.simpleMessage("Paylaş"),
        "shopGST": MessageLookupByLibrary.simpleMessage("Խանութի GST"),
        "signIn": MessageLookupByLibrary.simpleMessage("Մուտք գործել"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("Մուտք գործել էլ. հասցեով"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Հաճախորդի ստորագրությունը"),
        "size": MessageLookupByLibrary.simpleMessage("Չափ"),
        "skip": MessageLookupByLibrary.simpleMessage("Անցնել"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Սոցիալական մարկետինգ"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Ներեցեք, դուք չունեք այս ծառայությանը մուտք գործելու թույլտվություն"),
        "startDate": MessageLookupByLibrary.simpleMessage("Սկիզբի ամսաթիվ"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Սկսել նոր վաճառք"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage(
            "Սկսեք մուտքագրել որոնելու համար"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Մնացեք տեխնոլոգիական առաջխաղացումների առաջնագծում առանց լրացուցիչ ծախսերի: Մեր Pos Saas POS Անվճար թարմացումը ապահովում է, որ դուք միշտ ունենաք վերջին գործիքները և ֆունկցիաները ձեր մատների տակ, garantindo ձեր բիզնեսի արդիականությունը."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("Դեռ չի վճարվել"),
        "stock": MessageLookupByLibrary.simpleMessage("Պաշար"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Ապրանքի մնացորդը պարտադիր է"),
        "stockList": MessageLookupByLibrary.simpleMessage("Պաշարների ցուցակ"),
        "stocks": MessageLookupByLibrary.simpleMessage("Պաշարներ"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Excel ֆայլ ստեղծելու համար անհրաժեշտ է պահեստավորման թույլտվություն"),
        "subTaxList":
            MessageLookupByLibrary.simpleMessage("Երկրային հարկերի ցուցակ"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Երկրային հարկեր"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Երկրորդական գումար"),
        "submit": MessageLookupByLibrary.simpleMessage("Հանձնարարել"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "Բաժանորդագրվեք մեր YouTube ալիքին"),
        "subscription":
            MessageLookupByLibrary.simpleMessage("Բաժանորդագրություն"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Հաջողությամբ ավարտված"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Հաջողությամբ դուրս եկաք"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Հաջողությամբ թարմացվել է"),
        "supplier": MessageLookupByLibrary.simpleMessage("Մատակարար"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("Մատակարարի անուն"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT կոդ"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Վերցրեք վարորդի վկայական, ազգային նույնականացման քարտ կամ անձնագրի լուսանկար"),
        "takeaNidCardToCheckYourInformation": MessageLookupByLibrary.simpleMessage(
            "Վերցրեք նույնականացման քարտ, որպեսզի ստուգեք ձեր տեղեկատվությունը"),
        "tap": MessageLookupByLibrary.simpleMessage("Սեղմել"),
        "tax": MessageLookupByLibrary.simpleMessage("Հարկ"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Հարկային խումբ"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("Հարկի տոկոսը"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Հարկի տոկոսադրույք"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Հարկային տոկոսադրույքներ - կառավարեք ձեր հարկային տոկոսադրույքները"),
        "taxReport":
            MessageLookupByLibrary.simpleMessage("Հարկային հաշվետվություն"),
        "taxType": MessageLookupByLibrary.simpleMessage("Հարկի տեսակ"),
        "taxes": MessageLookupByLibrary.simpleMessage("Հարկեր"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Պայմաններ և պայմաններ"),
        "termsOfUse":
            MessageLookupByLibrary.simpleMessage("Օգտագործման պայմաններ"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Ակնթարթներ և գաղտնիություն"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Շնորհակալություն ձեր պարտքի վճարման համար"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Շնորհակալություն"),
        "thankYouForYourPurchase": MessageLookupByLibrary.simpleMessage(
            "Շնորհակալություն ձեր գնումների համար"),
        "theAccountAlreadyExistsForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Այդ էլեկտրոնային հասցեի համար հաշվետվությունը արդեն գոյություն ունի"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Excel ֆայլը արդեն ներբեռնվել է"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Անունը ասում է ամեն ինչ: Pos Saas POS Անվճարով ձեր օգտագործման վրա չկա սահմանափակում: Մինչ դուք մի քանի գործարքներ կատարում եք, թե չէ հաճախորդների rush եք ապրում, կարող եք վստահորեն գործել, իմանալով, որ ձեզ չեն սահմանափակել սահմանները."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "Տրված գաղտնաբառը չափազանց թույլ է"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Վաճառքը կհեռացվի, և բոլոր տվյալները կջնջվեն այս գնումից: Դուք վստահ եք, որ ցանկանում եք հեռացնել սա"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Վաճառքը կհեռացվի, և բոլոր տվյալները կջնջվեն այս վաճառքից: Դուք վստահ եք, որ ցանկանում եք հեռացնել սա"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Օգտագործողը կհանվի, և բոլոր տվյալները կհանվեն ձեր հաշվից։ Հիմա՞ եք վստահ, որ ցանկանում եք դա անել:"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Օգտվողը կհանվի, և բոլոր տվյալները կհանվեն ձեր հաշվից։ Համոզված եք, որ ցանկանում եք հեռացնել դա"),
        "thirdPartyServices": MessageLookupByLibrary.simpleMessage(
            "Երրորդ կողմի ծառայություններ"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Այս կատեգորիան չի կարող ջնջվել"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Այս ամսում)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Այս ապրանքը արդեն ավելացված է"),
        "title": MessageLookupByLibrary.simpleMessage("Վերնագիր"),
        "titleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Վերնագիրը չի կարող լինել դատարկ"),
        "to": MessageLookupByLibrary.simpleMessage("մեթել"),
        "toDate": MessageLookupByLibrary.simpleMessage("Մեկնաժամ"),
        "today": MessageLookupByLibrary.simpleMessage("Այսօր"),
        "total": MessageLookupByLibrary.simpleMessage("Ընդհանուր"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Ընդհանուր գումար"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Ընդհանուր հավաքված"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Ընդհանուր պարտք"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("Ընդհանուր ծախս"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Ընդհանուր վնաս"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("Ընդհանուր վճարելի"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Ընդհանուր գին"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("Ամբողջ ապրանքներ"),
        "totalProfit":
            MessageLookupByLibrary.simpleMessage("Ընդհանուր շահույթ"),
        "totalPurchase":
            MessageLookupByLibrary.simpleMessage("Ընդհանուր գնում"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Ընդհանուր վերադարձի գումարը"),
        "totalReturns":
            MessageLookupByLibrary.simpleMessage("Ընդհանուր վերադարձներ"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Ընդհանուր վաճառք"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Ընդհանուր պահեստ"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Ընդհանուր արժեքը"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Ընդհանուր ԱԱՀ"),
        "totals": MessageLookupByLibrary.simpleMessage("Ընդհանուր: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Գործարք"),
        "transactionId": MessageLookupByLibrary.simpleMessage("Գործարքի ID"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Պարզեք նորից"),
        "twitter": MessageLookupByLibrary.simpleMessage("Թվիթեր"),
        "type": MessageLookupByLibrary.simpleMessage("Տեսակ"),
        "unitName": MessageLookupByLibrary.simpleMessage("Միավորի անուն"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Միավորի գին"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Միավոր գինը"),
        "units": MessageLookupByLibrary.simpleMessage("Միավորներ"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Անսահման"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Չափազանցված օգտագործում"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Բացեք Pos Saas POS-ի ամբողջ ներուժը անհատականացված ուսուցման սեմինարների միջոցով, որոնք վարում են մեր փորձագետների թիմը: Ստեղծման հիմունքներից մինչև առաջադեմ տեխնիկաներ, մենք ապահովում ենք, որ դուք լավ տեղյակ եք յուրաքանչյուր համակարգի կողմը, որպեսզի օպտիմալացնեք ձեր բիզնես գործընթացները."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Չվճարված"),
        "update": MessageLookupByLibrary.simpleMessage("Թարմացնել"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Թարմացնել կոնտակտը"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Թարմացրեք հիմա"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("Թարմացնել ապրանքը"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Թարմացրեք ձեր պլանը առաջինը,\\nձեր սահմանաչափը ավարտված է"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Թարմացնել ձեր պրոֆիլը"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Թարմացրեք ձեր պրոֆիլը, որպեսզի ձեր բժիշկը կապվի ավելի լավ տպավորությամբ"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Թարմացրեք ձեր պրոֆիլը, որպեսզի ավելի լավ հարաբերություններ հաստատեք հաճախորդի հետ"),
        "updated": MessageLookupByLibrary.simpleMessage("Թարմացված"),
        "upload": MessageLookupByLibrary.simpleMessage("Ներբեռնել"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Ընթացքագրեք փաստաթուղթ"),
        "uploadDone": MessageLookupByLibrary.simpleMessage(
            "Ներբեռնման գործընթացը ավարտվեց"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Ընթացքագրեք ֆայլ"),
        "upplier": MessageLookupByLibrary.simpleMessage("Մատակարար"),
        "usbC": MessageLookupByLibrary.simpleMessage("Usb C"),
        "use": MessageLookupByLibrary.simpleMessage("Օգտագործել"),
        "useMobiPos":
            MessageLookupByLibrary.simpleMessage("Օգտագործել POS SaaS"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Համակարգի օգտագործում"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Օգտվողը հեռացվել է"),
        "userRole": MessageLookupByLibrary.simpleMessage("Օգտվողի դերը"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("Օգտագործողի դերագնահատում"),
        "userTitle": MessageLookupByLibrary.simpleMessage("Օգտվողի վերնագիր"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Օգտվողի վերնագիրը չի կարող լինել դատարկ"),
        "value": MessageLookupByLibrary.simpleMessage("Արժեք"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("VAT-ը չի կիրառվում"),
        "verifyOtp":
            MessageLookupByLibrary.simpleMessage("Ընտրված OTP-ը ստուգում"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Ստուգեք հեռախոսահամարը"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Դիտել բոլորը"),
        "viewDetails":
            MessageLookupByLibrary.simpleMessage("Տեսնել մանրամասները"),
        "walkInCustomer": MessageLookupByLibrary.simpleMessage(
            "Այն հաճախորդը, ով գալիս է առանց նախապես պատվիրելու"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Պահեստ"),
        "warehouseAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "Պահեստը արդեն գոյություն ունի"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("Գտնվող գույք"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("Պահեստի անուն"),
        "warranty": MessageLookupByLibrary.simpleMessage("Պատասխանատվություն"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Մենք ուղարկել ենք էլ. նամակ՝ պարունակող կարգավորումները փոխելու համար՝ այս հասցեով:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Մենք կարող ենք օգտագործել երրորդ կողմի ծառայություններ մեր հավելվածի գործառույթների աջակցելու համար, օրինակ՝ վերլուծական տրամադրողներ և վճարային պրոցեսորներ: Այս երրորդ կողմի ծառայությունները կարող են հավաքել տեղեկություններ ձեր մասին, երբ դուք օգտագործում եք մեր հավելվածը: Խնդրում ենք նկատի ունենալ, որ մենք պատասխանատու չենք այս երրորդ կողմի ծառայությունների գաղտնիության գործելաոճերի համար."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Մենք իրականացնում ենք արդյունաբերական ստանդարտների համապատասխան միջոցներ ձեր անձնական տեղեկատվությունը պաշտպանելու համար, այդ թվում՝ շ крипտում և անվտանգ պահեստավորում: Մենք նաև սահմանափակում ենք ձեր տեղեկատվության մուտքը միայն թույլատրված անձնակազմի համար."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Մենք հասկանում ենք անխափան գործողությունների կարևորությունը: Դրա համար մեր շուրջօրյա աջակցությունը հասանելի է ձեզ օգնություն ցույց տալու համար, թեև դա արագ հարց է, թե՞ համապարփակ խնդիր: Կապ հաստատեք մեզ հետ ցանկացած ժամանակ, ցանկացած տեղ՝ զանգահարելով կամ WhatsApp-ի միջոցով, որպեսզի զգաք անփոխարինելի հաճախորդի ծառայություն."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Մենք օգտագործում ենք ձեր անձնական տեղեկատվությունը, որպեսզի ձեզ առաջարկենք լավագույն հնարավոր փորձը մեր հավելվածում, այդ թվում՝ անձնակազմի խորհուրդների անհատականացում, մասնագետների հետ կապ ստեղծելը և մեր հավելվածի գործառույթների բարելավումը: Մենք կարող ենք նաև օգտագործել ձեր տեղեկատվությունը, որպեսզի կապ հաստատենք ձեզ մեր հավելվածի մասին թարմացումների, առաջխաղացումների կամ այլ տեղեկատվության վերաբերյալ."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Մենք կկայացնենք վճարման դիտարկումը և կհաստատենք այն 1-2 ժամվա ընթացքում"),
        "weekly": MessageLookupByLibrary.simpleMessage("Շաբաթական"),
        "weight": MessageLookupByLibrary.simpleMessage("Քաշ"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Ի՞նչ նորություն կա"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Մեծածախ վաճառող"),
        "wholeSalePrice": MessageLookupByLibrary.simpleMessage("Հունական գին"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("Մանրածախ գինը"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Մեծածախ"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Ավելացվելու է շուտով"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage(
            "Վավերականությունը ավարտվելու է"),
        "writeYourMessageHere": MessageLookupByLibrary.simpleMessage(
            "Նկարագրեք ձեր հաղորդագրությունը այստեղ"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("Սխալ OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Այդ օգտվողի համար սխալ գաղտնաբառ է տրամադրվել"),
        "yearly": MessageLookupByLibrary.simpleMessage("Տարեկան"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Այո, հանել հավիտյան"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("Դուք չեն բավականաչափ օգտվող"),
        "youAreUsing":
            MessageLookupByLibrary.simpleMessage("Դուք օգտագործում եք"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Դուք չեք կարող վճարել ավելի, քան պարտքը"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Դուք ունեք էլ. նամակ"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Դուք հաջողությամբ մուտք գործեցիք ձեր հաշիվը։ Մնացեք Pos Saas-ում։"),
        "youHaveToGivePermission": MessageLookupByLibrary.simpleMessage(
            "Դուք պետք է տաք թույլտվություն"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Դուք պետք է նորից մուտք գործեք ձեր հաշիվը."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Դուք պետք է հաստատեք ձեր ինքնությունը, նախքան SMS գնելու համար"),
        "yourMessageRemains": MessageLookupByLibrary.simpleMessage(
            "Ձեր հաղորդագրությունը մնում է"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Ձեր փաթեթը"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Ձեր փաթեթը կավարտվի 5 օրվա մեջ")
      };
}
