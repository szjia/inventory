// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a hu locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'hu';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Folytatás"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("GST szám"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("Az MRP kötelező"),
        "OK": MessageLookupByLibrary.simpleMessage("OK"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Ph.no"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT Kód"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Snackek"),
        "TAX": MessageLookupByLibrary.simpleMessage("ADÓ"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Feltöltés"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("Felhasználói cím"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Az Ön Csomagja Ma Lejár\n\nKérjük, Vásárolja újra"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) A Rendszer kizárólag azért került létrehozásra, hogy segítse az értékesítési ponton történő tranzakciókat és azokkal kapcsolatos tevékenységeket az Ön vállalkozásában."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) A Rendszer használatához lehet, hogy fiókot kell létrehoznia. Elfogadja, hogy pontos, naprakész és teljes információkat kell megadnia a regisztrációs folyamat során, és frissíteni kell az ilyen információkat azok naprakésszé és teljessé tétele érdekében."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("Az alkalmazásról"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Rólunk"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Feltételek elfogadása"),
        "accountName": MessageLookupByLibrary.simpleMessage("Számla neve"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("Számla száma"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Fiók regisztráció"),
        "acton": MessageLookupByLibrary.simpleMessage("Cselekvés"),
        "add": MessageLookupByLibrary.simpleMessage("Hozzáadás"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Márka hozzáadása"),
        "addCategory":
            MessageLookupByLibrary.simpleMessage("Kategória hozzáadása"),
        "addContact":
            MessageLookupByLibrary.simpleMessage("Kapcsolat hozzáadása"),
        "addCustomer":
            MessageLookupByLibrary.simpleMessage("Ügyfél hozzáadása"),
        "addDelivery":
            MessageLookupByLibrary.simpleMessage("Szállítás hozzáadása"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Leírás hozzáadása"),
        "addDescription":
            MessageLookupByLibrary.simpleMessage("Megjegyzés hozzáadása"),
        "addDiscount":
            MessageLookupByLibrary.simpleMessage("Kedvezmény hozzáadása"),
        "addDocumentId": MessageLookupByLibrary.simpleMessage(
            "Dokumentum Azonosító Hozzáadása"),
        "addDucument":
            MessageLookupByLibrary.simpleMessage("Dokumentum Hozzáadása"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Kiadás hozzáadása"),
        "addExpenseCategory": MessageLookupByLibrary.simpleMessage(
            "Kiadási kategória hozzáadása"),
        "addItems": MessageLookupByLibrary.simpleMessage("Tételek hozzáadása"),
        "addNew": MessageLookupByLibrary.simpleMessage("Új hozzáadása"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Új cím hozzáadása"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Új termék hozzáadása"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("Új adó hozzáadása"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Új adó hozzáadása egyetlen/több adó típussal"),
        "addNote":
            MessageLookupByLibrary.simpleMessage("Megjegyzés hozzáadása"),
        "addProductFirst": MessageLookupByLibrary.simpleMessage(
            "Először adjon hozzá egy terméket"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Promóciós kód hozzáadása"),
        "addPurchase":
            MessageLookupByLibrary.simpleMessage("Vásárlás hozzáadása"),
        "addSales":
            MessageLookupByLibrary.simpleMessage("Értékesítés Hozzáadása"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Sikeres hozzáadás"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Egység hozzáadása"),
        "addUserRole": MessageLookupByLibrary.simpleMessage(
            "Felhasználói szerep hozzáadása"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Sikeresen hozzáadva"),
        "addedToCart": MessageLookupByLibrary.simpleMessage("Kosárba téve"),
        "address": MessageLookupByLibrary.simpleMessage("Cím"),
        "admin": MessageLookupByLibrary.simpleMessage("Admin"),
        "all": MessageLookupByLibrary.simpleMessage("Mind"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("Minden üzleti megoldás"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("Már hozzáadva"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Már létezik"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Már van fiókod?"),
        "amount": MessageLookupByLibrary.simpleMessage("Összeg"),
        "anEmailHasBeenSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "Egy e-mailt küldtünk\\nEllenőrizze a beérkező levelek mappáját"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Android és iOS alkalmazás támogatás"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Alkalmazható adó"),
        "apply": MessageLookupByLibrary.simpleMessage("Alkalmaz"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Biztosan törli ezt a számlát?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Biztosan törli ezt az eladást?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Biztosan törölni akarja ezt a felhasználót?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Biztosan törölni akarja ezt az adót?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Biztosan törölni akarja ezt az adócsoportot?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Biztosan törölni akarja ezt a raktárt?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Biztos vagy benne, hogy törölni szeretnéd ezt a felhasználót?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Megtakarított aláírás"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Ön felelős a fiókjának és jelszavának bizalmas kezeléséért, és a fiókjához való hozzáférés korlátozásáért. Elfogadja a felelősséget az összes olyan tevékenységért, amely a fiókjában történik."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Az Rendszer használatához legalább 18 évesnek kell lennie, vagy az Ön joghatóságában érvényes legnagyobb életkornak kell megfelelnie."),
        "backSide": MessageLookupByLibrary.simpleMessage("Hátlap"),
        "backToHome":
            MessageLookupByLibrary.simpleMessage("Vissza a Főoldalra"),
        "balance": MessageLookupByLibrary.simpleMessage("Egyenleg"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Banglades"),
        "bank": MessageLookupByLibrary.simpleMessage("Bank"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Banki Számla Pénznem"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Bank számla pénzneme"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Bank információk"),
        "bankName": MessageLookupByLibrary.simpleMessage("Bank neve"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("Banki Átutalás"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Vonalkód megtalálva"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Számla/Invoice"),
        "billTo": MessageLookupByLibrary.simpleMessage("Számlázás címe"),
        "branchName": MessageLookupByLibrary.simpleMessage("Fiók neve"),
        "brand": MessageLookupByLibrary.simpleMessage("Márka"),
        "brandName": MessageLookupByLibrary.simpleMessage("Márka neve"),
        "bulkUpload":
            MessageLookupByLibrary.simpleMessage("Tömeges \nFeltöltés"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Vállalkozás kategória"),
        "buy": MessageLookupByLibrary.simpleMessage("Vásárlás"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Prémium Terv Vásárlása"),
        "buySms": MessageLookupByLibrary.simpleMessage("SMS Vásárlása"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "A [Your Company Name] („Vállalat”) által biztosított Értékesítési Pont (POS) Rendszerhez (a „Rendszerhez”) való hozzáféréssel vagy használattal elfogadja ezeket a Felhasználási Feltételeket. Ha nem ért egyet ezekkel a Felhasználási Feltételekkel, ne használja a Rendszert."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Ön felelős azért, hogy biztosítsa a Rendszerhez való hozzáférését és használatát az összes alkalmazandó törvény és rendelet betartásával."),
        "cacel": MessageLookupByLibrary.simpleMessage("Mégse"),
        "call": MessageLookupByLibrary.simpleMessage("Hívás"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "Hívjon sürgősségi támogatásért"),
        "camera": MessageLookupByLibrary.simpleMessage("Kamera"),
        "cancel": MessageLookupByLibrary.simpleMessage("Mégsem"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Minden termék törlése"),
        "capacity": MessageLookupByLibrary.simpleMessage("Kapacitás"),
        "card": MessageLookupByLibrary.simpleMessage("Kártya"),
        "cash": MessageLookupByLibrary.simpleMessage("Készpénz"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Kategóriák"),
        "category": MessageLookupByLibrary.simpleMessage("Kategória"),
        "categoryName": MessageLookupByLibrary.simpleMessage("Kategória neve"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "A kategória neve már létezik"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("Kategória neve"),
        "change": MessageLookupByLibrary.simpleMessage("Változtatni?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Jelszó módosítása"),
        "checkEmail":
            MessageLookupByLibrary.simpleMessage("Ellenőrizd az e-mailt"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Válassz ügyfelet"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Válassz beszállítót"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Válassza ki a funkciókat"),
        "clarence": MessageLookupByLibrary.simpleMessage("Clarence"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Kattints a kapcsolódáshoz"),
        "close": MessageLookupByLibrary.simpleMessage("Bezárás"),
        "color": MessageLookupByLibrary.simpleMessage("Szín"),
        "combinationOfMultipleTaxes":
            MessageLookupByLibrary.simpleMessage("(Több adó kombinációja)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Hamarosan"),
        "companyAddress": MessageLookupByLibrary.simpleMessage("Cég címe"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Cég és bolt neve"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("Cég és Üzleti Név"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Tranzakció Befejezése"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Jelszó megerősítése"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Visszatérés megerősítése"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Gratulálunk"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Kapcsolatfelvétel"),
        "continu": MessageLookupByLibrary.simpleMessage("Folytatás"),
        "country": MessageLookupByLibrary.simpleMessage("Ország"),
        "create": MessageLookupByLibrary.simpleMessage("Létrehozás"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Ingyenes fiók létrehozása"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Létrehozva és mentve"),
        "currency": MessageLookupByLibrary.simpleMessage("Valuta"),
        "currentStock":
            MessageLookupByLibrary.simpleMessage("Jelenlegi Készlet"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("Egyedi számlabranding"),
        "customer": MessageLookupByLibrary.simpleMessage("Ügyfél"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Vásárló adatai"),
        "customerGST": MessageLookupByLibrary.simpleMessage("Ügyfél GST"),
        "customerName": MessageLookupByLibrary.simpleMessage("Ügyfél neve"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Napi tranzakció"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Irányítópult áttekintése"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Adatok sikeresen mentve"),
        "date": MessageLookupByLibrary.simpleMessage("Dátum"),
        "day": MessageLookupByLibrary.simpleMessage("Nap"),
        "dealer": MessageLookupByLibrary.simpleMessage("Viszonteladó"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("Viszonteladói ár"),
        "defaultVATPercentage": MessageLookupByLibrary.simpleMessage(
            "Alapértelmezett ÁFA százalék"),
        "delete": MessageLookupByLibrary.simpleMessage("Törlés"),
        "deleting": MessageLookupByLibrary.simpleMessage("Törlés"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Szállítási cím"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Szállítási címek"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Szállítási díj"),
        "describtion": MessageLookupByLibrary.simpleMessage("Leírás"),
        "description": MessageLookupByLibrary.simpleMessage("Leírás"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("A leírás nem lehet üres"),
        "details": MessageLookupByLibrary.simpleMessage("Részletek"),
        "discount": MessageLookupByLibrary.simpleMessage("Kedvezmény"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Ne Zavarjanak"),
        "done": MessageLookupByLibrary.simpleMessage("Kész"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Excel formátum letöltése"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Sikeresen letöltve a letöltési mappába"),
        "due": MessageLookupByLibrary.simpleMessage("Esedékesség"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Esedékes összeg: "),
        "dueCollection":
            MessageLookupByLibrary.simpleMessage("Esedékességek behajtása"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("Lejárt beszedési jelentések"),
        "dueList":
            MessageLookupByLibrary.simpleMessage("Esedékességek listája"),
        "dueReports": MessageLookupByLibrary.simpleMessage("Fizetési Jelentés"),
        "duration": MessageLookupByLibrary.simpleMessage("Időtartam"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Időtartam: Től"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "Könnyen használható mobil pénztár"),
        "edit": MessageLookupByLibrary.simpleMessage("Szerkesztés"),
        "editPurchaseInvoice": MessageLookupByLibrary.simpleMessage(
            "Vásárlási Számla Szerkesztése"),
        "editSalesInvoice": MessageLookupByLibrary.simpleMessage(
            "Értékesítési Számla Szerkesztése"),
        "editSocailMedia": MessageLookupByLibrary.simpleMessage(
            "Szociális média szerkesztése"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Sikeres szerkesztés"),
        "editTax": MessageLookupByLibrary.simpleMessage("Adó szerkesztése"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Adócsoport szerkesztése"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("Raktár szerkesztése"),
        "email": MessageLookupByLibrary.simpleMessage("E-mail"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("E-mail cím"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Az e-mail nem lehet üres"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "Email elküldve! Ellenőrizze a beérkezett üzeneteket"),
        "endDate": MessageLookupByLibrary.simpleMessage("Végső dátum"),
        "enterAValidAmount": MessageLookupByLibrary.simpleMessage(
            "Adjon meg egy érvényes összeget"),
        "enterAValidDiscount": MessageLookupByLibrary.simpleMessage(
            "Adjon meg egy érvényes kedvezményt"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Adjon meg egy érvényes telefonszámot"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Adjon meg egy érvényes árat"),
        "enterAValidQuantity": MessageLookupByLibrary.simpleMessage(
            "Adjon meg egy érvényes mennyiséget"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("Add meg a címet"),
        "enterAmount":
            MessageLookupByLibrary.simpleMessage("Add meg az összeget"),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Add meg a márka nevét"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Add meg a kapacitást"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Add meg a kategória nevét"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Add meg a színt"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "Adja meg az ügyfél GST számát"),
        "enterDealerPrice": MessageLookupByLibrary.simpleMessage(
            "Add meg a viszonteladói árat"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Adja meg a leírást"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("Add meg a kedvezményt."),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Add meg a kiadás dátumát"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Add meg a teljes címet"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Adja meg a számlaszámot"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Adja meg az alacsony készlet figyelmeztetési mennyiséget"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Add meg a gyártót"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("Írja be az üzenet tartalmát"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "Add meg az MRP/Kiskereskedelmi árat"),
        "enterName": MessageLookupByLibrary.simpleMessage("Add meg a nevet"),
        "enterNote":
            MessageLookupByLibrary.simpleMessage("Add meg a megjegyzést"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Add meg a fél nevét"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Add meg a telefonszámot"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Add meg a termékkódot vagy olvasd be"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Add meg a termék nevét"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Add meg a beszerzési árat."),
        "enterReferenceNumber": MessageLookupByLibrary.simpleMessage(
            "Add meg a hivatkozási számot"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Add meg a méretet"),
        "enterStocks":
            MessageLookupByLibrary.simpleMessage("Add meg a készletet."),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Adókulcs megadása"),
        "enterTransactionId": MessageLookupByLibrary.simpleMessage(
            "Adja meg a tranzakciós azonosítót"),
        "enterType": MessageLookupByLibrary.simpleMessage("Add meg a típust"),
        "enterUserTitle": MessageLookupByLibrary.simpleMessage(
            "Adja meg a felhasználói címet"),
        "enterValidAmount": MessageLookupByLibrary.simpleMessage(
            "Kérjük, adjon meg egy érvényes összeget"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Adja meg a raktár nevét"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Add meg a súlyt"),
        "enterWholeSalePrice": MessageLookupByLibrary.simpleMessage(
            "Add meg a nagykereskedelmi árat"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("Adja meg a leírást itt"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("Add meg az e-mail címedet"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "Adja meg a visszajelzés címét"),
        "enterYourGSTNumber": MessageLookupByLibrary.simpleMessage(
            "Kérjük, adja meg a GST számát"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("Adja meg mobiltelefonszámát"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Add meg a neved"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("Add meg a telefonszámod"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Adja meg a jelszavát"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Add meg a telefonszámod"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "Adja meg a tranzakció azonosítóját"),
        "error": MessageLookupByLibrary.simpleMessage("Hiba"),
        "excTax": MessageLookupByLibrary.simpleMessage("Adó nélkül"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("Excel Feltöltő"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Kizáró"),
        "expense": MessageLookupByLibrary.simpleMessage("Kiadás"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Kiadási kategória"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Kiadás dátuma"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Kiadás célja"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Kiadás jelentés"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Lejárati dátum"),
        "expired": MessageLookupByLibrary.simpleMessage("Lejárt"),
        "expiring": MessageLookupByLibrary.simpleMessage("Lejáró"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError": MessageLookupByLibrary.simpleMessage("Hiba történt"),
        "fashion": MessageLookupByLibrary.simpleMessage("Divat"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "A funkciók azok a fontos részek, amelyek megkülönböztetik a Pos Saas-t a hagyományos megoldásoktól."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Visszajelzés"),
        "firstName": MessageLookupByLibrary.simpleMessage("Keresztnév"),
        "followUsOnFacebook": MessageLookupByLibrary.simpleMessage(
            "Kövessen minket a\\nFacebookon"),
        "followUsOnTwitter": MessageLookupByLibrary.simpleMessage(
            "Kövessen minket a\\nTwitteren"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Előlap"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("Korlátlan használathoz"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Elfelejtett jelszó"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Elfelejtett jelszó?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Kezdő dátum"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("Ingyenes adatmentés"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "Ingyenes élettartam frissítés"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Ingyenes Csomag"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Ingyenes Terv"),
        "from": MessageLookupByLibrary.simpleMessage("(Től"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Teljesen Kifizetve"),
        "gallary": MessageLookupByLibrary.simpleMessage("Galéria"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("PDF Generálása"),
        "getOtp": MessageLookupByLibrary.simpleMessage("OTP lekérése"),
        "govermentId":
            MessageLookupByLibrary.simpleMessage("Kormányzati Azonosító"),
        "guest": MessageLookupByLibrary.simpleMessage("Vendég"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Nincs még fiókod?"),
        "history": MessageLookupByLibrary.simpleMessage("Előzmények"),
        "home": MessageLookupByLibrary.simpleMessage("Főoldal"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Hogyan védelmezzük az Ön információit"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Hogyan használjuk az Ön információit"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Azonosság Ellenőrzése"),
        "image": MessageLookupByLibrary.simpleMessage("Kép"),
        "inHouseCantBeDelete": MessageLookupByLibrary.simpleMessage(
            "A helyszíni adat nem törölhető"),
        "inHouseCantBeEdited": MessageLookupByLibrary.simpleMessage(
            "A helyszíni adat nem szerkeszthető"),
        "inWord": MessageLookupByLibrary.simpleMessage("Szóban"),
        "incTax": MessageLookupByLibrary.simpleMessage("Adóval együtt"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Befoglaló"),
        "increaseStock":
            MessageLookupByLibrary.simpleMessage("Készlet növelése"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Eszköz"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Számla szám"),
        "invoice": MessageLookupByLibrary.simpleMessage("Számla"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("Számlaszám"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Számla Beállítás"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Számla megtekintő"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Tétel hozzáadva"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("KYC Ellenőrzés"),
        "language": MessageLookupByLibrary.simpleMessage("Nyelv"),
        "lastName": MessageLookupByLibrary.simpleMessage("Vezetéknév"),
        "ledger": MessageLookupByLibrary.simpleMessage("Könyvelés"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Életre Szóló\nVásárlás"),
        "link": MessageLookupByLibrary.simpleMessage("Link"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Élő Chat Támogatás"),
        "loading": MessageLookupByLibrary.simpleMessage("Betöltés"),
        "logIn": MessageLookupByLibrary.simpleMessage("Bejelentkezés"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Kijelentkezés"),
        "logOut": MessageLookupByLibrary.simpleMessage("Kijelentkezés"),
        "login": MessageLookupByLibrary.simpleMessage("Bejelentkezés"),
        "logo": MessageLookupByLibrary.simpleMessage("Logó"),
        "loss": MessageLookupByLibrary.simpleMessage("Veszteség"),
        "lossOrProfit":
            MessageLookupByLibrary.simpleMessage("Veszteség/Nyerés"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Veszteség/Nyerés részletei"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Veszteség/Nyereség Jelentés"),
        "lossProfitReports": MessageLookupByLibrary.simpleMessage(
            "Veszteség/Nyereség Jelentések"),
        "lowStockAlert": MessageLookupByLibrary.simpleMessage(
            "Alacsony készlet figyelmeztetés"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Hagyjon maradandó benyomást a vásárlóinál személyre szabott számlákkal. Korlátlan frissítésünk lehetővé teszi számláinak testreszabását, professzionális érintést adva, amely megerősíti a márkaidentitását és ügyfélhűséget teremt."),
        "manageYourBussinessWith": MessageLookupByLibrary.simpleMessage(
            "Vállalkozásod kezelése a következő segítségével: "),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Gyártási dátum"),
        "margin": MessageLookupByLibrary.simpleMessage("Haszon"),
        "masterCard": MessageLookupByLibrary.simpleMessage("Mastercard"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Gyártó"),
        "message": MessageLookupByLibrary.simpleMessage("Üzenet"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Üzenet Előzmények"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "A Pos Saas alkalmazás ingyenes és könnyen használható. Valójában ez az egyik legjobb POS rendszer a világon."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "A Pos Saas teljes üzleti megoldás készlettel, számlával, értékesítéssel, költségekkel és veszteséggel / nyereséggel."),
        "mobile": MessageLookupByLibrary.simpleMessage("Mobil"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("Mobilfizetés"),
        "monthly": MessageLookupByLibrary.simpleMessage("Havi"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("További információ"),
        "name": MessageLookupByLibrary.simpleMessage("Add meg a neved"),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("A név már létezik"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("A név nem lehet üres"),
        "next": MessageLookupByLibrary.simpleMessage("Következő"),
        "noConnection": MessageLookupByLibrary.simpleMessage("Nincs kapcsolat"),
        "noData": MessageLookupByLibrary.simpleMessage("Nincs Adat"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Nincs elérhető adat"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Nincs adat található"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("Nincs Előzmény!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Nem található termék"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("Nincs kiválasztva aladó"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("Nincs Tranzakció!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Nem található felhasználó ehhez az e-mail címhez."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "Nincs felhasználói szerep található"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Nem Aktív Felhasználó"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Nem biztosított"),
        "note": MessageLookupByLibrary.simpleMessage("Megjegyzés"),
        "notes": MessageLookupByLibrary.simpleMessage("Megjegyzések"),
        "notification": MessageLookupByLibrary.simpleMessage("Értesítés"),
        "oTPSentTo":
            MessageLookupByLibrary.simpleMessage("Az OTP-t elküldtük ide:"),
        "office": MessageLookupByLibrary.simpleMessage("Iroda"),
        "ok": MessageLookupByLibrary.simpleMessage("Rendben"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "A POS rendszer sok funkciót tartalmaz, ideértve az értékesítés nyomon követését és az állománykezelést."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Ez a rendszer segít javítani az Ön műveleteit az ügyfelek számára."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Az POS rendszerünk automatikusan egyszerűsíteni kell a mindennapi műveleteket, így könnyebbé teszi a navigációt."),
        "openingBalance": MessageLookupByLibrary.simpleMessage("Első egyenleg"),
        "order": MessageLookupByLibrary.simpleMessage("Rendelések"),
        "other": MessageLookupByLibrary.simpleMessage("Egyéb"),
        "otp": MessageLookupByLibrary.simpleMessage("Bezár"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Készleten kívül"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Csomag"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Csomag Funkciók"),
        "paid": MessageLookupByLibrary.simpleMessage("Fizetve"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Kifizetett összeg"),
        "parties": MessageLookupByLibrary.simpleMessage("Felek"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Fél listája"),
        "partyGST": MessageLookupByLibrary.simpleMessage("Fél GST"),
        "partyName": MessageLookupByLibrary.simpleMessage("Fél neve"),
        "password": MessageLookupByLibrary.simpleMessage("Jelszó"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "A jelszó és a megerősítő jelszó nem egyezik"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("A jelszó nem lehet üres"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("A jelszó nem egyezik"),
        "payCash": MessageLookupByLibrary.simpleMessage("Készpénzes fizetés"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("Fizetés bkash-szal"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Fizetés Paypal-lal"),
        "payeeName":
            MessageLookupByLibrary.simpleMessage("Kedvezményezett Neve"),
        "payeeNumber":
            MessageLookupByLibrary.simpleMessage("Kedvezményezett Száma"),
        "payment": MessageLookupByLibrary.simpleMessage("Fizetés"),
        "paymentAmount":
            MessageLookupByLibrary.simpleMessage("Fizetés összege"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Fizetés teljesítve"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Fizetési Utasítás:"),
        "paymentMethod":
            MessageLookupByLibrary.simpleMessage("Fizetési Módszer"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Fizetési mód"),
        "pdfView": MessageLookupByLibrary.simpleMessage("PDF Nézet"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Személyes információ"),
        "phone": MessageLookupByLibrary.simpleMessage("Telefon"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Telefonszám"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "A telefonszám már használatban van"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("A telefonszám nem érvényes"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("A telefonszám kötelező"),
        "pickAndUploadFile": MessageLookupByLibrary.simpleMessage(
            "Fájl kiválasztása és feltöltése"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("Válassz végső dátumot"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Válassz kezdő dátumot"),
        "plan": MessageLookupByLibrary.simpleMessage("Terv"),
        "pleaseAddQuantity": MessageLookupByLibrary.simpleMessage(
            "Kérjük, adjon meg mennyiséget"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Kérlek, ellenőrizd az internetkapcsolatod"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Kérjük, először csatlakoztassa a nyomtatót"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Kérlek, csatlakoztasd a Bluetooth nyomtatódat"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Kérjük, adjon meg egy hosszabb jelszót"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Kérlek, add meg a jelszó megerősítését"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("Kérlek, adj meg egy jelszót"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Kérjük, adjon meg egy érvényes e-mail címet"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Kérjük, adja meg a nevét"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("Kérjük, adja meg a jelszót"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Kérlek, add meg az e-mail címedet az alábbiakban a jelszó visszaállítási link megkapásához."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Kérjük, adja meg a tranzakció számát"),
        "pleaseInterAmount": MessageLookupByLibrary.simpleMessage(
            "Kérjük, adja meg az összeget"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Kérjük, először válasszon ki egy kategóriát"),
        "pleaseSelectAPlan": MessageLookupByLibrary.simpleMessage(
            "Kérjük, válasszon egy tervet"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Kérjük, válassza ki az üzleti kategóriát"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Kérjük, használjon érvényes vásárlási kódot az alkalmazás használatához"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Powered By Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Powered By"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Prémium ügyféltámogatás"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Prémium Terv"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Korábbi Fizetési Összegek"),
        "price": MessageLookupByLibrary.simpleMessage("Ár"),
        "print": MessageLookupByLibrary.simpleMessage("Nyomtatás"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Nyomtatási Beállítás"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Adatvédelmi irányelvek"),
        "product": MessageLookupByLibrary.simpleMessage("Termék"),
        "productCode": MessageLookupByLibrary.simpleMessage("Termékkód"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("A termékkód kötelező"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Termék kód/Név"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Termék Leírás"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Termék részletei"),
        "productList": MessageLookupByLibrary.simpleMessage("Terméklista"),
        "productName": MessageLookupByLibrary.simpleMessage("Termék neve"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "A termék neve már létezik ebben a raktárban"),
        "productNameIsAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("A termék neve már hozzáadva"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("A termék neve kötelező"),
        "products": MessageLookupByLibrary.simpleMessage("Termékek"),
        "profile": MessageLookupByLibrary.simpleMessage("Profil"),
        "profileEdit":
            MessageLookupByLibrary.simpleMessage("Profil szerkesztése"),
        "profit": MessageLookupByLibrary.simpleMessage("Nyerés"),
        "promo": MessageLookupByLibrary.simpleMessage("promóció"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Promóciós Kód"),
        "purchase": MessageLookupByLibrary.simpleMessage("Vásárlás"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("Vásárlás riasztás"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Vásárlás megerősítve"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Vásárlás részletei"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Vásárlási Számla"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("Vásárlás lista"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Vásárolj most"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Prémium Terv Vásárlása"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("Beszerzési ár"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("A beszerzési ár kötelező"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Beszerzési jelentések"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Vásárlási jelentések"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("Vásárlási Visszatérés"),
        "purchaseReturnReport": MessageLookupByLibrary.simpleMessage(
            "Vásárlási Visszatérítési Jelentés"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Vásárlási Átmenet"),
        "qty": MessageLookupByLibrary.simpleMessage("Mennyiség"),
        "quantity": MessageLookupByLibrary.simpleMessage("Mennyiség"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Legutóbbi tranzakciók"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("Megkaptuk a PIN-t"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Hivatkozási szám"),
        "register": MessageLookupByLibrary.simpleMessage("Regisztráció"),
        "registering": MessageLookupByLibrary.simpleMessage("Regisztrálás"),
        "remainingDue":
            MessageLookupByLibrary.simpleMessage("Hátralék maradék"),
        "remove": MessageLookupByLibrary.simpleMessage("Eltávolítás"),
        "reports": MessageLookupByLibrary.simpleMessage("Jelentések"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Kérés elküldve"),
        "resendCode": MessageLookupByLibrary.simpleMessage("Kód újraküldése"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("OTP újraküldése: "),
        "retailer": MessageLookupByLibrary.simpleMessage("Kiskereskedő"),
        "retur": MessageLookupByLibrary.simpleMessage("Visszatérés"),
        "returnAMount":
            MessageLookupByLibrary.simpleMessage("Visszatérített összeg"),
        "returnAmount":
            MessageLookupByLibrary.simpleMessage("Visszatérítés Összege"),
        "returnQTY":
            MessageLookupByLibrary.simpleMessage("Visszatérítési Mennyiség"),
        "revenue": MessageLookupByLibrary.simpleMessage("Bevétel"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Védje vállalkozása adatait könnyedén. Pos Saas POS Korlátlan Frissítésünk tartalmazza az ingyenes adatmentést, amely biztosítja az értékes információk védelmét minden előre nem látható eseménnyel szemben. Koncentráljon arra, ami valóban fontos - vállalkozása növekedésére."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Eladási Összeg"),
        "saleDetails":
            MessageLookupByLibrary.simpleMessage("Értékesítés Részletei"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Eladási ár"),
        "saleReports":
            MessageLookupByLibrary.simpleMessage("Értékesítési Jelentés"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Értékesítési jelentések"),
        "saleReturn":
            MessageLookupByLibrary.simpleMessage("Eladási Visszatérés"),
        "saleReturnReport": MessageLookupByLibrary.simpleMessage(
            "Eladási Visszatérítési Jelentés"),
        "saleSetting":
            MessageLookupByLibrary.simpleMessage("Eladási Beállítás"),
        "sales": MessageLookupByLibrary.simpleMessage("Értékesítés"),
        "salesAndPurchaseReports": MessageLookupByLibrary.simpleMessage(
            "Értékesítési és beszerzési jelentések"),
        "salesList": MessageLookupByLibrary.simpleMessage("Értékesítési Lista"),
        "salesReturn":
            MessageLookupByLibrary.simpleMessage("Eladási Visszatérés"),
        "save": MessageLookupByLibrary.simpleMessage("Mentés"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Mentés és Közzététel"),
        "saveChanges":
            MessageLookupByLibrary.simpleMessage("Változások Mentése"),
        "saving": MessageLookupByLibrary.simpleMessage("Mentés"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("Termék QR-kód beolvasása"),
        "search": MessageLookupByLibrary.simpleMessage("Keresés"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Keresés termék kód vagy név alapján"),
        "seeAllPromoCode": MessageLookupByLibrary.simpleMessage(
            "Az összes promóciós kód megtekintése"),
        "select": MessageLookupByLibrary.simpleMessage("Kiválasztás"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Válasszon ki egy terméket a visszatéréshez"),
        "selectBrand":
            MessageLookupByLibrary.simpleMessage("Márka kiválasztása"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Kategória kiválasztása"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Kapcsolatok Kiválasztása"),
        "selectProductCategory": MessageLookupByLibrary.simpleMessage(
            "Termékkategória kiválasztása"),
        "selectShopCategory": MessageLookupByLibrary.simpleMessage(
            "Válassza ki az üzlet kategóriát"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Adó kiválasztása"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Adótípus kiválasztása"),
        "selectUnit":
            MessageLookupByLibrary.simpleMessage("Mértékegység kiválasztása"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Válassz változatot:"),
        "seller": MessageLookupByLibrary.simpleMessage("Eladó"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Eladó"),
        "send": MessageLookupByLibrary.simpleMessage("Küldés"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("E-mail küldése"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Üzenet Küldése"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("Visszaállító link küldése"),
        "sendSms": MessageLookupByLibrary.simpleMessage("SMS küldése"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Küldjön SMS-t?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Whatsapp üzenet küldése"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Az Ön Email Címének Küldése"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage("Email küldése"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Üzenet küldése"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Szolgáltatás/Szállítás"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Profil beállítása"),
        "setting": MessageLookupByLibrary.simpleMessage("Beállítások"),
        "share": MessageLookupByLibrary.simpleMessage("Megosztás"),
        "shopGST": MessageLookupByLibrary.simpleMessage("Bolt GST"),
        "signIn": MessageLookupByLibrary.simpleMessage("Bejelentkezés"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("Bejelentkezés e-maillel"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Vevő aláírása"),
        "size": MessageLookupByLibrary.simpleMessage("Méret"),
        "skip": MessageLookupByLibrary.simpleMessage("Kihagyás"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Társadalmi marketing"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Sajnálom, nincs engedélye ennek a szolgáltatásnak a használatára"),
        "startDate": MessageLookupByLibrary.simpleMessage("Kezdő dátum"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Új értékesítés indítása"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage(
            "Kezdj el gépelni a kereséshez"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Maradjon a technológiai fejlesztések élén, további költségek nélkül. A Pos Saas POS Korlátlan Frissítés biztosítja, hogy mindig a legújabb eszközök és funkciók álljanak rendelkezésére, így vállalkozása mindig a legkorszerűbb marad."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("Még Kifizetetlen"),
        "stock": MessageLookupByLibrary.simpleMessage("Készlet"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("A készlet kötelező"),
        "stockList": MessageLookupByLibrary.simpleMessage("Készletlista"),
        "stocks": MessageLookupByLibrary.simpleMessage("Készletek"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Tárolási engedély szükséges az Excel fájl létrehozásához"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("Aladó Lista"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Aladó"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Részösszeg"),
        "submit": MessageLookupByLibrary.simpleMessage("Beküldés"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "Iratkozzon fel a\\nYoutube csatornánkra"),
        "subscription": MessageLookupByLibrary.simpleMessage("Előfizetés"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Sikeresen megtörtént"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Sikeresen kijelentkezett"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Sikeresen frissítve"),
        "supplier": MessageLookupByLibrary.simpleMessage("Beszállító"),
        "supplierName": MessageLookupByLibrary.simpleMessage("Beszállító neve"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT kód"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Fényképezzen be egy jogosítványt, személyi igazolványt vagy útlevél fényképet"),
        "takeaNidCardToCheckYourInformation": MessageLookupByLibrary.simpleMessage(
            "Hozzon magával személyi igazolványt az információk ellenőrzéséhez"),
        "tap": MessageLookupByLibrary.simpleMessage("Érintse meg"),
        "tax": MessageLookupByLibrary.simpleMessage("Adó"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Adócsoport"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("Adó százalék"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Adókulcs"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Adókulcsok - Kezelje az adókulcsait"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Adójelentés"),
        "taxType": MessageLookupByLibrary.simpleMessage("Adótípus"),
        "taxes": MessageLookupByLibrary.simpleMessage("Adók"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Felhasználási feltételek"),
        "termsOfUse":
            MessageLookupByLibrary.simpleMessage("Felhasználási feltételek"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Feltételek & Adatvédelem"),
        "thankYOuForYourDuePayment":
            MessageLookupByLibrary.simpleMessage("Köszönjük a hátralékot"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Köszönjük"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Köszönjük a vásárlást"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "A fiók már létezik ehhez az e-mailhez"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Az Excel fájl már letöltésre került"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "A név mindent elmond. A Pos Saas POS Korlátlan lehetővé teszi az Ön használatának korlátlanítását. Legyen szó néhány tranzakció feldolgozásáról vagy ügyfelek rohamáról, magabiztosan működhet, tudva, hogy nincsenek korlátok."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "A megadott jelszó túl gyenge"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Az eladás törlésre kerül, és minden adat törlődik erről a vásárlásról. Biztosan törli ezt?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Az eladás törlésre kerül, és minden adat törlődik erről az eladásról. Biztosan törli ezt?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "A felhasználó törlődik, és az összes adat törlődik a fiókodból. Biztosan törölni szeretnéd?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "A felhasználó törlésre kerül, és az összes adat törlődik a fiókjából. Biztos benne, hogy törölni akarja?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Harmadik fél szolgáltatásai"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Ez a kategória nem törölhető"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(E hónap)"),
        "thisProductAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("Ez a termék már hozzáadva"),
        "title": MessageLookupByLibrary.simpleMessage("Cím"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("A cím nem lehet üres"),
        "to": MessageLookupByLibrary.simpleMessage("ig"),
        "toDate": MessageLookupByLibrary.simpleMessage("Végső dátum"),
        "today": MessageLookupByLibrary.simpleMessage("Ma"),
        "total": MessageLookupByLibrary.simpleMessage("Összesen"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Teljes összeg"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Összesen Gyűjtött"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Teljes hátralék"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("Összes kiadás"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Összes veszteség"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("Fizetendő összesen"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Teljes ár"),
        "totalProducts": MessageLookupByLibrary.simpleMessage("Összes termék"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Összes nyereség"),
        "totalPurchase":
            MessageLookupByLibrary.simpleMessage("Összes Vásárlás"),
        "totalReturnAmount": MessageLookupByLibrary.simpleMessage(
            "Összes Visszatérítési Összeg"),
        "totalReturns":
            MessageLookupByLibrary.simpleMessage("Összes Visszatérés"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Összes értékesítés"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Teljes Készlet"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Összérték"),
        "totalVat": MessageLookupByLibrary.simpleMessage("ÁFA összesen"),
        "totals": MessageLookupByLibrary.simpleMessage("Összesen: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Tranzakció"),
        "transactionId":
            MessageLookupByLibrary.simpleMessage("Tranzakció Azonosító"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Próbáld újra"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Típus"),
        "unitName": MessageLookupByLibrary.simpleMessage("Egység Neve"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Egységár"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Egységár"),
        "units": MessageLookupByLibrary.simpleMessage("Egységek"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Korlátlan"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Korlátlan használat"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Oldja fel a Pos Saas POS teljes potenciálját személyre szabott tréningekkel, amelyeket szakértő csapatunk vezet. Az alapoktól az előrehaladott technikákig biztosítjuk, hogy jól felkészülten használja a rendszer minden részét a vállalkozási folyamatai optimalizálásához."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Fizetetlen"),
        "update": MessageLookupByLibrary.simpleMessage("Frissítés"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Kapcsolat frissítése"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Most frissít"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("Termék frissítése"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Először frissítse a tervét,\\na limitje lejárt"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Profil frissítése"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Frissítsd a profilodat, hogy jobb benyomást kelts a kapcsolódó orvosnak"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Frissítsd a profilodat, hogy jobb benyomást kelts ügyfeleidnél"),
        "updated": MessageLookupByLibrary.simpleMessage("Frissítve"),
        "upload": MessageLookupByLibrary.simpleMessage("Feltöltés"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Dokumentum feltöltése"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("Feltöltés kész"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Fájl feltöltése"),
        "usbC": MessageLookupByLibrary.simpleMessage("Usb C"),
        "use": MessageLookupByLibrary.simpleMessage("Használ"),
        "useMobiPos":
            MessageLookupByLibrary.simpleMessage("Használja a Pos Saas-t"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("A rendszer használata"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("A felhasználó törölve lett"),
        "userRole": MessageLookupByLibrary.simpleMessage("Felhasználói szerep"),
        "userRoleDetails": MessageLookupByLibrary.simpleMessage(
            "Felhasználói szerep részletei"),
        "userTitle": MessageLookupByLibrary.simpleMessage("Felhasználói cím"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "A felhasználói cím nem lehet üres"),
        "value": MessageLookupByLibrary.simpleMessage("Érték"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("Az áfa nem alkalmazható"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("OTP ellenőrzése"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Telefonszám ellenőrzése"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Összes megtekintése"),
        "viewDetails":
            MessageLookupByLibrary.simpleMessage("Részletek Megtekintése"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Gyalogos vásárló"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Raktár"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("A raktár már létezik"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("Raktár lista"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("Raktár neve"),
        "warranty": MessageLookupByLibrary.simpleMessage("Garancia"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Elküldtünk egy e-mailt az utasításokkal a jelszó visszaállításához a következő címre:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Harmadik fél szolgáltatásokat is használhatunk az alkalmazásunk funkcionalitásának támogatásához, mint például analitikai szolgáltatók és fizetési feldolgozók. Ezek a harmadik fél szolgáltatások információkat gyűjthetnek róla, amikor az alkalmazásunkat használja. Vegye figyelembe, hogy nem vagyunk felelősek ezeknek a harmadik fél szolgáltatások adatvédelmi gyakorlatáért."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Az Ön személyes információjának védelméhez ágazati szabványokat alkalmazunk, beleértve az adatok titkosítását és biztonságos tárolását. Az információhoz való hozzáférést csak az erre jogosult személyeknek engedélyezzük."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Megértjük a zökkenőmentes működés fontosságát. Ezért körömszakadtáig tartó támogatásunk rendelkezésre áll, hogy segítsen Önnek, legyen szó egy gyors kérdésről vagy átfogó aggodalomról. Bármikor és bárhol kapcsolatba léphet velünk hívással vagy WhatsApp-on keresztül, hogy páratlan ügyfélszolgálatot tapasztalhasson."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Az Ön személyes információit arra használjuk, hogy az Ön számára a lehető legjobb élményt nyújtsuk a mi alkalmazásunkban, ideértve a tartalomajánlás személyre szabását, az Ön kapcsolattartását szakértőkkel és az alkalmazásunk funkcionalitásának javítását. Az információit továbbá arra is felhasználhatjuk, hogy Önnel kommunikáljunk a frissítésekről, promóciókról vagy más, az alkalmazásunkhoz kapcsolódó információkról."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Át fogjuk nézni a kifizetést, és jóváhagyjuk 1-2 órán belül"),
        "weekly": MessageLookupByLibrary.simpleMessage("Havonta"),
        "weight": MessageLookupByLibrary.simpleMessage("Súly"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Mi újság"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Nagykereskedő"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Nagykereskedelmi ár"),
        "wholesalePrice":
            MessageLookupByLibrary.simpleMessage("Nagykereskedelmi ár"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Nagykereskedő"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Hamarosan hozzáadva"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Lejár"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Írja meg üzenetét itt"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("Hibás OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Rossz jelszót adtál meg ehhez a felhasználóhoz."),
        "yearly": MessageLookupByLibrary.simpleMessage("Éves"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Igen, végleges törlés"),
        "youAreNotAValidUser": MessageLookupByLibrary.simpleMessage(
            "Nem Ön egy érvényes felhasználó"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Ön használja"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Nem fizethet többet, mint a tartozás"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Kaptál egy e-mailt"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Sikeresen bejelentkeztél a fiókodba. Maradj Pos Saas-szal."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("Engedélyt kell adnia"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Újra be kell jelentkeznie a fiókjába."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Az azonosság ellenőrzése szükséges vásárlás előtt"),
        "yourMessageRemains": MessageLookupByLibrary.simpleMessage(
            "Az üzenet továbbra is érvényes"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Az Ön Csomagja"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Az Ön Csomagja 5 nap múlva lejár")
      };
}
