// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a cy locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'cy';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Parhau"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("Rhif GST"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("Mae MRP yn ofynnol"),
        "OK": MessageLookupByLibrary.simpleMessage("Iawn"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Ph.no"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("Cod SWIFT"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Snacks"),
        "TAX": MessageLookupByLibrary.simpleMessage("TAX"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Wrth lwytho i fyny"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("Teitl Defnyddiwr"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Bydd eich pecyn yn dod i ben heddiw\n\nOs gwelwch yn dda prynwch eto"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) Mae\'r System ar gael yn unig er mwyn hwyluso trafodion pwynt gwerthu a gweithgareddau cysylltiedig yn eich busnes."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) I ddefnyddio\'r System, efallai y bydd angen i chi greu cyfrif. Rydych yn cytuno i ddarparu gwybodaeth gywir, gyfredol, a chyflawn yn ystod y broses gofrestru ac i ddiweddaru\'r wybodaeth honno i\'w chadw\'n gywir a chyflawn."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("Ynglŷn â\'r Ap"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Amdanom ni"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Derbyniad o Derfynau"),
        "accountName": MessageLookupByLibrary.simpleMessage("Enw\'r Cyfrif"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("Rhif y Cyfrif"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Cofrestriad Cyfrif"),
        "acton": MessageLookupByLibrary.simpleMessage("Gweithredu"),
        "add": MessageLookupByLibrary.simpleMessage("Ychwanegu"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Ychwanegu Brand"),
        "addCategory":
            MessageLookupByLibrary.simpleMessage("Ychwanegu Categori"),
        "addContact": MessageLookupByLibrary.simpleMessage("Ychwanegu Cyswllt"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Ychwanegu Cwsmer"),
        "addDelivery":
            MessageLookupByLibrary.simpleMessage("Ychwanegu Danfoniad"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Ychwanegu Disgrifiad"),
        "addDescription":
            MessageLookupByLibrary.simpleMessage("Ychwanegu Nodyn"),
        "addDiscount":
            MessageLookupByLibrary.simpleMessage("Ychwanegu Disgownt"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Ychwanegu ID Dogfen"),
        "addDucument": MessageLookupByLibrary.simpleMessage("Ychwanegu Dogfen"),
        "addExpense":
            MessageLookupByLibrary.simpleMessage("Ychwanegu Gwariant"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Ychwanegu Categori Gwariant"),
        "addItems": MessageLookupByLibrary.simpleMessage("Ychwanegu Eitemau"),
        "addNew": MessageLookupByLibrary.simpleMessage("Ychwanegu Newydd"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Ychwanegu Cyfeiriad Newydd"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Ychwanegu Cynnyrch Newydd"),
        "addNewTax":
            MessageLookupByLibrary.simpleMessage("Ychwanegu Treth Newydd"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Ychwanegu Treth Newydd gyda math treth sengl/multipl"),
        "addNote": MessageLookupByLibrary.simpleMessage("Ychwanegu Nodyn"),
        "addProductFirst": MessageLookupByLibrary.simpleMessage(
            "Ychwanegwch gynnyrch yn gyntaf"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Ychwanegu Cod Hyrwyddo"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Ychwanegu Prynnu"),
        "addSales":
            MessageLookupByLibrary.simpleMessage("Ychwanegu Gwerthiannau"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Ychwanegwyd yn Llwyddiannus"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Ychwanegu Uned"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Ychwanegu Rôl Defnyddiwr"),
        "addedSuccessfully": MessageLookupByLibrary.simpleMessage(
            "Wedi\'i ychwanegu\'n llwyddiannus"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("Ychwanegwyd i\'r Gofrestr"),
        "address": MessageLookupByLibrary.simpleMessage("Cyfeiriad"),
        "admin": MessageLookupByLibrary.simpleMessage("Gweinyddu"),
        "all": MessageLookupByLibrary.simpleMessage("Pawb"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("Pob Ateb Busnes"),
        "alreadyAdded":
            MessageLookupByLibrary.simpleMessage("Eisoes wedi\'i ychwanegu"),
        "alreadyExists":
            MessageLookupByLibrary.simpleMessage("Mae eisoes yn bodoli"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Eisoes gan Gyfrif"),
        "amount": MessageLookupByLibrary.simpleMessage("Swm"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "Mae e-bost wedi\'i anfon\\nGwylio eich inbox"),
        "androidIOSAppSupport":
            MessageLookupByLibrary.simpleMessage("Cymorth Ap Android a iOS"),
        "applicableTax": MessageLookupByLibrary.simpleMessage("Treth Gymwys"),
        "apply": MessageLookupByLibrary.simpleMessage("Cymhwyso"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Ydych chi\'n siŵr eich bod am ddileu\'r anfoneb hon?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Ydych chi\'n siŵr eich bod am ddileu\'r gwerthiant hwn?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Ydych chi\'n siŵr eich bod am ddileu\'r defnyddiwr hwn?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "A ydych yn sicr am ddileu\'r Treth hon?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "A ydych yn sicr am ddileu\'r Grŵp Treth hwn?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "A ydych am ddileu\'r warws hwn?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Ydych chi\'n siŵr eich bod am ddileu\'r defnyddiwr hwn?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Llofnod Awdurdodedig"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Rydych yn gyfrifol am gadw cyfrinachedd eich cyfrif a\'ch cyfrinair a thynnu mynediad at eich cyfrif. Acceptiwn gyfrifoldeb am yr holl weithgareddau sy\'n digwydd o dan eich cyfrif."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Rhaid i chi fod o leiaf 18 oed neu oedran cyfreithiol y mwyafrif yn eich ardal i ddefnyddio\'r System."),
        "backSide": MessageLookupByLibrary.simpleMessage("Y Gwyneb Cefn"),
        "backToHome":
            MessageLookupByLibrary.simpleMessage("Yn ôl i\'r Cartref"),
        "balance": MessageLookupByLibrary.simpleMessage("Cydbwys"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladesh"),
        "bank": MessageLookupByLibrary.simpleMessage("Bank"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Arian Cyfrif Banc"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Arian Cyfrif y Banc"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Gwybodaeth Banc"),
        "bankName": MessageLookupByLibrary.simpleMessage("Enw\'r Banc"),
        "bankTransfer":
            MessageLookupByLibrary.simpleMessage("Trosglwyddiad Banc"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Cod bar wedi\'i ddod"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Bil/Anfoneb"),
        "billTo": MessageLookupByLibrary.simpleMessage("Bil i"),
        "branchName": MessageLookupByLibrary.simpleMessage("Enw\'r Ganghennau"),
        "brand": MessageLookupByLibrary.simpleMessage("Brand"),
        "brandName": MessageLookupByLibrary.simpleMessage("Enw\'r Brand"),
        "bulkUpload":
            MessageLookupByLibrary.simpleMessage("Llwytho Mawr\nI Fyny"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Categori Busnes"),
        "buy": MessageLookupByLibrary.simpleMessage("Prynwch"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Prynwch Gynllun Premiwm"),
        "buySms": MessageLookupByLibrary.simpleMessage("Prynwch SMS"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Trwy gael mynediad neu ddefnyddio\'r System Pwynt Gwerthu (POS) a gynhelir gan [Eich Enw Cwmni] (\"Cwmni\"), rydych yn cytuno i gydymffurfio â\'r Terfynau Defnyddio hyn. Os na chytunwch â\'r Terfynau Defnyddio hyn, peidiwch â defnyddio\'r System."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Rydych yn gyfrifol am sicrhau bod eich mynediad i\'r System a\'i ddefnydd yn cydymffurfio â\'r holl ddeddfau a rheolau cymwys."),
        "cacel": MessageLookupByLibrary.simpleMessage("Canslo"),
        "call": MessageLookupByLibrary.simpleMessage("Galw"),
        "callForEmergencySupport":
            MessageLookupByLibrary.simpleMessage("Galw Am Gymorth Brys"),
        "camera": MessageLookupByLibrary.simpleMessage("Camera"),
        "cancel": MessageLookupByLibrary.simpleMessage("Canslo"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Canslo Pob Cynnyrch"),
        "capacity": MessageLookupByLibrary.simpleMessage("Cynhwysedd"),
        "card": MessageLookupByLibrary.simpleMessage("Card"),
        "cash": MessageLookupByLibrary.simpleMessage("Arian Parod"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Categorïau"),
        "category": MessageLookupByLibrary.simpleMessage("Categori"),
        "categoryName": MessageLookupByLibrary.simpleMessage("Enw\'r Categori"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "Mae enw\'r categori eisoes yn bodoli"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("Enw Categori"),
        "change": MessageLookupByLibrary.simpleMessage("Newid?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Newid Cyfrinair"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("Gwirio E-bost"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Dewiswch Gwsmer"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Dewiswch Gyflenwr"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Dewiswch Eich Nodweddion"),
        "clarence": MessageLookupByLibrary.simpleMessage("Clirio"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Cliciwch i gysylltu"),
        "close": MessageLookupByLibrary.simpleMessage("Cau"),
        "color": MessageLookupByLibrary.simpleMessage("Lliw"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(Cymysgedd o drethau lluosog)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Yn Dod Yn Fuan"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Cyfeiriad Cwmni"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Enw Cwmni a Siop"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("Enw Cwmni a Busnes"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Cwblhau Tranzaction"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Cadarnhau Cyfrinair"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Cadarnhau dychwelyd"),
        "congratulations":
            MessageLookupByLibrary.simpleMessage("Llongyfarchiadau"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Cysylltwch â Ni"),
        "continu": MessageLookupByLibrary.simpleMessage("Parhau"),
        "country": MessageLookupByLibrary.simpleMessage("Gwlad"),
        "create": MessageLookupByLibrary.simpleMessage("Creu"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Creu Cyfrif Am Ddim"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Creu a Dihangodd"),
        "currency": MessageLookupByLibrary.simpleMessage("Arian"),
        "currentStock": MessageLookupByLibrary.simpleMessage("Stoc Presennol"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("Brandio Ffurflen Gyfrif"),
        "customer": MessageLookupByLibrary.simpleMessage("Cwsmer"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Manylion Cwsmer"),
        "customerGST": MessageLookupByLibrary.simpleMessage("GST Cwsmer"),
        "customerName": MessageLookupByLibrary.simpleMessage("Enw Cwsmer"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Trafodion Dyddiol"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Trosolwg y Dangosfwrdd"),
        "dataSavedSuccessfully": MessageLookupByLibrary.simpleMessage(
            "Data wedi\'i chadw\'n llwyddiannus"),
        "date": MessageLookupByLibrary.simpleMessage("Dyddiad"),
        "day": MessageLookupByLibrary.simpleMessage("Diwrnod"),
        "dealer": MessageLookupByLibrary.simpleMessage("Deliwr"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("Pris Dealer"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("Canran VAT Diffyg"),
        "delete": MessageLookupByLibrary.simpleMessage("Dileu"),
        "deleting": MessageLookupByLibrary.simpleMessage("Dileu"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Cyfeiriad Danfon"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Cyfeiriadau Danfoniad"),
        "deliveryCharge": MessageLookupByLibrary.simpleMessage("Tâl Dosbarthu"),
        "describtion": MessageLookupByLibrary.simpleMessage("Disgrifiad"),
        "description": MessageLookupByLibrary.simpleMessage("Disgrifiad"),
        "descriptionCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Nid yw\'r ddisgrifiad yn gallu bod yn wag"),
        "details": MessageLookupByLibrary.simpleMessage("Manylion"),
        "discount": MessageLookupByLibrary.simpleMessage("Disgownt"),
        "doNotDistrub":
            MessageLookupByLibrary.simpleMessage("Peidiwch â Pheryglu"),
        "done": MessageLookupByLibrary.simpleMessage("Wedi\'i Gwblhau"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Lawrlwytho Fformat Excel"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Wedi\'i lawrlwytho\'n llwyddiannus yn y ffolder lawrlwytho"),
        "due": MessageLookupByLibrary.simpleMessage("Dyled"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Swm Dyled: "),
        "dueCollection": MessageLookupByLibrary.simpleMessage("Casglu Dyled"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("Adroddiadau Casglu Dyled"),
        "dueList": MessageLookupByLibrary.simpleMessage("Rhestr Dyled"),
        "dueReports": MessageLookupByLibrary.simpleMessage("Adroddiad Dyled"),
        "duration": MessageLookupByLibrary.simpleMessage("Hyd"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Hyd: O"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "Haws i\'w Defnyddio ar Mobile POS"),
        "edit": MessageLookupByLibrary.simpleMessage("Golygu"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Golygu Ffurflen Ddyled"),
        "editSalesInvoice": MessageLookupByLibrary.simpleMessage(
            "Golygu Ffurflen Ddyled Gwerthu"),
        "editSocailMedia": MessageLookupByLibrary.simpleMessage(
            "Golygu Cyfryngau Cymdeithasol"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Golygu\'n llwyddiannus"),
        "editTax": MessageLookupByLibrary.simpleMessage("Golygu Treth"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Golygu Grŵp Treth"),
        "editWarehouse": MessageLookupByLibrary.simpleMessage("Golygu Warws"),
        "email": MessageLookupByLibrary.simpleMessage("E-bost"),
        "emailAddress":
            MessageLookupByLibrary.simpleMessage("Cyfeiriad E-bost"),
        "emailCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Nid yw\'r e-bost yn gallu bod yn wag"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "E-bost Wedi\'i Anfon! Gwiriwch eich Blwch Derbyn"),
        "endDate": MessageLookupByLibrary.simpleMessage("Dyddiad Diwedd"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Rhowch swm dilys"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Nodwch Ddisgownt Dilys"),
        "enterAValidPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Rhowch rif ffôn dilys"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Nodwch bris dilys"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("Nodwch gymhareb ddilys"),
        "enterAddress":
            MessageLookupByLibrary.simpleMessage("Rhowch Gyfeiriad"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("Rhowch Swm."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Mewnosod Enw\'r Brand"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Mewnosod Cynhwysedd"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Mewnosod Enw\'r Categori"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Mewnosod Lliw"),
        "enterCustomerGstNumber":
            MessageLookupByLibrary.simpleMessage("Rhowch rif GST y cwsmer"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Mewnosod Pris Dealer"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Nodwch Ddisgrifiad"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("Mewnosod Disgownt."),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Rhowch Dyddiad Gwariant"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Rhowch Gyfeiriad Llawn"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Nodwch Rhif Ffurflen Ddyled"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Nodwch Gymhareb Rhybudd Stoc Isel"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Mewnosod Gwneuthurwr"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("Nodwch Gynnwys Neges"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "Mewnosod MRP/Pric y Retailer"),
        "enterName": MessageLookupByLibrary.simpleMessage("Rhowch Enw"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Rhowch Nodyn"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Rhowch Enw\'r Parti"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Rhowch Rhif Ffôn"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Mewnosod Cod y Cynnyrch Neu Sganio"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Mewnosod Enw\'r Cynnyrch"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Mewnosod Pris Prynnu."),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("Rhowch Rhif Cyfeirnod"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Mewnosod Maint"),
        "enterStocks":
            MessageLookupByLibrary.simpleMessage("Mewnosod Stociau."),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Rhowch Gyfradd Treth"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("Rhowch ID y Trafodion"),
        "enterType": MessageLookupByLibrary.simpleMessage("Mewnosod Math"),
        "enterUserTitle": MessageLookupByLibrary.simpleMessage(
            "Mewngofnodwch deitl defnyddiwr"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Rhowch Swm Dilys"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Rhowch Enw\'r Warws"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Mewnosod Pwysau"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Mewnosod Pris Cyfanwerth"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("Nodwch eich disgrifiad yma"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "Rhowch eich cyfeiriad e-bost"),
        "enterYourFeedBackTitle":
            MessageLookupByLibrary.simpleMessage("Nodwch Deitl Eich Adborth"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Rhowch eich Rhif GST"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("Nodwch eich rhif symudol"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Rhowch Eich Enw"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("Rhowch eich rhif ffôn"),
        "enterYourPassword": MessageLookupByLibrary.simpleMessage(
            "Mewngofnodwch eich cyfrinair"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Rhowch Eich Rhif Ffôn"),
        "enterYourTransactionId":
            MessageLookupByLibrary.simpleMessage("Nodwch eich ID tranzaction"),
        "error": MessageLookupByLibrary.simpleMessage("Gwall"),
        "excTax": MessageLookupByLibrary.simpleMessage("Treth heb ei chynnwys"),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("Uwchraddwr Excel"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Heb gynnwys"),
        "expense": MessageLookupByLibrary.simpleMessage("Gwariant"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Categori Gwariant"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Dyddiad Gwariant"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Gwariant Ar Gyfer"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Adroddiad Gwariant"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Dyddiad Diddymu"),
        "expired": MessageLookupByLibrary.simpleMessage("Wedi Diddymu"),
        "expiring": MessageLookupByLibrary.simpleMessage("Yn dod i ben"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Methiant gyda Gwall"),
        "fashion": MessageLookupByLibrary.simpleMessage("Ffasiwn"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Mae nodweddion yn rhan bwysig sy\'n gwneud POS SaaS yn wahanol i atebion traddodiadol."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Adborth"),
        "firstName": MessageLookupByLibrary.simpleMessage("Enw Cyntaf"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Dilynwch Ni Ar\\nFacebook"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Dilynwch Ni Ar\\nTwitter"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Gwyneb Ffont"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("Am ddefnyddio di-belimit"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Wedi anghofio\'r cyfrinair"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Wedi anghofio\'r cyfrinair?"),
        "formDate": MessageLookupByLibrary.simpleMessage("O Dyddiad"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("Cefnogaeth Ddata Am Ddim"),
        "freeLifeTimeUpdate":
            MessageLookupByLibrary.simpleMessage("Diweddariad Am Ddim Am Byth"),
        "freePacakge":
            MessageLookupByLibrary.simpleMessage("Pecyn Rhad ac Am Ddim"),
        "freePlan":
            MessageLookupByLibrary.simpleMessage("Cynllun Rhad ac Am Ddim"),
        "from": MessageLookupByLibrary.simpleMessage("(O"),
        "fullyPaid":
            MessageLookupByLibrary.simpleMessage("Wedi\'i Dalu\'n Llwyr"),
        "gallary": MessageLookupByLibrary.simpleMessage("Oriel"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("Cynhyrchu PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Cael OTP"),
        "govermentId": MessageLookupByLibrary.simpleMessage("ID Llywodraeth"),
        "guest": MessageLookupByLibrary.simpleMessage("Gwesteiwr"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Nid oes gennych gyfrif?"),
        "history": MessageLookupByLibrary.simpleMessage("Hanes"),
        "home": MessageLookupByLibrary.simpleMessage("Cartref"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Sut Rydym yn Diogelu Eich Gwybodaeth"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Sut Rydym yn Defnyddio Eich Gwybodaeth"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Gwirio Hunaniaeth"),
        "image": MessageLookupByLibrary.simpleMessage("Delwedd"),
        "inHouseCantBeDelete": MessageLookupByLibrary.simpleMessage(
            "Nid yw InHouse yn gallu cael ei ddileu"),
        "inHouseCantBeEdited": MessageLookupByLibrary.simpleMessage(
            "Nid yw InHouse yn gallu cael ei olygu"),
        "inWord": MessageLookupByLibrary.simpleMessage("Mewn Geiriau"),
        "incTax":
            MessageLookupByLibrary.simpleMessage("Treth wedi\'i chynnwys"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Yn cynnwys"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("Cynyddu Stoc"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Offer"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Rhif Inv."),
        "invoice": MessageLookupByLibrary.simpleMessage("Ffoniad"),
        "invoiceNumber":
            MessageLookupByLibrary.simpleMessage("Rhif Ffurflen Ddyled"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Gosodiadau Ffurflen Ddyled"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Gwylydd Ffoniad"),
        "itemAdded":
            MessageLookupByLibrary.simpleMessage("Eitem wedi\'i ychwanegu"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification": MessageLookupByLibrary.simpleMessage("Gwirio KYC"),
        "language": MessageLookupByLibrary.simpleMessage("Iaith"),
        "lastName": MessageLookupByLibrary.simpleMessage("Enw Olaf"),
        "ledger": MessageLookupByLibrary.simpleMessage("Llyfr Taliadau"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Prynu Am Byth"),
        "link": MessageLookupByLibrary.simpleMessage("Dolen"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Cymorth Sgwrs Byw"),
        "loading": MessageLookupByLibrary.simpleMessage("Loading"),
        "logIn": MessageLookupByLibrary.simpleMessage("Mewngofnodi"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Allgofrestru"),
        "logOut": MessageLookupByLibrary.simpleMessage("Mewngofnodi"),
        "login": MessageLookupByLibrary.simpleMessage("Mewngofnodi"),
        "logo": MessageLookupByLibrary.simpleMessage("Logo"),
        "loss": MessageLookupByLibrary.simpleMessage("Colled"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Colled/Cynnyrch"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Manylion Colled/Cynnyrch"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Adroddiad Colli/Gwnaed"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Adroddiadau Colli/Gwnaed"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Rhybudd Stoc Isel"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Gwnewch argraff fythgofiadwy ar eich cwsmeriaid gyda ffurflenni brandio. Mae ein Gwelliant Diddiwedd yn cynnig y fantais unigryw o addasu eich ffurflenni, gan ychwanegu cyffwrdd proffesiynol sy\'n atgyfnerthu eich hunaniaeth frand a chynyddu teyrngarwch cwsmeriaid."),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("Rheoli eich busnes gyda "),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Dyddiad Cynhyrchu"),
        "margin": MessageLookupByLibrary.simpleMessage("Marjen"),
        "masterCard": MessageLookupByLibrary.simpleMessage("Card Master"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Gwneuthurwr"),
        "message": MessageLookupByLibrary.simpleMessage("Neges"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Hanes Negeseuon"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Mae\'r ap POS SaaS yn rhad ac am ddim, yn hawdd i\'w ddefnyddio. Yn wir, mae\'n un o\'r systemau POS gorau ledled y byd."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Mae POS SaaS yn ateb busnes llawn gyda stoc, cyfrif, gwerthiannau, treuliau a cholled/ennill."),
        "mobile": MessageLookupByLibrary.simpleMessage("Symudol"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("Taliad Symudol"),
        "monthly": MessageLookupByLibrary.simpleMessage("Misol"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("Mwy o Wybodaeth"),
        "name": MessageLookupByLibrary.simpleMessage("Rhowch Eich Enw."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Mae\'r enw eisoes yn bodoli"),
        "nameCantBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Nid yw\'r enw yn gallu bod yn wag"),
        "next": MessageLookupByLibrary.simpleMessage("Nesaf"),
        "noConnection": MessageLookupByLibrary.simpleMessage("Dim Cysylltiad"),
        "noData": MessageLookupByLibrary.simpleMessage("Dim Data"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Dim data ar gael"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Dim Data wedi\'i ddod o hyd"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("Dim Hanes a Ddarfod!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Dim Cynnyrch a Ddoddwyd"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("Dim Treth Is wedi\'i ddewis"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("Dim Tranzaction a Ddarfod!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Dim defnyddiwr a geir ar gyfer y cyfeiriad e-bost hwnnw."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "Dim Rôl Defnyddiwr wedi\'i Chanfod"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Defnyddiwr Anghysbell"),
        "notProvided":
            MessageLookupByLibrary.simpleMessage("Nid yw wedi\'i ddarparu"),
        "note": MessageLookupByLibrary.simpleMessage("Nodyn"),
        "notes": MessageLookupByLibrary.simpleMessage("Nodiadau"),
        "notification": MessageLookupByLibrary.simpleMessage("Hysbysiad"),
        "oTPSentTo":
            MessageLookupByLibrary.simpleMessage("OTP wedi\'i anfon i"),
        "office": MessageLookupByLibrary.simpleMessage("Swyddfa"),
        "ok": MessageLookupByLibrary.simpleMessage("Iawn"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS sy\'n cynnwys llawer o weithrediadau, gan gynnwys olrhain gwerthiannau, rheoli stoc."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Mae\'r system hon yn eich helpu i wella eich gweithrediadau ar gyfer eich cwsmeriaid."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Dylai ein system POS wneud gweithrediadau dyddiol yn syml, gan ei gwneud hi\'n hawdd i lywio."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("Cydbwysedd Agoriadol"),
        "order": MessageLookupByLibrary.simpleMessage("Gorchmynion"),
        "other": MessageLookupByLibrary.simpleMessage("Eraill"),
        "otp": MessageLookupByLibrary.simpleMessage("Cau"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Ar Goll o Stoc"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Pecyn"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Nodweddion Pecyn"),
        "paid": MessageLookupByLibrary.simpleMessage("Wedi\'i Dal"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Swm a Daliwyd"),
        "parties": MessageLookupByLibrary.simpleMessage("Partïon"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Rhestr Parti"),
        "partyGST": MessageLookupByLibrary.simpleMessage("GST Parti"),
        "partyName": MessageLookupByLibrary.simpleMessage("Enw\'r Parti"),
        "password": MessageLookupByLibrary.simpleMessage("Cyfrinair"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Nid yw\'r cyfrinair a\'r cyfrinair cadarnhau yn cyfateb"),
        "passwordCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Nid yw\'r cyfrinair yn gallu bod yn wag"),
        "passwordNotMach": MessageLookupByLibrary.simpleMessage(
            "Nid yw\'r cyfrinair yn cyfateb"),
        "payCash": MessageLookupByLibrary.simpleMessage("Talu ar Gyllid"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash": MessageLookupByLibrary.simpleMessage("Talu gyda Bkash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Talu gyda Paypal"),
        "payeeName": MessageLookupByLibrary.simpleMessage("Enw\'r Taliad"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("Rhif y Taliad"),
        "payment": MessageLookupByLibrary.simpleMessage("Taliad"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("Swm Taliad"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Taliad wedi\'i Gwblhau"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Cyfarwyddiadau Taliad:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("Dull Talu"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Math Taliad"),
        "pdfView": MessageLookupByLibrary.simpleMessage("Golygfa PDF"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Gwybodaeth Bersonol"),
        "phone": MessageLookupByLibrary.simpleMessage("Ffôn"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Rhif Ffôn"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Mae rhif ffôn eisoes wedi\'i ddefnyddio"),
        "phoneNumberIsNotValid": MessageLookupByLibrary.simpleMessage(
            "Nid yw\'r rhif ffôn yn ddilys"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("Mae angen rhif ffôn"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("Dewis a Uwchraddio Ffeil"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("Dewis Dyddiad Diwedd"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Dewis Dyddiad Dechrau"),
        "plan": MessageLookupByLibrary.simpleMessage("Cynllun"),
        "pleaseAddQuantity": MessageLookupByLibrary.simpleMessage(
            "Os gwelwch yn dda, ychwanegwch gymhareb"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Os gwelwch yn dda, gwirio eich cysylltedd rhyngrwyd"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Os gwelwch yn dda, cysylltwch â\'r argraffydd yn gyntaf"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Os gwelwch yn dda, cysylltwch â\'ch Argraffydd Bluetooth"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Os gwelwch yn dda, rhowch gyfrinair mwy"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Os gwelwch yn dda, Rhowch Gyfrinair Cadarnhaol"),
        "pleaseEnterAPassword": MessageLookupByLibrary.simpleMessage(
            "Os gwelwch yn dda, rhowch gyfrinair"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Os gwelwch yn dda, rhowch e-bost dilys"),
        "pleaseEnterName": MessageLookupByLibrary.simpleMessage(
            "Os gwelwch yn dda, rhowch enw"),
        "pleaseEnterPassword": MessageLookupByLibrary.simpleMessage(
            "Os gwelwch yn dda, rhowch gyfrinair"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Os gwelwch yn dda, rhowch eich cyfeiriad e-bost isod i dderbyn dolen adnewyddu cyfrinair."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Os gwelwch yn dda, rhowch y rhif trafodion"),
        "pleaseInterAmount": MessageLookupByLibrary.simpleMessage(
            "os gwelwch yn dda Rhowch Swm"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Os gwelwch yn dda, dewiswch gategori yn gyntaf"),
        "pleaseSelectAPlan": MessageLookupByLibrary.simpleMessage(
            "Os gwelwch yn dda, dewiswch gynllun"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Os gwelwch yn dda, dewiswch gategori busnes"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Defnyddiwch y cod prynu dilys i ddefnyddio\'r ap"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Cynhelir gan Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Cynhelir Gan"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Cymorth Cwsmer Premiwm"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Cynllun Premiwm"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Symiau Taliad Blaenorol"),
        "price": MessageLookupByLibrary.simpleMessage("Pris"),
        "print": MessageLookupByLibrary.simpleMessage("Argraffu"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Dewis Argraffu"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Polisi Preifatrwydd"),
        "product": MessageLookupByLibrary.simpleMessage("Cynnyrch"),
        "productCode": MessageLookupByLibrary.simpleMessage("Cod y Cynnyrch"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("Mae angen Cod y Cynnyrch"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Cod/Enw Cynnyrch"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Disgrifiad Cynnyrch"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Manylion Cynnyrch"),
        "productList": MessageLookupByLibrary.simpleMessage("Rhestr Cynnyrch"),
        "productName": MessageLookupByLibrary.simpleMessage("Enw\'r Cynnyrch"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Mae enw\'r cynnyrch eisoes yn bodoli yn y warws hon"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Mae enw\'r cynnyrch eisoes wedi\'i ychwanegu"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("Mae angen enw\'r cynnyrch"),
        "products": MessageLookupByLibrary.simpleMessage("Cynhyrchion"),
        "profile": MessageLookupByLibrary.simpleMessage("Proffil"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("Golygu Proffil"),
        "profit": MessageLookupByLibrary.simpleMessage("Cynnyrch"),
        "promo": MessageLookupByLibrary.simpleMessage("hysbyseb"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Cod Hyrwyddo"),
        "purchase": MessageLookupByLibrary.simpleMessage("Prynu"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage("Cloi Prynwyr"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Prynwch wedi\'i Gadarnhau"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Manylion Prynnu"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Anfoneb Prynwch"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("Rhestr Prynu"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Prynwch Nawr"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Prynwch Gynllun Premiwm"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("Pris Prynnu"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("Mae angen pris prynu"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("Adroddiad Prynu"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Adroddiadau Prynnu"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Adroddiadau Prynwyr"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("Dychweliad Prynwch"),
        "purchaseReturnReport": MessageLookupByLibrary.simpleMessage(
            "Adroddiad Dychweliad Prynwch"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Trosglwyddo Prynwr"),
        "qty": MessageLookupByLibrary.simpleMessage("Nifer"),
        "quantity": MessageLookupByLibrary.simpleMessage("Nifer"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Transgiweddau Diweddar"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("Derbyniodd y pin"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Rhif Cyfeirnod"),
        "register": MessageLookupByLibrary.simpleMessage("Cofrestru"),
        "registering": MessageLookupByLibrary.simpleMessage("Cofrestru"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("Dyled Ar Goll"),
        "remove": MessageLookupByLibrary.simpleMessage("Dileu"),
        "reports": MessageLookupByLibrary.simpleMessage("Adroddiadau"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Mae\'r cais wedi\'i anfon"),
        "resendCode": MessageLookupByLibrary.simpleMessage("Ail-anfon Cod"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("Ail-anfon OTP: "),
        "retailer": MessageLookupByLibrary.simpleMessage("Man Werthu"),
        "retur": MessageLookupByLibrary.simpleMessage("Dychwelyd"),
        "returN": MessageLookupByLibrary.simpleMessage("Dychwelyd"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("Dychwelyd Swm"),
        "returnAmount":
            MessageLookupByLibrary.simpleMessage("Symiau Dychwelyd"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("Dychwelyd QTY"),
        "revenue": MessageLookupByLibrary.simpleMessage("Refeniw"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Diogelu\'ch data busnes heb ymdrech. Mae ein Gwelliant Pos Saas POS Diddiwedd yn cynnwys cefnogaeth ddata am ddim, gan sicrhau bod eich gwybodaeth werthfawr wedi\'i diogelu rhag unrhyw ddigwyddiadau annisgwyl. Canolbwyntiwch ar yr hyn sy\'n wirioneddol bwysig - eich tyfiant busnes."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Swm Gwerthiant"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("Manylion Gwerthu"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Pris Gwerthu"),
        "saleReports":
            MessageLookupByLibrary.simpleMessage("Adroddiad Gwerthu"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Adroddiadau Gwerthu"),
        "saleReturn":
            MessageLookupByLibrary.simpleMessage("Dychweliad Gwerthiant"),
        "saleReturnReport": MessageLookupByLibrary.simpleMessage(
            "Adroddiad Dychweliad Gwerthiant"),
        "saleSetting":
            MessageLookupByLibrary.simpleMessage("Gosodiad Gwerthiant"),
        "sales": MessageLookupByLibrary.simpleMessage("Gwerthiant"),
        "salesAndPurchaseReports": MessageLookupByLibrary.simpleMessage(
            "Adroddiadau Gwerthu a Chaffaith"),
        "salesList":
            MessageLookupByLibrary.simpleMessage("Rhestr Gwerthiannau"),
        "salesReturn":
            MessageLookupByLibrary.simpleMessage("Dychweliad Gwerthiant"),
        "save": MessageLookupByLibrary.simpleMessage("Cadw"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Cadw a Cyhoeddi"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("Cadw Newidiadau"),
        "saving": MessageLookupByLibrary.simpleMessage("Arbed"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("Sganio cod QR cynnyrch"),
        "search": MessageLookupByLibrary.simpleMessage("Chwilio"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Chwilio gyda chod cynnyrch neu enw"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("Gweld pob cod hyrwyddo"),
        "select": MessageLookupByLibrary.simpleMessage("Dewis"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Dewiswch gynnyrch ar gyfer dychwelyd"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Dewiswch Frand"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Dewiswch Gategori"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Dewiswch Gysylltiadau"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("Dewiswch Gategori Cynnyrch"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("Dewiswch gategori siop"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Dewiswch Dreth"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Dewiswch fath treth"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("Dewiswch Uned"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Dewis Amrywiadau: "),
        "seller": MessageLookupByLibrary.simpleMessage("Gwerthwr"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Gwerthu Gan"),
        "send": MessageLookupByLibrary.simpleMessage("Anfon"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("Anfon E-bost"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Anfon Neges"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("Anfon Dolen Adnewyddu"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Anfon SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Anfon SMS?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Anfon neges whatsapp"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Anfon Eich E-bost"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage("Anfon E-bost"),
        "sendingMessage": MessageLookupByLibrary.simpleMessage("Anfon neges"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Gwasanaeth/Dosbarthiad"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Sefydlu eich Proffil"),
        "setting": MessageLookupByLibrary.simpleMessage("Gosodiad"),
        "share": MessageLookupByLibrary.simpleMessage("Rhannu"),
        "shopGST": MessageLookupByLibrary.simpleMessage("GST Siop"),
        "signIn": MessageLookupByLibrary.simpleMessage("Mewngofnodi"),
        "signInWithEmail": MessageLookupByLibrary.simpleMessage(
            "Mewngofnodwch gyda\'r e-bost"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Llofnod y Cwsmer"),
        "size": MessageLookupByLibrary.simpleMessage("Maint"),
        "skip": MessageLookupByLibrary.simpleMessage("Helo"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Marchnata Cymdeithasol"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Mae\'n ddrwg gennyf, nid oes gennych ganiatâd i fynd i\'r gwasanaeth hwn"),
        "startDate": MessageLookupByLibrary.simpleMessage("Dyddiad Dechrau"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Dechrau Gwerthiant Newydd"),
        "startTypingToSearch":
            MessageLookupByLibrary.simpleMessage("Dechreuwch deipio i chwilio"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Arhoswch ar flaen gwelliannau technolegol heb unrhyw gostau ychwanegol. Mae ein Pos Saas POS Diddiwedd Gwelliant yn sicrhau eich bod bob amser yn cael y offer a\'r nodweddion diweddaraf yn eich dwylo, gan sicrhau bod eich busnes yn aros yn arloesol."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("Still Unpaid"),
        "stock": MessageLookupByLibrary.simpleMessage("Stoc"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Mae angen stoc"),
        "stockList": MessageLookupByLibrary.simpleMessage("Rhestr Stoc"),
        "stocks": MessageLookupByLibrary.simpleMessage("Stociau"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Mae awdurdod storio yn ofynnol i greu ffeil Excel"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("Rhestr Treth Is"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Trethau Is"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Is-Sym"),
        "submit": MessageLookupByLibrary.simpleMessage("Cyflwyno"),
        "subscribeToOurYoutube":
            MessageLookupByLibrary.simpleMessage("Mynychwch I\'n\\nYoutube"),
        "subscription": MessageLookupByLibrary.simpleMessage("Aelodaeth"),
        "successfullyDone": MessageLookupByLibrary.simpleMessage(
            "Wedi\'i Gwblhau\'n Llwyddiannus"),
        "successfullyLoggedOut": MessageLookupByLibrary.simpleMessage(
            "Wedi Mewngofnodi\'n llwyddiannus"),
        "successfullyUpdated": MessageLookupByLibrary.simpleMessage(
            "Wedi\'i ddiweddaru\'n llwyddiannus"),
        "supplier": MessageLookupByLibrary.simpleMessage("Cyflenwr"),
        "supplierName": MessageLookupByLibrary.simpleMessage("Enw\'r Cyflenwr"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("Cod SWIFT"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Cymrwch lun o drwydded yrrwr, cerdyn hunaniaeth cenedlaethol neu basbort"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "Cymrwch gerdyn hunaniaeth i wirio eich gwybodaeth"),
        "tap": MessageLookupByLibrary.simpleMessage("Tap"),
        "tax": MessageLookupByLibrary.simpleMessage("Treth"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Grŵp Treth"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("Cantfed Treth"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Cyfradd Treth"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Cyfraddau Treth - Rheoli eich cyfraddau treth"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Adroddiad Treth"),
        "taxType": MessageLookupByLibrary.simpleMessage("Math Treth"),
        "taxes": MessageLookupByLibrary.simpleMessage("Trethi"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Telerau a Amodau"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("Telerau Defnyddio"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Telerau a Phreifatrwydd"),
        "thankYOuForYourDuePayment":
            MessageLookupByLibrary.simpleMessage("Diolch am Eich Taliad Dyled"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Diolch"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Diolch am eich pryniant"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "Mae\'r cyfrif eisoes yn bodoli ar gyfer yr e-bost hwnnw"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Mae\'r ffeil Excel wedi\'i lawrlwytho eisoes"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Mae\'r enw\'n dweud popeth. Gyda Pos Saas POS Diddiwedd, nid oes unrhyw ddirywiad ar eich defnydd. P\'un ai ydych yn prosesu nifer fach o drafodion neu\'n profi llif o gwsmeriaid, gallwch weithredu gyda hyder, gan wybod nad ydych yn gyfyngedig gan derfynau."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "Mae\'r cyfrinair a roddwyd yn rhy wan"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Bydd y gwerthiant yn cael ei ddileu a bydd yr holl ddata am y pryniant hwnnw\'n cael ei ddileu. Ydych chi\'n siŵr am ddileu hyn?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Bydd y gwerthiant yn cael ei ddileu a bydd yr holl ddata am y gwerthiant hwn yn cael ei ddileu. Ydych chi\'n siŵr am ddileu hyn?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Bydd y defnyddiwr yn cael ei ddileu ac bydd yr holl ddata\'n cael eu dileu o\'ch cyfrif. Ydych chi\'n siŵr eich bod am ddileu hyn?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Bydd y defnyddiwr yn cael ei ddileu a bydd yr holl ddata yn cael eu dileu o\'ch cyfrif. Ydych chi\'n siŵr eich bod am ddileu hyn?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Gwasanaethau Trydydd Parti"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Ni ellir dileu\'r categori hwn"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Y Mis hwn)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Mae\'r cynnyrch hwn eisoes wedi\'i ychwanegu"),
        "title": MessageLookupByLibrary.simpleMessage("Teitl"),
        "titleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Nid yw\'r teitl yn gallu bod yn wag"),
        "to": MessageLookupByLibrary.simpleMessage("i"),
        "toDate": MessageLookupByLibrary.simpleMessage("I Dyddiad"),
        "today": MessageLookupByLibrary.simpleMessage("Heddiw"),
        "total": MessageLookupByLibrary.simpleMessage("Cyfan"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Cyfanswm Swm"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Cyfanswm a Gasglwyd"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Cyfanswm Dyled"),
        "totalExpense":
            MessageLookupByLibrary.simpleMessage("Cyfanswm Gwariant"),
        "totalLoss":
            MessageLookupByLibrary.simpleMessage("Cyfanswm y Colledion"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("Cyfanswm i\'w Dal"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Pris Cyfan"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("Cyfanswm y Cynhyrchion"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Cyfanswm y Elw"),
        "totalPurchase":
            MessageLookupByLibrary.simpleMessage("Cyfanswm Prynwch"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Cyfanswm Yswiriant"),
        "totalReturns":
            MessageLookupByLibrary.simpleMessage("Cyfanswm Dychweliadau"),
        "totalSale":
            MessageLookupByLibrary.simpleMessage("Cyfanswm Gwerthiant"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Cyfanswm Stociau"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Gwerth Cyfanswm"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Cyfanswm TAW"),
        "totals": MessageLookupByLibrary.simpleMessage("Cyfanswm: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Tranzaction"),
        "transactionId": MessageLookupByLibrary.simpleMessage("ID Tranzaction"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Dewch yn ôl"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Math"),
        "unitName": MessageLookupByLibrary.simpleMessage("Enw Uned"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Pris Uned"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Pris Uned"),
        "units": MessageLookupByLibrary.simpleMessage("Unedau"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Diderfyn"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Defnydd Diddiwedd"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Agorwch botensial llawn Pos Saas POS gyda sesiynau hyfforddiant personol a arweinir gan ein tîm arbenigol. O\'r sylfaen i dechnegau uwch, rydym yn sicrhau eich bod yn dda wedi\'i hyfforddi i ddefnyddio pob agwedd ar y system i optimeiddio eich prosesau busnes."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Heb dalu"),
        "update": MessageLookupByLibrary.simpleMessage("Diweddaru"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Diweddaru Cyswllt"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Diweddaru Nawr"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("Diweddaru Cynnyrch"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Diweddarwch eich cynllun yn gyntaf,\\nmae eich terfyn drosodd"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Diweddaru Eich Proffil"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Diweddaru eich proffil i gysylltu â\'ch meddyg gyda gwell argraff"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Diweddaru eich proffil i gysylltu â\'ch cwsmer gyda gwell argraff"),
        "updated": MessageLookupByLibrary.simpleMessage("Diweddarwyd"),
        "upload": MessageLookupByLibrary.simpleMessage("Uwchraddio"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Pwythwch Ddogfen"),
        "uploadDone":
            MessageLookupByLibrary.simpleMessage("Uwchraddio Wedi\'i Gwblhau"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Pwythwch Ffeil"),
        "upplier": MessageLookupByLibrary.simpleMessage("Cyflenwr"),
        "usbC": MessageLookupByLibrary.simpleMessage("Usb C"),
        "use": MessageLookupByLibrary.simpleMessage("Defnyddio"),
        "useMobiPos":
            MessageLookupByLibrary.simpleMessage("Defnyddiwch POS SaaS"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Defnydd o\'r system"),
        "userIsDeleted": MessageLookupByLibrary.simpleMessage(
            "Mae\'r defnyddiwr wedi\'i ddileu"),
        "userRole": MessageLookupByLibrary.simpleMessage("Rôl Defnyddiwr"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("Manylion Rôl y Defnyddiwr"),
        "userTitle": MessageLookupByLibrary.simpleMessage("Teitl Defnyddiwr"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Nid yw teitl y defnyddiwr yn gallu bod yn wag"),
        "value": MessageLookupByLibrary.simpleMessage("Gwerth"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("Nid yw VAT yn gymwys"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("Gwirio OTP"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Gwirio Rhif Ffôn"),
        "viewAll": MessageLookupByLibrary.simpleMessage("View All"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("Gweld Manylion"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Cwsmer Cerdded-i-Mewn"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Warws"),
        "warehouseAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "Mae\'r warws eisoes yn bodoli"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("Rhestr Warws"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("Enw\'r Warws"),
        "warranty": MessageLookupByLibrary.simpleMessage("Gwarant"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Mae gennym ni anfon e-bost gyda chyfarwyddiadau ar sut i adnewyddu\'r cyfrinair i:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Efallai y byddwn yn defnyddio gwasanaethau trydydd parti i gefnogi gweithrediad ein hymgeisydd, fel darparwyr dadansoddeg a phroseswyr talu. Mae\'r gwasanaethau trydydd parti hyn yn gallu casglu gwybodaeth amdanat pan ddefnyddiwch ein hymgeisydd. Sylwch nad ydym yn gyfrifol am arferion preifatrwydd y gwasanaethau trydydd parti hyn."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Rydym yn cymryd mesurau safonol yn y diwydiant i ddiogelu eich gwybodaeth bersonol, gan gynnwys gollwng a storfa ddiogel. Rydym hefyd yn cyfyngu mynediad at eich gwybodaeth i bersonél awdurdodedig yn unig."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Rydym yn deall pwysigrwydd gweithrediadau di-dor. Dyna pam mae ein cymorth drwy\'r nos ar gael i\'ch cynorthwyo, boed yn gwestiwn cyflym neu broblem gynhwysfawr. Cysylltwch â ni unrhyw bryd, unrhyw le trwy alwad neu WhatsApp i brofi gwasanaeth cwsmer heb ei ail."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Rydym yn defnyddio eich gwybodaeth bersonol i\'ch darparu â\'r profiad gorau posib ar ein hymgeisydd, gan gynnwys i bersonoli eich argymhellion cynnwys, cysylltu â gwybodeg, a gwella gweithrediad ein hymgeisydd. Efallai y byddwn hefyd yn defnyddio eich gwybodaeth i gyfathrebu â chi am ddiweddariadau, hyrwyddiadau, neu wybodaeth arall sy\'n gysylltiedig â\'n hymgeisydd."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Byddwn yn adolygu\'r talu a\'i gymeradwyo o fewn 1-2 awr"),
        "weekly": MessageLookupByLibrary.simpleMessage("Cylchlythyr"),
        "weight": MessageLookupByLibrary.simpleMessage("Pwysau"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Beth sy\'n Newydd"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Cyfanwerthwr"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Pris Cyfanwerth"),
        "wholesalePrice":
            MessageLookupByLibrary.simpleMessage("Pris Cyfanwerth"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Cyfanwerthwr"),
        "willBeAddedSoon": MessageLookupByLibrary.simpleMessage(
            "Bydd yn cael ei ychwanegu yn fuan"),
        "willExpireAt":
            MessageLookupByLibrary.simpleMessage("Bydd yn Diddymu yn"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Ysgrifennwch eich neges yma"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("OTP anghywir"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Cyfrinair anghywir a roddwyd ar gyfer y defnyddiwr hwn."),
        "yearly": MessageLookupByLibrary.simpleMessage("Cylchblyg"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Oes, Dileu Am Byth"),
        "youAreNotAValidUser": MessageLookupByLibrary.simpleMessage(
            "Nid ydych yn ddefnyddiwr dilys"),
        "youAreUsing":
            MessageLookupByLibrary.simpleMessage("Rydych chi\'n defnyddio"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Ni allwch dalu mwy na\'r hyn sydd ddyledus"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Mae gennych e-bost"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Rydych wedi mewngofnodi\'n llwyddiannus i\'ch cyfrif. Arhoswch gyda Pos Saas."),
        "youHaveToGivePermission": MessageLookupByLibrary.simpleMessage(
            "Mae angen i chi roi caniatâd"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Mae angen i chi WNEUD COFRESTRU newydd ar eich cyfrif."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Mae angen i chi wirio hunaniaeth cyn prynu SMS"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Mae eich neges yn parhau"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Eich Pecyn"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Bydd eich pecyn yn dod i ben om ddyddiau 5")
      };
}
