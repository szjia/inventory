// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a it locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'it';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Continua"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("Numero GST"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("Il MRP è obbligatorio"),
        "OK": MessageLookupByLibrary.simpleMessage("OK"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("N. tel."),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("Codice SWIFT"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Snack"),
        "TAX": MessageLookupByLibrary.simpleMessage("TASSA"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Caricamento"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("Titolo Utente"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Il tuo pacchetto scadrà oggi.\n\nPer favore, acquista di nuovo."),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) Il Sistema è fornito esclusivamente per lo scopo di agevolare le transazioni punto vendita e attività correlate nella tua attività."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) Per utilizzare il Sistema, potrebbe essere necessario creare un account. Accetti di fornire informazioni accurate, attuali e complete durante il processo di registrazione e di aggiornare tali informazioni per mantenerle accurate e complete."),
        "aboutApp":
            MessageLookupByLibrary.simpleMessage("Informazioni sull\'App"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Chi siamo"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Accettazione dei Termini"),
        "accountName":
            MessageLookupByLibrary.simpleMessage("Nome dell\'Account"),
        "accountNumber":
            MessageLookupByLibrary.simpleMessage("Numero dell\'Account"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Registrazione dell\'Account"),
        "acton": MessageLookupByLibrary.simpleMessage("Azione"),
        "add": MessageLookupByLibrary.simpleMessage("Aggiungi"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Aggiungi Marca"),
        "addCategory":
            MessageLookupByLibrary.simpleMessage("Aggiungi Categoria"),
        "addContact": MessageLookupByLibrary.simpleMessage("Aggiungi Contatto"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Aggiungi Cliente"),
        "addDelivery":
            MessageLookupByLibrary.simpleMessage("Aggiungi Consegna"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Aggiungi descrizione"),
        "addDescription": MessageLookupByLibrary.simpleMessage("Aggiungi nota"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Aggiungi sconto"),
        "addDocumentId": MessageLookupByLibrary.simpleMessage(
            "Aggiungi documento d\'identità"),
        "addDucument":
            MessageLookupByLibrary.simpleMessage("Aggiungi documento"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Aggiungi Spesa"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Aggiungi Categoria Spesa"),
        "addItems": MessageLookupByLibrary.simpleMessage("Aggiungi Articoli"),
        "addNew": MessageLookupByLibrary.simpleMessage("Aggiungi nuovo"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Aggiungi Nuovo Indirizzo"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Aggiungi Nuovo Prodotto"),
        "addNewTax":
            MessageLookupByLibrary.simpleMessage("Aggiungi nuova tassa"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Aggiungi nuova tassa con tipo di tassa singolo/multiplo"),
        "addNote": MessageLookupByLibrary.simpleMessage("Aggiungi Nota"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Aggiungi prima il prodotto"),
        "addPromoCode": MessageLookupByLibrary.simpleMessage(
            "Aggiungi codice promozionale"),
        "addPurchase":
            MessageLookupByLibrary.simpleMessage("Aggiungi Acquisto"),
        "addSales": MessageLookupByLibrary.simpleMessage("Aggiungi Vendita"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Aggiunto con Successo"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Aggiungi Unità"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Aggiungi Ruolo Utente"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Aggiunto con successo"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("Aggiunto al carrello"),
        "address": MessageLookupByLibrary.simpleMessage("Indirizzo"),
        "admin": MessageLookupByLibrary.simpleMessage("Amministratore"),
        "all": MessageLookupByLibrary.simpleMessage("Tutti"),
        "allBusinessSolution": MessageLookupByLibrary.simpleMessage(
            "Tutte le soluzioni aziendali"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("Già aggiunto"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Esiste già"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Hai già un account?"),
        "amount": MessageLookupByLibrary.simpleMessage("Importo"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "È stata inviata un\'email. Controlla la tua casella di posta"),
        "androidIOSAppSupport":
            MessageLookupByLibrary.simpleMessage("Supporto App Android e iOS"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Tassa applicabile"),
        "apply": MessageLookupByLibrary.simpleMessage("Applica"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Sei sicuro di voler eliminare questa fattura?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Sei sicuro di voler eliminare questa vendita?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Sei sicuro di voler eliminare questo utente?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Sei sicuro di voler eliminare questa tassa?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Sei sicuro di voler eliminare questo gruppo fiscale?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Vuoi eliminare questo magazzino?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Sei sicuro di voler eliminare questo utente?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Firma autorizzata"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Sei responsabile di mantenere la riservatezza del tuo account e della tua password e di limitare l\'accesso al tuo account. Accetti la responsabilità di tutte le attività che avvengono sotto il tuo account."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Devi avere almeno 18 anni o l\'età legale della maggioranza nella tua giurisdizione per utilizzare il Sistema."),
        "backSide": MessageLookupByLibrary.simpleMessage("Lato posteriore"),
        "backToHome": MessageLookupByLibrary.simpleMessage("Torna alla Home"),
        "balance": MessageLookupByLibrary.simpleMessage("Saldo"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladesh"),
        "bank": MessageLookupByLibrary.simpleMessage("Banca"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Valuta del conto bancario"),
        "bankAccountingCurrecny": MessageLookupByLibrary.simpleMessage(
            "Valuta dell\'Account Bancario"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Informazioni Bancarie"),
        "bankName": MessageLookupByLibrary.simpleMessage("Nome della Banca"),
        "bankTransfer":
            MessageLookupByLibrary.simpleMessage("Bonifico bancario"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Codice a barre trovato"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Fattura"),
        "billTo": MessageLookupByLibrary.simpleMessage("Fatturato A"),
        "branchName":
            MessageLookupByLibrary.simpleMessage("Nome della Filiale"),
        "brand": MessageLookupByLibrary.simpleMessage("Marca"),
        "brandName": MessageLookupByLibrary.simpleMessage("Nome Marca"),
        "bulkUpload":
            MessageLookupByLibrary.simpleMessage("Caricamento massivo"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Categoria dell\'Attività"),
        "buy": MessageLookupByLibrary.simpleMessage("Acquista"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Acquista piano premium"),
        "buySms": MessageLookupByLibrary.simpleMessage("Acquista SMS"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Accedendo o utilizzando il Sistema Punto Vendita (POS) (il \"Sistema\") fornito da [Nome della Tua Azienda] (la \"Azienda\"), accetti di essere vincolato da questi Termini d\'Uso. Se non sei d\'accordo con questi Termini d\'Uso, non utilizzare il Sistema."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Sei responsabile di assicurarti che il tuo accesso e utilizzo del Sistema siano conformi a tutte le leggi e regolamenti applicabili."),
        "cacel": MessageLookupByLibrary.simpleMessage("Annulla"),
        "call": MessageLookupByLibrary.simpleMessage("Chiama"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "Chiama per supporto d\'emergenza"),
        "camera": MessageLookupByLibrary.simpleMessage("Fotocamera"),
        "cancel": MessageLookupByLibrary.simpleMessage("Annulla"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Annulla tutti i prodotti"),
        "capacity": MessageLookupByLibrary.simpleMessage("Capacità"),
        "card": MessageLookupByLibrary.simpleMessage("Carta"),
        "cash": MessageLookupByLibrary.simpleMessage("Contanti"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Categorie"),
        "category": MessageLookupByLibrary.simpleMessage("Categoria"),
        "categoryName": MessageLookupByLibrary.simpleMessage("Nome categoria"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "Il nome della categoria esiste già"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("Nome Categoria"),
        "change": MessageLookupByLibrary.simpleMessage("Cambia?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Cambia Password"),
        "checkEmail":
            MessageLookupByLibrary.simpleMessage("Controlla la posta"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Scegli un Cliente"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Scegli un Fornitore"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Scegli le tue funzionalità"),
        "clarence": MessageLookupByLibrary.simpleMessage("Clarence"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Clicca per collegare"),
        "close": MessageLookupByLibrary.simpleMessage("Chiudi"),
        "color": MessageLookupByLibrary.simpleMessage("Colore"),
        "combinationOfMultipleTaxes":
            MessageLookupByLibrary.simpleMessage("(Combinazione di più tasse)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Prossimamente"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Indirizzo dell\'Impresa"),
        "companyAndShopName": MessageLookupByLibrary.simpleMessage(
            "Nome dell\'Impresa e del Negozio"),
        "companyBusinessName": MessageLookupByLibrary.simpleMessage(
            "Nome dell\'azienda e dell\'attività"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Completa transazione"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Conferma Password"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Conferma il reso"),
        "congratulations":
            MessageLookupByLibrary.simpleMessage("Congratulazioni"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Contattaci"),
        "continu": MessageLookupByLibrary.simpleMessage("Continua"),
        "country": MessageLookupByLibrary.simpleMessage("Paese"),
        "create": MessageLookupByLibrary.simpleMessage("Crea"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Crea un Account Gratuito"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Creato e salvato"),
        "currency": MessageLookupByLibrary.simpleMessage("Valuta"),
        "currentStock":
            MessageLookupByLibrary.simpleMessage("Magazzino attuale"),
        "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
            "Marchio Fattura Personalizzato"),
        "customer": MessageLookupByLibrary.simpleMessage("Cliente"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Dettagli Cliente"),
        "customerGST": MessageLookupByLibrary.simpleMessage("GST del cliente"),
        "customerName": MessageLookupByLibrary.simpleMessage("Nome Cliente"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Transazione Giornaliera"),
        "dashBoardOverView": MessageLookupByLibrary.simpleMessage(
            "Panoramica del Pannello di Controllo"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Dati salvati con successo"),
        "date": MessageLookupByLibrary.simpleMessage("Data"),
        "day": MessageLookupByLibrary.simpleMessage("Giorno"),
        "dealer": MessageLookupByLibrary.simpleMessage("Rivenditore"),
        "dealerPrice":
            MessageLookupByLibrary.simpleMessage("Prezzo Rivenditore"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("Percentuale IVA predefinita"),
        "delete": MessageLookupByLibrary.simpleMessage("Elimina"),
        "deleting": MessageLookupByLibrary.simpleMessage("Eliminazione"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Indirizzo di Consegna"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Indirizzi di consegna"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Costo Consegna"),
        "describtion": MessageLookupByLibrary.simpleMessage("Descrizione"),
        "description": MessageLookupByLibrary.simpleMessage("Descrizione"),
        "descriptionCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "La descrizione non può essere vuota"),
        "details": MessageLookupByLibrary.simpleMessage("Dettagli"),
        "discount": MessageLookupByLibrary.simpleMessage("Sconto"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Non disturbare"),
        "done": MessageLookupByLibrary.simpleMessage("Fatto"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Scarica formato Excel"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Scaricato con successo nella cartella di download"),
        "due": MessageLookupByLibrary.simpleMessage("Scadenza"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Importo Scadenza: "),
        "dueCollection":
            MessageLookupByLibrary.simpleMessage("Raccolta Scadenze"),
        "dueCollectionReports": MessageLookupByLibrary.simpleMessage(
            "Rapporti di recupero scaduti"),
        "dueList": MessageLookupByLibrary.simpleMessage("Elenco Scadenze"),
        "dueReports": MessageLookupByLibrary.simpleMessage("Report Scadenze"),
        "duration": MessageLookupByLibrary.simpleMessage("Durata"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Durata: Da"),
        "easyToUseMobilePos":
            MessageLookupByLibrary.simpleMessage("Pos mobile facile da usare"),
        "edit": MessageLookupByLibrary.simpleMessage("Modifica"),
        "editPurchaseInvoice": MessageLookupByLibrary.simpleMessage(
            "Modifica Fattura di Acquisto"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Modifica Fattura di Vendita"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Modifica Social Media"),
        "editSuccessfully": MessageLookupByLibrary.simpleMessage(
            "Modifica effettuata con successo"),
        "editTax": MessageLookupByLibrary.simpleMessage("Modifica tassa"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Modifica gruppo fiscale"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("Modifica magazzino"),
        "email": MessageLookupByLibrary.simpleMessage("Email"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("Indirizzo Email"),
        "emailCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "L\'email non può essere vuota"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "Email inviata! Controlla la tua inbox"),
        "endDate": MessageLookupByLibrary.simpleMessage("Data Fine"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Inserisci un importo valido"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Inserisci uno sconto valido"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Inserisci un numero di telefono valido"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Inserisci un prezzo valido"),
        "enterAValidQuantity": MessageLookupByLibrary.simpleMessage(
            "Inserisci una quantità valida"),
        "enterAddress":
            MessageLookupByLibrary.simpleMessage("Inserisci l\'Indirizzo"),
        "enterAmount":
            MessageLookupByLibrary.simpleMessage("Inserisci l\'Importo"),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Inserisci Nome Marca"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Inserisci Capacità"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Inserisci Nome Categoria"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Inserisci Colore"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "Inserisci il numero GST del cliente"),
        "enterDealerPrice": MessageLookupByLibrary.simpleMessage(
            "Inserisci Prezzo Rivenditore"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Inserisci descrizione"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("Inserisci Sconto"),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Inserisci Data Spesa"),
        "enterFullAddress": MessageLookupByLibrary.simpleMessage(
            "Inserisci l\'Indirizzo Completo"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Inserisci Numero Fattura"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Inserisci la quantità di avviso di bassa scorta"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Inserisci Produttore"),
        "enterMessageContent": MessageLookupByLibrary.simpleMessage(
            "Inserisci il contenuto del messaggio"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "Inserisci MRP/Prezzo al Dettaglio"),
        "enterName": MessageLookupByLibrary.simpleMessage("Inserisci Nome"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Inserisci Nota"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Inserisci Nome Parte"),
        "enterPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Inserisci il Numero di Telefono"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Inserisci Codice Prodotto o Scansiona"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Inserisci Nome Prodotto"),
        "enterPurchasePrice": MessageLookupByLibrary.simpleMessage(
            "Inserisci Prezzo di Acquisto"),
        "enterReferenceNumber": MessageLookupByLibrary.simpleMessage(
            "Inserisci Numero di Riferimento"),
        "enterSize":
            MessageLookupByLibrary.simpleMessage("Inserisci Dimensione"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("Inserisci Scorte"),
        "enterTaxRate": MessageLookupByLibrary.simpleMessage(
            "Inserisci l\'aliquota fiscale"),
        "enterTransactionId": MessageLookupByLibrary.simpleMessage(
            "Inserisci l\'ID della Transazione"),
        "enterType": MessageLookupByLibrary.simpleMessage("Inserisci Tipo"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("Inserisci il titolo utente"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Inserisci un importo valido"),
        "enterWarehouseName": MessageLookupByLibrary.simpleMessage(
            "Inserisci il nome del magazzino"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Inserisci Peso"),
        "enterWholeSalePrice": MessageLookupByLibrary.simpleMessage(
            "Inserisci Prezzo All\'Ingrosso"),
        "enterYourDescriptionHere": MessageLookupByLibrary.simpleMessage(
            "Inserisci qui la tua descrizione"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "Inserisci il tuo indirizzo email"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "Inserisci il Titolo del Feedback"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Inserisci il tuo numero GST"),
        "enterYourMobileNumber": MessageLookupByLibrary.simpleMessage(
            "Inserisci il tuo numero di cellulare"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Inserisci il Tuo Nome"),
        "enterYourNumber": MessageLookupByLibrary.simpleMessage(
            "Inserisci il tuo numero di telefono"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Inserisci la tua password"),
        "enterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Inserisci il Tuo Numero di Telefono"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "Inserisci il tuo ID transazione"),
        "error": MessageLookupByLibrary.simpleMessage("Errore"),
        "excTax": MessageLookupByLibrary.simpleMessage("Tassa esclusa"),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("Caricatore Excel"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Esclusivo"),
        "expense": MessageLookupByLibrary.simpleMessage("Spesa"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Categoria Spesa"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Data Spesa"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Spesa Per"),
        "expenseReport": MessageLookupByLibrary.simpleMessage("Report Spese"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Data di scadenza"),
        "expired": MessageLookupByLibrary.simpleMessage("Scaduto"),
        "expiring": MessageLookupByLibrary.simpleMessage("In scadenza"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError": MessageLookupByLibrary.simpleMessage(
            "Operazione non riuscita con errore"),
        "fashion": MessageLookupByLibrary.simpleMessage("Moda"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Le funzionalità sono la parte importante che rende Pos Saas diverso dalle soluzioni tradizionali."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Feedback"),
        "firstName": MessageLookupByLibrary.simpleMessage("Nome"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Seguici su\\nFacebook"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Seguici su\\nTwitter"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Lato anteriore"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("Per utilizzi illimitati"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Password dimenticata"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Password dimenticata?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Dalla Data"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("Backup Dati Gratuito"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "Aggiornamento Gratuito a Vita"),
        "freePacakge":
            MessageLookupByLibrary.simpleMessage("Pacchetto gratuito"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Piano gratuito"),
        "from": MessageLookupByLibrary.simpleMessage("(Da"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Interamente pagato"),
        "gallary": MessageLookupByLibrary.simpleMessage("Galleria"),
        "generatingPDF":
            MessageLookupByLibrary.simpleMessage("Generazione PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Ottieni OTP"),
        "govermentId": MessageLookupByLibrary.simpleMessage(
            "Documento di identità governativo"),
        "guest": MessageLookupByLibrary.simpleMessage("Ospite"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Non hai un account?"),
        "history": MessageLookupByLibrary.simpleMessage("Storia"),
        "home": MessageLookupByLibrary.simpleMessage("Home"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Come Proteggiamo le Tue Informazioni"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Come Utilizziamo le Tue Informazioni"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Verifica identità"),
        "image": MessageLookupByLibrary.simpleMessage("Immagine"),
        "inHouseCantBeDelete": MessageLookupByLibrary.simpleMessage(
            "Non può essere eliminato in sede"),
        "inHouseCantBeEdited": MessageLookupByLibrary.simpleMessage(
            "Non può essere modificato in sede"),
        "inWord": MessageLookupByLibrary.simpleMessage("In parole"),
        "incTax": MessageLookupByLibrary.simpleMessage("Tassa inclusa"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Inclusivo"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("Aumenta stock"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Strumento"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("N° Fattura"),
        "invoice": MessageLookupByLibrary.simpleMessage("Fattura"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("Numero Fattura"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Impostazione Fattura"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Visualizzatore di fatture"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Articolo Aggiunto"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification": MessageLookupByLibrary.simpleMessage("Verifica KYC"),
        "language": MessageLookupByLibrary.simpleMessage("Lingua"),
        "lastName": MessageLookupByLibrary.simpleMessage("Cognome"),
        "ledger": MessageLookupByLibrary.simpleMessage("Registro"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Acquisto a vita"),
        "link": MessageLookupByLibrary.simpleMessage("Collegamento"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Supporto chat dal vivo"),
        "loading": MessageLookupByLibrary.simpleMessage("Caricamento"),
        "logIn": MessageLookupByLibrary.simpleMessage("Accedi"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Esci"),
        "logOut": MessageLookupByLibrary.simpleMessage("Disconnetti"),
        "login": MessageLookupByLibrary.simpleMessage("Accedi"),
        "logo": MessageLookupByLibrary.simpleMessage("Logo"),
        "loss": MessageLookupByLibrary.simpleMessage("Perdita"),
        "lossOrProfit":
            MessageLookupByLibrary.simpleMessage("Perdita/Profitto"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Dettagli Perdita/Profitto"),
        "lossProfitReport": MessageLookupByLibrary.simpleMessage(
            "Rapporto di perdita/profitto"),
        "lossProfitReports": MessageLookupByLibrary.simpleMessage(
            "Rapporti di perdita/profitto"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Avviso di bassa scorta"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Lascia un\'impressione duratura sui tuoi clienti con fatture personalizzate. Il nostro Aggiornamento Illimitato offre il vantaggio unico di personalizzare le tue fatture, aggiungendo un tocco professionale che rafforza l\'identità del tuo marchio e favorisce la fedeltà del cliente."),
        "manageYourBussinessWith": MessageLookupByLibrary.simpleMessage(
            "Gestisci la tua attività con"),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Data di produzione"),
        "margin": MessageLookupByLibrary.simpleMessage("Margine"),
        "masterCard": MessageLookupByLibrary.simpleMessage("Carta Mastercard"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Produttore"),
        "message": MessageLookupByLibrary.simpleMessage("Messaggio"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Cronologia messaggi"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "L\'app Pos Saas è gratuita e facile da usare. In effetti, è uno dei migliori sistemi POS al mondo."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas è una soluzione aziendale completa con gestione di magazzino, contabilità, vendite, spese e perdite/profitti."),
        "mobile": MessageLookupByLibrary.simpleMessage("Mobile"),
        "mobilePayment":
            MessageLookupByLibrary.simpleMessage("Pagamento mobile"),
        "monthly": MessageLookupByLibrary.simpleMessage("Mensile"),
        "moreInfo":
            MessageLookupByLibrary.simpleMessage("Maggiori Informazioni"),
        "name": MessageLookupByLibrary.simpleMessage("Inserisci il Tuo Nome"),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Il nome esiste già"),
        "nameCantBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Il nome non può essere vuoto"),
        "next": MessageLookupByLibrary.simpleMessage("Avanti"),
        "noConnection":
            MessageLookupByLibrary.simpleMessage("Nessuna connessione"),
        "noData": MessageLookupByLibrary.simpleMessage("Nessun dato"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Nessun dato disponibile"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Nessun dato trovato"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("Nessuna cronologia trovata!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Nessun prodotto trovato"),
        "noSubTaxSelected": MessageLookupByLibrary.simpleMessage(
            "Nessuna sotto tassa selezionata"),
        "noTransactionFound": MessageLookupByLibrary.simpleMessage(
            "Nessuna transazione trovata!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Nessun utente trovato con quell\'indirizzo email."),
        "noUserRoleFound":
            MessageLookupByLibrary.simpleMessage("Nessun Ruolo Utente Trovato"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Utente non attivo"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Non fornito"),
        "note": MessageLookupByLibrary.simpleMessage("Nota"),
        "notes": MessageLookupByLibrary.simpleMessage("Note"),
        "notification": MessageLookupByLibrary.simpleMessage("Notifica"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP inviato a"),
        "office": MessageLookupByLibrary.simpleMessage("Ufficio"),
        "ok": MessageLookupByLibrary.simpleMessage("Ok"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS che contiene molte funzionalità, inclusa la tracciatura delle vendite e la gestione dell\'inventario."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Questo sistema ti aiuta a migliorare le tue operazioni per i tuoi clienti."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Il nostro sistema POS dovrebbe semplificare automaticamente le operazioni quotidiane, facilitandone la navigazione."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("Saldo Iniziale"),
        "order": MessageLookupByLibrary.simpleMessage("Ordini"),
        "other": MessageLookupByLibrary.simpleMessage("Altro"),
        "otp": MessageLookupByLibrary.simpleMessage("Chiudi"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Esaurito"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Pacchetto"),
        "packageFeatures": MessageLookupByLibrary.simpleMessage(
            "Caratteristiche del pacchetto"),
        "paid": MessageLookupByLibrary.simpleMessage("Pagato"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Importo Pagato"),
        "parties": MessageLookupByLibrary.simpleMessage("Parti"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Lista Parti"),
        "partyGST": MessageLookupByLibrary.simpleMessage("GST della parte"),
        "partyName": MessageLookupByLibrary.simpleMessage("Nome Parte"),
        "password": MessageLookupByLibrary.simpleMessage("Password"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "La password e la conferma della password non corrispondono"),
        "passwordCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "La password non può essere vuota"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("La password non corrisponde"),
        "payCash": MessageLookupByLibrary.simpleMessage("Paga in Contanti"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash": MessageLookupByLibrary.simpleMessage("Paga con bkash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Paga con Paypal"),
        "payeeName":
            MessageLookupByLibrary.simpleMessage("Nome del beneficiario"),
        "payeeNumber":
            MessageLookupByLibrary.simpleMessage("Numero del beneficiario"),
        "payment": MessageLookupByLibrary.simpleMessage("Pagamento"),
        "paymentAmount":
            MessageLookupByLibrary.simpleMessage("Importo Pagamento"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Pagamento Completato"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Istruzioni di pagamento:"),
        "paymentMethod":
            MessageLookupByLibrary.simpleMessage("Metodo di pagamento"),
        "paymentType":
            MessageLookupByLibrary.simpleMessage("Tipo di Pagamento"),
        "pdfView": MessageLookupByLibrary.simpleMessage("Visualizzazione PDF"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Informazioni personali"),
        "phone": MessageLookupByLibrary.simpleMessage("Telefono"),
        "phoneNumber":
            MessageLookupByLibrary.simpleMessage("Numero di Telefono"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Il numero di telefono è già in uso"),
        "phoneNumberIsNotValid": MessageLookupByLibrary.simpleMessage(
            "Il numero di telefono non è valido"),
        "phoneNumberIsRequired": MessageLookupByLibrary.simpleMessage(
            "Il numero di telefono è obbligatorio"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("Seleziona e carica file"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("Seleziona Data Fine"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Seleziona Data Inizio"),
        "plan": MessageLookupByLibrary.simpleMessage("Piano"),
        "pleaseAddQuantity": MessageLookupByLibrary.simpleMessage(
            "Si prega di aggiungere quantità"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Controlla la tua connessione internet"),
        "pleaseConnectThePrinterFirst":
            MessageLookupByLibrary.simpleMessage("Collega prima la stampante"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Per favore, collega la tua stampante Bluetooth"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Si prega di inserire una password più lunga"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Inserisci una Password di Conferma"),
        "pleaseEnterAPassword": MessageLookupByLibrary.simpleMessage(
            "Inserisci una password, per favore."),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Si prega di inserire un\'email valida"),
        "pleaseEnterName": MessageLookupByLibrary.simpleMessage(
            "Si prega di inserire un nome"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("Inserisci la password"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Inserisci il tuo indirizzo email qui sotto per ricevere il link per la reimpostazione della password."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Si prega di inserire il numero di transazione"),
        "pleaseInterAmount": MessageLookupByLibrary.simpleMessage(
            "Si prega di inserire l\'importo"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Seleziona prima una categoria"),
        "pleaseSelectAPlan": MessageLookupByLibrary.simpleMessage(
            "Si prega di selezionare un piano"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Seleziona la categoria commerciale"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Si prega di utilizzare il codice di acquisto valido per utilizzare l\'app"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Powered By Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Realizzato da"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Supporto Clienti Premium"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Piano premium"),
        "previousPayAmounts": MessageLookupByLibrary.simpleMessage(
            "Importi Pagati in Precedenza"),
        "price": MessageLookupByLibrary.simpleMessage("Prezzo"),
        "print": MessageLookupByLibrary.simpleMessage("Stampa"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Opzione di Stampa"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Informativa sulla Privacy"),
        "product": MessageLookupByLibrary.simpleMessage("Prodotto"),
        "productCode": MessageLookupByLibrary.simpleMessage("Codice Prodotto"),
        "productCodeIsRequired": MessageLookupByLibrary.simpleMessage(
            "Il codice prodotto è obbligatorio"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Codice/Nome del prodotto"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Descrizione del prodotto"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Dettagli del prodotto"),
        "productList": MessageLookupByLibrary.simpleMessage("Lista Prodotti"),
        "productName": MessageLookupByLibrary.simpleMessage("Nome Prodotto"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Il nome del prodotto esiste già in questo magazzino"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Il nome del prodotto è già stato aggiunto"),
        "productNameIsRequired": MessageLookupByLibrary.simpleMessage(
            "Il nome del prodotto è obbligatorio"),
        "products": MessageLookupByLibrary.simpleMessage("Prodotti"),
        "profile": MessageLookupByLibrary.simpleMessage("Profilo"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("Modifica Profilo"),
        "profit": MessageLookupByLibrary.simpleMessage("Profitto"),
        "promo": MessageLookupByLibrary.simpleMessage("Promo"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Codice Promo"),
        "purchase": MessageLookupByLibrary.simpleMessage("Acquisto"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("Allarme Acquisto"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Acquisto Confermato"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Dettagli Acquisto"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Fattura d\'acquisto"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("Lista Acquisti"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Acquista ora"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Acquista piano premium"),
        "purchasePrice":
            MessageLookupByLibrary.simpleMessage("Prezzo di Acquisto"),
        "purchasePriceIsRequired": MessageLookupByLibrary.simpleMessage(
            "Il prezzo di acquisto è obbligatorio"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("Report Acquisto"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Report Acquisti"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Rapporti di acquisto"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("Reso di acquisto"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("Rapporto di reso acquisti"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Transazione di acquisto"),
        "qty": MessageLookupByLibrary.simpleMessage("Q.tà"),
        "quantity": MessageLookupByLibrary.simpleMessage("Quantità"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Transazioni Recenti"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("Ricevuto il Pin"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Numero di Riferimento"),
        "register": MessageLookupByLibrary.simpleMessage("Registrati"),
        "registering": MessageLookupByLibrary.simpleMessage("Registrazione"),
        "remainingDue":
            MessageLookupByLibrary.simpleMessage("Scadenze Residue"),
        "remove": MessageLookupByLibrary.simpleMessage("Rimuovi"),
        "reports": MessageLookupByLibrary.simpleMessage("Rapporti"),
        "requestHasBeenSend": MessageLookupByLibrary.simpleMessage(
            "La richiesta è stata inviata"),
        "resendCode": MessageLookupByLibrary.simpleMessage("Rinvia Codice"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("Rinvia OTP: "),
        "retailer": MessageLookupByLibrary.simpleMessage("Dettagliante"),
        "retur": MessageLookupByLibrary.simpleMessage("Reso"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("Importo Reso"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("Importo Reso"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("Quantità di reso"),
        "revenue": MessageLookupByLibrary.simpleMessage("Ricavi"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Proteggi i tuoi dati aziendali con facilità. Il nostro Pos Saas POS Unlimited Upgrade include un backup dati gratuito, garantendo che le tue informazioni preziose siano protette da eventi imprevisti. Concentrati su ciò che conta veramente: la crescita della tua attività."),
        "saleAmount":
            MessageLookupByLibrary.simpleMessage("Importo di vendita"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("Dettagli Vendita"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Prezzo di Vendita"),
        "saleReports": MessageLookupByLibrary.simpleMessage("Report Vendita"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Rapporti di vendita"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("Reso di vendita"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Rapporto di reso di vendita"),
        "saleSetting":
            MessageLookupByLibrary.simpleMessage("Impostazioni di vendita"),
        "sales": MessageLookupByLibrary.simpleMessage("Vendite"),
        "salesAndPurchaseReports": MessageLookupByLibrary.simpleMessage(
            "Rapporti di Vendita e Acquisto"),
        "salesList": MessageLookupByLibrary.simpleMessage("Lista Vendite"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("Reso di vendita"),
        "save": MessageLookupByLibrary.simpleMessage("Salva"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Salva e Pubblica"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("Salva Modifiche"),
        "saving": MessageLookupByLibrary.simpleMessage("Salvataggio"),
        "scanProductQRCode": MessageLookupByLibrary.simpleMessage(
            "Scansiona il codice QR del prodotto"),
        "search": MessageLookupByLibrary.simpleMessage("Cerca"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Cerca per codice o nome del prodotto"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("Vedi tutti i codici promo"),
        "select": MessageLookupByLibrary.simpleMessage("Seleziona"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Seleziona un prodotto per il reso"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Seleziona marca"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Seleziona categoria"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Seleziona Contatti"),
        "selectProductCategory": MessageLookupByLibrary.simpleMessage(
            "Seleziona categoria prodotto"),
        "selectShopCategory": MessageLookupByLibrary.simpleMessage(
            "Seleziona la categoria del negozio"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Seleziona tassa"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Seleziona tipo di tassa"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("Seleziona unità"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Seleziona Variante: "),
        "seller": MessageLookupByLibrary.simpleMessage("Venditore"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Venduto da"),
        "send": MessageLookupByLibrary.simpleMessage("Invia"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("Invia Email"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Invia messaggio"),
        "sendResetLink": MessageLookupByLibrary.simpleMessage(
            "Invia Link di Reimpostazione"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Invia SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Inviare SMS?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Invia messaggio WhatsApp"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Invia la tua email"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage("Invio email"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Invio messaggio"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Servizio/Spedizione"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Imposta il tuo Profilo"),
        "setting": MessageLookupByLibrary.simpleMessage("Impostazioni"),
        "share": MessageLookupByLibrary.simpleMessage("Condividi"),
        "shopGST": MessageLookupByLibrary.simpleMessage("GST del negozio"),
        "signIn": MessageLookupByLibrary.simpleMessage("Accedi"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("Accedi con email"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Firma del cliente"),
        "size": MessageLookupByLibrary.simpleMessage("Dimensione"),
        "skip": MessageLookupByLibrary.simpleMessage("Salta"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Marketing Sociale"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Spiacenti, non hai il permesso di accedere a questo servizio"),
        "startDate": MessageLookupByLibrary.simpleMessage("Data Inizio"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Inizia Nuova Vendita"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage(
            "Inizia a digitare per cercare"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Rimani all\'avanguardia delle innovazioni tecnologiche senza costi aggiuntivi. Il nostro Pos Saas POS Unlimited Upgrade garantisce che tu abbia sempre gli strumenti e le funzionalità più recenti a portata di mano, assicurando che la tua attività rimanga all\'avanguardia."),
        "stillUnpaid":
            MessageLookupByLibrary.simpleMessage("Ancora non pagato"),
        "stock": MessageLookupByLibrary.simpleMessage("Magazzino"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Lo stock è obbligatorio"),
        "stockList": MessageLookupByLibrary.simpleMessage("Lista Prodotti"),
        "stocks": MessageLookupByLibrary.simpleMessage("Scorte"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "È richiesta l\'autorizzazione di archiviazione per creare un file Excel"),
        "subTaxList":
            MessageLookupByLibrary.simpleMessage("Elenco sotto tasse"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Sotto tasse"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Subtotale"),
        "submit": MessageLookupByLibrary.simpleMessage("Invia"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "Iscriviti al nostro\\nYoutube"),
        "subscription": MessageLookupByLibrary.simpleMessage("Abbonamento"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Fatto con successo"),
        "successfullyLoggedOut": MessageLookupByLibrary.simpleMessage(
            "Disconnessione avvenuta con successo"),
        "successfullyUpdated": MessageLookupByLibrary.simpleMessage(
            "Aggiornamento effettuato con successo"),
        "supplier": MessageLookupByLibrary.simpleMessage("Fornitore"),
        "supplierName": MessageLookupByLibrary.simpleMessage("Nome Fornitore"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("Codice SWIFT"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Porta una patente di guida, una carta d\'identità nazionale o una foto del passaporto"),
        "takeaNidCardToCheckYourInformation": MessageLookupByLibrary.simpleMessage(
            "Prendi una carta d\'identità per verificare le tue informazioni"),
        "tap": MessageLookupByLibrary.simpleMessage("Tocca"),
        "tax": MessageLookupByLibrary.simpleMessage("Tassa"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Gruppo fiscale"),
        "taxPercentage":
            MessageLookupByLibrary.simpleMessage("Percentuale tassa"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Aliquota fiscale"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Aliquote fiscali - Gestisci le tue aliquote fiscali"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Rapporto fiscale"),
        "taxType": MessageLookupByLibrary.simpleMessage("Tipo di tassa"),
        "taxes": MessageLookupByLibrary.simpleMessage("Tasse"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Termini e condizioni"),
        "termsOfUse":
            MessageLookupByLibrary.simpleMessage("Termini di Utilizzo"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Termini e privacy"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Grazie per il pagamento delle tue scadenze"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Grazie"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Grazie per il tuo acquisto"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "L\'account esiste già per quell\'email"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Il file Excel è già stato scaricato"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Il nome dice tutto. Con Pos Saas POS Unlimited, non ci sono limiti al tuo utilizzo. Che tu stia elaborando una manciata di transazioni o che stia affrontando un afflusso di clienti, puoi operare con fiducia, sapendo che non sei vincolato da limiti."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "La password fornita è troppo debole"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "La vendita sarà eliminata e tutti i dati relativi a questo acquisto saranno eliminati. Sei sicuro di voler eliminare questo?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "La vendita sarà eliminata e tutti i dati relativi a questa vendita saranno eliminati. Sei sicuro di voler eliminare questo?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "L\'utente verrà eliminato e tutti i dati saranno cancellati dal tuo account. Sei sicuro di voler eliminare questo?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "L\'utente sarà eliminato e tutti i dati saranno rimossi dal tuo account. Sei sicuro di volerlo eliminare?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Servizi di Terze Parti"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Questa categoria non può essere eliminata"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Questo mese)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Questo prodotto è già stato aggiunto"),
        "title": MessageLookupByLibrary.simpleMessage("Titolo"),
        "titleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Il titolo non può essere vuoto"),
        "to": MessageLookupByLibrary.simpleMessage("a"),
        "toDate": MessageLookupByLibrary.simpleMessage("Alla Data"),
        "today": MessageLookupByLibrary.simpleMessage("Oggi"),
        "total": MessageLookupByLibrary.simpleMessage("Totale"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Importo Totale"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Totale raccolto"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Totale Scadenze"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("Totale Spese"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Perdita totale"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("Totale da Pagare"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Prezzo Totale"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("Prodotti totali"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Profitto totale"),
        "totalPurchase":
            MessageLookupByLibrary.simpleMessage("Totale acquisti"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Importo totale del reso"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("Resi totali"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Totale Vendite"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Totale magazzino"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Valore totale"),
        "totalVat": MessageLookupByLibrary.simpleMessage("IVA Totale"),
        "totals": MessageLookupByLibrary.simpleMessage("Totale: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Transazione"),
        "transactionId": MessageLookupByLibrary.simpleMessage("ID transazione"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Riprova"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Tipo"),
        "unitName": MessageLookupByLibrary.simpleMessage("Nome Unità"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Prezzo Unitario"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Prezzo unitario"),
        "units": MessageLookupByLibrary.simpleMessage("Unità"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Illimitato"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Utilizzo Illimitato"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Sblocca il pieno potenziale di Pos Saas POS con sessioni di formazione personalizzate condotte dal nostro team di esperti. Dalle basi alle tecniche avanzate, ci assicuriamo che tu sia ben preparato nell\'utilizzare ogni aspetto del sistema per ottimizzare i tuoi processi aziendali."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Non pagato"),
        "update": MessageLookupByLibrary.simpleMessage("Aggiorna"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Aggiorna Contatto"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Aggiorna Ora"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("Aggiorna Prodotto"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Aggiorna prima il tuo piano,\\nil tuo limite è superato"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Aggiorna il Tuo Profilo"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Aggiorna il tuo profilo per collegarti meglio con il tuo medico"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Aggiorna il tuo profilo per connetterti meglio con il cliente"),
        "updated": MessageLookupByLibrary.simpleMessage("Aggiornato"),
        "upload": MessageLookupByLibrary.simpleMessage("Carica"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Carica Documento"),
        "uploadDone":
            MessageLookupByLibrary.simpleMessage("Caricamento completato"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Carica File"),
        "upplier": MessageLookupByLibrary.simpleMessage("Fornitore"),
        "usbC": MessageLookupByLibrary.simpleMessage("Usb C"),
        "use": MessageLookupByLibrary.simpleMessage("Usa"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("Usa Pos Saas"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Utilizzo del sistema"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("L\'utente è stato eliminato"),
        "userRole": MessageLookupByLibrary.simpleMessage("Ruolo Utente"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("Dettagli del Ruolo Utente"),
        "userTitle": MessageLookupByLibrary.simpleMessage("Titolo Utente"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Il titolo utente non può essere vuoto"),
        "value": MessageLookupByLibrary.simpleMessage("Valore"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("L\'IVA non si applica"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("Verifica OTP"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Verifica Numero di Telefono"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Vedi Tutto"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("Vedi dettagli"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Cliente Senza Registrazione"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Magazzino"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Il magazzino esiste già"),
        "warehouseList":
            MessageLookupByLibrary.simpleMessage("Elenco dei magazzini"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("Nome magazzino"),
        "warranty": MessageLookupByLibrary.simpleMessage("Garanzia"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Abbiamo inviato un\'email con le istruzioni su come reimpostare la password a:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Potremmo utilizzare servizi di terze parti per supportare la funzionalità della nostra app, come fornitori di analisi e processori di pagamento. Questi servizi di terze parti potrebbero raccogliere informazioni su di te quando utilizzi la nostra app. Ti preghiamo di notare che non siamo responsabili delle pratiche sulla privacy di questi servizi di terze parti."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Adottiamo misure standard dell\'industria per proteggere le tue informazioni personali, inclusa la crittografia e la conservazione sicura. Limitiamo inoltre l\'accesso alle tue informazioni solo al personale autorizzato."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Comprendiamo l\'importanza delle operazioni senza soluzione di continuità. Ecco perché il nostro supporto attivo 24 ore su 24 è disponibile per assisterti, che si tratti di una semplice domanda o di una preoccupazione più complessa. Connettiti con noi in qualsiasi momento, ovunque, tramite chiamata o WhatsApp per vivere un servizio clienti senza rivali."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Utilizziamo le tue informazioni personali per offrirti la migliore esperienza possibile sulla nostra app, inclusa la personalizzazione delle raccomandazioni di contenuto, il collegamento con esperti e il miglioramento della funzionalità delle nostre app. Potremmo anche utilizzare le tue informazioni per comunicare con te riguardo agli aggiornamenti, promozioni o altre informazioni relative alla nostra app."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Esamineremo il pagamento e lo approveremo entro 1-2 ore"),
        "weekly": MessageLookupByLibrary.simpleMessage("Settimanale"),
        "weight": MessageLookupByLibrary.simpleMessage("Peso"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Novità"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Ingrosso"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Prezzo All\'Ingrosso"),
        "wholesalePrice":
            MessageLookupByLibrary.simpleMessage("Prezzo all\'ingrosso"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Grossista"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Sarà aggiunto presto"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Scadrà il"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Scrivi il tuo messaggio qui"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("OTP errato"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Password errata fornita per quell\'utente."),
        "yearly": MessageLookupByLibrary.simpleMessage("Annuale"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Sì, Elimina Definitivamente"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("Non sei un utente valido"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Stai utilizzando"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Non puoi pagare più di quanto dovuto"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Hai ricevuto una email"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Hai effettuato l\'accesso con successo al tuo account. Rimani con Pos Saas ."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("Devi concedere permessi"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Devi EFFETTUARE NUOVAMENTE L\'ACCESSO al tuo account."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Devi verificare l\'identità prima di acquistare SMS"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Il tuo messaggio rimane"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Il tuo pacchetto"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Il tuo pacchetto scadrà tra 5 giorni")
      };
}
