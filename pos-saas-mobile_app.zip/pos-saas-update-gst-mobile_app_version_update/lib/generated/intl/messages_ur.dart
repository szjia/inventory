// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a ur locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'ur';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("بل پلےز"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("جاری رکھیں"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("جی ایس ٹی نمبر"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("ایم آر پی ضروری ہے"),
        "OK": MessageLookupByLibrary.simpleMessage("ٹھیک ہے"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("پی او ایس ساس"),
        "Paypal": MessageLookupByLibrary.simpleMessage("پے پال"),
        "PhNo": MessageLookupByLibrary.simpleMessage("فون نمبر"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT کوڈ"),
        "Snacks": MessageLookupByLibrary.simpleMessage("اسنیکس"),
        "TAX": MessageLookupByLibrary.simpleMessage("ٹیکس"),
        "Uploading": MessageLookupByLibrary.simpleMessage("اپ لوڈ ہو رہا ہے"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("صارف عنوان"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "آپ کا پیکیج آج ختم ہو جائے گا\n\nبراہ کرم دوبارہ خریداری کریں"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(الف) سسٹم کو صرف فروخت کی نقل و حمل کرنے اور آپ کے کاروبار میں متعلق انشا کاری کیلئے فراہم کیا گیا ہے۔"),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(الف) سسٹم کا استعمال کرنے کے لئے، آپ سے طلب ہو سکتی ہے کہ آپ ایک اکاؤنٹ بنائیں۔ آپ تصدیق کرتے ہیں کہ رجسٹریشن کے دوران درست، موجودہ اور مکمل معلومات فراہم کریں اور ایسی معلومات کو تازہ کرنے کیلئے جوائز کریں تاکہ وہ درست اور مکمل رہے۔"),
        "aboutApp": MessageLookupByLibrary.simpleMessage("ایپ کے بارے میں"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("ہمارے بارے میں"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("شرائط کی قبولیت"),
        "accountName": MessageLookupByLibrary.simpleMessage("اکاؤنٹ کا نام"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("اکاؤنٹ نمبر"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("اکاؤنٹ رجسٹریشن"),
        "acton": MessageLookupByLibrary.simpleMessage("عمل"),
        "add": MessageLookupByLibrary.simpleMessage("شامل کریں"),
        "addBrand": MessageLookupByLibrary.simpleMessage("برانڈ شامل کریں"),
        "addCategory":
            MessageLookupByLibrary.simpleMessage("کیٹیگری شامل کریں"),
        "addContact": MessageLookupByLibrary.simpleMessage("رابطہ شامل کریں"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("گاہک شامل کریں"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("ترسیل شامل کریں"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("تفصیل شامل کریں"),
        "addDescription": MessageLookupByLibrary.simpleMessage("نوٹ شامل کریں"),
        "addDiscount":
            MessageLookupByLibrary.simpleMessage("ڈسکاؤنٹ شامل کریں"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("شناختی کارڈ شامل کریں"),
        "addDucument":
            MessageLookupByLibrary.simpleMessage("دستاویز شامل کریں"),
        "addExpense": MessageLookupByLibrary.simpleMessage("اخراج شامل کریں"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("اخراجات کی قسم شامل کریں"),
        "addItems": MessageLookupByLibrary.simpleMessage("آئٹمز شامل کریں"),
        "addNew": MessageLookupByLibrary.simpleMessage("نیا شامل کریں"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("نیا پتہ شامل کریں"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("نیا مصنوعہ شامل کریں"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("نیا ٹیکس شامل کریں"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "ایک یا زیادہ ٹیکس کی قسم کے ساتھ نیا ٹیکس شامل کریں"),
        "addNote": MessageLookupByLibrary.simpleMessage("نوٹ شامل کریں"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("پہلے پروڈکٹ شامل کریں"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("پرومو کوڈ شامل کریں"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("خرید شامل کریں"),
        "addSales": MessageLookupByLibrary.simpleMessage("فروخت شامل کریں"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("کامیابی سے شامل کیا گیا"),
        "addUnit": MessageLookupByLibrary.simpleMessage("یونٹ شامل کریں"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("صارف کردار شامل کریں"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("کامیابی سے شامل کیا گیا"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("ٹوکری میں شامل کر دیا گیا"),
        "address": MessageLookupByLibrary.simpleMessage("پتہ"),
        "admin": MessageLookupByLibrary.simpleMessage("ایڈمن"),
        "all": MessageLookupByLibrary.simpleMessage("سب"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("تمام کاروبار کے حل"),
        "alreadyAdded":
            MessageLookupByLibrary.simpleMessage("پہلے ہی شامل کیا جا چکا ہے"),
        "alreadyExists":
            MessageLookupByLibrary.simpleMessage("پہلے سے موجود ہے"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("پہلے سے اکاؤنٹ ہے؟"),
        "amount": MessageLookupByLibrary.simpleMessage("رقم"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "ایک ای میل بھیجی گئی ہے\\nاپنے ان باکس میں چیک کریں"),
        "androidIOSAppSupport":
            MessageLookupByLibrary.simpleMessage("Android اور iOS ایپ سپورٹ"),
        "applicableTax": MessageLookupByLibrary.simpleMessage("لاگو ٹیکس"),
        "apply": MessageLookupByLibrary.simpleMessage("لاگو کریں"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "کیا آپ اس انوائس کو حذف کرنے کے لیے یقین رکھتے ہیں؟"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "کیا آپ اس فروخت کو حذف کرنے کے لیے یقین رکھتے ہیں؟"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "کیا آپ اس صارف کو حذف کرنے کے لیے یقین رکھتے ہیں؟"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "کیا آپ واقعی اس ٹیکس کو حذف کرنا چاہتے ہیں؟"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "کیا آپ واقعی اس ٹیکس گروپ کو حذف کرنا چاہتے ہیں؟"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "کیا آپ واقعی اس گودام کو حذف کرنا چاہتے ہیں؟"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "کیا آپ اس صارف کو حذف کرنا چاہتے ہیں؟"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("مجازی دستخط"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(ب) آپ اپنے اکاؤنٹ اور پاس ورڈ کی رازداری کو برقرار رکھنے اور اپنے اکاؤنٹ کی رسمیت کو محدود کرنے کے لئے ذمہ دار ہیں۔ آپ اپنے اکاؤنٹ کے تحت واقع ہونے والی تمام سرگرمیوں کے لئے ذمہ داری قبول کرتے ہیں۔"),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(ب) آپ کو کم از کم 18 سال کے ہونا چاہئے یا آپ کے اختیار کی علیحدگی کی قانونی عمر کو استعمال کرنے کی اختیار ہونی چاہئے جو آپ کی علاقے میں لاگو ہوتی ہے۔"),
        "backSide": MessageLookupByLibrary.simpleMessage("پیچھے کی طرف"),
        "backToHome":
            MessageLookupByLibrary.simpleMessage("مرکزی صفحہ پر واپس جائیں"),
        "balance": MessageLookupByLibrary.simpleMessage("بیلنس"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("بنگلہ دیش"),
        "bank": MessageLookupByLibrary.simpleMessage("بینک"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("بینک اکاؤنٹ کی کرنسی"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("بینک اکاؤنٹ کرنسی"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("بینک کی معلومات"),
        "bankName": MessageLookupByLibrary.simpleMessage("بینک کا نام"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("بینک ٹرانسفر"),
        "barcodeFound": MessageLookupByLibrary.simpleMessage("بارکوڈ ملا"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("بل/انوائس"),
        "billTo": MessageLookupByLibrary.simpleMessage("بل بھیجیں"),
        "branchName": MessageLookupByLibrary.simpleMessage("شاخ کا نام"),
        "brand": MessageLookupByLibrary.simpleMessage("برانڈ"),
        "brandName": MessageLookupByLibrary.simpleMessage("برانڈ کا نام"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("بلک\nاپ لوڈ"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("کاروبار کی قسم"),
        "buy": MessageLookupByLibrary.simpleMessage("خریداری کریں"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("پریمیم پلان خریدیں"),
        "buySms": MessageLookupByLibrary.simpleMessage("ایس ایم ایس خریدیں"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "پوائنٹ آف سیل (پوز) سسٹم (\"سسٹم\") کا دسترسی یا استعمال کرکے، جو [آپ کی کمپنی کا نام] (\"کمپنی\") فراہم کرتی ہے، آپ ان شرائط کی پابندیوں کو تسلیم کرتے ہیں۔ اگر آپ ان شرائط کو منظور نہیں کرتے ہیں تو سسٹم کا استعمال نہ کریں۔"),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(ج) آپ ذمہ دار ہیں کہ آپ کی سسٹم کے دسترسی اور استعمال کو تمام لاگو ہونے والے قوانین اور پیروی کی تصدیق کریں۔"),
        "cacel": MessageLookupByLibrary.simpleMessage("منسوخ کریں"),
        "call": MessageLookupByLibrary.simpleMessage("کال کریں"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "ایمرجنسی سپورٹ کے لیے کال کریں"),
        "camera": MessageLookupByLibrary.simpleMessage("کیمرا"),
        "cancel": MessageLookupByLibrary.simpleMessage("کینسل کریں"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("تمام مصنوعات منسوخ کریں"),
        "capacity": MessageLookupByLibrary.simpleMessage("کمیت"),
        "card": MessageLookupByLibrary.simpleMessage("کارڈ"),
        "cash": MessageLookupByLibrary.simpleMessage("نقد"),
        "cashFree": MessageLookupByLibrary.simpleMessage("کیش فری"),
        "categories": MessageLookupByLibrary.simpleMessage("کیٹیگریاں"),
        "category": MessageLookupByLibrary.simpleMessage("کیٹیگری"),
        "categoryName": MessageLookupByLibrary.simpleMessage("زمرہ کا نام"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "زمرہ کا نام پہلے ہی موجود ہے"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("قسم کا نام"),
        "change": MessageLookupByLibrary.simpleMessage("تبدیل کریں؟"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("پاس ورڈ تبدیل کریں"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("ای میل چیک کریں"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("ایک مشتری منتخب کریں"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("فراہم کنندہ منتخب کریں"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("اپنی خصوصیات منتخب کریں"),
        "clarence": MessageLookupByLibrary.simpleMessage("کلیرنس"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("منسلک ہونے کے لئے کلک کریں"),
        "close": MessageLookupByLibrary.simpleMessage("بند کریں"),
        "color": MessageLookupByLibrary.simpleMessage("رنگ"),
        "combinationOfMultipleTaxes":
            MessageLookupByLibrary.simpleMessage("(کئی ٹیکسوں کا مجموعہ)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("جلد ہی آ رہا ہے"),
        "companyAddress": MessageLookupByLibrary.simpleMessage("کمپنی کا پتہ"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("کمپنی اور دکان کا نام"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("کمپنی اور کاروبار کا نام"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("مکمل لین دین"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("پاس ورڈ کی تصدیق کریں"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("واپسی کی تصدیق کریں"),
        "congratulations": MessageLookupByLibrary.simpleMessage("مبارک ہو"),
        "contactUs": MessageLookupByLibrary.simpleMessage("ہم سے رابطہ کریں"),
        "continu": MessageLookupByLibrary.simpleMessage("جاری رہیں"),
        "country": MessageLookupByLibrary.simpleMessage("ملک"),
        "create": MessageLookupByLibrary.simpleMessage("تخلیق کریں"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("مفت اکاؤنٹ بنائیں"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("تیار اور محفوظ کر دیا گیا"),
        "currency": MessageLookupByLibrary.simpleMessage("کرنسی"),
        "currentStock": MessageLookupByLibrary.simpleMessage("موجودہ اسٹاک"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("خصوصی فاترہ برانڈنگ"),
        "customer": MessageLookupByLibrary.simpleMessage("مشتری"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("گاہک کی تفصیلات"),
        "customerGST": MessageLookupByLibrary.simpleMessage("کسٹمر جی ایس ٹی"),
        "customerName": MessageLookupByLibrary.simpleMessage("گاہک کا نام"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("روزانہ لین دین"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("ڈیش بورڈ کا جائزہ"),
        "dataSavedSuccessfully": MessageLookupByLibrary.simpleMessage(
            "ڈیٹا کامیابی سے محفوظ ہو گیا"),
        "date": MessageLookupByLibrary.simpleMessage("تاریخ"),
        "day": MessageLookupByLibrary.simpleMessage("دن"),
        "dealer": MessageLookupByLibrary.simpleMessage("ڈیلر"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("ڈیلر کی قیمت"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("ڈیفالٹ VAT فیصد"),
        "delete": MessageLookupByLibrary.simpleMessage("حذف کریں"),
        "deleting": MessageLookupByLibrary.simpleMessage("حذف کر رہے ہیں"),
        "deliveryAddress": MessageLookupByLibrary.simpleMessage("ترسیل کا پتہ"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("ترسیل کے پتے"),
        "deliveryCharge": MessageLookupByLibrary.simpleMessage("ترسیل کی فیس"),
        "describtion": MessageLookupByLibrary.simpleMessage("تفصیل"),
        "description": MessageLookupByLibrary.simpleMessage("تفصیل"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("تفصیل خالی نہیں ہو سکتی"),
        "details": MessageLookupByLibrary.simpleMessage("تفصیلات"),
        "discount": MessageLookupByLibrary.simpleMessage("چھوٹ"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("تنگ نہ کریں"),
        "done": MessageLookupByLibrary.simpleMessage("ہو گیا"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("ایکسلی فارمیٹ ڈاؤن لوڈ کریں"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "ڈاؤن لوڈنگ کے فولڈر میں کامیابی سے ڈاؤن لوڈ کیا گیا"),
        "due": MessageLookupByLibrary.simpleMessage("قرض"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("قرض کی رقم: "),
        "dueCollection": MessageLookupByLibrary.simpleMessage("قرض کی جمع"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("موصولہ وصول رپورٹس"),
        "dueList": MessageLookupByLibrary.simpleMessage("قرض کی فہرست"),
        "dueReports": MessageLookupByLibrary.simpleMessage("قرض کی رپورٹ"),
        "duration": MessageLookupByLibrary.simpleMessage("مدت"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("مدت: سے"),
        "easyToUseMobilePos":
            MessageLookupByLibrary.simpleMessage("آسان استعمال موبائل پوز"),
        "edit": MessageLookupByLibrary.simpleMessage("ترمیم کریں"),
        "editPurchaseInvoice": MessageLookupByLibrary.simpleMessage(
            "خرید کی انوائس کی ترمیم کریں"),
        "editSalesInvoice": MessageLookupByLibrary.simpleMessage(
            "فروخت کی انوائس کی ترمیم کریں"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("سوشل میڈیا میں ترمیم کریں"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("کامیابی سے ترمیم کی گئی"),
        "editTax": MessageLookupByLibrary.simpleMessage("ٹیکس میں ترمیم کریں"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("ٹیکس گروپ میں ترمیم کریں"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("گودام میں ترمیم کریں"),
        "email": MessageLookupByLibrary.simpleMessage("ای میل"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("ای میل ایڈریس"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("ای میل خالی نہیں ہو سکتی"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "ای میل بھیج دی گئی! اپنے ان باکس میں چیک کریں"),
        "endDate": MessageLookupByLibrary.simpleMessage("ختم ہونے کی تاریخ"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("درست رقم درج کریں"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("صحیح ڈسکاؤنٹ درج کریں"),
        "enterAValidPhoneNumber":
            MessageLookupByLibrary.simpleMessage("درست فون نمبر درج کریں"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("صحیح قیمت درج کریں"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("صحیح مقدار درج کریں"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("پتہ درج کریں"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("رقم درج کریں۔"),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("برانڈ کا نام درج کریں"),
        "enterCapacity": MessageLookupByLibrary.simpleMessage("کمیت درج کریں"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("کیٹیگری کا نام درج کریں"),
        "enterColor": MessageLookupByLibrary.simpleMessage("رنگ درج کریں"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "کسٹمر کا جی ایس ٹی نمبر درج کریں"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("ڈیلر کی قیمت درج کریں"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("تفصیل درج کریں"),
        "enterDiscount": MessageLookupByLibrary.simpleMessage("چھوٹ درج کریں"),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("اخراجات کی تاریخ درج کریں"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("مکمل پتہ درج کریں"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("انوائس نمبر درج کریں"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "کم اسٹاک الرٹ کی مقدار درج کریں"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("مینوفیکچرر درج کریں"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("پیغام کی مواد درج کریں"),
        "enterMrpOrRetailerPirce":
            MessageLookupByLibrary.simpleMessage("MRP/ریٹیلر قیمت درج کریں"),
        "enterName": MessageLookupByLibrary.simpleMessage("نام درج کریں"),
        "enterNote": MessageLookupByLibrary.simpleMessage("نوٹ درج کریں"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("جماعت کا نام درج کریں"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("فون نمبر درج کریں"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "مصنوعہ کوڈ درج کریں یا اسکین کریں"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("مصنوعہ کا نام درج کریں"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("خریداری کی قیمت درج کریں"),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("حوالہ نمبر درج کریں"),
        "enterSize": MessageLookupByLibrary.simpleMessage("سائز درج کریں"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("اسٹاک درج کریں"),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("ٹیکس کی شرح درج کریں"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("ٹرانزیکشن آئی ڈی درج کریں"),
        "enterType": MessageLookupByLibrary.simpleMessage("قسم درج کریں"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("صارف عنوان درج کریں"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("درست رقم درج کریں"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("گودام کا نام درج کریں"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("وزن درج کریں"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("خرید فروخت قیمت درج کریں"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("یہاں اپنی تفصیلات درج کریں"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("اپنا ای میل ایڈریس درج کریں"),
        "enterYourFeedBackTitle":
            MessageLookupByLibrary.simpleMessage("اپنا فیڈبیک عنوان درج کریں"),
        "enterYourGSTNumber": MessageLookupByLibrary.simpleMessage(
            "اپنا جی ایس ٹی نمبر درج کریں"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("اپنا موبائل نمبر درج کریں"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("اپنا نام درج کریں"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("اپنا فون نمبر درج کریں"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("اپنا پاسورڈ درج کریں"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("اپنا فون نمبر درج کریں"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "اپنی لین دین کی شناخت درج کریں"),
        "error": MessageLookupByLibrary.simpleMessage("غلطی"),
        "excTax": MessageLookupByLibrary.simpleMessage("غیر شامل ٹیکس"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("ایکسلی اپلوڈر"),
        "exclusive": MessageLookupByLibrary.simpleMessage("غیر شامل"),
        "expense": MessageLookupByLibrary.simpleMessage("اخراجات"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("اخراجات کی قسم"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("اخراجات کی تاریخ"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("اخراجات کا لئے"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("اخراجات کی رپورٹ"),
        "expireDate": MessageLookupByLibrary.simpleMessage("ختم ہونے کی تاریخ"),
        "expired": MessageLookupByLibrary.simpleMessage("ختم ہو گیا"),
        "expiring": MessageLookupByLibrary.simpleMessage("ختم ہونے والا"),
        "facebok": MessageLookupByLibrary.simpleMessage("فیس بک"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("غلطی کے ساتھ ناکام"),
        "fashion": MessageLookupByLibrary.simpleMessage("فیشن"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "خصوصیات وہ اہم حصہ ہیں جو پوز سسٹم کو روایتی حلوں سے مختلف بناتے ہیں۔"),
        "feedBack": MessageLookupByLibrary.simpleMessage("فیڈبیک"),
        "firstName": MessageLookupByLibrary.simpleMessage("پہلا نام"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("ہمیں فیس بک پر فالو کریں"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("ہمیں ٹویٹر پر فالو کریں"),
        "fontSide": MessageLookupByLibrary.simpleMessage("سامنے کی طرف"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("لا محدود استعمال کے لئے"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("پاسورڈ بھول گئے ہیں"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("پاسورڈ بھول گئے ہیں؟"),
        "formDate": MessageLookupByLibrary.simpleMessage("تاریخ سے"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("مفت ڈیٹا بیک اپ"),
        "freeLifeTimeUpdate":
            MessageLookupByLibrary.simpleMessage("مفت مدتِ عمر کی اپ ڈیٹ"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("مفت پیکیج"),
        "freePlan": MessageLookupByLibrary.simpleMessage("مفت پلان"),
        "from": MessageLookupByLibrary.simpleMessage("(سے"),
        "fullyPaid":
            MessageLookupByLibrary.simpleMessage("پوری طرح ادا کیا گیا"),
        "gallary": MessageLookupByLibrary.simpleMessage("گیلری"),
        "generatingPDF":
            MessageLookupByLibrary.simpleMessage("پی ڈی ایف تیار کر رہے ہیں"),
        "getOtp": MessageLookupByLibrary.simpleMessage("OTP حاصل کریں"),
        "govermentId":
            MessageLookupByLibrary.simpleMessage("حکومتی شناختی کارڈ"),
        "guest": MessageLookupByLibrary.simpleMessage("مہمان"),
        "havenotAnAccounts": MessageLookupByLibrary.simpleMessage(
            "کیا آپ کا کوئی اکاؤنٹ نہیں ہے؟"),
        "history": MessageLookupByLibrary.simpleMessage("تاریخ"),
        "home": MessageLookupByLibrary.simpleMessage("ہوم"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "آپ کی معلومات کی حفاظت کیسے کرتے ہیں"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "آپ کی معلومات کا استعمال کیسے کرتے ہیں"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("شناخت تصدیق کریں"),
        "image": MessageLookupByLibrary.simpleMessage("تصویر"),
        "inHouseCantBeDelete": MessageLookupByLibrary.simpleMessage(
            "ان ہاؤس کو حذف نہیں کیا جا سکتا"),
        "inHouseCantBeEdited": MessageLookupByLibrary.simpleMessage(
            "ان ہاؤس میں ترمیم نہیں کی جا سکتی"),
        "inWord": MessageLookupByLibrary.simpleMessage("الفاظ میں"),
        "incTax": MessageLookupByLibrary.simpleMessage("شامل ٹیکس"),
        "inclusive": MessageLookupByLibrary.simpleMessage("شامل"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("اسٹاک بڑھائیں"),
        "inistrument": MessageLookupByLibrary.simpleMessage("اسٹرومنٹ"),
        "instragram": MessageLookupByLibrary.simpleMessage("انسٹاگرام"),
        "invNo": MessageLookupByLibrary.simpleMessage("انوائس نمبر"),
        "invoice": MessageLookupByLibrary.simpleMessage("انوائس"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("انوائس نمبر"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("انوائس کی ترتیبات"),
        "invoiceViewer": MessageLookupByLibrary.simpleMessage("انوائس ویوئر"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("آئٹم شامل ہوگیا"),
        "kg": MessageLookupByLibrary.simpleMessage("کلوگرام"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("کی وائی سی تصدیق"),
        "language": MessageLookupByLibrary.simpleMessage("زبان"),
        "lastName": MessageLookupByLibrary.simpleMessage("آخری نام"),
        "ledger": MessageLookupByLibrary.simpleMessage("لیجر"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("لائف ٹائم خریداری"),
        "link": MessageLookupByLibrary.simpleMessage("لنک"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("لنکڈ ان"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("لائیو چیٹ سپورٹ"),
        "loading": MessageLookupByLibrary.simpleMessage("لوڈ ہو رہا ہے"),
        "logIn": MessageLookupByLibrary.simpleMessage("لاگ ان کریں"),
        "logOUt": MessageLookupByLibrary.simpleMessage("لاگ آؤٹ"),
        "logOut": MessageLookupByLibrary.simpleMessage("لاگ آؤٹ"),
        "login": MessageLookupByLibrary.simpleMessage("لاگ ان"),
        "logo": MessageLookupByLibrary.simpleMessage("لوگو"),
        "loss": MessageLookupByLibrary.simpleMessage("نقصان"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("نقصان/منافع"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("نقصان/منافع کی تفصیلات"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("نقصان/منافع کی رپورٹ"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("نقصان/منافع کی رپورٹس"),
        "lowStockAlert": MessageLookupByLibrary.simpleMessage("کم اسٹاک الرٹ"),
        "maan": MessageLookupByLibrary.simpleMessage("مان"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "برانڈ انوائسز کے ساتھ اپنے گاہکوں پر مستقل اثر ڈالیں۔ ہمارا انتہائی اپ گریڈ آپ کو اپنی انوائس کو تخصیص دینے کے مخصوص فوائد پیش کرتا ہے، جو آپ کی برانڈ کی شناخت کو مضبوطی دیتا ہے اور گاہک وفاداری کو فروغ دیتا ہے۔"),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("اپنے کاروبار کو منظم کریں "),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("پیداوار کی تاریخ"),
        "margin": MessageLookupByLibrary.simpleMessage("مارجن"),
        "masterCard": MessageLookupByLibrary.simpleMessage("ماسٹر کارڈ"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("مینوفیکچرر"),
        "message": MessageLookupByLibrary.simpleMessage("پیغام"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("پیغام کی تاریخ"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Pos Saas ایپ مفت ہے، استعمال کرنے میں آسان ہے۔ حقیقت میں، یہ دنیا بھر میں بہترین پوز سسٹموں میں سے ایک ہے۔"),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas ایک مکمل کاروبار کا حل ہے جس میں اسٹاک، اکاؤنٹ، فروخت، اخراجات اور نفع/نقصان شامل ہیں۔"),
        "mobile": MessageLookupByLibrary.simpleMessage("موبائل"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("موبائل ادائیگی"),
        "monthly": MessageLookupByLibrary.simpleMessage("ماہانہ"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("مزید معلومات"),
        "name": MessageLookupByLibrary.simpleMessage("اپنا نام درج کریں۔"),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("نام پہلے ہی موجود ہے"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("نام خالی نہیں ہو سکتا"),
        "next": MessageLookupByLibrary.simpleMessage("اگلا"),
        "noConnection": MessageLookupByLibrary.simpleMessage("کوئی کنکشن نہیں"),
        "noData": MessageLookupByLibrary.simpleMessage("کوئی ڈیٹا نہیں"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("کوئی ڈیٹا دستیاب نہیں ہے"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("کوئی ڈیٹا نہیں ملا"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("کوئی تاریخ نہیں ملی!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("کوئی پروڈکٹ نہیں ملی"),
        "noSubTaxSelected": MessageLookupByLibrary.simpleMessage(
            "کوئی ذیلی ٹیکس منتخب نہیں کیا گیا"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("کوئی لین دین نہیں ملی!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "اس ای میل کے لئے کوئی صارف موجود نہیں ہے۔"),
        "noUserRoleFound":
            MessageLookupByLibrary.simpleMessage("کوئی صارف کردار نہیں ملا"),
        "notActiveUser": MessageLookupByLibrary.simpleMessage("غیر فعال صارف"),
        "notProvided":
            MessageLookupByLibrary.simpleMessage("فراہم نہیں کیا گیا"),
        "note": MessageLookupByLibrary.simpleMessage("نوٹ"),
        "notes": MessageLookupByLibrary.simpleMessage("نوٹس"),
        "notification": MessageLookupByLibrary.simpleMessage("نوٹیفیکیشن"),
        "oTPSentTo":
            MessageLookupByLibrary.simpleMessage("او ٹی پی بھیج دیا گیا"),
        "office": MessageLookupByLibrary.simpleMessage("دفتر"),
        "ok": MessageLookupByLibrary.simpleMessage("ٹھیک ہے"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "ایک پوائنٹ آف سیل (پوز) جو فروخت کی نقل و حمل اور انفرادی کارکری کیلئے بہت زیادہ فعالیت کا حامل ہے۔"),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "یہ سسٹم آپ کی کارکری کو آپ کے مشتریوں کیلئے بہتر بنانے میں آپ کی مدد کرتا ہے۔"),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "ہمارا پوائنٹ آف سیل سسٹم خود کار دن کی سب سے بہترین تجربے کو سادہ بنانے میں مدد فراہم کرتا ہے، جسے آسانی سے ہدایت دی جا سکتی ہے۔"),
        "openingBalance": MessageLookupByLibrary.simpleMessage("آغازی بیلنس"),
        "order": MessageLookupByLibrary.simpleMessage("آرڈرز"),
        "other": MessageLookupByLibrary.simpleMessage("دیگر"),
        "otp": MessageLookupByLibrary.simpleMessage("بند کریں"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("اسٹاک میں نہیں ہے"),
        "pacakge": MessageLookupByLibrary.simpleMessage("پیکیج"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("پیکیج کی خصوصیات"),
        "paid": MessageLookupByLibrary.simpleMessage("ادا کیا گیا"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("ادا کی گئی رقم"),
        "parties": MessageLookupByLibrary.simpleMessage("جماعتیں"),
        "partiesList": MessageLookupByLibrary.simpleMessage("جماعتیں کی فہرست"),
        "partyGST": MessageLookupByLibrary.simpleMessage("پارٹی جی ایس ٹی"),
        "partyName": MessageLookupByLibrary.simpleMessage("جماعت کا نام"),
        "password": MessageLookupByLibrary.simpleMessage("پاس ورڈ"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "پاسورڈ اور تصدیقی پاسورڈ ملتے نہیں"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("پاسورڈ خالی نہیں ہو سکتا"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("پاسورڈ میل نہیں کھاتا"),
        "payCash": MessageLookupByLibrary.simpleMessage("نقد ادائیگی کریں"),
        "payStack": MessageLookupByLibrary.simpleMessage("پے اسٹیک"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("بکاش کے ساتھ ادائیگی کریں"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("پے پال کے ساتھ ادائیگی کریں"),
        "payeeName":
            MessageLookupByLibrary.simpleMessage("ادائیگی کرنے والا کا نام"),
        "payeeNumber":
            MessageLookupByLibrary.simpleMessage("ادائیگی کرنے والا کا نمبر"),
        "payment": MessageLookupByLibrary.simpleMessage("ادائیگی"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("ادائیگی کی رقم"),
        "paymentComplete": MessageLookupByLibrary.simpleMessage("ادائیگی مکمل"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("ادائیگی کی ہدایات:"),
        "paymentMethod":
            MessageLookupByLibrary.simpleMessage("ادائیگی کا طریقہ"),
        "paymentType": MessageLookupByLibrary.simpleMessage("ادائیگی کی قسم"),
        "pdfView": MessageLookupByLibrary.simpleMessage("پی ڈی ایف ویو"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("ذاتی معلومات"),
        "phone": MessageLookupByLibrary.simpleMessage("فون"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("فون نمبر"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "فون نمبر پہلے ہی استعمال کیا جا چکا ہے"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("فون نمبر درست نہیں ہے"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("فون نمبر ضروری ہے"),
        "pickAndUploadFile": MessageLookupByLibrary.simpleMessage(
            "فائل منتخب کریں اور اپ لوڈ کریں"),
        "pickEndDate": MessageLookupByLibrary.simpleMessage(
            "ختم ہونے کی تاریخ منتخب کریں"),
        "pickStartDate": MessageLookupByLibrary.simpleMessage(
            "شروع کرنے کی تاریخ منتخب کریں"),
        "plan": MessageLookupByLibrary.simpleMessage("منصوبہ"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("براہ کرم مقدار شامل کریں"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "براہ کرم اپنے انٹرنیٹ کنکشن کی جانچ کریں"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "براہ کرم پہلے پرنٹر منسلک کریں"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "براہ کرم اپنے بلوٹوتھ پرنٹر کو منسلک کریں"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "براہ کرم بڑا پاسورڈ درج کریں"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "براہ کرم پاس ورڈ کی تصدیق کریں"),
        "pleaseEnterAPassword": MessageLookupByLibrary.simpleMessage(
            "براہ کرم ایک پاس ورڈ درج کریں"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "براہ کرم درست ای میل درج کریں"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("براہ کرم نام درج کریں"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("براہ کرم پاسورڈ درج کریں"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "براہ کرم اپنا ای میل ایڈریس درج کریں تاکہ آپ پاس ورڈ ری سیٹ لنک حاصل کر سکیں۔"),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "براہ کرم لین دین کا نمبر درج کریں"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("براہ کرم رقم درج کریں"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "براہ کرم پہلے ایک زمرہ منتخب کریں"),
        "pleaseSelectAPlan": MessageLookupByLibrary.simpleMessage(
            "براہ کرم ایک منصوبہ منتخب کریں"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "براہ کرم کاروباری زمرہ منتخب کریں"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "براہ کرم ایپ استعمال کرنے کے لیے درست خریداری کا کوڈ استعمال کریں"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Pos Saas کی طرف سے ممتاز"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("کی مدد سے"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("پریمیم گاہک حمایت"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("پریمیم پلان"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("پچھلے ادائیگی رقمیں"),
        "price": MessageLookupByLibrary.simpleMessage("قیمت"),
        "print": MessageLookupByLibrary.simpleMessage("پرنٹ کریں"),
        "printingOption": MessageLookupByLibrary.simpleMessage("پرنٹنگ اختیار"),
        "privacyPolicy": MessageLookupByLibrary.simpleMessage("رازداری پالیسی"),
        "product": MessageLookupByLibrary.simpleMessage("مصنوعات"),
        "productCode": MessageLookupByLibrary.simpleMessage("مصنوعہ کوڈ"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("مصنوعات کا کوڈ ضروری ہے"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("پروڈکٹ کوڈ/نام"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("پروڈکٹ کی تفصیل"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("مصنوعات کی تفصیلات"),
        "productList": MessageLookupByLibrary.simpleMessage("مصنوعہ فہرست"),
        "productName": MessageLookupByLibrary.simpleMessage("مصنوعہ کا نام"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "یہ مصنوعات کا نام پہلے ہی اس گودام میں موجود ہے"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "پروڈکٹ کا نام پہلے ہی شامل کیا جا چکا ہے"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("مصنوعات کا نام ضروری ہے"),
        "products": MessageLookupByLibrary.simpleMessage("پروڈکٹس"),
        "profile": MessageLookupByLibrary.simpleMessage("پروفائل"),
        "profileEdit":
            MessageLookupByLibrary.simpleMessage("پروفائل ترتیب دیں"),
        "profit": MessageLookupByLibrary.simpleMessage("منافع"),
        "promo": MessageLookupByLibrary.simpleMessage("پرومو"),
        "promoCode": MessageLookupByLibrary.simpleMessage("پرومو کوڈ"),
        "purchase": MessageLookupByLibrary.simpleMessage("خرید"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("خریداری کی الارم"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("خریداری تصدیق شدہ"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("خرید کی تفصیلات"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("خریداری کی انوائس"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("خرید کی فہرست"),
        "purchaseNow":
            MessageLookupByLibrary.simpleMessage("ابھی خریداری کریں"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("پریمیم پلان خریدیں"),
        "purchasePrice":
            MessageLookupByLibrary.simpleMessage("خریداری کی قیمت"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("خریداری کی قیمت ضروری ہے"),
        "purchaseRepoet": MessageLookupByLibrary.simpleMessage("خرید کی رپورٹ"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("خرید کی رپورٹ"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("خریداری کی رپورٹس"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("خریداری کی واپسی"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("خریداری کی واپسی کی رپورٹ"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("خریداری کا منتقلی"),
        "qty": MessageLookupByLibrary.simpleMessage("مقدار"),
        "quantity": MessageLookupByLibrary.simpleMessage("مقدار"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("تازہ ترین لین دین"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("پن موصول کیا گیا"),
        "referenceNumber": MessageLookupByLibrary.simpleMessage("حوالہ نمبر"),
        "register": MessageLookupByLibrary.simpleMessage("رجسٹر کریں"),
        "registering": MessageLookupByLibrary.simpleMessage("رجسٹر ہو رہا ہے"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("باقی قرض"),
        "remove": MessageLookupByLibrary.simpleMessage("ہٹا دیں"),
        "reports": MessageLookupByLibrary.simpleMessage("رپورٹس"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("درخواست بھیج دی گئی ہے"),
        "resendCode": MessageLookupByLibrary.simpleMessage("کوڈ دوبارہ بھیجیں"),
        "resendOtp":
            MessageLookupByLibrary.simpleMessage("OTP دوبارہ بھیجیں: "),
        "retailer": MessageLookupByLibrary.simpleMessage("خوردہ فروش"),
        "retur": MessageLookupByLibrary.simpleMessage("واپس"),
        "returN": MessageLookupByLibrary.simpleMessage("واپسی"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("رقم واپسی"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("واپسی رقم"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("واپسی کی مقدار"),
        "revenue": MessageLookupByLibrary.simpleMessage("آمدنی"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "آسانی سے اپنے کاروبار کے ڈیٹا کو محفوظ کریں۔ ہمارا Pos Saas POS بے محدود اپ گریڈ مفت ڈیٹا بیک اپ شامل ہے، جو آپ کی قیمتی معلومات کو ناگہانی واقعات کے خلاف محفوظ رکھتا ہے۔ واقعی اہم چیزوں پر توجہ دیں - آپ کے کاروبار کی نمائندگی۔"),
        "saleAmount": MessageLookupByLibrary.simpleMessage("فروخت کی رقم"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("فروخت کی تفصیلات"),
        "salePrice": MessageLookupByLibrary.simpleMessage("فروخت کی قیمت"),
        "saleReports": MessageLookupByLibrary.simpleMessage("فروخت کی رپورٹ"),
        "saleReportss": MessageLookupByLibrary.simpleMessage("فروخت کی رپورٹس"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("فروخت کی واپسی"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("فروخت کی واپسی کی رپورٹ"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("فروخت کی ترتیب"),
        "sales": MessageLookupByLibrary.simpleMessage("فروخت"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("فروخت اور خریداری رپورٹس"),
        "salesList": MessageLookupByLibrary.simpleMessage("فروخت کی فہرست"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("فروخت کی واپسی"),
        "save": MessageLookupByLibrary.simpleMessage("محفوظ کریں"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("محفوظ کریں اور شائع کریں"),
        "saveChanges":
            MessageLookupByLibrary.simpleMessage("تبدیلیاں محفوظ کریں"),
        "saving": MessageLookupByLibrary.simpleMessage("محفوظ کر رہے ہیں"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("پروڈکٹ کا QR کوڈ اسکین کریں"),
        "search": MessageLookupByLibrary.simpleMessage("تلاش کریں"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "پروڈکٹ کوڈ یا نام سے تلاش کریں"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("تمام پرومو کوڈ دیکھیں"),
        "select": MessageLookupByLibrary.simpleMessage("منتخب کریں"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "واپسی کے لیے ایک پروڈکٹ منتخب کریں"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("برانڈ منتخب کریں"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("زمرہ منتخب کریں"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("رابطے منتخب کریں"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("مصنوعات کا زمرہ منتخب کریں"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("دکان کا زمرہ منتخب کریں"),
        "selectTax": MessageLookupByLibrary.simpleMessage("ٹیکس منتخب کریں"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("ٹیکس کی قسم منتخب کریں"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("یونٹ منتخب کریں"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("متغیرات منتخب کریں: "),
        "seller": MessageLookupByLibrary.simpleMessage("بیچنے والا"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("فروخت کنندہ"),
        "send": MessageLookupByLibrary.simpleMessage("بھیجیں"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("ای میل بھیجیں"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("پیغام بھیجیں"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("ری سیٹ لنک بھیجیں"),
        "sendSms": MessageLookupByLibrary.simpleMessage("اس ایم ایس بھیجیں"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("ایس ایم ایس بھیجیں؟"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("واٹس ایپ پیغام بھیجیں"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("اپنا ای میل بھیجیں"),
        "sendingEmail":
            MessageLookupByLibrary.simpleMessage("ای میل بھیج رہے ہیں"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("پیغام بھیج رہا ہے"),
        "serviceShipping": MessageLookupByLibrary.simpleMessage("سروس/شپنگ"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("اپنی پروفائل تشکیل دیں"),
        "setting": MessageLookupByLibrary.simpleMessage("سیٹنگ"),
        "share": MessageLookupByLibrary.simpleMessage("اشتراک کریں"),
        "shopGST": MessageLookupByLibrary.simpleMessage("دکان کا جی ایس ٹی"),
        "signIn": MessageLookupByLibrary.simpleMessage("سائن ان کریں"),
        "signInWithEmail": MessageLookupByLibrary.simpleMessage(
            "ای میل کے ذریعے سائن ان کریں"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("کسٹمر کے دستخط"),
        "size": MessageLookupByLibrary.simpleMessage("سائز"),
        "skip": MessageLookupByLibrary.simpleMessage("چھوڑیں"),
        "sms": MessageLookupByLibrary.simpleMessage("ایس ایم ایس"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("سوشل مارکیٹنگ"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "معاف کریں، آپ کو اس خدمت تک رسائی کی اجازت نہیں ہے"),
        "startDate": MessageLookupByLibrary.simpleMessage("شروع کرنے کی تاریخ"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("نیا فروخت شروع کریں"),
        "startTypingToSearch":
            MessageLookupByLibrary.simpleMessage("تلاش کرنے کے لئے ٹائپ کریں"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "کسی بھی اضافی لاگت کے بغیر تکنولوجی کی ترقی کے سامنے رہیں. ہمارا Pos Saas POS Unlimited اپ گریڈ یہ یقینی بناتا ہے کہ آپ ہمیشہ آپ کے انگلیوں پر تازہ ترین ٹولز اور خصوصیات رکھتے ہیں، جو آپ کے کاروبار کو بندوبست رکھنے کی ضمانت دیتا ہے۔"),
        "stillUnpaid":
            MessageLookupByLibrary.simpleMessage("ابھی بھی غیر ادا شدہ"),
        "stock": MessageLookupByLibrary.simpleMessage("اسٹاک"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("اسٹاک ضروری ہے"),
        "stockList": MessageLookupByLibrary.simpleMessage("اسٹاک کی فہرست"),
        "stocks": MessageLookupByLibrary.simpleMessage("اسٹاک"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "ایکسلی فائل بنانے کے لیے اسٹوریج کی اجازت ضروری ہے"),
        "subTaxList":
            MessageLookupByLibrary.simpleMessage("ذیلی ٹیکس کی فہرست"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("ذیلی ٹیکس"),
        "subTotal": MessageLookupByLibrary.simpleMessage("ذیلی کل"),
        "submit": MessageLookupByLibrary.simpleMessage("جمع کرائیں"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "ہمارے یوٹیوب چینل کو سبسکرائب کریں"),
        "subscription": MessageLookupByLibrary.simpleMessage("سبسکرپشن"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("کامیابی سے ہو گیا"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("کامیابی سے لاگ آؤٹ ہو گیا"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("کامیابی سے اپ ڈیٹ کیا گیا"),
        "supplier": MessageLookupByLibrary.simpleMessage("سپلائر"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("فراہم کنندہ کا نام"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT کوڈ"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "ڈرائیورز لائسنس، قومی شناختی کارڈ یا پاسپورٹ کی تصویر لے لیں"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "اپنی معلومات کی تصدیق کرنے کے لئے ایک شناختی کارڈ لے لیں"),
        "tap": MessageLookupByLibrary.simpleMessage("ٹپ کریں"),
        "tax": MessageLookupByLibrary.simpleMessage("ٹیکس"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("ٹیکس گروپ"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("ٹیکس فیصد"),
        "taxRate": MessageLookupByLibrary.simpleMessage("ٹیکس کی شرح"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "ٹیکس کی شرحیں - اپنی ٹیکس کی شرحیں منظم کریں"),
        "taxReport": MessageLookupByLibrary.simpleMessage("ٹیکس رپورٹ"),
        "taxType": MessageLookupByLibrary.simpleMessage("ٹیکس کی قسم"),
        "taxes": MessageLookupByLibrary.simpleMessage("ٹیکس"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("شرائط و ضوابط"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("استعمال کی شرائط"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("شرائط اور رازداری"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "آپ کی قرض کی ادائیگی کا شکریہ"),
        "thankYou": MessageLookupByLibrary.simpleMessage("شکریہ"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("آپ کی خریداری کا شکریہ"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "اس ای میل کے لیے اکاؤنٹ پہلے ہی موجود ہے"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "ایکسلی فائل پہلے ہی ڈاؤن لوڈ ہو چکی ہے"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "نام ہی کافی ہے. پوز Saas POS بے محدود کے ساتھ، آپ کے استعمال پر کوئی پابندی نہیں ہے۔ چاہے آپ کچھ ترنزکشن کی پرکسیس کر رہے ہیں یا کسی آپس کے آنے کا سامنا کر رہے ہیں، آپ اعتماد کے ساتھ کام کر سکتے ہیں، جانتے ہیں کہ آپ کو کوئی پابندی نہیں ہے۔"),
        "thePasswordProvidedIsTooWeak":
            MessageLookupByLibrary.simpleMessage("دی گئی پاسورڈ بہت کمزور ہے"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "یہ فروخت حذف کر دی جائے گی اور اس خریداری کے بارے میں تمام ڈیٹا حذف ہو جائے گا۔ کیا آپ واقعی اسے حذف کرنا چاہتے ہیں؟"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "یہ فروخت حذف کر دی جائے گی اور اس فروخت کے بارے میں تمام ڈیٹا حذف ہو جائے گا۔ کیا آپ واقعی اسے حذف کرنا چاہتے ہیں؟"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "صارف کو حذف کیا جائے گا اور تمام ڈیٹا آپ کے اکاؤنٹ سے حذف کر دیا جائے گا۔ کیا آپ واقف ہیں کہ آپ اسے حذف کرنا چاہتے ہیں؟"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "صارف حذف کر دیا جائے گا اور آپ کے اکاؤنٹ سے تمام ڈیٹا حذف ہو جائے گا۔ کیا آپ واقعی حذف کرنا چاہتے ہیں؟"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("تیسری پارٹی کی خدمات"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "یہ زمرہ حذف نہیں کیا جا سکتا"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(اس مہینے)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "یہ مصنوعات پہلے ہی شامل کی جا چکی ہے"),
        "title": MessageLookupByLibrary.simpleMessage("عنوان"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("عنوان خالی نہیں ہو سکتا"),
        "to": MessageLookupByLibrary.simpleMessage("تک"),
        "toDate": MessageLookupByLibrary.simpleMessage("تاریخ تک"),
        "today": MessageLookupByLibrary.simpleMessage("آج"),
        "total": MessageLookupByLibrary.simpleMessage("کل"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("کل رقم"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("مجموعی طور پر جمع کیا گیا"),
        "totalDue": MessageLookupByLibrary.simpleMessage("کل قرض"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("کل اخراجات"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("مجموعی نقصان"),
        "totalPayable": MessageLookupByLibrary.simpleMessage("کل ادائیگی"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("کل قیمت"),
        "totalProducts": MessageLookupByLibrary.simpleMessage("مجموعی مصنوعات"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("مجموعی منافع"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("مجموعی خریداری"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("مجموعی واپسی کی رقم"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("مجموعی واپسی"),
        "totalSale": MessageLookupByLibrary.simpleMessage("کل فروخت"),
        "totalStock": MessageLookupByLibrary.simpleMessage("کل اسٹاک"),
        "totalValue": MessageLookupByLibrary.simpleMessage("مجموعی قیمت"),
        "totalVat": MessageLookupByLibrary.simpleMessage("کل ویٹ"),
        "totals": MessageLookupByLibrary.simpleMessage("کل: "),
        "transaction": MessageLookupByLibrary.simpleMessage("لین دین"),
        "transactionId":
            MessageLookupByLibrary.simpleMessage("لین دین کی شناخت"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("دوبارہ کوشش کریں"),
        "twitter": MessageLookupByLibrary.simpleMessage("ٹوئٹر"),
        "type": MessageLookupByLibrary.simpleMessage("قسم"),
        "unitName": MessageLookupByLibrary.simpleMessage("یونٹ کا نام"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("فی اکائی قیمت"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("یونٹ قیمت"),
        "units": MessageLookupByLibrary.simpleMessage("یونٹس"),
        "unlimited": MessageLookupByLibrary.simpleMessage("لامحدود"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("غیر محدود استعمال"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "پوز Saas POS کی مکمل مخصوص تربیت سیشنوں کے ساتھ مکمل قوت کو کھولیں جو ہماری ماہر ٹیم کے زیرِ اہتمام ہے۔ بنیاد سے انتہائی تکنیکوں تک، ہم یقینی بناتے ہیں کہ آپ کاروبار کی پروسیسز کو بہتر بنانے کے لئے نظام کے ہر پہلو کو استفادہ کرنے میں ماہر ہیں۔"),
        "unpaid": MessageLookupByLibrary.simpleMessage("غیر ادا شدہ"),
        "update": MessageLookupByLibrary.simpleMessage("تازہ کاری کریں"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("رابطہ اپ ڈیٹ کریں"),
        "updateNow": MessageLookupByLibrary.simpleMessage("ابھی اپ ڈیٹ کریں"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("مصنوعہ اپ ڈیٹ کریں"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "پہلے اپنے منصوبے کو اپ ڈیٹ کریں، آپ کی حد ختم ہو چکی ہے"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("اپنی پروفائل اپ ڈیٹ کریں"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "اپنی پروفائل کو اپ ڈیٹ کریں تاکہ آپ کا ڈاکٹر بہتر تاثر دینے کے لئے آپ کے ساتھ منسلک ہو سکے"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "بہتر تاثر کے لئے اپنی پروفائل اپ ڈیٹ کریں تاکہ آپ کا گاہک منسلک ہو سکے"),
        "updated": MessageLookupByLibrary.simpleMessage("اپ ڈیٹ ہو گیا"),
        "upload": MessageLookupByLibrary.simpleMessage("اپ لوڈ کریں"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("دستاویز اپ لوڈ کریں"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("اپ لوڈ مکمل"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("فائل اپ لوڈ کریں"),
        "upplier": MessageLookupByLibrary.simpleMessage("سپلائر"),
        "usbC": MessageLookupByLibrary.simpleMessage("یو ایس بی سی"),
        "use": MessageLookupByLibrary.simpleMessage("استعمال کریں"),
        "useMobiPos":
            MessageLookupByLibrary.simpleMessage("Pos Saas کا استعمال کریں"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("سسٹم کا استعمال"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("صارف حذف کر دیا گیا"),
        "userRole": MessageLookupByLibrary.simpleMessage("صارف کردار"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("صارف کردار تفصیلات"),
        "userTitle": MessageLookupByLibrary.simpleMessage("صارف عنوان"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "صارف کا عنوان خالی نہیں ہو سکتا"),
        "value": MessageLookupByLibrary.simpleMessage("قیمت"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("ویٹ لاگو نہیں ہوتا"),
        "verifyOtp":
            MessageLookupByLibrary.simpleMessage("OTP کی تصدیق کر رہے ہیں"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("فون نمبر کی تصدیق کریں"),
        "viewAll": MessageLookupByLibrary.simpleMessage("تمام دیکھیں"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("تفصیلات دیکھیں"),
        "walkInCustomer": MessageLookupByLibrary.simpleMessage("واک ان مشتری"),
        "warehouse": MessageLookupByLibrary.simpleMessage("گودام"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("گودام پہلے ہی موجود ہے"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("گودام کی فہرست"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("گودام کا نام"),
        "warranty": MessageLookupByLibrary.simpleMessage("ضمانت"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "ہم نے ایک ای میل بھیجا ہے جس میں دستور دئے گئے ہیں کہ آپ پاس ورڈ دوبارہ ترتیب دیں:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "ہم ہماری ایپ کی فعالیت کو حمایت دینے کے لئے تیسری پارٹی کی خدمات کا استعمال کرتے ہیں، جیسے کے تجزیہ کاروں کے فراہم کنندگان اور ادائیگی کاروں کو۔ جب آپ ہماری ایپ کا استعمال کرتے ہیں تو یہ تیسری پارٹی خدمات آپ کی معلومات کو جمع کرسکتی ہیں۔ براہ کرم نوٹ کریں کہ ہم ان تیسری پارٹی خدمات کی رازداری عمل کا ذمہ دار نہیں ہیں۔"),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "ہم آپ کی شخصی معلومات کی حفاظت کے لئے صنعت کے معیاری اقدامات اٹھاتے ہیں، جیسے کے کوڈنامہ بندی اور محفوظ ذخیرہ کاری۔ ہم آپ کی معلومات کا رسمی دسترس کی حدود کو صرف متصدق کردہ عملہ کے لئے محدود کرتے ہیں۔"),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            " ہم سلسلہ وار کارروائیوں کی اہمیت کو سمجھتے ہیں۔ اسی وجہ سے ہماری 24/7 حمایت آپ کی مدد کے لئے دستیاب ہے، چاہے وہ تیز پوچھ تیز جواب ہو یا کامل تشویش ہو۔ ہم سے کہیں بھی کبھی بھی رابطہ کریں یا کال یا وٹس ایپ کے ذریعے بے مثل گاہک خدمت کا تجربہ کریں۔"),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "ہم آپ کی شخصی معلومات کا استعمال ہماری ایپ کیسے بہترین تجربے فراہم کرنے کیلئے کرتے ہیں، اس میں آپ کے مواد کی تجویز کو شخصی بنانا، ماہرین سے رابطہ کرنا، اور ہماری ایپ کی فعالیت کو بہتر بنانا شامل ہے۔ ہم ممکن ہے کہ آپ کی معلومات کا استعمال اپ ڈیٹس، فروخت کا پروموشنز، یا ہماری ایپ سے متعلق دیگر معلومات کو آپ کے ساتھ بات چیت کرنے کے لئے کریں۔"),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "ہم ادائیگی کا جائزہ لیں گے اور اسے 1-2 گھنٹوں کے اندر منظور کریں گے"),
        "weekly": MessageLookupByLibrary.simpleMessage("ہفتہ وار"),
        "weight": MessageLookupByLibrary.simpleMessage("وزن"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("نیا کیا ہے"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("ہول سیلر"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("خرید فروخت قیمت"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("ہول سیل قیمت"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("ہول سیلر"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("جلد ہی شامل کیا جائے گا"),
        "willExpireAt":
            MessageLookupByLibrary.simpleMessage("یہ وقت پر ختم ہوگا"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("یہاں اپنا پیغام لکھیں"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("غلط او ٹی پی"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "اس صارف کے لئے غلط پاس ورڈ دیا گیا ہے۔"),
        "yearly": MessageLookupByLibrary.simpleMessage("سالانہ"),
        "yesDeleteForever": MessageLookupByLibrary.simpleMessage(
            "جی ہاں، مکمل طور پر حذف کریں"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("آپ ایک درست صارف نہیں ہیں"),
        "youAreUsing":
            MessageLookupByLibrary.simpleMessage("آپ استعمال کر رہے ہیں"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "آپ مقررہ رقم سے زیادہ نہیں ادا کر سکتے"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("آپ کو ایک ای میل ملا ہے"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "آپ کامیابی سے اپنے اکاؤنٹ میں لاگ ان ہو گئے ہیں۔ Pos Saas کے ساتھ رہیں۔"),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("آپ کو اجازت دینی ہوگی"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "آپ کو اپنے اکاؤنٹ پر دوبارہ لاگ ان کرنا ہوگا۔"),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "آپ کو خریداری سے پہلے اپنی شناخت تصدیق کرنی ہوگی"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("آپ کا پیغام باقی رہتا ہے"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("آپ کی پیکیج"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "آپ کا پیکیج 5 دنوں میں ختم ہو جائے گا")
      };
}
