// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a no locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'no';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Fortsett"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("GST-nummer"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired": MessageLookupByLibrary.simpleMessage("MRP er påkrevd"),
        "OK": MessageLookupByLibrary.simpleMessage("OK"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Tlf.no"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT-kode"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Snacks"),
        "TAX": MessageLookupByLibrary.simpleMessage("MVA"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Laster opp"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("Brukertittel"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Pakken din utløper i dag\n\nVennligst kjøp igjen"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) Systemet tilbys utelukkende for å\nlegge til rette for salgstransaksjoner og\nrelaterte aktiviteter i din\nvirksomhet."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) For å bruke Systemet kan du bli\nkrevd å opprette en konto. Du\nsamtykker til å gi nøyaktig, oppdatert, og\nfullstendig informasjon under\nregistreringsprosessen og å oppdatere\nslik informasjon for å holde den\nnøyaktig og fullstendig."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("Om appen"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Om oss"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Aksept av vilkår"),
        "accountName": MessageLookupByLibrary.simpleMessage("Kontonavn"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("Kontonummer"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Kontoregistrering"),
        "acton": MessageLookupByLibrary.simpleMessage("Handling"),
        "add": MessageLookupByLibrary.simpleMessage("Legg til"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Legg til merke"),
        "addCategory":
            MessageLookupByLibrary.simpleMessage("Legg til kategori"),
        "addContact": MessageLookupByLibrary.simpleMessage("Legg til kontakt"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Legg til kunde"),
        "addDelivery":
            MessageLookupByLibrary.simpleMessage("Legg til levering"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Legg til beskrivelse"),
        "addDescription":
            MessageLookupByLibrary.simpleMessage("Legg til notat"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Legg til rabatt"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Legg til dokument-ID"),
        "addDucument":
            MessageLookupByLibrary.simpleMessage("Legg til dokument"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Legg til utgift"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Legg til utgiftskategori"),
        "addItems": MessageLookupByLibrary.simpleMessage("Legg til varer"),
        "addNew": MessageLookupByLibrary.simpleMessage("Legg til ny"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Legg til ny adresse"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Legg til produkt"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("Legg til ny skatt"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Legg til ny skatt med enkelt/flere skatteformer"),
        "addNote": MessageLookupByLibrary.simpleMessage("Legg til notat"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Legg til produkt først"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Legg til kampanjekode"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Legg til kjøp"),
        "addSales": MessageLookupByLibrary.simpleMessage("Legg til salg"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Lagt til med suksess"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Legg til enhet"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Legg til brukerrolle"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Lagt til med suksess"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("Lagt til i handlekurv"),
        "address": MessageLookupByLibrary.simpleMessage("Adresse"),
        "admin": MessageLookupByLibrary.simpleMessage("Admin"),
        "all": MessageLookupByLibrary.simpleMessage("Alle"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("Alle forretningsløsninger"),
        "alreadyAdded":
            MessageLookupByLibrary.simpleMessage("Allerede lagt til"),
        "alreadyExists":
            MessageLookupByLibrary.simpleMessage("Eksisterer allerede"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Har allerede en konto"),
        "amount": MessageLookupByLibrary.simpleMessage("Beløp"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "En e-post er sendt. Sjekk innboksen din."),
        "androidIOSAppSupport":
            MessageLookupByLibrary.simpleMessage("Android- og iOS-appstøtte"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Gjeldende skatt"),
        "apply": MessageLookupByLibrary.simpleMessage("Søk"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Er du sikker på at du vil slette denne fakturaen?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Er du sikker på at du vil slette dette salget?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Er du sikker på at du vil slette denne brukeren?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Er du sikker på at du vil slette denne skatten?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Er du sikker på at du vil slette denne skattegruppen?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Vil du slette dette lageret?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Er du sikker på at du vil slette denne brukeren?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Autorisert signatur"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Du er ansvarlig for\nå opprettholde konfidensialiteten til din\nkonto og passord og for å begrense\ntilgang til kontoen din. Du aksepterer\nansvar for alle aktiviteter som\nforegår under kontoen din."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Du må være minst 18 år gammel eller den\njuridiske alderen for myndighet i din\njurisdiksjon for å bruke Systemet."),
        "backSide": MessageLookupByLibrary.simpleMessage("Baksiden"),
        "backToHome": MessageLookupByLibrary.simpleMessage("Tilbake til hjem"),
        "balance": MessageLookupByLibrary.simpleMessage("Saldo"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladesh"),
        "bank": MessageLookupByLibrary.simpleMessage("Bank"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Valuta for bankkonto"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Bankkonto Valuta"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Bankinformasjon"),
        "bankName": MessageLookupByLibrary.simpleMessage("Banknavn"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("Bankoverføring"),
        "barcodeFound": MessageLookupByLibrary.simpleMessage("Strekode funnet"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Regning/Faktura"),
        "billTo": MessageLookupByLibrary.simpleMessage("Fakturer til"),
        "branchName": MessageLookupByLibrary.simpleMessage("Filialnavn"),
        "brand": MessageLookupByLibrary.simpleMessage("Merke"),
        "brandName": MessageLookupByLibrary.simpleMessage("Merkenavn"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("Masseopplasting"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Forretningskategori"),
        "buy": MessageLookupByLibrary.simpleMessage("Kjøp"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Kjøp premium plan"),
        "buySms": MessageLookupByLibrary.simpleMessage("Kjøp sms"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Ved å få tilgang til eller bruke Punktet for Salg (POS) Systemet (\"Systemet\") levert av [Ditt Selskapsnavn] (\"Selskapet\"), godtar du å være bundet av disse Vilkårene for bruk. Hvis du ikke godtar disse Vilkårene for bruk, ikke bruk Systemet."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Du er ansvarlig for å sikre at din\ntilgang til og bruk av Systemet er i\nsamsvar med alle gjeldende lover og\nforskrifter."),
        "cacel": MessageLookupByLibrary.simpleMessage("Avbryt"),
        "call": MessageLookupByLibrary.simpleMessage("Ring"),
        "callForEmergencySupport":
            MessageLookupByLibrary.simpleMessage("Ring for nødhjelp"),
        "camera": MessageLookupByLibrary.simpleMessage("Kamera"),
        "cancel": MessageLookupByLibrary.simpleMessage("Avbryt"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Avbryt alle produkter"),
        "capacity": MessageLookupByLibrary.simpleMessage("Kapasitet"),
        "card": MessageLookupByLibrary.simpleMessage("Kort"),
        "cash": MessageLookupByLibrary.simpleMessage("Kontanter"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Kategorier"),
        "category": MessageLookupByLibrary.simpleMessage("Kategori"),
        "categoryName": MessageLookupByLibrary.simpleMessage("Kategorinavn"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "Kategorinavn eksisterer allerede"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("Kategorinavn"),
        "change": MessageLookupByLibrary.simpleMessage("Endre?"),
        "changePassword": MessageLookupByLibrary.simpleMessage("Endre passord"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("Sjekk e-posten"),
        "choseACustomer": MessageLookupByLibrary.simpleMessage("Velg en kunde"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Velg en leverandør"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Velg dine funksjoner"),
        "clarence": MessageLookupByLibrary.simpleMessage("Klart"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Klikk for å koble til"),
        "close": MessageLookupByLibrary.simpleMessage("Lukk"),
        "color": MessageLookupByLibrary.simpleMessage("Farge"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(Kombinasjon av flere skatter)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Kommer snart"),
        "companyAddress": MessageLookupByLibrary.simpleMessage("Firmaadresse"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Firma- og butiksnavn"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("Firma- og forretningsnavn"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Fullfør transaksjon"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Bekreft passord"),
        "confirmReturn": MessageLookupByLibrary.simpleMessage("Bekreft retur"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Gratulerer"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Kontakt oss"),
        "continu": MessageLookupByLibrary.simpleMessage("Fortsett"),
        "country": MessageLookupByLibrary.simpleMessage("Land"),
        "create": MessageLookupByLibrary.simpleMessage("Opprett"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Opprett en gratis konto"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Opprettet og lagret"),
        "currency": MessageLookupByLibrary.simpleMessage("Valuta"),
        "currentStock": MessageLookupByLibrary.simpleMessage("Nåværende lager"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("Egendefinert fakturamerking"),
        "customer": MessageLookupByLibrary.simpleMessage("Kunde"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Kundedetaljer"),
        "customerGST": MessageLookupByLibrary.simpleMessage("Kunde GST"),
        "customerName": MessageLookupByLibrary.simpleMessage("Kundenavn"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Daglig transaksjon"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Oversikt over Dashbordet"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Data lagret med suksess"),
        "date": MessageLookupByLibrary.simpleMessage("Dato"),
        "day": MessageLookupByLibrary.simpleMessage("Dag"),
        "dealer": MessageLookupByLibrary.simpleMessage("Forhandler"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("Forhandlerpris"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("Standard MVA-prosent"),
        "delete": MessageLookupByLibrary.simpleMessage("Slett"),
        "deleting": MessageLookupByLibrary.simpleMessage("Sletter"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Leveringsadresse"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Leveringsadresser"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Leveringsavgift"),
        "describtion": MessageLookupByLibrary.simpleMessage("Beskrivelse"),
        "description": MessageLookupByLibrary.simpleMessage("Beskrivelse"),
        "descriptionCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Beskrivelse kan ikke være tom"),
        "details": MessageLookupByLibrary.simpleMessage("Detaljer"),
        "discount": MessageLookupByLibrary.simpleMessage("Rabatt"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Ikke forstyrr"),
        "done": MessageLookupByLibrary.simpleMessage("Ferdig"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Last ned Excel-format"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Lastet ned vellykket i nedlastingsmappen"),
        "due": MessageLookupByLibrary.simpleMessage("Forfalt"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Forfalt beløp: "),
        "dueCollection": MessageLookupByLibrary.simpleMessage(
            "Innsamling av forfalte beløp"),
        "dueCollectionReports": MessageLookupByLibrary.simpleMessage(
            "Rapporter om utestående innkreving"),
        "dueList": MessageLookupByLibrary.simpleMessage("Forfalt liste"),
        "dueReports": MessageLookupByLibrary.simpleMessage("Forfallsrapport"),
        "duration": MessageLookupByLibrary.simpleMessage("Varighet"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Varighet: Fra"),
        "easyToUseMobilePos":
            MessageLookupByLibrary.simpleMessage("Enkel å bruke mobil pos"),
        "edit": MessageLookupByLibrary.simpleMessage("Rediger"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Rediger kjøpsfaktura"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Rediger salgsfaktura"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Rediger sosiale medier"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Redigert med suksess"),
        "editTax": MessageLookupByLibrary.simpleMessage("Rediger skatt"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Rediger skattegruppe"),
        "editWarehouse": MessageLookupByLibrary.simpleMessage("Rediger lager"),
        "email": MessageLookupByLibrary.simpleMessage("E-post"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("E-postadresse"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("E-post kan ikke være tom"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "E-post sendt! Sjekk innboksen din"),
        "endDate": MessageLookupByLibrary.simpleMessage("Sluttdato"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Skriv inn et gyldig beløp"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Skriv inn en gyldig rabatt"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Skriv inn et gyldig telefonnummer"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Skriv inn en gyldig pris"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("Skriv inn en gyldig mengde"),
        "enterAddress":
            MessageLookupByLibrary.simpleMessage("Skriv inn adresse"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("Skriv inn beløp."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Skriv inn merkenavn"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Skriv inn kapasitet"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Skriv inn kategorinavn"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Skriv inn farge"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "Skriv inn kundens GST-nummer"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Skriv inn forhandlerpris"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Skriv inn beskrivelse"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("Skriv inn rabatt."),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Skriv inn utgiftsdato"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Skriv inn full adresse"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Skriv inn fakturanummer"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Skriv inn varsel om lav lagerbeholdning mengde"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Skriv inn produsent"),
        "enterMessageContent": MessageLookupByLibrary.simpleMessage(
            "Skriv inn meldingens innhold"),
        "enterMrpOrRetailerPirce":
            MessageLookupByLibrary.simpleMessage("Skriv inn MRP/Detaljistpris"),
        "enterName": MessageLookupByLibrary.simpleMessage("Skriv inn navn"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Skriv inn notat"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Skriv inn partinavn"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Skriv inn telefonnummer"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Skriv inn produktkode eller skann"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Skriv inn produktnavn"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Skriv inn kjøpspris."),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("Skriv inn referansenummer"),
        "enterSize":
            MessageLookupByLibrary.simpleMessage("Skriv inn størrelse"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("Skriv inn lager."),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Skriv inn skattesatsen"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("Skriv inn transaksjons-ID"),
        "enterType": MessageLookupByLibrary.simpleMessage("Skriv inn type"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("Skriv inn brukertittel"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Skriv inn gyldig beløp"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Skriv inn lagernavn"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Skriv inn vekt"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Skriv inn engrospris"),
        "enterYourDescriptionHere": MessageLookupByLibrary.simpleMessage(
            "Skriv inn beskrivelsen din her"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "Skriv inn e-postadressen din"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "Skriv inn din tilbakemeldingstittel"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Skriv inn ditt GST-nummer"),
        "enterYourMobileNumber": MessageLookupByLibrary.simpleMessage(
            "Skriv inn mobilnummeret ditt"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Skriv inn navnet ditt"),
        "enterYourNumber": MessageLookupByLibrary.simpleMessage(
            "Skriv inn telefonnummeret ditt"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Skriv inn passordet ditt"),
        "enterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Skriv inn telefonnummeret ditt"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "Skriv inn din transaksjons-ID"),
        "error": MessageLookupByLibrary.simpleMessage("Feil"),
        "excTax": MessageLookupByLibrary.simpleMessage("Ekskl. skatt"),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("Excel-opplaster"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Eksklusiv"),
        "expense": MessageLookupByLibrary.simpleMessage("Utgift"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Utgiftskategori"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Utgiftsdato"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Utgift for"),
        "expenseReport": MessageLookupByLibrary.simpleMessage("Utgiftsrapport"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Utløpsdato"),
        "expired": MessageLookupByLibrary.simpleMessage("Utløpt"),
        "expiring": MessageLookupByLibrary.simpleMessage("Utløper"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Feilet med feil"),
        "fashion": MessageLookupByLibrary.simpleMessage("Mote"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Funksjoner er den viktige delen som gjør Pos Saas forskjellig fra tradisjonelle løsninger."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Tilbakemelding"),
        "firstName": MessageLookupByLibrary.simpleMessage("Fornavn"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Følg oss på\\nFacebook"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Følg oss på\\nTwitter"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Forside"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("For ubegrenset bruk"),
        "forgotPassword": MessageLookupByLibrary.simpleMessage("Glemt passord"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Glemt passord?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Fra dato"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("Gratis databeskyttelse"),
        "freeLifeTimeUpdate":
            MessageLookupByLibrary.simpleMessage("Gratis livstidsoppdatering"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Gratis pakke"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Gratis plan"),
        "from": MessageLookupByLibrary.simpleMessage("(Fra"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Fullt betalt"),
        "gallary": MessageLookupByLibrary.simpleMessage("Galleri"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("Genererer PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Få OTP"),
        "govermentId": MessageLookupByLibrary.simpleMessage("Regjering ID"),
        "guest": MessageLookupByLibrary.simpleMessage("Gjest"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Har ikke en konto?"),
        "history": MessageLookupByLibrary.simpleMessage("Historikk"),
        "home": MessageLookupByLibrary.simpleMessage("Hjem"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Hvordan vi beskytter din informasjon"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Hvordan vi bruker din informasjon"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Identitetsbekreftelse"),
        "image": MessageLookupByLibrary.simpleMessage("Bilde"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("Internt kan ikke slettes"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("Internt kan ikke redigeres"),
        "inWord": MessageLookupByLibrary.simpleMessage("I ord"),
        "incTax": MessageLookupByLibrary.simpleMessage("Inkl. skatt"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Inkludert"),
        "increaseStock":
            MessageLookupByLibrary.simpleMessage("Øk lagerbeholdning"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Instrument"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Faktura nr."),
        "invoice": MessageLookupByLibrary.simpleMessage("Faktura"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("Fakturanummer"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Fakturainnstillinger"),
        "invoiceViewer": MessageLookupByLibrary.simpleMessage("Faktura leser"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Vare lagt til"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("KYC-verifisering"),
        "language": MessageLookupByLibrary.simpleMessage("Språk"),
        "lastName": MessageLookupByLibrary.simpleMessage("Etternavn"),
        "ledger": MessageLookupByLibrary.simpleMessage("Hovedbok"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Livstidskjøp"),
        "link": MessageLookupByLibrary.simpleMessage("Lenke"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Direktemeldingssupport"),
        "loading": MessageLookupByLibrary.simpleMessage("Laster"),
        "logIn": MessageLookupByLibrary.simpleMessage("Logg inn"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Logg ut"),
        "logOut": MessageLookupByLibrary.simpleMessage("Logg ut"),
        "login": MessageLookupByLibrary.simpleMessage("Logg inn"),
        "logo": MessageLookupByLibrary.simpleMessage("Logo"),
        "loss": MessageLookupByLibrary.simpleMessage("Tap"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Tap/Vinning"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Tap/Vinning Detaljer"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Tap/Vinn Rapport"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Tap/Vinn Rapporter"),
        "lowStockAlert": MessageLookupByLibrary.simpleMessage(
            "Varsel om lav lagerbeholdning"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Gjør et varig inntrykk på kundene dine med merket fakturaer. Vår Ubegrenset Oppgradering tilbyr den unike fordelen av å tilpasse fakturaene dine, noe som gir et profesjonelt preg som forsterker merkeidentiteten din og fremmer kundelojalitet."),
        "manageYourBussinessWith": MessageLookupByLibrary.simpleMessage(
            "Administrer virksomheten din med "),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Produksjonsdato"),
        "margin": MessageLookupByLibrary.simpleMessage("Margin"),
        "masterCard": MessageLookupByLibrary.simpleMessage("MasterCard"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Produsent"),
        "message": MessageLookupByLibrary.simpleMessage("Melding"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Meldingshistorikk"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Pos Saas appen er gratis, enkel å bruke. Faktisk er det et av de beste POS-systemene i verden."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas er en komplett forretningsløsning med lager, regnskap, salg, utgifter og tap/profit."),
        "mobile": MessageLookupByLibrary.simpleMessage("Mobil"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("Mobilbetaling"),
        "monthly": MessageLookupByLibrary.simpleMessage("Månedlig"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("Mer info"),
        "name": MessageLookupByLibrary.simpleMessage("Skriv inn navnet ditt."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Navn eksisterer allerede"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("Navn kan ikke være tomt"),
        "next": MessageLookupByLibrary.simpleMessage("Neste"),
        "noConnection":
            MessageLookupByLibrary.simpleMessage("Ingen tilkobling"),
        "noData": MessageLookupByLibrary.simpleMessage("Ingen data"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Ingen data tilgjengelig"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Ingen data funnet"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("Ingen historikk funnet!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Ingen produkter funnet"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("Ingen underkatt valgt"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("Ingen transaksjoner funnet!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Ingen bruker funnet for den e-posten."),
        "noUserRoleFound":
            MessageLookupByLibrary.simpleMessage("Ingen brukerrolle funnet"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Ikke aktiv bruker"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Ikke oppgitt"),
        "note": MessageLookupByLibrary.simpleMessage("Notat"),
        "notes": MessageLookupByLibrary.simpleMessage("Notater"),
        "notification": MessageLookupByLibrary.simpleMessage("Varsel"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP sendt til"),
        "office": MessageLookupByLibrary.simpleMessage("Kontor"),
        "ok": MessageLookupByLibrary.simpleMessage("Ok"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS som inneholder en stor mengde funksjonalitet, inkludert salgssporing, lagerstyring."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Dette systemet hjelper deg med å forbedre driften for kundene dine."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Vårt POS-system skal forenkle daglige operasjoner automatisk, og gjøre det enkelt å navigere."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("Åpningsbalanse"),
        "order": MessageLookupByLibrary.simpleMessage("Bestillinger"),
        "other": MessageLookupByLibrary.simpleMessage("Annet"),
        "otp": MessageLookupByLibrary.simpleMessage("Lukk"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Utsolgt"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Pakke"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Pakkeegenskaper"),
        "paid": MessageLookupByLibrary.simpleMessage("Betalt"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Betalt beløp"),
        "parties": MessageLookupByLibrary.simpleMessage("Parter"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Partiers liste"),
        "partyGST": MessageLookupByLibrary.simpleMessage("Parti GST"),
        "partyName": MessageLookupByLibrary.simpleMessage("Partinavn"),
        "password": MessageLookupByLibrary.simpleMessage("Passord"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Passord og bekreftelsespasord samsvarer ikke"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Passord kan ikke være tomt"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("Passordet stemmer ikke"),
        "payCash": MessageLookupByLibrary.simpleMessage("Betal med kontanter"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash": MessageLookupByLibrary.simpleMessage("Betal med bKash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Betal med Paypal"),
        "payeeName": MessageLookupByLibrary.simpleMessage("Mottakers navn"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("Mottakers nummer"),
        "payment": MessageLookupByLibrary.simpleMessage("Betaling"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("Betalingsbeløp"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Betaling fullført"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Betalingsinstruksjoner:"),
        "paymentMethod":
            MessageLookupByLibrary.simpleMessage("Betalingsmetode"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Betalingsmetode"),
        "pdfView": MessageLookupByLibrary.simpleMessage("PDF-visning"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Personlig informasjon"),
        "phone": MessageLookupByLibrary.simpleMessage("Telefon"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Telefonnummer"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Telefonnummeret er allerede brukt"),
        "phoneNumberIsNotValid": MessageLookupByLibrary.simpleMessage(
            "Telefonnummeret er ikke gyldig"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("Telefonnummer er påkrevd"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("Velg og last opp fil"),
        "pickEndDate": MessageLookupByLibrary.simpleMessage("Velg sluttdato"),
        "pickStartDate": MessageLookupByLibrary.simpleMessage("Velg startdato"),
        "plan": MessageLookupByLibrary.simpleMessage("Plan"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("Vennligst legg til mengde"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Vennligst sjekk internettforbindelsen din"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Vennligst koble til skriveren først"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Vennligst koble til din Bluetooth-skriver"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Vennligst skriv inn et større passord"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Vennligst skriv inn et bekreftelsespassord"),
        "pleaseEnterAPassword": MessageLookupByLibrary.simpleMessage(
            "Vennligst skriv inn et passord"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Vennligst skriv inn en gyldig e-post"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Vennligst skriv inn navn"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("Vennligst skriv inn passord"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Vennligst skriv inn e-postadressen din nedenfor for å motta tilbakestillingslink."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Vennligst skriv inn transaksjonsnummer"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("Vennligst skriv inn beløp"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Vennligst velg en kategori først"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("Vennligst velg en plan"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Vennligst velg forretningskategori"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Vennligst bruk gyldig kjøpskode for å bruke appen"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Drevet av Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Drevet av"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Premium kundestøtte"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Premium plan"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Tidligere betalingsbeløp"),
        "price": MessageLookupByLibrary.simpleMessage("Pris"),
        "print": MessageLookupByLibrary.simpleMessage("Skriv ut"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Utskriftsalternativ"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Personvernerklæring"),
        "product": MessageLookupByLibrary.simpleMessage("Produkt"),
        "productCode": MessageLookupByLibrary.simpleMessage("Produktkode"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("Produktkode er påkrevd"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Produktkode/Navn"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Produktbeskrivelse"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Produktdetaljer"),
        "productList": MessageLookupByLibrary.simpleMessage("Produktliste"),
        "productName": MessageLookupByLibrary.simpleMessage("Produktnavn"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Produktnavnet finnes allerede i dette lageret"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Produktnavn er allerede lagt til"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("Produktnavn er påkrevd"),
        "products": MessageLookupByLibrary.simpleMessage("Produkter"),
        "profile": MessageLookupByLibrary.simpleMessage("Profil"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("Profilredigering"),
        "profit": MessageLookupByLibrary.simpleMessage("Vinning"),
        "promo": MessageLookupByLibrary.simpleMessage("Kampanje"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Kampanjekode"),
        "purchase": MessageLookupByLibrary.simpleMessage("Kjøp"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage("Kjøpsalarm"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Kjøp bekreftet"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Kjøpsdetaljer"),
        "purchaseInvoice": MessageLookupByLibrary.simpleMessage("Kjøpsfaktura"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("Kjøpsliste"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Kjøp nå"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Kjøp premium plan"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("Kjøpspris"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("Innkjøpspris er påkrevd"),
        "purchaseRepoet": MessageLookupByLibrary.simpleMessage("Kjøpsrapport"),
        "purchaseReports": MessageLookupByLibrary.simpleMessage("Kjøpsrapport"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Kjøpsrapporter"),
        "purchaseReturn": MessageLookupByLibrary.simpleMessage("Kjøpsretur"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("Kjøpsreturrapport"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Kjøpstransaksjon"),
        "qty": MessageLookupByLibrary.simpleMessage("Ant."),
        "quantity": MessageLookupByLibrary.simpleMessage("Antall"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Nylige transaksjoner"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("Mottatt PIN-koden"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Referansenummer"),
        "register": MessageLookupByLibrary.simpleMessage("Registrer"),
        "registering": MessageLookupByLibrary.simpleMessage("Registrerer"),
        "remainingDue":
            MessageLookupByLibrary.simpleMessage("Gjenværende forfalt"),
        "remove": MessageLookupByLibrary.simpleMessage("Fjern"),
        "reports": MessageLookupByLibrary.simpleMessage("Rapporter"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Forespørsel har blitt sendt"),
        "resendCode": MessageLookupByLibrary.simpleMessage("Send kode på nytt"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("Send OTP på nytt: "),
        "retailer": MessageLookupByLibrary.simpleMessage("Forhandler"),
        "retur": MessageLookupByLibrary.simpleMessage("Retur"),
        "returN": MessageLookupByLibrary.simpleMessage("Retur"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("Returbeløp"),
        "returnAmount":
            MessageLookupByLibrary.simpleMessage("Tilbakebetalingsbeløp"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("Returmengde"),
        "revenue": MessageLookupByLibrary.simpleMessage("Inntekt"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Beskytt bedriftsdataene dine uten problemer. Vår Pos Saas POS Ubegrenset Oppgradering inkluderer gratis databeskyttelse, som sikrer at din verdifulle informasjon er beskyttet mot uforutsette hendelser. Fokuser på det som virkelig betyr noe - veksten av virksomheten din."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Salgsbeløp"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("Salgsdetaljer"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Salgspris"),
        "saleReports": MessageLookupByLibrary.simpleMessage("Salgsrapport"),
        "saleReportss": MessageLookupByLibrary.simpleMessage("Salgsrapporter"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("Salgsretur"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Salgsreturrapport"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("Salgsinnstilling"),
        "sales": MessageLookupByLibrary.simpleMessage("Salg"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("Salgs- og kjøpsrapporter"),
        "salesList": MessageLookupByLibrary.simpleMessage("Salgslisten"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("Salgsretur"),
        "save": MessageLookupByLibrary.simpleMessage("Lagre"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Lagre og publiser"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("Lagre endringer"),
        "saving": MessageLookupByLibrary.simpleMessage("Lagrer"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("Skann produktets QR-kode"),
        "search": MessageLookupByLibrary.simpleMessage("Søk"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Søk etter produktkode eller navn"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("Se alle kampanjekoder"),
        "select": MessageLookupByLibrary.simpleMessage("Velg"),
        "selectAProductForReturn":
            MessageLookupByLibrary.simpleMessage("Velg et produkt for retur"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Velg merke"),
        "selectCategory": MessageLookupByLibrary.simpleMessage("Velg kategori"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Velg kontakter"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("Velg produktkategori"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("Velg butikkategori"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Velg skatt"),
        "selectTaxType": MessageLookupByLibrary.simpleMessage("Velg skatttype"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("Velg enhet"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Velg variasjon:"),
        "seller": MessageLookupByLibrary.simpleMessage("Selger"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Selges av"),
        "send": MessageLookupByLibrary.simpleMessage("Send"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("Send e-post"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Send melding"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("Send tilbakestillingslink"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Send SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Send sms?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Send WhatsApp-melding"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Send din e-post"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage("Sender e-post"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Sender melding"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Service/Frakt"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Sett opp profilen din"),
        "setting": MessageLookupByLibrary.simpleMessage("Innstillinger"),
        "share": MessageLookupByLibrary.simpleMessage("Del"),
        "shopGST": MessageLookupByLibrary.simpleMessage("Butikk GST"),
        "signIn": MessageLookupByLibrary.simpleMessage("Logg inn"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("Logg inn med e-post"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Kundens signatur"),
        "size": MessageLookupByLibrary.simpleMessage("Størrelse"),
        "skip": MessageLookupByLibrary.simpleMessage("Hopp over"),
        "sms": MessageLookupByLibrary.simpleMessage("Sms"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Sosial Markedsføring"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Beklager, du har ikke tillatelse til å få tilgang til denne tjenesten"),
        "startDate": MessageLookupByLibrary.simpleMessage("Startdato"),
        "startNewSale": MessageLookupByLibrary.simpleMessage("Start nytt salg"),
        "startTypingToSearch":
            MessageLookupByLibrary.simpleMessage("Begynn å skrive for å søke"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Hold deg i forkant av teknologiske fremskritt uten ekstra kostnader. Vår Pos Saas POS Ubegrenset Oppgradering sikrer at du alltid har de nyeste verktøyene og funksjonene tilgjengelig, som garanterer at virksomheten din forblir moderne."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("Fortsatt ubetalt"),
        "stock": MessageLookupByLibrary.simpleMessage("Lager"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Lager er påkrevd"),
        "stockList": MessageLookupByLibrary.simpleMessage("Lagerliste"),
        "stocks": MessageLookupByLibrary.simpleMessage("Lager"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Lagringsrettigheter kreves for å opprette Excel-fil"),
        "subTaxList":
            MessageLookupByLibrary.simpleMessage("Liste over underkatter"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Underkatter"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Delsum"),
        "submit": MessageLookupByLibrary.simpleMessage("Send inn"),
        "subscribeToOurYoutube":
            MessageLookupByLibrary.simpleMessage("Abonner på vår\\nYouTube"),
        "subscription": MessageLookupByLibrary.simpleMessage("Abonnement"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Vellykket gjort"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Logget ut med suksess"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Oppdatert med suksess"),
        "supplier": MessageLookupByLibrary.simpleMessage("Leverandør"),
        "supplierName": MessageLookupByLibrary.simpleMessage("Leverandørnavn"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT-kode"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Ta bilde av førerkort, nasjonal identitetskort eller pass"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "Ta et identitetskort for å sjekke informasjonen din"),
        "tap": MessageLookupByLibrary.simpleMessage("Trykk"),
        "tax": MessageLookupByLibrary.simpleMessage("Skatt"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Skattegruppe"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("Skatteprosent"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Skattesats"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Skattesatser - Administrer dine skattesatser"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Skatterapport"),
        "taxType": MessageLookupByLibrary.simpleMessage("Skatttype"),
        "taxes": MessageLookupByLibrary.simpleMessage("Skatter"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Vilkår og betingelser"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("Brukervilkår"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Vilkår & Personvern"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Takk for din forfalte betaling"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Takk"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Takk for ditt kjøp"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "Kontoen eksisterer allerede for den e-posten"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Excel-filen er allerede lastet ned"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Navnet sier alt. Med Pos Saas POS Ubegrenset er det ingen begrensninger på bruken din. Enten du behandler en håndfull transaksjoner eller opplever en rush av kunder, kan du operere med tillit, vel vitende om at du ikke er begrenset av grenser."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "Passordet som er oppgitt er for svakt"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Salget vil bli slettet, og all data om dette kjøpet vil bli slettet. Er du sikker på at du vil slette dette?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Salget vil bli slettet, og all data om dette salget vil bli slettet. Er du sikker på at du vil slette dette?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Brukeren vil bli slettet og all data vil bli slettet fra kontoen din. Er du sikker på at du vil slette dette?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Brukeren vil bli slettet og all data vil bli slettet fra kontoen din. Er du sikker på at du vil slette dette?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Tjenester fra tredjepart"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Denne kategorien kan ikke slettes"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Denne måneden)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Dette produktet er allerede lagt til"),
        "title": MessageLookupByLibrary.simpleMessage("Tittel"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Tittel kan ikke være tom"),
        "to": MessageLookupByLibrary.simpleMessage("til"),
        "toDate": MessageLookupByLibrary.simpleMessage("Til dato"),
        "today": MessageLookupByLibrary.simpleMessage("I dag"),
        "total": MessageLookupByLibrary.simpleMessage("Total"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Totalsum"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Totalt innsamlet"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Totalt forfalt"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("Totale utgifter"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Totalt tap"),
        "totalPayable": MessageLookupByLibrary.simpleMessage("Totalt å betale"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Totalpris"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("Totalt antall produkter"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Totalt overskudd"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("Total kjøp"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Total returbeløp"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("Totale returer"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Totalsalg"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Totalt lager"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Totalverdi"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Total MVA"),
        "totals": MessageLookupByLibrary.simpleMessage("Total: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Transaksjon"),
        "transactionId":
            MessageLookupByLibrary.simpleMessage("Transaksjons-ID"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Prøv igjen"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Type"),
        "unitName": MessageLookupByLibrary.simpleMessage("Enhetsnavn"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Enhetspris"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Enhetspris"),
        "units": MessageLookupByLibrary.simpleMessage("Enheter"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Ubegrenset"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Ubegrenset bruk"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Lås opp det fulle potensialet til Pos Saas POS med personlige opplæringsøkter ledet av vårt ekspertteam. Fra det grunnleggende til avanserte teknikker, sikrer vi at du er godt kjent med å bruke alle aspekter av systemet for å optimalisere forretningsprosessene dine."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Ubetalt"),
        "update": MessageLookupByLibrary.simpleMessage("Oppdater"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Oppdater kontakt"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Oppdater nå"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("Oppdater produkt"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Oppdater planen din først, grensen din er overskredet"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Oppdater profilen din"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Oppdater profilen din for å knytte legen din til et bedre inntrykk"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Oppdater profilen din for å knytte kundene dine med bedre inntrykk"),
        "updated": MessageLookupByLibrary.simpleMessage("Oppdatert"),
        "upload": MessageLookupByLibrary.simpleMessage("Last opp"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Last opp dokument"),
        "uploadDone":
            MessageLookupByLibrary.simpleMessage("Opplasting fullført"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Last opp fil"),
        "upplier": MessageLookupByLibrary.simpleMessage("Leverandør"),
        "usbC": MessageLookupByLibrary.simpleMessage("USB C"),
        "use": MessageLookupByLibrary.simpleMessage("Bruk"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("Bruk Pos Saas"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Bruk av systemet"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Bruker er slettet"),
        "userRole": MessageLookupByLibrary.simpleMessage("Brukerrolle"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("Brukerrolle detaljer"),
        "userTitle": MessageLookupByLibrary.simpleMessage("Brukertittel"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Brukertittel kan ikke være tom"),
        "value": MessageLookupByLibrary.simpleMessage("Verdi"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("MVA gjelder ikke"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("Verifiserer OTP"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Bekreft telefonnummer"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Se alle"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("Vis detaljer"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Dør-til-dør-kunde"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Lager"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Lageret eksisterer allerede"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("Lagerliste"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("Lagnavn"),
        "warranty": MessageLookupByLibrary.simpleMessage("Garanti"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Vi har sendt en e-post med instruksjoner om hvordan du tilbakestiller passordet til:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Vi kan bruke tredjepartstjenester for å støtte funksjonaliteten til appen vår, som analysetjenester og betalingsprosessorer. Disse tredjepartstjenestene kan samle informasjon om deg når du bruker appen vår. Vennligst merk at vi ikke er ansvarlige for personvernpraksisene til disse tredjepartstjenestene."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Vi tar bransjestandard tiltak for å beskytte din personlige informasjon, inkludert kryptering og sikker lagring. Vi begrenser også tilgangen til din informasjon til autorisert personell."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Vi forstår viktigheten av sømløse operasjoner. Derfor er vår døgnåpne støtte tilgjengelig for å hjelpe deg, enten det er et raskt spørsmål eller en omfattende bekymring. Koble deg til oss når som helst, hvor som helst via telefon eller WhatsApp for å oppleve uovertruffen kundeservice."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Vi bruker din personlige informasjon for å gi deg den best mulige opplevelsen på appen vår, inkludert å personalisere innholdsanbefalingene dine, koble deg med eksperter, og forbedre funksjonaliteten til appene våre. Vi kan også bruke informasjonen din til å kommunisere med deg om oppdateringer, kampanjer eller annen informasjon relatert til appen vår."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Vi vil gjennomgå betalingen og godkjenne den innen 1-2 timer"),
        "weekly": MessageLookupByLibrary.simpleMessage("Ukentlig"),
        "weight": MessageLookupByLibrary.simpleMessage("Vekt"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Hva er nytt"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Engroskjøper"),
        "wholeSalePrice": MessageLookupByLibrary.simpleMessage("Engrospris"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("Engrospris"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Engrosforhandler"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Vil bli lagt til snart"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Vil utløpe den"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Skriv meldingen din her"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("Feil OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Feil passord oppgitt for den brukeren."),
        "yearly": MessageLookupByLibrary.simpleMessage("Årlig"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Ja, slett for alltid"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("Du er ikke en gyldig bruker"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Du bruker"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Du kan ikke betale mer enn det som skyldes"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Du har mottatt en e-post"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Du har logget inn på kontoen din. Hold deg med Pos Saas."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("Du må gi tillatelse"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Du må logge inn på nytt på kontoen din."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Du må bekrefte identiteten før du kjøper sms"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Dine meldinger gjenstår"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Din pakke"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Pakken din vil utløpe om 5 dager")
      };
}
