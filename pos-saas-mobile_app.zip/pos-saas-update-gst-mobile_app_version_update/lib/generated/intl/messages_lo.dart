// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a lo locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'lo';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("ດໍາເນີນຕໍ່"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("ເລກທະບຽນ GST"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired": MessageLookupByLibrary.simpleMessage("MRP ແມ່ນຈິງ"),
        "OK": MessageLookupByLibrary.simpleMessage("ຕົກລົງ"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("ເບິ່ງເພີ່ນ"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("ລະດັບ"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("ລະຫັດ SWIFT"),
        "Snacks": MessageLookupByLibrary.simpleMessage("ສິນຄ້າກິນເພີ່ມ"),
        "TAX": MessageLookupByLibrary.simpleMessage("ສ່ອງພິມ"),
        "Uploading": MessageLookupByLibrary.simpleMessage("ກະຕອນອັບໂຫລດ"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("ຫົວຂໍ້ຜູ້ໃຊ້"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "ເອກະສານຂອງທ່ານຈະໝົດອາຍຸຕອນນີ້\n\nກະລຸນາຊື້ອີກຄອມໂບນອນ"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) The System is provided solely for the\npurpose of facilitating point of sale\ntransactions andrelatedactivities in your\nbusiness."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) To use the System, you may be\nrequired to create an account. You\nagree to provide accurate, current, and\ncomplete information during\nthe registration process and toupdate\nsuchinformationto keep itaccurate\nand complete."),
        "aboutApp":
            MessageLookupByLibrary.simpleMessage("ແພງການໃຊ້ງານກ່ຽວກັບແອັບ"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("ກ່ຽວກັບເຮົາ"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Acceptance of Terms"),
        "accountName": MessageLookupByLibrary.simpleMessage("ຊື້ຊື້"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("ເລກບັນຊື້"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Account Registration"),
        "acton": MessageLookupByLibrary.simpleMessage("ກະບວນການ"),
        "add": MessageLookupByLibrary.simpleMessage("ເພີ່ມ"),
        "addBrand": MessageLookupByLibrary.simpleMessage("ເພີ່ມຍີ່ຫໍ້"),
        "addCategory": MessageLookupByLibrary.simpleMessage("ເພີ່ມປະເພດ"),
        "addContact": MessageLookupByLibrary.simpleMessage("ເພີ່ມຕິດຕໍ່"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("ເພີ່ມລູກຄ້າ"),
        "addDelivery":
            MessageLookupByLibrary.simpleMessage("ເພີ່ມການສົ່ງສິນຄ້າ"),
        "addDescriptioN": MessageLookupByLibrary.simpleMessage("ເພີ່ມລາຍລະອຽດ"),
        "addDescription": MessageLookupByLibrary.simpleMessage("ເພີ່ມຫມາຍເຫດ"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("ເພີ່ມສ່ວນຫຼຸດ"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("ເພີ່ມບັດປະຈຳຕົວຕະລາງ"),
        "addDucument": MessageLookupByLibrary.simpleMessage("ເພີ່ມເອກະສານ"),
        "addExpense": MessageLookupByLibrary.simpleMessage("ເພີ່ມຄ່າໃຊ້ເງິນ"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("ເພີ່ມປະເພດຄ່າໃຊ້ເງິນ"),
        "addItems": MessageLookupByLibrary.simpleMessage("ເພີ່ມລາຍການ"),
        "addNew": MessageLookupByLibrary.simpleMessage("ເພີ່ມໃໝ່"),
        "addNewAddress": MessageLookupByLibrary.simpleMessage("ເພີ່ມທີ່ຢູ່ໃໝ່"),
        "addNewProduct": MessageLookupByLibrary.simpleMessage("ເພີ່ມສິນຄ້າໃໝ່"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("ເພີ່ມພາສີໃໝ່"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "ເພີ່ມພາສີໃໝ່ດ້ວຍແບບໃດບໍ່ແບບລວມ"),
        "addNote": MessageLookupByLibrary.simpleMessage("ເພີ່ມໝາຍເຫດ"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("ເພີ່ມສິນຄ້າກ່ອນ"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("ເພີ່ມລະຫັດສໍາລັບຂາຍ"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("ເພີ່ມການຊື້"),
        "addSales": MessageLookupByLibrary.simpleMessage("ເພີ່ມການຂາຍ"),
        "addSuccessful": MessageLookupByLibrary.simpleMessage("ເພີ່ມຮຽບຮ້ອຍ"),
        "addUnit": MessageLookupByLibrary.simpleMessage("ເພີ່ມຫົວໜ່ວຍ"),
        "addUserRole": MessageLookupByLibrary.simpleMessage("ເພີ່ມບັດຜູ້ໃຊ້"),
        "addedSuccessfully": MessageLookupByLibrary.simpleMessage("ເພີ່ມແລ້ວ"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("ເພີ່ມເຂົ້າໃນກະຕ່າ"),
        "address": MessageLookupByLibrary.simpleMessage("ທີ່ຢູ່"),
        "admin": MessageLookupByLibrary.simpleMessage("ບັດຄະແນນ"),
        "all": MessageLookupByLibrary.simpleMessage("ທັງຫມົດ"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("ການປະສານທັງຫມົດຂອງທ່ານ"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("ເພີ່ມແລ້ວ"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("ມີແລ້ວ"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("ມີບັນຊີແລ້ວ?"),
        "amount": MessageLookupByLibrary.simpleMessage("ຈຳນວນເງິນ"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "ອີເມວໄດ້ຖືກສົ່ມແລ້ວ ກວດເບິ່ງອີນບອກຂອງທ່ານ"),
        "androidIOSAppSupport":
            MessageLookupByLibrary.simpleMessage("ສະຫນັບເຂົ້າ Android & iOS"),
        "applicableTax": MessageLookupByLibrary.simpleMessage("ພາສີທີ່ປະລິມານ"),
        "apply": MessageLookupByLibrary.simpleMessage("ນຳໃຊ້"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "ທ່ານແນ່ໃຈທີ່ຈະລົບໃບບິນນີ້ບໍ?"),
        "areYouSureToDeleteThisSale":
            MessageLookupByLibrary.simpleMessage("ເຈົ້າແນ່ໃຈບໍ່ວ່າຈະລົບຂາຍນີ້"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "ເຈົ້າແນ່ໃຈບໍ່ທີ່ຈະລຶບຜູ້ໃຊ້ນີ້"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "ທ່ານແນ່ໃຈບໍ່ວ່າຈະລົບພາສີນີ້?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "ທ່ານແນ່ໃຈບໍ່ວ່າຈະລົບກຸ່ມພາສີນີ້?"),
        "areYouWantToDeleteThisWarehouse":
            MessageLookupByLibrary.simpleMessage("ທ່ານຕ້ອງການລົບສິນຄ້ານີ້ບໍ່?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "ທ່ານແນ່ໃຈບໍ່ທີ່ຈະລົບຜູ້ໃຊ້ງານນີ້?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("ລົງຊື່ອະນຸຍາດ"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) You are responsible for\nmaintainingthe confidentiality of your\naccount and password andfor restricting\naccess to your account. You accept\nresponsibility for all activities that\noccur under your account."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) You must be at least 18 years old or the\nlegal age of majority in your jurisdiction to\nuse the System."),
        "backSide":
            MessageLookupByLibrary.simpleMessage("ພະນັກງານຂອງບັດປະຈຳຕົວຕະລາງ"),
        "backToHome": MessageLookupByLibrary.simpleMessage("ກັບໜ້າຫຼັກ"),
        "balance": MessageLookupByLibrary.simpleMessage("ຍອດເງິນ"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("ປະເທດບັງກາຣຽນ"),
        "bank": MessageLookupByLibrary.simpleMessage("ບັນຊີ"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("ເງິນສຽງບັນຊີ"),
        "bankInformation": MessageLookupByLibrary.simpleMessage("ຂໍ້ມູນທາງຊື້"),
        "bankName": MessageLookupByLibrary.simpleMessage("ຊື້ທາງຊື້"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("ແຊກເງິນທະນາຄານ"),
        "barcodeFound": MessageLookupByLibrary.simpleMessage("ສິນຄ້າທີ່ພົບ"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("ບິນ/ໃບບັດ"),
        "billTo": MessageLookupByLibrary.simpleMessage("ຮູບແບບຮອງເອງ"),
        "branchName": MessageLookupByLibrary.simpleMessage("ຊື້ພັກ"),
        "brand": MessageLookupByLibrary.simpleMessage("ຍີ່ຫໍ້"),
        "brandName": MessageLookupByLibrary.simpleMessage("ຊື່ຍີ່ຫໍ້"),
        "bulkUpload":
            MessageLookupByLibrary.simpleMessage("ອັບໂຫລດເປົ່ນແບບດຽວ"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("ປະເພດທາງີການທີ່ຕັ້ງຂຶ້ນ"),
        "buy": MessageLookupByLibrary.simpleMessage("ຊື້"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("ຊື້ເອກະສານນິຍົມ"),
        "buySms": MessageLookupByLibrary.simpleMessage("ຊື້ SMS"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "By accessing or using the Point of Sale (POS) System (the \"System\") provided by [Your Company Name] (\"Company\"), you agree to be bound by these Terms of Use. If you do not agree to these Terms of Use, do not use the System."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) You are responsible for ensuring that your\naccess to and use of the System is in\ncompliance with all applicable laws and\nregulations."),
        "cacel": MessageLookupByLibrary.simpleMessage("ຍົກເລີກ"),
        "call": MessageLookupByLibrary.simpleMessage("ໂທລະສັບ"),
        "callForEmergencySupport":
            MessageLookupByLibrary.simpleMessage("ໂທເພື່ອສະໜອງໃນສະຖານກັນ"),
        "camera": MessageLookupByLibrary.simpleMessage("ເຄື່ອງມື"),
        "cancel": MessageLookupByLibrary.simpleMessage("ຍົກເລີກ"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("ຍົກເລີກສິນຄ້າທັງໝົດ"),
        "capacity": MessageLookupByLibrary.simpleMessage("ລວມຄ້າ"),
        "card": MessageLookupByLibrary.simpleMessage("ໃບບັດ"),
        "cash": MessageLookupByLibrary.simpleMessage("ເງິນສົດ"),
        "cashFree": MessageLookupByLibrary.simpleMessage("ບໍ່ເຂົ້າເງິນ"),
        "categories": MessageLookupByLibrary.simpleMessage("ປະເພດ"),
        "category": MessageLookupByLibrary.simpleMessage("ປະເພດ"),
        "categoryName": MessageLookupByLibrary.simpleMessage("ຊື່ປະເພດ"),
        "categoryNameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("ຊື່ປະເພດນີ້ມີແລ້ວ"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("ຊື່ປະເພດ"),
        "change": MessageLookupByLibrary.simpleMessage("ປ່ຽນ?"),
        "changePassword": MessageLookupByLibrary.simpleMessage("ປ່ຽນລະຫັດຜ່ານ"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("ກວດສອບອີເມວ"),
        "choseACustomer": MessageLookupByLibrary.simpleMessage("ເລືອກລູກຄ້າ"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("ເລືອກຜູ້ສະຫວັດສິນຄ້າ"),
        "choseYourFeature": MessageLookupByLibrary.simpleMessage(
            "ເລືອກຄວາມຄືບັນຫາທີ່ຈະທ່ານຈັກ"),
        "clarence": MessageLookupByLibrary.simpleMessage("ຈຳນວນ"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("ຄລິກເພື່ອເຊື່ອມຕໍ່"),
        "close": MessageLookupByLibrary.simpleMessage("ປິດ"),
        "color": MessageLookupByLibrary.simpleMessage("ສີ"),
        "combinationOfMultipleTaxes":
            MessageLookupByLibrary.simpleMessage("(ການປະຊອບພາສີຫຼາຍ)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("ກຳລັງເລີ່ມ"),
        "companyAddress": MessageLookupByLibrary.simpleMessage("ທີ່ຢູ່ບໍລິສັດ"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("ຊື່ບໍລິສັດ & ຮ້ານ"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("ຊື່ບໍລິສັດແລະທຸລະກິດ"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("ການເຮັດການສົບຜົນສ່ວນຕົວ"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("ຢືນຢັນລະຫັດຜ່ານ"),
        "confirmReturn": MessageLookupByLibrary.simpleMessage("ຢືນຢັນຄືນ"),
        "congratulations": MessageLookupByLibrary.simpleMessage("ຊື່ສິນຄ້າ"),
        "contactUs": MessageLookupByLibrary.simpleMessage("ຕິດຕໍ່ພວກເຮົາ"),
        "continu": MessageLookupByLibrary.simpleMessage("ຕໍ່"),
        "country": MessageLookupByLibrary.simpleMessage("ປະເທດ"),
        "create": MessageLookupByLibrary.simpleMessage("ສ້າງ"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("ສ້າງບັນຊີຟຣີ"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("ເປີດແລະເກັບສຽງ"),
        "currency": MessageLookupByLibrary.simpleMessage("ເງິນຕາ"),
        "currentStock":
            MessageLookupByLibrary.simpleMessage("ສະຕັອກປະຈຳຕົວອອກ"),
        "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
            "ລາຍການໃບສົນຊ່ວຍການບັດສົນຊ່ວຍ"),
        "customer": MessageLookupByLibrary.simpleMessage("ລູກຄ້າ"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("ລາຍລະອຽດລູກຄ້າ"),
        "customerGST": MessageLookupByLibrary.simpleMessage("ກົດບັດລູກຄ້າ"),
        "customerName": MessageLookupByLibrary.simpleMessage("ຊື່ລູກຄ້າ"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("ການເຮັດການປະຈຳການມື້ນີ້"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Dashboard Overview"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("ຂໍໍໍາລົດສຳເນົດແລ້ວ"),
        "date": MessageLookupByLibrary.simpleMessage("ວັນທີ"),
        "day": MessageLookupByLibrary.simpleMessage("ມື້"),
        "dealer": MessageLookupByLibrary.simpleMessage("ນັກຮັບສີນຄ້າຂອງທ່ານ"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("ລາຄາຂາຍ"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("ລວມລົບ VAT"),
        "delete": MessageLookupByLibrary.simpleMessage("ລືບ"),
        "deleting": MessageLookupByLibrary.simpleMessage("ກຳລັງລົບ"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("ທີ່ຢູ່ຂອງຜູ້ສົ່ງສິນຄ້າ"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("ທີ່ຢູ່ສົ່ງສິນຄ້າ"),
        "deliveryCharge": MessageLookupByLibrary.simpleMessage("ຄ່າຂົນສົ່ງ"),
        "describtion": MessageLookupByLibrary.simpleMessage("ລາຍລະອຽດ"),
        "description": MessageLookupByLibrary.simpleMessage("ລວມລະບຽວ"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("ຄຳອະທິບາຍບໍ່ສາມາດແລ້ວ"),
        "details": MessageLookupByLibrary.simpleMessage("ລະລຽງ"),
        "discount": MessageLookupByLibrary.simpleMessage("ສ່ວນຫຼຸດ"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("ບໍ່ຫາກໍຕາມ"),
        "done": MessageLookupByLibrary.simpleMessage("ສຳເລັດ"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("ດາວ໌ໂອນຮູບແບບ Excel"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage("ດາວ໌ໂອນສໍາເລັດໃນແຟ້ມດາວໂອນ"),
        "due": MessageLookupByLibrary.simpleMessage("ຄ່າຊຳລະ"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("ຈຳນວນທີ່ຕ້ອງຊຳລະ: "),
        "dueCollection":
            MessageLookupByLibrary.simpleMessage("ການຊຳລະເງິນຊຳລະທັງຫມົດ"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("ບົດລາຍງານການຈ່າຍຄ່າທຳງານ"),
        "dueList": MessageLookupByLibrary.simpleMessage("ລາຍການຊຳລະ"),
        "dueReports": MessageLookupByLibrary.simpleMessage(
            "ລາຍງານການຊໍາລະທາງຄ່າເງິນຍັງຈ່າຍ"),
        "duration": MessageLookupByLibrary.simpleMessage("ອາຍຸ"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("ໄລຍະເວລາ: ຈາກ"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "ລະບົບໂມດູນຖ່າຍຄ່າອີກຈັບໄປຜ່ານ"),
        "edit": MessageLookupByLibrary.simpleMessage("ແກ້ໄຂ"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("ແກ້ໄຂໃບບິນການຊື້"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("ແກ້ໄຂໃບໃບບິນການຂາຍ"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("ແກ້ໄຂສື່ມການສື່ນເທີຕິດຕໍ່"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("ແກ້ໄຂສໍາເລັດ"),
        "editTax": MessageLookupByLibrary.simpleMessage("ແກ້ໄຂພາສີ"),
        "editTaxGroup": MessageLookupByLibrary.simpleMessage("ແກ້ໄຂກຸ່ມພາສີ"),
        "editWarehouse": MessageLookupByLibrary.simpleMessage("ແກ້ໄຂສິນຄ້າ"),
        "email": MessageLookupByLibrary.simpleMessage("ອີເມລ"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("ອີເມລທີ່ອີເມລ"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("ອີເມວບໍ່ສາມາດປ່ອນໄດ້"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "ອີເມວເສົ່ງແລ້ວ! ກວດເບິ່ງໃນອິນບອກຂອງທ່ານ"),
        "endDate": MessageLookupByLibrary.simpleMessage("ວັນສິ້ນສຸດ"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("ໃສ່ຈຳນວນທີ່ແມ່ນຈິງ"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("ໃສ່ສ່ວນຫລຸດທີ່ຖືກຕ້ອງ"),
        "enterAValidPhoneNumber":
            MessageLookupByLibrary.simpleMessage("ກະລຸນາໃສ່ເບີໂທທີ່ແມ່ນຈິງ"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("ໃສ່ລາຄາທີ່ແມ່ນຈິງ"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("ໃສ່ຈຳນວນທີ່ແມ່ນຈິງ"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("ປ້ອນທີ່ຢູ່"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("ປ້ອນຈຳນວນເງິນ"),
        "enterBrandName": MessageLookupByLibrary.simpleMessage("ປ້ອນຊື່ຍີ່ຫໍ້"),
        "enterCapacity": MessageLookupByLibrary.simpleMessage("ປ້ອນລວມຄ້າ"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("ປ້ອນຊື່ປະເພດ"),
        "enterColor": MessageLookupByLibrary.simpleMessage("ປ້ອນສີ"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "ກະລຸນາໃສ່ເລກທະບຽນ GST ຂອງລູກຄ້າ"),
        "enterDealerPrice": MessageLookupByLibrary.simpleMessage("ປ້ອນລາຄາຂາຍ"),
        "enterDescription": MessageLookupByLibrary.simpleMessage("ໃສ່ລວມລະບຽວ"),
        "enterDiscount": MessageLookupByLibrary.simpleMessage("ປ້ອນສ່ວນຫຼຸດ."),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("ປ້ອນວັນທີໃຊ້ເງິນ"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("ປ້ອນທີ່ຢູ່ເມືອງ"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("ປ້ອນເລກທີໃບບິນ"),
        "enterLowStockAlertQuantity":
            MessageLookupByLibrary.simpleMessage("ໃສ່ຈຳນວນຄໍາເຕືອນສະຕັດຕ່ຳ"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("ປ້ອນຜະລິດຕະພາບ"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("ປ້ອນເນື້ອຫາຂອງຂໍ້ຄວາມ"),
        "enterMrpOrRetailerPirce":
            MessageLookupByLibrary.simpleMessage("ປ້ອນ MRP/ລາຄາຂາຍ"),
        "enterName": MessageLookupByLibrary.simpleMessage("ປ້ອນຊື່"),
        "enterNote": MessageLookupByLibrary.simpleMessage("ປ້ອນໝາຍເຫດ"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("ປ້ອນຊື່ຄົນຊື້ຂາຍ"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("ປ້ອນເບີໂທຂອງທ່ານ"),
        "enterProductCodeOrScan":
            MessageLookupByLibrary.simpleMessage("ປ້ອນລະຫັດສິນຄ້າ ຫຼື ສະກັບ"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("ປ້ອນຊື່ສິນຄ້າ"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("ປ້ອນລາຄາຊື້."),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("ປ້ອນເລກທີ່ນໍາໃຊ້ໃໝ່"),
        "enterSize": MessageLookupByLibrary.simpleMessage("ປ້ອນຂະໜາດ"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("ປ້ອນຈຳນວນສິນຄ້າ."),
        "enterTaxRate": MessageLookupByLibrary.simpleMessage("ໃສ່ອັດຕາພາສີ"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("ໃບຮັບຊ້ອງກັນ ID"),
        "enterType": MessageLookupByLibrary.simpleMessage("ປ້ອນປະເພດ"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("ປ້ອນຫົວຂໍ້ຜູ້ໃຊ້"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("ໃສ່ຈຳນວນທີ່ແມ່ນຈິງ"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("ໃສ່ຊື່ສິນຄ້າ"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("ປ້ອນນ້ຳມັນ"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("ປ້ອນລາຄາຂາຍແທກ"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("ປ້ອນລາຍລະອຽດຂອງທ່ານນີ້"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("ກະລຸນາໃສ່ອີເມລຂອງທ່ານ"),
        "enterYourFeedBackTitle":
            MessageLookupByLibrary.simpleMessage("ປ້ອນຫົວໜ່ວຍຄຳແນະນຳຂອງທ່ານ"),
        "enterYourGSTNumber": MessageLookupByLibrary.simpleMessage(
            "ກະລຸນາໃສ່ເລກທະບຽນ GST ຂອງເທົ່ານັ້ນ"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("ປ້ອນເບີໂທລະສັບຂອງທ່ານ"),
        "enterYourName": MessageLookupByLibrary.simpleMessage("ປ້ອນຊື່ຂອງທ່ານ"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("ປ້ອນເບີໂທຂອງທ່ານ"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("ປ້ອນລະຫັດຜ່ານຂອງທ່ານ"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("ປ້ອນເບີໂທລະສັບຂອງທ່ານ"),
        "enterYourTransactionId":
            MessageLookupByLibrary.simpleMessage("ປ້ອນລະຫັດການເຮັດການຂອງທ່ານ"),
        "error": MessageLookupByLibrary.simpleMessage("ຜິດພາດ"),
        "excTax": MessageLookupByLibrary.simpleMessage("ພາສີບໍ່ລວມ"),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("ການໂອນຟາຍ Excel"),
        "exclusive": MessageLookupByLibrary.simpleMessage("ບໍ່ລວມ"),
        "expense": MessageLookupByLibrary.simpleMessage("ຄ່າໃຊ້ເງິນ"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("ປະເພດຄ່າໃຊ້ເງິນ"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("ວັນທີໃຊ້ເງິນ"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("ຈ່າຍສ້າງເຫດການ"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("ບົດລາຍການຄ່າໃຊ້ເງິນ"),
        "expireDate": MessageLookupByLibrary.simpleMessage("ວັນທີສໍາເລັດ"),
        "expired": MessageLookupByLibrary.simpleMessage("ແລ້ວໃໝ່"),
        "expiring": MessageLookupByLibrary.simpleMessage("ກຳລັງສໍາເລັດ"),
        "facebok": MessageLookupByLibrary.simpleMessage("ເຟຣມບັນພະຄົມ"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("ລົ້ມເລີຍດ້ວຍຄວາມຜິດພາດ"),
        "fashion": MessageLookupByLibrary.simpleMessage("ຕົວແທນ"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "ຄວາມຄືບັນຫາແມ່ນພາຍຫລັງທີ່ຈະໃຊ້ການ Pos Saas ຈັດຕະນີຈາກວິດີໂອຂອງການສະເຫນີຕາມພວກເຮົາ."),
        "feedBack": MessageLookupByLibrary.simpleMessage("ຄຳແນະນຳ"),
        "firstName": MessageLookupByLibrary.simpleMessage("ຊື່ແທ້"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("ຕາມພວກເຮົາໃນ\\nFacebook"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("ຕາມພວກເຮົາໃນ\\nTwitter"),
        "fontSide": MessageLookupByLibrary.simpleMessage("ຖົງໂລກ"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("ສະເຫນຳທຸລະກິດກໍ່ຄື"),
        "forgotPassword": MessageLookupByLibrary.simpleMessage("ລືມລະຫັດຜ່ານ"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("ລືມລະຫັດຜ່ານ?"),
        "formDate": MessageLookupByLibrary.simpleMessage("ວັນທີ່ເລີ່ມມື້"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("ການສຳຮອງຂໍ້ມູນທີ່ມີລົດສິນ"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "ປະຫວັດໂມງຫລືມພັກຢ່າງໂດຍມີການປັບປຸງໂມງ"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("ເອກະສານຟຣີດ"),
        "freePlan": MessageLookupByLibrary.simpleMessage("ເອກະສານຟຣີດ"),
        "from": MessageLookupByLibrary.simpleMessage("(ຈາກ"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("ຈ່າຍສົມບູນ"),
        "gallary": MessageLookupByLibrary.simpleMessage("ຮູບພາບ"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("ກຳລັງເປີດ PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("ໄອດີລະຫັດ OTP"),
        "govermentId":
            MessageLookupByLibrary.simpleMessage("ບັດປະຈຳຕົວຕະລາງພາສາ"),
        "guest": MessageLookupByLibrary.simpleMessage("ລູກຊ່ອມສາທາລະນະ"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("ບໍ່ມີບັນຊີ?"),
        "history": MessageLookupByLibrary.simpleMessage("ປະຫວັດ"),
        "home": MessageLookupByLibrary.simpleMessage("ໜ້າຫຼັກ"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "How We Protect Your Information"),
        "howWeUseYourInformation":
            MessageLookupByLibrary.simpleMessage("How We Use Your Information"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("ກວດກາດການກົດອາຟຣິກາ"),
        "image": MessageLookupByLibrary.simpleMessage("ຮູບພາບ"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("ສິນຄ້າໃນເຮືອນບໍ່ສາມາດລົບ"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("ສິນຄ້າໃນເຮືອນບໍ່ສາມາດແກ້ໄຂ"),
        "inWord": MessageLookupByLibrary.simpleMessage("ໃນສັບດຽວ"),
        "incTax": MessageLookupByLibrary.simpleMessage("ພາສີແບບລວມ"),
        "inclusive": MessageLookupByLibrary.simpleMessage("ລວມ"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("ເພີ່ມສິນຄ້າ"),
        "inistrument": MessageLookupByLibrary.simpleMessage("ຜະລິດຕະພາບ"),
        "instragram": MessageLookupByLibrary.simpleMessage("ອິນສະການອິນ"),
        "invNo": MessageLookupByLibrary.simpleMessage("ລະຫັດໃບບິນ"),
        "invoice": MessageLookupByLibrary.simpleMessage("ບັດຄະແນນ"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("ເລກທີໃບບິນ"),
        "invoiceSetting": MessageLookupByLibrary.simpleMessage("ຕັ້ງຄ່າໃບບິນ"),
        "invoiceViewer": MessageLookupByLibrary.simpleMessage("ມິດຄະແນນ"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("ເພີ່ມລາຍການໄດ້"),
        "kg": MessageLookupByLibrary.simpleMessage("ກິໂລກິກມັນ"),
        "kycVerification": MessageLookupByLibrary.simpleMessage("ກວດກາດ KYC"),
        "language": MessageLookupByLibrary.simpleMessage("ພາສາ"),
        "lastName": MessageLookupByLibrary.simpleMessage("ນາມສະກຸນ"),
        "ledger": MessageLookupByLibrary.simpleMessage("ລິບບັນທຶກ"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("ຊື້ເອກະສານໃຊ້ທົ່ວໄປ"),
        "link": MessageLookupByLibrary.simpleMessage("ເຊື່ອມຕໍ່"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("ລິດຄີເນັດ"),
        "liveChatSupport": MessageLookupByLibrary.simpleMessage("ສະໜອງຄອດເຖິງ"),
        "loading": MessageLookupByLibrary.simpleMessage("ກະຕອນບັນທຸກ"),
        "logIn": MessageLookupByLibrary.simpleMessage("ເຂົ້າສູ່ລະບົບ"),
        "logOUt": MessageLookupByLibrary.simpleMessage("ອອກຈາກລະບົບ"),
        "logOut": MessageLookupByLibrary.simpleMessage("ລົດອອກ"),
        "login": MessageLookupByLibrary.simpleMessage("ເຂົ້າສູ່ລະບົບ"),
        "logo": MessageLookupByLibrary.simpleMessage("ໂລໂກລະບົບ"),
        "loss": MessageLookupByLibrary.simpleMessage("ການຂາຍ"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("ຂັ້ນ/ການຍາການ"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("ລາຍລະອຽດຂັ້ນ/ການຍາການ"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("ລາຍງານຂາຍສົບ"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("ລາຍງານຂາຍສົບ"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("ຄໍາເຕືອນສະຕັດຕ່ຳ"),
        "maan": MessageLookupByLibrary.simpleMessage("ມານ"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "ສ້າງຄວາມປະທັບໃຈແກ່ລູກຄ້າຂອງທ່ານດ້ວຍໃບແຈ້ງໜີ້ທີ່ມີຍີ່ຫໍ້. ການອັບເກຣດແບບບໍ່ຈຳກັດຂອງພວກເຮົາໃຫ້ຂໍ້ໄດ້ປຽບທີ່ເປັນເອກະລັກຂອງການປັບແຕ່ງໃບແຈ້ງໜີ້ຂອງທ່ານ, ເພີ່ມການສໍາພັດແບບມືອາຊີບທີ່ເສີມສ້າງເອກະລັກຂອງຍີ່ຫໍ້ຂອງທ່ານແລະສົ່ງເສີມຄວາມສັດຊື່ຂອງລູກຄ້າ."),
        "manageYourBussinessWith": MessageLookupByLibrary.simpleMessage(
            "ຈັດການທາງີການບໍລິສັດຂອງທ່ານດ້ວຍ "),
        "manufactureDate": MessageLookupByLibrary.simpleMessage("ວັນທີຜະຕິດ"),
        "margin": MessageLookupByLibrary.simpleMessage("ເຄດເລືອນ"),
        "masterCard": MessageLookupByLibrary.simpleMessage("ເວລາເກີນ"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("ຜະລິດຕະພາບ"),
        "message": MessageLookupByLibrary.simpleMessage("ຂໍ້ຄວາມ"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("ປະຫວັດການສົ່ງຂໍ້ຄວາມ"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "ລະບົບ Pos Saas ຟຣີດ, ຄໍາຮ້ອງທາງໄວ້ງ່າຍ. ນີ້ແມ່ນລະຫວ່າງການນາຍພາສາຂອງການຂາຍພາຍໃນໂລກປະຈຳຕົວຕະລາງທີ່ມີໂມດູນຫຼາຍທີ່ປະສົງຂະນະໃນສົມບັດຂອງທ່ານໄດ້."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "ລະບົບ Pos Saas ຄວາມສາມາດເປັນການປະສານທັງຫມົດຂອງທ່ານດ້ວຍການນຳພາຍ, ບັດປະຈຳຕົວຕະລາງ, ການຂາຍ, ການຈ່າຍຄ່າ & ການໃຫ້ລູກຢູ່/ລາວລົງຂອງທ່ານ."),
        "mobile": MessageLookupByLibrary.simpleMessage("ໂທລະສັບ"),
        "mobilePayment":
            MessageLookupByLibrary.simpleMessage("ການຊໍາລະເງິນຜ່ານໂທລະສັບ"),
        "monthly": MessageLookupByLibrary.simpleMessage("ເດືອນ"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("ຂໍ້ມູນເພີ່ມເຕີມ"),
        "name": MessageLookupByLibrary.simpleMessage("ປ້ອນຊື່ຂອງທ່ານ"),
        "nameAlreadyExists": MessageLookupByLibrary.simpleMessage("ຊື່ມີແລ້ວ"),
        "nameCantBeEmpty": MessageLookupByLibrary.simpleMessage("ຊື່ບໍ່ໃສ່ໄດ້"),
        "next": MessageLookupByLibrary.simpleMessage("ຕໍ່ໄປ"),
        "noConnection":
            MessageLookupByLibrary.simpleMessage("ບໍ່ມີການເຊື່ອງໄປ"),
        "noData": MessageLookupByLibrary.simpleMessage("ບໍ່ມີຂໍ້ມູນ"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("ບໍ່ມີຂໍ້ມູນສຳລັບການກວດສອບ"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("ບໍ່ພົບຂໍໍຂໍໍຂໍໍມັນ"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("ບໍ່ພົບປະຫວັດການໃນບິນປີກ່ອນ!"),
        "noProductFound": MessageLookupByLibrary.simpleMessage("ບໍ່ພົບສິນຄ້າ"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("ບໍ່ມີພາສີຍໍໍທີ່ເລືອກ"),
        "noTransactionFound": MessageLookupByLibrary.simpleMessage(
            "ບໍ່ພົບການເຮັດການໃນບິນປີກ່ອນ!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "ບໍ່ພົບຜູ້ໃຊ້ງານສຳລັບອີເມລນີ້."),
        "noUserRoleFound":
            MessageLookupByLibrary.simpleMessage("ບໍ່ພົບບັດຜູ້ໃຊ້"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("ບໍ່ແມ່ນຜູ້ໃຊ້ທີ່ເບິ່ງໃສ"),
        "notProvided": MessageLookupByLibrary.simpleMessage("ບໍ່ແຈ່ໃສ່"),
        "note": MessageLookupByLibrary.simpleMessage("ໝາຍເຫດ"),
        "notes": MessageLookupByLibrary.simpleMessage("ເລີ່ມເລີຍ"),
        "notification": MessageLookupByLibrary.simpleMessage("ການແຈ້ງເຕືອນ"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP ສົ່ງໄປທີ່"),
        "office": MessageLookupByLibrary.simpleMessage("ສຳນວນ"),
        "ok": MessageLookupByLibrary.simpleMessage("ຕົກລົງ"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS that contains a great deal of functionality, including sales tracking, inventory management."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "This system helps you improve your operations for your customers."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Our POS system should simplify daily operations automatically, making it easy to navigate."),
        "openingBalance": MessageLookupByLibrary.simpleMessage("ຍອດເລີ່ມຕົ້ນ"),
        "order": MessageLookupByLibrary.simpleMessage("ສັງກັດ"),
        "other": MessageLookupByLibrary.simpleMessage("ອື່ນໆ"),
        "otp": MessageLookupByLibrary.simpleMessage("ປິດ"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("ສິນຄ້າບໍ່ມີສິນຄ້າ"),
        "pacakge": MessageLookupByLibrary.simpleMessage("ເອກະສານ"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("ຄວາມຄືສຳຫຼັບເອກະສານ"),
        "paid": MessageLookupByLibrary.simpleMessage("ຈ່າຍແລ້ວ"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("ຈຳນວນທີ່ຈ່າຍແລ້ວ"),
        "parties": MessageLookupByLibrary.simpleMessage("ຄົນຈຳເປັນ"),
        "partiesList": MessageLookupByLibrary.simpleMessage("ລາຍຊື່ຄົນຊື້ຂາຍ"),
        "partyGST": MessageLookupByLibrary.simpleMessage("ກົດບັດຄະແນນສົດສາສາ"),
        "partyName": MessageLookupByLibrary.simpleMessage("ຊື່ຄົນຊື້ຂາຍ"),
        "password": MessageLookupByLibrary.simpleMessage("ລະຫັດຜ່ານ"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "ລະຫັດຜ່ານ ແລະ ລະຫັດຜ່ານຢືນຢັນບໍ່ຄິດກັນ"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("ລະຫັດຜ່ານບໍ່ສາມາດປ່ອນໄດ້"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("ລະຫັດຜ່ານບໍ່ຕົງກັນ"),
        "payCash": MessageLookupByLibrary.simpleMessage("ຈ່າຍເງິນສົກຫຼິ່ນ"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash": MessageLookupByLibrary.simpleMessage("ຊໍາລະເງິນດູດ"),
        "payWithPaypal": MessageLookupByLibrary.simpleMessage("ຊໍາລະເງິນດູດ"),
        "payeeName": MessageLookupByLibrary.simpleMessage("ຊື່ຜູ້ຊໍາລະ"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("ເລກທະບຽນສູງສຸດ"),
        "payment": MessageLookupByLibrary.simpleMessage("ການຊຳລະເງິນ"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("ຈຳນວນເງິນຊຳລະ"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("ການຊຳລະເງິນໄດ້ສຳເລັດແລ້ວ"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("ຄຳຕິຊຳການຊໍາລະເງິນ:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("ວິທີການຈ່າຍ"),
        "paymentType":
            MessageLookupByLibrary.simpleMessage("ຊື່ປະເພດການຊຳລະເງິນ"),
        "pdfView": MessageLookupByLibrary.simpleMessage("ມອບບິນ PDF"),
        "personalInformation": MessageLookupByLibrary.simpleMessage(
            "ຂໍໍໍາລົດສະຖິຕິສະຕເສຍສ່ວນບຸກຄົນ"),
        "phone": MessageLookupByLibrary.simpleMessage("ເບິ່ງ"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("ເບີໂທລະສັບ"),
        "phoneNumberAlreadyUsed":
            MessageLookupByLibrary.simpleMessage("ເບີໂທໄດ້ຖືກໃຊ້ແລ້ວ"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("ເບີໂທບໍ່ແມ່ນຈິງ"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("ເບີໂທຈະຕ້ອງ"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("ເລືອກແລະໂອນຟາຍ"),
        "pickEndDate": MessageLookupByLibrary.simpleMessage("ເລືອນວັນສິ້ນສຸດ"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("ເລືອນວັນເລີ່ມມື້"),
        "plan": MessageLookupByLibrary.simpleMessage("ແຜນ"),
        "pleaseAddQuantity": MessageLookupByLibrary.simpleMessage("ຂໍໃສ່ຈຳນວນ"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "ກະລຸນາກວດສອບການເຊື່ອງໄປຂອງທ່ານ"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "ກະລຸນາເຊື່ອມຕໍ່ເປີນກ່ຽວກ່ຽວທີ່ສົ່ງສິນຄ້າສິນຄ້າ"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "ກະລຸນາເຊື່ອມຕໍ່ພຽງແຕ່ພຽງຊາວໂທລະສັບຂອງທ່ານ"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "ກະລຸນາໃສ່ລະຫັດຜ່ານທີ່ໃຫຍ່ກວ່າ"),
        "pleaseEnterAConfirmPassword":
            MessageLookupByLibrary.simpleMessage("ກະລຸນາປ້ອນຢືນຢັນລະຫັດຜ່ານ"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("ກະລຸນາໃສ່ລະຫັດຜ່ານ"),
        "pleaseEnterAValidEmail":
            MessageLookupByLibrary.simpleMessage("ກະລຸນາໃສ່ອີເມວທີ່ແມ່ນຈິງ"),
        "pleaseEnterName": MessageLookupByLibrary.simpleMessage("ກະລຸນາໃສ່ຊື່"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("ກະລຸນາໃສ່ລະຫັດຜ່ານ"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "ກະລຸນາປ້ອນອີເມລຂອງທ່ານລອງທີ່ຈະຮູ້ສຶກສາລະຫັດລະຫັດຜ່ານ."),
        "pleaseEnterTransactionNumber":
            MessageLookupByLibrary.simpleMessage("ກະລຸນາເປິ່ນເລກທະບຽນ"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("ກະລຸນາໃສ່ຈຳນວນ"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "ກະລຸນາເລືອກແບບສິນຄ້າກ່ຽວກ່ຽວກ່ຽວກ່ຽວກ່ຽວກ່ຽວກ່ຽວກ່ຽວກ່ຽວກ່ຽວກ່ຽວກ່ຽວ"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("ກະລຸນາເລືອກແຜນ"),
        "pleaseSelectBusinessCategory":
            MessageLookupByLibrary.simpleMessage("ກະລຸນາເລືອກແບບທຸລະກິດ"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "ກະລຸນາໃຊ້ລະຫັດຊື່ບັດທີ່ຖືກຕ້ອງເພື່ອໃຊ້ແອັບ"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("ຮູບແບບຂະຫນາດໂດຍ Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("ໂດຍສິນຄ້າ"),
        "premiumCustomerSupport": MessageLookupByLibrary.simpleMessage(
            "ການສະຫນັບລວບລວມຂອງລູກທໍາອ້ອມ"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("ເອກະສານນິຍົມ"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("ຈຳນວນເງິນຈ່າຍກ່ອນ"),
        "price": MessageLookupByLibrary.simpleMessage("ລາຄາ"),
        "print": MessageLookupByLibrary.simpleMessage("ພິມ"),
        "printingOption": MessageLookupByLibrary.simpleMessage("ຕົວເລືອນພິມ"),
        "privacyPolicy": MessageLookupByLibrary.simpleMessage("ຂໍ້ມູນລັດວິສາວ"),
        "product": MessageLookupByLibrary.simpleMessage("ສິນຄ້າ"),
        "productCode": MessageLookupByLibrary.simpleMessage("ລະຫັດສິນຄ້າ"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("ລະຫັດສິນຄ້າຈະຕ້ອງການ"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("ລະຫັດ/ຊື່ສິນຄ້າ"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("ລວມລະບຽດສິນຄ້າ"),
        "productDetails": MessageLookupByLibrary.simpleMessage("ລະລຽງສິນຄ້າ"),
        "productList": MessageLookupByLibrary.simpleMessage("ລາຍການສິນຄ້າ"),
        "productName": MessageLookupByLibrary.simpleMessage("ຊື່ສິນຄ້າ"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage("ຊື່ສິນຄ້າມີໃນແດນຄ້ານີ້ແລ້ວ"),
        "productNameIsAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("ຊື່ສິນຄ້າແມ່ນແລ້ວຖືກໃສ່"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("ຊື່ສິນຄ້າຈະຕ້ອງການ"),
        "products": MessageLookupByLibrary.simpleMessage("ສິນຄ້າ"),
        "profile": MessageLookupByLibrary.simpleMessage("ໂປຣໂມເອກະສານ"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("ແກ້ໄຂໂປຣໂຕ"),
        "profit": MessageLookupByLibrary.simpleMessage("ຍາການ"),
        "promo": MessageLookupByLibrary.simpleMessage("ໂປຣໂປ"),
        "promoCode": MessageLookupByLibrary.simpleMessage("ລະຫັດໂປ່ມ"),
        "purchase": MessageLookupByLibrary.simpleMessage("ການຊື້"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("ແນະນຳການຊື້ສິນຄ້າ"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("ການຊື້ສິນຄ້າຍັງຈະຖືກອະນຸຍາດ"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("ລາຍລະອຽດການຊື້"),
        "purchaseInvoice": MessageLookupByLibrary.simpleMessage("ໃບບັດຊື້"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("ລາຍການຊື້"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("ຊື້ດຽວນີ້"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("ຊື້ເອກະສານນິຍົມ"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("ລາຄາຊື້"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("ລາຄາຊື້ຈະຕ້ອງການ"),
        "purchaseRepoet": MessageLookupByLibrary.simpleMessage("ລາຍງານການຊື້"),
        "purchaseReports": MessageLookupByLibrary.simpleMessage("ລາຍງານການຊື້"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("ບົດລາຍງານການຊື້"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("ການກັບຄືນສິນຄ້າ"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("ລາຍງານຄືນຊື້"),
        "purchaseTransition": MessageLookupByLibrary.simpleMessage("ປ່ອນບິນ"),
        "qty": MessageLookupByLibrary.simpleMessage("ຈຳນວນ"),
        "quantity": MessageLookupByLibrary.simpleMessage("ຈຳນວນ"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("ການເຮັດການຫຼ້າສຸດ"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("ໄດ້ຮັບລະຫັດການຢືນຢັນແລ້ວ"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("ເລກທີ່ນໍາໃຊ້ໃໝ່"),
        "register": MessageLookupByLibrary.simpleMessage("ລົງທະບຽນ"),
        "registering": MessageLookupByLibrary.simpleMessage("ກະບວນການລົງທະນາ"),
        "remainingDue":
            MessageLookupByLibrary.simpleMessage("ລວມຄ່າຍ່ອຍທັງຫມົດ"),
        "remove": MessageLookupByLibrary.simpleMessage("ລົບ"),
        "reports": MessageLookupByLibrary.simpleMessage("ບົດລາຍການ"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("ຄະແນນໄດ້ຖືກສົ່ງ"),
        "resendCode":
            MessageLookupByLibrary.simpleMessage("ສົ່ງລະຫັດຕົວຢ່າງໃໝ່"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("ສົ່ງ OTP ອີກຄັ້ງ: "),
        "retailer": MessageLookupByLibrary.simpleMessage("ນັກຮັບສີນຄ້າ"),
        "retur": MessageLookupByLibrary.simpleMessage("ການສົ່ງສິນຄ້າຄືນ"),
        "returN": MessageLookupByLibrary.simpleMessage("ຄືນ"),
        "returnAMount":
            MessageLookupByLibrary.simpleMessage("ຈຳນວນເງິນການສົ່ງສິນຄ້າຄືນ"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("ຈຳນວນເງິນຄືນ"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("ຈຳນວນຄືນ"),
        "revenue": MessageLookupByLibrary.simpleMessage("ລາຍຮັບ"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "ປົກປ້ອງຂໍ້ມູນທຸລະກິດຂອງທ່ານຢ່າງງ່າຍດາຍ. Pos Saas POS Unlimited Upgrade ຂອງພວກເຮົາປະກອບມີການສໍາຮອງຂໍ້ມູນຟຣີ, ໃຫ້ແນ່ໃຈວ່າຂໍ້ມູນທີ່ມີຄຸນຄ່າຂອງທ່ານຖືກປົກປ້ອງຈາກເຫດການທີ່ບໍ່ໄດ້ຄາດຄິດ. ສຸມໃສ່ສິ່ງທີ່ສໍາຄັນແທ້ໆ - ການເຕີບໂຕຂອງທຸລະກິດຂອງທ່ານ."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("ຈຳນວນຂາຍ"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("ລາຍລະອຽດການຂາຍ"),
        "salePrice": MessageLookupByLibrary.simpleMessage("ລາຄາຂາຍ"),
        "saleReports": MessageLookupByLibrary.simpleMessage("ລາຍງານການຂາຍ"),
        "saleReportss": MessageLookupByLibrary.simpleMessage("ບົດລາຍງານການຂາຍ"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("ຄືນຂາຍ"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("ລາຍງານຄືນຂາຍ"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("ຕັ້ງຄ່າຂາຍ"),
        "sales": MessageLookupByLibrary.simpleMessage("ການຂາຍ"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("Sale & Purchase Reports"),
        "salesList": MessageLookupByLibrary.simpleMessage("ລາຍການຂາຍ"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("ຄືນຂາຍ"),
        "save": MessageLookupByLibrary.simpleMessage("ບັນທຶກ"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("ບັນທຶກແລະເຜີຍແກ້"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("ບັນທຶກການປ່ຽນແປງ"),
        "saving": MessageLookupByLibrary.simpleMessage("ກຳລັງບັນທຶກ"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("ສແສນລະຫັດ QR ສິນຄ້າ"),
        "search": MessageLookupByLibrary.simpleMessage("ຄົ້ນຫາ"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "ຄົ້ນຫາຕາມລະຫັດສິນຄ້າ ຫຼື ຊື່"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("ເບິ່ງລະຫັດໂປ່ມທັງຫມົດ"),
        "select": MessageLookupByLibrary.simpleMessage("ເລືອກ"),
        "selectAProductForReturn":
            MessageLookupByLibrary.simpleMessage("ເລືອກສິນຄ້າເພື່ອຄືນ"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("ເລືອກແບບ"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("ເລືອກແບບສິນຄ້າ"),
        "selectContacts": MessageLookupByLibrary.simpleMessage("ເລືອກຕິດຕໍ່"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("ເລືອກແບບສິນຄ້າ"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("ເລືອກແບບຮ້ານ"),
        "selectTax": MessageLookupByLibrary.simpleMessage("ເລືອກພາສີ"),
        "selectTaxType": MessageLookupByLibrary.simpleMessage("ເລືອກແບບພາສີ"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("ເລືອກໜ່ວຍ"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("ເລືອກປະເພດ: "),
        "seller": MessageLookupByLibrary.simpleMessage("ຜູ້ຂາຍ"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("ຂາຍໂດຍ"),
        "send": MessageLookupByLibrary.simpleMessage("ສົ່ງ"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("ສົ່ງອີເມລ"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("ສົ່ງຂໍ້ຄວາມ"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("ສົ່ງລິ້ງລະຫັດລະຫັດຜ່ານ"),
        "sendSms": MessageLookupByLibrary.simpleMessage("ສົ່ງ SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("ສົ່ງ SMS?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("ສົ່ງຂໍແນະນຳໃສ່ Whatsapp"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("ສົ່ງອີເມລຂອງທ່ານ"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage("ກຳລັງສົ່ງອີເມວ"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("ກຳລັງສົ່ງຂໍແອບ"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("ບໍດິກບໍລິການ/ສົ່ງເສດ"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("ຕັ້ງຂໍ້ມູນໂປຣໄຟລຂອງທ່ານ"),
        "setting": MessageLookupByLibrary.simpleMessage("ຕັ້ງຄ່າ"),
        "share": MessageLookupByLibrary.simpleMessage("ແບ່ງປັນ"),
        "shopGST": MessageLookupByLibrary.simpleMessage("ກົດບັດຮ້ານ"),
        "signIn": MessageLookupByLibrary.simpleMessage("ເຂົ້າລະບົບ"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("ເຂົ້າລະບົບດ້ວຍອີເມວ"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("ລົງຊື່ຂອງລູກຄ້າ"),
        "size": MessageLookupByLibrary.simpleMessage("ຂະໜາດ"),
        "skip": MessageLookupByLibrary.simpleMessage("ຂໍ້ມູນນີ້"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing": MessageLookupByLibrary.simpleMessage(
            "ການຕິດຕໍ່ພາຍໃນວິດຕາມບັນຊີຂອງຜູ້ໃຊ້"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "ສຽງໃສ່ພະລັດດັບລະດັບໃສ່ນຳເວັບທ່ານ"),
        "startDate": MessageLookupByLibrary.simpleMessage("ວັນເລີ່ມມື້"),
        "startNewSale": MessageLookupByLibrary.simpleMessage("ເລີ່ມການຂາຍໃໝ່"),
        "startTypingToSearch":
            MessageLookupByLibrary.simpleMessage("ເລີ່ມຕົວຢ່າງເພື່ອຄົ້ນຫາ"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "ຢືນໃຈຢູ່ໃບພັກພິເກຊ້ານຕາມການການແບ່ງ່າຍໂດຍບໍ່ມີຄ່າເພີ່ມເຕີ. Pos Saas POS Unlimited Upgrade ການປັບປຸງທ່ານຄືນມີຂະຫວີແຫຼ່ນດ້ວຍມີຄ່າໂດຍນຳມາ, ການກອກຕອນແລະຄາວວ່າການສະບັບຂອງທ່ານຄວນກັບການສະຖິງຂຶ້ງ."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("ຍັງບໍ່ຈ່າຍ"),
        "stock": MessageLookupByLibrary.simpleMessage("ສາຍສິນຄ້າ"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("ສາກໍາລະດັບຈະຕ້ອງການ"),
        "stockList": MessageLookupByLibrary.simpleMessage("ລາຍການສະຕັອກ"),
        "stocks": MessageLookupByLibrary.simpleMessage("ຈຳນວນສິນຄ້າ"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "ອະນຸຍາດສະຖານທີ່ຈິງຈະຕ້ອງເພື່ອເລີ່ມສໍາເນົາຟາຍ Excel"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("ລາຍການພາສີຍໍໍ"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("ພາສີຍໍໍ"),
        "subTotal": MessageLookupByLibrary.simpleMessage("ລວມລາຄາຍົວກວ່າ"),
        "submit": MessageLookupByLibrary.simpleMessage("ສົ່ງ"),
        "subscribeToOurYoutube":
            MessageLookupByLibrary.simpleMessage("ສະຖານທີ່ໃນ\\nYoutube"),
        "subscription": MessageLookupByLibrary.simpleMessage("ການສະຫນັບເງິນ"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("ເຮັດແລ້ວສົມບູນ"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("ລົດອອກສໍາເລັດ"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("ແກ້ໄຂສຳເລັດ"),
        "supplier": MessageLookupByLibrary.simpleMessage("ຜູ້ສະໜອງ"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("ຊື່ຜູ້ສະຫວັດສິນຄ້າ"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("ລະຫັດ SWIFT"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "ເກົ່າໃສ່ກິດຈະກຳຂັບ, ບັດປະຈຳຕົວຕະລາງສັນຍານລາວ ຫຼືຮູບປະຈຳຕົວຕະລາງ"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "ເກົ່າໄວ້ກິດຈະກຳການກົດອາຟຣິກາໃນການກວດສອບຂໍ້ມູນຂອງທ່ານ"),
        "tap": MessageLookupByLibrary.simpleMessage("ຈິດ"),
        "tax": MessageLookupByLibrary.simpleMessage("ພາສີ"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("ກຸ່ມພາສີ"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("ເປີເຊນພາສີ"),
        "taxRate": MessageLookupByLibrary.simpleMessage("ອັດຕາພາສີ"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "ອັດຕາພາສີ- ຈັດການອັດຕາພາສີຂອງເຈົ້າ"),
        "taxReport": MessageLookupByLibrary.simpleMessage("ບົດລາຍງານພາສີ"),
        "taxType": MessageLookupByLibrary.simpleMessage("ແບບພາສີ"),
        "taxes": MessageLookupByLibrary.simpleMessage("ພາສີ"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("ແນວແລະສະບັບຂອງຄວາມລັບ"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("ແຈ້ງເຕືອນການນຳໃຊ້"),
        "termsPrivacy": MessageLookupByLibrary.simpleMessage("ແນວແລະຄວາມລັບ"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "ຂໍຂອບໃຈທ່ານສິນຄ້າຈ່າຍຊຳລະທັງຫມົດ"),
        "thankYou": MessageLookupByLibrary.simpleMessage("ຂອບໃຈ"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("ຂໍຂອບໃຈທ່ານສິນຄ້າໃນການຊື້"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "ບັນຊີນີ້ໄດ້ສໍາລັບອີເມວນີ້ແລ້ວ"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage("ຟາຍ Excel ຖືກໂອນແລ້ວ"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "ຊື່ເວົ້າວ່າມັນທັງຫມົດ. ດ້ວຍ Pos Saas POS Unlimited, ບໍ່ມີຂີດຈຳກັດໃນການນຳໃຊ້ຂອງທ່ານ. ບໍ່ວ່າທ່ານກໍາລັງດໍາເນີນທຸລະກໍາຈໍານວນຫນຶ່ງຫຼືປະສົບກັບລູກຄ້າທີ່ຮີບຮ້ອນ, ທ່ານສາມາດດໍາເນີນການດ້ວຍຄວາມຫມັ້ນໃຈ, ໂດຍຮູ້ວ່າທ່ານບໍ່ໄດ້ຖືກຈໍາກັດໂດຍຂໍ້ຈໍາກັດ."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "ລະຫັດຜ່ານທີ່ໃຫ້ມາດັ່ງແບບອ່ອນເກີນໄປ"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "ການຂາຍຈະຖືກລົບແລະຂໍໍເດັດແລະຂໍໍຂໍໍໍຂອງການຊື້ນີ້. ທ່ານແນ່ໃຈທີ່ຈະລົບບໍ?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "ຂາຍນີ້ຈະຖອນແລະຂໍໍານວນສິນຄ້າຈະຖອນສະຖິດສູບການຄືນແນ່ໃຈບໍ່ວ່າຈະລົບກັບນີ້"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "ຜູ້ໃຊ້ງານຈະຖືກລົບແລ້ວເລື່ອງທີ່ຂ້ອຍຈະຖືກລົບລາຍການທັງຫມົດຈາກບັນຊີຂອງທ່ານ. ທ່ານແນ່ໃຈບໍ່ທີ່ຈະລົບອີເມລແນວໃດນີ້?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "ຜູ້ໃຊ້ຈະຖືກລຶບແລະຂໍໍຂໍໍທັງເຂົ້າຂໍໍໍຈະຖືກລຶບຈາກບັນຊີຂອງເຈົ້າ. ເຈົ້າແນ່ໃຈບໍ່ທີ່ຈະລຶບນີ້"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Third-Party Services"),
        "thisCategoryCannotBeDeleted":
            MessageLookupByLibrary.simpleMessage("ປະເພດນີ້ບໍ່ສາມາດຖອນອອກ"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(ໃນເດືອນນີ້)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "ສິນຄ້ານີ້ແລ້ວແຕ່ກ່ຽວກ່ຽວກ່ຽວ"),
        "title": MessageLookupByLibrary.simpleMessage("ຫົວໜ່ວຍ"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("ຊື່ບໍ່ສາມາດແລ້ວ"),
        "to": MessageLookupByLibrary.simpleMessage("ສູ່"),
        "toDate": MessageLookupByLibrary.simpleMessage("ວັນທີ່ສິ້ນສຸດ"),
        "today": MessageLookupByLibrary.simpleMessage("ມື້ນີ້"),
        "total": MessageLookupByLibrary.simpleMessage("ລວມ"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("ຈຳນວນທັງຫມົດ"),
        "totalCollected": MessageLookupByLibrary.simpleMessage("ຈຳນວນສົມບູນ"),
        "totalDue": MessageLookupByLibrary.simpleMessage("ລວມຄ່າຊຳລະທັງຫມົດ"),
        "totalExpense":
            MessageLookupByLibrary.simpleMessage("ລວມຄ່າໃຊ້ເງິນທັງຫມົດ"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("ສິນຄ້າສູນ"),
        "totalPayable": MessageLookupByLibrary.simpleMessage("ລວມຍ່ອຍທັງຫມົດ"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("ລວມລາຄາທັງຫມົດ"),
        "totalProducts": MessageLookupByLibrary.simpleMessage("ສິນຄ້າທັງໝົດ"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("ສິນຄ້າຮັບ"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("ຊື້ທັງໝົດ"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("ຈຳນວນຄືນທັງໝົດ"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("ຈຳນວນຄືນທັງໝົດ"),
        "totalSale": MessageLookupByLibrary.simpleMessage("ລວມການຂາຍທັງຫມົດ"),
        "totalStock": MessageLookupByLibrary.simpleMessage("ສະຕັອກທັງຫມົດ"),
        "totalValue": MessageLookupByLibrary.simpleMessage("ລາຄາລວມ"),
        "totalVat":
            MessageLookupByLibrary.simpleMessage("ລວມມອງການພາສີທັງຫມົດ"),
        "totals": MessageLookupByLibrary.simpleMessage("ລວມ: "),
        "transaction": MessageLookupByLibrary.simpleMessage("ການເຮັດການ"),
        "transactionId":
            MessageLookupByLibrary.simpleMessage("ລະຫັດການເຮັດການ"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("ລອງອີກຄັ້ງ"),
        "twitter": MessageLookupByLibrary.simpleMessage("ທວິດສະດີ"),
        "type": MessageLookupByLibrary.simpleMessage("ປະເພດ"),
        "unitName": MessageLookupByLibrary.simpleMessage("ຊື່ຫົວໜ່ວຍ"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("ລາຄາຕາຕະລາງ"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("ລາຄາໃບຕົວ"),
        "units": MessageLookupByLibrary.simpleMessage("ຫົວໜ່ວຍ"),
        "unlimited": MessageLookupByLibrary.simpleMessage("ບໍ່ຈິດຈິງ"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("ການນໍາໃຊ້ທົ່ວໂລກ"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "ປົດລັອກທ່າແຮງອັນເຕັມທີ່ຂອງ Pos Saas POS ດ້ວຍການຝຶກອົບຮົມສ່ວນບຸກຄົນທີ່ນໍາພາໂດຍທີມງານຜູ້ຊ່ຽວຊານຂອງພວກເຮົາ. ຈາກພື້ນຖານໄປສູ່ເຕັກນິກຂັ້ນສູງ, ພວກເຮົາຮັບປະກັນວ່າທ່ານມີຄວາມຊໍານິຊໍານານໃນການນໍາໃຊ້ທຸກໆດ້ານຂອງລະບົບເພື່ອເພີ່ມປະສິດທິພາບຂະບວນການທຸລະກິດຂອງທ່ານ."),
        "unpaid": MessageLookupByLibrary.simpleMessage("ບໍ່ແຈ່ເງິນ"),
        "update": MessageLookupByLibrary.simpleMessage("ປັບປຸງ"),
        "updateContact": MessageLookupByLibrary.simpleMessage("ປັບປຸງຕິດຕໍ່"),
        "updateNow":
            MessageLookupByLibrary.simpleMessage("ປ່ຽນແປງຕົວຢ່າງດຽວກັນ"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("ແກ້ໄຂລາຍການສິນຄ້າ"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "ອັບໄດເບິ່ງອະທິບາຍທີ່ທ່ານຈິງແລ້ວທ່ານຈິງ"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("ປ່ຽນແປງໂປຣໂມເອກະສານຂອງທ່ານ"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "ປັບປຸງໂປຣໄຟລຂອງທ່ານເພື່ອເຊື່ອມຕໍ່ຜູ້ບໍລິຫານຂອງທ່ານດຽວກັນນຳສືກສາທາງປະທານສົດ"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "ປ່ຽນແປງໂປຣໂມເອກະສານຂອງທ່ານເພື່ອເຊື່ອມຕໍ່ທຸກຄົນຊົ່ວລາຍການທາງທັງສິນຄ້າດົນເລືອກ"),
        "updated": MessageLookupByLibrary.simpleMessage("ອັບເດດ"),
        "upload": MessageLookupByLibrary.simpleMessage("ໂອນ"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("ອັບໂຫຼດເອກະສານ"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("ໂອນແລ້ວ"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("ອັບໂຫຼດໄຟລ"),
        "upplier": MessageLookupByLibrary.simpleMessage("ຜູ້ສະໜອງ"),
        "usbC": MessageLookupByLibrary.simpleMessage("USB C"),
        "use": MessageLookupByLibrary.simpleMessage("ໃຊ້"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("ໃຊ້ລະບົບ Pos Saas"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Use of the system"),
        "userIsDeleted": MessageLookupByLibrary.simpleMessage("ຜູ້ໃຊ້ຖືກລຶບ"),
        "userRole": MessageLookupByLibrary.simpleMessage("ບັນຊີຜູ້ໃຊ້"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("ລາຍລະອຽດຜູ້ໃຊ້"),
        "userTitle": MessageLookupByLibrary.simpleMessage("ຫົວຂໍ້ຜູ້ໃຊ້"),
        "userTitleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("ຊື່ຜູ້ໃຊ້ບໍ່ໃສ່ຄ່າ"),
        "value": MessageLookupByLibrary.simpleMessage("ລາຄາ"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("ພາສີບໍ່ແບ່ງຂື້ນ"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("ກວດສອບ OTP"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("ກວດສອບເບີໂທລະຫັດ"),
        "viewAll": MessageLookupByLibrary.simpleMessage("ເບິ່ງທັງຫມົດ"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("ເບິ່ງລາຍລະອຽດ"),
        "walkInCustomer": MessageLookupByLibrary.simpleMessage("ລູກຊ່ອມໄວ້"),
        "warehouse": MessageLookupByLibrary.simpleMessage("ຄ່າສິນຄ້າ"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("ສິນຄ້ານີ້ມີແລ້ວ"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("ລາຍຊື່ສິນຄ້າ"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("ຊື່ສິນຄ້າ"),
        "warranty": MessageLookupByLibrary.simpleMessage("ການປ່ອນໃຫ້"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "ພວກເຮົາໄດ້ສົ່ງອີເມວຕາມຄຳຕອບເອກະສານຕິດຕໍ່ກັບວິຊາການຊົມລະຫວ່າງສອນ:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "We may use third-party services to support our app\'s functionality, such as analytics providers and payment processors. These third-party services may collect information about you when you use our app. Please note that we are not responsible for the privacy practices of these third-party services."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "We take industry-standard measures to protect your personal information, including encryption and secure storage. We also limit access to your information to authorized personnel only."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "ພວກເຮົາເຂົ້າໃຈຄວາມສໍາຄັນຂອງການດໍາເນີນງານ seamless. ນັ້ນແມ່ນເຫດຜົນທີ່ວ່າການສະຫນັບສະຫນູນຕະຫຼອດໂມງຂອງພວກເຮົາແມ່ນມີຢູ່ເພື່ອຊ່ວຍທ່ານ, ບໍ່ວ່າຈະເປັນການສອບຖາມດ່ວນຫຼືຄວາມກັງວົນທີ່ສົມບູນແບບ. ເຊື່ອມຕໍ່ກັບພວກເຮົາທຸກເວລາ, ທຸກແຫ່ງຫົນໂດຍການໂທຫຼື WhatsApp ເພື່ອປະສົບການການບໍລິການລູກຄ້າທີ່ບໍ່ມີໃຜທຽບໄດ້."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "We use your personal information to provide you with the best possible experience on our app, including to personalize your content recomme ndations, connect you with experts, and improve our apps functionality. We may also use your information to communicate with you about updates, promotions, or other information related to our app."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "ພວກເຮົາຈະກວດສອບການຈ່າຍແລະອະນຸມັດໃນໄວໆ 1-2 ຊົ່ວໂມງ"),
        "weekly": MessageLookupByLibrary.simpleMessage("ປະຈຳອາທິດ"),
        "weight": MessageLookupByLibrary.simpleMessage("ນ້ຳມັນ"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("ຫຍັງແມ່ນເປັນໃນ"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("ນັກຮັບສີນຄ້າລາວ"),
        "wholeSalePrice": MessageLookupByLibrary.simpleMessage("ລາຄາຂາຍແທກ"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("ລາຄາສໍາລວດ"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("ຜູ້ຂາຍປະຈໍາ"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("ຈະເພີ່ມໃນໄວໆນີ້"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("ຈະເສຍຈາກໃນ"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("ປ້ອນຂໍ້ຄວາມຂອງທ່ານທີ່ນີ້"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("OTP ຜິດ"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "ລະຫັດຜ່ານທີ່ໃສ່ສິດຜິດພາດສຳລັບຜູ້ໃຊ້ງານນີ້."),
        "yearly": MessageLookupByLibrary.simpleMessage("ປີ"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("ດຳເນີນລົບຄືນ"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("ທ່ານເປັນຜູ້ໃຊ້ທີ່ບໍ່ຖືກຕ້ອງ"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("ທ່ານໃຊ້"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "ທ່ານບໍ່ສາມາດເຊິກຈ່າຍເງິນເກີນຈິງ"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("ທ່ານມີອີເມລທີ່"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "ທ່ານໄດ້ເຂົ້າລະບົບສົມບູນ. ປ້ອນຕົວຕົນດຽວກັນກັບ Pos Saas."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("ທ່ານຕ້ອງໃຫ້ອະນຸຍາດ"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "ທ່ານຕ້ອງເຂົ້າລະບົບສົ່ງສຳນັກສຳຮອງໃຫ້ທ່ານ."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "ທ່ານຕ້ອງກວດກາດການກົດອາຟຣິກາກ່ອນທ່ານຊື້ SMS"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("ຂໍ້ຄວາມຂອງທ່ານຍັງຢູ່"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("ເອກະສານຂອງທ່ານ"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "ເອກະສານຂອງທ່ານຈະໝົດອາຍຸສອນໃນ 5 ມື້")
      };
}
