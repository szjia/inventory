// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a pl locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'pl';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Kontynuuj"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("Numer GST"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("MRP jest wymagane"),
        "OK": MessageLookupByLibrary.simpleMessage("OK"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Nr tel."),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("Kod SWIFT"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Przekąski"),
        "TAX": MessageLookupByLibrary.simpleMessage("PODATEK"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Przesyłanie"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("Tytuł użytkownika"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Twoja paczka wygaśnie dzisiaj\n\nProszę zakupić ją ponownie"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) System jest dostarczany wyłącznie w celu ułatwienia transakcji sprzedaży i związanych z nimi działań w Twojej firmie."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) Aby korzystać z Systemu, możesz być zobowiązany do założenia konta. Zgadzasz się dostarczyć dokładne, aktualne i kompleksowe informacje podczas procesu rejestracji i aktualizować te informacje, aby były dokładne i kompleksowe."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("O aplikacji"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("O nas"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Akceptacja warunków"),
        "accountName": MessageLookupByLibrary.simpleMessage("Nazwa konta"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("Numer konta"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Rejestracja konta"),
        "acton": MessageLookupByLibrary.simpleMessage("Akcja"),
        "add": MessageLookupByLibrary.simpleMessage("Dodaj"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Dodaj markę"),
        "addCategory": MessageLookupByLibrary.simpleMessage("Dodaj kategorię"),
        "addContact": MessageLookupByLibrary.simpleMessage("Dodaj kontakt"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Dodaj klienta"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("Dodaj dostawę"),
        "addDescriptioN": MessageLookupByLibrary.simpleMessage("Dodaj opis"),
        "addDescription": MessageLookupByLibrary.simpleMessage("Dodaj notatkę"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Dodaj zniżkę"),
        "addDocumentId": MessageLookupByLibrary.simpleMessage(
            "Dodaj identyfikator dokumentu"),
        "addDucument": MessageLookupByLibrary.simpleMessage("Dodaj dokument"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Dodaj wydatek"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Dodaj kategorię wydatków"),
        "addItems": MessageLookupByLibrary.simpleMessage("Dodaj elementy"),
        "addNew": MessageLookupByLibrary.simpleMessage("Dodaj nowy"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Dodaj nowy adres"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Dodaj nowy produkt"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("Dodaj nowy podatek"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Dodaj nowy podatek z jednym/wieloma typami podatków"),
        "addNote": MessageLookupByLibrary.simpleMessage("Dodaj notatkę"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Najpierw dodaj produkt"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Dodaj kod promocyjny"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Dodaj zakup"),
        "addSales": MessageLookupByLibrary.simpleMessage("Dodaj sprzedaż"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Dodano pomyślnie"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Dodaj jednostkę"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Dodaj rolę użytkownika"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Dodano pomyślnie"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("Dodano do koszyka"),
        "address": MessageLookupByLibrary.simpleMessage("Adres"),
        "admin": MessageLookupByLibrary.simpleMessage("Administrator"),
        "all": MessageLookupByLibrary.simpleMessage("Wszystko"),
        "allBusinessSolution": MessageLookupByLibrary.simpleMessage(
            "Wszystkie rozwiązania biznesowe"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("Już dodano"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Już istnieje"),
        "amount": MessageLookupByLibrary.simpleMessage("Kwota"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "Wysłano e-mail\\nSprawdź swoją skrzynkę odbiorczą"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Wsparcie dla aplikacji Android i iOS"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Obowiązujący podatek"),
        "apply": MessageLookupByLibrary.simpleMessage("Zastosuj"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Czy na pewno chcesz usunąć tę fakturę?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Czy na pewno chcesz usunąć tę sprzedaż?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Czy na pewno chcesz usunąć tego użytkownika?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Czy na pewno chcesz usunąć ten podatek?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Czy na pewno chcesz usunąć tę grupę podatkową?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Czy chcesz usunąć ten magazyn?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Czy na pewno chcesz usunąć tego użytkownika?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Podpis autoryzowany"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Jesteś odpowiedzialny za zachowanie poufności swojego konta i hasła oraz za ograniczenie dostępu do swojego konta. Ponosisz odpowiedzialność za wszystkie działania, które mają miejsce na Twoim koncie."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Musisz mieć co najmniej 18 lat lub pełnoletniość obowiązującą w Twojej jurysdykcji, aby korzystać z Systemu."),
        "backSide": MessageLookupByLibrary.simpleMessage("Strona tylna"),
        "backToHome":
            MessageLookupByLibrary.simpleMessage("Powrót do strony głównej"),
        "balance": MessageLookupByLibrary.simpleMessage("Saldo"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladesz"),
        "bank": MessageLookupByLibrary.simpleMessage("Bank"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Waluta konta bankowego"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Waluta konta bankowego"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Informacje bankowe"),
        "bankName": MessageLookupByLibrary.simpleMessage("Nazwa banku"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("Przelew bankowy"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Znaleziono kod kreskowy"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Rachunek/Faktura"),
        "billTo": MessageLookupByLibrary.simpleMessage("Do zapłaty"),
        "branchName": MessageLookupByLibrary.simpleMessage("Nazwa oddziału"),
        "brand": MessageLookupByLibrary.simpleMessage("Marka"),
        "brandName": MessageLookupByLibrary.simpleMessage("Nazwa marki"),
        "bulkUpload":
            MessageLookupByLibrary.simpleMessage("Masowe \\nPrzesyłanie"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Kategoria biznesu"),
        "buy": MessageLookupByLibrary.simpleMessage("Kup"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Kup plan premium"),
        "buySms": MessageLookupByLibrary.simpleMessage("Kup SMS"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Korzystając z Systemu Punktów Sprzedaży (POS) („System”) dostarczanego przez [Nazwa Twojej Firmy] („Firmę”), zgadzasz się być związany tymi Warunkami Korzystania. Jeśli nie zgadzasz się z tymi Warunkami Korzystania, nie korzystaj z Systemu."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Jesteś odpowiedzialny za zapewnienie, że Twoje korzystanie z Systemu jest zgodne z obowiązującym prawem i przepisami."),
        "call": MessageLookupByLibrary.simpleMessage("Zadzwoń"),
        "callForEmergencySupport":
            MessageLookupByLibrary.simpleMessage("Zadzwoń po pomoc awaryjną"),
        "camera": MessageLookupByLibrary.simpleMessage("Aparat"),
        "cancel": MessageLookupByLibrary.simpleMessage("Anuluj"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Anuluj wszystkie produkty"),
        "capacity": MessageLookupByLibrary.simpleMessage("Pojemność"),
        "card": MessageLookupByLibrary.simpleMessage("Karta"),
        "cash": MessageLookupByLibrary.simpleMessage("Gotówka"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Kategorie"),
        "category": MessageLookupByLibrary.simpleMessage("Kategoria"),
        "categoryName": MessageLookupByLibrary.simpleMessage("Nazwa kategorii"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "Nazwa kategorii już istnieje"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("Nazwa kategorii"),
        "change": MessageLookupByLibrary.simpleMessage("Zmień?"),
        "changePassword": MessageLookupByLibrary.simpleMessage("Zmień hasło"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("Sprawdź e-mail"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Wybierz swoje funkcje"),
        "clarence": MessageLookupByLibrary.simpleMessage("Clarence"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Kliknij, aby połączyć"),
        "close": MessageLookupByLibrary.simpleMessage("Zamknij"),
        "color": MessageLookupByLibrary.simpleMessage("Kolor"),
        "combinationOfMultipleTaxes":
            MessageLookupByLibrary.simpleMessage("(Kombinacja wielu podatków)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Wkrótce"),
        "companyAddress": MessageLookupByLibrary.simpleMessage("Adres firmy"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Nazwa firmy i sklepu"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("Nazwa firmy i działalności"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Zakończ transakcję"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Potwierdź hasło"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Potwierdź zwrot"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Gratulacje"),
        "contactUs":
            MessageLookupByLibrary.simpleMessage("Skontaktuj się z nami"),
        "continu": MessageLookupByLibrary.simpleMessage("Kontynuuj"),
        "country": MessageLookupByLibrary.simpleMessage("Kraj"),
        "create": MessageLookupByLibrary.simpleMessage("Utwórz"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Utwórz darmowe konto"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Utworzono i zapisano"),
        "currency": MessageLookupByLibrary.simpleMessage("Waluta"),
        "currentStock": MessageLookupByLibrary.simpleMessage("Aktualne zapasy"),
        "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
            "Spersonalizowane znakowanie faktur"),
        "customer": MessageLookupByLibrary.simpleMessage("Klient"),
        "customerDetails": MessageLookupByLibrary.simpleMessage("Dane klienta"),
        "customerGST": MessageLookupByLibrary.simpleMessage("GST klienta"),
        "customerName": MessageLookupByLibrary.simpleMessage("Imię klienta"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Przegląd panelu"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Dane zapisane pomyślnie"),
        "date": MessageLookupByLibrary.simpleMessage("Data"),
        "day": MessageLookupByLibrary.simpleMessage("Dzień"),
        "dealer": MessageLookupByLibrary.simpleMessage("Diler"),
        "dealerPrice":
            MessageLookupByLibrary.simpleMessage("Cena dla dealerów"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("Domyślny procent VAT"),
        "delete": MessageLookupByLibrary.simpleMessage("Usuń"),
        "deleting": MessageLookupByLibrary.simpleMessage("Usuwanie"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Adres dostawy"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Adresy dostawy"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Opłata za dostawę"),
        "description": MessageLookupByLibrary.simpleMessage("Opis"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Opis nie może być pusty"),
        "details": MessageLookupByLibrary.simpleMessage("Szczegóły"),
        "discount": MessageLookupByLibrary.simpleMessage("Rabat"),
        "doNotDistrub":
            MessageLookupByLibrary.simpleMessage("Nie przeszkadzać"),
        "done": MessageLookupByLibrary.simpleMessage("Zrobione"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Pobierz format Excel"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Pobrano pomyślnie do folderu pobierania"),
        "due": MessageLookupByLibrary.simpleMessage("Zaległość"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Kwota zaległości: "),
        "dueCollection":
            MessageLookupByLibrary.simpleMessage("Odbiór zaległości"),
        "dueCollectionReports": MessageLookupByLibrary.simpleMessage(
            "Raporty o zbieraniu należności"),
        "dueList": MessageLookupByLibrary.simpleMessage("Lista zaległości"),
        "dueReports": MessageLookupByLibrary.simpleMessage("Raport zaległości"),
        "duration": MessageLookupByLibrary.simpleMessage("Czas trwania"),
        "durationFrom":
            MessageLookupByLibrary.simpleMessage("Czas trwania: Od"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "Prosta w użyciu mobilna kasa"),
        "edit": MessageLookupByLibrary.simpleMessage("Edytuj"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Edytuj fakturę zakupu"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Edytuj fakturę sprzedaży"),
        "editSocailMedia": MessageLookupByLibrary.simpleMessage(
            "Edytuj media społecznościowe"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Edytowano pomyślnie"),
        "editTax": MessageLookupByLibrary.simpleMessage("Edytuj podatek"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Edytuj grupę podatkową"),
        "editWarehouse": MessageLookupByLibrary.simpleMessage("Edytuj magazyn"),
        "email": MessageLookupByLibrary.simpleMessage("E-mail"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("Adres e-mail"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Email nie może być pusty"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "E-mail wysłany! Sprawdź swoją skrzynkę odbiorczą"),
        "endDate": MessageLookupByLibrary.simpleMessage("Data zakończenia"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Wprowadź prawidłową kwotę"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Wprowadź ważny rabat"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Wprowadź prawidłowy numer telefonu"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Wprowadź ważną cenę"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("Wprowadź ważną ilość"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("Wprowadź adres"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("Wprowadź kwotę."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Wprowadź nazwę marki"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Wprowadź pojemność"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Wprowadź nazwę kategorii"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Wprowadź kolor"),
        "enterCustomerGstNumber":
            MessageLookupByLibrary.simpleMessage("Wprowadź numer GST klienta"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Wprowadź cenę dla dealerów"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Wprowadź opis"),
        "enterDiscount": MessageLookupByLibrary.simpleMessage("Wprowadź rabat"),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Wprowadź datę wydatku"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Wprowadź pełny adres"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Wprowadź numer faktury"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Wprowadź ilość alertu niskiego stanu"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Wprowadź producenta"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("Wprowadź treść wiadomości"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "Wprowadź MRP / Cenę detaliczną"),
        "enterName": MessageLookupByLibrary.simpleMessage("Wprowadź nazwę"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Wprowadź notatkę"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Wprowadź nazwę strony"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Wprowadź numer telefonu"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Wprowadź kod produktu lub zeskanuj"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Wprowadź nazwę produktu"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Wprowadź cenę zakupu"),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("Wprowadź numer referencyjny"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Wprowadź rozmiar"),
        "enterStocks":
            MessageLookupByLibrary.simpleMessage("Wprowadź ilość zapasów"),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Wprowadź stawkę podatkową"),
        "enterTransactionId": MessageLookupByLibrary.simpleMessage(
            "Wprowadź identyfikator transakcji"),
        "enterType": MessageLookupByLibrary.simpleMessage("Wprowadź typ"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("Wprowadź tytuł użytkownika"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Wprowadź prawidłową kwotę"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Wprowadź nazwę magazynu"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Wprowadź wagę"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Wprowadź cenę hurtową"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("Wprowadź opis tutaj"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("Wprowadź swój adres e-mail"),
        "enterYourFeedBackTitle":
            MessageLookupByLibrary.simpleMessage("Wprowadź tytuł opinii"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Wprowadź swój numer GST"),
        "enterYourMobileNumber": MessageLookupByLibrary.simpleMessage(
            "Wprowadź swój numer telefonu komórkowego"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Wprowadź swoje imię"),
        "enterYourNumber": MessageLookupByLibrary.simpleMessage(
            "Wprowadź swój numer telefonu"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Wprowadź swoje hasło"),
        "enterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Wprowadź swój numer telefonu"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "Wprowadź identyfikator transakcji"),
        "error": MessageLookupByLibrary.simpleMessage("Błąd"),
        "excTax": MessageLookupByLibrary.simpleMessage("Bez podatku"),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("Przesyłanie plików Excel"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Wyłączone"),
        "expense": MessageLookupByLibrary.simpleMessage("Wydatek"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Kategoria wydatków"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Data wydatku"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Wydatek na"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Raport wydatków"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Data wygaśnięcia"),
        "expired": MessageLookupByLibrary.simpleMessage("Wygasło"),
        "expiring": MessageLookupByLibrary.simpleMessage("Wygasa"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Niepowodzenie z błędem"),
        "fashion": MessageLookupByLibrary.simpleMessage("Moda"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Funkcje stanowią ważną część, która odróżnia Pos Saas od tradycyjnych rozwiązań."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Opinia"),
        "firstName": MessageLookupByLibrary.simpleMessage("Imię"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Śledź nas na\\nFacebooku"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Śledź nas na\\nTwitterze"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Strona przednia"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("Dla nieograniczonego użytku"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Zapomniałeś hasła"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Zapomniałeś hasła?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Od daty"),
        "freeDataBackup": MessageLookupByLibrary.simpleMessage(
            "Bezpłatna kopia zapasowa danych"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "Bezpłatna aktualizacja na całe życie"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Paczka darmowa"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Plan darmowy"),
        "from": MessageLookupByLibrary.simpleMessage("(Od"),
        "fullyPaid":
            MessageLookupByLibrary.simpleMessage("Całkowicie opłacone"),
        "gallary": MessageLookupByLibrary.simpleMessage("Galeria"),
        "generatingPDF":
            MessageLookupByLibrary.simpleMessage("Generowanie PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Otrzymaj kod OTP"),
        "govermentId": MessageLookupByLibrary.simpleMessage("Dowód tożsamości"),
        "guest": MessageLookupByLibrary.simpleMessage("Gość"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Nie masz jeszcze konta?"),
        "history": MessageLookupByLibrary.simpleMessage("Historia"),
        "home": MessageLookupByLibrary.simpleMessage("Strona główna"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Jak chronimy Twoje informacje"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Jak wykorzystujemy Twoje informacje"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Zweryfikuj tożsamość"),
        "image": MessageLookupByLibrary.simpleMessage("Obraz"),
        "inHouseCantBeDelete": MessageLookupByLibrary.simpleMessage(
            "Wewnętrzny nie może być usunięty"),
        "inHouseCantBeEdited": MessageLookupByLibrary.simpleMessage(
            "Wewnętrzny nie może być edytowany"),
        "inWord": MessageLookupByLibrary.simpleMessage("Słownie"),
        "incTax": MessageLookupByLibrary.simpleMessage("Z podatkiem"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Wliczone"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("Zwiększ zapas"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Instrument"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Nr faktury"),
        "invoice": MessageLookupByLibrary.simpleMessage("Faktura"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("Numer faktury"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Ustawienia faktury"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Przeglądarka faktur"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Element dodany"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("Weryfikacja KYC"),
        "language": MessageLookupByLibrary.simpleMessage("Język"),
        "lastName": MessageLookupByLibrary.simpleMessage("Nazwisko"),
        "ledger": MessageLookupByLibrary.simpleMessage("Księga główna"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Zakup na całe życie"),
        "link": MessageLookupByLibrary.simpleMessage("Link"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Wsparcie na czacie na żywo"),
        "loading": MessageLookupByLibrary.simpleMessage("Ładowanie"),
        "logIn": MessageLookupByLibrary.simpleMessage("Zaloguj się"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Wyloguj się"),
        "logOut": MessageLookupByLibrary.simpleMessage("Wyloguj się"),
        "login": MessageLookupByLibrary.simpleMessage("Zaloguj się"),
        "logo": MessageLookupByLibrary.simpleMessage("Logo"),
        "loss": MessageLookupByLibrary.simpleMessage("Strata"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Strata/Profit"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Szczegóły straty/profitu"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Raport strat/zysków"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Raporty strat/zysków"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Alert niskiego stanu"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Zostaw trwałe wrażenie na swoich klientach dzięki spersonalizowanym fakturom. Nasza nieograniczona aktualizacja oferuje unikalną zaletę dostosowywania swoich faktur, dodając profesjonalny akcent, który wzmacnia tożsamość Twojej marki i sprzyja lojalności klientów."),
        "manageYourBussinessWith": MessageLookupByLibrary.simpleMessage(
            "Zarządzaj swoim biznesem za pomocą"),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Data produkcji"),
        "margin": MessageLookupByLibrary.simpleMessage("Marża"),
        "masterCard": MessageLookupByLibrary.simpleMessage("Karta Mastercard"),
        "message": MessageLookupByLibrary.simpleMessage("Wiadomość"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Historia wiadomości"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Aplikacja Pos Saas jest darmowa i łatwa w użyciu. W rzeczywistości jest jednym z najlepszych systemów POS na świecie."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas to kompleksowe rozwiązanie biznesowe z zapasami, kontami, sprzedażą, wydatkami i stratami/zyskami."),
        "mobile": MessageLookupByLibrary.simpleMessage("Mobilny"),
        "mobilePayment":
            MessageLookupByLibrary.simpleMessage("Płatność mobilna"),
        "monthly": MessageLookupByLibrary.simpleMessage("Miesięcznie"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("Więcej informacji"),
        "name": MessageLookupByLibrary.simpleMessage("Wprowadź swoje imię."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Nazwa już istnieje"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("Nazwa nie może być pusta"),
        "next": MessageLookupByLibrary.simpleMessage("Następny"),
        "noConnection": MessageLookupByLibrary.simpleMessage("Brak połączenia"),
        "noData": MessageLookupByLibrary.simpleMessage("Brak danych"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Brak dostępnych danych"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Nie znaleziono danych"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("Nie znaleziono historii!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Nie znaleziono produktu"),
        "noSubTaxSelected": MessageLookupByLibrary.simpleMessage(
            "Nie wybrano podatku podrzędnego"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("Nie znaleziono transakcji!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Nie znaleziono użytkownika o podanym adresie e-mail."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "Nie znaleziono roli użytkownika"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Nieaktywny użytkownik"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Nie podano"),
        "note": MessageLookupByLibrary.simpleMessage("Notatka"),
        "notes": MessageLookupByLibrary.simpleMessage("notatki"),
        "notification": MessageLookupByLibrary.simpleMessage("Powiadomienie"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP wysłano na"),
        "office": MessageLookupByLibrary.simpleMessage("Biuro"),
        "ok": MessageLookupByLibrary.simpleMessage("Ok"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "System POS zawiera wiele funkcji, w tym śledzenie sprzedaży i zarządzanie zapasami."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Ten system pomaga Ci poprawić operacje dla Twoich klientów."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Nasz system POS powinien automatycznie upraszczać codzienne operacje, ułatwiając nawigację."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("Saldo otwarcia"),
        "order": MessageLookupByLibrary.simpleMessage("Zamówienia"),
        "other": MessageLookupByLibrary.simpleMessage("Inne"),
        "otp": MessageLookupByLibrary.simpleMessage("Zamknij"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Brak na stanie"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Pakiet"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Funkcje paczki"),
        "paid": MessageLookupByLibrary.simpleMessage("Zapłacone"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Zapłacona kwota"),
        "parties": MessageLookupByLibrary.simpleMessage("Strony"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Lista stron"),
        "partyGST": MessageLookupByLibrary.simpleMessage("GST strony"),
        "partyName": MessageLookupByLibrary.simpleMessage("Nazwa strony"),
        "password": MessageLookupByLibrary.simpleMessage("Hasło"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Hasło i potwierdzenie hasła nie pasują"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Hasło nie może być puste"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("Hasło się nie zgadza"),
        "payCash": MessageLookupByLibrary.simpleMessage("Płatność gotówką"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("Zapłać za pomocą bkash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Zapłać za pomocą PayPal"),
        "payeeName": MessageLookupByLibrary.simpleMessage("Nazwa odbiorcy"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("Numer odbiorcy"),
        "payment": MessageLookupByLibrary.simpleMessage("Płatność"),
        "paymentAmount":
            MessageLookupByLibrary.simpleMessage("Kwota płatności"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Płatność zakończona"),
        "paymentInstructions": MessageLookupByLibrary.simpleMessage(
            "Instrukcje dotyczące płatności:"),
        "paymentMethod":
            MessageLookupByLibrary.simpleMessage("Metoda płatności"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Typ płatności"),
        "pdfView": MessageLookupByLibrary.simpleMessage("Widok PDF"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Informacje osobiste"),
        "phone": MessageLookupByLibrary.simpleMessage("Telefon"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Numer telefonu"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Numer telefonu jest już używany"),
        "phoneNumberIsNotValid": MessageLookupByLibrary.simpleMessage(
            "Numer telefonu jest nieprawidłowy"),
        "phoneNumberIsRequired": MessageLookupByLibrary.simpleMessage(
            "Numer telefonu jest wymagany"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("Wybierz i przesyłaj plik"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("Wybierz datę zakończenia"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Wybierz datę rozpoczęcia"),
        "plan": MessageLookupByLibrary.simpleMessage("Plan"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("Proszę dodać ilość"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Proszę sprawdzić połączenie internetowe"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Proszę najpierw podłączyć drukarkę"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Proszę wprowadzić dłuższe hasło"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Proszę wprowadzić potwierdzenie hasła"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("Proszę wprowadzić hasło"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Proszę wprowadzić prawidłowy adres email"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Proszę wprowadzić nazwę"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("Proszę wprowadzić hasło"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Proszę wprowadzić poniżej swój adres e-mail, aby otrzymać odnośnik do resetowania hasła."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Proszę wprowadzić numer transakcji"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("Proszę wprowadzić kwotę"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Proszę najpierw wybrać kategorię"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("Proszę wybrać plan"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Proszę wybrać kategorię biznesową"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Proszę użyć ważnego kodu zakupu, aby korzystać z aplikacji"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Napędzane przez Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Zasilane przez"),
        "premiumCustomerSupport": MessageLookupByLibrary.simpleMessage(
            "Wsparcie premium dla klientów"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Plan premium"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Poprzednie kwoty płatności"),
        "price": MessageLookupByLibrary.simpleMessage("Cena"),
        "print": MessageLookupByLibrary.simpleMessage("Drukuj"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Opcje drukowania"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Polityka prywatności"),
        "product": MessageLookupByLibrary.simpleMessage("Produkt"),
        "productCode": MessageLookupByLibrary.simpleMessage("Kod produktu"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("Kod produktu jest wymagany"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Kod/Nazwa produktu"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Opis produktu"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Szczegóły produktu"),
        "productList": MessageLookupByLibrary.simpleMessage("Lista produktów"),
        "productName": MessageLookupByLibrary.simpleMessage("Nazwa produktu"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Nazwa produktu już istnieje w tym magazynie"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Nazwa produktu jest już dodana"),
        "productNameIsRequired": MessageLookupByLibrary.simpleMessage(
            "Nazwa produktu jest wymagana"),
        "products": MessageLookupByLibrary.simpleMessage("Produkty"),
        "profile": MessageLookupByLibrary.simpleMessage("Profil"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("Edycja profilu"),
        "profit": MessageLookupByLibrary.simpleMessage("Profit"),
        "promo": MessageLookupByLibrary.simpleMessage("Promocja"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Kod promocyjny"),
        "purchase": MessageLookupByLibrary.simpleMessage("Zakup"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage("Alarm zakupu"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Zakup potwierdzony"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Szczegóły zakupu"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Faktura zakupu"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("Lista zakupów"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Kup teraz"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Kup plan premium"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("Cena zakupu"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("Cena zakupu jest wymagana"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Raport zakupów"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Raporty zakupów"),
        "purchaseReturn": MessageLookupByLibrary.simpleMessage("Zwrot zakupu"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("Raport zwrotu zakupu"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Transakcja zakupu"),
        "qty": MessageLookupByLibrary.simpleMessage("Ilość"),
        "quantity": MessageLookupByLibrary.simpleMessage("Ilość"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Ostatnie transakcje"),
        "recivedThePin": MessageLookupByLibrary.simpleMessage("Otrzymano PIN"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Numer referencyjny"),
        "register": MessageLookupByLibrary.simpleMessage("Zarejestruj się"),
        "registering": MessageLookupByLibrary.simpleMessage("Rejestrowanie"),
        "remainingDue":
            MessageLookupByLibrary.simpleMessage("Należność pozostała"),
        "remove": MessageLookupByLibrary.simpleMessage("Usuń"),
        "reports": MessageLookupByLibrary.simpleMessage("Raporty"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Wniosek został wysłany"),
        "resendCode":
            MessageLookupByLibrary.simpleMessage("Wyślij kod ponownie"),
        "resendOtp":
            MessageLookupByLibrary.simpleMessage("Wyślij ponownie kod OTP: "),
        "retailer": MessageLookupByLibrary.simpleMessage("Detalista"),
        "retur": MessageLookupByLibrary.simpleMessage("Zwrot"),
        "returN": MessageLookupByLibrary.simpleMessage("Zwrot"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("Kwota zwrotu"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("Ilość zwrotów"),
        "revenue": MessageLookupByLibrary.simpleMessage("Dochód"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Ochron swoje dane biznesowe w prosty sposób. Nasza nieograniczona aktualizacja Pos Saas POS obejmuje bezpłatną kopię zapasową danych, zapewniając ochronę Twoich cennych informacji przed nieprzewidywalnymi zdarzeniami. Skup się na tym, co naprawdę ma znaczenie - wzrostie Twojego biznesu."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Kwota sprzedaży"),
        "saleDetails":
            MessageLookupByLibrary.simpleMessage("Szczegóły sprzedaży"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Cena sprzedaży"),
        "saleReports": MessageLookupByLibrary.simpleMessage("Raport sprzedaży"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Raporty sprzedaży"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("Zwrot sprzedaży"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Raport zwrotu sprzedaży"),
        "saleSetting":
            MessageLookupByLibrary.simpleMessage("Ustawienia sprzedaży"),
        "sales": MessageLookupByLibrary.simpleMessage("Sprzedaż"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("Raporty sprzedaży i zakupów"),
        "salesList": MessageLookupByLibrary.simpleMessage("Lista sprzedaży"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("Zwrot sprzedaży"),
        "save": MessageLookupByLibrary.simpleMessage("Zapisz"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Zapisz i opublikuj"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("Zapisz zmiany"),
        "saving": MessageLookupByLibrary.simpleMessage("Zapisywanie"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("Skanuj kod QR produktu"),
        "search": MessageLookupByLibrary.simpleMessage("Szukaj"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Szukaj według kodu lub nazwy produktu"),
        "seeAllPromoCode": MessageLookupByLibrary.simpleMessage(
            "Zobacz wszystkie kody promocyjne"),
        "select": MessageLookupByLibrary.simpleMessage("Wybierz"),
        "selectAProductForReturn":
            MessageLookupByLibrary.simpleMessage("Wybierz produkt do zwrotu"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Wybierz markę"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Wybierz kategorię"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Wybierz kontakty"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("Wybierz kategorię produktu"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("Wybierz kategorię sklepu"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Wybierz podatek"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Wybierz rodzaj podatku"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("Wybierz jednostkę"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Wybierz wariację: "),
        "seller": MessageLookupByLibrary.simpleMessage("Sprzedawca"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Sprzedawane przez"),
        "send": MessageLookupByLibrary.simpleMessage("Wyślij"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("Wyślij e-mail"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Wyślij wiadomość"),
        "sendResetLink": MessageLookupByLibrary.simpleMessage(
            "Wyślij odnośnik do resetowania"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Wyślij SMS"),
        "sendSmsw":
            MessageLookupByLibrary.simpleMessage("Wysłać wiadomość SMS?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Wyślij wiadomość WhatsApp"),
        "sendYOurEmail": MessageLookupByLibrary.simpleMessage(
            "Wyślij swoją wiadomość e-mail"),
        "sendingEmail":
            MessageLookupByLibrary.simpleMessage("Wysyłanie e-maila"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Wysyłanie wiadomości"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Usługa/Wysyłka"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Skonfiguruj swój profil"),
        "setting": MessageLookupByLibrary.simpleMessage("Ustawienia"),
        "share": MessageLookupByLibrary.simpleMessage("Udostępnij"),
        "shopGST": MessageLookupByLibrary.simpleMessage("GST sklepu"),
        "signIn": MessageLookupByLibrary.simpleMessage("Zaloguj się"),
        "signInWithEmail": MessageLookupByLibrary.simpleMessage(
            "Zaloguj się za pomocą emaila"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Podpis klienta"),
        "size": MessageLookupByLibrary.simpleMessage("Rozmiar"),
        "skip": MessageLookupByLibrary.simpleMessage("Pomiń"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Marketing społecznościowy"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Przepraszamy, nie masz uprawnień do dostępu do tej usługi"),
        "startDate": MessageLookupByLibrary.simpleMessage("Data rozpoczęcia"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Rozpocznij nową sprzedaż"),
        "startTypingToSearch":
            MessageLookupByLibrary.simpleMessage("Zacznij pisać, aby wyszukać"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Pozostań na czele postępu technologicznego bez dodatkowych kosztów. Nasza nieograniczona aktualizacja Pos Saas POS zapewnia, że zawsze masz dostęp do najnowszych narzędzi i funkcji, gwarantując, że Twoja firma pozostaje na czele innowacji."),
        "stillUnpaid":
            MessageLookupByLibrary.simpleMessage("Nadal nieopłacone"),
        "stock": MessageLookupByLibrary.simpleMessage("Stan"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Stan jest wymagany"),
        "stockList": MessageLookupByLibrary.simpleMessage("Lista zapasów"),
        "stocks": MessageLookupByLibrary.simpleMessage("Zapas"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Wymagana jest zgoda na przechowywanie, aby utworzyć plik Excel"),
        "subTaxList":
            MessageLookupByLibrary.simpleMessage("Lista podatków podrzędnych"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Podatki podrzędne"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Suma częściowa"),
        "submit": MessageLookupByLibrary.simpleMessage("Prześlij"),
        "subscribeToOurYoutube":
            MessageLookupByLibrary.simpleMessage("Subskrybuj nas na\\nYouTube"),
        "subscription": MessageLookupByLibrary.simpleMessage("Subskrypcja"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Zrealizowane pomyślnie"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Wylogowano pomyślnie"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Pomyślnie zaktualizowano"),
        "supplier": MessageLookupByLibrary.simpleMessage("Dostawca"),
        "supplierName": MessageLookupByLibrary.simpleMessage("Nazwa dostawcy"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("Kod SWIFT"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Weź prawo jazdy, dowód osobisty lub paszport"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "Weź dowód tożsamości, aby sprawdzić swoje informacje"),
        "tap": MessageLookupByLibrary.simpleMessage("Tap"),
        "tax": MessageLookupByLibrary.simpleMessage("Podatek"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Grupa podatkowa"),
        "taxPercentage":
            MessageLookupByLibrary.simpleMessage("Procent podatku"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Stawka podatkowa"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Stawki podatkowe - zarządzaj swoimi stawkami podatkowymi"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Raport podatkowy"),
        "taxType": MessageLookupByLibrary.simpleMessage("Rodzaj podatku"),
        "taxes": MessageLookupByLibrary.simpleMessage("Podatki"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Warunki i zasady"),
        "termsOfUse":
            MessageLookupByLibrary.simpleMessage("Warunki korzystania"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Warunki i prywatność"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Dziękujemy za dokonanie płatności"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Dziękuję"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Dziękujemy za zakup"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "Konto już istnieje dla tego adresu e-mail"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Plik Excel został już pobrany"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Nazwa mówi sama za siebie. Dzięki Pos Saas POS Unlimited nie ma ograniczeń w użyciu. Bez względu na to, czy przetwarzasz kilka transakcji, czy masz dużo klientów, możesz działać z pewnością, wiedząc, że nie masz ograniczeń."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "Podane hasło jest zbyt słabe"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Sprzedaż zostanie usunięta, a wszystkie dane dotyczące tego zakupu również. Czy na pewno chcesz to usunąć?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Sprzedaż zostanie usunięta, a wszystkie dane dotyczące tej sprzedaży również. Czy na pewno chcesz to usunąć?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Użytkownik zostanie usunięty, a wszystkie dane zostaną usunięte z twojego konta. Czy na pewno chcesz to usunąć?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Użytkownik zostanie usunięty, a wszystkie dane zostaną usunięte z Twojego konta. Czy na pewno chcesz to usunąć?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Usługi osób trzecich"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Ta kategoria nie może być usunięta"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Ten miesiąc)"),
        "thisProductAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("Ten produkt już dodano"),
        "title": MessageLookupByLibrary.simpleMessage("Tytuł"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Tytuł nie może być pusty"),
        "to": MessageLookupByLibrary.simpleMessage("do"),
        "toDate": MessageLookupByLibrary.simpleMessage("Do daty"),
        "today": MessageLookupByLibrary.simpleMessage("Dziś"),
        "total": MessageLookupByLibrary.simpleMessage("Suma: "),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Całkowita kwota"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Całkowita zebrana kwota"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Całkowita należność"),
        "totalExpense":
            MessageLookupByLibrary.simpleMessage("Całkowity wydatek"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Całkowita strata"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("Całkowita kwota do zapłaty"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Całkowita cena"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("Łączna liczba produktów"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Całkowity zysk"),
        "totalPurchase":
            MessageLookupByLibrary.simpleMessage("Całkowity zakup"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Całkowita kwota zwrotu"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("Łączne zwroty"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Całkowita sprzedaż"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Łączne zapasy"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Całkowita wartość"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Całkowity VAT"),
        "transaction": MessageLookupByLibrary.simpleMessage("Transakcja"),
        "transactionId":
            MessageLookupByLibrary.simpleMessage("Identyfikator transakcji"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Spróbuj ponownie"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Typ"),
        "unitName": MessageLookupByLibrary.simpleMessage("Nazwa jednostki"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Cena jednostkowa"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Cena jednostkowa"),
        "units": MessageLookupByLibrary.simpleMessage("Jednostki"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Nieograniczone"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Nielimitowane użycie"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Odblokuj pełny potencjał Pos Saas POS dzięki spersonalizowanym sesjom szkoleniowym prowadzonym przez nasz zespół ekspertów. Od podstawowych do zaawansowanych technik zapewniamy, że opanujesz korzystanie z każdego aspektu systemu, aby zoptymalizować procesy biznesowe."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Nieopłacone"),
        "update": MessageLookupByLibrary.simpleMessage("Aktualizuj"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Aktualizuj kontakt"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Zaktualizuj teraz"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("Aktualizuj produkt"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Zaktualizuj swój plan,\\n Twój limit został przekroczony"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Zaktualizuj swój profil"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Zaktualizuj swój profil, aby lekarz mógł się z Tobą lepiej skontaktować"),
        "updated": MessageLookupByLibrary.simpleMessage("Zaktualizowane"),
        "upload": MessageLookupByLibrary.simpleMessage("Prześlij"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Prześlij dokument"),
        "uploadDone":
            MessageLookupByLibrary.simpleMessage("Przesyłanie zakończone"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Prześlij plik"),
        "usbC": MessageLookupByLibrary.simpleMessage("Usb C"),
        "use": MessageLookupByLibrary.simpleMessage("Użyj"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("Użyj Pos Saas"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Korzystanie z systemu"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Użytkownik został usunięty"),
        "userRole": MessageLookupByLibrary.simpleMessage("Rola użytkownika"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("Szczegóły roli użytkownika"),
        "userTitle": MessageLookupByLibrary.simpleMessage("Tytuł użytkownika"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Tytuł użytkownika nie może być pusty"),
        "value": MessageLookupByLibrary.simpleMessage("Wartość"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("VAT nie dotyczy"),
        "verifyOtp":
            MessageLookupByLibrary.simpleMessage("Weryfikacja kodu OTP"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Zweryfikuj numer telefonu"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Pokaż wszystko"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("Pokaż szczegóły"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Klient bez umówienia"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Magazyn"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Magazyn już istnieje"),
        "warehouseList":
            MessageLookupByLibrary.simpleMessage("Lista magazynów"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("Nazwa magazynu"),
        "warranty": MessageLookupByLibrary.simpleMessage("Gwarancja"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Wysłaliśmy e-maila z instrukcjami dotyczącymi resetowania hasła na:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Możemy korzystać z usług osób trzecich w celu wsparcia funkcjonalności naszej aplikacji, takich jak dostawcy analiz i procesorzy płatności. Te usługi osób trzecich mogą zbierać informacje o Tobie podczas korzystania z naszej aplikacji. Prosimy zauważyć, że nie ponosimy odpowiedzialności za praktyki prywatności tych usług osób trzecich."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Podjęliśmy standardowe środki w celu ochrony Twoich informacji osobistych, w tym szyfrowanie i bezpieczne przechowywanie. Ograniczamy również dostęp do Twoich informacji tylko dla upoważnionego personelu."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Rozumiemy znaczenie płynnego funkcjonowania. Dlatego nasze całodobowe wsparcie jest dostępne, aby pomóc Ci w szybkim zapytaniu lub bardziej szczegółowym problemie. Skontaktuj się z nami o dowolnej porze i w dowolnym miejscu, dzwoniąc lub korzystając z WhatsApp, aby doświadczyć niezrównanego obsługi klienta."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Wykorzystujemy Twoje informacje osobiste, aby zapewnić Ci najlepsze możliwe doświadczenie w naszej aplikacji, w tym personalizację rekomendacji treści, łączenie Cię z ekspertami i poprawę funkcjonalności naszej aplikacji. Możemy także wykorzystywać Twoje informacje do komunikowania się z Tobą w sprawie aktualizacji, promocji lub innych informacji związanych z naszą aplikacją."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Przejrzymy płatność i zatwierdzimy ją w ciągu 1-2 godzin"),
        "weekly": MessageLookupByLibrary.simpleMessage("Tygodniowo"),
        "weight": MessageLookupByLibrary.simpleMessage("Waga"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Co nowego"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Hurtownik"),
        "wholeSalePrice": MessageLookupByLibrary.simpleMessage("Cena hurtowa"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("Cena hurtowa"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Hurtownik"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Wkrótce zostanie dodany"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Wygasa o"),
        "writeYourMessageHere": MessageLookupByLibrary.simpleMessage(
            "Napisz swoją wiadomość tutaj"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("Błędny OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Podano nieprawidłowe hasło dla tego użytkownika."),
        "yearly": MessageLookupByLibrary.simpleMessage("Rocznie"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Tak, usuń na zawsze"),
        "youAreNotAValidUser": MessageLookupByLibrary.simpleMessage(
            "Nie jesteś ważnym użytkownikiem"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Korzystasz z"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Nie możesz zapłacić więcej niż wymagana kwota"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Otrzymałeś(eś) e-maila"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Pomyślnie zalogowałeś się na swoje konto. Zostań z Pos Saas ."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("Musisz udzielić zgody"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Musisz ZALOGOWAĆ się ponownie na swoje konto."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Musisz zweryfikować swoją tożsamość przed zakupem SMS"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Twoja wiadomość pozostaje"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Twoja paczka"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Twoja paczka wygaśnie za 5 dni")
      };
}
