# salespro_saas_admin

A new Flutter project.

## Getting Started


Flutter Update:

Flutter Update LastDate : 14 Nov 2024
Flutter Version : 3.24.5
Dart version : 3.5.4






This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://docs.flutter.dev/cookbook)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
