// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a uk locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'uk';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Продовжити"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("Номер GST"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired": MessageLookupByLibrary.simpleMessage(
            "Ціна виробника є обов\'язковою"),
        "OK": MessageLookupByLibrary.simpleMessage("ОК"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Тел. номер"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("СЛ"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT Код"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Закуски"),
        "TAX": MessageLookupByLibrary.simpleMessage("ПОДАТОК"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Завантаження"),
        "UserTitle":
            MessageLookupByLibrary.simpleMessage("Заголовок користувача"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Термін дії вашого пакету закінчується сьогодні\n\nБудь ласка, придбайте ще раз"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) Система надається виключно з метою сприяння операціям з продажу та пов\'язаним діяльностям у вашому бізнесі."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) Для використання Системи вам може бути потрібно створити обліковий запис. Ви погоджуєтеся надавати точну, поточну та повну інформацію під час процесу реєстрації та оновлювати таку інформацію для збереження її актуальною та повною."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("Про додаток"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Про нас"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Прийняття умов"),
        "accountName": MessageLookupByLibrary.simpleMessage("Назва рахунку"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("Номер рахунку"),
        "accountRegistration": MessageLookupByLibrary.simpleMessage(
            "Реєстрація облікового запису"),
        "acton": MessageLookupByLibrary.simpleMessage("Дія"),
        "add": MessageLookupByLibrary.simpleMessage("Додати"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Додати бренд"),
        "addCategory": MessageLookupByLibrary.simpleMessage("Додати категорію"),
        "addContact": MessageLookupByLibrary.simpleMessage("Додати контакт"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Додати клієнта"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("Додати доставку"),
        "addDescriptioN": MessageLookupByLibrary.simpleMessage("Додати опис"),
        "addDescription":
            MessageLookupByLibrary.simpleMessage("Додати примітку"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Додати знижку"),
        "addDocumentId": MessageLookupByLibrary.simpleMessage(
            "Додати ідентифікаційний документ"),
        "addDucument": MessageLookupByLibrary.simpleMessage("Додати документ"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Додати витрати"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Додати категорію витрат"),
        "addItems": MessageLookupByLibrary.simpleMessage("Додати товари"),
        "addNew": MessageLookupByLibrary.simpleMessage("Додати новий"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Додати нову адресу"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Додати новий товар"),
        "addNewTax":
            MessageLookupByLibrary.simpleMessage("Додати новий податок"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Додати новий податок з одиничним/багатократним типом податку"),
        "addNote": MessageLookupByLibrary.simpleMessage("Додати примітку"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Спочатку додайте продукт"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Додати промо-код"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Додати закупівлю"),
        "addSales": MessageLookupByLibrary.simpleMessage("Додати продаж"),
        "addSuccessful": MessageLookupByLibrary.simpleMessage("Додано успішно"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Додати одиницю"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Додати роль користувача"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Успішно додано"),
        "addedToCart": MessageLookupByLibrary.simpleMessage("Додано до кошика"),
        "address": MessageLookupByLibrary.simpleMessage("Адреса"),
        "admin": MessageLookupByLibrary.simpleMessage("Адміністратор"),
        "all": MessageLookupByLibrary.simpleMessage("Усі"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("Всі бізнес-рішення"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("Вже додано"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Вже існує"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Вже маєте обліковий запис"),
        "amount": MessageLookupByLibrary.simpleMessage("Сума"),
        "anEmailHasBeenSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "На вашу електронну пошту надіслано лист. Перевірте свій вхідний ящик."),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Підтримка додатків для Android і iOS"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Застосовуваний податок"),
        "apply": MessageLookupByLibrary.simpleMessage("Застосувати"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Ви впевнені, що хочете видалити цей рахунок?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Ви впевнені, що хочете видалити цей продаж?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Ви впевнені, що хочете видалити цього користувача?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Ви впевнені, що хочете видалити цей податок?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Ви впевнені, що хочете видалити цю групу податків?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Ви впевнені, що хочете видалити цей склад?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Ви впевнені, що хочете видалити цього користувача?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Уповноважений підпис"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Ви несете відповідальність за збереження конфіденційності вашого облікового запису та пароля та обмеження доступу до вашого облікового запису. Ви приймаєте на себе відповідальність за всі дії, які відбуваються в рамках вашого облікового запису."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Вам має бути принаймні 18 років або досягнутий законний вік більшості в вашому юрисдикційному області, щоб використовувати Систему."),
        "backSide": MessageLookupByLibrary.simpleMessage("Задня сторона"),
        "backToHome":
            MessageLookupByLibrary.simpleMessage("Повернутися додому"),
        "balance": MessageLookupByLibrary.simpleMessage("Баланс"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Бангладеш"),
        "bank": MessageLookupByLibrary.simpleMessage("Банк"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Валюта банківського рахунку"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Валюта банківського рахунку"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Банківська інформація"),
        "bankName": MessageLookupByLibrary.simpleMessage("Назва банку"),
        "bankTransfer":
            MessageLookupByLibrary.simpleMessage("Банківський переказ"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Штрих-код знайдено"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Рахунок/Фактура"),
        "billTo": MessageLookupByLibrary.simpleMessage("Виставити рахунок"),
        "branchName": MessageLookupByLibrary.simpleMessage("Назва відділення"),
        "brand": MessageLookupByLibrary.simpleMessage("Бренд"),
        "brandName": MessageLookupByLibrary.simpleMessage("Назва бренду"),
        "bulkUpload":
            MessageLookupByLibrary.simpleMessage("Масове\nзавантаження"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Категорія бізнесу"),
        "buy": MessageLookupByLibrary.simpleMessage("Купити"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Купити преміум план"),
        "buySms": MessageLookupByLibrary.simpleMessage("Купити SMS"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Звертаючись до або використовуючи систему точки продажів (POS) (\"Система\"), надану [Назва вашої компанії] (\"Компанія\"), ви погоджуєтеся дотримуватися цих Умов використання. Якщо ви не згодні з цими Умовами використання, не використовуйте Систему."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Ви несете відповідальність за забезпечення того, щоб ваш доступ та використання Системи відповідали всім чинним законам і нормативам."),
        "call": MessageLookupByLibrary.simpleMessage("Виклик"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "Телефонуйте для екстреної підтримки"),
        "camera": MessageLookupByLibrary.simpleMessage("Камера"),
        "cancel": MessageLookupByLibrary.simpleMessage("Скасувати"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Скасувати всі продукти"),
        "capacity": MessageLookupByLibrary.simpleMessage("Ємність"),
        "card": MessageLookupByLibrary.simpleMessage("Картка"),
        "cash": MessageLookupByLibrary.simpleMessage("Готівка"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Категорії"),
        "category": MessageLookupByLibrary.simpleMessage("Категорія"),
        "categoryName": MessageLookupByLibrary.simpleMessage("Назва категорії"),
        "categoryNameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Назва категорії вже існує"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("Назва категорії"),
        "change": MessageLookupByLibrary.simpleMessage("Змінити?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Змінити пароль"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("Перевірте пошту"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Виберіть клієнта"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Виберіть постачальника"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Виберіть ваші функції"),
        "clarence": MessageLookupByLibrary.simpleMessage("Клеренс"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Натисніть, щоб підключити"),
        "close": MessageLookupByLibrary.simpleMessage("Закрити"),
        "color": MessageLookupByLibrary.simpleMessage("Колір"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(Комбінація кількох податків)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Скоро"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Адреса компанії"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Назва компанії та магазину"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("Назва компанії та бізнесу"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Завершити транзакцію"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Підтвердити пароль"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Підтвердити повернення"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Вітаємо"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Зв\'яжіться з нами"),
        "continu": MessageLookupByLibrary.simpleMessage("Продовжити"),
        "country": MessageLookupByLibrary.simpleMessage("Країна"),
        "create": MessageLookupByLibrary.simpleMessage("Створити"),
        "createAFreeAccounts": MessageLookupByLibrary.simpleMessage(
            "Створити безкоштовний обліковий запис"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Створено та збережено"),
        "currency": MessageLookupByLibrary.simpleMessage("Валюта"),
        "currentStock": MessageLookupByLibrary.simpleMessage("Поточний запас"),
        "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
            "Настройка брендування рахунків"),
        "customer": MessageLookupByLibrary.simpleMessage("Клієнт"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Деталі клієнта"),
        "customerGST": MessageLookupByLibrary.simpleMessage("GST клієнта"),
        "customerName": MessageLookupByLibrary.simpleMessage("Ім\'я клієнта"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Щоденна транзакція"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Огляд інформаційної панелі"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Дані успішно збережено"),
        "date": MessageLookupByLibrary.simpleMessage("Дата"),
        "day": MessageLookupByLibrary.simpleMessage("День"),
        "dealer": MessageLookupByLibrary.simpleMessage("Дилер"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("Ціна дилера"),
        "defaultVATPercentage": MessageLookupByLibrary.simpleMessage(
            "Відсоток ПДВ за замовчуванням"),
        "delete": MessageLookupByLibrary.simpleMessage("Видалити"),
        "deleting": MessageLookupByLibrary.simpleMessage("Видалення"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Адреса доставки"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Адреси доставки"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Вартість доставки"),
        "describtion": MessageLookupByLibrary.simpleMessage("Опис"),
        "description": MessageLookupByLibrary.simpleMessage("Опис"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Опис не може бути пустим"),
        "details": MessageLookupByLibrary.simpleMessage("Деталі"),
        "discount": MessageLookupByLibrary.simpleMessage("Знижка"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Не турбувати"),
        "done": MessageLookupByLibrary.simpleMessage("Готово"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Завантажити формат Excel"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Успішно завантажено в папку завантажень"),
        "due": MessageLookupByLibrary.simpleMessage("Заборгованість"),
        "dueAmount":
            MessageLookupByLibrary.simpleMessage("Сума заборгованості: "),
        "dueCollection":
            MessageLookupByLibrary.simpleMessage("Збір заборгованостей"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("Звіти про сплату боргів"),
        "dueList":
            MessageLookupByLibrary.simpleMessage("Список заборгованостей"),
        "dueReports":
            MessageLookupByLibrary.simpleMessage("Звіт про заборгованість"),
        "duration": MessageLookupByLibrary.simpleMessage("Тривалість"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Тривалість: Від"),
        "easyToUseMobilePos":
            MessageLookupByLibrary.simpleMessage("Зручний мобільний POS"),
        "edit": MessageLookupByLibrary.simpleMessage("Редагувати"),
        "editPurchaseInvoice": MessageLookupByLibrary.simpleMessage(
            "Редагувати рахунок на закупівлю"),
        "editSalesInvoice": MessageLookupByLibrary.simpleMessage(
            "Редагувати рахунок на продажі"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Редагувати соціальні медіа"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Успішно відредаговано"),
        "editTax": MessageLookupByLibrary.simpleMessage("Редагувати податок"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Редагувати групу податків"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("Редагувати склад"),
        "email": MessageLookupByLibrary.simpleMessage("Електронна пошта"),
        "emailAddress":
            MessageLookupByLibrary.simpleMessage("Адреса електронної пошти"),
        "emailCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Електронна пошта не може бути порожньою"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "Електронну пошту надіслано! Перевірте ваш вхідний ящик"),
        "endDate": MessageLookupByLibrary.simpleMessage("Дата закінчення"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Введіть дійсну суму"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Введіть дійсну знижку"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Введіть дійсний номер телефону"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Введіть дійсну ціну"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("Введіть дійсну кількість"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("Введіть адресу"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("Введіть суму"),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Введіть назву бренду"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Введіть ємність"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Введіть назву категорії"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Введіть колір"),
        "enterCustomerGstNumber":
            MessageLookupByLibrary.simpleMessage("Введіть номер GST клієнта"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Введіть ціну дилера"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Введіть опис"),
        "enterDiscount": MessageLookupByLibrary.simpleMessage("Введіть знижку"),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Введіть дату витрат"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Введіть повну адресу"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Введіть номер рахунку"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Введіть кількість для оповіщення про низький запас"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Введіть виробника"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("Введіть вміст повідомлення"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "Введіть MRP / Ціну роздрібної торгівлі"),
        "enterName": MessageLookupByLibrary.simpleMessage("Введіть ім\'я"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Введіть примітку"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Введіть назву сторони"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Введіть номер телефону"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Введіть код товару або відскануйте"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Введіть назву товару"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Введіть ціну закупівлі"),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("Введіть референційний номер"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Введіть розмір"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("Введіть запаси"),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Введіть податкову ставку"),
        "enterTransactionId": MessageLookupByLibrary.simpleMessage(
            "Введіть ідентифікатор транзакції"),
        "enterType": MessageLookupByLibrary.simpleMessage("Введіть тип"),
        "enterUserTitle": MessageLookupByLibrary.simpleMessage(
            "Введіть заголовок користувача"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Введіть дійсну суму"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Введіть назву складу"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Введіть вагу"),
        "enterWholeSalePrice": MessageLookupByLibrary.simpleMessage(
            "Введіть ціну оптового продажу"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("Введіть ваш опис тут"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "Введіть вашу адресу електронної пошти"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "Введіть заголовок вашого відгуку"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Введіть ваш номер GST"),
        "enterYourMobileNumber": MessageLookupByLibrary.simpleMessage(
            "Введіть свій номер мобільного телефону"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Введіть ваше ім\'я"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("Введіть номер телефону"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Введіть ваш пароль"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Введіть свій номер телефону"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "Введіть ідентифікатор вашої транзакції"),
        "error": MessageLookupByLibrary.simpleMessage("Помилка"),
        "excTax": MessageLookupByLibrary.simpleMessage("Без податку"),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("Завантажувач Excel"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Виключно"),
        "expense": MessageLookupByLibrary.simpleMessage("Витрати"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Категорія витрат"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Дата витрат"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Витрати на"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Звіт про витрати"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Дата закінчення"),
        "expired":
            MessageLookupByLibrary.simpleMessage("Термін дії закінчився"),
        "expiring":
            MessageLookupByLibrary.simpleMessage("Термін дії закінчується"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Сталася помилка"),
        "fashion": MessageLookupByLibrary.simpleMessage("Мода"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Функції є важливою частиною, яка відрізняє Pos Saas від традиційних рішень."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Відгук"),
        "firstName": MessageLookupByLibrary.simpleMessage("Ім\'я"),
        "followUsOnFacebook": MessageLookupByLibrary.simpleMessage(
            "Слідкуйте за нами на\\nFacebook"),
        "followUsOnTwitter": MessageLookupByLibrary.simpleMessage(
            "Слідкуйте за нами на\\nTwitter"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Передня сторона"),
        "forUnlimitedUses": MessageLookupByLibrary.simpleMessage(
            "Для необмеженого використання"),
        "forgotPassword": MessageLookupByLibrary.simpleMessage("Забули пароль"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Забули пароль?"),
        "formDate": MessageLookupByLibrary.simpleMessage("З дати"),
        "freeDataBackup": MessageLookupByLibrary.simpleMessage(
            "Безкоштовне резервне копіювання даних"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "Безкоштовне оновлення на все життя"),
        "freePacakge":
            MessageLookupByLibrary.simpleMessage("Безкоштовний пакет"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Безкоштовний план"),
        "from": MessageLookupByLibrary.simpleMessage("(Від"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Повністю сплачено"),
        "gallary": MessageLookupByLibrary.simpleMessage("Галерея"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("Генерація PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Отримати OTP"),
        "govermentId":
            MessageLookupByLibrary.simpleMessage("Документ державного зразка"),
        "guest": MessageLookupByLibrary.simpleMessage("Гість"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Немає облікового запису?"),
        "history": MessageLookupByLibrary.simpleMessage("Історія"),
        "home": MessageLookupByLibrary.simpleMessage("Головна"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Як ми захищаємо вашу інформацію"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Як ми використовуємо вашу інформацію"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Перевірка ідентичності"),
        "image": MessageLookupByLibrary.simpleMessage("Зображення"),
        "inHouseCantBeDelete": MessageLookupByLibrary.simpleMessage(
            "Внутрішній склад не можна видалити"),
        "inHouseCantBeEdited": MessageLookupByLibrary.simpleMessage(
            "Внутрішній склад не можна редагувати"),
        "inWord": MessageLookupByLibrary.simpleMessage("Словом"),
        "incTax": MessageLookupByLibrary.simpleMessage("З урахуванням податку"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Включно"),
        "increaseStock":
            MessageLookupByLibrary.simpleMessage("Збільшити запаси"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Інструмент"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("№ рахунку"),
        "invoice": MessageLookupByLibrary.simpleMessage("Рахунок"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("Номер рахунку"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Налаштування рахунку"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Переглядач рахунків"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Товар додано"),
        "kg": MessageLookupByLibrary.simpleMessage("кг"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("Підтвердження KYC"),
        "language": MessageLookupByLibrary.simpleMessage("Мова"),
        "lastName": MessageLookupByLibrary.simpleMessage("Прізвище"),
        "ledger": MessageLookupByLibrary.simpleMessage("Головна книга"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Пожизненна покупка"),
        "link": MessageLookupByLibrary.simpleMessage("Посилання"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport": MessageLookupByLibrary.simpleMessage(
            "Підтримка в чаті в реальному часі"),
        "loading": MessageLookupByLibrary.simpleMessage("Завантаження"),
        "logIn": MessageLookupByLibrary.simpleMessage("Увійти"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Вийти"),
        "logOut": MessageLookupByLibrary.simpleMessage("Вийти"),
        "login": MessageLookupByLibrary.simpleMessage("Увійти"),
        "logo": MessageLookupByLibrary.simpleMessage("Логотип"),
        "loss": MessageLookupByLibrary.simpleMessage("Збиток"),
        "lossOrProfit":
            MessageLookupByLibrary.simpleMessage("Збиток / Прибуток"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Деталі збитку / прибутку"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Звіт про збитки/прибутки"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Звіти про збитки/прибутки"),
        "lowStockAlert": MessageLookupByLibrary.simpleMessage(
            "Оповіщення про низький запас"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Залиште незабутнє враження на своїх клієнтах завдяки брендованим рахункам. Наша безмежна оновлення надає унікальну перевагу настроювання ваших рахунків, додаючи професійний штрих, який посилює вашу корпоративну ідентичність і сприяє лояльності клієнтів."),
        "manageYourBussinessWith": MessageLookupByLibrary.simpleMessage(
            "Управляйте своїм бізнесом за допомогою"),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Дата виробництва"),
        "margin": MessageLookupByLibrary.simpleMessage("Маржа"),
        "masterCard": MessageLookupByLibrary.simpleMessage("MasterCard"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Виробник"),
        "message": MessageLookupByLibrary.simpleMessage("Повідомлення"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Історія повідомлень"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Додаток Pos Saas безкоштовний і простий у використанні. Насправді, це одна з найкращих ПОС-систем по всьому світу."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas - це повноцінне бізнес-рішення з управління запасами, обліку, продажами, витратами та прибутками / збитками."),
        "mobile": MessageLookupByLibrary.simpleMessage("Мобільний"),
        "mobilePayment":
            MessageLookupByLibrary.simpleMessage("Мобільний платіж"),
        "monthly": MessageLookupByLibrary.simpleMessage("Щомісяця"),
        "moreInfo":
            MessageLookupByLibrary.simpleMessage("Додаткова інформація"),
        "name": MessageLookupByLibrary.simpleMessage("Введіть ваше ім\'я"),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Ім\'я вже існує"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("Ім\'я не може бути пустим"),
        "next": MessageLookupByLibrary.simpleMessage("Далі"),
        "noConnection":
            MessageLookupByLibrary.simpleMessage("Відсутній зв\'язок"),
        "noData": MessageLookupByLibrary.simpleMessage("Дані відсутні"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Дані відсутні"),
        "noDataFound": MessageLookupByLibrary.simpleMessage("Дані не знайдені"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("Історія не знайдена!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Продукт не знайдено"),
        "noSubTaxSelected": MessageLookupByLibrary.simpleMessage(
            "Додатковий податок не вибрано"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("Транзакцій не знайдено!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Користувача з такою адресою електронної пошти не знайдено."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "Роль користувача не знайдена"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Неактивний користувач"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Не надано"),
        "note": MessageLookupByLibrary.simpleMessage("Примітка"),
        "notes": MessageLookupByLibrary.simpleMessage("Примітки"),
        "notification": MessageLookupByLibrary.simpleMessage("Сповіщення"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP надіслано на"),
        "office": MessageLookupByLibrary.simpleMessage("Офіс"),
        "ok": MessageLookupByLibrary.simpleMessage("OK"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS, який містить велику кількість функціональності, включаючи відстеження продажів та управління запасами."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Ця система допомагає покращити ваші операції для ваших клієнтів."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Наша система POS має спрощувати щоденні операції автоматично, роблячи їх легкими для навігації."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("Початковий баланс"),
        "order": MessageLookupByLibrary.simpleMessage("Замовлення"),
        "other": MessageLookupByLibrary.simpleMessage("Інше"),
        "otp": MessageLookupByLibrary.simpleMessage("Закрити"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Немає в наявності"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Пакет"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Особливості пакету"),
        "paid": MessageLookupByLibrary.simpleMessage("Сплачено"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Сплачена сума"),
        "parties": MessageLookupByLibrary.simpleMessage("Учасники"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Список сторін"),
        "partyGST": MessageLookupByLibrary.simpleMessage("GST сторони"),
        "partyName": MessageLookupByLibrary.simpleMessage("Назва сторони"),
        "password": MessageLookupByLibrary.simpleMessage("Пароль"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Пароль та підтвердження пароля не співпадають"),
        "passwordCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Пароль не може бути порожнім"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("Паролі не збігаються"),
        "payCash": MessageLookupByLibrary.simpleMessage("Оплатити готівкою"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("Сплатити за допомогою bkash"),
        "payWithPaypal": MessageLookupByLibrary.simpleMessage(
            "Сплатити за допомогою PayPal"),
        "payeeName": MessageLookupByLibrary.simpleMessage("Получатель"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("Номер отримувача"),
        "payment": MessageLookupByLibrary.simpleMessage("Оплата"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("Сума платежу"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Оплата завершена"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Інструкція щодо оплати:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("Метод оплати"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Тип платежу"),
        "pdfView": MessageLookupByLibrary.simpleMessage("Перегляд PDF"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Особиста інформація"),
        "phone": MessageLookupByLibrary.simpleMessage("Телефон"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Номер телефону"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Номер телефону вже використовується"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("Номер телефону недійсний"),
        "phoneNumberIsRequired": MessageLookupByLibrary.simpleMessage(
            "Номер телефону обов\'язковий"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("Виберіть і завантажте файл"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("Виберіть дату закінчення"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Виберіть дату початку"),
        "plan": MessageLookupByLibrary.simpleMessage("План"),
        "pleaseAddQuantity": MessageLookupByLibrary.simpleMessage(
            "Будь ласка, додайте кількість"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Будь ласка, перевірте підключення до Інтернету"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Будь ласка, спочатку підключіть принтер"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Будь ласка, підключіть свій принтер Bluetooth"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Будь ласка, введіть більший пароль"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Будь ласка, введіть підтвердження пароля"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("Будь ласка, введіть пароль"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Будь ласка, введіть дійсну електронну пошту"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Будь ласка, введіть ім\'я"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("Будь ласка, введіть пароль"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Будь ласка, введіть свою адресу електронної пошти нижче, щоб отримати посилання на скидання пароля."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Будь ласка, введіть номер транзакції"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("Будь ласка, введіть суму"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Будь ласка, спочатку виберіть категорію"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("Будь ласка, виберіть план"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Будь ласка, виберіть категорію бізнесу"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Будь ласка, використовуйте дійсний код покупки для використання додатку"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("За допомогою Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Розроблено"),
        "premiumCustomerSupport": MessageLookupByLibrary.simpleMessage(
            "Преміальна підтримка клієнтів"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Преміум план"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Попередні суми оплат"),
        "price": MessageLookupByLibrary.simpleMessage("Ціна"),
        "print": MessageLookupByLibrary.simpleMessage("Друкувати"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Параметр друку"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Політика конфіденційності"),
        "product": MessageLookupByLibrary.simpleMessage("Продукт"),
        "productCode": MessageLookupByLibrary.simpleMessage("Код товару"),
        "productCodeIsRequired": MessageLookupByLibrary.simpleMessage(
            "Код продукту є обов\'язковим"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Код/Назва продукту"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Опис продукту"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Деталі продукту"),
        "productList": MessageLookupByLibrary.simpleMessage("Список товарів"),
        "productName": MessageLookupByLibrary.simpleMessage("Назва товару"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Назва продукту вже існує на цьому складі"),
        "productNameIsAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("Назва продукту вже додана"),
        "productNameIsRequired": MessageLookupByLibrary.simpleMessage(
            "Назва продукту є обов\'язковою"),
        "products": MessageLookupByLibrary.simpleMessage("Продукти"),
        "profile": MessageLookupByLibrary.simpleMessage("Профіль"),
        "profileEdit":
            MessageLookupByLibrary.simpleMessage("Редагування профілю"),
        "profit": MessageLookupByLibrary.simpleMessage("Прибуток"),
        "promo": MessageLookupByLibrary.simpleMessage("Промо"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Промо-код"),
        "purchase": MessageLookupByLibrary.simpleMessage("Закупівля"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("Сповіщення про закупівлю"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Закупівлю підтверджено"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Деталі закупівлі"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Фактура покупки"),
        "purchaseList":
            MessageLookupByLibrary.simpleMessage("Список закупівель"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Купити зараз"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Придбати платний план"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("Ціна закупівлі"),
        "purchasePriceIsRequired": MessageLookupByLibrary.simpleMessage(
            "Ціна покупки є обов\'язковою"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("Звіт про закупівлю"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Звіти про закупівлю"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Звіти про закупівлі"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("Повернення покупки"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("Звіт про повернення покупки"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Перехід на покупку"),
        "qty": MessageLookupByLibrary.simpleMessage("Кількість"),
        "quantity": MessageLookupByLibrary.simpleMessage("Кількість"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Останні транзакції"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("Отримано пін-код"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Референційний номер"),
        "register": MessageLookupByLibrary.simpleMessage("Реєстрація"),
        "registering": MessageLookupByLibrary.simpleMessage("Реєстрація"),
        "remainingDue":
            MessageLookupByLibrary.simpleMessage("Залишок заборгованості"),
        "remove": MessageLookupByLibrary.simpleMessage("Видалити"),
        "reports": MessageLookupByLibrary.simpleMessage("Звіти"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Запит надіслано"),
        "resendCode":
            MessageLookupByLibrary.simpleMessage("Відправити код повторно"),
        "resendOtp":
            MessageLookupByLibrary.simpleMessage("Відправити OTP повторно: "),
        "retailer":
            MessageLookupByLibrary.simpleMessage("Роздрібний продавець"),
        "retur": MessageLookupByLibrary.simpleMessage("Повернення"),
        "returN": MessageLookupByLibrary.simpleMessage("Повернення"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("Сума повернення"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("Сума повернення"),
        "returnQTY":
            MessageLookupByLibrary.simpleMessage("Кількість повернень"),
        "revenue": MessageLookupByLibrary.simpleMessage("Дохід"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Захистіть дані свого бізнесу легко. Наше безмежне оновлення Pos Saas POS включає безкоштовне резервне копіювання даних, що гарантує захист вашої цінної інформації від несподіваних подій. Сконцентруйтеся на тому, що дійсно має значення - зростанні вашого бізнесу."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Сума продажу"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("Деталі продажу"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Ціна продажу"),
        "saleReports": MessageLookupByLibrary.simpleMessage("Звіт про продажі"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Звіти про продажі"),
        "saleReturn":
            MessageLookupByLibrary.simpleMessage("Повернення продажу"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Звіт про повернення продажу"),
        "saleSetting":
            MessageLookupByLibrary.simpleMessage("Налаштування продажу"),
        "sales": MessageLookupByLibrary.simpleMessage("Продажі"),
        "salesAndPurchaseReports": MessageLookupByLibrary.simpleMessage(
            "Звіти про продажі та закупівлі"),
        "salesList": MessageLookupByLibrary.simpleMessage("Список продажів"),
        "salesReturn":
            MessageLookupByLibrary.simpleMessage("Повернення продажу"),
        "save": MessageLookupByLibrary.simpleMessage("Зберегти"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Зберегти та опублікувати"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("Зберегти зміни"),
        "saving": MessageLookupByLibrary.simpleMessage("Збереження"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("Скануйте QR-код продукту"),
        "search": MessageLookupByLibrary.simpleMessage("Пошук"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Шукати за кодом або назвою продукту"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("Переглянути всі промо-коди"),
        "select": MessageLookupByLibrary.simpleMessage("Вибрати"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Виберіть продукт для повернення"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Виберіть бренд"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Виберіть категорію"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Вибрати контакти"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("Виберіть категорію продукту"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("Виберіть категорію магазину"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Виберіть податок"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Виберіть тип податку"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("Виберіть одиницю"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Вибрати варіацію:"),
        "seller": MessageLookupByLibrary.simpleMessage("Продавець"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Продає"),
        "send": MessageLookupByLibrary.simpleMessage("Надіслати"),
        "sendEmail":
            MessageLookupByLibrary.simpleMessage("Надіслати електронний лист"),
        "sendMessage":
            MessageLookupByLibrary.simpleMessage("Надіслати повідомлення"),
        "sendResetLink": MessageLookupByLibrary.simpleMessage(
            "Надіслати посилання для скидання"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Надіслати SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Надіслати SMS?"),
        "sendWhatsappMessage": MessageLookupByLibrary.simpleMessage(
            "Надіслати повідомлення в WhatsApp"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Надіслати ваш email"),
        "sendingEmail":
            MessageLookupByLibrary.simpleMessage("Відправка електронної пошти"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Надсилаємо повідомлення"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Служба/Доставка"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Налаштуйте свій профіль"),
        "setting": MessageLookupByLibrary.simpleMessage("Налаштування"),
        "share": MessageLookupByLibrary.simpleMessage("Поділитися"),
        "shopGST": MessageLookupByLibrary.simpleMessage("GST магазину"),
        "signIn": MessageLookupByLibrary.simpleMessage("Увійти"),
        "signInWithEmail": MessageLookupByLibrary.simpleMessage(
            "Увійти за електронною поштою"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Підпис клієнта"),
        "size": MessageLookupByLibrary.simpleMessage("Розмір"),
        "skip": MessageLookupByLibrary.simpleMessage("Пропустити"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Соціальний маркетинг"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Вибачте, у вас немає дозволу на доступ до цього сервісу"),
        "startDate": MessageLookupByLibrary.simpleMessage("Дата початку"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Розпочати новий продаж"),
        "startTypingToSearch":
            MessageLookupByLibrary.simpleMessage("Почніть вводити для пошуку"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Залишайтесь на передньому краї технологічних досягнень без додаткових витрат. Наше безмежне оновлення Pos Saas POS завжди надає вам останні інструменти та можливості на ваших пальцях, гарантуючи, що ваш бізнес залишається на передовому."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("Ще не сплачено"),
        "stock": MessageLookupByLibrary.simpleMessage("Склад"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Запас є обов\'язковим"),
        "stockList": MessageLookupByLibrary.simpleMessage("Список товарів"),
        "stocks": MessageLookupByLibrary.simpleMessage("Запаси"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Необхідно надати дозвіл на зберігання для створення файлу Excel"),
        "subTaxList":
            MessageLookupByLibrary.simpleMessage("Список додаткових податків"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Додаткові податки"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Підсумок"),
        "submit": MessageLookupByLibrary.simpleMessage("Відправити"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "Підпишіться на наш\\nYouTube"),
        "subscription": MessageLookupByLibrary.simpleMessage("Підписка"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Успішно виконано"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Успішно вийшли з системи"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Успішно оновлено"),
        "supplier": MessageLookupByLibrary.simpleMessage("Постачальник"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("Назва постачальника"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("Код SWIFT"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Потрібно документи, які підтверджують особистість, такі як водійські права, національний паспорт або посвідчення особи"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "Візьміть посвідчення особи для перевірки вашої інформації"),
        "tap": MessageLookupByLibrary.simpleMessage("Торкніться"),
        "tax": MessageLookupByLibrary.simpleMessage("Податок"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Податкова група"),
        "taxPercentage":
            MessageLookupByLibrary.simpleMessage("Відсоток податку"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Податкова ставка"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Податкові ставки - Керуйте своїми податковими ставками"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Податковий звіт"),
        "taxType": MessageLookupByLibrary.simpleMessage("Тип податку"),
        "taxes": MessageLookupByLibrary.simpleMessage("Податки"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Умови та положення"),
        "termsOfUse":
            MessageLookupByLibrary.simpleMessage("Умови використання"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Умови та конфіденційність"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Дякуємо за оплату заборгованості"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Дякуємо"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Дякуємо за вашу покупку"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "Обліковий запис вже існує для цієї електронної пошти"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Файл Excel вже було завантажено"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Ім\'я говорить само за себе. З Pos Saas POS Unlimited не існує обмежень в щоденному використанні. Незалежно від того, чи обробляєте ви кілька операцій, чи зустрічаєте потік клієнтів, ви можете працювати з впевненістю, знаючи, що вас не обмежують обмеження."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "Вказаний пароль занадто слабкий"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Продаж буде видалено, і всі дані про цю покупку будуть видалені. Ви впевнені, що хочете видалити це?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Продаж буде видалено, і всі дані про цей продаж будуть видалені. Ви впевнені, що хочете видалити це?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Користувач буде видалений, і всі дані будуть видалені з вашого облікового запису. Ви впевнені, що хочете видалити це?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Користувач буде видалений, і всі дані будуть видалені з вашого облікового запису. Ви впевнені, що хочете це зробити?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Послуги третіх сторін"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Цю категорію не можна видалити"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Цього місяця)"),
        "thisProductAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("Цей продукт вже додано"),
        "title": MessageLookupByLibrary.simpleMessage("Заголовок"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Назва не може бути пустою"),
        "to": MessageLookupByLibrary.simpleMessage("до"),
        "toDate": MessageLookupByLibrary.simpleMessage("До дати"),
        "today": MessageLookupByLibrary.simpleMessage("Сьогодні"),
        "total": MessageLookupByLibrary.simpleMessage("Всього"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Загальна сума"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Загальна сума зібрана"),
        "totalDue":
            MessageLookupByLibrary.simpleMessage("Загальна заборгованість"),
        "totalExpense":
            MessageLookupByLibrary.simpleMessage("Загальна вартість"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Загальні втрати"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("Загальна сума до сплати"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Загальна ціна"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("Всього продуктів"),
        "totalProfit":
            MessageLookupByLibrary.simpleMessage("Загальний прибуток"),
        "totalPurchase":
            MessageLookupByLibrary.simpleMessage("Загальна покупка"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Загальна сума повернення"),
        "totalReturns": MessageLookupByLibrary.simpleMessage(
            "Загальна кількість повернень"),
        "totalSale":
            MessageLookupByLibrary.simpleMessage("Загальна сума продажів"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Загальний запас"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Загальна вартість"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Загальний ПДВ"),
        "totals": MessageLookupByLibrary.simpleMessage("Всього:"),
        "transaction": MessageLookupByLibrary.simpleMessage("Транзакція"),
        "transactionId":
            MessageLookupByLibrary.simpleMessage("Ідентифікатор транзакції"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Спробуйте ще раз"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Тип"),
        "unitName": MessageLookupByLibrary.simpleMessage("Назва одиниці"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Ціна за одиницю"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Ціна за одиницю"),
        "units": MessageLookupByLibrary.simpleMessage("Одиниці"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Без обмежень"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Необмежене використання"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Розблокуйте повний потенціал Pos Saas POS завдяки персоналізованим навчальним сеансам під керівництвом нашої експертної команди. Від основ до високорівневих технік ми гарантуємо, що ви добре розбираєтеся в використанні кожного аспекту системи для оптимізації своїх бізнес-процесів."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Не сплачено"),
        "update": MessageLookupByLibrary.simpleMessage("Оновити"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Оновити контакт"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Оновити зараз"),
        "updateProduct": MessageLookupByLibrary.simpleMessage("Оновити товар"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Оновіть свій план, ваш ліміт вичерпано"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Оновіть свій профіль"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Оновіть свій профіль, щоб зв\'язати вашого лікаря з кращим враженням"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Оновіть свій профіль, щоб покращити зв\'язок з вашим клієнтом"),
        "updated": MessageLookupByLibrary.simpleMessage("Оновлено"),
        "upload": MessageLookupByLibrary.simpleMessage("Завантажити"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Завантажити документ"),
        "uploadDone":
            MessageLookupByLibrary.simpleMessage("Завантаження завершено"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Завантажити файл"),
        "usbC": MessageLookupByLibrary.simpleMessage("USB C"),
        "use": MessageLookupByLibrary.simpleMessage("Використовувати"),
        "useMobiPos":
            MessageLookupByLibrary.simpleMessage("Використовуйте Pos Saas"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Використання системи"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Користувач видалений"),
        "userRole": MessageLookupByLibrary.simpleMessage("Роль користувача"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("Деталі ролі користувача"),
        "userTitle":
            MessageLookupByLibrary.simpleMessage("Заголовок користувача"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Заголовок користувача не може бути пустим"),
        "value": MessageLookupByLibrary.simpleMessage("Вартість"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("ПДВ не застосовується"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("Підтвердження OTP"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Підтвердити номер телефону"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Подивитися все"),
        "viewDetails":
            MessageLookupByLibrary.simpleMessage("Переглянути деталі"),
        "walkInCustomer": MessageLookupByLibrary.simpleMessage(
            "Клієнт без попереднього запису"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Склад"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Склад вже існує"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("Список складів"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("Назва складу"),
        "warranty": MessageLookupByLibrary.simpleMessage("Гарантія"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Ми відправили електронний лист з інструкціями щодо скидання пароля на:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Ми можемо використовувати послуги третіх сторін для підтримки функціональності нашого додатка, такі як постачальники аналітики та платіжні обробники. Ці послуги третіх сторін можуть збирати інформацію про вас під час використання нашого додатка. Зверніть увагу, що ми не несемо відповідальності за практики конфіденційності цих послуг третіх сторін."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Ми застосовуємо стандартні галузеві заходи для захисту вашої особистої інформації, включаючи шифрування та безпечне зберігання. Ми також обмежуємо доступ до вашої інформації лише для уповноважених співробітників."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Ми розуміємо важливість безшовних операцій. Саме тому наша цілодобова підтримка доступна для вас, незалежно від того, чи це швидкий запит, чи комплексне питання. Зв\'яжіться з нами в будь-який час і в будь-якому місці за допомогою дзвінка або WhatsApp, щоб відчути неперевершену обслуговування клієнтів."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Ми використовуємо вашу особисту інформацію для надання вам найкращого можливого досвіду використання нашого додатка, включаючи персоналізацію рекомендацій щодо вмісту, підключення вас до експертів та покращення функціональності наших додатків. Ми також можемо використовувати вашу інформацію для спілкування з вами щодо оновлень, акцій або іншої інформації, пов\'язаної з нашим додатком."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Ми розглянемо платіж і схвалимо його протягом 1-2 годин"),
        "weekly": MessageLookupByLibrary.simpleMessage("Щотижня"),
        "weight": MessageLookupByLibrary.simpleMessage("Вага"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Що нового"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Оптовик"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Ціна оптового продажу"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("Оптова ціна"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Оптовик"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Скоро буде додано"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Закінчиться о"),
        "writeYourMessageHere": MessageLookupByLibrary.simpleMessage(
            "Напишіть ваше повідомлення тут"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("Невірний OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Наданий неправильний пароль для цього користувача."),
        "yearly": MessageLookupByLibrary.simpleMessage("Щорічно"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Так, видалити назавжди"),
        "youAreNotAValidUser": MessageLookupByLibrary.simpleMessage(
            "Ви не є дійсним користувачем"),
        "youAreUsing":
            MessageLookupByLibrary.simpleMessage("Ви використовуєте"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Ви не можете сплатити більше, ніж заборгованість"),
        "youHaveGotAnEmail": MessageLookupByLibrary.simpleMessage(
            "Ви отримали електронного листа"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Ви успішно увійшли до свого облікового запису. Залишайтеся з Pos Saas ."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("Вам потрібно надати дозвіл"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Вам потрібно знову увійти в свій обліковий запис."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Перед покупкою SMS вам потрібно підтвердити свою особистість"),
        "yourMessageRemains": MessageLookupByLibrary.simpleMessage(
            "Ваше повідомлення залишається"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Ваш пакет"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Термін дії вашого пакету закінчується через 5 днів")
      };
}
