// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a ja locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'ja';

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "ADDSALE": MessageLookupByLibrary.simpleMessage("売上を追加"),
        "AnExcelFilePicked":
            MessageLookupByLibrary.simpleMessage("Excelファイルが選択されました"),
        "CATEGORY": MessageLookupByLibrary.simpleMessage("カテゴリ"),
        "INVOICE": MessageLookupByLibrary.simpleMessage("請求書"),
        "MOBIPOS": MessageLookupByLibrary.simpleMessage("Pos Saas"),
        "OF": MessageLookupByLibrary.simpleMessage("の"),
        "Of": MessageLookupByLibrary.simpleMessage("の"),
        "Ok": MessageLookupByLibrary.simpleMessage("OK"),
        "POSSale": MessageLookupByLibrary.simpleMessage("POS 売上"),
        "PRICE": MessageLookupByLibrary.simpleMessage("価格"),
        "PRODUCTNAME": MessageLookupByLibrary.simpleMessage("商品名"),
        "PosSaasLoginPanel":
            MessageLookupByLibrary.simpleMessage("Pos Saasログインパネル"),
        "QTY": MessageLookupByLibrary.simpleMessage("数量"),
        "Quantity": MessageLookupByLibrary.simpleMessage("数量*"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "STATUS": MessageLookupByLibrary.simpleMessage("ステータス"),
        "ShopGST": MessageLookupByLibrary.simpleMessage("ショップGST"),
        "TOTALVALUE": MessageLookupByLibrary.simpleMessage("合計値"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("ユーザータイトル"),
        "aboutApp": MessageLookupByLibrary.simpleMessage("アプリについて"),
        "accountName": MessageLookupByLibrary.simpleMessage("口座名"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("口座番号"),
        "action": MessageLookupByLibrary.simpleMessage("アクション"),
        "add": MessageLookupByLibrary.simpleMessage("追加"),
        "addBrand": MessageLookupByLibrary.simpleMessage("ブランドを追加"),
        "addCategory": MessageLookupByLibrary.simpleMessage("カテゴリを追加"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("顧客を追加"),
        "addDescription": MessageLookupByLibrary.simpleMessage("説明を追加...."),
        "addDesignation": MessageLookupByLibrary.simpleMessage("役職を追加"),
        "addDucument": MessageLookupByLibrary.simpleMessage("ドキュメントを追加"),
        "addItem": MessageLookupByLibrary.simpleMessage("アイテムを追加"),
        "addItemCategory": MessageLookupByLibrary.simpleMessage("商品カテゴリを追加"),
        "addNew": MessageLookupByLibrary.simpleMessage("新しいものを追加"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("新しい税金を追加"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage("単一/複数の税タイプで新しい税金を追加"),
        "addNewUser": MessageLookupByLibrary.simpleMessage("新しいユーザーを追加"),
        "addNewWareHouse": MessageLookupByLibrary.simpleMessage("新しい倉庫を追加"),
        "addProduct": MessageLookupByLibrary.simpleMessage("商品を追加"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("最初に商品を追加してください"),
        "addSuccessful": MessageLookupByLibrary.simpleMessage("追加に成功"),
        "addSupplier": MessageLookupByLibrary.simpleMessage("サプライヤーを追加"),
        "addUnit": MessageLookupByLibrary.simpleMessage("単位を追加"),
        "addUpdateExpenseList":
            MessageLookupByLibrary.simpleMessage("経費リストの追加/更新"),
        "addUpdateIncomeList":
            MessageLookupByLibrary.simpleMessage("収入リストの追加/更新"),
        "addUserRole": MessageLookupByLibrary.simpleMessage("ユーザーロールを追加"),
        "addWareHouse": MessageLookupByLibrary.simpleMessage("倉庫を追加"),
        "addedSuccessfully": MessageLookupByLibrary.simpleMessage("正常に追加されました"),
        "addingBrand": MessageLookupByLibrary.simpleMessage("ブランドの追加"),
        "addingCategory": MessageLookupByLibrary.simpleMessage("カテゴリを追加中"),
        "addingSerialNumber":
            MessageLookupByLibrary.simpleMessage("シリアル番号を追加しますか？"),
        "addingUnits": MessageLookupByLibrary.simpleMessage("単位の追加"),
        "address": MessageLookupByLibrary.simpleMessage("住所"),
        "addressCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("住所を入力してください"),
        "admin": MessageLookupByLibrary.simpleMessage("管理者"),
        "all": MessageLookupByLibrary.simpleMessage("すべて"),
        "allBasicFeatures": MessageLookupByLibrary.simpleMessage("すべての基本機能"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("すでに追加されています"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("既に存在します"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("アカウントをお持ちですか？"),
        "amount": MessageLookupByLibrary.simpleMessage("金額"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage("メールが送信されました\n受信トレイを確認してください"),
        "androidIOSAppSupport":
            MessageLookupByLibrary.simpleMessage("AndroidおよびiOSアプリサポート"),
        "applicableTax": MessageLookupByLibrary.simpleMessage("適用される税金"),
        "april": MessageLookupByLibrary.simpleMessage("4月"),
        "areYouSureToDeleteThisPurchase":
            MessageLookupByLibrary.simpleMessage("この購入を削除してもよろしいですか"),
        "areYouSureToDeleteThisSale":
            MessageLookupByLibrary.simpleMessage("この販売を削除してもよろしいですか"),
        "areYouSureWantToDeleteThisTax":
            MessageLookupByLibrary.simpleMessage("この税金を削除してもよろしいですか"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage("この税グループを削除してもよろしいですか"),
        "areYouWantToCreateThisQuation":
            MessageLookupByLibrary.simpleMessage("この見積書を作成しますか？"),
        "areYouWantToDeleteThisCustomer":
            MessageLookupByLibrary.simpleMessage("この顧客を削除しますか？"),
        "areYouWantToDeleteThisProduct":
            MessageLookupByLibrary.simpleMessage("この製品を削除しますか"),
        "areYouWantToDeleteThisQuotion":
            MessageLookupByLibrary.simpleMessage("この見積書を削除しますか？"),
        "areYouWantToReturnThisSale":
            MessageLookupByLibrary.simpleMessage("この売上を返品しますか？"),
        "balance": MessageLookupByLibrary.simpleMessage("残高"),
        "bank": MessageLookupByLibrary.simpleMessage("銀行"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("銀行口座の通貨"),
        "bankAccounts": MessageLookupByLibrary.simpleMessage("銀行口座"),
        "bankInformation": MessageLookupByLibrary.simpleMessage("銀行情報"),
        "bankName": MessageLookupByLibrary.simpleMessage("銀行名"),
        "barcodeGenerate": MessageLookupByLibrary.simpleMessage("バーコード生成"),
        "between": MessageLookupByLibrary.simpleMessage("間"),
        "billTo": MessageLookupByLibrary.simpleMessage("請求先："),
        "branchName": MessageLookupByLibrary.simpleMessage("支店名"),
        "brand": MessageLookupByLibrary.simpleMessage("ブランド"),
        "brandName": MessageLookupByLibrary.simpleMessage("ブランド名"),
        "brandNameIsAlreadyExist":
            MessageLookupByLibrary.simpleMessage("ブランド名は既に存在します"),
        "brandNameIsRequired":
            MessageLookupByLibrary.simpleMessage("ブランド名は必須です"),
        "bulkProductUpload": MessageLookupByLibrary.simpleMessage("一括商品アップロード"),
        "bulkTemplate": MessageLookupByLibrary.simpleMessage("バルクテンプレート"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("一括アップロード"),
        "businessCategory": MessageLookupByLibrary.simpleMessage("ビジネスカテゴリ"),
        "buy": MessageLookupByLibrary.simpleMessage("購入"),
        "buyPremiumPlan": MessageLookupByLibrary.simpleMessage("プレミアムプランを購入"),
        "buySms": MessageLookupByLibrary.simpleMessage("SMSを購入"),
        "calculator": MessageLookupByLibrary.simpleMessage("計算機:"),
        "camera": MessageLookupByLibrary.simpleMessage("カメラ"),
        "cancel": MessageLookupByLibrary.simpleMessage("キャンセル"),
        "capacity": MessageLookupByLibrary.simpleMessage("容量"),
        "card": MessageLookupByLibrary.simpleMessage("カード"),
        "cash": MessageLookupByLibrary.simpleMessage("現金"),
        "cashAndBank": MessageLookupByLibrary.simpleMessage("現金と銀行"),
        "cashInHand": MessageLookupByLibrary.simpleMessage("手元現金"),
        "categories": MessageLookupByLibrary.simpleMessage("カテゴリ"),
        "category": MessageLookupByLibrary.simpleMessage("カテゴリ"),
        "categoryName": MessageLookupByLibrary.simpleMessage("カテゴリ名"),
        "categoryNameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("カテゴリ名はすでに存在します"),
        "categoryNameIsAlreadyExist":
            MessageLookupByLibrary.simpleMessage("カテゴリー名は既に存在します"),
        "categoryNameIsRequired":
            MessageLookupByLibrary.simpleMessage("カテゴリー名は必須です"),
        "changeAmount": MessageLookupByLibrary.simpleMessage("釣り銭"),
        "changeReturn": MessageLookupByLibrary.simpleMessage("お釣り"),
        "changeableAmount": MessageLookupByLibrary.simpleMessage("変更可能金額"),
        "checkWarranty": MessageLookupByLibrary.simpleMessage("保証を確認する"),
        "choseAplan": MessageLookupByLibrary.simpleMessage("プランを選択"),
        "code": MessageLookupByLibrary.simpleMessage("コード"),
        "collectDue": MessageLookupByLibrary.simpleMessage("未払い集計"),
        "color": MessageLookupByLibrary.simpleMessage("色"),
        "comapnyName": MessageLookupByLibrary.simpleMessage("会社名"),
        "combinationOfMultipleTaxes":
            MessageLookupByLibrary.simpleMessage("複数の税金の組み合わせ"),
        "companyAddress": MessageLookupByLibrary.simpleMessage("会社住所"),
        "companyDescription": MessageLookupByLibrary.simpleMessage("会社概要"),
        "companyEmailAddress":
            MessageLookupByLibrary.simpleMessage("会社電子メールアドレス"),
        "companyName": MessageLookupByLibrary.simpleMessage("会社名"),
        "companyNameCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("会社名を入力してください"),
        "companyPhoneNumber": MessageLookupByLibrary.simpleMessage("会社電話番号"),
        "companyWebsiteUrl":
            MessageLookupByLibrary.simpleMessage("会社ウェブサイトURL"),
        "components": MessageLookupByLibrary.simpleMessage("コンポーネント"),
        "confirmPassword": MessageLookupByLibrary.simpleMessage("パスワードの確認"),
        "conformReturn": MessageLookupByLibrary.simpleMessage("返品を確認する"),
        "continu": MessageLookupByLibrary.simpleMessage("続行"),
        "convertToSale": MessageLookupByLibrary.simpleMessage("販売に変換"),
        "create": MessageLookupByLibrary.simpleMessage("作成"),
        "createPayment": MessageLookupByLibrary.simpleMessage("支払い作成"),
        "createdBy": MessageLookupByLibrary.simpleMessage("作成者"),
        "creativeHub": MessageLookupByLibrary.simpleMessage("クリエイティブハブ"),
        "currency": MessageLookupByLibrary.simpleMessage("通貨"),
        "currentPlan": MessageLookupByLibrary.simpleMessage("現在のプラン"),
        "currentStock": MessageLookupByLibrary.simpleMessage("現在の在庫"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("カスタム請求書のブランディング"),
        "customer": MessageLookupByLibrary.simpleMessage("顧客"),
        "customerDue": MessageLookupByLibrary.simpleMessage("顧客未払い"),
        "customerGST": MessageLookupByLibrary.simpleMessage("顧客GST"),
        "customerInvoices": MessageLookupByLibrary.simpleMessage("顧客請求書"),
        "customerList": MessageLookupByLibrary.simpleMessage("顧客リスト"),
        "customerName": MessageLookupByLibrary.simpleMessage("顧客名"),
        "customerNameIsRequired":
            MessageLookupByLibrary.simpleMessage("顧客名は必須です"),
        "customerOfTheMonth": MessageLookupByLibrary.simpleMessage("今月の顧客"),
        "customerPhone": MessageLookupByLibrary.simpleMessage("顧客名"),
        "customerType": MessageLookupByLibrary.simpleMessage("顧客タイプ"),
        "customerWalkIncostomer":
            MessageLookupByLibrary.simpleMessage("顧客: 来店客"),
        "customers": MessageLookupByLibrary.simpleMessage("顧客"),
        "dailyCollection": MessageLookupByLibrary.simpleMessage("日集計"),
        "dailySales": MessageLookupByLibrary.simpleMessage("日売上"),
        "dailyTransaction": MessageLookupByLibrary.simpleMessage("日次取引"),
        "dashBoard": MessageLookupByLibrary.simpleMessage("ダッシュボード"),
        "date": MessageLookupByLibrary.simpleMessage("日付"),
        "dateTime": MessageLookupByLibrary.simpleMessage("日時"),
        "day": MessageLookupByLibrary.simpleMessage("日"),
        "dealer": MessageLookupByLibrary.simpleMessage("ディーラー"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("ディーラー価格"),
        "delete": MessageLookupByLibrary.simpleMessage("削除"),
        "deleteSuccessful": MessageLookupByLibrary.simpleMessage("削除成功"),
        "deleting": MessageLookupByLibrary.simpleMessage("削除中"),
        "deliveryCharge": MessageLookupByLibrary.simpleMessage("配送料"),
        "description": MessageLookupByLibrary.simpleMessage("説明"),
        "designation": MessageLookupByLibrary.simpleMessage("役職"),
        "designationList": MessageLookupByLibrary.simpleMessage("役職リスト"),
        "designationNameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("役職名はすでに存在します"),
        "details": MessageLookupByLibrary.simpleMessage("詳細>"),
        "discount": MessageLookupByLibrary.simpleMessage("割引"),
        "discountPrice": MessageLookupByLibrary.simpleMessage("割引価格"),
        "done": MessageLookupByLibrary.simpleMessage("完了"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Excel形式でダウンロード"),
        "downloadPDF": MessageLookupByLibrary.simpleMessage("PDFをダウンロード"),
        "due": MessageLookupByLibrary.simpleMessage("未払い"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("未払い額"),
        "dueAmountWillShowHere":
            MessageLookupByLibrary.simpleMessage("未払い金額がここに表示されます"),
        "dueCollection": MessageLookupByLibrary.simpleMessage("未払い回収"),
        "dueDate": MessageLookupByLibrary.simpleMessage("支払期日"),
        "dueIsNotAvailableForGuest":
            MessageLookupByLibrary.simpleMessage("ゲストには支払うべき金額はありません"),
        "dueIsNotForGuestCustomer":
            MessageLookupByLibrary.simpleMessage("ゲスト顧客には期限はありません"),
        "dueList": MessageLookupByLibrary.simpleMessage("未払いリスト"),
        "dueListCustomer": MessageLookupByLibrary.simpleMessage("顧客の未払いリスト"),
        "dueListSupplier":
            MessageLookupByLibrary.simpleMessage("サプライヤーの未払いリスト"),
        "dueTemplate": MessageLookupByLibrary.simpleMessage("未払いテンプレート"),
        "dueTransaction": MessageLookupByLibrary.simpleMessage("未払い取引"),
        "duration": MessageLookupByLibrary.simpleMessage("期間"),
        "edit": MessageLookupByLibrary.simpleMessage("編集"),
        "editOrAddSerial": MessageLookupByLibrary.simpleMessage("シリアルを編集/追加:"),
        "editSuccessfully": MessageLookupByLibrary.simpleMessage("編集が完了しました"),
        "editTax": MessageLookupByLibrary.simpleMessage("税金を編集"),
        "editYourProfile": MessageLookupByLibrary.simpleMessage("プロフィールを編集"),
        "email": MessageLookupByLibrary.simpleMessage("Eメール"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("メールアドレスを入力してください"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("有効な金額を入力してください"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("有効な割引を入力してください"),
        "enterAValidPhoneNumber":
            MessageLookupByLibrary.simpleMessage("有効な電話番号を入力してください"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("有効な価格を入力してください"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("住所を入力してください"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("金額を入力してください"),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("ブランド名を入力してください"),
        "enterBulkSMSTemplate":
            MessageLookupByLibrary.simpleMessage("バルクSMSテンプレートを入力"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("カテゴリ名を入力してください"),
        "enterChangeReturn":
            MessageLookupByLibrary.simpleMessage("お釣りを入力してください"),
        "enterCompanyDesciption":
            MessageLookupByLibrary.simpleMessage("会社概要を入力してください"),
        "enterCompanyEmailAddress":
            MessageLookupByLibrary.simpleMessage("会社電子メールアドレスを入力してください"),
        "enterCompanyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("会社電話番号を入力してください"),
        "enterCompanyWebsiteUrl":
            MessageLookupByLibrary.simpleMessage("会社ウェブサイトURLを入力してください"),
        "enterCustomerGSTNumber":
            MessageLookupByLibrary.simpleMessage("顧客のGST番号を入力してください"),
        "enterCustomerName":
            MessageLookupByLibrary.simpleMessage("顧客名を入力してください"),
        "enterDate": MessageLookupByLibrary.simpleMessage("日付を入力してください"),
        "enterDealePrice":
            MessageLookupByLibrary.simpleMessage("ディーラー価格を入力してください"),
        "enterDescription": MessageLookupByLibrary.simpleMessage("説明を入力"),
        "enterDesignationName": MessageLookupByLibrary.simpleMessage("役職名を入力"),
        "enterDiscountPrice":
            MessageLookupByLibrary.simpleMessage("割引価格を入力してください"),
        "enterDueAmount":
            MessageLookupByLibrary.simpleMessage("支払うべき金額を入力してください"),
        "enterDueTemplate":
            MessageLookupByLibrary.simpleMessage("未払いテンプレートを入力"),
        "enterEmailAddress":
            MessageLookupByLibrary.simpleMessage("メールアドレスを入力してください"),
        "enterExpanseCategory":
            MessageLookupByLibrary.simpleMessage("経費カテゴリを入力してください"),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("経費日を入力してください"),
        "enterIncomeCategory":
            MessageLookupByLibrary.simpleMessage("収入カテゴリを入力してください"),
        "enterIncomeDate": MessageLookupByLibrary.simpleMessage("収入日を入力してください"),
        "enterLowStockAlertQuantity":
            MessageLookupByLibrary.simpleMessage("在庫不足アラートの数量を入力してください"),
        "enterManufacturerName":
            MessageLookupByLibrary.simpleMessage("メーカー名を入力してください"),
        "enterName": MessageLookupByLibrary.simpleMessage("名前を入力してください"),
        "enterNames": MessageLookupByLibrary.simpleMessage("名前を入力してください"),
        "enterNote": MessageLookupByLibrary.simpleMessage("メモを入力してください"),
        "enterOpeningBalance":
            MessageLookupByLibrary.simpleMessage("期首残高を入力してください"),
        "enterPaidAmount":
            MessageLookupByLibrary.simpleMessage("支払い金額を入力してください"),
        "enterPassword": MessageLookupByLibrary.simpleMessage("パスワードを入力"),
        "enterPayingAmount":
            MessageLookupByLibrary.simpleMessage("支払い金額を入力してください"),
        "enterPrice": MessageLookupByLibrary.simpleMessage("価格を入力してください"),
        "enterPriceInNumber":
            MessageLookupByLibrary.simpleMessage("価格を数字で入力してください"),
        "enterProductCapacity":
            MessageLookupByLibrary.simpleMessage("商品容量を入力してください"),
        "enterProductCode":
            MessageLookupByLibrary.simpleMessage("商品コードを入力してください"),
        "enterProductColor":
            MessageLookupByLibrary.simpleMessage("商品の色を入力してください"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("商品名を入力してください"),
        "enterProductQuantity":
            MessageLookupByLibrary.simpleMessage("商品数量を入力してください"),
        "enterProductSize":
            MessageLookupByLibrary.simpleMessage("商品サイズを入力してください"),
        "enterProductType":
            MessageLookupByLibrary.simpleMessage("商品タイプを入力してください"),
        "enterProductUnit":
            MessageLookupByLibrary.simpleMessage("商品単位を入力してください"),
        "enterProductWeight":
            MessageLookupByLibrary.simpleMessage("商品重量を入力してください"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("購入価格を入力してください"),
        "enterPurchaseReturnTemplate":
            MessageLookupByLibrary.simpleMessage("購入返品テンプレートを入力"),
        "enterPurchaseTemplate":
            MessageLookupByLibrary.simpleMessage("購入テンプレートを入力"),
        "enterQuantity": MessageLookupByLibrary.simpleMessage("数量を入力してください"),
        "enterQuantityInNumber":
            MessageLookupByLibrary.simpleMessage("数量を数字で入力してください"),
        "enterQuotationTemplate":
            MessageLookupByLibrary.simpleMessage("見積もりテンプレートを入力"),
        "enterReceivedAmount":
            MessageLookupByLibrary.simpleMessage("受け取った金額を入力してください"),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("参照番号を入力してください"),
        "enterSalePrice": MessageLookupByLibrary.simpleMessage("販売価格を入力してください"),
        "enterSalesReturnTemplate":
            MessageLookupByLibrary.simpleMessage("販売返品テンプレートを入力"),
        "enterSalesTemplate":
            MessageLookupByLibrary.simpleMessage("販売テンプレートを入力"),
        "enterSerialNumber":
            MessageLookupByLibrary.simpleMessage("シリアル番号を入力してください"),
        "enterSmsContent":
            MessageLookupByLibrary.simpleMessage("メッセージのコンテンツを入力してください"),
        "enterStockAmount":
            MessageLookupByLibrary.simpleMessage("在庫数量を入力してください"),
        "enterStockInNumber":
            MessageLookupByLibrary.simpleMessage("在庫を数字で入力してください"),
        "enterStockNumber":
            MessageLookupByLibrary.simpleMessage("在庫番号を入力してください"),
        "enterTaxRate": MessageLookupByLibrary.simpleMessage("税率を入力してください"),
        "enterTransactionId": MessageLookupByLibrary.simpleMessage("取引IDを入力"),
        "enterUnitName": MessageLookupByLibrary.simpleMessage("単位名を入力してください"),
        "enterUserRole":
            MessageLookupByLibrary.simpleMessage("ユーザー役割を入力してください"),
        "enterUserRoleName":
            MessageLookupByLibrary.simpleMessage("ユーザーロール名を入力"),
        "enterUserTitle": MessageLookupByLibrary.simpleMessage("ユーザータイトルを入力"),
        "enterValidNumber":
            MessageLookupByLibrary.simpleMessage("有効な数字を入力してください"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("倉庫名を入力してください"),
        "enterWarranty": MessageLookupByLibrary.simpleMessage("保証を入力してください"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("卸売価格を入力してください"),
        "enterYOurAmount": MessageLookupByLibrary.simpleMessage("金額を入力してください"),
        "enterYourAddress": MessageLookupByLibrary.simpleMessage("住所を入力してください"),
        "enterYourCompanyAddress":
            MessageLookupByLibrary.simpleMessage("会社住所を入力してください"),
        "enterYourCompanyName":
            MessageLookupByLibrary.simpleMessage("会社名を入力してください"),
        "enterYourCompanyNames":
            MessageLookupByLibrary.simpleMessage("会社名を入力してください"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("メールアドレスを入力してください"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("パスワードを入力してください"),
        "enterYourPasswordAgain":
            MessageLookupByLibrary.simpleMessage("パスワードをもう一度入力してください"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("電話番号を入力してください"),
        "enterYourShopAddress":
            MessageLookupByLibrary.simpleMessage("ショップの住所を入力してください"),
        "enterYourShopGSTNumber":
            MessageLookupByLibrary.simpleMessage("ショップのGST番号を入力してください"),
        "enterYourShopName":
            MessageLookupByLibrary.simpleMessage("店名を入力してください"),
        "enterYourUserTitle":
            MessageLookupByLibrary.simpleMessage("ユーザーのタイトルを入力してください"),
        "entercategoryName":
            MessageLookupByLibrary.simpleMessage("カテゴリ名を入力してください"),
        "entries": MessageLookupByLibrary.simpleMessage("エントリ"),
        "error": MessageLookupByLibrary.simpleMessage("エラー"),
        "excTax": MessageLookupByLibrary.simpleMessage("税抜き"),
        "exclusive": MessageLookupByLibrary.simpleMessage("税抜き"),
        "expense": MessageLookupByLibrary.simpleMessage("経費"),
        "expenseCategory": MessageLookupByLibrary.simpleMessage("支出カテゴリー"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("経費日"),
        "expenseDetails": MessageLookupByLibrary.simpleMessage("経費の詳細"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("経費用"),
        "expensecategoryList":
            MessageLookupByLibrary.simpleMessage("経費カテゴリリスト"),
        "expenses": MessageLookupByLibrary.simpleMessage("経費"),
        "expensesList": MessageLookupByLibrary.simpleMessage("支出リスト"),
        "expireDate": MessageLookupByLibrary.simpleMessage("期限日"),
        "expired": MessageLookupByLibrary.simpleMessage("期限切れ"),
        "expiredList": MessageLookupByLibrary.simpleMessage("期限切れリスト"),
        "failedWithError": MessageLookupByLibrary.simpleMessage("エラーで失敗しました"),
        "february": MessageLookupByLibrary.simpleMessage("2月"),
        "fieldToPickImage":
            MessageLookupByLibrary.simpleMessage("画像を選択するフィールド"),
        "fillAllRequiredField":
            MessageLookupByLibrary.simpleMessage("すべての必須フィールドを入力してください"),
        "fivePurchase": MessageLookupByLibrary.simpleMessage("今月のトップ5購入商品"),
        "forUnlimitedUses": MessageLookupByLibrary.simpleMessage("無制限の使用のために"),
        "forgetPassword": MessageLookupByLibrary.simpleMessage("パスワードを忘れました"),
        "forgotPassword": MessageLookupByLibrary.simpleMessage("パスワードをお忘れですか？"),
        "freeDataBackup": MessageLookupByLibrary.simpleMessage("無料データバックアップ"),
        "freeLifeTimeUpdate":
            MessageLookupByLibrary.simpleMessage("無制限の無料アップデート"),
        "freePackage": MessageLookupByLibrary.simpleMessage("無料パッケージ"),
        "freePlan": MessageLookupByLibrary.simpleMessage("無料プラン"),
        "generate": MessageLookupByLibrary.simpleMessage("生成"),
        "getStarted": MessageLookupByLibrary.simpleMessage("始めてみる"),
        "govermentId": MessageLookupByLibrary.simpleMessage("政府ID"),
        "grandTotal": MessageLookupByLibrary.simpleMessage("総計"),
        "guest": MessageLookupByLibrary.simpleMessage("ゲスト"),
        "high": MessageLookupByLibrary.simpleMessage("高"),
        "hold": MessageLookupByLibrary.simpleMessage("保留"),
        "holdNumber": MessageLookupByLibrary.simpleMessage("保留番号"),
        "identityVerify": MessageLookupByLibrary.simpleMessage("身元確認"),
        "image": MessageLookupByLibrary.simpleMessage("画像"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("InHouseは削除できません"),
        "inHouseCantBeEdit":
            MessageLookupByLibrary.simpleMessage("InHouseは編集できません"),
        "inc": MessageLookupByLibrary.simpleMessage("収入"),
        "incTax": MessageLookupByLibrary.simpleMessage("税込"),
        "inclusive": MessageLookupByLibrary.simpleMessage("税込"),
        "income": MessageLookupByLibrary.simpleMessage("収入"),
        "incomeCategory": MessageLookupByLibrary.simpleMessage("収入カテゴリ"),
        "incomeCategoryList": MessageLookupByLibrary.simpleMessage("収入カテゴリリスト"),
        "incomeDate": MessageLookupByLibrary.simpleMessage("収入日"),
        "incomeDetails": MessageLookupByLibrary.simpleMessage("収入の詳細"),
        "incomeFor": MessageLookupByLibrary.simpleMessage("収入の対象"),
        "incomeList": MessageLookupByLibrary.simpleMessage("収入リスト"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("在庫を増やす"),
        "instantPrivacy": MessageLookupByLibrary.simpleMessage("即時プライバシー"),
        "invoice": MessageLookupByLibrary.simpleMessage("請求書"),
        "invoiceCo": MessageLookupByLibrary.simpleMessage("請求書:"),
        "invoiceHint": MessageLookupByLibrary.simpleMessage("請求書番号..."),
        "invoiceNo": MessageLookupByLibrary.simpleMessage("請求書番号"),
        "item": MessageLookupByLibrary.simpleMessage("商品"),
        "itemName": MessageLookupByLibrary.simpleMessage("商品名"),
        "items": MessageLookupByLibrary.simpleMessage("アイテム"),
        "january": MessageLookupByLibrary.simpleMessage("1月"),
        "july": MessageLookupByLibrary.simpleMessage("7月"),
        "june": MessageLookupByLibrary.simpleMessage("6月"),
        "kycVerification": MessageLookupByLibrary.simpleMessage("KYC検証"),
        "last6Month": MessageLookupByLibrary.simpleMessage("過去6ヶ月"),
        "lastMonth": MessageLookupByLibrary.simpleMessage("先月"),
        "ledgeDetails": MessageLookupByLibrary.simpleMessage("台帳の詳細"),
        "ledger": MessageLookupByLibrary.simpleMessage("台帳"),
        "ledgerDetails": MessageLookupByLibrary.simpleMessage("台帳詳細"),
        "left": MessageLookupByLibrary.simpleMessage("左"),
        "loading": MessageLookupByLibrary.simpleMessage("読み込み中"),
        "loanAccounts": MessageLookupByLibrary.simpleMessage("ローン口座"),
        "logOut": MessageLookupByLibrary.simpleMessage("ログアウト"),
        "login": MessageLookupByLibrary.simpleMessage("ログイン"),
        "loginPanel": MessageLookupByLibrary.simpleMessage("ログインパネル"),
        "logoPositionInInvoice":
            MessageLookupByLibrary.simpleMessage("請求書のロゴの位置"),
        "loss": MessageLookupByLibrary.simpleMessage("損失"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("損益"),
        "lossProfit": MessageLookupByLibrary.simpleMessage("損益"),
        "lossProfitReport": MessageLookupByLibrary.simpleMessage("損益報告"),
        "lossminus": MessageLookupByLibrary.simpleMessage("損失(-)"),
        "low": MessageLookupByLibrary.simpleMessage("低"),
        "lowStock": MessageLookupByLibrary.simpleMessage("在庫不足"),
        "lowStockAlert": MessageLookupByLibrary.simpleMessage("在庫不足アラート"),
        "lowStocks": MessageLookupByLibrary.simpleMessage("低在庫"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "ブランドの請求書を使用して顧客に持続的な印象を与えます。当社の無制限アップグレードは、請求書をカスタマイズし、ブランドのアイデンティティを強化し、顧客の忠誠心を育む独自の利点を提供します。"),
        "manufactureDate": MessageLookupByLibrary.simpleMessage("製造日"),
        "manufacturer": MessageLookupByLibrary.simpleMessage("メーカー"),
        "march": MessageLookupByLibrary.simpleMessage("3月"),
        "margin": MessageLookupByLibrary.simpleMessage("マージン"),
        "may": MessageLookupByLibrary.simpleMessage("5月"),
        "mobiPosLoginPanel":
            MessageLookupByLibrary.simpleMessage("Pos Saas ログインパネル"),
        "mobiPosSignUpPane":
            MessageLookupByLibrary.simpleMessage("Pos Saas サインアップパネル"),
        "mobilePay": MessageLookupByLibrary.simpleMessage("モバイル決済"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("モバイル決済"),
        "mobilePlusDesktop":
            MessageLookupByLibrary.simpleMessage("モバイルアプリ\n+\nデスクトップ"),
        "moneyReciept": MessageLookupByLibrary.simpleMessage("領収書"),
        "nam": MessageLookupByLibrary.simpleMessage("名前*"),
        "name": MessageLookupByLibrary.simpleMessage("名前"),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("名前はすでに存在します"),
        "nameCantBeEmpty": MessageLookupByLibrary.simpleMessage("名前は空にできません"),
        "nameCodeOrCateogry":
            MessageLookupByLibrary.simpleMessage("名前、コード、またはカテゴリ"),
        "newCusotmers": MessageLookupByLibrary.simpleMessage("新規顧客"),
        "newCustomers": MessageLookupByLibrary.simpleMessage("新規顧客"),
        "newExpenses": MessageLookupByLibrary.simpleMessage("新しい支出"),
        "newIncome": MessageLookupByLibrary.simpleMessage("新規収入"),
        "next": MessageLookupByLibrary.simpleMessage("次"),
        "no": MessageLookupByLibrary.simpleMessage("いいえ"),
        "noConnection": MessageLookupByLibrary.simpleMessage("接続なし"),
        "noCustomerFound": MessageLookupByLibrary.simpleMessage("顧客が見つかりません"),
        "noDataFound": MessageLookupByLibrary.simpleMessage("データが見つかりません"),
        "noDueTransantionFound":
            MessageLookupByLibrary.simpleMessage("未払い取引が見つかりません"),
        "noExpenseCategoryFound":
            MessageLookupByLibrary.simpleMessage("経費カテゴリが見つかりません"),
        "noExpenseFound": MessageLookupByLibrary.simpleMessage("支出が見つかりません"),
        "noGroupFound": MessageLookupByLibrary.simpleMessage("グループが見つかりません"),
        "noIncomeCategoryFound":
            MessageLookupByLibrary.simpleMessage("収入カテゴリが見つかりません"),
        "noIncomeFound": MessageLookupByLibrary.simpleMessage("収入が見つかりません"),
        "noInvoiceFound": MessageLookupByLibrary.simpleMessage("請求書が見つかりません"),
        "noProductFound": MessageLookupByLibrary.simpleMessage("商品が見つかりません"),
        "noPurchaseTransactionFound":
            MessageLookupByLibrary.simpleMessage("購入取引が見つかりません"),
        "noQuotionFound":
            MessageLookupByLibrary.simpleMessage("見積もりが見つかりませんでした"),
        "noReportFound": MessageLookupByLibrary.simpleMessage("レポートが見つかりません"),
        "noSaleTransaactionFound":
            MessageLookupByLibrary.simpleMessage("売上取引が見つかりません"),
        "noSerialNumberFound":
            MessageLookupByLibrary.simpleMessage("シリアル番号が見つかりません"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("サブ税金が選択されていません"),
        "noSupplierFound":
            MessageLookupByLibrary.simpleMessage("サプライヤーが見つかりません"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("取引が見つかりません"),
        "noUserFound": MessageLookupByLibrary.simpleMessage("ユーザーが見つかりません"),
        "noUserFoundForThatEmail":
            MessageLookupByLibrary.simpleMessage("そのメールアドレスに一致するユーザーが見つかりません"),
        "noUserRoleFound":
            MessageLookupByLibrary.simpleMessage("ユーザーロールが見つかりません"),
        "nosSerialNumberFound":
            MessageLookupByLibrary.simpleMessage("シリアル番号が見つかりません"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("アクティブなユーザーではありません"),
        "notFound": MessageLookupByLibrary.simpleMessage("見つかりません"),
        "note": MessageLookupByLibrary.simpleMessage("メモ"),
        "oK": MessageLookupByLibrary.simpleMessage("OK"),
        "ok": MessageLookupByLibrary.simpleMessage("OK"),
        "openCheques": MessageLookupByLibrary.simpleMessage("開いた小切手"),
        "openingBalance": MessageLookupByLibrary.simpleMessage("期首残高"),
        "openingBalanceCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("開始残高を入力してください"),
        "orDragAndDropPng":
            MessageLookupByLibrary.simpleMessage("または PNG、JPG をドラッグ＆ドロップ"),
        "orDragdropXlsx":
            MessageLookupByLibrary.simpleMessage("または .xlsx をドラッグ＆ドロップ"),
        "orders": MessageLookupByLibrary.simpleMessage("注文"),
        "other": MessageLookupByLibrary.simpleMessage("その他"),
        "otherIncome": MessageLookupByLibrary.simpleMessage("その他収入"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("在庫切れ"),
        "packageFeature": MessageLookupByLibrary.simpleMessage("パッケージの特徴"),
        "paid": MessageLookupByLibrary.simpleMessage("支払済み"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("支払い済み金額"),
        "party": MessageLookupByLibrary.simpleMessage("パーティ"),
        "partyName": MessageLookupByLibrary.simpleMessage("取引先名"),
        "partyType": MessageLookupByLibrary.simpleMessage("取引先の種類"),
        "password": MessageLookupByLibrary.simpleMessage("パスワード"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage("パスワードと確認用パスワードが一致しません"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("パスワードを入力してください"),
        "passwordNotMach": MessageLookupByLibrary.simpleMessage("パスワードが一致しません"),
        "payCash": MessageLookupByLibrary.simpleMessage("現金支払い"),
        "payable": MessageLookupByLibrary.simpleMessage("支払い"),
        "payingAmount": MessageLookupByLibrary.simpleMessage("支払金額"),
        "payment": MessageLookupByLibrary.simpleMessage("支払い"),
        "paymentIn": MessageLookupByLibrary.simpleMessage("入金"),
        "paymentOut": MessageLookupByLibrary.simpleMessage("出金"),
        "paymentType": MessageLookupByLibrary.simpleMessage("支払い方法"),
        "paymentTypes": MessageLookupByLibrary.simpleMessage("支払い方法"),
        "phone": MessageLookupByLibrary.simpleMessage("電話"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("電話番号"),
        "phoneNumberAlreadyExists":
            MessageLookupByLibrary.simpleMessage("その電話番号は既に存在します"),
        "phoneNumberAlreadyUsed":
            MessageLookupByLibrary.simpleMessage("その電話番号は既に使用されています"),
        "phoneNumberCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("電話番号を入力してください"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("電話番号は必須です"),
        "phoneVerification": MessageLookupByLibrary.simpleMessage("電話番号の確認"),
        "plan": MessageLookupByLibrary.simpleMessage("プラン"),
        "pleaseAddAProductCode":
            MessageLookupByLibrary.simpleMessage("商品コードを追加してください"),
        "pleaseAddAProductName":
            MessageLookupByLibrary.simpleMessage("商品名を追加してください"),
        "pleaseAddASale": MessageLookupByLibrary.simpleMessage("売上を追加してください"),
        "pleaseAddCustomer":
            MessageLookupByLibrary.simpleMessage("顧客を追加してください"),
        "pleaseAddPurchasePrice":
            MessageLookupByLibrary.simpleMessage("購入価格を追加してください"),
        "pleaseAddSalePrice":
            MessageLookupByLibrary.simpleMessage("販売価格を追加してください"),
        "pleaseAddSomeProductFirst":
            MessageLookupByLibrary.simpleMessage("まずいくつかの商品を追加してください"),
        "pleaseCheckYourInbox":
            MessageLookupByLibrary.simpleMessage("受信箱をご確認ください"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage("インターネット接続を確認してください"),
        "pleaseDownloadOurMobileApp": MessageLookupByLibrary.simpleMessage(
            "モバイルアプリをダウンロードして、デスクトップ版を使用するにはパッケージに加入してください"),
        "pleaseEnterABiggerPassword":
            MessageLookupByLibrary.simpleMessage("より大きなパスワードを入力してください"),
        "pleaseEnterACompanyName":
            MessageLookupByLibrary.simpleMessage("会社名を入力してください"),
        "pleaseEnterAPhoneNumber":
            MessageLookupByLibrary.simpleMessage("電話番号を入力してください"),
        "pleaseEnterAValidEmail":
            MessageLookupByLibrary.simpleMessage("有効なメールアドレスを入力してください"),
        "pleaseEnterAmount":
            MessageLookupByLibrary.simpleMessage("金額を入力してください"),
        "pleaseEnterDesignation":
            MessageLookupByLibrary.simpleMessage("役職名を入力してください"),
        "pleaseEnterName": MessageLookupByLibrary.simpleMessage("名前を入力してください"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("パスワードを入力してください"),
        "pleaseEnterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("電話番号を入力してください"),
        "pleaseEnterProductStock":
            MessageLookupByLibrary.simpleMessage("製品在庫を入力してください"),
        "pleaseEnterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("購入価格を入力してください"),
        "pleaseEnterSalePrice":
            MessageLookupByLibrary.simpleMessage("販売価格を入力してください"),
        "pleaseEnterStock": MessageLookupByLibrary.simpleMessage("在庫を入力してください"),
        "pleaseEnterTransactionNumber":
            MessageLookupByLibrary.simpleMessage("取引番号を入力してください"),
        "pleaseEnterValidBalance":
            MessageLookupByLibrary.simpleMessage("有効な残高を入力してください"),
        "pleaseEnterValidData":
            MessageLookupByLibrary.simpleMessage("有効なデータを入力してください"),
        "pleaseEnterValidPhoneNumber":
            MessageLookupByLibrary.simpleMessage("有効な電話番号を入力してください"),
        "pleaseEnterYourAddress":
            MessageLookupByLibrary.simpleMessage("住所を入力してください"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("金額を入力してください"),
        "pleaseSelectABrand":
            MessageLookupByLibrary.simpleMessage("ブランドを選択してください"),
        "pleaseSelectACategory":
            MessageLookupByLibrary.simpleMessage("カテゴリーを選択してください"),
        "pleaseSelectACustomer":
            MessageLookupByLibrary.simpleMessage("顧客を選択してください"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("プランを選択してください"),
        "pleaseSelectAProductCategory":
            MessageLookupByLibrary.simpleMessage("商品カテゴリを選択してください"),
        "pleaseSelectBusinessCategory":
            MessageLookupByLibrary.simpleMessage("ビジネスカテゴリーを選択してください"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage("アプリを使用するには有効な購入コードを使用してください"),
        "pleaseentervaliddata":
            MessageLookupByLibrary.simpleMessage("有効なデータを入力してください"),
        "posSaasSingUpPanel":
            MessageLookupByLibrary.simpleMessage("Pos Saasサインアップパネル"),
        "practies": MessageLookupByLibrary.simpleMessage("実践"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("プレミアムカスタマーサポート"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("プレミアムプラン"),
        "preview": MessageLookupByLibrary.simpleMessage("プレビュー"),
        "previous": MessageLookupByLibrary.simpleMessage("前"),
        "previousDue": MessageLookupByLibrary.simpleMessage("前回支払い:"),
        "price": MessageLookupByLibrary.simpleMessage("価格"),
        "print": MessageLookupByLibrary.simpleMessage("印刷"),
        "printInvoice": MessageLookupByLibrary.simpleMessage("請求書を印刷する"),
        "printPdf": MessageLookupByLibrary.simpleMessage("PDFを印刷"),
        "privacyPolicy": MessageLookupByLibrary.simpleMessage("プライバシーポリシー"),
        "product": MessageLookupByLibrary.simpleMessage("商品"),
        "productBarcode": MessageLookupByLibrary.simpleMessage("商品バーコード"),
        "productCategory": MessageLookupByLibrary.simpleMessage("商品カテゴリ"),
        "productCod": MessageLookupByLibrary.simpleMessage("商品コード*"),
        "productCode": MessageLookupByLibrary.simpleMessage("商品コード"),
        "productCodeAlreadyExist":
            MessageLookupByLibrary.simpleMessage("商品コードは既に存在します"),
        "productColor": MessageLookupByLibrary.simpleMessage("商品の色"),
        "productList": MessageLookupByLibrary.simpleMessage("商品リスト"),
        "productNam": MessageLookupByLibrary.simpleMessage("商品名*"),
        "productName": MessageLookupByLibrary.simpleMessage("商品名"),
        "productNameAlreadyExist":
            MessageLookupByLibrary.simpleMessage("商品名は既に存在します"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage("この倉庫に既に商品名が存在します"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("商品名は必須です"),
        "productNameWithCode": MessageLookupByLibrary.simpleMessage("商品名とコード"),
        "productOutOfStock": MessageLookupByLibrary.simpleMessage("商品は在庫切れです"),
        "productPrice": MessageLookupByLibrary.simpleMessage("商品価格"),
        "productPurchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("商品購入価格は必須です"),
        "productQuantityIsRequired":
            MessageLookupByLibrary.simpleMessage("商品数量は必須です"),
        "productSalePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("商品販売価格は必須です"),
        "productSize": MessageLookupByLibrary.simpleMessage("商品サイズ"),
        "productStock": MessageLookupByLibrary.simpleMessage("製品在庫"),
        "productType": MessageLookupByLibrary.simpleMessage("商品タイプ"),
        "productUnit": MessageLookupByLibrary.simpleMessage("商品単位"),
        "productWaranty": MessageLookupByLibrary.simpleMessage("商品保証"),
        "productWeight": MessageLookupByLibrary.simpleMessage("商品重量"),
        "productcapacity": MessageLookupByLibrary.simpleMessage("商品容量"),
        "prof": MessageLookupByLibrary.simpleMessage("プロフィール"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("プロフィールの編集"),
        "profit": MessageLookupByLibrary.simpleMessage("利益"),
        "profitMinus": MessageLookupByLibrary.simpleMessage("利益(-)"),
        "profitPlus": MessageLookupByLibrary.simpleMessage("利益(+)"),
        "purchase": MessageLookupByLibrary.simpleMessage("購入"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("購入リスト"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("プレミアムプランを購入"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("購入価格"),
        "purchaseReturn": MessageLookupByLibrary.simpleMessage("購入返品"),
        "purchaseReturnTemplate":
            MessageLookupByLibrary.simpleMessage("購入返品テンプレート"),
        "purchaseTemplate": MessageLookupByLibrary.simpleMessage("購入テンプレート"),
        "purchaseTransaction": MessageLookupByLibrary.simpleMessage("購入取引"),
        "quantity": MessageLookupByLibrary.simpleMessage("数量"),
        "quantityIsRequired": MessageLookupByLibrary.simpleMessage("数量は必須です"),
        "quotation": MessageLookupByLibrary.simpleMessage("見積書"),
        "quotationList": MessageLookupByLibrary.simpleMessage("見積もりリスト"),
        "quotationSaleHistory": MessageLookupByLibrary.simpleMessage("見積販売履歴"),
        "quotationTemplate": MessageLookupByLibrary.simpleMessage("見積もりテンプレート"),
        "receiveWhatsappUpdates":
            MessageLookupByLibrary.simpleMessage("WhatsAppの更新を受け取る"),
        "receivedAmount": MessageLookupByLibrary.simpleMessage("受け取った金額"),
        "recentSale": MessageLookupByLibrary.simpleMessage("最近の販売"),
        "recivedAmount": MessageLookupByLibrary.simpleMessage("受領金額"),
        "referenceNo": MessageLookupByLibrary.simpleMessage("参照番号"),
        "referenceNumber": MessageLookupByLibrary.simpleMessage("参照番号"),
        "registering": MessageLookupByLibrary.simpleMessage("登録中"),
        "registration": MessageLookupByLibrary.simpleMessage("登録"),
        "remaining": MessageLookupByLibrary.simpleMessage("残り: "),
        "remainingBalance": MessageLookupByLibrary.simpleMessage("残高"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("残りの未払い"),
        "remove": MessageLookupByLibrary.simpleMessage("削除"),
        "reports": MessageLookupByLibrary.simpleMessage("レポート"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("リクエストが送信されました"),
        "reset": MessageLookupByLibrary.simpleMessage("リセット"),
        "resetYourPassword": MessageLookupByLibrary.simpleMessage("パスワードをリセット"),
        "result": MessageLookupByLibrary.simpleMessage("結果"),
        "retailer": MessageLookupByLibrary.simpleMessage("小売業者"),
        "returnQuantity": MessageLookupByLibrary.simpleMessage("返品数量"),
        "revenue": MessageLookupByLibrary.simpleMessage("収益"),
        "right": MessageLookupByLibrary.simpleMessage("右"),
        "sAmount": MessageLookupByLibrary.simpleMessage("販売金額"),
        "safegurardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "ビジネスデータを簡単に保護します。当社のPos Saas POS Unlimitedアップグレードには無料のデータバックアップが含まれており、貴重な情報が予期せぬイベントから保護されています。本当に重要なこと、つまりビジネスの成長に集中できます。"),
        "sale": MessageLookupByLibrary.simpleMessage("売上"),
        "saleAmount": MessageLookupByLibrary.simpleMessage("売上高"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("売上詳細"),
        "saleList": MessageLookupByLibrary.simpleMessage("売上リスト"),
        "salePrice": MessageLookupByLibrary.simpleMessage("販売価格"),
        "salePrices": MessageLookupByLibrary.simpleMessage("販売価格*"),
        "saleQuantity": MessageLookupByLibrary.simpleMessage("販売数量"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("売上返品"),
        "saleSuccessfullyDone":
            MessageLookupByLibrary.simpleMessage("販売が成功しました"),
        "saleTransaction": MessageLookupByLibrary.simpleMessage("売上取引"),
        "saleTransactionQuatationHistory":
            MessageLookupByLibrary.simpleMessage("売上取引（見積もり売上履歴）"),
        "sales": MessageLookupByLibrary.simpleMessage("売上"),
        "salesList": MessageLookupByLibrary.simpleMessage("販売リスト"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("販売返品"),
        "salesReturnTemplate":
            MessageLookupByLibrary.simpleMessage("販売返品テンプレート"),
        "salesTemplate": MessageLookupByLibrary.simpleMessage("販売テンプレート"),
        "save": MessageLookupByLibrary.simpleMessage("保存"),
        "saveAndPublish": MessageLookupByLibrary.simpleMessage("保存して公開"),
        "saveAndPublished": MessageLookupByLibrary.simpleMessage("保存して公開"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("変更を保存"),
        "search": MessageLookupByLibrary.simpleMessage("検索......"),
        "searchAnyThing": MessageLookupByLibrary.simpleMessage("何でも検索..."),
        "searchByInvoice": MessageLookupByLibrary.simpleMessage("請求書で検索...."),
        "searchByInvoiceOrName":
            MessageLookupByLibrary.simpleMessage("請求書または名前で検索"),
        "searchByName": MessageLookupByLibrary.simpleMessage("名前で検索"),
        "searchByNameOrPhone":
            MessageLookupByLibrary.simpleMessage("名前または電話で検索..."),
        "searchProductNameOrCode":
            MessageLookupByLibrary.simpleMessage("商品名またはコードで検索"),
        "searchSerialNumber": MessageLookupByLibrary.simpleMessage("シリアル番号を検索"),
        "searchWithName": MessageLookupByLibrary.simpleMessage("名前で検索"),
        "searchWithProductName": MessageLookupByLibrary.simpleMessage("商品名で検索"),
        "selectACategory": MessageLookupByLibrary.simpleMessage("カテゴリーを選択"),
        "selectAInvoice": MessageLookupByLibrary.simpleMessage("請求書を選択"),
        "selectAProductForReturn":
            MessageLookupByLibrary.simpleMessage("返品する商品を選択してください"),
        "selectCategory": MessageLookupByLibrary.simpleMessage("カテゴリーを選択"),
        "selectExpenseCategory":
            MessageLookupByLibrary.simpleMessage("支出カテゴリーを選択"),
        "selectParties": MessageLookupByLibrary.simpleMessage("取引先を選択してください"),
        "selectPractise": MessageLookupByLibrary.simpleMessage("実践を選択してください"),
        "selectProduct": MessageLookupByLibrary.simpleMessage("数量は必須です"),
        "selectProductBrand":
            MessageLookupByLibrary.simpleMessage("商品ブランドを選択してください"),
        "selectSerialNumber": MessageLookupByLibrary.simpleMessage("シリアル番号を選択"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("ショップカテゴリーを選択"),
        "selectTax": MessageLookupByLibrary.simpleMessage("税金を選択"),
        "selectTaxType": MessageLookupByLibrary.simpleMessage("税金タイプを選択"),
        "selectUnitType":
            MessageLookupByLibrary.simpleMessage("単位タイプを選択してください"),
        "selectVariations":
            MessageLookupByLibrary.simpleMessage("バリエーションを選択してください："),
        "selectWarrantyTime":
            MessageLookupByLibrary.simpleMessage("保証期間を選択してください"),
        "selectYourLanguage":
            MessageLookupByLibrary.simpleMessage("言語を選択してください"),
        "seller": MessageLookupByLibrary.simpleMessage("販売者"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("メッセージを送信"),
        "sendingResetEmail":
            MessageLookupByLibrary.simpleMessage("リセットメールを送信中"),
        "serial": MessageLookupByLibrary.simpleMessage("シリアル"),
        "serialNumber": MessageLookupByLibrary.simpleMessage("シリアル番号"),
        "serialNumberAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("シリアル番号は既に追加されています"),
        "serialNumbers": MessageLookupByLibrary.simpleMessage("シリアル番号"),
        "serviceCharge": MessageLookupByLibrary.simpleMessage("サービス料"),
        "setting": MessageLookupByLibrary.simpleMessage("設定"),
        "share": MessageLookupByLibrary.simpleMessage("共有"),
        "shipingOrOther": MessageLookupByLibrary.simpleMessage("配送/その他"),
        "shopName": MessageLookupByLibrary.simpleMessage("店名"),
        "shopOpeningBalance": MessageLookupByLibrary.simpleMessage("開店残高"),
        "shortcodes": MessageLookupByLibrary.simpleMessage("ショートコード"),
        "show": MessageLookupByLibrary.simpleMessage("表示>"),
        "showLogoInInvoice":
            MessageLookupByLibrary.simpleMessage("請求書にロゴを表示しますか？"),
        "showing": MessageLookupByLibrary.simpleMessage("表示中"),
        "shpingOrServices": MessageLookupByLibrary.simpleMessage("配送/サービス"),
        "signUpPanel": MessageLookupByLibrary.simpleMessage("サインアップパネル"),
        "siteName": MessageLookupByLibrary.simpleMessage("サイト名"),
        "size": MessageLookupByLibrary.simpleMessage("サイズ"),
        "snacks": MessageLookupByLibrary.simpleMessage("スナック"),
        "statistic": MessageLookupByLibrary.simpleMessage("統計"),
        "status": MessageLookupByLibrary.simpleMessage("ステータス"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "追加費用なしで最新のツールと機能が常に手の届くところにあることを確保し、ビジネスが常に最新の状態を維持する、技術革新の最前線にとどまる。"),
        "stayAtTheForeFrontOfTechnological": MessageLookupByLibrary.simpleMessage(
            "追加の費用なしで技術の最前線にとどまり、最新のツールと機能を常に手の届くところに持つことを確実にするPos Sass POS Unlimited Upgrade。"),
        "stock": MessageLookupByLibrary.simpleMessage("在庫"),
        "stockInventory": MessageLookupByLibrary.simpleMessage("在庫"),
        "stockIsMoreThenLowLimit":
            MessageLookupByLibrary.simpleMessage("在庫が低い制限を超えています"),
        "stockQuantity": MessageLookupByLibrary.simpleMessage("在庫数量"),
        "stockReport": MessageLookupByLibrary.simpleMessage("在庫レポート"),
        "stockValue": MessageLookupByLibrary.simpleMessage("在庫価値"),
        "stockValues": MessageLookupByLibrary.simpleMessage("在庫価値"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("サブ税金"),
        "subTotal": MessageLookupByLibrary.simpleMessage("小計"),
        "subciption": MessageLookupByLibrary.simpleMessage("サブスクリプション"),
        "submit": MessageLookupByLibrary.simpleMessage("送信"),
        "successfull": MessageLookupByLibrary.simpleMessage("成功"),
        "successfullyAdded": MessageLookupByLibrary.simpleMessage("正常に追加されました"),
        "successfullyDeleted":
            MessageLookupByLibrary.simpleMessage("正常に削除されました"),
        "successfullyDone": MessageLookupByLibrary.simpleMessage("正常に完了しました"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("正常に更新されました"),
        "supplier": MessageLookupByLibrary.simpleMessage("サプライヤー"),
        "supplierDue": MessageLookupByLibrary.simpleMessage("仕入先未払い"),
        "supplierInvoice": MessageLookupByLibrary.simpleMessage("サプライヤー請求書"),
        "supplierList": MessageLookupByLibrary.simpleMessage("サプライヤーリスト"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFTコード"),
        "tSale": MessageLookupByLibrary.simpleMessage("総販売額"),
        "takeADriveLisense": MessageLookupByLibrary.simpleMessage(
            "運転免許証、身分証明書、またはパスポートの写真を撮ってください"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("税グループ"),
        "taxRate": MessageLookupByLibrary.simpleMessage("税率"),
        "taxRatesManageYourTaxRates":
            MessageLookupByLibrary.simpleMessage("税率の管理 - あなたの税率を管理"),
        "taxType": MessageLookupByLibrary.simpleMessage("税金タイプ"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("利用規約"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage("そのメールアドレスのアカウントはすでに存在します"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "名前がすべてを物語っています。Pos Saas POS Unlimitedを使用すると、利用制限がありません。少数の取引を処理している場合でも、多くの顧客が押し寄せている場合でも、制限に縛られないことを知りながら、自信を持って運用できます。"),
        "thePasswordProvidedIsTooWeak":
            MessageLookupByLibrary.simpleMessage("提供されたパスワードは弱すぎます"),
        "theSaleWillBeDeletedAndAllTheDataWillBeDeletedAboutThisPurchaseAreYouSureToDeleteThis":
            MessageLookupByLibrary.simpleMessage(
                "販売は削除され、この購入に関するすべてのデータも削除されます。削除してもよろしいですか"),
        "theSaleWillBeDeletedAndAllTheDataWillBeDeletedAboutThisSaleAreYouSureToDeleteThis":
            MessageLookupByLibrary.simpleMessage(
                "販売が削除され、この販売に関するすべてのデータも削除されます。本当に削除してもよろしいですか"),
        "thisCategoryCannotBeDeleted":
            MessageLookupByLibrary.simpleMessage("このカテゴリは削除できません"),
        "thisCustmerHasNoDue":
            MessageLookupByLibrary.simpleMessage("この顧客は未払いがありません"),
        "thisCustomerHavePreviousDue":
            MessageLookupByLibrary.simpleMessage("この顧客には前回の未払いがあります"),
        "thisCustomerHavepreviousDue":
            MessageLookupByLibrary.simpleMessage("この顧客は以前の未払いがあります"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("今月"),
        "thisYear": MessageLookupByLibrary.simpleMessage("今年"),
        "to": MessageLookupByLibrary.simpleMessage("に"),
        "topSellingProduct": MessageLookupByLibrary.simpleMessage("トップセラー商品"),
        "total": MessageLookupByLibrary.simpleMessage("合計"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("合計金額"),
        "totalDiscount": MessageLookupByLibrary.simpleMessage("合計割引"),
        "totalDue": MessageLookupByLibrary.simpleMessage("合計未払い"),
        "totalDues": MessageLookupByLibrary.simpleMessage("合計未払い"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("総経費"),
        "totalIncome": MessageLookupByLibrary.simpleMessage("合計収入"),
        "totalItem": MessageLookupByLibrary.simpleMessage("合計アイテム"),
        "totalItem2": MessageLookupByLibrary.simpleMessage("合計商品: 2"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("合計損失"),
        "totalPaid": MessageLookupByLibrary.simpleMessage("合計支払い"),
        "totalPayable": MessageLookupByLibrary.simpleMessage("合計支払い"),
        "totalPaymentOut": MessageLookupByLibrary.simpleMessage("合計出金"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("合計金額"),
        "totalProduct": MessageLookupByLibrary.simpleMessage("合計商品数"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("合計利益"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("合計購入"),
        "totalReturnAmount": MessageLookupByLibrary.simpleMessage("合計返品額"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("合計返品"),
        "totalSale": MessageLookupByLibrary.simpleMessage("合計売上"),
        "totalSales": MessageLookupByLibrary.simpleMessage("総売上"),
        "totalValue": MessageLookupByLibrary.simpleMessage("総価値"),
        "totalVat": MessageLookupByLibrary.simpleMessage("合計VAT"),
        "totalpaymentIn": MessageLookupByLibrary.simpleMessage("合計入金"),
        "transaction": MessageLookupByLibrary.simpleMessage("取引"),
        "transactionId": MessageLookupByLibrary.simpleMessage("取引ID"),
        "transactionReport": MessageLookupByLibrary.simpleMessage("取引レポート"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("再試行"),
        "type": MessageLookupByLibrary.simpleMessage("タイプ"),
        "unPaid": MessageLookupByLibrary.simpleMessage("未払い"),
        "unit": MessageLookupByLibrary.simpleMessage("単位"),
        "unitName": MessageLookupByLibrary.simpleMessage("単位名"),
        "unitNameIsAlreadyExist":
            MessageLookupByLibrary.simpleMessage("単位名は既に存在します"),
        "unitNameIsRequired": MessageLookupByLibrary.simpleMessage("単位名は必須です"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("単価"),
        "unlimited": MessageLookupByLibrary.simpleMessage("無制限"),
        "unlimitedInvoice": MessageLookupByLibrary.simpleMessage("無制限の請求書"),
        "unlimitedUsage": MessageLookupByLibrary.simpleMessage("無制限の利用"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "エキスパートチームによる個別のトレーニングセッションでPos Saas POSのフルポテンシャルを引き出します。基本から高度なテクニックまで、システムのあらゆる側面を活用してビジネスプロセスを最適化することを確実にします。"),
        "unpaid": MessageLookupByLibrary.simpleMessage("未払い"),
        "update": MessageLookupByLibrary.simpleMessage("更新"),
        "updateNow": MessageLookupByLibrary.simpleMessage("今すぐ更新"),
        "updateTemplate": MessageLookupByLibrary.simpleMessage("テンプレートを更新"),
        "updateYourPlanFirst":
            MessageLookupByLibrary.simpleMessage("プランを更新してください。\n販売制限を超えました。"),
        "updateYourPlanFirstAddCustomerLimitIsOver":
            MessageLookupByLibrary.simpleMessage("プランを更新してください、顧客追加制限が超過しました"),
        "updateYourPlanFirstDueCollectionLimitIsOver":
            MessageLookupByLibrary.simpleMessage("プランを更新してください、未払い収集制限が超過しました"),
        "updateYourPlanFirstPurchaseLimitIsOver":
            MessageLookupByLibrary.simpleMessage("プランを更新してください\\n購入制限が終了しました"),
        "updateYourPlanFirstSaleLimitIsOver":
            MessageLookupByLibrary.simpleMessage("プランを更新してください\\n販売制限を超えました"),
        "updatingTemplate": MessageLookupByLibrary.simpleMessage("テンプレート更新中"),
        "upgradeOnMobileApp":
            MessageLookupByLibrary.simpleMessage("モバイルアプリでアップグレード"),
        "upload": MessageLookupByLibrary.simpleMessage("アップロード"),
        "uploadAImage": MessageLookupByLibrary.simpleMessage("画像をアップロード"),
        "uploadAnExcel":
            MessageLookupByLibrary.simpleMessage("Excelファイルをアップロード"),
        "uploadAnInvoiceLogo":
            MessageLookupByLibrary.simpleMessage("請求書のログイン画像をアップロード"),
        "uploadDocument": MessageLookupByLibrary.simpleMessage("ドキュメントをアップロード"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("アップロード完了"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("ファイルをアップロード"),
        "uploadSuccessful": MessageLookupByLibrary.simpleMessage("アップロード成功"),
        "uploading": MessageLookupByLibrary.simpleMessage("アップロード中"),
        "userName": MessageLookupByLibrary.simpleMessage("ユーザー名"),
        "userRole": MessageLookupByLibrary.simpleMessage("ユーザーロール"),
        "userRoleDetails": MessageLookupByLibrary.simpleMessage("ユーザー役割の詳細"),
        "userRoleName": MessageLookupByLibrary.simpleMessage("ユーザーロール名"),
        "userTitle": MessageLookupByLibrary.simpleMessage("ユーザータイトル"),
        "userTitleCanBeEmpty":
            MessageLookupByLibrary.simpleMessage("ユーザーのタイトルは空であっても構いません"),
        "vatOrgst": MessageLookupByLibrary.simpleMessage("VAT/GST"),
        "verifyPhoneNumber": MessageLookupByLibrary.simpleMessage("電話番号を検証"),
        "view": MessageLookupByLibrary.simpleMessage("表示"),
        "viewAll": MessageLookupByLibrary.simpleMessage("すべて表示"),
        "walkInCustomer": MessageLookupByLibrary.simpleMessage("来店客"),
        "warehouse": MessageLookupByLibrary.simpleMessage("倉庫"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("倉庫はすでに存在します"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("倉庫リスト"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("倉庫名"),
        "warranty": MessageLookupByLibrary.simpleMessage("保証"),
        "warrantys": MessageLookupByLibrary.simpleMessage("保証"),
        "weNeedToRegisterYourPhone":
            MessageLookupByLibrary.simpleMessage("開始する前に電話番号を登録する必要があります！"),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "シームレスな運用の重要性を理解しています。そのため、24時間体制でサポートが利用可能で、簡単なクエリから包括的な問題までをサポートします。いつでもどこからでも通話またはWhatsAppを介して接続し、比類のないカスタマーサービスを体験してください。"),
        "welcome": MessageLookupByLibrary.simpleMessage("ようこそ"),
        "whatsappMarketingEnabled":
            MessageLookupByLibrary.simpleMessage("Whatsappマーケティングが有効になっています"),
        "whatsappMarketingIsNotEnabledInYourCurrentSubscriptionPlan":
            MessageLookupByLibrary.simpleMessage(
                "現在のサブスクリプションプランではWhatsappマーケティングは有効になっていません"),
        "whatsappMarketingSMSTemplate":
            MessageLookupByLibrary.simpleMessage("WhatsappマーケティングSMSテンプレート"),
        "wholeSaleprice": MessageLookupByLibrary.simpleMessage("卸売価格"),
        "wholeSeller": MessageLookupByLibrary.simpleMessage("卸売業者"),
        "wholesale": MessageLookupByLibrary.simpleMessage("卸売"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("卸売業者"),
        "wight": MessageLookupByLibrary.simpleMessage("重量"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("期限はここで終了します"),
        "wrongPassword": MessageLookupByLibrary.simpleMessage("間違ったパスワード"),
        "wrongPasswordProvidedForThatUser":
            MessageLookupByLibrary.simpleMessage("そのユーザーのパスワードが間違っています"),
        "yearly": MessageLookupByLibrary.simpleMessage("年次"),
        "yesDeleteForever": MessageLookupByLibrary.simpleMessage("はい、永遠に削除"),
        "yesReturn": MessageLookupByLibrary.simpleMessage("はい、返品"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("無効なユーザーです"),
        "youDonNotHavePermissionToAddCustomer":
            MessageLookupByLibrary.simpleMessage("顧客を追加する権限がありません"),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("許可を与える必要があります"),
        "youHaveToRELOGINOnYourAccount":
            MessageLookupByLibrary.simpleMessage("再度ログインする必要があります"),
        "youHaveToRelogin":
            MessageLookupByLibrary.simpleMessage("アカウントを再ログインする必要があります。"),
        "youNeedToIdentityVerifySms":
            MessageLookupByLibrary.simpleMessage("メッセージを購入する前に身元確認が必要です"),
        "yourAllSaleList": MessageLookupByLibrary.simpleMessage("全売上リスト"),
        "yourAllSales": MessageLookupByLibrary.simpleMessage("全売上"),
        "yourAreUsing": MessageLookupByLibrary.simpleMessage("使用中"),
        "yourDueSales": MessageLookupByLibrary.simpleMessage("未払い売上"),
        "yourNeedToIdentityVerify":
            MessageLookupByLibrary.simpleMessage("メッセージを購入する前に身元確認が必要です"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("あなたのパッケージ"),
        "yourPaymentIsCancelled":
            MessageLookupByLibrary.simpleMessage("お支払いがキャンセルされました"),
        "yourPaymentIsSuccessfully":
            MessageLookupByLibrary.simpleMessage("お支払いが正常に完了しました"),
        "yourPaymentIscancelled":
            MessageLookupByLibrary.simpleMessage("お支払いがキャンセルされました")
      };
}
