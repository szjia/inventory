// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a sw locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'sw';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Endelea"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("Nambari ya GST"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP":
            MessageLookupByLibrary.simpleMessage("Bei ya Kuuza Rejareja (MRP)"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("MRP inahitajika"),
        "OK": MessageLookupByLibrary.simpleMessage("Sawa"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Ph.no"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("Nambari ya SWIFT"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Vyakula vya kati"),
        "TAX": MessageLookupByLibrary.simpleMessage("USHURU"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Inapakia"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("Cheo cha Mtumiaji"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Kifurushi Chako Kitakamilika Leo\n\nTafadhali Nunua tena"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) Mfumo unatolewa kwa lengo la kufacilitate shughuli za mauzo na shughuli zinazohusiana na mauzo katika biashara yako."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) Ili kutumia Mfumo, inaweza kuhitajika kujenga akaunti. Unakubaliana kutoa habari sahihi, za sasa, na kamili wakati wa mchakato wa usajili na kuzisasisha ili ziwe sahihi na kamili."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("Kuhusu Programu"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Kuhusu sisi"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Ukubalifu wa Masharti"),
        "accountName": MessageLookupByLibrary.simpleMessage("Jina la Akaunti"),
        "accountNumber":
            MessageLookupByLibrary.simpleMessage("Nambari ya Akaunti"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Usajili wa Akaunti"),
        "acton": MessageLookupByLibrary.simpleMessage("Kitendo"),
        "add": MessageLookupByLibrary.simpleMessage("Ongeza"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Ongeza Chapa"),
        "addCategory": MessageLookupByLibrary.simpleMessage("Ongeza Jamii"),
        "addContact": MessageLookupByLibrary.simpleMessage("Ongeza Mwasiliani"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Ongeza Mteja"),
        "addDelivery":
            MessageLookupByLibrary.simpleMessage("Ongeza Uwasilishaji"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Ongeza Maelezo"),
        "addDescription":
            MessageLookupByLibrary.simpleMessage("Ongeza Maelezo"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Ongeza Punguzo"),
        "addDocumentId": MessageLookupByLibrary.simpleMessage(
            "Ongeza Kitambulisho cha Hati"),
        "addDucument": MessageLookupByLibrary.simpleMessage("Ongeza Hati"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Ongeza Gharama"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Ongeza Jamii ya Gharama"),
        "addItems": MessageLookupByLibrary.simpleMessage("Ongeza Vitu"),
        "addNew": MessageLookupByLibrary.simpleMessage("Ongeza Mpya"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Ongeza Anwani Mpya"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Ongeza Bidhaa Mpya"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("Ongeza Kodi Mpya"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Ongeza Kodi Mpya kwa aina ya kodi moja/multiple"),
        "addNote": MessageLookupByLibrary.simpleMessage("Ongeza Noti"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Ongeza bidhaa kwanza"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Ongeza Kode ya Kukuza"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Ongeza Ununuzi"),
        "addSales": MessageLookupByLibrary.simpleMessage("Ongeza Uuzaji"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Umeongeza Kwa Mafanikio"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Ongeza Kitengo"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Ongeza Wajibu wa Mtumiaji"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Imepokelewa kwa mafanikio"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("Imeongezwa Katika Kikapu"),
        "address": MessageLookupByLibrary.simpleMessage("Anwani"),
        "admin": MessageLookupByLibrary.simpleMessage("Msimamizi"),
        "all": MessageLookupByLibrary.simpleMessage("Yote"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("Suluhisho zote za biashara"),
        "alreadyAdded":
            MessageLookupByLibrary.simpleMessage("Tayari imeongezwa"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Tayari Ipo"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Tayari Una Akaunti"),
        "amount": MessageLookupByLibrary.simpleMessage("Kiasi"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "Barua pepe imepelekwa\\nAngalia kisanduku chako cha kupokea"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Msaada wa Programu za Android na iOS"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Ushuru unaotumika"),
        "apply": MessageLookupByLibrary.simpleMessage("Tumia"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Je, uko sawa kufuta ankara hii?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Je, uko sawa kufuta mauzo haya?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Je, uko na uhakika wa kufuta mtumiaji huyu?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Je, Unahakika Unataka Kufuta Ushuru Huu?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Je, Unahakika Unataka Kufuta Kundi Hili la Ushuru?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Je, Unataka Kufuta Ghala Hili?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Je, una uhakika unataka kufuta mtumiaji huyu?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Saini ya Watahiniwa"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Wewe ni mwenye jukumu la kudumisha usiri wa akaunti yako na nywila yako na kuzuia ufikiaji wa akaunti yako. Unakubali jukumu la shughuli zote zinazotokea chini ya akaunti yako."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Lazima uwe na umri wa angalau miaka 18 au umri halali wa kufikia wengi katika eneo lako ili kutumia Mfumo."),
        "backSide": MessageLookupByLibrary.simpleMessage("Upande wa Nyuma"),
        "backToHome": MessageLookupByLibrary.simpleMessage("Rudi Nyumbani"),
        "balance": MessageLookupByLibrary.simpleMessage("Salio"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladesh"),
        "bank": MessageLookupByLibrary.simpleMessage("Benki"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Sarafu ya Akaunti ya Benki"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Sarafu ya Akaunti ya Benki"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Taarifa za Benki"),
        "bankName": MessageLookupByLibrary.simpleMessage("Jina la Benki"),
        "bankTransfer":
            MessageLookupByLibrary.simpleMessage("Uhamisho wa Benki"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Barcode imepatikana"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Ankara"),
        "billTo": MessageLookupByLibrary.simpleMessage("Mlipaji"),
        "branchName": MessageLookupByLibrary.simpleMessage("Jina la Tawi"),
        "brand": MessageLookupByLibrary.simpleMessage("Chapa"),
        "brandName": MessageLookupByLibrary.simpleMessage("Jina la Chapa"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("Kupakia kwa Wingi"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Jamii ya Biashara"),
        "buy": MessageLookupByLibrary.simpleMessage("Kununua"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Nunua Mpango wa Premium"),
        "buySms": MessageLookupByLibrary.simpleMessage("Nunua Ujumbe"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Kwa kufikia au kutumia Mfumo wa Point of Sale (POS) (\"Mfumo\") uliotolewa na [Jina la Kampuni Yako] (\"Kampuni\"), unakubaliana kufungwa na Masharti ya Matumizi haya. Ikiwa hukubaliani na Masharti haya ya Matumizi, tafadhali usitumie Mfumo."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Wewe ni mwenye jukumu la kuhakikisha kwamba ufikiaji wako na matumizi ya Mfumo unazingatia sheria na kanuni zote zinazofaa."),
        "cacel": MessageLookupByLibrary.simpleMessage("Ghairi"),
        "call": MessageLookupByLibrary.simpleMessage("Piga Simu"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "Piga simu kwa Msaada wa Dharura"),
        "camera": MessageLookupByLibrary.simpleMessage("Kamera"),
        "cancel": MessageLookupByLibrary.simpleMessage("Ghairi"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Ghairi Bidhaa Zote"),
        "capacity": MessageLookupByLibrary.simpleMessage("Uwezo"),
        "card": MessageLookupByLibrary.simpleMessage("Kadi"),
        "cash": MessageLookupByLibrary.simpleMessage("Fedha taslimu"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Kasi ya Pesa"),
        "categories": MessageLookupByLibrary.simpleMessage("Jamii"),
        "category": MessageLookupByLibrary.simpleMessage("Jamii"),
        "categoryName": MessageLookupByLibrary.simpleMessage("Jina la Kikundi"),
        "categoryNameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Jina la Kikundi Tayari Lipo"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("Jina la Jamii"),
        "change": MessageLookupByLibrary.simpleMessage("Badilisha?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Badilisha Nenosiri"),
        "checkEmail":
            MessageLookupByLibrary.simpleMessage("Angalia Barua pepe"),
        "choseACustomer": MessageLookupByLibrary.simpleMessage("Chagua Mteja"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Chagua Msambazaji"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Chagua vipengele vyako"),
        "clarence": MessageLookupByLibrary.simpleMessage("Clarence"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Bonyeza kuunganisha"),
        "close": MessageLookupByLibrary.simpleMessage("Funga"),
        "color": MessageLookupByLibrary.simpleMessage("Rangi"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(Mchanganyiko wa Ushuru Mbalimbali)"),
        "comingSoon":
            MessageLookupByLibrary.simpleMessage("Inakuja Hivi Punde"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Anwani ya Kampuni"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Jina la Kampuni na Duka"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("Jina la Kampuni & Biashara"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Kamilisha Uhamisho"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Thibitisha Nenosiri"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Thibitisha kurudi"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Hongera"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Wasiliana Nasi"),
        "continu": MessageLookupByLibrary.simpleMessage("Endelea"),
        "country": MessageLookupByLibrary.simpleMessage("Nchi"),
        "create": MessageLookupByLibrary.simpleMessage("Unda"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Tengeneza Akaunti Bure"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Imetengenezwa na Kuokolewa"),
        "currency": MessageLookupByLibrary.simpleMessage("Sarafu"),
        "currentStock":
            MessageLookupByLibrary.simpleMessage("Hisabati ya Sasa"),
        "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
            "Ubunifu wa Bili za Kibinafsi"),
        "customer": MessageLookupByLibrary.simpleMessage("Mteja"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Maelezo ya Mteja"),
        "customerGST": MessageLookupByLibrary.simpleMessage("GST ya mteja"),
        "customerName": MessageLookupByLibrary.simpleMessage("Jina la Mteja"),
        "dashBoardOverView": MessageLookupByLibrary.simpleMessage(
            "Muhtasari wa Eneo la Kudhibiti"),
        "dataSavedSuccessfully": MessageLookupByLibrary.simpleMessage(
            "Data zimehifadhiwa kwa mafanikio"),
        "date": MessageLookupByLibrary.simpleMessage("Tarehe"),
        "day": MessageLookupByLibrary.simpleMessage("Siku"),
        "dealer": MessageLookupByLibrary.simpleMessage("Muuzaji"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("Bei ya Muuzaji"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("Asilimia ya VAT ya Kawaida"),
        "delete": MessageLookupByLibrary.simpleMessage("Futa"),
        "deleting": MessageLookupByLibrary.simpleMessage("Kufuta"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Anwani ya Kujifanyia"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Anwani za usambazaji"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Gharama ya Uwasilishaji"),
        "describtion": MessageLookupByLibrary.simpleMessage("Maelezo"),
        "description": MessageLookupByLibrary.simpleMessage("Maelezo"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Maelezo hayawezi kuwa tupu"),
        "details": MessageLookupByLibrary.simpleMessage("Maelezo"),
        "discount": MessageLookupByLibrary.simpleMessage("Punguzo"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Usisumbue"),
        "done": MessageLookupByLibrary.simpleMessage("Imekamilika"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Pakua Muundo wa Excel"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Imepakuliwa kwa mafanikio kwenye folda ya kupakua"),
        "due": MessageLookupByLibrary.simpleMessage("Deni"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Kiasi cha Deni: "),
        "dueCollection":
            MessageLookupByLibrary.simpleMessage("Ukusanyaji wa Deni"),
        "dueCollectionReports": MessageLookupByLibrary.simpleMessage(
            "Ripoti za Mkusanyiko Unaostahili"),
        "dueList": MessageLookupByLibrary.simpleMessage("Orodha ya Deni"),
        "dueReports": MessageLookupByLibrary.simpleMessage("Ripoti ya Deni"),
        "duration": MessageLookupByLibrary.simpleMessage("Mudao"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Mudao: Kutoka"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "Rahisi kutumia Simu ya Mkono POS"),
        "edit": MessageLookupByLibrary.simpleMessage("Hariri"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Hariri Hati ya Ununuzi"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Hariri Ankara ya Uuzaji"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Hariri Mitandao ya Kijamii"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Imehaririwa Kwa Mafanikio"),
        "editTax": MessageLookupByLibrary.simpleMessage("Hariri Ushuru"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Hariri Kundi la Ushuru"),
        "editWarehouse": MessageLookupByLibrary.simpleMessage("Hariri Ghala"),
        "email": MessageLookupByLibrary.simpleMessage("Barua pepe"),
        "emailAddress":
            MessageLookupByLibrary.simpleMessage("Anwani ya Barua pepe"),
        "emailCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Barua pepe haiwezi kuwa tupu"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "Barua Pepe Imetumwa! Angalia kwenye Sanduku lako la Kuingia"),
        "endDate": MessageLookupByLibrary.simpleMessage("Tarehe ya Mwisho"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Ingiza kiasi halali"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Ingiza punguzo halali"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Ingiza nambari halali ya simu"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Ingiza bei halali"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("Ingiza kiasi halali"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("Ingiza Anwani"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("Ingiza Kiasi."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Ingiza Jina la Chapa"),
        "enterCapacity": MessageLookupByLibrary.simpleMessage("Ingiza Uwezo"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Ingiza Jina la Jamii"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Ingiza Rangi"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "Ingiza nambari ya gst ya mteja"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Ingiza Bei ya Muuzaji"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Ingiza Maelezo"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("Ingiza Punguzo."),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Ingiza Tarehe ya Gharama"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Ingiza Anwani Kamili"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Ingiza Nambari ya Hati"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Ingiza Kiasi cha Tahadhari ya Hisa Chache"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Ingiza Mzalishaji"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("Ingiza Maudhui ya Ujumbe"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "Ingiza Bei ya Kuuza Rejareja (MRP)"),
        "enterName": MessageLookupByLibrary.simpleMessage("Ingiza Jina"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Ingiza Noti"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Ingiza Jina la Chama"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Ingiza Namba ya Simu"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Ingiza Nambari ya Bidhaa au Sikiza"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Ingiza Jina la Bidhaa"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Ingiza Bei ya Ununuzi."),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("Ingiza Nambari ya Marejeleo"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Ingiza Ukubwa"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("Ingiza Hisani."),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Ingiza Kiwango cha Ushuru"),
        "enterTransactionId": MessageLookupByLibrary.simpleMessage(
            "Ingiza Kitambulisho cha Hesabu"),
        "enterType": MessageLookupByLibrary.simpleMessage("Ingiza Aina"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("Ingiza Cheo cha Mtumiaji"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Ingiza kiasi halali"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Ingiza Jina la Ghala"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Ingiza Uzito"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Ingiza Bei ya Jumla"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("Ingiza maelezo yako hapa"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "Ingiza Anwani yako ya Barua pepe"),
        "enterYourFeedBackTitle":
            MessageLookupByLibrary.simpleMessage("Ingiza Jina la Maoni Yako"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Ingiza nambari yako ya GST"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("Ingiza nambari yako ya simu"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Ingiza Jina Lako"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("Ingiza namba yako ya simu"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Ingiza Nywila Yako"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Ingiza Namba yako ya Simu"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "Ingiza kitambulisho chako cha uhamisho"),
        "error": MessageLookupByLibrary.simpleMessage("Kosa"),
        "excTax": MessageLookupByLibrary.simpleMessage("Ushuru wa Exc."),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("Mpakiaji wa Excel"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Kutoa"),
        "expense": MessageLookupByLibrary.simpleMessage("Gharama"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Jamii ya Gharama"),
        "expenseDate":
            MessageLookupByLibrary.simpleMessage("Tarehe ya Gharama"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Gharama Kwa"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Ripoti ya Gharama"),
        "expireDate":
            MessageLookupByLibrary.simpleMessage("Tarehe ya kumalizika"),
        "expired": MessageLookupByLibrary.simpleMessage("Imeisha"),
        "expiring": MessageLookupByLibrary.simpleMessage("Inakamilika"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Imeshindwa kwa Kosa"),
        "fashion": MessageLookupByLibrary.simpleMessage("Mitindo"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Vipengele ni sehemu muhimu inayofanya Pos Saas kuwa tofauti na suluhisho za jadi."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Maoni"),
        "firstName": MessageLookupByLibrary.simpleMessage("Jina la Kwanza"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Tutafute kwenye\\nFacebook"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Tutafute kwenye\\nTwitter"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Upande wa Mbele"),
        "forUnlimitedUses": MessageLookupByLibrary.simpleMessage(
            "Kwa matumizi yasiyokuwa na kikomo"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Umesahau Nenosiri"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Umesahau Nenosiri?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Tarehe ya Kuanzia"),
        "freeDataBackup": MessageLookupByLibrary.simpleMessage(
            "Nakala za Uhifadhi wa Data Bure"),
        "freeLifeTimeUpdate":
            MessageLookupByLibrary.simpleMessage("Sasisho za Maisha Bure"),
        "freePacakge":
            MessageLookupByLibrary.simpleMessage("Kifurushi cha Bure"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Mpango wa Bure"),
        "from": MessageLookupByLibrary.simpleMessage("(Kutoka"),
        "fullyPaid":
            MessageLookupByLibrary.simpleMessage("Imelipwa Kwa Ukamilifu"),
        "gallary": MessageLookupByLibrary.simpleMessage("Picha"),
        "generatingPDF":
            MessageLookupByLibrary.simpleMessage("Inatengeneza PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Pata Nambari ya OTP"),
        "govermentId":
            MessageLookupByLibrary.simpleMessage("Kitambulisho cha Serikali"),
        "guest": MessageLookupByLibrary.simpleMessage("Mgeni"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Huna akaunti?"),
        "history": MessageLookupByLibrary.simpleMessage("Historia"),
        "home": MessageLookupByLibrary.simpleMessage("Nyumbani"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Jinsi Tunavyolinda Taarifa Yako"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Jinsi Tunavyotumia Taarifa Yako"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Hakiki Utambulisho"),
        "image": MessageLookupByLibrary.simpleMessage("Picha"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("Haliwezi Kufutwa Ndani"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("Haliwezi Kuhaririwa Ndani"),
        "inWord": MessageLookupByLibrary.simpleMessage("Katika Neno"),
        "incTax": MessageLookupByLibrary.simpleMessage("Ushuru wa Inc."),
        "inclusive": MessageLookupByLibrary.simpleMessage("Kujumuisha"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("Ongeza Hifadhi"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Chombo"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Nambari ya Hati"),
        "invoice": MessageLookupByLibrary.simpleMessage("Ankara"),
        "invoiceNumber":
            MessageLookupByLibrary.simpleMessage("Nambari ya Hati"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Mipangilio ya Ankara"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Mtazamaji wa Ankara"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Bidhaa Imeongezwa"),
        "kg": MessageLookupByLibrary.simpleMessage("Kilogramu"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("Uhakiki wa KYC"),
        "language": MessageLookupByLibrary.simpleMessage(" Lugha"),
        "lastName": MessageLookupByLibrary.simpleMessage("Jina la Mwisho"),
        "ledger": MessageLookupByLibrary.simpleMessage("Kitabu Kipya"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Nunua Milele"),
        "link": MessageLookupByLibrary.simpleMessage("Kiungo"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport": MessageLookupByLibrary.simpleMessage(
            "Msaada wa Chat wa Moja kwa Moja"),
        "loading": MessageLookupByLibrary.simpleMessage("Inapakia"),
        "logIn": MessageLookupByLibrary.simpleMessage("Ingia"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Toka"),
        "logOut": MessageLookupByLibrary.simpleMessage("Toka"),
        "login": MessageLookupByLibrary.simpleMessage("Ingia"),
        "logo": MessageLookupByLibrary.simpleMessage("Alama"),
        "loss": MessageLookupByLibrary.simpleMessage("Hasara"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Hasara/Faida"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Maelezo ya Hasara/Faida"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Ripoti ya Hasara/Faida"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Ripoti za Hasara/Faida"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Tahadhari ya Hisa Chache"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Tengeneza athari ya kudumu kwa wateja wako na bili zenye nembo yako. Sasisho lisilokuwa na kikomo linatoa faida ya kipekee ya kubinafsisha bili zako, kuongeza umuhimu wa kitaalam ambao unaimarisha utambulisho wako wa chapa na kukuza uaminifu wa wateja."),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("Simamia biashara yako na "),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Tarehe ya utengenezaji"),
        "margin": MessageLookupByLibrary.simpleMessage("Mtiririko"),
        "masterCard": MessageLookupByLibrary.simpleMessage("Kadi ya Master"),
        "message": MessageLookupByLibrary.simpleMessage("Ujumbe"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Historia ya Ujumbe"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Programu ya Pos Saas ni bure, rahisi kutumia. Kwa kweli, ni moja ya mfumo bora wa POS duniani."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas ni suluhisho kamili la biashara na hisa, akaunti, mauzo, matumizi, na hasara/faida."),
        "mobile": MessageLookupByLibrary.simpleMessage("Simu"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("Malipo ya Simu"),
        "monthly": MessageLookupByLibrary.simpleMessage("Kila Mwezi"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("Maelezo Zaidi"),
        "name": MessageLookupByLibrary.simpleMessage("Ingiza Jina Lako."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Jina Tayari Lipo"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("Jina Haliwezi Kuwa Tupu"),
        "next": MessageLookupByLibrary.simpleMessage("Ifuatayo"),
        "noConnection":
            MessageLookupByLibrary.simpleMessage("Hakuna Uunganisho"),
        "noData": MessageLookupByLibrary.simpleMessage("Hakuna Data"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Hakuna Data Inapatikana"),
        "noDataFound": MessageLookupByLibrary.simpleMessage(
            "Hakuna Takwimu Zilizopatikana"),
        "noHistoryFound": MessageLookupByLibrary.simpleMessage(
            "Hakuna Historia Iliyopatikana!"),
        "noProductFound": MessageLookupByLibrary.simpleMessage(
            "Hakuna bidhaa iliyo patikana"),
        "noSubTaxSelected": MessageLookupByLibrary.simpleMessage(
            "Hakuna Kodi za Ndani Zilizochaguliwa"),
        "noTransactionFound": MessageLookupByLibrary.simpleMessage(
            "Hakuna Biashara Iliyopatikana!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Hakuna mtumiaji aliyepatikana kwa anwani hiyo ya barua pepe."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "Hakuna Jukumu la Mtumiaji Lililopatikana"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Mtumiaji Asiyehai"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Haitolewa"),
        "note": MessageLookupByLibrary.simpleMessage("Noti"),
        "notes": MessageLookupByLibrary.simpleMessage("Maelezo"),
        "notification": MessageLookupByLibrary.simpleMessage("Taarifa"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP imetumwa kwa"),
        "office": MessageLookupByLibrary.simpleMessage("Ofisi"),
        "ok": MessageLookupByLibrary.simpleMessage("Sawa"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS inayojumuisha kiasi kikubwa cha utendaji, ikiwa ni pamoja na ufuatiliaji wa mauzo na usimamizi wa hisa."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Mfumo huu unawasaidia kuboresha shughuli zako kwa ajili ya wateja wako."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Mfumo wetu wa POS unapaswa kusimplify shughuli za kila siku kiotomatiki, hivyo kuifanya iwe rahisi kwa urahisi wa kusimamia."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("Salio la Awali"),
        "order": MessageLookupByLibrary.simpleMessage("maagizo"),
        "other": MessageLookupByLibrary.simpleMessage("Nyingine"),
        "otp": MessageLookupByLibrary.simpleMessage("Funga"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Haina Hisa"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Kifurushi"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Vipengele vya Kifurushi"),
        "paid": MessageLookupByLibrary.simpleMessage("Limefadhiliwa"),
        "paidAmount":
            MessageLookupByLibrary.simpleMessage("Kiasi Kilicholipwa"),
        "parties": MessageLookupByLibrary.simpleMessage("Vyama"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Orodha ya Vyama"),
        "partyGST": MessageLookupByLibrary.simpleMessage("GST ya chama"),
        "partyName": MessageLookupByLibrary.simpleMessage("Jina la Chama"),
        "password": MessageLookupByLibrary.simpleMessage("Nenosiri"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Nywila na kuthibitisha nywila hazifananishi"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Nenosiri haliwezi kuwa tupu"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("Nenosiri halifani"),
        "payCash": MessageLookupByLibrary.simpleMessage("Lipa Kwa Pesa"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash": MessageLookupByLibrary.simpleMessage("Lipa kwa bKash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Lipa kwa Paypal"),
        "payeeName": MessageLookupByLibrary.simpleMessage("Jina la Mpokeaji"),
        "payeeNumber":
            MessageLookupByLibrary.simpleMessage("Nambari ya Mpokeaji"),
        "payment": MessageLookupByLibrary.simpleMessage("Malipo"),
        "paymentAmount":
            MessageLookupByLibrary.simpleMessage("Kiasi cha Malipo"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Malipo Yamekamilika"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Maelekezo ya Malipo:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("Njia ya Malipo"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Aina ya Malipo"),
        "pdfView": MessageLookupByLibrary.simpleMessage("Muonekano wa PDF"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Taarifa binafsi"),
        "phone": MessageLookupByLibrary.simpleMessage("Simu"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Namba ya Simu"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Nambari ya simu tayari inatumika"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("Nambari ya simu si halali"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("Nambari ya simu inahitajika"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("Chagua na Pakia Faili"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("Chagua Tarehe ya Mwisho"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Chagua Tarehe ya Kuanza"),
        "plan": MessageLookupByLibrary.simpleMessage("Mpango"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("Tafadhali ongeza kiasi"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Tafadhali angalia uunganisho wako wa intaneti"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Tafadhali ungana na printer kwanza"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Tafadhali unganisha printeri yako ya bluetooth"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Tafadhali ingiza nenosiri kubwa zaidi"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Tafadhali Ingiza Nenosiri la Kuthibitisha"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("Tafadhali ingiza nenosiri"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Tafadhali ingiza barua pepe halali"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Tafadhali ingiza jina"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("Tafadhali Ingiza Nywila"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Tafadhali ingiza anwani yako ya barua pepe hapa chini ili upokee Kiungo cha Kubadilisha Nenosiri."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Tafadhali ingiza Nambari ya Muhasibu"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("Tafadhali ingiza kiasi"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Tafadhali chagua aina kwanza"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("Tafadhali Chagua Mpango"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Tafadhali chagua aina ya biashara"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Tafadhali tumia kodi halali ya ununuzi ili kutumia programu"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Inayoendeshwa na Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Imetolewa Na"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Msaada wa Wateja wa Kipekee"),
        "premiumPlan":
            MessageLookupByLibrary.simpleMessage("Mpango wa Premium"),
        "previousPayAmounts": MessageLookupByLibrary.simpleMessage(
            "Mikataba ya Malipo Iliyotangulia"),
        "price": MessageLookupByLibrary.simpleMessage("bei"),
        "print": MessageLookupByLibrary.simpleMessage("Chapisha"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Chaguo la Uchapishaji"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Sera ya Faragha"),
        "product": MessageLookupByLibrary.simpleMessage("Bidhaa"),
        "productCode":
            MessageLookupByLibrary.simpleMessage("Nambari ya Bidhaa"),
        "productCodeIsRequired": MessageLookupByLibrary.simpleMessage(
            "Msimbo wa bidhaa unahitajika"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Kodi/Jina la Bidhaa"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Maelezo ya Bidhaa"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Maelezo ya Bidhaa"),
        "productList": MessageLookupByLibrary.simpleMessage("Orodha ya Bidhaa"),
        "productName": MessageLookupByLibrary.simpleMessage("Jina la Bidhaa"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Jina la bidhaa tayari lipo katika ghala hili"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Jina la bidhaa tayari limeongezwa"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("Jina la bidhaa linahitajika"),
        "products": MessageLookupByLibrary.simpleMessage("Bidhaa"),
        "profile": MessageLookupByLibrary.simpleMessage("Wasifu"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("Hariri Wasifu"),
        "profit": MessageLookupByLibrary.simpleMessage("Faida"),
        "promo": MessageLookupByLibrary.simpleMessage("Promo"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Nambari ya Promo"),
        "purchase": MessageLookupByLibrary.simpleMessage("Ununuzi"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("Kengele ya Ununuzi"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Ununuzi Umesajiliwa"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Maelezo ya Ununuzi"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Ankara ya Ununuzi"),
        "purchaseList":
            MessageLookupByLibrary.simpleMessage("Orodha ya Ununuzi"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Nunua Sasa"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Nunua Mpango wa Premium"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("Bei ya Ununuzi"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("Bei ya ununuzi inahitajika"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Ripoti ya Ununuzi"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Ripoti za Ununuzi"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("Kurudi kwa Ununuzi"),
        "purchaseReturnReport": MessageLookupByLibrary.simpleMessage(
            "Ripoti ya Kurudi kwa Ununuzi"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Mabadiliko ya Ununuzi"),
        "qty": MessageLookupByLibrary.simpleMessage("Kiasi"),
        "quantity": MessageLookupByLibrary.simpleMessage("Kiasi"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Shughuli za Hivi Karibuni"),
        "recivedThePin": MessageLookupByLibrary.simpleMessage("Umepokea PIN"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Nambari ya Marejeleo"),
        "register": MessageLookupByLibrary.simpleMessage("Jiandikishe"),
        "registering": MessageLookupByLibrary.simpleMessage("Kusajili"),
        "remainingDue":
            MessageLookupByLibrary.simpleMessage("Salio Inayostahili"),
        "remove": MessageLookupByLibrary.simpleMessage("Ondoa"),
        "reports": MessageLookupByLibrary.simpleMessage("Ripoti"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Ombi limepelekwa"),
        "resendCode": MessageLookupByLibrary.simpleMessage("Tuma tena Kanuni"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("Tuma tena OTP: "),
        "retailer": MessageLookupByLibrary.simpleMessage("Muuza rejareja"),
        "retur": MessageLookupByLibrary.simpleMessage("Kurudi"),
        "returN": MessageLookupByLibrary.simpleMessage("Rudisha"),
        "returnAmount":
            MessageLookupByLibrary.simpleMessage("Kiasi cha Kurudisha"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("Kiasi cha Kurudi"),
        "revenue": MessageLookupByLibrary.simpleMessage("Mapato"),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Kiasi cha Uuzaji"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("Maelezo ya Kuuza"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Bei ya Kuuza"),
        "saleReports": MessageLookupByLibrary.simpleMessage("Ripoti ya Kuuza"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Ripoti za Uuzaji"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("Kurudi kwa Uuzaji"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Ripoti ya Kurudi kwa Uuzaji"),
        "saleSetting":
            MessageLookupByLibrary.simpleMessage("Mipangilio ya Uuzaji"),
        "sales": MessageLookupByLibrary.simpleMessage("Mauzo"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("Ripoti za Kuuza na Kununua"),
        "salesList": MessageLookupByLibrary.simpleMessage("Orodha ya Uuzaji"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("Rudisha Mauzo"),
        "save": MessageLookupByLibrary.simpleMessage("Hifadhi"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Hifadhi na Chapisha"),
        "saveChanges":
            MessageLookupByLibrary.simpleMessage("Hifadhi Mabadiliko"),
        "saving": MessageLookupByLibrary.simpleMessage("Kuokoa"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("Scan QR Code ya bidhaa"),
        "search": MessageLookupByLibrary.simpleMessage("Tafuta"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Tafuta kwa kodi ya bidhaa au jina"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("Ona nambari zote za promo"),
        "select": MessageLookupByLibrary.simpleMessage("Chagua"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Chagua bidhaa kwa ajili ya kurudi"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Chagua Alama"),
        "selectCategory": MessageLookupByLibrary.simpleMessage("Chagua aina"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Chagua Mawasiliano"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("Chagua Aina ya Bidhaa"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("Chagua aina ya duka"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Chagua Ushuru"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Chagua aina ya ushuru"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("Chagua Kitengo"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Chagua Mbadala: "),
        "seller": MessageLookupByLibrary.simpleMessage("Muuzaji"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Inauzwa Na"),
        "send": MessageLookupByLibrary.simpleMessage("Tuma"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("Tuma Barua pepe"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Tuma Ujumbe"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("Tuma Kiungo cha Kubadilisha"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Tuma SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Tuma sms?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Tuma ujumbe wa whatsapp"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Tuma Barua Pepe Yako"),
        "sendingEmail":
            MessageLookupByLibrary.simpleMessage("Kutuma Barua Pepe"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Inatuma ujumbe"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Huduma/Uwasilishaji"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Sanidi Profaili Yako"),
        "setting": MessageLookupByLibrary.simpleMessage("Mipangilio"),
        "share": MessageLookupByLibrary.simpleMessage("shiriki"),
        "shopGST": MessageLookupByLibrary.simpleMessage("GST ya duka"),
        "signIn": MessageLookupByLibrary.simpleMessage("Ingia"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("Ingia kwa barua pepe"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Saini ya Mteja"),
        "size": MessageLookupByLibrary.simpleMessage("Ukubwa"),
        "skip": MessageLookupByLibrary.simpleMessage("Ruka"),
        "sms": MessageLookupByLibrary.simpleMessage("Ujumbe mfupi"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Masoko ya Kijamii"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Pole, huna ruhusa ya kufikia huduma hii"),
        "startDate": MessageLookupByLibrary.simpleMessage("Tarehe ya Kuanza"),
        "startNewSale": MessageLookupByLibrary.simpleMessage("Anza Mauzo Mpya"),
        "startTypingToSearch":
            MessageLookupByLibrary.simpleMessage("Anza kuandika ili kutafuta"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Kuwa mstari wa mbele wa maendeleo ya teknolojia bila gharama za ziada. Sasisho la Pos Saas POS lisilokuwa na kikomo linahakikisha kuwa unakuwa na zana na huduma za hivi karibuni mkononi mwako, kuhakikisha biashara yako inabaki kuwa ya kisasa."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("Bado Haijalipwa"),
        "stock": MessageLookupByLibrary.simpleMessage("Hisa"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Hisa inahitajika"),
        "stockList": MessageLookupByLibrary.simpleMessage("Orodha ya Bidhaa"),
        "stocks": MessageLookupByLibrary.simpleMessage("Hisani"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Ruhusa ya hifadhi inahitajika ili kuunda faili ya Excel"),
        "subTaxList":
            MessageLookupByLibrary.simpleMessage("Orodha ya Kodi za Ndani"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Kodi za Ndani"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Jumla Ndogo"),
        "submit": MessageLookupByLibrary.simpleMessage("Tuma"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "Jiandikishe kwa\\nYoutube Yetu"),
        "subscription": MessageLookupByLibrary.simpleMessage("Majumuisho"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Imekamilika kwa Mafanikio"),
        "successfullyLoggedOut": MessageLookupByLibrary.simpleMessage(
            "Umetolewa Kwenye Mfumo kwa Mafanikio"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Imesasishwa Kwa Mafanikio"),
        "supplier": MessageLookupByLibrary.simpleMessage("Mtoa Huduma"),
        "supplierName": MessageLookupByLibrary.simpleMessage("Jina la Muuzaji"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("Msimbo wa SWIFT"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Chukua picha ya leseni ya dereva, kitambulisho cha kitaifa au pasipoti"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "Chukua kadi ya kitambulisho ili kuangalia habari zako"),
        "tap": MessageLookupByLibrary.simpleMessage("Gusa"),
        "tax": MessageLookupByLibrary.simpleMessage("Kodi"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Kundi la Ushuru"),
        "taxPercentage":
            MessageLookupByLibrary.simpleMessage("Asilimia ya Kodi"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Kiwango cha Ushuru"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Viwango vya Ushuru - Dhibiti Viwango Vyako vya Ushuru"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Ripoti ya Ushuru"),
        "taxType": MessageLookupByLibrary.simpleMessage("Aina ya Ushuru"),
        "taxes": MessageLookupByLibrary.simpleMessage("Kodi"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Masharti na Masharti"),
        "termsOfUse":
            MessageLookupByLibrary.simpleMessage("Sheria za Matumizi"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Masharti & Faragha"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Asante kwa Malipo yako yanayostahili"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Asante"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Asante kwa ununuzi wako"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "Akaunti tayari inapatikana kwa barua pepe hiyo"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Faili ya Excel tayari imepakuliwa"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Jina linasema yote. Na Pos Saas POS lisilokuwa na kikomo, hakuna kikomo kwa matumizi yako. Iwe unaprocessing idadi ndogo ya manunuzi au unakumbana na msururu wa wateja, unaweza kufanya kazi kwa ujasiri, ukiwa na uhakika kuwa haujazuiwa na kikomo."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "Nywila iliyotolewa ni dhaifu sana"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Uuzaji utaondolewa na data zote zitafutwa kuhusu ununuzi huu. Je, uko sawa kufuta hii?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Mauzo yataondolewa na data zote zitafutwa kuhusu mauzo haya. Je, uko sawa kufuta hii?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Mtumiaji atafutwa na data zote zitafutwa kutoka kwenye akaunti yako. Una uhakika unataka kufuta hii?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Mtumiaji atafutwa na data zote zitatolewa kutoka kwa akaunti yako. Je, uko na uhakika wa kufuta hii?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Huduma za Tatu"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Kikundi Hiki Hakiwezi Kufutwa"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Mwezi Huu)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Bidhaa hii tayari imeongezwa"),
        "title": MessageLookupByLibrary.simpleMessage("Jina la Kichwa"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Kichwa hakiwezi kuwa tupu"),
        "to": MessageLookupByLibrary.simpleMessage("ku"),
        "toDate": MessageLookupByLibrary.simpleMessage("Tarehe ya Mwisho"),
        "today": MessageLookupByLibrary.simpleMessage("Leo"),
        "total": MessageLookupByLibrary.simpleMessage("Jumla"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Jumla ya Kiasi"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Jumla Iliyokusanywa"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Jumla Inayostahili"),
        "totalExpense":
            MessageLookupByLibrary.simpleMessage("Jumla ya Gharama"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Hasara yote"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("Jumla ya Kulipia"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Jumla ya Bei"),
        "totalProducts": MessageLookupByLibrary.simpleMessage("Bidhaa zote"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Faida yote"),
        "totalPurchase":
            MessageLookupByLibrary.simpleMessage("Jumla ya Ununuzi"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Jumla ya Kiasi cha Kurudi"),
        "totalReturns":
            MessageLookupByLibrary.simpleMessage("Jumla ya Marejesho"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Jumla ya Mauzo"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Jumla ya Hisa"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Thamani Jumla"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Jumla ya Kodi"),
        "totals": MessageLookupByLibrary.simpleMessage("Jumla: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Biashara"),
        "transactionId":
            MessageLookupByLibrary.simpleMessage("Kitambulisho cha Uhamisho"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Jaribu Tena"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Aina"),
        "unitName": MessageLookupByLibrary.simpleMessage("Jina la Kitengo"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Bei ya Kipande"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Bei ya Kitengo"),
        "units": MessageLookupByLibrary.simpleMessage("Vipande"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Isiyo na kikomo"),
        "unlimitedUsage": MessageLookupByLibrary.simpleMessage(
            "Matumizi Yasiyokuwa na Kikomo"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Fungua uwezo kamili wa Pos Saas POS na mafunzo ya kibinafsi yanayoongozwa na timu yetu ya wataalamu. Kutoka kwa misingi hadi mbinu za juu, tunahakikisha una maarifa ya kutosha ya kutumia kila sehemu ya mfumo ili kuboresha shughuli za biashara yako."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Hajapewa"),
        "update": MessageLookupByLibrary.simpleMessage("Sasisha"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Sasisha Mawasiliano"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Sasisha Sasa"),
        "updateProduct": MessageLookupByLibrary.simpleMessage("Sasisha Bidhaa"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Sasisha mpango wako kwanza,\\nukomo wako umemalizika"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Sasisha Wasifu Wako"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Sasisha wasifu wako ili kuunganisha daktari wako na athari bora"),
        "updated": MessageLookupByLibrary.simpleMessage("Imesasishwa"),
        "upload": MessageLookupByLibrary.simpleMessage("Pakia"),
        "uploadDocument": MessageLookupByLibrary.simpleMessage("Pakia Hati"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("Pakia Imekamilika"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Pakia Faili"),
        "usbC": MessageLookupByLibrary.simpleMessage("Usb C"),
        "use": MessageLookupByLibrary.simpleMessage("Tumia"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("Tumia Pos Saas"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Matumizi ya Mfumo"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Mtumiaji amefutwa"),
        "userRole": MessageLookupByLibrary.simpleMessage("Wajibu wa Mtumiaji"),
        "userRoleDetails": MessageLookupByLibrary.simpleMessage(
            "Maelezo ya Wajibu wa Mtumiaji"),
        "userTitle": MessageLookupByLibrary.simpleMessage("Cheo cha Mtumiaji"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Kichwa cha Mtumiaji Haliwezi Kuwa Tupu"),
        "value": MessageLookupByLibrary.simpleMessage("Thamani"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("VAT haitumiki"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("Kuthibitisha OTP"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Thibitisha Namba ya Simu"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Onyesha Yote"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("Ona Maelezo"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Mteja wa Kuingia"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Ghala"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Ghala Tayari Lipo"),
        "warehouseList":
            MessageLookupByLibrary.simpleMessage("Orodha ya Ghala"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("Jina la Ghala"),
        "warranty": MessageLookupByLibrary.simpleMessage("Dhamana"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Tumetuma barua pepe na maelekezo ya jinsi ya kurekebisha nenosiri kwa:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Tunaweza kutumia huduma za tatu kusaidia utendaji wa programu yetu, kama watoa huduma wa uchambuzi na wapokeaji wa malipo. Huduma za tatu hizi zinaweza kukusanya taarifa kuhusu wewe unapotumia programu yetu. Tafadhali fahamu kwamba hatuwajibiki kwa mazoea ya faragha ya huduma za tatu hizi."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Tunachukua hatua za viwango vya sekta kwa kulinda taarifa yako binafsi, ikiwa ni pamoja na kuficha na kuhifadhi kwa usalama. Pia tunapunguza ufikiaji wa taarifa yako kwa wafanyakazi walioidhinishwa pekee."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Tunaelewa umuhimu wa shughuli bila kukwama. Ndio maana msaada wetu wa saa 24 uko tayari kutoa usaidizi, iwe ni swali dogo au suala kubwa. Wasiliana nasi wakati wowote, mahali popote kupitia simu au WhatsApp ili ujue huduma isiyo na kifani."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Tunatumia taarifa yako binafsi ili kutoa uzoefu bora zaidi kwenye programu yetu, ikiwa ni pamoja na kubinafsisha mapendekezo ya yaliyomo, kukukutanisha na wataalamu, na kuboresha utendaji wa programu yetu. Pia tunaweza kutumia taarifa yako kuwasiliana nawe kuhusu sasisho, matangazo, au taarifa nyingine kuhusiana na programu yetu."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Tutakagua malipo na kuyakubali ndani ya masaa 1-2"),
        "weekly": MessageLookupByLibrary.simpleMessage("Kila wiki"),
        "weight": MessageLookupByLibrary.simpleMessage("Uzito"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Kipya"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Muuza Jumla"),
        "wholeSalePrice": MessageLookupByLibrary.simpleMessage("Bei ya Jumla"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("Bei ya jumla"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Wauzaji wa jumla"),
        "willBeAddedSoon": MessageLookupByLibrary.simpleMessage(
            "Itakuwa Imeongezwa Hivi Punde"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Itakamilika saa"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Andika ujumbe wako hapa"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("OTP si sahihi"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Nenosiri sio sahihi kwa mtumiaji huyo."),
        "yearly": MessageLookupByLibrary.simpleMessage("Kila Mwaka"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Ndiyo, Futa Milele"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("Wewe si Mtumiaji Halali"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Unatumia"),
        "youCanNotPayMoreThenDue":
            MessageLookupByLibrary.simpleMessage("Huwezi kulipa zaidi ya deni"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Umepokea Barua pepe"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Umeingia kwenye akaunti yako kwa mafanikio. Endelea na Pos Saas."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("Lazima Upate Ruhusa"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Lazima Uingie tena kwenye akaunti yako."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Unahitaji kuhakiki utambulisho kabla ya kununua sms"),
        "yourMessageRemains": MessageLookupByLibrary.simpleMessage(
            "Ujumbe wako unaendelea kubaki"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Kifurushi Chako"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Kifurushi Chako Kitakamilika Katika Siku 5")
      };
}
