// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a my locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'my';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("ဆက်လုပ်ပါ"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("GST နံပါတ်"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("အများစုရေးနှုန်း"),
        "MRPIsRequired": MessageLookupByLibrary.simpleMessage("MRP လိုအပ်သည်"),
        "OK": MessageLookupByLibrary.simpleMessage("အိုကေ"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("PayPal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("ဖုန်းနံပါတ်"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT ကုဒ်"),
        "Snacks": MessageLookupByLibrary.simpleMessage("အစားအစာ"),
        "TAX": MessageLookupByLibrary.simpleMessage("အခွန်"),
        "Uploading": MessageLookupByLibrary.simpleMessage("ထည့်သွင်းနေသည်"),
        "UserTitle":
            MessageLookupByLibrary.simpleMessage("အသုံးပြုသူ ခေါ်ဆိုတဲ့ နာမည်"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "သင်၏အကောင့်အတွက်ပြသရန်ယနေ့မှာသင်အားပြန်ယူရန်အတွက်အခြားကြားလပ်ရောက်ပါလိမ့်မည်"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) The System is provided solely for the\npurpose of facilitating point of sale\ntransactions andrelatedactivities in your\nbusiness."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) To use the System, you may be\nrequired to create an account. You\nagree to provide accurate, current, and\ncomplete information during\nthe registration process and toupdate\nsuchinformationto keep itaccurate\nand complete."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("အက်ပလီကေတ"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("ကျွန်ုပ်တို့အကြောင်း"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Acceptance of Terms"),
        "accountName": MessageLookupByLibrary.simpleMessage("အကောင့်အမည်"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("အကောင့်နံပါတ်"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Account Registration"),
        "acton": MessageLookupByLibrary.simpleMessage("အပြုအမူ"),
        "add": MessageLookupByLibrary.simpleMessage("ထည့်ပါ"),
        "addBrand":
            MessageLookupByLibrary.simpleMessage("ကုန်ပစ္စည်းအမည်ထည့်မည်"),
        "addCategory": MessageLookupByLibrary.simpleMessage("အမျိုးအစားထည့်ပါ"),
        "addContact":
            MessageLookupByLibrary.simpleMessage("ဆက်သွယ်ရန်အသုံးပြုရန်"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("အသုံးပြုသူထည့်ပါ"),
        "addDelivery":
            MessageLookupByLibrary.simpleMessage("ပေးပို့ရန်အသစ်ထည့်ပါ"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("ဖော်ပြချက် ထည့်ပါ"),
        "addDescription":
            MessageLookupByLibrary.simpleMessage("မှတ်ချက်ထည့်ပါ"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("လျှော့ချပေးပါ"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("စာရွက်စာတမ်း ID ထည့်ပါ"),
        "addDucument": MessageLookupByLibrary.simpleMessage("မှတ်တမ်းထည့်မည်"),
        "addExpense": MessageLookupByLibrary.simpleMessage("အသုံးစရိတ်ထည့်ပါ"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("အသုံးစရိတ်အမျိုးအစားထည့်ပါ"),
        "addItems":
            MessageLookupByLibrary.simpleMessage("ကုန်ပစ္စည်းများထည့်ပါ"),
        "addNew": MessageLookupByLibrary.simpleMessage("သစ်ထည့်ပါ"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("လိပ်စာအသစ်ထည့်ပါ"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("အသစ်တစ်ခုထည့်မည်"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("အခွန်အသစ်ထည့်ပါ"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Single/Multiple အခွန်အမျိုးအစားဖြင့် အခွန်အသစ်ထည့်ပါ"),
        "addNote": MessageLookupByLibrary.simpleMessage("မှတ်ချက်ထည့်ပါ"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("ထုတ်ကုန်ကို ပထမဦးစွာထည့်ပါ"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("ထူးခြားကုဒ်ထည့်ပါ"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("အဝယ်ချက်ထည့်ပါ"),
        "addSales": MessageLookupByLibrary.simpleMessage("ရောင်းအသစ်ထည့်မည်"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("အသုံးပြု အဆင့်မြှင့်ပြီး"),
        "addUnit": MessageLookupByLibrary.simpleMessage("ယူနစ်ထည့်ပါ"),
        "addUserRole": MessageLookupByLibrary.simpleMessage(
            "အသုံးပြုသူ ရာခိုင်နှုန်း ထည့်သွင်းရန်"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("အောင်မြင်စွာထည့်ပြီး"),
        "addedToCart": MessageLookupByLibrary.simpleMessage("ကားတင်ခဲ့ပါပြီ"),
        "address": MessageLookupByLibrary.simpleMessage("လိပ်စာ"),
        "admin": MessageLookupByLibrary.simpleMessage("အုပ်ချုပ်ရေးမှူး"),
        "all": MessageLookupByLibrary.simpleMessage("အားလုံး"),
        "allBusinessSolution": MessageLookupByLibrary.simpleMessage(
            "အားလုံးစီးပွားရေးရှင်းစနစ်များ"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("ရောက်ပြီး"),
        "alreadyExists":
            MessageLookupByLibrary.simpleMessage("အရင်ဆုံး ရှိခဲ့ပါပြီ"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("အကောင့်ရှိပြီးပြီလား"),
        "amount": MessageLookupByLibrary.simpleMessage("ပမာဏ"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "အီးမေးလ်တစ်စောင် ပို့ထားပါသည်\nသင့် inbox ကို စစ်ဆေးပါ"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Android နှင့် iOS အ်ကိုပ်ဆုံးအကောင့်"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("သင့်လျော်သောအခွန်"),
        "apply": MessageLookupByLibrary.simpleMessage("လျှောက်ထားမည်"),
        "areYouSureToDeleteThisInvoice":
            MessageLookupByLibrary.simpleMessage("ဤလိပ်စာကို ဖျက်မလား?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "ဤရောင်းချမှုကို ဖျက်သိမ်းမလား"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "ဤအသုံးပြုသူကိုဖျက်မလားသေချာပါသလား"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "ဤအခွန်ကို ဖျက်ရန် သေချာပါသလား"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "ဤအခွန်အုပ်စုကို ဖျက်ရန် သေချာပါသလား"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "ဤကုန်ဆောင်ရုံကို ဖျက်လိုပါသလား"),
        "areYourSureDeleteThisUser":
            MessageLookupByLibrary.simpleMessage("ဤအသုံးပြုသူကို ဖျက်မလား?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("အတည်ပြု လက်မှတ်"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) You are responsible for\nmaintainingthe confidentiality of your\naccount and password andfor restricting\naccess to your account. You accept\nresponsibility for all activities that\noccur under your account."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) You must be at least 18 years old or the\nlegal age of majority in your jurisdiction to\nuse the System."),
        "backSide": MessageLookupByLibrary.simpleMessage("နောက်စက်"),
        "backToHome":
            MessageLookupByLibrary.simpleMessage("မူလစ်အပြင်မှတ်ပြီး"),
        "balance": MessageLookupByLibrary.simpleMessage("ကျန်ရှိအကျယ်ကန်"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("ဘန်ဂကလားဒီနိုင်ငံ"),
        "bank": MessageLookupByLibrary.simpleMessage("ဘဏ်"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("ဘဏ်အကောင့် ရွှေ့ပြောင်းငွေ"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("ဘဏ်အကောင့် ငွေကြေး"),
        "bankInformation": MessageLookupByLibrary.simpleMessage("ဘဏ်အချက်များ"),
        "bankName": MessageLookupByLibrary.simpleMessage("ဘဏ်အမည်"),
        "bankTransfer":
            MessageLookupByLibrary.simpleMessage("ဘဏ်လွှဲပြောင်းမှု"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("ဘားကုဒ်ကိုတွေ့ရှိခဲ့သည်"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("ဘီလ်/လိပ်စာ"),
        "billTo": MessageLookupByLibrary.simpleMessage("ဘီလ်အက်င်"),
        "branchName": MessageLookupByLibrary.simpleMessage("အခြားအချက်အလက်"),
        "brand": MessageLookupByLibrary.simpleMessage("ကုန်ပစ္စည်း"),
        "brandName": MessageLookupByLibrary.simpleMessage("ကုန်ပစ္စည်းအမည်"),
        "bulkUpload":
            MessageLookupByLibrary.simpleMessage("အစုလိုက် \nအပ်ဒိတ်"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("လုပ်ငန်းအမျိုးအစား"),
        "buy": MessageLookupByLibrary.simpleMessage("ဝယ်ယူ"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("အထူးအကြောင်းဝယ်ပါ"),
        "buySms": MessageLookupByLibrary.simpleMessage("SMS ဝယ်မည်"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "By accessing or using the Point of Sale (POS) System (the \"System\") provided by [Your Company Name] (\"Company\"), you agree to be bound by these Terms of Use. If you do not agree to these Terms of Use, do not use the System."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) You are responsible for ensuring that your\naccess to and use of the System is in\ncompliance with all applicable laws and\nregulations."),
        "cacel": MessageLookupByLibrary.simpleMessage("ပယ်ဖျက်မည်"),
        "call": MessageLookupByLibrary.simpleMessage("ခေါ်ဆိုပါ"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "အရေးပေါ် ကူညီမှုအတွက် ဖုန်းခေါ်ပါ"),
        "camera": MessageLookupByLibrary.simpleMessage("ကင်မရာ"),
        "cancel": MessageLookupByLibrary.simpleMessage("မလုပ်တော့ပါ"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("ကုန်ပစ္စည်းအားလုံးဖျက်ပါ"),
        "capacity": MessageLookupByLibrary.simpleMessage("အရှေ့ဆုံးရမ်"),
        "card": MessageLookupByLibrary.simpleMessage("ကတ်"),
        "cash": MessageLookupByLibrary.simpleMessage("ငွေ"),
        "cashFree": MessageLookupByLibrary.simpleMessage("ငွေကြေးလွတ်"),
        "categories": MessageLookupByLibrary.simpleMessage("အမျိုးအစားများ"),
        "category": MessageLookupByLibrary.simpleMessage("အမျိုးအစား"),
        "categoryName":
            MessageLookupByLibrary.simpleMessage("အမျိုးအစား နာမည်"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "အမျိုးအစား နာမည် ကြားထဲရှိသည်"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("အမျိုးအစားအမည်"),
        "change": MessageLookupByLibrary.simpleMessage("ပြောင်းရန်"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("စကားဝှက်ကိုပြောင်းရန်"),
        "checkEmail":
            MessageLookupByLibrary.simpleMessage("အီးမေးလ်ကိုစစ်ဆေးပါ"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("ဖောက်သည်အားရွေးပါ"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("ကုန်ရောင်းသူကိုရွေးပါ"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("သင်၏အကြောင်းအရင်းရွေးချယ်ပါ"),
        "clarence": MessageLookupByLibrary.simpleMessage("အမှိုက်ပြီး"),
        "clickToConnect": MessageLookupByLibrary.simpleMessage("ချိတ်ဆက်မည်ပါ"),
        "close": MessageLookupByLibrary.simpleMessage("ပိတ်မည်"),
        "color": MessageLookupByLibrary.simpleMessage("အရောင်"),
        "combinationOfMultipleTaxes":
            MessageLookupByLibrary.simpleMessage("(အခွန်များ၏ ပေါင်းစပ်ခြင်း)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("ရောက်လာမည်"),
        "companyAddress": MessageLookupByLibrary.simpleMessage("ကုမ္ပဏီလိပ်စာ"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("ကုမ္ပဏီနှင့်ဆိုင်းအမည်"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("ကုမ္ပဏီနှင့် စီးပွားရေးအမည်"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("ငွေသားအသင်းကိုပြီးဆုံးမည်"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("အတည်ပြုကာကွယ်ရန်"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("ပြန်လည်အတည်ပြုပါ"),
        "congratulations":
            MessageLookupByLibrary.simpleMessage("ဂျပန်စခန်းကျွန်ုပ်သို့"),
        "contactUs": MessageLookupByLibrary.simpleMessage("ဆက်သွယ်ရန်"),
        "continu": MessageLookupByLibrary.simpleMessage("ဆက်လုပ်မည်"),
        "country": MessageLookupByLibrary.simpleMessage("နိုင်ငံ"),
        "create": MessageLookupByLibrary.simpleMessage("ဖန်တီးရန်"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("အခမဲ့အကောင့်ဖန်တီးပါ"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("ဖန်တီးပြီး သိမ်းဆည်းထားသည်"),
        "currency": MessageLookupByLibrary.simpleMessage("ငွေကြေး"),
        "currentStock": MessageLookupByLibrary.simpleMessage("လက်ရှိစျေးကွက်"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("မူဝါဒအကောင့်ထက်ဆိုင်အရာ"),
        "customer": MessageLookupByLibrary.simpleMessage("ဖောက်သည်"),
        "customerDetails": MessageLookupByLibrary.simpleMessage("အဖအမည်များ"),
        "customerGST": MessageLookupByLibrary.simpleMessage("သုံးစွဲသူ GST"),
        "customerName": MessageLookupByLibrary.simpleMessage("အသုံးပြုသူအမည်"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("နေ့စဉ်အင်တာနက်များ"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Dashboard Overview"),
        "dataSavedSuccessfully": MessageLookupByLibrary.simpleMessage(
            "ဒေတာကိုအောင်မြင်စွာသိမ်းဆည်းပြီး"),
        "date": MessageLookupByLibrary.simpleMessage("ရက်စွဲ"),
        "day": MessageLookupByLibrary.simpleMessage("နေ့"),
        "dealer": MessageLookupByLibrary.simpleMessage("ကုန်ပစ္စည်းရောင်းသူ"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("ဆေးရေးစျေးနှုန်း"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("မူရင်း VAT ရာခိုင်နှုန်း"),
        "delete": MessageLookupByLibrary.simpleMessage("ဖျက်ရန်"),
        "deleting": MessageLookupByLibrary.simpleMessage("ဖျက်သိမ်းနေပါသည်"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("ပေးပို့လိပ်စာ"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("ပို့ဆောင်ရန်လိပ်စာများ"),
        "deliveryCharge": MessageLookupByLibrary.simpleMessage("ပေးပို့ခဲ့သည်"),
        "describtion": MessageLookupByLibrary.simpleMessage("ဖော်ပြချက်"),
        "description": MessageLookupByLibrary.simpleMessage("ဖော်ပြချက်"),
        "descriptionCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "ဖော်ပြချက်သည် လွတ်လပ်လှည့်လျှင် မရပါ"),
        "details": MessageLookupByLibrary.simpleMessage("အသေးစိတ်"),
        "discount": MessageLookupByLibrary.simpleMessage("လျှော့စျေး"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("အကြံ့မပြောနေပါ"),
        "done": MessageLookupByLibrary.simpleMessage("ပြီးခဲ့ပါပြီ"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Excel ပုံစံဒေါင်းလုဒ်"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "ဒေါင်းလုဒ်ဖိုလ်ထဲတွင်အောင်မြင်စွာဒေါင်းလုဒ်လုပ်ပြီးပါပြီ"),
        "due": MessageLookupByLibrary.simpleMessage("ကျန်ငွေသော"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("ကျန်ငွေသောပမာဏ: "),
        "dueCollection":
            MessageLookupByLibrary.simpleMessage("ကျန်ငွေသောစုစုပေါင်း"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("ကျသံတောင်မှု စာရင်းများ"),
        "dueList":
            MessageLookupByLibrary.simpleMessage("ကျန်ငွေသောနောက်ဆုံးစာရင်း"),
        "dueReports": MessageLookupByLibrary.simpleMessage("အကြောင်းအသေးစိတ်"),
        "duration": MessageLookupByLibrary.simpleMessage("ကာလ"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("ကာလ: မှ"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "အကြောင်းအရင်းဖွင့်နံပါတ်အသုံးစရိတ်ဖြစ်စေရန်လိုအပ်သည်"),
        "edit": MessageLookupByLibrary.simpleMessage("ပြင်မည်"),
        "editPurchaseInvoice": MessageLookupByLibrary.simpleMessage(
            "အဝယ်ဘေ့စာမေးပွဲကိုတည်းဖြတ်ပါ"),
        "editSalesInvoice": MessageLookupByLibrary.simpleMessage(
            "ရောင်းအသေးစာမေးပွဲကိုတည်းဖြတ်ပါ"),
        "editSocailMedia": MessageLookupByLibrary.simpleMessage(
            "လျှောက်လှမ်းမည့်အိုင်ဒီနယ်များပြင်ရန်"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("ပြင်ဆင်မှု အောင်မြင်သည်"),
        "editTax": MessageLookupByLibrary.simpleMessage("အခွန် ပြင်ဆင်ပါ"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("အခွန်အုပ်စု ပြင်ဆင်ပါ"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("ကုန်ဆောင်ရုံ ပြင်ဆင်ပါ"),
        "email": MessageLookupByLibrary.simpleMessage("အီးမေးလ်"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("အီးမေးလ်လိပ်စာ"),
        "emailCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "အီးမေးလ်သည်အလွတ်ဖြစ်လို့မရပါ"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "အီးမေးလ်ပို့ပြီး! inbox ကိုစစ်ဆေးပါ"),
        "endDate": MessageLookupByLibrary.simpleMessage("အဆုံးနေ့"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("မှန်ကန်သောငွေပမာဏထည့်ပါ"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("မှန်ကန်သောထုတ်ပေးမှုထည့်ပါ"),
        "enterAValidPhoneNumber":
            MessageLookupByLibrary.simpleMessage("မှန်ကန်သောဖုန်းနံပါတ်ထည့်ပါ"),
        "enterAValidPrice": MessageLookupByLibrary.simpleMessage(
            "မှန်ကန်သော ဈေးနှုန်းကို ထည့်ပါ"),
        "enterAValidQuantity": MessageLookupByLibrary.simpleMessage(
            "မှန်ကန်သော အရေအတွက်ကို ထည့်ပါ"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("လိပ်စာရိုက်ပါ"),
        "enterAmount":
            MessageLookupByLibrary.simpleMessage("ပမာဏအရေအတွက်ထည့်ပါ။"),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("ကုန်ပစ္စည်းအမည်ထည့်ပါ"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("အရှေ့ဆုံးရမ်ထည့်ပါ"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("အမျိုးအစားအမည်ထည့်ပါ"),
        "enterColor": MessageLookupByLibrary.simpleMessage("အရောင်ထည့်ပါ"),
        "enterCustomerGstNumber":
            MessageLookupByLibrary.simpleMessage("သုံးစွဲသူ၏ GST နံပါတ်ထည့်ပါ"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("ဆေးရေးစျေးနှုန်းထည့်ပါ"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("ဖော်ပြချက်ထည့်ပါ"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("လျှော့စျေးရိုက်ထည့်ပါ"),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("အသုံးစရိတ်ရက်စွဲထည့်ပါ"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("လိပ်စာအပြည့်အစုံကိုရိုက်ပါ"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("ဘောင်မဲပေးနံပါတ်ထည့်ပါ"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "ပစ္စည်းပမာဏနည်းလျှင်အကြောင်းကြားချက်အတွက်အရေအတွက်ထည့်ပါ"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("ပစ္စည်းကိုယ်စားလှယ်ထည့်ပါ"),
        "enterMessageContent": MessageLookupByLibrary.simpleMessage(
            "မက်ဆေ့ခ်ျမှတ်ချက်အကြောင်းရိုက်ထည့်ပါ"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "အများစုရေးနှုန်းသို့ရိုက်ထည့်ပါ"),
        "enterName": MessageLookupByLibrary.simpleMessage("နာမည်ထည့်ပါ"),
        "enterNote": MessageLookupByLibrary.simpleMessage("မှတ်ချက်ထည့်ပါ"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("လက်ခံသူအမည်ရိုက်ပါ"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("ဖုန်းနံပါတ်အစရှိသည်"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "ကုန်ပစ္စည်းကုဒ်ထည့်သို့စကန်းရန်သို့ရိုက်ထည့်ပါ"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("ကုန်ပစ္စည်းအမည်ထည့်ပါ"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("ဝယ်ယူရန်စျေးနှုန်းထည့်ပါ"),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("အမြေပေးနံပါတ်ထည့်ပါ"),
        "enterSize": MessageLookupByLibrary.simpleMessage("အရွယ်ထည့်ပါ"),
        "enterStocks":
            MessageLookupByLibrary.simpleMessage("ကုန်ပစ္စည်းကန်နံပါတ်ထည့်ပါ"),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("အခွန်အချိုး ထည့်ပါ"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("ကုန်အကောင့်အမှတ် ထည့်ပါ"),
        "enterType": MessageLookupByLibrary.simpleMessage("အမျိုးအစားထည့်ပါ"),
        "enterUserTitle": MessageLookupByLibrary.simpleMessage(
            "အသုံးပြုသူ ခေါ်ဆိုတဲ့ နာမည် ထည့်ပါ"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("မှန်ကန်သောငွေပမာဏထည့်ပါ"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("ကုန်ဆောင်ရုံ နာမည် ထည့်ပါ"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("အလေးချိန်ထည့်ပါ"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("လက်ကျန်စျေးနှုန်းထည့်ပါ"),
        "enterYourDescriptionHere": MessageLookupByLibrary.simpleMessage(
            "သင်၏ဖော်ပြချက်ကိုဒေတာဘာအားထည့်ပါ"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "သင်၏အီးမေးလ်အကြောင်းကိုရိုက်ပါ"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "သင်၏တုံ့ပြန်ချက်ခေါင်းစဉ်ထည့်ပါ"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("သင့် GST နံပါတ်ထည့်ပါ"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("ဖုန်းနံပါတ်ထည့်ပါ"),
        "enterYourName": MessageLookupByLibrary.simpleMessage("သင်၏အမည်ထည့်ပါ"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("သင်၏ဖုန်းနံပါတ်ကိုရိုက်ပါ"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("သင့်စကားဝှက်ထည့်ပါ"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("သင်၏ဖုန်းနံပါတ်အစရှိသည်"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "ငွေသွင်းငွေသွင်းအချက်အလက်ထည့်ပါ"),
        "error": MessageLookupByLibrary.simpleMessage("အမှား"),
        "excTax": MessageLookupByLibrary.simpleMessage("အခွန်မပါ"),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("Excel အပ်ဒိတ်လုပ်သူ"),
        "exclusive": MessageLookupByLibrary.simpleMessage("ထူးခြားသော"),
        "expense": MessageLookupByLibrary.simpleMessage("ကုန်ကျစရိတ်"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("အသုံးစရိတ်အမျိုးအစား"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("အသုံးစရိတ်ရက်စွဲ"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("အသုံးစရိတ်အတွက်"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("အသုံးစရိတ်အစီရင်ခံစာ"),
        "expireDate": MessageLookupByLibrary.simpleMessage("ကုန်ဆုံးရက်စွဲ"),
        "expired": MessageLookupByLibrary.simpleMessage("ကုန်ဆုံးပြီးပါပြီ"),
        "expiring": MessageLookupByLibrary.simpleMessage("အဆုံးစွန်"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("အမှားဖြင့် ရပ်တန့်သည်"),
        "fashion": MessageLookupByLibrary.simpleMessage("ဖက်ရှင်း"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "အရင်းအမြစ်များသည်မျှော်လင့်ကိုသာစိတ်ကြိုက်သင့်များမှာ Pos Saas ကိုပြောင်းလဲရန်အခက်အခဲတစ်ခုဖြစ်ပါသည်။"),
        "feedBack": MessageLookupByLibrary.simpleMessage("တုံ့ပြန်ချက်"),
        "firstName": MessageLookupByLibrary.simpleMessage("နာမည်အစီအစဉ်"),
        "followUsOnFacebook": MessageLookupByLibrary.simpleMessage(
            "Facebook တွင် ကျွန်ုပ်တို့ကို လိုက်နာပါ"),
        "followUsOnTwitter": MessageLookupByLibrary.simpleMessage(
            "Twitter တွင် ကျွန်ုပ်တို့ကို လိုက်နာပါ"),
        "fontSide": MessageLookupByLibrary.simpleMessage("ဖောင့်စက်"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("အမြင့်ရစျေးကွက်အတွက်"),
        "forgotPassword": MessageLookupByLibrary.simpleMessage(
            "စကားဝှက်မေ့နေသည်ဟု မသိခဲ့ရင်"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("စကားဝှက်မေ့နေပြီးမသိခဲ့ရင်"),
        "formDate": MessageLookupByLibrary.simpleMessage("ရက်စွဲမှ"),
        "freeDataBackup": MessageLookupByLibrary.simpleMessage(
            "အသုံးပြုအချက်အလက် အိတ်ပိုင်ခြင်း"),
        "freeLifeTimeUpdate":
            MessageLookupByLibrary.simpleMessage("အခြားရက်သတ္တပါတယ်အဖွဲ့"),
        "freePacakge":
            MessageLookupByLibrary.simpleMessage("အခုနှင့်အခမဲ့အကြောင်း"),
        "freePlan":
            MessageLookupByLibrary.simpleMessage("အခုနှင့်အခမဲ့အကြောင်း"),
        "from": MessageLookupByLibrary.simpleMessage("(မှ"),
        "fullyPaid":
            MessageLookupByLibrary.simpleMessage("ပြည့်စုံစွာ ငွေပေးချေခဲ့သည်"),
        "gallary": MessageLookupByLibrary.simpleMessage("ဓာတ်ပုံများ"),
        "generatingPDF":
            MessageLookupByLibrary.simpleMessage("PDF ဖန်တီးနေသည်"),
        "getOtp": MessageLookupByLibrary.simpleMessage("OTP ရယူပါ"),
        "govermentId": MessageLookupByLibrary.simpleMessage(
            "နိုင်ငံဆက်သွယ်သူအိုင်တီးနံပါတ်"),
        "guest": MessageLookupByLibrary.simpleMessage("ဧည့်"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("အကောင့်မရှိပါဘူးလား။"),
        "history": MessageLookupByLibrary.simpleMessage("သမိုင်း"),
        "home": MessageLookupByLibrary.simpleMessage("ပင်မစာမျက်နှာ"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "How We Protect Your Information"),
        "howWeUseYourInformation":
            MessageLookupByLibrary.simpleMessage("How We Use Your Information"),
        "identityVerify": MessageLookupByLibrary.simpleMessage(
            "အဆင့်မြှင့်ခြင်းတို့သို့တည်းဖြတ်ပါ"),
        "image": MessageLookupByLibrary.simpleMessage("ပုံ"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("အိမ်တွင်းကို ဖျက်မရပါ"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("အိမ်တွင်းကို ပြင်ဆင်မရပါ"),
        "inWord": MessageLookupByLibrary.simpleMessage("စာဖြင့်"),
        "incTax": MessageLookupByLibrary.simpleMessage("အခွန်ပါ"),
        "inclusive": MessageLookupByLibrary.simpleMessage("ပါဝင်သော"),
        "increaseStock":
            MessageLookupByLibrary.simpleMessage("စတော့ပမာဏ တိုးမြှင့်ပါ"),
        "inistrument": MessageLookupByLibrary.simpleMessage("အင်တာနက်"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("ဝယ်ယူမဲပေးနံပါတ်"),
        "invoice": MessageLookupByLibrary.simpleMessage("ငွေထုတ်ပေးစာ"),
        "invoiceNumber":
            MessageLookupByLibrary.simpleMessage("ဘောင်မဲပေးနံပါတ်"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("ဘောင်ချာနံပါတ်ဆက်တင်ရန်"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("ငွေထုတ်ပေးစာကြည့်ရှုသူ"),
        "itemAdded":
            MessageLookupByLibrary.simpleMessage("ကုန်ပစ္စည်းထည့်ပြီး"),
        "kg": MessageLookupByLibrary.simpleMessage("ကီလိုဂရမ်"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("ကြိုတင်ကြောင်းစစ်ခြင်း"),
        "language": MessageLookupByLibrary.simpleMessage("ဘာသာစကား"),
        "lastName": MessageLookupByLibrary.simpleMessage("မက်စီအမည်"),
        "ledger": MessageLookupByLibrary.simpleMessage("ကဘောင်ချာ"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("အဆုံးအနှစ်ခုဝယ်ယူရန်"),
        "link": MessageLookupByLibrary.simpleMessage("လင်ခဲ့သည်"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("တိုက်ရိုက် စကားပြော ကူညီမှု"),
        "loading": MessageLookupByLibrary.simpleMessage("ထုတ်ယူနေသည်"),
        "logIn": MessageLookupByLibrary.simpleMessage("အကောင့်ဝင်ရန်"),
        "logOUt": MessageLookupByLibrary.simpleMessage("အကောင့်ထွက်မည်"),
        "logOut": MessageLookupByLibrary.simpleMessage("ထွက်ပြေးပါ"),
        "login": MessageLookupByLibrary.simpleMessage("အကောင့်ဝင်ရန်"),
        "logo": MessageLookupByLibrary.simpleMessage("လိုဂို"),
        "loss": MessageLookupByLibrary.simpleMessage("ကျန်တော့"),
        "lossOrProfit":
            MessageLookupByLibrary.simpleMessage("ကျန်တော့/အရောင်း"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("ကျန်တော့/အရောင်း အသေးစိတ်"),
        "lossProfitReport": MessageLookupByLibrary.simpleMessage(
            "အကျိုးအမြတ်နှင့် အဆုံးအမြတ်အစီရင်ခံစာ"),
        "lossProfitReports": MessageLookupByLibrary.simpleMessage(
            "အကျိုးအမြတ်နှင့် အဆုံးအမြတ်အစီရင်ခံစာများ"),
        "lowStockAlert": MessageLookupByLibrary.simpleMessage(
            "ပစ္စည်းပမာဏနည်းသောအကြောင်းကြားချက်"),
        "maan": MessageLookupByLibrary.simpleMessage("မအန်"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "အမှတ်တံဆိပ်ပါ ငွေတောင်းခံလွှာများဖြင့် သင့်ဖောက်သည်များအပေါ် ရေရှည်အထင်ကြီးစေပါ။ ကျွန်ုပ်တို့၏ အကန့်အသတ်မဲ့ အဆင့်မြှင့်တင်မှုသည် သင့်ငွေတောင်းခံလွှာများကို စိတ်ကြိုက်ပြင်ဆင်ခြင်း၏ ပြိုင်ဘက်ကင်းသောအားသာချက်ကို ပေးဆောင်ပြီး သင့်အမှတ်တံဆိပ်အထောက်အထားကို အားဖြည့်ပေးပြီး ဖောက်သည်၏သစ္စာစောင့်သိမှုကို မြှင့်တင်ပေးသည့် ပရော်ဖက်ရှင်နယ်အထိအတွေ့ကို ထည့်သွင်းပေးပါသည်။"),
        "manageYourBussinessWith": MessageLookupByLibrary.simpleMessage(
            "သင်၏စီးပွားရေးကို စီးပွားရှင်းနှင့်ခွဲခြားရန် "),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("ထုတ်လုပ်သောရက်စွဲ"),
        "margin": MessageLookupByLibrary.simpleMessage("အမြတ်"),
        "masterCard": MessageLookupByLibrary.simpleMessage("မက်စ်ကဒ်"),
        "menufeturer":
            MessageLookupByLibrary.simpleMessage("ပစ္စည်းကိုယ်စားလှယ်"),
        "message": MessageLookupByLibrary.simpleMessage("မက်ဆေ့ခ်ျပါ"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("မက်ဆေ့ခ်ျမှတ်တမ်းသမိုင်း"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Pos Saas အက်ပလီကေးရှင်အကောင့်အဆင့်မှတစ်ဆင့်အသုံးပြုသူအဆင့်မြှင့်တောင်းအကောင်းကိုအသုံးပြုရန်အဆင့်တစ်စင်ခြင်း ကိုအချို့မရရှိပါ။ အကြောင်းအရင်းဖွင့်ရမည်၊ ဒါဟာ ကျောင်းပျက်လက်ကောင်း POS စနစ်တစ်ခုဖြစ်ပါသည်။"),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas သည်စတိုး၊ အကောင့်၊ အကောင့်၊ အောင်မြင်မှုနှင့်အတူအကြောင်းအရင်းရွေးချယ်ရန်အကြောင်းအရင်းဖြစ်ပါသည်။"),
        "mobile": MessageLookupByLibrary.simpleMessage("မိုဘိုင်း"),
        "mobilePayment":
            MessageLookupByLibrary.simpleMessage("မိုဘိုင်းငွေပေးချေမှု"),
        "monthly": MessageLookupByLibrary.simpleMessage("လစဉ်းကန့်"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("အချက်အလက်"),
        "name": MessageLookupByLibrary.simpleMessage("သင်၏အမည်ထည့်ပါ။"),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("နာမည် ကြားထဲရှိပါသည်"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("နာမည် သေးရင်မရပါ"),
        "next": MessageLookupByLibrary.simpleMessage("နောက်တစ်ခု"),
        "noConnection":
            MessageLookupByLibrary.simpleMessage("ချိတ်ဆက်မှုမရှိပါ"),
        "noData": MessageLookupByLibrary.simpleMessage("အချက်အလက်မရှိပါ"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("အချက်အလက်မရရှိနိုင်ပါ"),
        "noDataFound": MessageLookupByLibrary.simpleMessage("ဒေတာ မတွေ့ပါ"),
        "noHistoryFound": MessageLookupByLibrary.simpleMessage("မရှိသေးပါ"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("ထုတ်ကုန်မရှိပါ"),
        "noSubTaxSelected": MessageLookupByLibrary.simpleMessage(
            "အောက်ခံ အခွန် ရွေးချယ်ထားခြင်းမရှိပါ"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("ငွေသားအသင်းမရှိပါ"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "ဤအီးမေးလ်အတွက် အသုံးပြုသူမရှိပါ။"),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "အသုံးပြုသူ ရာခိုင်နှုန်း မရှိပါ"),
        "notActiveUser": MessageLookupByLibrary.simpleMessage(
            "ကျွန်ုပ်တို့တွင် အထွေထွေ မရှိပါ"),
        "notProvided": MessageLookupByLibrary.simpleMessage("မပေးထားပါ"),
        "note": MessageLookupByLibrary.simpleMessage("မှတ်ချက်"),
        "notes": MessageLookupByLibrary.simpleMessage("မှတ်စုများ"),
        "notification": MessageLookupByLibrary.simpleMessage("အသိပေးချက်"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP ကိုပို့ခဲ့သည်"),
        "office": MessageLookupByLibrary.simpleMessage("ရုံး"),
        "ok": MessageLookupByLibrary.simpleMessage("အိုက"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS that contains a great deal of functionality, including sales tracking, inventory management."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "This system helps you improve your operations for your customers."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Our POS system should simplify daily operations automatically, making it easy to navigate."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("ပိတ်ဆုံးဖွဲ့ရန်"),
        "order": MessageLookupByLibrary.simpleMessage("အမှာစာ"),
        "other": MessageLookupByLibrary.simpleMessage("အခြား"),
        "otp": MessageLookupByLibrary.simpleMessage("ပိတ်"),
        "outOfStock":
            MessageLookupByLibrary.simpleMessage("ဆိပ်ကမ်းအတွင်း မရရှိနိုင်ပါ"),
        "pacakge": MessageLookupByLibrary.simpleMessage("ပါကစ်"),
        "packageFeatures": MessageLookupByLibrary.simpleMessage(
            "အကောင့်ပိုင်းအရင်းရွေးချယ်ခြင်းများ"),
        "paid": MessageLookupByLibrary.simpleMessage("ပေးခဲ့သည်"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("ပေးချေသည့်ပမာဏ"),
        "parties": MessageLookupByLibrary.simpleMessage("လက်ခံသူများ"),
        "partiesList": MessageLookupByLibrary.simpleMessage("လက်ခံသူစာရင်း"),
        "partyGST": MessageLookupByLibrary.simpleMessage("ပါတီ GST"),
        "partyName": MessageLookupByLibrary.simpleMessage("လက်ခံသူအမည်"),
        "password": MessageLookupByLibrary.simpleMessage("စကားဝှက်"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "လျှို့ဝှက်နံပါတ်နှင့် အတည်ပြုလျှို့ဝှက်နံပါတ် မကိုက်ညီပါ"),
        "passwordCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "စကားဝှက်သည်အလွတ်ဖြစ်လို့မရပါ"),
        "passwordNotMach": MessageLookupByLibrary.simpleMessage("စကားဝှက်မတူ"),
        "payCash": MessageLookupByLibrary.simpleMessage("ငွေသားချယ်ရန်"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("Bkash နှင့် ငွေပေးချေမှု"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("PayPal နှင့် ငွေပေးချေမှု"),
        "payeeName": MessageLookupByLibrary.simpleMessage("လစာပို့သူအမည်"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("လစာပို့သူနံပါတ်"),
        "payment": MessageLookupByLibrary.simpleMessage("ငွေပေးချေရန်"),
        "paymentAmount":
            MessageLookupByLibrary.simpleMessage("ငွေပေးချေရေငုပမာဏ"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("ငွေပေးချေရန်အားပြီးစီး"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("ငွေပေးချေမှုကိုအတည်ပြုရန်:"),
        "paymentMethod":
            MessageLookupByLibrary.simpleMessage("ငွေပေးချေမှု နည်းလမ်း"),
        "paymentType":
            MessageLookupByLibrary.simpleMessage("ငွေပေးချေရန်အမျိုးအစား"),
        "pdfView": MessageLookupByLibrary.simpleMessage("PDF ကြည့်ရန်"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("ကိုယ်ရေးအချက်အလက်များ"),
        "phone": MessageLookupByLibrary.simpleMessage("ဖုန်း"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("ဖုန်းနံပါတ်"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "ဖုန်းနံပါတ်ကို ယခင်မှာ အသုံးပြုခဲ့ပါပြီ"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("ဖုန်းနံပါတ်မှန်ကန်မှုမရှိပါ"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("ဖုန်းနံပါတ်လိုအပ်သည်"),
        "pickAndUploadFile": MessageLookupByLibrary.simpleMessage(
            "ဖိုင်ကိုရွေးချယ်ပြီးအပ်ဒိတ်လုပ်ပါ"),
        "pickEndDate": MessageLookupByLibrary.simpleMessage("အဆုံးနေ့ရွေးပါ"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("စတင်ခဲ့သည်နေ့ရွေးပါ"),
        "plan": MessageLookupByLibrary.simpleMessage("အစီအစဉ်"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("အရေအတွက်ထည့်ပါ"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "အင်တာနက်သို့သွားရန် သင်၏အင်တာနက်ကိုစစ်ဆေးပါ"),
        "pleaseConnectThePrinterFirst":
            MessageLookupByLibrary.simpleMessage("ပရင်တာကိုပထမဦးစွာချိတ်ဆက်ပါ"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "ကုန်ပစ္စည်းသင့် bluetooth ပရိတ်ကို ချိတ်ဆက်ပါ"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "ကျေးဇူးပြု၍ စကားဝှက်ကြီးတစ်ခုထည့်ပါ"),
        "pleaseEnterAConfirmPassword":
            MessageLookupByLibrary.simpleMessage("အတည်ပြုရန်ကာကွယ်ထည့်ပါ"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("စကားဝှက်ကိုရိုက်ပါ"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "ကျေးဇူးပြု၍သင့်အီးမေးလ်ကိုမှန်ကန်စွာထည့်ပါ"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("ကျေးဇူးပြု၍ နာမည်ထည့်ပါ"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("လျှို့ဝှက်နံပါတ် ထည့်ပါ"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "စကားဝှက်မေ့နံပါတ်အကြောင်းကို ရယူရန်အီးမေးလ်လိပ်စာကိုရိုက်ထည့်ပါ။"),
        "pleaseEnterTransactionNumber":
            MessageLookupByLibrary.simpleMessage("ငွေလွှဲနံပါတ်ကို ထည့်ပါ"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("ကျေးဇူးပြု၍ ငွေပမာဏထည့်ပါ"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "ပထမဦးဆုံး အမျိုးအစားကိုရွေးချယ်ပါ"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("အစီအစဉ်ကို ရွေးချယ်ပါ"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "လုပ်ငန်းအမျိုးအစားကိုရွေးချယ်ပါ"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "အက်ပ်ကို အသုံးပြုရန် မှန်ကန်သော ဝယ်ယူမှု ကုဒ်ကို အသုံးပြုပါ"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Pos Saas အား တက်သွင်းပါသည်"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("ပံ့ပိုးသည်"),
        "premiumCustomerSupport": MessageLookupByLibrary.simpleMessage(
            "အဖွဲ့ အသုံးပြုသူ ကိုယ်ရေးရေးချယ်ရန်"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("အထူးအကြောင်း"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("ယခင်ပေးဆောင်မှုပမာဏများ"),
        "price": MessageLookupByLibrary.simpleMessage("စျေးနှုန်း"),
        "print": MessageLookupByLibrary.simpleMessage("ပုံနှိပ်ပါ"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("ပရော်တိုက်ရေးပမာဏ"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("လုံခြုံ အုပ်ချုပ်"),
        "product": MessageLookupByLibrary.simpleMessage("အကြောင်း"),
        "productCode": MessageLookupByLibrary.simpleMessage("ကုန်ပစ္စည်းကုဒ်"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("ကုန်ပစ္စည်းကုဒ်လိုအပ်သည်"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("ထုတ်ကုန်ကုဒ်/အမည်"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("ထုတ်ကုန်အကြောင်းအရာ"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("ကုန်ပစ္စည်းအသေးစိတ်"),
        "productList":
            MessageLookupByLibrary.simpleMessage("ကုန်ပစ္စည်းစာရင်း"),
        "productName": MessageLookupByLibrary.simpleMessage("ကုန်ပစ္စည်းအမည်"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "ကုန်ပစ္စည်းအမည်သည်ဤအထုပ်တွင်မည်မဟုတ်ပါ"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "ထုတ်ကုန်အမည်ကို အရင်ရောက်ရှိပြီးသားပါ"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("ကုန်ပစ္စည်းအမည်လိုအပ်သည်"),
        "products": MessageLookupByLibrary.simpleMessage("ထုတ်ကုန်များ"),
        "profile": MessageLookupByLibrary.simpleMessage("ပရိုဖိုင်"),
        "profileEdit":
            MessageLookupByLibrary.simpleMessage("ပရိုပိုဆိုး တည်ဆောက်ရန်"),
        "profit": MessageLookupByLibrary.simpleMessage("အရောင်း"),
        "promo": MessageLookupByLibrary.simpleMessage("ပရိုမို"),
        "promoCode": MessageLookupByLibrary.simpleMessage("ပရိုမိုကုဒ်"),
        "purchase": MessageLookupByLibrary.simpleMessage("အဝယ်"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("ဝယ်ခဲ့သောမီလာမှု"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("ဝယ်ယူထားသည်"),
        "purchaseDetails": MessageLookupByLibrary.simpleMessage("အဝယ်အသေးစိတ်"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("ဝယ်ယူမှုလိပ်စာ"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("အဝယ်စာရင်း"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("ယခုဝယ်ယူပါ"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("အထူးအကြောင်းဝယ်ယူပါ"),
        "purchasePrice":
            MessageLookupByLibrary.simpleMessage("ဝယ်ယူရန်စျေးနှုန်း"),
        "purchasePriceIsRequired": MessageLookupByLibrary.simpleMessage(
            "ဝယ်ယူရောင်းရင်စျေးနှုန်းလိုအပ်သည်"),
        "purchaseRepoet": MessageLookupByLibrary.simpleMessage("အဝယ်အသေးစိတ်"),
        "purchaseReports": MessageLookupByLibrary.simpleMessage("အဝယ်အသေးစိတ်"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("အဝယ် စာရင်းများ"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("ဝယ်ယူမှု ပြန်လည်"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("ဝယ်ယူမှု ပြန်လည်အစီရင်ခံစာ"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("ဝယ်ယူမှု လှည့်လည်မှု"),
        "qty": MessageLookupByLibrary.simpleMessage("အရေအတွက်"),
        "quantity": MessageLookupByLibrary.simpleMessage("အရေအတွက်"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("လက်ရှိသင့်လုပ်ဆောင်မှုများ"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("PIN ကိုလက်ခံသည်"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("အမြေပေးနံပါတ်"),
        "register": MessageLookupByLibrary.simpleMessage("မှတ်ပုံတင်ရန်"),
        "registering": MessageLookupByLibrary.simpleMessage("မှတ်ပုံတင်နေသည်"),
        "remainingDue":
            MessageLookupByLibrary.simpleMessage("ကျသင့်ရက်ပစ်ကျသင့်"),
        "remove": MessageLookupByLibrary.simpleMessage("ဖျက်ပါ"),
        "reports": MessageLookupByLibrary.simpleMessage("အစီရင်ခံစာများ"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("တောင်းဆိုချက်ပို့ပြီးပါပြီ"),
        "resendCode": MessageLookupByLibrary.simpleMessage("ကုဒ်ပြန်ပို့ပါ"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("OTP ပြန်ပို့ရန်: "),
        "retailer": MessageLookupByLibrary.simpleMessage("ကုန်ပစ္စည်းရောင်းသူ"),
        "retur": MessageLookupByLibrary.simpleMessage("ပြန်သွားမည်"),
        "returN": MessageLookupByLibrary.simpleMessage("ပြန်"),
        "returnAMount":
            MessageLookupByLibrary.simpleMessage("ပြန်မှတ်တမ်းက်ငွေ"),
        "returnAmount":
            MessageLookupByLibrary.simpleMessage("ပြန်မှတ်တမ်းက်ငွေ"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("ပြန်လည်အရေအတွက်"),
        "revenue": MessageLookupByLibrary.simpleMessage("ဝင်ငွေ"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "သင့်လုပ်ငန်းဒေတာကို စိုက်ထုတ်ကာကွယ်ပါ။ ကျွန်ုပ်တို့၏ Pos Saas POS Unlimited Upgrade တွင် အခမဲ့ဒေတာ အရန်ကူးခြင်း ပါ၀င်ပြီး သင့်တန်ဖိုးရှိသော အချက်အလက်များကို ကြိုမမြင်နိုင်သော အဖြစ်အပျက်များမှ ကာကွယ်ထားကြောင်း သေချာစေပါသည်။ အမှန်တကယ်အရေးကြီးသောအရာကို အာရုံစိုက်ပါ - သင့်လုပ်ငန်းတိုးတက်မှု။"),
        "saleAmount": MessageLookupByLibrary.simpleMessage("ရောင်းချမှု ပမာဏ"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("ရောင်းအသေးစိတ်"),
        "salePrice": MessageLookupByLibrary.simpleMessage("ရောင်းစျေး"),
        "saleReports": MessageLookupByLibrary.simpleMessage("ရောင်းအသေးစိတ်"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("ရောင်း စာရင်းများ"),
        "saleReturn":
            MessageLookupByLibrary.simpleMessage("ရောင်းချမှု ပြန်လည်လက်ခံမှု"),
        "saleReturnReport": MessageLookupByLibrary.simpleMessage(
            "ရောင်းချမှု ပြန်လည်အစီရင်ခံစာ"),
        "saleSetting":
            MessageLookupByLibrary.simpleMessage("ရောင်းချမှု သတ်မှတ်ချက်"),
        "sales": MessageLookupByLibrary.simpleMessage("အေရာင်းအဝယ်များ"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("Sale & Purchase Reports"),
        "salesList": MessageLookupByLibrary.simpleMessage("ရောင်းအသေးစာရင်း"),
        "salesReturn":
            MessageLookupByLibrary.simpleMessage("ရောင်းချမှု ပြန်လည်လက်ခံမှု"),
        "save": MessageLookupByLibrary.simpleMessage("သိမ်းမည်"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("သိမ်းဆည်းနှင့် ထုတ်ပြန်ပါ"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("ပြင်ဆင်မည်"),
        "saving": MessageLookupByLibrary.simpleMessage("သိမ်းဆည်းခြင်း"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("ထုတ်ကုန် QR ကုဒ်ကို စကန်ပါ"),
        "search": MessageLookupByLibrary.simpleMessage("ရှာဖွေရန်"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "ထုတ်ကုန်ကုဒ် သို့မဟုတ် အမည်ဖြင့်ရှာဖွေပါ"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("ပရိုမိုကုဒ်အားလုံးကြည့်မည်"),
        "select": MessageLookupByLibrary.simpleMessage("ရွေးချယ်မည်"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "ပြန်လည်ရန်ထုတ်ကုန်တစ်ခုကိုရွေးချယ်ပါ"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("ဘရန်းရွေးချယ်ပါ"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("အမျိုးအစားကိုရွေးချယ်ပါ"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("ဆက်သွယ်သူများရွေးပါ"),
        "selectProductCategory": MessageLookupByLibrary.simpleMessage(
            "ကုန်ပစ္စည်းအမျိုးအစားရွေးချယ်ပါ"),
        "selectShopCategory": MessageLookupByLibrary.simpleMessage(
            "ဆိုင်အမျိုးအစားကိုရွေးချယ်ပါ"),
        "selectTax": MessageLookupByLibrary.simpleMessage("အခွန်ရွေးချယ်ပါ"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("အခွန်အမျိုးအစားရွေးချယ်ပါ"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("ယူနစ်ရွေးချယ်ပါ"),
        "selectvariations": MessageLookupByLibrary.simpleMessage(
            "ရွေးချယ်ရန်စီရင်းကြားရွေးချယ်ခြင်း: "),
        "seller": MessageLookupByLibrary.simpleMessage("အရောင်းသူ"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("ရောင်းသူ"),
        "send": MessageLookupByLibrary.simpleMessage("ပို့ပါ"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("အီးမေးလ်ပို့ရန်"),
        "sendMessage":
            MessageLookupByLibrary.simpleMessage("မက်ဆေ့ခ်ျကိုပို့ပါ"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("စကားဝှက်မေ့နံပါတ်ကို ပို့ပါ"),
        "sendSms": MessageLookupByLibrary.simpleMessage("မက်ဆေ့ခ်ျပို့ရန်"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("SMS ပေးပို့မည်လား"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("WhatsApp သို့ စာပို့မည်"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("သင်၏အီးမေးလ်ပို့ပါ"),
        "sendingEmail":
            MessageLookupByLibrary.simpleMessage("အီးမေးလ်ပို့နေသည်"),
        "sendingMessage": MessageLookupByLibrary.simpleMessage("စာပို့နေသည်"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("ဝန်ဆောင်မှု/ပို့်မောင်း"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("သင်၏ကိုယ်ရေးကို တပ်ဆင်ပါ"),
        "setting": MessageLookupByLibrary.simpleMessage("ဆက်တင်များ"),
        "share": MessageLookupByLibrary.simpleMessage("မျှဝေ"),
        "shopGST": MessageLookupByLibrary.simpleMessage("ဆိုင် GST"),
        "signIn": MessageLookupByLibrary.simpleMessage("လော့ဂ်အင်ဝင်မည်"),
        "signInWithEmail": MessageLookupByLibrary.simpleMessage(
            "အီးမေးလ်ဖြင့် လော့ဂ်အင်ဝင်ပါ"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("သုံးစွဲသူ လက်မှတ်"),
        "size": MessageLookupByLibrary.simpleMessage("အရွယ်"),
        "skip": MessageLookupByLibrary.simpleMessage("လက်ကျန်ရှိပါ"),
        "sms": MessageLookupByLibrary.simpleMessage("ဆဆစ်"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("လျှောက်လှမ်းစီးပွားရေး"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "ခွင့်ပြုချက်မရှိသောဝန်ဆောင်မှုကိုရောက်ရှိခြင်းအတွက်တောင်းပန်ပါသည်"),
        "startDate": MessageLookupByLibrary.simpleMessage("စတင်ခဲ့သည်နေ့"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("အသစ်တစ်ခုစတင်မည်"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage(
            "ရှာဖွေရန်အစတစ်ကြောင်းရိုက်ထည့်ပါ"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "အပိုကုန်ကျစရိတ်မရှိဘဲ နည်းပညာတိုးတက်မှု၏ ရှေ့တန်းတွင်နေပါ။ ကျွန်ုပ်တို့၏ Pos Saas POS Unlimited Upgrade သည် သင့်တွင် နောက်ဆုံးပေါ်ကိရိယာများနှင့် အင်္ဂါရပ်များကို သင့်လက်ချောင်းထိပ်တွင် အမြဲရှိနေစေရန် သေချာစေကာ သင့်လုပ်ငန်းသည် ခေတ်မီနေသေးကြောင်း အာမခံပါသည်။"),
        "stillUnpaid":
            MessageLookupByLibrary.simpleMessage("လက်ကျန် ငွေပေးချေမှုရှိသည်"),
        "stock": MessageLookupByLibrary.simpleMessage("ဆိပ်ကမ်း"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("ပစ္စည်းရောင်းရန်လိုအပ်သည်"),
        "stockList": MessageLookupByLibrary.simpleMessage("ကုန်ပစ္စည်းစာရင်း"),
        "stocks": MessageLookupByLibrary.simpleMessage("ကုန်ပစ္စည်းကန်နံပါတ်"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Excel ဖိုင်ဖန်တီးရန်သိုလှောင်မှုခွင့်ပြုချက်လိုအပ်သည်"),
        "subTaxList":
            MessageLookupByLibrary.simpleMessage("အောက်ခံ အခွန်စာရင်း"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("အောက်ခံ အခွန်များ"),
        "subTotal": MessageLookupByLibrary.simpleMessage("စုစုပေါင်း"),
        "submit": MessageLookupByLibrary.simpleMessage("တင်သွင်းမည်"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "YouTube တွင် ကျွန်ုပ်တို့ကို စာရင်းသွင်းပါ"),
        "subscription": MessageLookupByLibrary.simpleMessage("စာရင်းပေးခြင်း"),
        "successfullyDone": MessageLookupByLibrary.simpleMessage(
            "အောင်မြင်စွာပြီးမြောက်ခဲ့သည်"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("ထွက်ပြေးပြီးပါပြီ"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("အောင်မြင်စွာ အဆင်ပြေသည်"),
        "supplier": MessageLookupByLibrary.simpleMessage("ကုန်ပစ္စည်းရောင်း"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("ကုန်ရောင်းသူအမည်"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT ကုဒ်"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "ယာဥ်အကျယ်လစ်တက္ကသော လှိုင်သားမားအောက်ကုန်ဖြင့် အောက်မှာရိုက်ထည့်ပါ"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "သင့်အချက်အလက်ကိုစစ်ဆေးရန် NID ကဒ်ကိုရယူပါ"),
        "tap": MessageLookupByLibrary.simpleMessage("တင်ပါ"),
        "tax": MessageLookupByLibrary.simpleMessage("အခွန်"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("အခွန်အုပ်စု"),
        "taxPercentage":
            MessageLookupByLibrary.simpleMessage("အခွန် ရာခိုင်နှုန်း"),
        "taxRate": MessageLookupByLibrary.simpleMessage("အခွန်အချိုး"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "အခွန်အချိုးများ - သင့်အခွန်အချိုးများကို စီမံပါ"),
        "taxReport": MessageLookupByLibrary.simpleMessage("အခွန် အစီရင်ခံစာ"),
        "taxType": MessageLookupByLibrary.simpleMessage("အခွန်အမျိုးအစား"),
        "taxes": MessageLookupByLibrary.simpleMessage("အခွန်များ"),
        "termsAndConditions": MessageLookupByLibrary.simpleMessage(
            "အခြေခံစည်းမျဉ်းနှင့် အဆင်ပြေအခြေအနေများ"),
        "termsOfUse":
            MessageLookupByLibrary.simpleMessage("အသုံးပြုအုပ်ချုပ်များ"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("အသုံးပြုချက်နှင့် သာမန်ရုံ"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "သင်၏ကျသင့်ပေးချေစောင့်အာမခံစာမှကောင်းပါသည်"),
        "thankYou": MessageLookupByLibrary.simpleMessage("ကျေးဇူးတင်ပါတယ်"),
        "thankYouForYourPurchase": MessageLookupByLibrary.simpleMessage(
            "အရောင်းဝယ်ခဲ့သောအချက်အလက်အားတင်ပြရန်ကူညီပါသည်"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "ထိုအီးမေးလ်အတွက် အကောင့် ရှိပြီးသားဖြစ်သည်"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Excel ဖိုင်ကိုရယူပြီးသားဖြစ်သည်"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "နာမည်က အကုန်ပြောတယ်။ Pos Saas POS Unlimited ဖြင့်၊ သင့်အသုံးပြုမှုအတွက် ကန့်သတ်ချက်မရှိပါ။ လက်တစ်ဆုပ်စာ အရောင်းအ၀ယ်လုပ်နေသည်ဖြစ်စေ သို့မဟုတ် ဖောက်သည်များ အလျင်စလိုကြုံနေရသည်ဖြစ်စေ သင်သည် ကန့်သတ်ချက်များဖြင့် ကန့်သတ်ချုပ်ချယ်ထားခြင်း မရှိကြောင်းကို ယုံကြည်စိတ်ချစွာဖြင့် လည်ပတ်နိုင်သည်"),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "ပေးထားသော လျှို့ဝှက်နံပါတ် အားနည်းလွန်းသည်"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "ရောင်းချမှုကို ဖျက်ပစ်မည်နှင့် ဤဝယ်ယူမှုအတွက် အချက်အလက်အားလုံးကို ဖျက်ပစ်မည်။ ဖျက်မလား?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "ရောင်းချမှုကို ဖျက်သိမ်းမည်၊ ဤရောင်းချမှုနှင့် ပတ်သက်သော အချက်အလက်အားလုံး ဖျက်သိမ်းမည်။ ဤကို ဖျက်သိမ်းရန် အတည်ပြုပါ။"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "ဤအသုံးပြုသူကို ဖျက်နိုင်သောနောက်ဆုံးအကြောင်းသည်သင်၏အကောင့်မှာဖျက်နိုင်သည်နှင့်အချက်အလက်အားဖျက်မည်။ သင်သို့ဖျက်မလား?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "အသုံးပြုသူကိုဖျက်ရန်ရှိပြီး အချက်အလက်အားလုံးကို သင့်အကောင့်မှဖျက်မည်။ ဤအသုံးပြုသူကိုဖျက်ရန်သေချာပါသလား"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Third-Party Services"),
        "thisCategoryCannotBeDeleted":
            MessageLookupByLibrary.simpleMessage("ဤအမျိုးအစားကို ဖျက်မရပါ"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(ဒီလ)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "ဤကုန်ပစ္စည်းသည်အထုပ်ထဲတွင်ထည့်ပြီးသားပါ"),
        "title": MessageLookupByLibrary.simpleMessage("ခေါင်းစဉ်"),
        "titleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "ခေါင်းစဉ်သည် လွတ်လပ်လှည့်လျှင် မရပါ"),
        "to": MessageLookupByLibrary.simpleMessage("ထဲသို့"),
        "toDate": MessageLookupByLibrary.simpleMessage("ရက်စွဲအထိ"),
        "today": MessageLookupByLibrary.simpleMessage("ယနေ့"),
        "total": MessageLookupByLibrary.simpleMessage("စုစုပေါင်း"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("စုစုပေါင်းပမာဏ"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("စုစုပေါင်း စုဆောင်းထားသည်"),
        "totalDue": MessageLookupByLibrary.simpleMessage("စုစုပေါင်းကျသင့်"),
        "totalExpense":
            MessageLookupByLibrary.simpleMessage("အသုံးစရိတ်စုစုပေါင်း"),
        "totalLoss":
            MessageLookupByLibrary.simpleMessage("စုစုပေါင်းပျောက်ဆုံးမှု"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("စုစုပေါင်းကောက်ခံမှု"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("စုစုပေါင်းကို"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("စုစုပေါင်းထုတ်ကုန်များ"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("စုစုပေါင်းအမြတ်"),
        "totalPurchase":
            MessageLookupByLibrary.simpleMessage("စုစုပေါင်း ဝယ်ယူမှု"),
        "totalReturnAmount": MessageLookupByLibrary.simpleMessage(
            "စုစုပေါင်း ပြန်လည်ရရှိမည့်ငွေ"),
        "totalReturns":
            MessageLookupByLibrary.simpleMessage("စုစုပေါင်း ပြန်လည်လက်ခံမှု"),
        "totalSale": MessageLookupByLibrary.simpleMessage("စုစုပေါင်းအေရာင်း"),
        "totalStock":
            MessageLookupByLibrary.simpleMessage("စုစုပေါင်းစျေးကွက်"),
        "totalValue": MessageLookupByLibrary.simpleMessage("စုစုပေါင်းတန်ဖိုး"),
        "totalVat":
            MessageLookupByLibrary.simpleMessage("စုစုပေါင်းအသုံးစရိတ်"),
        "totals": MessageLookupByLibrary.simpleMessage("စုစုပေါင်း: "),
        "transaction": MessageLookupByLibrary.simpleMessage("ငွေသားအသင်း"),
        "transactionId":
            MessageLookupByLibrary.simpleMessage("ငွေသွင်းငွေသွင်းအချက်အလက်"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("ထပ်မံကြိုးစားပါ"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("အမျိုးအစား"),
        "unitName": MessageLookupByLibrary.simpleMessage("ယူနစ်အမည်"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("ယူနစ်ခြင်း"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("ယူနစ်ဈေးနှုန်း"),
        "units": MessageLookupByLibrary.simpleMessage("ယူနစ်များ"),
        "unlimited": MessageLookupByLibrary.simpleMessage("ကန့်သတ်မရှိ"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("အကယ်ဒများအသုံးပြုပါနှင့်"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "ကျွန်ုပ်တို့၏ကျွမ်းကျင်ပညာရှင်အဖွဲ့မှ ဦးဆောင်သော ပုဂ္ဂိုလ်ရေးသီးသန့်လေ့ကျင့်မှုသင်တန်းများဖြင့် Pos Saas POS ၏ အလားအလာအပြည့်ကို လော့ခ်ဖွင့်ပါ။ အခြေခံမှစပြီး အဆင့်မြင့်နည်းပညာများအထိ၊ သင့်လုပ်ငန်းလုပ်ငန်းစဉ်များကို အကောင်းဆုံးဖြစ်အောင် စနစ်၏မျက်နှာစာတိုင်းကို အသုံးပြုရာတွင် သင်ကျွမ်းကျင်ကြောင်း သေချာပါသည်။"),
        "unpaid": MessageLookupByLibrary.simpleMessage("ငွေပေးချေမှုမရှိသေး"),
        "update": MessageLookupByLibrary.simpleMessage("အပြီးအစီး"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("ဆက်သွယ်ရန်အသုံးပြုရန်"),
        "updateNow":
            MessageLookupByLibrary.simpleMessage("ယခုအချို့အဆက်တင်ရန်"),
        "updateProduct": MessageLookupByLibrary.simpleMessage(
            "ကုန်ပစ္စည်းအပ်ဒိတ်ကိုအပ်ဒိတ်အပ်ပါ"),
        "updateYourPlanFirstYourLimitIsOver": MessageLookupByLibrary.simpleMessage(
            "အစီအစဉ်ကိုပထမဦးစွာအပ်ဒိတ်လုပ်ပါ၊\\nyour အကန့်အသတ်သည်ကျော်လွန်နေပါသည်"),
        "updateYourProfile": MessageLookupByLibrary.simpleMessage(
            "သင်၏ပရိုဖိုင်အပ်ဒိတ်ကိုအပ်ဒိတ်အပ်ပါ"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "သင်၏ဆရာဝန်ကျသည့် အရေးကြီးကို တပ်ဆင်ရန်သင်၏ပရိုဖိုင်အား အကြောင်းပြောင်းပေးသည်"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "သင်၏ပရိုဖိုင်အပ်ဒိတ်ကိုသင်၏ဖောက်သည်အားပြင်ပါရန်အခြားဖြင့်ချိတ်ဆက်နိုင်ရန်"),
        "updated": MessageLookupByLibrary.simpleMessage("အပ်ဒိတ်လုပ်ပြီး"),
        "upload": MessageLookupByLibrary.simpleMessage("အပ်ဒိတ်"),
        "uploadDocument": MessageLookupByLibrary.simpleMessage("စာရွက် တင်ရန်"),
        "uploadDone":
            MessageLookupByLibrary.simpleMessage("အပ်ဒိတ်လုပ်ပြီးပါပြီ"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("ဖိုင် တင်ရန်"),
        "upplier": MessageLookupByLibrary.simpleMessage("ကုန်ပစ္စည်းရောင်း"),
        "usbC": MessageLookupByLibrary.simpleMessage("USB C"),
        "use": MessageLookupByLibrary.simpleMessage("သုံးပါ"),
        "useMobiPos":
            MessageLookupByLibrary.simpleMessage("Pos Saas ကိုအသုံးပြုပါ"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Use of the system"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("အသုံးပြုသူကိုဖျက်လိုက်ပါသည်"),
        "userRole":
            MessageLookupByLibrary.simpleMessage("အသုံးပြုသူ ရာခိုင်နှုန်း"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("အသုံးပြုသူ အချက်အလက်"),
        "userTitle":
            MessageLookupByLibrary.simpleMessage("အသုံးပြုသူ ခေါ်ဆိုတဲ့ နာမည်"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "အသုံးပြုသူ ခေါင်းစဥ် မသေးရပါ"),
        "value": MessageLookupByLibrary.simpleMessage("တန်ဖိုး"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("Vat မပေါင်းသင့်ပါ"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("OTP အတည်ပြုပါ"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("ဖုန်းနံပါတ်အတည်ပြုပါ"),
        "viewAll": MessageLookupByLibrary.simpleMessage("အားလုံးကြည့်မည်"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("အသေးစိတ်ကြည့်မည်"),
        "walkInCustomer": MessageLookupByLibrary.simpleMessage("လက်ရှိလူငယ်"),
        "warehouse": MessageLookupByLibrary.simpleMessage("အထုပ်"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("ကုန်ဆောင်ရုံ ကြားထဲရှိသည်"),
        "warehouseList":
            MessageLookupByLibrary.simpleMessage("ကုန်ဆောင်ရုံ စာရင်း"),
        "warehouseName":
            MessageLookupByLibrary.simpleMessage("ကုန်ဆောင်ရုံ နာမည်"),
        "warranty": MessageLookupByLibrary.simpleMessage("အာမခံ"),
        "weHaveSendAnEmailwithInstructions":
            MessageLookupByLibrary.simpleMessage(
                "သင့်အီးမေးလ်ကိုပို့သွားသည်။ စကားဝှက်ပြန်ဖြတ်ရန်အကြောင်း:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "We may use third-party services to support our app\'s functionality, such as analytics providers and payment processors. These third-party services may collect information about you when you use our app. Please note that we are not responsible for the privacy practices of these third-party services."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "We take industry-standard measures to protect your personal information, including encryption and secure storage. We also limit access to your information to authorized personnel only."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            " ချောမွေ့မှုမရှိသော လုပ်ငန်းဆောင်ရွက်မှုများ၏ အရေးပါမှုကို ကျွန်ုပ်တို့ နားလည်ပါသည်။ ထို့ကြောင့် အမြန်မေးမြန်းမှု သို့မဟုတ် ကျယ်ကျယ်ပြန့်ပြန့် စိုးရိမ်ပူပန်မှုဖြစ်စေရန် ကျွန်ုပ်တို့၏ နာရီလက်တံအကူအညီသည် သင့်အား ကူညီပေးနိုင်ပါသည်။ ပြိုင်ဘက်ကင်းသော ဖောက်သည်ဝန်ဆောင်မှုကို တွေ့ကြုံခံစားနိုင်ရန် ခေါ်ဆိုမှု သို့မဟုတ် WhatsApp မှတစ်ဆင့် အချိန်မရွေး၊ နေရာမရွေး ကျွန်ုပ်တို့နှင့် ချိတ်ဆက်ပါ။"),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "We use your personal information to provide you with the best possible experience on our app, including to personalize your content recomme ndations, connect you with experts, and improve our apps functionality. We may also use your information to communicate with you about updates, promotions, or other information related to our app."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "ငွေပေးချေမှုကို ပြန်လည်သုံးသပ်ပြီး 1-2 နာရီအတွင်း အတည်ပြုမည်"),
        "weekly": MessageLookupByLibrary.simpleMessage("အပတ်စဉ်"),
        "weight": MessageLookupByLibrary.simpleMessage("အလေးချိန်"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("ဘာသာပြန်မှုများ"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("ကုန်လက်ခံသူ"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("လက်ကျန်စျေးနှုန်း"),
        "wholesalePrice":
            MessageLookupByLibrary.simpleMessage("စျေးနှုန်းကြီး"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("စျေးဝယ်သူ"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("မကြာမီထည့်မည်"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("အဆုံးစွန်မည်"),
        "writeYourMessageHere": MessageLookupByLibrary.simpleMessage(
            "သင်၏မက်ဆေ့ခ််ကိုမှတ်တမ်းတင်ပါ"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("OTP မှား"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "ဤအသုံးပြုသူအတွက် မှားနေသည့် စကားဝှက်မှာ မှားယွင်းထားပါသည်။"),
        "yearly": MessageLookupByLibrary.simpleMessage("နှစ်ကန့်"),
        "yesDeleteForever": MessageLookupByLibrary.simpleMessage(
            "ဟုတ်ကြီးပါ။ အမှားဖျက်သွားမည်"),
        "youAreNotAValidUser": MessageLookupByLibrary.simpleMessage(
            "သင်သည် သာမန်အသုံးပြုသူ မဟုတ်ပါ"),
        "youAreUsing":
            MessageLookupByLibrary.simpleMessage("သင်ကိုယ်ရေးကျော်သော"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "သင်မရနိုင်ပါ အထက်ပါငွေပေးချေမှုထက်ပိုသည်"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("သင်မှာအီးမေးလ်ပြီးပါပြီ"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "သင်အောင်မြင်သောအကောင့်ဝင်ပြီးပါပြီ။ Pos Saas နှင့်တက်ရောက်ကြောင်းကိုကာကွယ်ရှိပါတယ်။"),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("ခွင့်ပြုချက် ပေးရမည်"),
        "youHaveToReLogin":
            MessageLookupByLibrary.simpleMessage("သင့်အကောင့်ပြောပါတယ်။"),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "သင်ရောင်းစျေးရယူရန်အဆင့်မြှင့်ရန်လိုအပ်ပါသည်"),
        "yourMessageRemains": MessageLookupByLibrary.simpleMessage(
            "သင့်မက်ဆေ့ခ်ျကိုကျွန်ုပ်တို့ထောက်တန်းကြောင်းသွားပါမည်"),
        "yourPackage":
            MessageLookupByLibrary.simpleMessage("သင်၏အကောင့်အတွက်ပက်ကန်စွာ"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "သင်၏အကောင့်အတွက်အသက်တိုက်များအတွက်ပြသရန် ၅ ရက်အတွက်သတ်မှတ်ခြင်း")
      };
}
