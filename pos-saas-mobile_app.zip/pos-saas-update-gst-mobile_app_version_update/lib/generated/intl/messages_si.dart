// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a si locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'si';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("අග්‍රහණය"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("GST අංකය"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired": MessageLookupByLibrary.simpleMessage("MRP අවශ්‍යයි"),
        "OK": MessageLookupByLibrary.simpleMessage("හොඳයි"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("දුරකථන අංකය"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("එස් එල්"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT කේතය"),
        "Snacks": MessageLookupByLibrary.simpleMessage("ස්නැක්ස්"),
        "TAX": MessageLookupByLibrary.simpleMessage("බදු"),
        "Uploading": MessageLookupByLibrary.simpleMessage("අපේක්ෂිතයි"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("පරිශීලක ශීර්ෂය"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "ඔබගේ පැකේජය අද සවස සඳහා පමණක් පරියෝජනවන්න\n\nකරුණාකර නැවත මිලදී ගැනීමට"),
        "aboutApp": MessageLookupByLibrary.simpleMessage("යෙදුම ගැන"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("අපි ගැන"),
        "accountName": MessageLookupByLibrary.simpleMessage("ගිලන් නම"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("ගිලන් අංකය"),
        "acton": MessageLookupByLibrary.simpleMessage("ක්‍රියාව"),
        "add": MessageLookupByLibrary.simpleMessage("ඇතුළුවීම"),
        "addBrand": MessageLookupByLibrary.simpleMessage("වෙළඳපොලට එකතු කරනවා"),
        "addCategory":
            MessageLookupByLibrary.simpleMessage("ප්‍රභේදයක් එකතු කරනවා"),
        "addContact":
            MessageLookupByLibrary.simpleMessage("දුරකථනය එකතු කරන්න"),
        "addCustomer":
            MessageLookupByLibrary.simpleMessage("කුමුදු එකතු කරන්න"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("භාණ්ඩ එකතු කරන්න"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("විස්තරය ඇතුළුවෙන්න"),
        "addDescription":
            MessageLookupByLibrary.simpleMessage("අලුත් සටහනක් එකතු කරන්න"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("අවසානය එක් කරන්න"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("ලේඛන අංකය එකතු කිරීම"),
        "addDucument": MessageLookupByLibrary.simpleMessage("ලේඛනය එකතු කරනවා"),
        "addExpense": MessageLookupByLibrary.simpleMessage("අයදුම් එකතු කරන්න"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("අයදුම් කාණ්ඩයක් එකතු කරන්න"),
        "addItems": MessageLookupByLibrary.simpleMessage("අයිතම් එකතු කිරීම"),
        "addNew": MessageLookupByLibrary.simpleMessage("නවයක් ඇතුළුවෙන්න"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("නව ලිපිනයක් එක් කරන්න"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("නව නිශ්චිතයක් එකතු කරනවා"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("නව බදු එකතු කරන්න"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "එකක්/බහු බදු වර්ග සමඟ නව බදු එකතු කරන්න"),
        "addNote": MessageLookupByLibrary.simpleMessage("සටහනක් එකතු කරන්න"),
        "addProductFirst": MessageLookupByLibrary.simpleMessage(
            "ප්‍රථමයෙන් නිෂ්පාදනයක් එක් කරන්න"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("ප්‍රවර්ධන කේතය එක් කරන්න"),
        "addPurchase":
            MessageLookupByLibrary.simpleMessage("වෙළඳපොලට එකතු කිරීම"),
        "addSales":
            MessageLookupByLibrary.simpleMessage("විකුණු කිරීම් එකතු කරනවා"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("සාර්ථකයෙන් එකතු කළ යුතුවේ"),
        "addUnit": MessageLookupByLibrary.simpleMessage("ඒකකය එකතු කරනවා"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("පරිශීලක භාරකෝ එකතු කරන්න"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("සාර්ථකව එකතු කරන ලදි"),
        "addedToCart": MessageLookupByLibrary.simpleMessage("ගෘහීකෘත කර ඇත"),
        "address": MessageLookupByLibrary.simpleMessage("ලිපිනය"),
        "admin": MessageLookupByLibrary.simpleMessage("පරිපාලක"),
        "all": MessageLookupByLibrary.simpleMessage("සියල්ල"),
        "allBusinessSolution": MessageLookupByLibrary.simpleMessage(
            "සියළු ව්‍යාපෘතියන්ගේ ව්‍යාපෘතිය"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("ඇතුළුවිම ඇති"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("පෙර සිට ඇත"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("දැනටමත් ගිණුමක් තිබේ"),
        "amount": MessageLookupByLibrary.simpleMessage("මුදල"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "විද්‍යුත් තැපැල් යවනු ලැබී ඇත\\nඔබේ බිත්තිය පරීක්ෂා කරන්න"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "ඇන්ඩ්‍රොයිඩ් & iOS යෙපය සහාය"),
        "applicableTax": MessageLookupByLibrary.simpleMessage("අදාළ බදු"),
        "apply": MessageLookupByLibrary.simpleMessage("යොමු කරන්න"),
        "areYouSureToDeleteThisInvoice":
            MessageLookupByLibrary.simpleMessage("ඔබට මෙම මැදුර මකන්න සහතිකද?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "ඔබට මෙම විකිණීම මැදීමට ඇත්තේද?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "මෙම පරිශීලකයා මකන්නැයි ඔබ විශ්වාසද?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "මෙම කරනය ඉවත් කිරීමට සහතිකද?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "මෙම කරනය කණ්ඩායම ඉවත් කිරීමට සහතිකද?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "ඔබට මෙම ගබඩාව මකා දැමීමට අවශ්‍යද?"),
        "areYourSureDeleteThisUser":
            MessageLookupByLibrary.simpleMessage("මෙය මකාද?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("අධිකාරී අත්සන"),
        "backSide": MessageLookupByLibrary.simpleMessage("පසුවෙනි කොටුව"),
        "backToHome": MessageLookupByLibrary.simpleMessage("මුල් පිටවනවා"),
        "balance": MessageLookupByLibrary.simpleMessage("ඉතිරිය"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("බංග්ලාදේශය"),
        "bank": MessageLookupByLibrary.simpleMessage("බැංකුව"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("බැංකු ගිණුමේ මුදල්"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("බැංකු ගණක මුදල"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("බැංකු තොරතුරු"),
        "bankName": MessageLookupByLibrary.simpleMessage("බැංකු නම"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("බැංකු මාරු"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("බාර්කෝඩය සොයා ගෙන ඇත"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("බිල්/ඉන්වොයිසය"),
        "billTo": MessageLookupByLibrary.simpleMessage("බිල්ල කරනවා"),
        "branchName": MessageLookupByLibrary.simpleMessage("ශාඛා නම"),
        "brand": MessageLookupByLibrary.simpleMessage("වෙළඳපොලය"),
        "brandName": MessageLookupByLibrary.simpleMessage("වෙළඳපොලට නම"),
        "bulkUpload":
            MessageLookupByLibrary.simpleMessage("ප්‍රමාණවත්\nඇතුළත් කිරීම"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("ව්‍යාපාර වර්ගය"),
        "buy": MessageLookupByLibrary.simpleMessage("මිලදී"),
        "buyPremiumPlan": MessageLookupByLibrary.simpleMessage(
            "ප්‍රිමේටල් පැකේජය මිලට මිලදීම"),
        "buySms": MessageLookupByLibrary.simpleMessage("SMS ගෙවීම"),
        "call": MessageLookupByLibrary.simpleMessage("කෝටියක්"),
        "callForEmergencySupport":
            MessageLookupByLibrary.simpleMessage("ආපදාවක් සඳහා අමතන්න"),
        "camera": MessageLookupByLibrary.simpleMessage("කැමරාව"),
        "cancel": MessageLookupByLibrary.simpleMessage("අවලංගු කරන්න"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("සියලු නිෂ්පාදන අහෝසි කරන්න"),
        "capacity": MessageLookupByLibrary.simpleMessage("ප්‍රමාණය"),
        "card": MessageLookupByLibrary.simpleMessage("කාඩ්පත"),
        "cash": MessageLookupByLibrary.simpleMessage("මුදල්"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("ප්‍රභේද"),
        "category": MessageLookupByLibrary.simpleMessage("ප්‍රභේදය"),
        "categoryName": MessageLookupByLibrary.simpleMessage("කාණ්ඩ නාමය"),
        "categoryNameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("කාණ්ඩ නාමය දැනටමත් ඇත"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("ප්‍රභේදයේ නම"),
        "change": MessageLookupByLibrary.simpleMessage("වෙනස් කරනවාද?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("මුරපදය වෙනස් කිරීම"),
        "checkEmail":
            MessageLookupByLibrary.simpleMessage("ඊමේල් පණිවිඩය පරික්ෂා කරන්න"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("පාරිභෝගීකයන්ෙන් තෝරාගන්න"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("සේවාදායකයෙන් තෝරාගන්න"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("ඔබගේ විස්තරයන් තෝරන්න"),
        "clarence": MessageLookupByLibrary.simpleMessage("ක්ලැරන්ස්"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("සම්බනවේ ක්ලික් කරන්න"),
        "close": MessageLookupByLibrary.simpleMessage("වසන්න"),
        "color": MessageLookupByLibrary.simpleMessage("වර්ණය"),
        "combinationOfMultipleTaxes":
            MessageLookupByLibrary.simpleMessage("(බහුවරණ කරන සංයෝජන)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("ඉක්මනින් පැමිණේ"),
        "companyAddress": MessageLookupByLibrary.simpleMessage("කාමී ලිපිනය"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("කාමී & සාප්පු නාමය"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("සමාගම සහ වාණිජ නාමය"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("සම්පුර්ණ සංවේදීය ක්‍රියාව"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("මහන්තය තහවුරු කරන්න"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("ආපසු යැවීම සහතික කරන්න"),
        "congratulations": MessageLookupByLibrary.simpleMessage("සුබාධායක්ද"),
        "contactUs":
            MessageLookupByLibrary.simpleMessage("අප වෙත සම්බන්ද කරනවා"),
        "continu": MessageLookupByLibrary.simpleMessage("දිගටම"),
        "country": MessageLookupByLibrary.simpleMessage("රට"),
        "create": MessageLookupByLibrary.simpleMessage("නිරවද්‍යයන්"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("නොමිලේ ගිණුමක් සාදන්න"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("ආරම්භක හා සුරකින්නා"),
        "currency": MessageLookupByLibrary.simpleMessage("මුදල්"),
        "currentStock": MessageLookupByLibrary.simpleMessage("වර්ගයේ ගණන"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("අභිරවේදී පෙනුම් භාරකෝ සහාය"),
        "customer": MessageLookupByLibrary.simpleMessage("පාරිභෝගීකයා"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("කුමුදු විස්තර"),
        "customerGST": MessageLookupByLibrary.simpleMessage("පාරිභෝගික GST"),
        "customerName": MessageLookupByLibrary.simpleMessage("කුමුදු නම"),
        "dailyTransaciton": MessageLookupByLibrary.simpleMessage("දින සේවාව"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("දත්ත සාර්ථකව සුරකින ලදි"),
        "date": MessageLookupByLibrary.simpleMessage("දිනය"),
        "day": MessageLookupByLibrary.simpleMessage("දින"),
        "dealer": MessageLookupByLibrary.simpleMessage("දෙවැනියානු"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("කාර්යාලයෙන් මිල"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("මූලික VAT ප්‍රතිශතය"),
        "delete": MessageLookupByLibrary.simpleMessage("මකාදමා"),
        "deleting": MessageLookupByLibrary.simpleMessage("මැදුර මකනවා"),
        "deliveryAddress": MessageLookupByLibrary.simpleMessage("භාණ්ඩ ලිපිනය"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("නිවසේ ලිපිනයන්"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("සේවා ප්රවාහන ගාස්තු"),
        "describtion": MessageLookupByLibrary.simpleMessage("විස්තරය"),
        "description": MessageLookupByLibrary.simpleMessage("විස්තරය"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("විස්තරය හිස් විය නොහැක"),
        "details": MessageLookupByLibrary.simpleMessage("විස්තර"),
        "discount": MessageLookupByLibrary.simpleMessage("වට්ටම"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("අවවාදයයි"),
        "done": MessageLookupByLibrary.simpleMessage("සාර්ථකයි"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("එක්සෙල් ආකෘතිය බාගත කරන්න"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "බාගත කළ හැකි අයදුම්පත් ගොනුව තුළ සාර්ථකව බාගත කර ඇත"),
        "due": MessageLookupByLibrary.simpleMessage("මුදල්"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("මුදල් ප්‍රමානය: "),
        "dueCollection": MessageLookupByLibrary.simpleMessage("මුදල් එකතුව"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("ඇගයීමේ වාර්තා"),
        "dueList": MessageLookupByLibrary.simpleMessage("මුදල් ලැයිස්තුව"),
        "dueReports": MessageLookupByLibrary.simpleMessage("හිඟ වාර්තා"),
        "duration": MessageLookupByLibrary.simpleMessage("කාලය"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("කාලය: සිට"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "ප්‍රමුඛතාවේ භාවිතා කිරීමවීම හොඳයි"),
        "edit": MessageLookupByLibrary.simpleMessage("සංස්කරනවා"),
        "editPurchaseInvoice": MessageLookupByLibrary.simpleMessage(
            "වෙළඳපොල ආපසු ලිපිගොනු සංස්කරනවා"),
        "editSalesInvoice": MessageLookupByLibrary.simpleMessage(
            "විකුණු ආපසු ලිපිගොනු සංස්කරනවා"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("සමාජ ජාල සංස්ථාව සංස්කරනවා"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("සංස්කරණය සාර්ථකයි"),
        "editTax": MessageLookupByLibrary.simpleMessage("කරණය සංස්කරණය කරන්න"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("කරණය කණ්ඩායම සංස්කරණය කරන්න"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("ගබඩාව සංස්කරණය කරන්න"),
        "email": MessageLookupByLibrary.simpleMessage("ඊමේල්"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("ඊමේල් ලිපිනය"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("ඊමේල් එක අහරින් යුතුය"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "ඊමේල් යවනු ලැබුණා! ඔබගේ ඉන්බොක්ස් පරීක්ෂා කරන්න"),
        "endDate": MessageLookupByLibrary.simpleMessage("අවසාන දිනය"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("වලංගු ප්‍රමාණයක් ඇතුළුවන්න"),
        "enterAValidDiscount": MessageLookupByLibrary.simpleMessage(
            "කලින් ඉල්ලුමක් නිරුපිත කරන්න"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "වලංගු දුරකතන අංකයක් ඇතුළුවන්න"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("නිවැරදි මිලක් ඇතුළත් කරන්න"),
        "enterAValidQuantity": MessageLookupByLibrary.simpleMessage(
            "මොත් මගින් නිවැරදි ප්‍රමාණයක් ඇතුළත් කරන්න"),
        "enterAddress":
            MessageLookupByLibrary.simpleMessage("ලිපිනය ඇතුළත් කරන්න"),
        "enterAmount":
            MessageLookupByLibrary.simpleMessage("මුදල ඇතුළත් කරන්න."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("වෙළඳපොලට නම ඇතුළත් කරන්න"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("ප්‍රමාණය ඇතුළත් කරන්න"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("ප්‍රභේදයේ නම ඇතුළත් කරන්න"),
        "enterColor":
            MessageLookupByLibrary.simpleMessage("වර්ණය ඇතුළත් කරන්න"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "පාරිභෝගිකයාගේ GST අංකය ඇතුළුවන්න"),
        "enterDealerPrice": MessageLookupByLibrary.simpleMessage(
            "කාර්යාලයෙන් මිල ඇතුළත් කරන්න"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("විස්තරය ඇතුළත් කරන්න"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("වට්ටම ඇතුළත් කරන්න."),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("අයදුම් දිනය ඇතුළත් කරන්න"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("මුල් ලිපිනය ඇතුළත් කරන්න"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("ලිපිගොනු අංකය ඇතුළත් කරන්න"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "අඩු තොග මැදිහත් ප්‍රමාණය ඇතුළත් කරන්න"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("නිෂ්පාතය ඇතුළත් කරන්න"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("පණිවිඩ අන්තරය ඇතුළත් කරන්න"),
        "enterMrpOrRetailerPirce":
            MessageLookupByLibrary.simpleMessage("MRP/කුළුදු මිල ඇතුළත් කරන්න"),
        "enterName": MessageLookupByLibrary.simpleMessage("නම ඇතුළත් කරන්න"),
        "enterNote": MessageLookupByLibrary.simpleMessage("සටහන ඇතුළත් කරන්න"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("පක්ෂවක් නම ඇතුළත් කරන්න"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("දුරකථන අංකය ඇතුළත් කරන්න"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "නිශ්චිත කේතය ඇතුළත් කරන්න හෝ පැනය කරන්න"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("නිශ්චිතයේ නම ඇතුළත් කරන්න"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("වෙළඳපොල මිල ඇතුළත් කරන්න."),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("සම්බන්ධක අංකය ඇතුළත් කරන්න"),
        "enterSize":
            MessageLookupByLibrary.simpleMessage("ප්‍රමාණය ඇතුළත් කරන්න"),
        "enterStocks":
            MessageLookupByLibrary.simpleMessage("ස්ථාන ඇතුළත් කරන්න."),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("කරණය අනුපාතය ඇතුළුවෙන්න"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("සමාවෙයින හැදුනුමේ හැඳුනුමක්"),
        "enterType": MessageLookupByLibrary.simpleMessage("වර්ගය ඇතුළත් කරන්න"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("පරිශීලක ශීර්ෂය ඇතුලත් කරන්න"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("වලංගු ප්‍රමාණයක් ඇතුළුවන්න"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("ගබඩා නම ඇතුළුවෙන්න"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("බර ඇතුළත් කරන්න"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("වෙළෙඳුරු මිල ඇතුළත් කරන්න"),
        "enterYourDescriptionHere": MessageLookupByLibrary.simpleMessage(
            "ඔබේ විස්තරය මෙහි ඇතුළත් කරන්න"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "ඔබේ ඊමේල් ලිපිනය ඇතුළත් කරන්න"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "ඔබේ ප්‍රකාශ ශීර්ෂය ඇතුළත් කරන්න"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("ඔබගේ GST අංකය ඇතුළුවන්න"),
        "enterYourMobileNumber": MessageLookupByLibrary.simpleMessage(
            "ඔබගේ ජංගම දුරකථන අංකය ඇතුළත් කරන්න"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("ඔබගේ නම ඇතුළත් කරන්න"),
        "enterYourNumber": MessageLookupByLibrary.simpleMessage(
            "ඔබේ දුරකථන අංකය ඇතුළත් කරන්න"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("ඔබේ මුරපදය ඇතුලත් කරන්න"),
        "enterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "ඔබගේ දුරකථන අංකය ඇතුළත් කරන්න"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "ඔබගේ සංගීත අංකය ඇතුළත් කරන්න"),
        "error": MessageLookupByLibrary.simpleMessage("දෝෂය"),
        "excTax": MessageLookupByLibrary.simpleMessage("බදු ඉවත් කිරීම"),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("එක්සෙල් උඩුගතකරු"),
        "exclusive": MessageLookupByLibrary.simpleMessage("අතින් ඉවත්"),
        "expense": MessageLookupByLibrary.simpleMessage("අයිතමය"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("අයදුම් කාණ්ඩය"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("අයදුම් දිනය"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("අයදුම් සඳහා"),
        "expenseReport": MessageLookupByLibrary.simpleMessage("අයදුම් වාර්තාව"),
        "expireDate": MessageLookupByLibrary.simpleMessage("අවුරුදු දිනය"),
        "expired": MessageLookupByLibrary.simpleMessage("අවසන් වී ඇත"),
        "expiring": MessageLookupByLibrary.simpleMessage("අවසන් වන"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("දෝෂයක් සමඟ වසිකිරීම"),
        "fashion": MessageLookupByLibrary.simpleMessage("විවාහය"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "අනුමැතියන් වැනි ප්‍රතික්ෂේපන අංශය ස්මාර්ට් බියාෂරා දැක්කාය."),
        "feedBack": MessageLookupByLibrary.simpleMessage("ප්‍රකාශය"),
        "firstName": MessageLookupByLibrary.simpleMessage("මුල් නම"),
        "followUsOnFacebook": MessageLookupByLibrary.simpleMessage(
            "අපි Facebook හි අනුගමනය කරන්න"),
        "followUsOnTwitter": MessageLookupByLibrary.simpleMessage(
            "අපි Twitter හි අනුගමනය කරන්න"),
        "fontSide": MessageLookupByLibrary.simpleMessage("මුළු පෙර කොටුව"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("අසීමිත භාවිතයන්ට සඳහා"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("මුරපදය අමතක වීම"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("මුරපදය අමතක වීම?"),
        "formDate": MessageLookupByLibrary.simpleMessage("දිනයේ සිට"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("නොගෙවිය යුතු දත් සේවා"),
        "freeLifeTimeUpdate":
            MessageLookupByLibrary.simpleMessage("සීයැජ් ජවිය සංස්කරණය"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("නොමිලේ පැකේජය"),
        "freePlan": MessageLookupByLibrary.simpleMessage("නොමිලේ සැලැස්ම"),
        "from": MessageLookupByLibrary.simpleMessage("(ආසන්නය"),
        "fullyPaid":
            MessageLookupByLibrary.simpleMessage("සම්පූර්ණයෙන් ගෙවා ඇත"),
        "gallary": MessageLookupByLibrary.simpleMessage("ගැලරි"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("PDF ජනනය කිරීම"),
        "getOtp": MessageLookupByLibrary.simpleMessage("OTP ලබාගන්න"),
        "govermentId": MessageLookupByLibrary.simpleMessage("සේවාදායකයේ අංකය"),
        "guest": MessageLookupByLibrary.simpleMessage("පටුපාටු"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("කිසියක් නොමැතිව?"),
        "history": MessageLookupByLibrary.simpleMessage("වට්ටම"),
        "home": MessageLookupByLibrary.simpleMessage("මුල් පිටුව"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("හැඳුනුම් පිටවන්න"),
        "image": MessageLookupByLibrary.simpleMessage("පින්තූරය"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("අභ්‍යන්තරය මකා දැමිය නොහැක"),
        "inHouseCantBeEdited": MessageLookupByLibrary.simpleMessage(
            "අභ්‍යන්තරය සංස්කරණය කළ නොහැක"),
        "inWord": MessageLookupByLibrary.simpleMessage("ශබ්දයෙන්"),
        "incTax": MessageLookupByLibrary.simpleMessage("ආසන බදු"),
        "inclusive": MessageLookupByLibrary.simpleMessage("සමාවන"),
        "increaseStock":
            MessageLookupByLibrary.simpleMessage("සැපයුම වැඩි කරන්න"),
        "inistrument": MessageLookupByLibrary.simpleMessage("උපාධාරය"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("ආයාත අංකය"),
        "invoice": MessageLookupByLibrary.simpleMessage("ඉන්වොයිස්"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("ලිපිගොනු අංකය"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("ලිපිගොනු සැකසීම"),
        "invoiceViewer": MessageLookupByLibrary.simpleMessage("ඉන්වොයිස් දසුන"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("අයිතමය එකතු වී ඇත"),
        "kg": MessageLookupByLibrary.simpleMessage("කිලෝ"),
        "kycVerification": MessageLookupByLibrary.simpleMessage("KYC සත්‍යායය"),
        "language": MessageLookupByLibrary.simpleMessage("භාෂාව"),
        "lastName": MessageLookupByLibrary.simpleMessage("වාසනය"),
        "ledger": MessageLookupByLibrary.simpleMessage("බියුදුන්"),
        "lifeTimePurchase": MessageLookupByLibrary.simpleMessage("ජීවිත"),
        "link": MessageLookupByLibrary.simpleMessage("සබැඳුම"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("සජීවී චැට් සහය"),
        "loading": MessageLookupByLibrary.simpleMessage("අයදුම් කරමින්"),
        "logIn": MessageLookupByLibrary.simpleMessage("පිවිසුම"),
        "logOUt": MessageLookupByLibrary.simpleMessage("පිටවනවා"),
        "logOut": MessageLookupByLibrary.simpleMessage("පිටවන්න"),
        "login": MessageLookupByLibrary.simpleMessage("ඇතුළත් වන්න"),
        "logo": MessageLookupByLibrary.simpleMessage("ලාංකීය ලාංකීය"),
        "loss": MessageLookupByLibrary.simpleMessage("ලාස්සනය"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("භාවිත/ලාස්සන"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("භාවිත/ලාස්සන විස්තර"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("නිති හා ලාභ වාර්තා"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("නිති හා ලාභ වාර්තා"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("අඩු තොග මැදිහත්"),
        "maan": MessageLookupByLibrary.simpleMessage("මාං"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "සන්නාමගත ඉන්වොයිසි සමඟින් ඔබේ පාරිභෝගිකයන් කෙරෙහි සදාකාලික හැඟීමක් ඇති කරන්න. අපගේ අසීමිත උත්ශ්රේණි කිරීම ඔබේ ඉන්වොයිසි අභිරුචිකරණය කිරීමේ සුවිශේෂී වාසියක් ලබා දෙයි, ඔබේ සන්නාම අනන්යතාවය ශක්තිමත් කරන සහ පාරිභෝගික පක්ෂපාතිත්වය පෝෂණය කරන වෘත්තීය ස්පර්ශයක් එක් කරයි."),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("ඔබගේ ව්‍යාපාරය කළමනාකරන්න "),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("නිෂ්පාදන දිනය"),
        "margin": MessageLookupByLibrary.simpleMessage("ආසන"),
        "masterCard": MessageLookupByLibrary.simpleMessage("මාස්ටර් කාඩ්"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("නිෂ්පාතය"),
        "message": MessageLookupByLibrary.simpleMessage("සමාව"),
        "messageHistory": MessageLookupByLibrary.simpleMessage("පණිවිඩ සටහන"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "ස්මාර්ට් බියාෂරා යෙදුම නොමිලයේ සඳහා, භාවිතා කිරීම සඳහා හොඳයි. සුළු ලෙස, එකම POS පද්ධතියේ ස්මාර්ට් බියාෂරා විසින් එකමුත් වාසියක් දැක්වෙයි."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "ස්මාර්ට් බියාෂරා විසින් සංප්‍රේම ක්‍රියාවක් වෙනස්වූ සම්පූර්ණ ව්‍යාපෘතියක් වේ, ස්මාර්ට් බියාෂරා මගින් වාසි, වෙළඳපොල, සහාය සහ පරාසිපාත කුවේදැයි/ලාස්පිට් සඳහා සම්පූර්ණ ව්‍යාපෘතියක් වේ."),
        "mobile": MessageLookupByLibrary.simpleMessage("ජංගම"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("ජංගම ගෙවීම්"),
        "monthly": MessageLookupByLibrary.simpleMessage("මාසික"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("වැඩි විස්තර"),
        "name": MessageLookupByLibrary.simpleMessage("ඔබගේ නම ඇතුළත් කරන්න."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("නම දැනටමත් ඇත"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("නම අමතක විය නොහැක"),
        "next": MessageLookupByLibrary.simpleMessage("ඊළඟ"),
        "noConnection": MessageLookupByLibrary.simpleMessage("දැනුම නොමැත"),
        "noData": MessageLookupByLibrary.simpleMessage("දත්ත නොමැත"),
        "noDataAvailable": MessageLookupByLibrary.simpleMessage("දත්ත නොමැත"),
        "noDataFound": MessageLookupByLibrary.simpleMessage("දත්ත කිසිවක් නැත"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("සටහන කිසිවක් නැත!"),
        "noProductFound": MessageLookupByLibrary.simpleMessage(
            "නව නිෂ්පාදන කිසිවක් සොයා ගන්න නොහැක"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("නොමැත උප බදු තෝරා ඇත"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("සංස්කාරයක් නැත!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "එවිට එය සබැඳියක් සොයාගත නොහැක."),
        "noUserRoleFound":
            MessageLookupByLibrary.simpleMessage("පරිශීලක භාරකෝ දක්වා නැත"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("සක්‍රිය පරිශීලකයෙක් නොවේ"),
        "notProvided": MessageLookupByLibrary.simpleMessage("පළ කරන ලදි නැත"),
        "note": MessageLookupByLibrary.simpleMessage("සටහන"),
        "notes": MessageLookupByLibrary.simpleMessage("සටහන්"),
        "notification": MessageLookupByLibrary.simpleMessage("ස්ථාපනය"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP යවන ලදි"),
        "office": MessageLookupByLibrary.simpleMessage("කාර්යාලය"),
        "ok": MessageLookupByLibrary.simpleMessage("හරි"),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("ආරක්ෂාව අරක්ෂාව"),
        "order": MessageLookupByLibrary.simpleMessage("ඇණ"),
        "other": MessageLookupByLibrary.simpleMessage("අනික්"),
        "otp": MessageLookupByLibrary.simpleMessage("අවලංගු කරන්න"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("හිඟය"),
        "pacakge": MessageLookupByLibrary.simpleMessage("පැකේජය"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("පැකේජ් සුලු විස්තර"),
        "paid": MessageLookupByLibrary.simpleMessage("ගෙවූ"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("ගෙවූ මුදල"),
        "parties": MessageLookupByLibrary.simpleMessage("පක්ෂ"),
        "partiesList": MessageLookupByLibrary.simpleMessage("පක්ෂ ලැයිස්තුව"),
        "partyGST": MessageLookupByLibrary.simpleMessage("කණ්ඩායම ජාතික බදු"),
        "partyName": MessageLookupByLibrary.simpleMessage("පක්ෂවක් නම"),
        "password": MessageLookupByLibrary.simpleMessage("මුරපදය"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "මුරපදය සහ තහවුරු කිරීමේ මුරපදය සමාන නොවේ"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("මුරපදය හිස් විය නොහැක"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("මුරපදය නොගැලපේ"),
        "payCash": MessageLookupByLibrary.simpleMessage("මුදල් ගෙවීම"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("බීකාශ් සමග ගෙවනවා"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("පේපල් මගින් ගෙවීම"),
        "payeeName": MessageLookupByLibrary.simpleMessage("ගෙවීම් නම"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("ගෙවීම් අංකය"),
        "payment": MessageLookupByLibrary.simpleMessage("ගෙවීම"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("ගෙවූ මුදල"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("ගෙවීම සම්පුර්ණයි"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("ගෙවීමේ උපලේඛනය:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("ගෙවීම් ක්‍රමය"),
        "paymentType": MessageLookupByLibrary.simpleMessage("ගෙවීමේ වර්ගය"),
        "pdfView": MessageLookupByLibrary.simpleMessage("PDF දර්ශනය"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("කැමැත්තන්ගේ විස්තර"),
        "phone": MessageLookupByLibrary.simpleMessage("දුරකථන"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("දුරකථන අංකය"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "දුරකතන අංකය දැනටමත් භාවිතා කරයි"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("දුරකතන අංකය වලංගු නොවේ"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("දුරකතන අංකය අවශ්‍යයි"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("ගොනුව තෝරා උඩුගත කරන්න"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("අවසාන දිනය තෝරන්න"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("ආරම්භ දිනය තෝරන්න"),
        "plan": MessageLookupByLibrary.simpleMessage("සැලසුම"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("කරුණාකර ප්‍රමාණය එක් කරන්න"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "කරුණාකර ඔබේ අන්තර්ජාල සම්බන්ධවන්තව පරිශ්වාකරන්න"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "කරුණාකර මුද්‍රකය මුල්ව සම්බන්ධ කරන්න"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "කරුණාකර ඔබේ බෙලූටූත් මුදුන් ප්‍රින්ටරය සම්බනවීම"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "කරුණාකර විශාල මුරපදයක් ඇතුළුවන්න"),
        "pleaseEnterAConfirmPassword":
            MessageLookupByLibrary.simpleMessage("කරුණාකර මහන්තය තහවුරු කරන්න"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("කරුණාකර මුරපදය ඇතුළත් කරන්න"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "කරුණාකර වලංගු ඊමේල් එකක් ඇතුළුවන්න"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("කරුණාකර නම ඇතුළුවන්න"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("කරුණාකර මුරපදය ඇතුළුවෙන්න"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "කරුණාකර ඔබේ ඊමේල් ලිපිනය පහත සැපයුම් ලබා ගැනීමට පහත ඇති ඊමේල් ලිපිනය ඇතුළත් කරන්න:"),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "කරුණාකර ගනුදෙනු අංකය ඇතුළත් කරන්න"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("කරුණාකර ප්‍රමාණය ඇතුළුවන්න"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "කරුණාකර පළමුව කාණ්ඩයක් තෝරන්න"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("කරුණාකර එකක් තෝරන්න"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "කරුණාකර ව්‍යාපාර කාණ්ඩය තෝරන්න"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "කරුණාකර යෙදුම භාවිතා කිරීමට වලංගු මිලදී ගැනීම් කේතය භාවිතා කරන්න"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Pos Saas වෙත සබලකළ"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("පවිත රහිතයි"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("විසින් පාරිභාවය සහාය"),
        "premiumPlan":
            MessageLookupByLibrary.simpleMessage("ප්‍රිමේටල් පැකේජය"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("පෙර ගෙවූ මුදල"),
        "price": MessageLookupByLibrary.simpleMessage("මිල"),
        "print": MessageLookupByLibrary.simpleMessage("මුද්‍රණය"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("මුද්‍රණාගත වීමේ විකල්ප"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("පුරවැසි සාලාංඡය"),
        "product": MessageLookupByLibrary.simpleMessage("නිශ්චිතය"),
        "productCode": MessageLookupByLibrary.simpleMessage("නිශ්චිත කේතය"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("නිෂ්පාදන කේතය අවශ්‍යයි"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("නිෂ්පාදන කේතය/නම"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("නිෂ්පාදන විවරණය"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("නිෂ්පාදන විස්තර"),
        "productList":
            MessageLookupByLibrary.simpleMessage("නිශ්චිත ලැයිස්තුව"),
        "productName": MessageLookupByLibrary.simpleMessage("නිශ්චිතයේ නම"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "නිෂ්පාදන නාමය මෙම ගබඩාව තුළ දැනටමත් පවතී"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "නිෂ්පාදන නම දැනටමත් එක් කර ඇත"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("නිෂ්පාදන නාමය අවශ්‍යයි"),
        "products": MessageLookupByLibrary.simpleMessage("නිෂ්පාදන"),
        "profile": MessageLookupByLibrary.simpleMessage("පැත්තක්"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("පැකේජන සංස්කරණය"),
        "profit": MessageLookupByLibrary.simpleMessage("භාවිතය"),
        "promo": MessageLookupByLibrary.simpleMessage("ප්‍රොමෝ"),
        "promoCode": MessageLookupByLibrary.simpleMessage("ප්‍රොමෝ කේතය"),
        "purchase": MessageLookupByLibrary.simpleMessage("වෙළඳපොල"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage("වෙළඳපොල ඇලමය"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("වෙළඳපොල සියල්ලන්ය"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("වෙළඳපොල විස්තර"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("මිලදී ගැනීමේ ඉන්වොයිසය"),
        "purchaseList":
            MessageLookupByLibrary.simpleMessage("වෙළඳපොල ලැයිස්තුව"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("දැන් මිලදී ගන්න"),
        "purchasePremiumPlan": MessageLookupByLibrary.simpleMessage(
            "ප්‍රිමේටල් පැකේජය මිලට මිලිදක් ගන්න"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("වෙළඳපොල මිල"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("මිල ගණන් අවශ්‍යයි"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("වෙළඳපොල වාර්තා"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("වෙළඳපොල වාර්තා"),
        "purchaseReportss": MessageLookupByLibrary.simpleMessage("මිල වාර්තා"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("මිලදී ගැනීමේ ආපසු යැවීම"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("මිලදී ගැනීම් ආපසු වාර්තා"),
        "purchaseTransition": MessageLookupByLibrary.simpleMessage("සැලැස්ම"),
        "qty": MessageLookupByLibrary.simpleMessage("ප්රමාණය"),
        "quantity": MessageLookupByLibrary.simpleMessage("ප්‍රමාණය"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("නවතම සම්පුර්ණ ක්‍රියාවලිය"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("අපි ඔබට වෙනස්වී ඇත"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("සම්බන්ධක අංකය"),
        "register": MessageLookupByLibrary.simpleMessage("ලියාපදිංචි වන්න"),
        "registering": MessageLookupByLibrary.simpleMessage("නිකුත් කිරීම"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("ඉතිරි මුදල"),
        "remove": MessageLookupByLibrary.simpleMessage("අහෝසි කරන්න"),
        "reports": MessageLookupByLibrary.simpleMessage("වාර්තා"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("අයදුම්පත යවන ලදී"),
        "resendCode": MessageLookupByLibrary.simpleMessage("නැවත යවන්න"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("OTP නැවත යවන්න: "),
        "retailer": MessageLookupByLibrary.simpleMessage("කාර්යාලයේ"),
        "retur": MessageLookupByLibrary.simpleMessage("ප්‍රතිසංස්කරණය"),
        "returN": MessageLookupByLibrary.simpleMessage("ආපසු යැවීම"),
        "returnAMount":
            MessageLookupByLibrary.simpleMessage("පෙර වෙළඳපොලට පාර සහාය"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("සහාය පාර සහාය"),
        "returnQTY":
            MessageLookupByLibrary.simpleMessage("ආපසු යැවීමේ ප්‍රමාණය"),
        "revenue": MessageLookupByLibrary.simpleMessage("ආදායම"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "ඔබේ ව්යාපාර දත්ත ආයාසයකින් තොරව සුරක්ෂිත කරන්න. අපගේ Pos Saas POS Unlimited Upgrade හි නොමිලේ දත්ත උපස්ථයක් ඇතුළත් වන අතර, ඔබගේ වටිනා තොරතුරු අනපේක්ෂිත සිදුවීම් වලින් ආරක්ෂා කර ඇති බව සහතික කරයි. සැබවින්ම වැදගත් වන්නේ කුමක්ද යන්න පිළිබඳව අවධානය යොමු කරන්න - ඔබේ ව්යාපාර වර්ධනය."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("විකිණීම් මුදල"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("විකුණු විස්තර"),
        "salePrice": MessageLookupByLibrary.simpleMessage("විකුණු මිල"),
        "saleReports": MessageLookupByLibrary.simpleMessage("විකුණු වාර්තා"),
        "saleReportss": MessageLookupByLibrary.simpleMessage("විකුණුම් වාර්තා"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("විකිණීමේ ආපසු"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("විකිණීමේ ආපසු වාර්තා"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("විකිණීම් සකසන්න"),
        "sales": MessageLookupByLibrary.simpleMessage("විකුණු"),
        "salesList": MessageLookupByLibrary.simpleMessage("විකුණු ලැයිස්තුව"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("විකිණීමේ ආපසු"),
        "save": MessageLookupByLibrary.simpleMessage("සුරකින්න"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("සුරකින්න සහ ප්රකාශ කරන්න"),
        "saveChanges":
            MessageLookupByLibrary.simpleMessage("වෙනස් කිරීම් සුරකින්න"),
        "saving": MessageLookupByLibrary.simpleMessage("සුරකිමින්"),
        "scanProductQRCode": MessageLookupByLibrary.simpleMessage(
            "නිෂ්පාදන QR කේතය ස්කෑන් කරන්න"),
        "search": MessageLookupByLibrary.simpleMessage("සොයන්න"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "නිෂ්පාදන කේතය හෝ නම අනුව සෙවීම"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("සියලුම ප්‍රොමෝ කේත බලන්න"),
        "select": MessageLookupByLibrary.simpleMessage("තෝරන්න"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "ආපසු යැවීමට නිෂ්පාදනයක් තෝරන්න"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("කැලෑ තෝරන්න"),
        "selectCategory": MessageLookupByLibrary.simpleMessage("කාණ්ඩය තෝරන්න"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("සම්බන්දු තෝරන්න"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("නිෂ්පාදන කොට්ටස තෝරන්න"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("ඇසුරන කාණ්ඩය තෝරන්න"),
        "selectTax": MessageLookupByLibrary.simpleMessage("බදු තෝරන්න"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("බදු වර්ගය තෝරන්න"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("ආයතනය තෝරන්න"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("වෙළඳ සංඛ්‍යාව තෝරන්න: "),
        "seller": MessageLookupByLibrary.simpleMessage("විකුණුම්කරු"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("විකුණන්නා"),
        "send": MessageLookupByLibrary.simpleMessage("යවනවා"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("එවෙමු"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("පණිවිඩය යවනවා"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("නැවත සකසාව ලබාගන්න"),
        "sendSms": MessageLookupByLibrary.simpleMessage("එවෙමු SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("SMS යවනවා?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("WhatsApp පණිවිඩයක් යවන්න"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("ඔබේ විද්‍යුත් තැපැල් යවනවා"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage("ඊමේල් යැවීම"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("පණිවිඩය යවාමින්"),
        "serviceShipping": MessageLookupByLibrary.simpleMessage("සේවා/අයැදුම්"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("ඔබගේ පැතිකඩ සැකසීම"),
        "setting": MessageLookupByLibrary.simpleMessage("සැකසුම්"),
        "share": MessageLookupByLibrary.simpleMessage("බෙදාකරනවා"),
        "shopGST": MessageLookupByLibrary.simpleMessage("කඩ ජාතික බදු"),
        "signIn": MessageLookupByLibrary.simpleMessage("ඇතුළු වන්න"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("ඊමේල් සමඟ ඇතුළු වන්න"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("ගනුදෙනුකරුවන්ගේ අත්සන"),
        "size": MessageLookupByLibrary.simpleMessage("ප්‍රමාණය"),
        "skip": MessageLookupByLibrary.simpleMessage("මකන්න"),
        "sms": MessageLookupByLibrary.simpleMessage("පණිවිඩය"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("සමාජ වෙනස් කිරීම"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "කණගාටුයි, ඔබට මෙම සේවාවට ප්‍රවේශ වීමට ඉඩ නොමැත"),
        "startDate": MessageLookupByLibrary.simpleMessage("ආරම්භ දිනය"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("නව විකුණුම ආරම්භයක්"),
        "startTypingToSearch":
            MessageLookupByLibrary.simpleMessage("සොයන්නට ඇරඹන්න"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "කිසිදු අමතර පිරිවැයකින් තොරව තාක්ෂණික දියුණුවෙහි ඉදිරියෙන් සිටින්න. අපගේ Pos Saas POS Unlimited උත්ශ්රේණි කිරීම මඟින් ඔබට සැමවිටම නවතම මෙවලම් සහ විශේෂාංග ඔබේ ඇඟිලි තුඩුවල ඇති බව සහතික කරයි, ඔබේ ව්යාපාරය අති නවීන බව සහතික කරයි."),
        "stillUnpaid":
            MessageLookupByLibrary.simpleMessage("ඉක්මනින් ගෙවී නැත"),
        "stock": MessageLookupByLibrary.simpleMessage("සිටියාව"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("අදාළ තොගය අවශ්‍යයි"),
        "stockList": MessageLookupByLibrary.simpleMessage("සම්පත් ලැයිස්තුව"),
        "stocks": MessageLookupByLibrary.simpleMessage("ස්ථාන"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "එක්සෙල් ගොනුවක් සාදන ලෙස ගබඩා අවසරය අවශ්‍යයි"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("උප බදු ලැයිස්තුව"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("උප බදු"),
        "subTotal": MessageLookupByLibrary.simpleMessage("උප මුලු"),
        "submit": MessageLookupByLibrary.simpleMessage("ඉදිරිපත් කරනවා"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "අපේ YouTube හි සම්බන්ධ වෙන්න"),
        "subscription": MessageLookupByLibrary.simpleMessage("දැනුම"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("සාර්ථකව කරන ලදි"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("සාර්ථකව පිටවී ඇත"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("සාර්ථකව යාවත්කාලීන කළා"),
        "supplier": MessageLookupByLibrary.simpleMessage("සහායක"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("සහාය සේවාදායකයේ නම"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT කේතය"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "වාහන නිවාඩු ගෙවූලා, ජාතික හැඳුනුම් ප්රසිද්ධයා හෝ ගුවන්ටේ පෝර්ට් පහසුකම් ඡායාරූපයක් අතුළත් කරන්න"),
        "takeaNidCardToCheckYourInformation": MessageLookupByLibrary.simpleMessage(
            "ඔබගේ තොරතුර පළමු කිරීමට හැකි නම් තෙරුවෙනි නිදහස් කාඩ් එක ගෙවන්න"),
        "tap": MessageLookupByLibrary.simpleMessage("සෝදා"),
        "tax": MessageLookupByLibrary.simpleMessage("බදු"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("කරණය කණ්ඩායම"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("බදු ප්‍රතිශතය"),
        "taxRate": MessageLookupByLibrary.simpleMessage("කරණය අනුපාතය"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "කරණය අනුපාත - ඔබේ කර්මාන්ත අනුපාත කළමනාකරණය කරන්න"),
        "taxReport": MessageLookupByLibrary.simpleMessage("කරණය වාර්තාව"),
        "taxType": MessageLookupByLibrary.simpleMessage("බදු වර්ගය"),
        "taxes": MessageLookupByLibrary.simpleMessage("බදු"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("නිති සහ කොන්දේසි"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("භාර෴ති භාවිතා"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("නියමයන් සහ රහස්‍යතා"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "ඔබගේ මුදල සහාය කරන ගමන සදහා ස්වයංක්රීයයි ස්වයංක්රීයයි"),
        "thankYou": MessageLookupByLibrary.simpleMessage("ඔබට ස්තූතියි"),
        "thankYouForYourPurchase": MessageLookupByLibrary.simpleMessage(
            "ඔබගේ වෙළඳපොලට ස්වයංක්රීයයි සැපයූවන්ද"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "ආයාචිත විද්‍යුත් ලිපිනය සඳහා ගිණුම දැනටමත් ඇත"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "එක්සෙල් ගොනුව දැනටමත් බාගත කර ඇත"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "නම හැම දෙයක්ම කියනවා. Pos Saas POS Unlimited සමඟින්, ඔබේ භාවිතයේ සීමාවක් නොමැත. ඔබ ගනුදෙනු අතලොස්සක් සකසමින් සිටියත් හෝ ගනුදෙනුකරුවන්ගේ අධික තදබදයක් අත්විඳිමින් සිටියත්, ඔබ සීමාවන්ට සීමා නොවන බව දැනගෙන ඔබට විශ්වාසයෙන් යුතුව ක්රියා කළ හැක."),
        "thePasswordProvidedIsTooWeak":
            MessageLookupByLibrary.simpleMessage("දෙන ලද මුරපදය වඩා පහසුයි"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "විකුණුම් මකා දැමීමට සහ මෙම මිලදී ගැනීම පිළිබඳ සියළු දත්ත මකන්නා වූ නමුත්. ඔබට මකන්න සහතිකද?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "මෙම විකිණීම මැද කරනු ලබන අතර මෙම විකිණීම පිළිබඳ සියළු දත්ත මැද කරනු ඇත. ඔබට විකිණීම මැද කිරීමට ඇත්තේද?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "පරිශීලකයා මකා දැමීමට සහ සියල්ල දත්ත ඔබේ ගිණුමෙහිද මකා දමා යෑමට හෝදයාගේ ඉල්ලීමට ඔබට විසඳුමක් ලැබේ. මෙම මකා දැමීමට ඔබට හෝදයේ වෙනත් සියල්ල ගැන හෝදයේ උපදෙස් සහිත නිසාය."),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "පරිශීලකයා මකනු ලැබෙන අතර ඔබගේ ගිණුමෙන් සියලු දත්ත මකනු ලබනු ඇත. මෙය මකන්න ඔබ විශ්වාසද?"),
        "thisCategoryCannotBeDeleted":
            MessageLookupByLibrary.simpleMessage("මෙම කාණ්ඩය මකා දැමිය නොහැක"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(මේ මාසයේ)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "මෙම නිෂ්පාදන දැනටමත් එකතු කර ඇත"),
        "title": MessageLookupByLibrary.simpleMessage("ශීර්ෂය"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("කොටුව හිස් විය නොහැක"),
        "to": MessageLookupByLibrary.simpleMessage("ටෝ"),
        "toDate": MessageLookupByLibrary.simpleMessage("දිනය දක්වා"),
        "today": MessageLookupByLibrary.simpleMessage("අද"),
        "total": MessageLookupByLibrary.simpleMessage("මුළු"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("මුළු ප්‍රමාණය"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("මුළු එකතු කරන ලද"),
        "totalDue": MessageLookupByLibrary.simpleMessage("මුළු මුදල"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("මුදල් එකතුව"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("සම්පුර්ණ හානි"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("සියල්ල ගෙවීම් මුළු"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("මුළු මිල"),
        "totalProducts": MessageLookupByLibrary.simpleMessage("මුළු නිෂ්පාදන"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("සම්පුර්ණ ලාභය"),
        "totalPurchase":
            MessageLookupByLibrary.simpleMessage("මුළු මිලදී ගැනීම"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("මුළු ආපසු යැවීමේ මුදල"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("මුළු ආපසු"),
        "totalSale": MessageLookupByLibrary.simpleMessage("මුළු විකුණු"),
        "totalStock": MessageLookupByLibrary.simpleMessage("මුළු ගණන"),
        "totalValue": MessageLookupByLibrary.simpleMessage("මුළු අගය"),
        "totalVat": MessageLookupByLibrary.simpleMessage("මුළු වැඩ"),
        "totals": MessageLookupByLibrary.simpleMessage("මුළු: "),
        "transaction": MessageLookupByLibrary.simpleMessage("සංස්කාරකය"),
        "transactionId": MessageLookupByLibrary.simpleMessage("සංගීත අංකය"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("නැවත උත්සාහ කරන්න"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("වර්ගය"),
        "unitName": MessageLookupByLibrary.simpleMessage("ඒකක නම"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("ඒකක මිල"),
        "unitPrice":
            MessageLookupByLibrary.simpleMessage("ඉක්මනින් ගෙවීමේ මිල"),
        "units": MessageLookupByLibrary.simpleMessage("ඒකක"),
        "unlimited": MessageLookupByLibrary.simpleMessage("අනියම්"),
        "unlimitedUsage": MessageLookupByLibrary.simpleMessage("අසීමිත භාරකෝ"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "අපගේ විශේෂඥ කණ්ඩායම විසින් මෙහෙයවනු ලබන පුද්ගලාරෝපිත පුහුණු සැසි සමඟ Pos Saas POS හි සම්පූර්ණ විභවය අගුළු හරින්න. මූලික කරුණුවල සිට උසස් තාක්ෂණික ක්රම දක්වා, ඔබේ ව්යාපාර ක්රියාවලීන් ප්රශස්ත කිරීම සඳහා පද්ධතියේ සෑම අංශයක්ම භාවිතා කිරීමට ඔබ හොඳින් දන්නා බව අපි සහතික කරමු."),
        "unpaid": MessageLookupByLibrary.simpleMessage("භාජනය"),
        "update": MessageLookupByLibrary.simpleMessage("යාවත්කාලීනය"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("දුරකථන එකතු කරන්න"),
        "updateNow":
            MessageLookupByLibrary.simpleMessage("දැනටමත් යාවත්කාල කරනවා"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("නිශ්චිතය යාවත් කරනවා"),
        "updateYourPlanFirstYourLimitIsOver": MessageLookupByLibrary.simpleMessage(
            "ඔබගේ සැලැස්ම ප්‍රථමය යාවත්කාලීන කරන්න, \\n ඔබගේ සීමාව ඉක්මවා ගියා"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("ඔබගේ පැත්තක් යාවත්කාල කිරීම"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "ඔබේ වෛර සම්බන්ධය සුරැකීම සඳහා ඔබගේ පැතිකඩය යාවත් කරන්න"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "ඔබගේ පැත්තක් යවන කාර්යය සමඟ සම්බන්ධයක් කිරීම සඳහා ඔබට පැත්තක් යාවත්කාල කළ යුතුයි"),
        "updated": MessageLookupByLibrary.simpleMessage("අලුත් කළ"),
        "upload": MessageLookupByLibrary.simpleMessage("උඩුගත කරන්න"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("ලේඛනය උඩුගත කරන්න"),
        "uploadDone":
            MessageLookupByLibrary.simpleMessage("උඩුගත කිරීම සිදු කරන ලදී"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("ගොනුව උඩුගත කරන්න"),
        "usbC": MessageLookupByLibrary.simpleMessage("USB C"),
        "use": MessageLookupByLibrary.simpleMessage("භාවිතා කරන්න"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage(
            "ස්මාර්ට් බියාෂරය භාවිතා කරනවා"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("පරිශීලකයා මකනු ලැබිය"),
        "userRole": MessageLookupByLibrary.simpleMessage("පරිශීලක භාරකෝ"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("පරිශීලක හැඳුනුමේ විස්තර"),
        "userTitle": MessageLookupByLibrary.simpleMessage("පරිශීලක ශීර්ෂය"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "පරිශීලක මාතෘකාව හිස් විය නොහැක"),
        "value": MessageLookupByLibrary.simpleMessage("අගය"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("වට්ටම අය නොකෙරේ"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("OTP තහවුරු කිරීම"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("දුරකථන අංකය තහවුරු කරනවාද"),
        "viewAll": MessageLookupByLibrary.simpleMessage("සියලු බලන්න"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("විස්තර බලන්න"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("දියතල පාර්ශවයෙන් ආවාරයන්"),
        "warehouse": MessageLookupByLibrary.simpleMessage("ගබඩාව"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("ගබඩාව දැනටමත් ඇත"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("ගබඩා ලැයිස්තුව"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("ගබඩා නම"),
        "warranty": MessageLookupByLibrary.simpleMessage("හෝඩිය"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "විද්‍යුත් පත්කරන්නේ කෙසේදැයි අමතකව උත්සාහ කිරීමේ නම අයිතමයෙන් ඊමේල් එකක් ලබා ගැනීමට:"),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "බාධාවකින් තොරව මෙහෙයුම් වල වැදගත්කම අපි තේරුම් ගනිමු. ඉක්මන් විමසුමක් හෝ විස්තීර්ණ සැලකිල්ලක් වේවා ඔබට සහය වීමට අපගේ 24-24 සහාය ලබා ගත හැක්කේ එබැවිනි. අසමසම පාරිභෝගික සේවාවක් අත්විඳීමට ඕනෑම වේලාවක, ඕනෑම තැනක ඇමතුමක් හෝ WhatsApp හරහා අප හා සම්බන්ධ වන්න."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "අපි ගෙවීම් සමාලෝචනය කර, එය පැය 1-2ක් තුල අනුමත කරන්නෙමු"),
        "weekly": MessageLookupByLibrary.simpleMessage("සතියේ"),
        "weight": MessageLookupByLibrary.simpleMessage("බර"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("නව ක්‍රියාවලිය"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("සාම්ප්‍රදායික"),
        "wholeSalePrice": MessageLookupByLibrary.simpleMessage("වෙළෙඳුරු මිල"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("සැහැල්ලු මිල"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("සැපයුම්කරු"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("ඉක්මනින් එක් කෙරෙනු ඇත"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("අවසන් වන දිනය"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("ඔබගේ පණිවුඩය මෙහි ලියන්න"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("වැරදි OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "එවිට එය පරිශීලකයක් සදහා වැරදි මුරපදය ලබාදෙන නිසාය."),
        "yearly": MessageLookupByLibrary.simpleMessage("වසරේ"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("හරි, සෑමවිටම මකා දමන්න"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("ඔබ වලංගු පරිශීලකයෙකු නොවේ"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("ඔබ භාවිතා කරනවා"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "ඔබට බදු දීමනාවට වඩා ගෙවිය නොහැක"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("ඔබට ඊමේල් එකක් ලබාදී ඇත"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "ඔබට සාර්ථකත්වයෙන් ඔබේ ගිණුමට පිවිසුම් වී ඇත. Pos Saas සමඟ සම්බනවේ."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("ඔබට අනුමැතිය ලබා දිය යුතුය"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "ඔබට ඔබේ ගිණුමට නැවත පිවිසීමට අවශ්‍යයි"),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "ඔබට වෙළඳපොලට ගෙවූනු වෙනත් කිසිමාක් පීඨයේ නැති බවට වඩාත් හෝ හෝටමු කිරීමට ඔබට යෝජනා කළ යුතුය"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("ඔබගේ පණිවිඩය සුරකිය යුතුයි"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("ඔබගේ පැකේජය"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "ඔබගේ පැකේජය 5 දිනට පමණක් පවතීය")
      };
}
