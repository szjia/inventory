// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a pa locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'pa';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("ਜਾਰੀ ਰੱਖੋ"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("ਜੀਐਸਟੀ ਨੰਬਰ"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired": MessageLookupByLibrary.simpleMessage("MRP ਦੀ ਲੋੜ ਹੈ"),
        "OK": MessageLookupByLibrary.simpleMessage("ਠੀਕ ਹੈ"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("PayPal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("ਫੋਨ ਨੰਬਰ"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT ਕੋਡ"),
        "Snacks": MessageLookupByLibrary.simpleMessage("ਸਨੈਕਸ"),
        "TAX": MessageLookupByLibrary.simpleMessage("ਟੈਕਸ"),
        "Uploading": MessageLookupByLibrary.simpleMessage("ਅਪਲੋਡ ਹੋ ਰਿਹਾ ਹੈ"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("ਯੂਜ਼ਰ ਦਾ ਸਿਰਲੇਖ"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "ਤੁਹਾਡਾ ਪੈਕੇਜ ਅੱਜ ਸਮਾਪਤ ਹੋ ਜਾਵੇਗਾ\n\nਕਿਰਪਾ ਕਰਕੇ ਦੁਬਾਰਾ ਖਰੀਦੋ"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) ਸਿਸਟਮ ਸਿਰਫ਼ ਤੁਹਾਡੇ ਵਪਾਰ ਵਿੱਚ ਪੋਇੰਟ ਆਫ ਸੇਲ ਦੇ ਲੈਣ-ਦੇਣ ਅਤੇ ਸਬੰਧਿਤ ਗਤੀਵਿਧੀਆਂ ਨੂੰ ਸੁਗਮ ਬਣਾਉਣ ਦੇ ਲਈ ਪ੍ਰਦਾਨ ਕੀਤਾ ਗਿਆ ਹੈ।"),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) ਸਿਸਟਮ ਦੀ ਵਰਤੋਂ ਕਰਨ ਲਈ, ਤੁਹਾਨੂੰ ਇੱਕ ਖਾਤਾ ਬਣਾਉਣ ਦੀ ਲੋੜ ਹੋ ਸਕਦੀ ਹੈ। ਤੁਸੀਂ ਰਜਿਸਟ੍ਰੇਸ਼ਨ ਪ੍ਰਕਿਰਿਆ ਦੌਰਾਨ ਸਹੀ, ਵਰਤਮਾਨ ਅਤੇ ਪੂਰਨ ਜਾਣਕਾਰੀ ਪ੍ਰਦਾਨ ਕਰਨ ਲਈ ਸਹਿਮਤ ਹੋ ਅਤੇ ਇਸ ਜਾਣਕਾਰੀ ਨੂੰ ਅਪਡੇਟ ਕਰਕੇ ਇਸਨੂੰ ਸਹੀ ਅਤੇ ਪੂਰਨ ਰੱਖਣ ਲਈ ਸਹਿਮਤ ਹੋ।"),
        "aboutApp": MessageLookupByLibrary.simpleMessage("ਐਪ ਬਾਰੇ"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("ਸਾਡੇ ਬਾਰੇ"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("ਸ਼ਰਤਾਂ ਦੀ ਸਵੀਕਾਰਤਾ"),
        "accountName": MessageLookupByLibrary.simpleMessage("ਖਾਤੇ ਦਾ ਨਾਮ"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("ਖਾਤਾ ਨੰਬਰ"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("ਖਾਤਾ ਰਜਿਸਟ੍ਰੇਸ਼ਨ"),
        "acton": MessageLookupByLibrary.simpleMessage("ਕਰਵਾਈ"),
        "add": MessageLookupByLibrary.simpleMessage("ਜੋੜੋ"),
        "addBrand": MessageLookupByLibrary.simpleMessage("ਬ੍ਰਾਂਡ ਸ਼ਾਮਿਲ ਕਰੋ"),
        "addCategory":
            MessageLookupByLibrary.simpleMessage("ਸ਼੍ਰੇਣੀ ਸ਼ਾਮਿਲ ਕਰੋ"),
        "addContact": MessageLookupByLibrary.simpleMessage("ਸੰਪਰਕ ਸ਼ਾਮਲ ਕਰੋ"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("ਗਾਹਕ ਸ਼ਾਮਲ ਕਰੋ"),
        "addDelivery":
            MessageLookupByLibrary.simpleMessage("ਡਿਲਿਵਰੀ ਸ਼ਾਮਲ ਕਰੋ"),
        "addDescriptioN": MessageLookupByLibrary.simpleMessage("ਵਰਨਨ ਜੋੜੋ"),
        "addDescription": MessageLookupByLibrary.simpleMessage("ਨੋਟ ਸ਼ਾਮਲ ਕਰੋ"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("ਛੂਟ ਸ਼ਾਮਲ ਕਰੋ"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("ਦਸਤਾਵੇਜ਼ ID ਸ਼ਾਮਲ ਕਰੋ"),
        "addDucument":
            MessageLookupByLibrary.simpleMessage("ਦਸਤਾਵੇਜ਼ ਸ਼ਾਮਲ ਕਰੋ"),
        "addExpense": MessageLookupByLibrary.simpleMessage("ਖਰਚ ਸ਼ਾਮਲ ਕਰੋ"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("ਖਰਚ ਦੀ ਸ਼੍ਰੇਣੀ ਸ਼ਾਮਲ ਕਰੋ"),
        "addItems": MessageLookupByLibrary.simpleMessage("ਆਈਟਮ ਸ਼ਾਮਿਲ ਕਰੋ"),
        "addNew": MessageLookupByLibrary.simpleMessage("ਨਵਾਂ ਜੋੜੋ"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("ਨਵਾਂ ਪਤਾ ਸ਼ਾਮਲ ਕਰੋ"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("ਨਵਾਂ ਉਤਪਾਦ ਸ਼ਾਮਿਲ ਕਰੋ"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("ਨਵਾਂ ਕਰ ਜੋੜੋ"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "ਇੱਕ/ਕਈ ਟੈਕਸ ਕਿਸਮਾਂ ਨਾਲ ਨਵਾਂ ਕਰ ਜੋੜੋ"),
        "addNote": MessageLookupByLibrary.simpleMessage("ਨੋਟ ਸ਼ਾਮਲ ਕਰੋ"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("ਪਹਿਲਾਂ ਉਤਪਾਦ ਜੋੜੋ"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("ਪ੍ਰੋਮੋ ਕੋਡ ਸ਼ਾਮਲ ਕਰੋ"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("ਖਰੀਦ ਸ਼ਾਮਿਲ ਕਰੋ"),
        "addSales": MessageLookupByLibrary.simpleMessage("ਵਿਕਰੀ ਸ਼ਾਮਲ ਕਰੋ"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("ਸਫਲਤਾਪੂਰਕ ਸ਼ਾਮਲ ਕੀਤਾ ਗਿਆ"),
        "addUnit": MessageLookupByLibrary.simpleMessage("ਇਕਾਈ ਸ਼ਾਮਿਲ ਕਰੋ"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("ਯੂਜ਼ਰ ਰੋਲ ਸ਼ਾਮਲ ਕਰੋ"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("ਸਫਲਤਾ ਨਾਲ ਸ਼ਾਮਲ ਕੀਤਾ ਗਿਆ"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("ਕਾਰਟ ਵਿੱਚ ਜੋੜਿਆ ਗਿਆ"),
        "address": MessageLookupByLibrary.simpleMessage("ਪਤਾ"),
        "admin": MessageLookupByLibrary.simpleMessage("ਐਡਮਿਨ"),
        "all": MessageLookupByLibrary.simpleMessage("ਸਾਰੇ"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("ਸਾਰੇ ਵਪਾਰ ਹੱਲ"),
        "alreadyAdded":
            MessageLookupByLibrary.simpleMessage("ਪਹਿਲਾਂ ਹੀ ਸ਼ਾਮਲ ਕੀਤਾ ਗਿਆ"),
        "alreadyExists":
            MessageLookupByLibrary.simpleMessage("ਇਹ ਪਹਿਲਾਂ ਹੀ ਮੌਜੂਦ ਹੈ"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("ਪਹਿਲਾਂ ਹੀ ਇੱਕ ਖਾਤਾ ਹੈ"),
        "amount": MessageLookupByLibrary.simpleMessage("ਰਕਮ"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "ਇੱਕ ਈਮੇਲ ਭੇਜੀ ਗਈ ਹੈ\\nਤੁਹਾਡੇ ਇਨਬਾਕਸ ਦੀ ਜਾਂਚ ਕਰੋ"),
        "androidIOSAppSupport":
            MessageLookupByLibrary.simpleMessage("ਐਂਡਰਾਇਡ ਅਤੇ ਆਈਓਐਸ ਐਪ ਸਮਰਥਨ"),
        "applicableTax": MessageLookupByLibrary.simpleMessage("ਲਾਗੂ ਟੈਕਸ"),
        "apply": MessageLookupByLibrary.simpleMessage("ਲਾਗੂ ਕਰੋ"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "ਕੀ ਤੁਸੀਂ ਇਸ ਇਨਵੌਇਸ ਨੂੰ ਹਟਾਉਣ ਲਈ ਯਕੀਨੀ ਹੋ?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "ਕੀ ਤੁਸੀਂ ਇਸ ਵਿਕਰੀ ਨੂੰ ਹਟਾਉਣ ਲਈ ਯਕੀਨੀ ਹੋ?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "ਕੀ ਤੁਸੀਂ ਇਸ ਉਪਭੋਗਤਾ ਨੂੰ ਮਿਟਾਉਣ ਲਈ ਯਕੀਨੀ ਹੋ?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "ਕੀ ਤੁਸੀਂ ਇਸ ਕਰ ਨੂੰ ਮਿਟਾਉਣ ਲਈ ਯਕੀਨੀ ਹੋ?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "ਕੀ ਤੁਸੀਂ ਇਸ ਕਰ ਗਰੁੱਪ ਨੂੰ ਮਿਟਾਉਣ ਲਈ ਯਕੀਨੀ ਹੋ?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "ਕੀ ਤੁਸੀਂ ਇਸ ਗੋਦਾਮ ਨੂੰ ਮਿਟਾਉਣ ਚਾਹੁੰਦੇ ਹੋ?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "ਕੀ ਤੁਸੀਂ ਇਸ ਉਪਭੋਗਤਾ ਨੂੰ ਮਿਟਾਉਣ ਦੇ ਲਈ ਯਕੀਨੀ ਹੋ?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("ਅਧਿਕਾਰਿਤ ਦਸਤਖਤ"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) ਤੁਸੀਂ ਆਪਣੇ ਖਾਤੇ ਅਤੇ ਪਾਸਵਰਡ ਦੀ ਗੋਪਨੀਅਤ ਬਨਾਉਣ ਅਤੇ ਆਪਣੇ ਖਾਤੇ ਤੱਕ ਪਹੁੰਚ ਦੀ ਸੀਮਾ ਰੱਖਣ ਲਈ ਜ਼ਿੰਮੇਵਾਰ ਹੋ। ਤੁਸੀਂ ਆਪਣੇ ਖਾਤੇ ਤਹਿਤ ਹੋ ਰਹੀਆਂ ਸਾਰੀਆਂ ਗਤਿਵਿਧੀਆਂ ਲਈ ਜ਼ਿੰਮੇਵਾਰੀ ਸਵੀਕਾਰ ਕਰਦੇ ਹੋ।"),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) ਤੁਸੀਂ ਸਿਸਟਮ ਦੀ ਵਰਤੋਂ ਲਈ ਘੱਟੋ-ਘੱਟ 18 ਸਾਲ ਦਾ ਜਾਂ ਤੁਹਾਡੇ ਖੇਤਰ ਵਿੱਚ ਕਾਨੂੰਨੀ ਉਮਰ ਦਾ ਮਜਰ ਹੈ।"),
        "backSide": MessageLookupByLibrary.simpleMessage("ਪਿੱਛੇ ਦਾ ਪਾਸਾ"),
        "backToHome": MessageLookupByLibrary.simpleMessage("ਘਰ ਤੇ ਵਾਪਸ ਜਾਓ"),
        "balance": MessageLookupByLibrary.simpleMessage("ਬਕਾਇਆ"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("ਬੰਗਲਾਦੇਸ਼"),
        "bank": MessageLookupByLibrary.simpleMessage("ਬੈਂਕ"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("ਬੈਂਕ ਖਾਤਾ ਮੁਦਰਾ"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("ਬੈਂਕ ਖਾਤੇ ਦੀ ਕਰੰਸੀ"),
        "bankInformation": MessageLookupByLibrary.simpleMessage("ਬੈਂਕ ਜਾਣਕਾਰੀ"),
        "bankName": MessageLookupByLibrary.simpleMessage("ਬੈਂਕ ਦਾ ਨਾਮ"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("ਬੈਂਕ ਹਵਾਲਾ"),
        "barcodeFound": MessageLookupByLibrary.simpleMessage("ਬਾਰਕੋਡ ਮਿਲਿਆ"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("ਬਿੱਲ/ਇਨਵੌਇਸ"),
        "billTo": MessageLookupByLibrary.simpleMessage("ਬਿਲ ਕੀਤਾ ਜਾਵੇਗਾ"),
        "branchName": MessageLookupByLibrary.simpleMessage("ਬ੍ਰਾਂਚ ਦਾ ਨਾਮ"),
        "brand": MessageLookupByLibrary.simpleMessage("ਬ੍ਰਾਂਡ"),
        "brandName": MessageLookupByLibrary.simpleMessage("ਬ੍ਰਾਂਡ ਦਾ ਨਾਮ"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("ਬਰਗ\nਅਪਲੋਡ"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("ਬਿਜ਼ਨਸ ਸ਼੍ਰੇਣੀ"),
        "buy": MessageLookupByLibrary.simpleMessage("ਖਰੀਦੋ"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("ਪ੍ਰੀਮੀਅਮ ਯੋਜਨਾ ਖਰੀਦੋ"),
        "buySms": MessageLookupByLibrary.simpleMessage("ਐਸਐਮਐਸ ਖਰੀਦੋ"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "[ਤੁਹਾਡੀ ਕੰਪਨੀ ਦਾ ਨਾਮ] (\"ਕੰਪਨੀ\") ਦੁਆਰਾ ਪ੍ਰਦਾਨ ਕੀਤਾ ਗਿਆ ਪੋਇੰਟ ਆਫ ਸੇਲ (POS) ਸਿਸਟਮ (\"ਸਿਸਟਮ\") ਦੀ ਵਰਤੋਂ ਜਾਂ ਪਹੁੰਚ ਕਰਨ ਨਾਲ, ਤੁਸੀਂ ਇਨ੍ਹਾਂ ਸ਼ਰਤਾਂ ਨੂੰ ਮੰਨਣ ਲਈ ਸਹਿਮਤ ਹੋ। ਜੇਕਰ ਤੁਸੀਂ ਇਨ੍ਹਾਂ ਸ਼ਰਤਾਂ ਨੂੰ ਸਵੀਕਾਰ ਨਹੀਂ ਕਰਦੇ, ਤਾਂ ਸਿਸਟਮ ਦੀ ਵਰਤੋਂ ਨਾ ਕਰੋ।"),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) ਤੁਸੀਂ ਯਕੀਨੀ ਬਣਾਉਣ ਲਈ ਜ਼ਿੰਮੇਵਾਰ ਹੋ ਕਿ ਤੁਹਾਡੇ ਸਿਸਟਮ ਤੱਕ ਪਹੁੰਚ ਅਤੇ ਵਰਤੋਂ ਸਾਰੇ ਲਾਗੂ ਕਾਨੂੰਨਾਂ ਅਤੇ ਨਿਯਮਾਂ ਦੇ ਅਨੁਕੂਲ ਹੈ।"),
        "cacel": MessageLookupByLibrary.simpleMessage("ਰੱਦ ਕਰੋ"),
        "call": MessageLookupByLibrary.simpleMessage("ਕਾਲ ਕਰੋ"),
        "callForEmergencySupport":
            MessageLookupByLibrary.simpleMessage("ਐਮਰਜੈਂਸੀ ਸਹਾਇਤਾ ਲਈ ਕਾਲ ਕਰੋ"),
        "camera": MessageLookupByLibrary.simpleMessage("ਕੈਮਰਾ"),
        "cancel": MessageLookupByLibrary.simpleMessage("ਰੱਦ ਕਰੋ"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("ਸਾਰੇ ਉਤਪਾਦ ਰੱਦ ਕਰੋ"),
        "capacity": MessageLookupByLibrary.simpleMessage("ਸਮਰੱਥਾ"),
        "card": MessageLookupByLibrary.simpleMessage("ਕਾਰਡ"),
        "cash": MessageLookupByLibrary.simpleMessage("ਨਗਦ"),
        "cashFree": MessageLookupByLibrary.simpleMessage("ਕੈਸ਼ ਫ੍ਰੀ"),
        "categories": MessageLookupByLibrary.simpleMessage("ਸ਼੍ਰੇਣੀਆਂ"),
        "category": MessageLookupByLibrary.simpleMessage("ਸ਼੍ਰੇਣੀ"),
        "categoryName": MessageLookupByLibrary.simpleMessage("ਵਰਗ ਦਾ ਨਾਮ"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "ਵਰਗ ਦਾ ਨਾਮ ਪਹਿਲਾਂ ਹੀ ਮੌਜੂਦ ਹੈ"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("ਸ਼੍ਰੇਣੀ ਦਾ ਨਾਮ"),
        "change": MessageLookupByLibrary.simpleMessage("ਬਦਲਣਾ?"),
        "changePassword": MessageLookupByLibrary.simpleMessage("ਪਾਸਵਰਡ ਬਦਲੋ"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("ਇਮੇਲ ਚੈਕ ਕਰੋ"),
        "choseACustomer": MessageLookupByLibrary.simpleMessage("ਕਿਸਾਨ ਚੁਣੋ"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("ਇੱਕ ਸਪਲਾਇਰ ਚੁਣੋ"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("ਆਪਣੀਆਂ ਖਾਸੀਅਤਾਂ ਚੁਣੋ"),
        "clarence": MessageLookupByLibrary.simpleMessage("ਕਲੀਅਰੈਂਸ"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("ਜੁੜਨ ਲਈ ਕਲਿਕ ਕਰੋ"),
        "close": MessageLookupByLibrary.simpleMessage("ਬੰਦ ਕਰੋ"),
        "color": MessageLookupByLibrary.simpleMessage("ਰੰਗ"),
        "combinationOfMultipleTaxes":
            MessageLookupByLibrary.simpleMessage("(ਕਈ ਕਰਾਂ ਦਾ ਜੋੜ)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("ਜਲਦੀ ਆ ਰਿਹਾ ਹੈ"),
        "companyAddress": MessageLookupByLibrary.simpleMessage("ਕੰਪਨੀ ਦਾ ਪਤਾ"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("ਕੰਪਨੀ ਅਤੇ ਦੁਕਾਨ ਦਾ ਨਾਮ"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("ਕੰਪਨੀ ਅਤੇ ਕਾਰੋਬਾਰ ਦਾ ਨਾਮ"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("ਲੈਣ-ਦੇਣ ਪੂਰਾ ਕਰੋ"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("ਪਾਸਵਰਡ ਦੀ ਪੁਸ਼ਟੀ ਕਰੋ"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("ਵਾਪਸੀ ਦੀ ਪੁਸ਼ਟੀ ਕਰੋ"),
        "congratulations": MessageLookupByLibrary.simpleMessage("ਬਧਾਈਆਂ"),
        "contactUs": MessageLookupByLibrary.simpleMessage("ਸਾਡੇ ਨਾਲ ਸੰਪਰਕ ਕਰੋ"),
        "continu": MessageLookupByLibrary.simpleMessage("ਜਾਰੀ ਰੱਖੋ"),
        "country": MessageLookupByLibrary.simpleMessage("ਦੇਸ਼"),
        "create": MessageLookupByLibrary.simpleMessage("ਬਨਾਉਣ"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("ਮੁਫਤ ਖਾਤਾ ਬਣਾਓ"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("ਬਣਾਇਆ ਗਿਆ ਅਤੇ ਸੰਭਾਲਿਆ ਗਿਆ"),
        "currency": MessageLookupByLibrary.simpleMessage("ਮੁਦਰਾ"),
        "currentStock": MessageLookupByLibrary.simpleMessage("ਮੌਜੂਦਾ ਸਟਾਕ"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("ਕਸਟਮ ਇਨਵੌਇਸ ਬ੍ਰਾਂਡਿੰਗ"),
        "customer": MessageLookupByLibrary.simpleMessage("ਗਾਹਕ"),
        "customerDetails": MessageLookupByLibrary.simpleMessage("ਗਾਹਕ ਵੇਰਵੇ"),
        "customerGST": MessageLookupByLibrary.simpleMessage("ਗਾਹਕ ਦਾ ਜੀਐਸਟੀ"),
        "customerName": MessageLookupByLibrary.simpleMessage("ਗਾਹਕ ਦਾ ਨਾਮ"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("ਦਿਨ ਦੀ ਕਾਰਵਾਈ"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("ਡੈਸ਼ਬੋਰਡ ਦਾ ਆਧਾਰ"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("ਡਾਟਾ ਸਫਲਤਾ ਨਾਲ ਸੇਵ ਕੀਤਾ ਗਿਆ"),
        "date": MessageLookupByLibrary.simpleMessage("ਤਾਰੀਖ"),
        "day": MessageLookupByLibrary.simpleMessage("ਦਿਨ"),
        "dealer": MessageLookupByLibrary.simpleMessage("ਡਿਲਰ"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("ਡੀਲਰ ਕੀਮਤ"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("ਮੂਲ VAT ਪ੍ਰਤੀਸ਼ਤ"),
        "delete": MessageLookupByLibrary.simpleMessage("ਹਟਾਓ"),
        "deleting": MessageLookupByLibrary.simpleMessage("ਹਟਾਇਆ ਜਾ ਰਿਹਾ ਹੈ"),
        "deliveryAddress": MessageLookupByLibrary.simpleMessage("ਡਿਲਿਵਰੀ ਪਤਾ"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("ਡਿਲੀਵਰੀ ਪਤੇ"),
        "deliveryCharge": MessageLookupByLibrary.simpleMessage("ਡਿਲਿਵਰੀ ਖਰਚ"),
        "describtion": MessageLookupByLibrary.simpleMessage("ਵਰਣਨ"),
        "description": MessageLookupByLibrary.simpleMessage("ਵੇਰਵਾ"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("ਵੇਰਵਾ ਖਾਲੀ ਨਹੀਂ ਹੋ ਸਕਦਾ"),
        "details": MessageLookupByLibrary.simpleMessage("ਵੇਰਵਾਰ"),
        "discount": MessageLookupByLibrary.simpleMessage("ਛੋਟ"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("ਦਖਲ ਨਾ ਦਿਓ"),
        "done": MessageLookupByLibrary.simpleMessage("ਕੰਮ ਹੋ ਗਿਆ"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Excel ਫਾਰਮੈਟ ਡਾਊਨਲੋਡ ਕਰੋ"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "ਡਾਊਨਲੋਡ ਫੋਲਡਰ ਵਿੱਚ ਸਫਲਤਾ ਨਾਲ ਡਾਊਨਲੋਡ ਕੀਤਾ ਗਿਆ"),
        "due": MessageLookupByLibrary.simpleMessage("ਕਰਜ਼"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("ਕਰਜ਼ ਰਕਮ: "),
        "dueCollection": MessageLookupByLibrary.simpleMessage("ਕਰਜ਼ ਜਮ੍ਹਾਂ"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("ਉਤਰਦਾਇਤਿਆਂ ਦੀ ਇਕੱਠਾ ਰਿਪੋਰਟ"),
        "dueList": MessageLookupByLibrary.simpleMessage("ਕਰਜ਼ ਦੀ ਸੂਚੀ"),
        "dueReports": MessageLookupByLibrary.simpleMessage("ਬਕਾਇਆ ਰਿਪੋਰਟ"),
        "duration": MessageLookupByLibrary.simpleMessage("ਅਵਧੀ"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("ਅਵਧੀ: ਤੋਂ"),
        "easyToUseMobilePos":
            MessageLookupByLibrary.simpleMessage("ਵਰਤੋਂ ਲਈ ਆਸਾਨ ਮੋਬਾਈਲ ਪੋਸ"),
        "edit": MessageLookupByLibrary.simpleMessage("ਸੰਪਾਦਿਤ ਕਰੋ"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("ਖਰੀਦ ਇਨਵਾਇਸ ਸੰਪਾਦਨ ਕਰੋ"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("ਵਿਕਰੀ ਇਨਵਾਇਸ ਸੰਪਾਦਨ ਕਰੋ"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("ਸੋਸ਼ਲ ਮੀਡੀਆ ਨੂੰ ਸੰਪਾਦਿਤ ਕਰੋ"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("ਸਫਲਤਾਪੂਰਵਕ ਸੰਪਾਦਿਤ"),
        "editTax": MessageLookupByLibrary.simpleMessage("ਕਰ ਸੰਪਾਦਨ ਕਰੋ"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("ਕਰ ਗਰੁੱਪ ਸੰਪਾਦਨ ਕਰੋ"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("ਗੋਦਾਮ ਸੰਪਾਦਨ ਕਰੋ"),
        "email": MessageLookupByLibrary.simpleMessage("ਈਮੇਲ"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("ਈਮੇਲ ਪਤਾ"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("ਈਮੇਲ ਖਾਲੀ ਨਹੀਂ ਹੋ ਸਕਦੀ"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "ਈਮੇਲ ਭੇਜੀ ਗਈ! ਆਪਣੇ ਇਨਬਾਕਸ ਦੀ ਜਾਂਚ ਕਰੋ"),
        "endDate": MessageLookupByLibrary.simpleMessage("ਅੰਤ ਦੀ ਤਾਰੀਖ"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("ਮੰਨਯੋਗ ਰਕਮ ਦਾਖਲ ਕਰੋ"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("ਇੱਕ ਵੈਧ ਛੂਟ ਦਰਜ ਕਰੋ"),
        "enterAValidPhoneNumber":
            MessageLookupByLibrary.simpleMessage("ਮੰਨਯੋਗ ਫੋਨ ਨੰਬਰ ਦਾਖਲ ਕਰੋ"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("ਇੱਕ ਵੈਧ ਮੁੱਲ ਦਰਜ ਕਰੋ"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("ਇੱਕ ਵੈਧ ਮਾਤਰਾ ਦਰਜ ਕਰੋ"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("ਪਤਾ ਦਾਖਲ ਕਰੋ"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("ਰਕਮ ਦਾਖਲ ਕਰੋ।"),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("ਬ੍ਰਾਂਡ ਦਾ ਨਾਮ ਦਰਜ ਕਰੋ"),
        "enterCapacity": MessageLookupByLibrary.simpleMessage("ਸਮਰੱਥਾ ਦਰਜ ਕਰੋ"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("ਸ਼੍ਰੇਣੀ ਦਾ ਨਾਮ ਦਰਜ ਕਰੋ"),
        "enterColor": MessageLookupByLibrary.simpleMessage("ਰੰਗ ਦਰਜ ਕਰੋ"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "ਗਾਹਕ ਦਾ ਜੀਐਸਟੀ ਨੰਬਰ ਦਾਖਲ ਕਰੋ"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("ਡੀਲਰ ਕੀਮਤ ਦਰਜ ਕਰੋ"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("ਵੇਰਵਾ ਦਰਜ ਕਰੋ"),
        "enterDiscount": MessageLookupByLibrary.simpleMessage("ਛੋਟ ਦਰਜ ਕਰੋ"),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("ਖਰਚ ਦੀ ਤਾਰੀਖ ਦਾਖਲ ਕਰੋ"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("ਪੂਰਾ ਪਤਾ ਦਾਖਲ ਕਰੋ"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("ਇਨਵਾਇਸ ਨੰਬਰ ਦਰਜ ਕਰੋ"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "ਘੱਟ ਸਟਾਕ ਦੀ ਚੇਤਾਵਨੀ ਲਈ ਮਾਤਰਾ ਦਰਜ ਕਰੋ"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("ਉਤਪਾਦਕ ਦਾ ਨਾਮ ਦਰਜ ਕਰੋ"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("ਸੁਨੇਹਾ ਸਮੱਗਰੀ ਦਰਜ ਕਰੋ"),
        "enterMrpOrRetailerPirce":
            MessageLookupByLibrary.simpleMessage("MRP/ਰਿਟੇਲਰ ਕੀਮਤ ਦਰਜ ਕਰੋ"),
        "enterName": MessageLookupByLibrary.simpleMessage("ਨਾਮ ਦਾਖਲ ਕਰੋ"),
        "enterNote": MessageLookupByLibrary.simpleMessage("ਨੋਟ ਦਾਖਲ ਕਰੋ"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("ਪਾਰਟੀ ਦਾ ਨਾਮ ਦਾਖਲ ਕਰੋ"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("ਫੋਨ ਨੰਬਰ ਦਾਖਲ ਕਰੋ"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "ਉਤਪਾਦ ਕੋਡ ਦਰਜ ਕਰੋ ਜਾਂ ਸਕੈਨ ਕਰੋ"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("ਉਤਪਾਦ ਦਾ ਨਾਮ ਦਰਜ ਕਰੋ"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("ਖਰੀਦ ਕੀਮਤ ਦਰਜ ਕਰੋ"),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("ਸੰਕੇਤ ਨੰਬਰ ਦਾਖਲ ਕਰੋ"),
        "enterSize": MessageLookupByLibrary.simpleMessage("ਆਕਾਰ ਦਰਜ ਕਰੋ"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("ਸਟਾਕ ਦਰਜ ਕਰੋ"),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("ਕਰ ਦੀ ਦਰ ਦਰਜ ਕਰੋ"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("ਲੈਣ-ਦੇਣ ਆਈਡੀ ਦਾਖਲ ਕਰੋ"),
        "enterType": MessageLookupByLibrary.simpleMessage("ਕਿਸਮ ਦਰਜ ਕਰੋ"),
        "enterUserTitle": MessageLookupByLibrary.simpleMessage(
            "ਯੂਜ਼ਰ ਦੇ ਸਿਰਲੇਖ ਨੂੰ ਦਾਖਲ ਕਰੋ"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("ਮੰਨਯੋਗ ਰਕਮ ਦਾਖਲ ਕਰੋ"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("ਗੋਦਾਮ ਦਾ ਨਾਮ ਦਰਜ ਕਰੋ"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("ਭਾਰ ਦਰਜ ਕਰੋ"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("ਹੋਲਸੇਲ ਕੀਮਤ ਦਰਜ ਕਰੋ"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("ਇੱਥੇ ਆਪਣਾ ਵੇਰਵਾ ਦਰਜ ਕਰੋ"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("ਆਪਣਾ ਈਮੇਲ ਪਤਾ ਦਾਖਲ ਕਰੋ"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "ਆਪਣੀ ਫੀਡਬੈਕ ਦਾ ਸਿਰਲੇਖ ਦਰਜ ਕਰੋ"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("ਆਪਣਾ ਜੀਐਸਟੀ ਨੰਬਰ ਦਾਖਲ ਕਰੋ"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("ਆਪਣਾ ਮੋਬਾਈਲ ਨੰਬਰ ਦਰਜ ਕਰੋ"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("ਤੁਹਾਡਾ ਨਾਮ ਦਾਖਲ ਕਰੋ"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("ਆਪਣਾ ਫੋਨ ਨੰਬਰ ਦਾਖਲ ਕਰੋ"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("ਆਪਣਾ ਪਾਸਵਰਡ ਦਾਖਲ ਕਰੋ"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("ਤੁਹਾਡਾ ਫੋਨ ਨੰਬਰ ਦਾਖਲ ਕਰੋ"),
        "enterYourTransactionId":
            MessageLookupByLibrary.simpleMessage("ਆਪਣਾ ਲੈਣ-ਦੇਣ ID ਦਰਜ ਕਰੋ"),
        "error": MessageLookupByLibrary.simpleMessage("ਗਲਤੀ"),
        "excTax": MessageLookupByLibrary.simpleMessage("ਬਿਨਾ ਟੈਕਸ"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("Excel ਅਪਲੋਡਰ"),
        "exclusive": MessageLookupByLibrary.simpleMessage("ਵੱਖਰਾ"),
        "expense": MessageLookupByLibrary.simpleMessage("ਖਰਚ"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("ਖਰਚ ਦੀ ਸ਼੍ਰੇਣੀ"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("ਖਰਚ ਦੀ ਤਾਰੀਖ"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("ਖਰਚ ਲਈ"),
        "expenseReport": MessageLookupByLibrary.simpleMessage("ਖਰਚ ਦੀ ਰਿਪੋਰਟ"),
        "expireDate":
            MessageLookupByLibrary.simpleMessage("ਮਿਆਦ ਖਤਮ ਹੋਣ ਦੀ ਮਿਤੀ"),
        "expired": MessageLookupByLibrary.simpleMessage("ਮਿਆਦ ਖਤਮ ਹੋ ਗਈ"),
        "expiring": MessageLookupByLibrary.simpleMessage("ਮਿਆਦ ਖਤਮ ਹੋ ਰਹੀ ਹੈ"),
        "facebok": MessageLookupByLibrary.simpleMessage("ਫੇਸਬੁੱਕ"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("ਗਲਤੀ ਨਾਲ ਅਸਫਲ"),
        "fashion": MessageLookupByLibrary.simpleMessage("ਫੈਸ਼ਨ"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "ਖਾਸੀਤਾਂ ਉਹ ਮਹੱਤਵਪੂਰਨ ਭਾਗ ਹਨ ਜੋ ਪੋਸ ਸਾਅਸ ਨੂੰ ਪਰੰਪਰਿਕ ਹੱਲਾਂ ਤੋਂ ਵੱਖਰਾ ਕਰਦੀਆਂ ਹਨ।"),
        "feedBack": MessageLookupByLibrary.simpleMessage("ਫੀਡਬੈਕ"),
        "firstName": MessageLookupByLibrary.simpleMessage("ਪਹਿਲਾ ਨਾਮ"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("ਸਾਨੂੰ ਫੇਸਬੁੱਕ \'ਤੇ ਫੋਲੋ ਕਰੋ"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("ਸਾਨੂੰ ਟਵਿੱਟਰ \'ਤੇ ਫੋਲੋ ਕਰੋ"),
        "fontSide": MessageLookupByLibrary.simpleMessage("ਫਰੰਟ ਸਾਈਡ"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("ਅਸੀਮਤ ਵਰਤੋਂ ਲਈ"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("ਪਾਸਵਰਡ ਭੁੱਲ ਗਏ?"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("ਪਾਸਵਰਡ ਭੁੱਲ ਗਏ?"),
        "formDate": MessageLookupByLibrary.simpleMessage("ਤਾਰੀਖ ਤੋਂ"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("ਮੁਫਤ ਡਾਟਾ ਬੈਕਅਪ"),
        "freeLifeTimeUpdate":
            MessageLookupByLibrary.simpleMessage("ਮੁਫਤ ਜੀਵਨਕਾਲ ਅਪਡੇਟ"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("ਮੁਫ਼ਤ ਪੈਕੇਜ"),
        "freePlan": MessageLookupByLibrary.simpleMessage("ਮੁਫ਼ਤ ਯੋਜਨਾ"),
        "from": MessageLookupByLibrary.simpleMessage("(ਤੋਂ"),
        "fullyPaid":
            MessageLookupByLibrary.simpleMessage("ਪੂਰੀ ਤਰ੍ਹਾਂ ਭਰਿਆ ਗਿਆ"),
        "gallary": MessageLookupByLibrary.simpleMessage("ਗੈਲਰੀ"),
        "generatingPDF":
            MessageLookupByLibrary.simpleMessage("PDF ਬਣਾਇਆ ਜਾ ਰਿਹਾ ਹੈ"),
        "getOtp": MessageLookupByLibrary.simpleMessage("OTP ਪ੍ਰਾਪਤ ਕਰੋ"),
        "govermentId": MessageLookupByLibrary.simpleMessage("ਸਰਕਾਰੀ ID"),
        "guest": MessageLookupByLibrary.simpleMessage("ਅਤਿਥੀ"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("ਕੋਈ ਖਾਤਾ ਨਹੀਂ ਹੈ?"),
        "history": MessageLookupByLibrary.simpleMessage("ਇਤਿਹਾਸ"),
        "home": MessageLookupByLibrary.simpleMessage("ਘਰ"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "ਅਸੀਂ ਤੁਹਾਡੀ ਜਾਣਕਾਰੀ ਕਿਵੇਂ ਸੁਰੱਖਿਅਤ ਕਰਦੇ ਹਾਂ"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "ਅਸੀਂ ਤੁਹਾਡੀ ਜਾਣਕਾਰੀ ਕਿਵੇਂ ਵਰਤਦੇ ਹਾਂ"),
        "identityVerify": MessageLookupByLibrary.simpleMessage("ਛੋਟੀ ਪੁਸ਼ਟੀ"),
        "image": MessageLookupByLibrary.simpleMessage("ਚਿੱਤਰ"),
        "inHouseCantBeDelete": MessageLookupByLibrary.simpleMessage(
            "ਘਰੇਲੂ ਨੂੰ ਮਿਟਾਇਆ ਨਹੀਂ ਜਾ ਸਕਦਾ"),
        "inHouseCantBeEdited": MessageLookupByLibrary.simpleMessage(
            "ਘਰੇਲੂ ਨੂੰ ਸੰਪਾਦਿਤ ਨਹੀਂ ਕੀਤਾ ਜਾ ਸਕਦਾ"),
        "inWord": MessageLookupByLibrary.simpleMessage("ਸ਼ਬਦਾਂ ਵਿੱਚ"),
        "incTax": MessageLookupByLibrary.simpleMessage("ਟੈਕਸ ਸਮੇਤ"),
        "inclusive": MessageLookupByLibrary.simpleMessage("ਸ਼ਾਮਲ ਹੈ"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("ਸਟਾਕ ਵਧਾਓ"),
        "inistrument": MessageLookupByLibrary.simpleMessage("ਉਪਕਰਣ"),
        "instragram": MessageLookupByLibrary.simpleMessage("ਇੰਸਟਾਗ੍ਰਾਮ"),
        "invNo": MessageLookupByLibrary.simpleMessage("ਬਿੱਲ ਨੰ."),
        "invoice": MessageLookupByLibrary.simpleMessage("ਚਿੱਠੀ"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("ਇਨਵਾਇਸ ਨੰਬਰ"),
        "invoiceSetting": MessageLookupByLibrary.simpleMessage("ਇਨਵਾਇਸ ਸੈਟਿੰਗ"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("ਚਿੱਠੀ ਵੇਖਣ ਵਾਲਾ"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("ਆਈਟਮ ਸ਼ਾਮਿਲ ਕੀਤੀ"),
        "kg": MessageLookupByLibrary.simpleMessage("ਕਿਲੋ"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("KYC ਪੁਸ਼ਟੀकरण"),
        "language": MessageLookupByLibrary.simpleMessage("ਭਾਸ਼ਾ"),
        "lastName": MessageLookupByLibrary.simpleMessage("ਆਖਰੀ ਨਾਮ"),
        "ledger": MessageLookupByLibrary.simpleMessage("ਲੇਜਰ"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("ਲਾਇਫਟਾਈਮ\nਖਰੀਦ"),
        "link": MessageLookupByLibrary.simpleMessage("ਲਿੰਕ"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("ਲਿੰਕਡਇਨ"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("ਲਾਈਵ ਚੈਟ ਸਹਾਇਤਾ"),
        "loading": MessageLookupByLibrary.simpleMessage("ਲੋਡ ਹੋ ਰਿਹਾ ਹੈ"),
        "logIn": MessageLookupByLibrary.simpleMessage("ਲੌਗਇਨ"),
        "logOUt": MessageLookupByLibrary.simpleMessage("ਲੋਗ ਆਊਟ"),
        "logOut": MessageLookupByLibrary.simpleMessage("ਲੌਗ ਆਊਟ ਕਰੋ"),
        "login": MessageLookupByLibrary.simpleMessage("ਲੌਗਿਨ"),
        "logo": MessageLookupByLibrary.simpleMessage("ਲੋਗੋ"),
        "loss": MessageLookupByLibrary.simpleMessage("ਨੁਕਸਾਨ"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("ਨੁਕਸਾਨ/ਮਨਾਫਾ"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("ਨੁਕਸਾਨ/ਮਨਾਫਾ ਵੇਰਵਾ"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("ਨੁਕਸਾਨ/ਲਾਭ ਰਿਪੋਰਟ"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("ਨੁਕਸਾਨ/ਲਾਭ ਰਿਪੋਰਟਾਂ"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("ਘੱਟ ਸਟਾਕ ਦੀ ਚੇਤਾਵਨੀ"),
        "maan": MessageLookupByLibrary.simpleMessage("ਮਾਨ"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "ਆਪਣੇ ਗਾਹਕਾਂ \'ਤੇ ਇੱਕ ਅਟੱਲ ਪ੍ਰਭਾਵ ਬਣਾਓ ਬ੍ਰਾਂਡ ਕੀਤੇ ਇਨਵਾਇਸਾਂ ਨਾਲ। ਸਾਡਾ ਅਨਲਿਮਿਟਡ ਅੱਪਗਰੇਡ ਇਸ ਦੂਹਾਂ ਦੀ ਵਿਸ਼ੇਸ਼ਤਾ ਦਿੰਦਾ ਹੈ ਕਿ ਤੁਸੀਂ ਆਪਣੇ ਇਨਵਾਇਸਾਂ ਨੂੰ ਆਪਣੇ ਬ੍ਰਾਂਡ ਦੀ ਪਹਚਾਣ ਨੂੰ ਮਜ਼ਬੂਤ ਕਰਨ ਲਈ ਵਿਅਕਤੀਗਤ ਕਰ ਸਕਦੇ ਹੋ।"),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("ਆਪਣੇ ਵਪਾਰ ਨੂੰ ਸੰਗਠਿਤ ਕਰੋ"),
        "manufactureDate": MessageLookupByLibrary.simpleMessage("ਉਤਪਾਦਨ ਮਿਤੀ"),
        "margin": MessageLookupByLibrary.simpleMessage("ਮਾਰਜਿਨ"),
        "masterCard": MessageLookupByLibrary.simpleMessage("ਮਾਸਟਰ ਕਾਰਡ"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("ਉਤਪਾਦਕ"),
        "message": MessageLookupByLibrary.simpleMessage("ਸੰਦਰਭ"),
        "messageHistory": MessageLookupByLibrary.simpleMessage("ਸੁਨੇਹਾ ਇਤਿਹਾਸ"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "ਪੋਸ ਸਾਅਸ ਐਪ ਮੁਫ਼ਤ ਹੈ, ਵਰਤੋਂ ਲਈ ਆਸਾਨ। ਅਸਲ ਵਿੱਚ, ਇਹ ਦੁਨੀਆ ਵਿੱਚੋਂ ਇੱਕ ਸਰਵੋਤਮ ਪੀਓਐੱਸ ਸਿਸਟਮਾਂ ਵਿੱਚੋਂ ਇੱਕ ਹੈ।"),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "ਪੋਸ ਸਾਅਸ ਇੱਕ ਪੂਰਾ ਵਪਾਰ ਹੱਲ ਹੈ ਜਿਸ ਵਿੱਚ ਸਟਾਕ, ਖਾਤਾ, ਵਿਕਰੀ, ਖਰਚ & ਨੁਕਸਾਨ / ਮੋਨਾਫਾ ਸ਼ਾਮਲ ਹੈ।"),
        "mobile": MessageLookupByLibrary.simpleMessage("ਮੋਬਾਈਲ"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("ਮੋਬਾਈਲ ਭੁਗਤਾਨ"),
        "monthly": MessageLookupByLibrary.simpleMessage("ਮਹੀਨਾਵਾਰ"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("ਹੋਰ ਜਾਣਕਾਰੀ"),
        "name": MessageLookupByLibrary.simpleMessage("ਤੁਹਾਡਾ ਨਾਮ ਦਾਖਲ ਕਰੋ।"),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("ਨਾਮ ਪਹਿਲਾਂ ਹੀ ਮੌਜੂਦ ਹੈ"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("ਨਾਮ ਖਾਲੀ ਨਹੀਂ ਹੋ ਸਕਦਾ"),
        "next": MessageLookupByLibrary.simpleMessage("ਅਗਲਾ"),
        "noConnection": MessageLookupByLibrary.simpleMessage("ਕੋਈ ਜੁੜਾਅ ਨਹੀਂ"),
        "noData": MessageLookupByLibrary.simpleMessage("ਕੋਈ ਡਾਟਾ ਨਹੀਂ"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("ਕੋਈ ਡਾਟਾ ਉਪਲਬਧ ਨਹੀਂ"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("ਕੋਈ ਡੇਟਾ ਨਹੀਂ ਮਿਲਿਆ"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("ਕੋਈ ਇਤਿਹਾਸ ਨਹੀਂ ਮਿਲਿਆ!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("ਕੋਈ ਉਤਪਾਦ ਨਹੀਂ ਮਿਲਿਆ"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("ਕੋਈ ਉਪ ਕਰ ਨਹੀਂ ਚੁਣਿਆ ਗਿਆ"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("ਕੋਈ ਲੈਣ-ਦੇਣ ਨਹੀਂ ਮਿਲਿਆ!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "ਉਸ ਇਮੇਲ ਲਈ ਕੋਈ ਉਪਭੋਗਤਾ ਨਹੀਂ ਮਿਲਿਆ।"),
        "noUserRoleFound":
            MessageLookupByLibrary.simpleMessage("ਕੋਈ ਯੂਜ਼ਰ ਰੋਲ ਨਹੀਂ ਮਿਲਿਆ"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("ਸਰਗਰਮ ਉਪਭੋਗਤਾ ਨਹੀਂ"),
        "notProvided": MessageLookupByLibrary.simpleMessage("ਦਿੱਤਾ ਨਹੀਂ ਗਿਆ"),
        "note": MessageLookupByLibrary.simpleMessage("ਨੋਟ"),
        "notes": MessageLookupByLibrary.simpleMessage("ਨੋਟਸ"),
        "notification":
            MessageLookupByLibrary.simpleMessage("ਅਧਿਕਾਰਿਤ ਜਾਣਕਾਰੀ"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("ਓਟੀਪੀ ਭੇਜਿਆ ਗਿਆ"),
        "office": MessageLookupByLibrary.simpleMessage("ਕਾਰਜਾਲਾ"),
        "ok": MessageLookupByLibrary.simpleMessage("ਠੀਕ"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS ਜਿਸ ਵਿੱਚ ਵੱਡੀ ਕਾਰਗੁਜ਼ਾਰੀ ਹੈ, ਜਿਸ ਵਿੱਚ ਵਿਕਰੀ ਟ੍ਰੈਕਿੰਗ, ਇਨਵੈਂਟਰੀ ਮੈਨੇਜਮੈਂਟ ਸ਼ਾਮਲ ਹੈ।"),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "ਇਹ ਸਿਸਟਮ ਤੁਹਾਡੇ ਗਾਹਕਾਂ ਲਈ ਤੁਹਾਡੀਆਂ ਕਾਰਵਾਈਆਂ ਨੂੰ ਸੁਧਾਰਣ ਵਿੱਚ ਮਦਦ ਕਰਦਾ ਹੈ।"),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "ਸਾਡਾ POS ਸਿਸਟਮ ਦੈਨੀਕ ਕਾਰਵਾਈਆਂ ਨੂੰ ਆਪਣੇ-ਆਪ ਸੁਗਮ ਬਨਾਉਣਾ ਚਾਹੀਦਾ ਹੈ, ਜਿਸ ਨਾਲ ਨੈਵੀਗੇਟ ਕਰਨਾ ਆਸਾਨ ਹੁੰਦਾ ਹੈ।"),
        "openingBalance": MessageLookupByLibrary.simpleMessage("ਖੁਲ੍ਹਾ ਬਕਾਇਆ"),
        "order": MessageLookupByLibrary.simpleMessage("ਆਰਡਰ"),
        "other": MessageLookupByLibrary.simpleMessage("ਹੋਰ"),
        "otp": MessageLookupByLibrary.simpleMessage("ਬੰਦ ਕਰੋ"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("ਸਟਾਕ ਵਿੱਚ ਨਹੀਂ"),
        "pacakge": MessageLookupByLibrary.simpleMessage("ਪੈਕੇਜ"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("ਪੈਕੇਜ ਦੀ ਖਾਸੀਤਾਂ"),
        "paid": MessageLookupByLibrary.simpleMessage("ਭੁਗਤਾਨ ਕੀਤਾ"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("ਭੁਗਤਾਨ ਕੀਤੀ ਰਕਮ"),
        "parties": MessageLookupByLibrary.simpleMessage("ਪਾਰਟੀਆਂ"),
        "partiesList": MessageLookupByLibrary.simpleMessage("ਪਾਰਟੀ ਦੀ ਸੂਚੀ"),
        "partyGST": MessageLookupByLibrary.simpleMessage("ਪਾਰਟੀ ਜੀਐਸਟੀ"),
        "partyName": MessageLookupByLibrary.simpleMessage("ਪਾਰਟੀ ਦਾ ਨਾਮ"),
        "password": MessageLookupByLibrary.simpleMessage("ਪਾਸਵਰਡ"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "ਪਾਸਵਰਡ ਅਤੇ ਪੁਸ਼ਟੀ ਪਾਸਵਰਡ ਮੇਲ ਨਹੀਂ ਖਾਂਦੇ"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("ਗੁਪਤਕੋਡ ਖਾਲੀ ਨਹੀਂ ਹੋ ਸਕਦਾ"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("ਗੁਪਤਕੋਡ ਮਿਲਦਾ ਨਹੀਂ"),
        "payCash": MessageLookupByLibrary.simpleMessage("ਨਕਦ ਦਾ ਭੁਗਤਾਨ ਕਰੋ"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("Bkash ਨਾਲ ਭੁਗਤਾਨ ਕਰੋ"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("ਪੇਪਾਲ ਨਾਲ ਭੁਗਤਾਨ ਕਰੋ"),
        "payeeName":
            MessageLookupByLibrary.simpleMessage("ਭੁਗਤਾਨ ਕਰਨ ਵਾਲੇ ਦਾ ਨਾਮ"),
        "payeeNumber":
            MessageLookupByLibrary.simpleMessage("ਭੁਗਤਾਨ ਕਰਨ ਵਾਲੇ ਦਾ ਨੰਬਰ"),
        "payment": MessageLookupByLibrary.simpleMessage("ਭੁਗਤਾਨ"),
        "paymentAmount":
            MessageLookupByLibrary.simpleMessage("ਭੁਗਤਾਨ ਕੀਤੀ ਰਕਮ"),
        "paymentComplete": MessageLookupByLibrary.simpleMessage("ਭੁਗਤਾਨ ਪੂਰਾ"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("ਭੁਗਤਾਨ ਦੇ ਨਿਰਦੇਸ਼:"),
        "paymentMethod":
            MessageLookupByLibrary.simpleMessage("ਭੁਗਤਾਨ ਦਾ ਤਰੀਕਾ"),
        "paymentType": MessageLookupByLibrary.simpleMessage("ਭੁਗਤਾਨ ਦਾ ਤਰੀਕਾ"),
        "pdfView": MessageLookupByLibrary.simpleMessage("PDF ਦੇਖੋ"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("ਨਿੱਜੀ ਜਾਣਕਾਰੀ"),
        "phone": MessageLookupByLibrary.simpleMessage("ਫੋਨ"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("ਫੋਨ ਨੰਬਰ"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "ਫੋਨ ਨੰਬਰ ਪਹਿਲਾਂ ਹੀ ਵਰਤਿਆ ਗਿਆ ਹੈ"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("ਫੋਨ ਨੰਬਰ ਮੰਨਯੋਗ ਨਹੀਂ ਹੈ"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("ਫੋਨ ਨੰਬਰ ਲਾਜ਼ਮੀ ਹੈ"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("ਫਾਈਲ ਚੁਣੋ ਅਤੇ ਅਪਲੋਡ ਕਰੋ"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("ਅੰਤ ਦੀ ਤਾਰੀਖ ਚੁਣੋ"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("ਸ਼ੁਰੂਆਤ ਦੀ ਤਾਰੀਖ ਚੁਣੋ"),
        "plan": MessageLookupByLibrary.simpleMessage("ਯੋਜਨਾ"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("ਕਿਰਪਾ ਕਰਕੇ ਮਾਤਰਾ ਜੋੜੋ"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "ਕਿਰਪਾ ਕਰਕੇ ਆਪਣੇ ਇੰਟਰਨੈਟ ਕਨੈਕਸ਼ਨ ਦੀ ਜਾਂਚ ਕਰੋ"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "ਕਿਰਪਾ ਕਰਕੇ ਪਹਿਲਾਂ ਪ੍ਰਿੰਟਰ ਜੁੜੋ"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "ਕਿਰਪਾ ਕਰਕੇ ਆਪਣਾ ਬਲੂਟੂਥ ਪ੍ਰਿੰਟਰ ਜੁੜਨ ਕਰੋ"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "ਕਿਰਪਾ ਕਰਕੇ ਵੱਡਾ ਗੁਪਤਕੋਡ ਦਾਖਲ ਕਰੋ"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "ਕਿਰਪਾ ਕਰਕੇ ਇੱਕ ਪਾਸਵਰਡ ਦੀ ਪੁਸ਼ਟੀ ਦਾਖਲ ਕਰੋ"),
        "pleaseEnterAPassword": MessageLookupByLibrary.simpleMessage(
            "ਕਿਰਪਾ ਕਰਕੇ ਇੱਕ ਪਾਸਵਰਡ ਦਾਖਲ ਕਰੋ"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "ਕਿਰਪਾ ਕਰਕੇ ਇੱਕ ਮੰਨਯੋਗ ਈਮੇਲ ਦਾਖਲ ਕਰੋ"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("ਕਿਰਪਾ ਕਰਕੇ ਨਾਮ ਦਾਖਲ ਕਰੋ"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("ਕਿਰਪਾ ਕਰਕੇ ਪਾਸਵਰਡ ਦਰਜ ਕਰੋ"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "ਕਿਰਪਾ ਕਰਕੇ ਹੇਠਾਂ ਆਪਣਾ ਇਮੇਲ ਪਤਾ ਦਾਖਲ ਕਰੋ ਪਾਸਵਰਡ ਰੀਸੈਟ ਲਿੰਕ ਪ੍ਰਾਪਤ ਕਰਨ ਲਈ।"),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "ਕਿਰਪਾ ਕਰਕੇ ਲੈਣ-ਦੇਣ ਨੰਬਰ ਦਰਜ ਕਰੋ"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("ਕਿਰਪਾ ਕਰਕੇ ਰਕਮ ਦਾਖਲ ਕਰੋ"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "ਕਿਰਪਾ ਕਰਕੇ ਪਹਿਲਾਂ ਇੱਕ ਸ਼੍ਰੇਣੀ ਚੁਣੋ"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("ਕਿਰਪਾ ਕਰਕੇ ਇੱਕ ਯੋਜਨਾ ਚੁਣੋ"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "ਕਿਰਪਾ ਕਰਕੇ ਵਪਾਰ ਦੀ ਸ਼੍ਰੇਣੀ ਚੁਣੋ"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "ਕਿਰਪਾ ਕਰਕੇ ਐਪ ਦੀ ਵਰਤੋਂ ਕਰਨ ਲਈ ਵੈਧ ਖਰੀਦ ਕੋਡ ਦੀ ਵਰਤੋਂ ਕਰੋ"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("ਮੋਬਾਈਲ ਪੋਸ ਦੁਆਰਾ ਸੰਚਾਲਿਤ"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("ਇਸ ਨੂੰ ਚਲਾਇਆ ਗਿਆ"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("ਪ੍ਰੀਮੀਅਮ ਗਾਹਕ ਸਮਰਥਨ"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("ਪ੍ਰੀਮੀਅਮ ਯੋਜਨਾ"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("ਪਿਛਲੇ ਭੁਗਤਾਨ ਦੀ ਰਕਮ"),
        "price": MessageLookupByLibrary.simpleMessage("ਕੀਮਤ"),
        "print": MessageLookupByLibrary.simpleMessage("ਛਾਪੋ"),
        "printingOption": MessageLookupByLibrary.simpleMessage("ਛਾਪਣ ਦਾ ਵਿਕਲਪ"),
        "privacyPolicy": MessageLookupByLibrary.simpleMessage("ਗੋਪਨੀਯਤਾ ਨੀਤੀ"),
        "product": MessageLookupByLibrary.simpleMessage("ਉਤਪਾਦ"),
        "productCode": MessageLookupByLibrary.simpleMessage("ਉਤਪਾਦ ਕੋਡ"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("ਉਤਪਾਦ ਕੋਡ ਲਾਜ਼ਮੀ ਹੈ"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("ਉਤਪਾਦ ਕੋਡ/ਨਾਮ"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("ਉਤਪਾਦ ਦਾ ਵੇਰਵਾ"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("ਉਤਪਾਦ ਦੀਆਂ ਜਾਣਕਾਰੀਆਂ"),
        "productList": MessageLookupByLibrary.simpleMessage("ਉਤਪਾਦਾਂ ਦੀ ਸੂਚੀ"),
        "productName": MessageLookupByLibrary.simpleMessage("ਉਤਪਾਦ ਦਾ ਨਾਮ"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "ਉਤਪਾਦ ਨਾਮ ਪਹਿਲਾਂ ਹੀ ਇਸ ਗੋਦਾਮ ਵਿੱਚ ਮੌਜੂਦ ਹੈ"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "ਉਤਪਾਦ ਦਾ ਨਾਮ ਪਹਿਲਾਂ ਹੀ ਜੋੜਿਆ ਗਿਆ ਹੈ"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("ਉਤਪਾਦ ਦਾ ਨਾਮ ਲਾਜ਼ਮੀ ਹੈ"),
        "products": MessageLookupByLibrary.simpleMessage("ਉਤਪਾਦ"),
        "profile": MessageLookupByLibrary.simpleMessage("ਪ੍ਰੋਫਾਈਲ"),
        "profileEdit":
            MessageLookupByLibrary.simpleMessage("ਪ੍ਰੋਫਾਈਲ ਸੰਪਾਦਿਤ ਕਰੋ"),
        "profit": MessageLookupByLibrary.simpleMessage("ਮਨਾਫਾ"),
        "promo": MessageLookupByLibrary.simpleMessage("ਪ੍ਰਚਾਰ"),
        "promoCode": MessageLookupByLibrary.simpleMessage("ਪ੍ਰੋਮੋ ਕੋਡ"),
        "purchase": MessageLookupByLibrary.simpleMessage("ਖਰੀਦ"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage("ਖਰੀਦ ਅਲਾਰਮ"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("ਖਰੀਦ ਦੀ ਪੁਸ਼ਟੀ ਕੀਤੀ"),
        "purchaseDetails": MessageLookupByLibrary.simpleMessage("ਖਰੀਦ ਵੇਰਵਾ"),
        "purchaseInvoice": MessageLookupByLibrary.simpleMessage("ਖਰੀਦ ਇਨਵੌਇਸ"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("ਖਰੀਦਾਂ ਦੀ ਸੂਚੀ"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("ਹੁਣ ਖਰੀਦੋ"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("ਪ੍ਰੀਮੀਅਮ ਯੋਜਨਾ ਖਰੀਦੋ"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("ਖਰੀਦ ਕੀਮਤ"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("ਖਰੀਦ ਮੁੱਲ ਲਾਜ਼ਮੀ ਹੈ"),
        "purchaseRepoet": MessageLookupByLibrary.simpleMessage("ਖਰੀਦ ਰਿਪੋਰਟ"),
        "purchaseReports": MessageLookupByLibrary.simpleMessage("ਖਰੀਦ ਰਿਪੋਰਟ"),
        "purchaseReportss": MessageLookupByLibrary.simpleMessage("ਖਰੀਦ ਰਿਪੋਰਟ"),
        "purchaseReturn": MessageLookupByLibrary.simpleMessage("ਖਰੀਦ ਵਾਪਸੀ"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("ਖਰੀਦ ਵਾਪਸੀ ਰਿਪੋਰਟ"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("ਖਰੀਦਣ ਦਾ ਬਦਲਾਅ"),
        "qty": MessageLookupByLibrary.simpleMessage("ਮਾਤਰਾ"),
        "quantity": MessageLookupByLibrary.simpleMessage("ਮਾਤਰਾ"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("ਤਾਜ਼ਾ ਲੈਨ-ਦੇਣ"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("ਪਿਨ ਪ੍ਰਾਪਤ ਕੀਤਾ"),
        "referenceNumber": MessageLookupByLibrary.simpleMessage("ਸੰਕੇਤ ਨੰਬਰ"),
        "register": MessageLookupByLibrary.simpleMessage("ਰਜਿਸਟਰ"),
        "registering":
            MessageLookupByLibrary.simpleMessage("ਰਜਿਸਟਰ ਕੀਤਾ ਜਾ ਰਿਹਾ ਹੈ"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("ਬਚਤ ਕਰਜ਼"),
        "remove": MessageLookupByLibrary.simpleMessage("ਹਟਾਓ"),
        "reports": MessageLookupByLibrary.simpleMessage("ਰਿਪੋਰਟਾਂ"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("ਬੇਨਤੀ ਭੇਜੀ ਜਾ ਚੁਕੀ ਹੈ"),
        "resendCode": MessageLookupByLibrary.simpleMessage("ਮੁੜ ਭੇਜੋ ਕੋਡ"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("ਮੁੜ ਭੇਜੋ OTP:"),
        "retailer": MessageLookupByLibrary.simpleMessage("ਰਿਟੇਲਰ"),
        "retur": MessageLookupByLibrary.simpleMessage("ਵਾਪਸੀ"),
        "returN": MessageLookupByLibrary.simpleMessage("ਵਾਪਸੀ"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("ਵਾਪਸੀ ਦੀ ਰਕਮ"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("ਵਾਪਸੀ ਦੀ ਰਕਮ"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("ਵਾਪਸੀ QTY"),
        "revenue": MessageLookupByLibrary.simpleMessage("ਆਮਦਨ"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "ਆਪਣੇ ਕਾਰੋਬਾਰ ਦੇ ਡਾਟਾ ਨੂੰ ਆਸਾਨੀ ਨਾਲ ਸੁਰੱਖਿਅਤ ਕਰੋ। ਸਾਡਾ ਪੋਸ ਸਾਅਸ ਪੋਸ ਅਨਲਿਮਿਟਡ ਅੱਪਗਰੇਡ ਮੁਫ਼ਤ ਡਾਟਾ ਬੈਕਅਪ ਸ਼ਾਮਲ ਹੈ, ਇਹ ਯਕੀਨੀ ਬਣਾਉਂਦਾ ਹੈ ਕਿ ਤੁਹਾਡੀ ਕੀਮਤੀ ਜਾਣਕਾਰੀ ਕਿਸੇ ਅਣਪਛਾਤੇ ਘਟਨਾ ਦੇ ਖਿਲਾਫ ਸੁਰੱਖਿਅਤ ਹੈ। ਉਸ ਤੇ ਧਿਆਨ ਦਿਓ ਜੋ ਵਾਸਤਵਿਕ ਰੂਪ ਵਿੱਚ ਮਹੱਤਵਪੂਰਨ ਹੈ - ਤੁਹਾਡਾ ਕਾਰੋਬਾਰ ਵਧਾਉਣਾ।"),
        "saleAmount": MessageLookupByLibrary.simpleMessage("ਵਿਕਰੀ ਦੀ ਰਕਮ"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("ਵਿਕਰੀ ਵੇਰਵਾ"),
        "salePrice": MessageLookupByLibrary.simpleMessage("ਵਿਕਰੀ ਕੀਮਤ"),
        "saleReports": MessageLookupByLibrary.simpleMessage("ਵਿਕਰੀ ਰਿਪੋਰਟ"),
        "saleReportss": MessageLookupByLibrary.simpleMessage("ਵਿਕਰੀ ਰਿਪੋਰਟ"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("ਵਿਕਰੀ ਵਾਪਸੀ"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("ਵਿਕਰੀ ਵਾਪਸੀ ਰਿਪੋਰਟ"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("ਵਿਕਰੀ ਸੈਟਿੰਗ"),
        "sales": MessageLookupByLibrary.simpleMessage("ਵਿਕਰੀ"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("ਵਿਕਰੀ ਅਤੇ ਖਰੀਦ ਰਿਪੋਰਟਾਂ"),
        "salesList": MessageLookupByLibrary.simpleMessage("ਵਿਕਰੀ ਦੀ ਸੂਚੀ"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("ਵਿਕਰੀ ਵਾਪਸੀ"),
        "save": MessageLookupByLibrary.simpleMessage("ਸੇਵ ਕਰੋ"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("ਸੰਭਾਲੋ ਅਤੇ ਪ੍ਰਕਾਸ਼ਿਤ ਕਰੋ"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("ਬਦਲਾਵ ਸੇਵ ਕਰੋ"),
        "saving": MessageLookupByLibrary.simpleMessage("ਸੰਭਾਲਣਾ"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("ਉਤਪਾਦ QR ਕੋਡ ਸਕੈਨ ਕਰੋ"),
        "search": MessageLookupByLibrary.simpleMessage("ਖੋਜੋ"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "ਉਤਪਾਦ ਕੋਡ ਜਾਂ ਨਾਮ ਦੁਆਰਾ ਖੋਜੋ"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("ਸਾਰੇ ਪ੍ਰੋਮੋ ਕੋਡ ਦੇਖੋ"),
        "select": MessageLookupByLibrary.simpleMessage("ਚੁਣੋ"),
        "selectAProductForReturn":
            MessageLookupByLibrary.simpleMessage("ਵਾਪਸੀ ਲਈ ਇੱਕ ਉਤਪਾਦ ਚੁਣੋ"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("ਬ੍ਰਾਂਡ ਚੁਣੋ"),
        "selectCategory": MessageLookupByLibrary.simpleMessage("ਸ਼੍ਰੇਣੀ ਚੁਣੋ"),
        "selectContacts": MessageLookupByLibrary.simpleMessage("ਸੰਪਰਕ ਚੁਣੋ"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("ਉਤਪਾਦ ਦੀ ਸ਼੍ਰੇਣੀ ਚੁਣੋ"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("ਦੋਕਾਨ ਦੀ ਸ਼੍ਰੇਣੀ ਚੁਣੋ"),
        "selectTax": MessageLookupByLibrary.simpleMessage("ਟੈਕਸ ਚੁਣੋ"),
        "selectTaxType": MessageLookupByLibrary.simpleMessage("ਟੈਕਸ ਕਿਸਮ ਚੁਣੋ"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("ਇੱਕਾਈ ਚੁਣੋ"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("ਵਿਸ਼ੇਸ਼ਤਾਵਾਂ ਚੁਣੋ:"),
        "seller": MessageLookupByLibrary.simpleMessage("ਬੇਚਣ ਵਾਲਾ"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("ਦੁਕਾਨਦਾਰ"),
        "send": MessageLookupByLibrary.simpleMessage("ਭੇਜੋ"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("ਈਮੇਲ ਭੇਜੋ"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("ਸੁਨੇਹਾ ਭੇਜੋ"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("ਰੀਸੈਟ ਲਿੰਕ ਭੇਜੋ"),
        "sendSms": MessageLookupByLibrary.simpleMessage("ਐਸਐਮਐਸ ਭੇਜੋ"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("ਐਸਐਮਐਸ ਭੇਜਣਾ?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("ਵਟਸਐਪ ਸੁਨੇਹਾ ਭੇਜੋ"),
        "sendYOurEmail": MessageLookupByLibrary.simpleMessage("ਆਪਣਾ ਈਮੇਲ ਭੇਜੋ"),
        "sendingEmail":
            MessageLookupByLibrary.simpleMessage("ਈਮੇਲ ਭੇਜੀ ਜਾ ਰਹੀ ਹੈ"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("ਸੁਨੇਹਾ ਭੇਜ ਰਹੇ ਹਾਂ"),
        "serviceShipping": MessageLookupByLibrary.simpleMessage("ਸੇਵਾ/ਸ਼ਿਪਿੰਗ"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("ਆਪਣੀ ਪ੍ਰੋਫਾਈਲ ਸੈਟਅਪ ਕਰੋ"),
        "setting": MessageLookupByLibrary.simpleMessage("ਸੈਟਿੰਗ"),
        "share": MessageLookupByLibrary.simpleMessage("ਵੰਡੋ"),
        "shopGST": MessageLookupByLibrary.simpleMessage("ਦੋਕਾਨ ਦਾ ਜੀਐਸਟੀ"),
        "signIn": MessageLookupByLibrary.simpleMessage("ਸਾਈਨ ਇਨ ਕਰੋ"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("ਈਮੇਲ ਨਾਲ ਸਾਈਨ ਇਨ ਕਰੋ"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("ਗਾਹਕ ਦਾ ਦਸਤਖਤ"),
        "size": MessageLookupByLibrary.simpleMessage("ਆਕਾਰ"),
        "skip": MessageLookupByLibrary.simpleMessage("ਛੱਡੋ"),
        "sms": MessageLookupByLibrary.simpleMessage("ਐਸਐਮਐਸ"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("ਸੋਸ਼ਲ ਮਾਰਕੀਟਿੰਗ"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "ਮਾਫ ਕਰਨਾ, ਤੁਹਾਨੂੰ ਇਸ ਸੇਵਾ ਤੱਕ ਪਹੁੰਚ ਕਰਨ ਦੀ ਇਜਾਜ਼ਤ ਨਹੀਂ ਹੈ"),
        "startDate": MessageLookupByLibrary.simpleMessage("ਸ਼ੁਰੂਆਤ ਦੀ ਤਾਰੀਖ"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("ਨਵੀਂ ਵਿਕਰੀ ਸ਼ੁਰੂ ਕਰੋ"),
        "startTypingToSearch":
            MessageLookupByLibrary.simpleMessage("ਖੋਜਣ ਲਈ ਟਾਈਪ ਕਰਨਾ ਸ਼ੁਰੂ ਕਰੋ"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "ਤਕਨਾਲੋਜੀ ਦੇ ਵਿਕਾਸ ਦੇ ਅੱਗੇ ਰਹੋ ਬਿਨਾਂ ਕਿਸੇ ਵਾਧੂ ਖਰਚੇ ਦੇ। ਸਾਡਾ ਪੋਸ ਸਾਅਸ ਪੋਸ ਅਨਲਿਮਿਟਡ ਅੱਪਗਰੇਡ ਇਹ ਯਕੀਨੀ ਬਣਾਉਂਦਾ ਹੈ ਕਿ ਤੁਹਾਡੇ ਕੋਲ ਹਮੇਸ਼ਾ ਆਧੁਨਿਕ ਉਪਕਰਨ ਅਤੇ ਵਿਸ਼ੇਸ਼ਤਾਵਾਂ ਹਨ, ਜਿਸ ਨਾਲ ਤੁਹਾਡਾ ਕਾਰੋਬਾਰ ਅੱਗੇ ਰਹਿੰਦਾ ਹੈ।"),
        "stillUnpaid":
            MessageLookupByLibrary.simpleMessage("ਅਜੇ ਵੀ ਅਦਾਇਗੀ ਕਰਨੀ ਹੈ"),
        "stock": MessageLookupByLibrary.simpleMessage("ਸਟਾਕ"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("ਸਟੌਕ ਲਾਜ਼ਮੀ ਹੈ"),
        "stockList": MessageLookupByLibrary.simpleMessage("ਸਟਾਕ ਲਿਸਟ"),
        "stocks": MessageLookupByLibrary.simpleMessage("ਸਟਾਕ"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Excel ਫਾਈਲ ਬਣਾਉਣ ਲਈ ਸਟੋਰੇਜ ਦੀ ਆਗਿਆ ਦੀ ਲੋੜ ਹੈ"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("ਉਪ ਟੈਕਸ ਸੂਚੀ"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("ਉਪ ਕਰ"),
        "subTotal": MessageLookupByLibrary.simpleMessage("ਉਪ ਕੁੱਲ"),
        "submit": MessageLookupByLibrary.simpleMessage("ਜਮ੍ਹਾਂ ਕਰੋ"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "ਸਾਡੇ ਯੂਟਿਊਬ \'ਤੇ ਸਬਸਕ੍ਰਾਈਬ ਕਰੋ"),
        "subscription": MessageLookupByLibrary.simpleMessage("ਸਬਸਕ੍ਰਿਪਸ਼ਨ"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("ਸਫਲਤਾ ਨਾਲ ਕੀਤਾ ਗਿਆ"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("ਸਫਲਤਾ ਨਾਲ ਲੌਗ ਆਊਟ ਹੋ ਗਿਆ"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("ਸਫਲਤਾਪੂਰਵਕ ਅੱਪਡੇਟ ਕੀਤਾ ਗਿਆ"),
        "supplier": MessageLookupByLibrary.simpleMessage("ਸਪਲਾਇਰ"),
        "supplierName": MessageLookupByLibrary.simpleMessage("ਸਪਲਾਇਰ ਦਾ ਨਾਮ"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT ਕੋਡ"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "ਡ੍ਰਾਈਵਰ ਦੇ ਲਾਇਸੈਂਸ, ਰਾਸ਼ਟਰ ਉਪਛੇਦ ਜਾਂ ਪਾਸਪੋਰਟ ਦੀ ਫੋਟੋ ਲਓ"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "ਆਪਣੀ ਜਾਣਕਾਰੀ ਦੀ ਜਾਂਚ ਲਈ ਇੱਕ ਪਹਚਾਣ ਪੱਤਰ ਲਓ"),
        "tap": MessageLookupByLibrary.simpleMessage("ਟੈਪ ਕਰੋ"),
        "tax": MessageLookupByLibrary.simpleMessage("ਕਰ"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("ਕਰ ਗਰੁੱਪ"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("ਟੈਕਸ ਸਿਫ਼ਰ"),
        "taxRate": MessageLookupByLibrary.simpleMessage("ਕਰ ਦੀ ਦਰ"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "ਕਰ ਦੀਆਂ ਦਰਾਂ- ਤੁਹਾਡੀਆਂ ਕਰ ਦੀਆਂ ਦਰਾਂ ਨੂੰ ਪ੍ਰਬੰਧਿਤ ਕਰੋ"),
        "taxReport": MessageLookupByLibrary.simpleMessage("ਕਰ ਰਿਪੋਰਟ"),
        "taxType": MessageLookupByLibrary.simpleMessage("ਟੈਕਸ ਕਿਸਮ"),
        "taxes": MessageLookupByLibrary.simpleMessage("ਕਰ"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("ਸ਼ਰਤਾਂ ਅਤੇ ਸ਼ਰਤਾਂ"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("ਉਪਯੋਗ ਦੀਆਂ ਸ਼ਰਤਾਂ"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("ਸ਼ਰਤਾਂ ਅਤੇ ਨਿੱਜਤਾ"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "ਤੁਹਾਡੇ ਕਰਜ਼ ਭੁਗਤਾਨ ਲਈ ਧੰਨਵਾਦ"),
        "thankYou": MessageLookupByLibrary.simpleMessage("ਤੁਹਾਡਾ ਧੰਨਵਾਦ"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("ਤੁਹਾਡੀ ਖਰੀਦ ਲਈ ਧੰਨਵਾਦ"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "ਉਸ ਈਮੇਲ ਲਈ ਖਾਤਾ ਪਹਿਲਾਂ ਹੀ ਮੌਜੂਦ ਹੈ"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Excel ਫਾਈਲ ਪਹਿਲਾਂ ਹੀ ਡਾਊਨਲੋਡ ਕੀਤੀ ਜਾ ਚੁਕੀ ਹੈ"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "ਨਾਮ ਹੀ ਸਭ ਕੁਝ ਦੱਸਦਾ ਹੈ। ਪੋਸ ਸਾਅਸ ਪੋਸ ਅਨਲਿਮਿਟਡ ਨਾਲ, ਤੁਹਾਡੇ ਉਪਯੋਗ \'ਤੇ ਕੋਈ ਸੀਮਾ ਨਹੀਂ। ਚਾਹੇ ਤੁਸੀਂ ਕੁਝ ਵਪਾਰਾਂ ਨੂੰ ਪ੍ਰਕਿਰਿਆ ਕਰ ਰਹੇ ਹੋ ਜਾਂ ਗਾਹਕਾਂ ਦੇ ਇਕ ਬਹੁਤ ਵੱਡੇ ਧੱਕੇ ਦਾ ਸਾਹਮਣਾ ਕਰ ਰਹੇ ਹੋ, ਤੁਸੀਂ ਇਸ ਗੱਲ ਨੂੰ ਯਕੀਨੀ ਬਣਾਉਣ ਦੇ ਯੋਗ ਹੋ ਕਿ ਤੁਸੀਂ ਸੀਮਾਵਾਂ ਦੁਆਰਾ ਪਾਬੰਦੀ ਵਿੱਚ ਨਹੀਂ ਹੋ।"),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "ਦਿੱਤਾ ਗਿਆ ਪਾਸਵਰਡ ਬਹੁਤ ਸ਼ਕਤਿਸ਼ਾਲੀ ਹੈ"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "ਵਿਕਰੀ ਹਟਾਈ ਜਾਏਗੀ ਅਤੇ ਇਸ ਖਰੀਦ ਸਬੰਧੀ ਸਾਰੀ ਜਾਣਕਾਰੀ ਹਟਾਈ ਜਾਵੇਗੀ। ਕੀ ਤੁਸੀਂ ਇਸਨੂੰ ਹਟਾਉਣ ਲਈ ਯਕੀਨੀ ਹੋ?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "ਵਿਕਰੀ ਹਟਾਈ ਜਾਏਗੀ ਅਤੇ ਇਸ ਵਿਕਰੀ ਸਬੰਧੀ ਸਾਰੀ ਜਾਣਕਾਰੀ ਹਟਾਈ ਜਾਵੇਗੀ। ਕੀ ਤੁਸੀਂ ਇਸਨੂੰ ਹਟਾਉਣ ਲਈ ਯਕੀਨੀ ਹੋ?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "ਉਪਭੋਗਤਾ ਮਿਟਾ ਦਿੱਤਾ ਜਾਵੇਗਾ ਅਤੇ ਤੁਹਾਡੇ ਖਾਤੇ ਤੋਂ ਸਾਰੀ ਜਾਣਕਾਰੀ ਮਿਟਾ ਦਿੱਤੀ ਜਾਵੇਗੀ। ਕੀ ਤੁਸੀਂ ਇਸ ਨੂੰ ਮਿਟਾਉਣ ਲਈ ਯਕੀਨੀ ਹੋ?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "ਉਪਭੋਗਤਾ ਨੂੰ ਮਿਟਾਇਆ ਜਾਵੇਗਾ ਅਤੇ ਸਾਰੀ ਡਾਟਾ ਤੁਹਾਡੇ ਖਾਤੇ ਤੋਂ ਮਿਟਾਈ ਜਾਵੇਗੀ। ਕੀ ਤੁਸੀਂ ਇਸਨੂੰ ਮਿਟਾਉਣ ਲਈ ਯਕੀਨੀ ਹੋ?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("ਤੀਜੀ ਪੱਖੀ ਸੇਵਾਵਾਂ"),
        "thisCategoryCannotBeDeleted":
            MessageLookupByLibrary.simpleMessage("ਇਹ ਵਰਗ ਮਿਟਾਇਆ ਨਹੀਂ ਜਾ ਸਕਦਾ"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(ਇਸ ਮਹੀਨੇ)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "ਇਹ ਉਤਪਾਦ ਪਹਿਲਾਂ ਹੀ ਸ਼ਾਮਲ ਕੀਤਾ ਗਿਆ ਹੈ"),
        "title": MessageLookupByLibrary.simpleMessage("ਸਿਰਲੇਖ"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("ਸਿਰਲੇਖ ਖਾਲੀ ਨਹੀਂ ਹੋ ਸਕਦਾ"),
        "to": MessageLookupByLibrary.simpleMessage("ਤੱਕ"),
        "toDate": MessageLookupByLibrary.simpleMessage("ਤਾਰੀਖ ਤੱਕ"),
        "today": MessageLookupByLibrary.simpleMessage("ਅੱਜ"),
        "total": MessageLookupByLibrary.simpleMessage("ਕੁੱਲ"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("ਕੁੱਲ ਰਕਮ"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("ਕੁੱਲ ਇਕੱਤਰ ਕੀਤਾ ਗਿਆ"),
        "totalDue": MessageLookupByLibrary.simpleMessage("ਕੁੱਲ ਕਰਜ਼"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("ਕੁੱਲ ਖਰਚ"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("ਕੁੱਲ ਨੁਕਸਾਨ"),
        "totalPayable": MessageLookupByLibrary.simpleMessage("ਕੁੱਲ ਭੁਗਤਾਨ"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("ਕੁੱਲ ਕੀਮਤ"),
        "totalProducts": MessageLookupByLibrary.simpleMessage("ਕੁੱਲ ਉਤਪਾਦ"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("ਕੁੱਲ ਲਾਭ"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("ਕੁੱਲ ਖਰੀਦ"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("ਕੁੱਲ ਵਾਪਸੀ ਦੀ ਰਕਮ"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("ਕੁੱਲ ਵਾਪਸੀਆਂ"),
        "totalSale": MessageLookupByLibrary.simpleMessage("ਕੁੱਲ ਵਿਕਰੀ"),
        "totalStock": MessageLookupByLibrary.simpleMessage("ਕੁੱਲ ਸਟਾਕ"),
        "totalValue": MessageLookupByLibrary.simpleMessage("ਕੁੱਲ ਮੁੱਲ"),
        "totalVat": MessageLookupByLibrary.simpleMessage("ਕੁੱਲ ਵੈਟ"),
        "totals": MessageLookupByLibrary.simpleMessage("ਕੁੱਲ: "),
        "transaction": MessageLookupByLibrary.simpleMessage("ਲੈਣ-ਦੇਣ"),
        "transactionId": MessageLookupByLibrary.simpleMessage("ਲੈਣ-ਦੇਣ ID"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("ਮੁੜ ਕੋਸ਼ਿਸ਼ ਕਰੋ"),
        "twitter": MessageLookupByLibrary.simpleMessage("ਟਵਿੱਟਰ"),
        "type": MessageLookupByLibrary.simpleMessage("ਕਿਸਮ"),
        "unitName": MessageLookupByLibrary.simpleMessage("ਇਕਾਈ ਦਾ ਨਾਮ"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("ਇਕਾਈ ਕੀਮਤ"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("ਇਕਾਈ ਮੁੱਲ"),
        "units": MessageLookupByLibrary.simpleMessage("ਇਕਾਈਆਂ"),
        "unlimited": MessageLookupByLibrary.simpleMessage("ਅਪਰਿਮਿਤ"),
        "unlimitedUsage": MessageLookupByLibrary.simpleMessage("ਅਸੀਮਤ ਵਰਤੋਂ"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "ਪੋਸ ਸਾਅਸ ਪੋਸ ਦੀ ਪੂਰੀ ਸਮਰੱਥਾ ਨੂੰ ਖੋਲ੍ਹੋ ਸਾਡੇ ਮਾਹਿਰ ਟੀਮ ਦੁਆਰਾ ਚਲਾਏ ਗਏ ਨਿੱਜੀ ਤਾਲਿਮ ਸੈਸ਼ਨਾਂ ਨਾਲ। ਬੁਨਿਆਦੀ ਤੋਂ ਲੈ ਕੇ ਉੱਚਤਮ ਤਕਨੀਕਾਂ ਤੱਕ, ਅਸੀਂ ਯਕੀਨੀ ਬਣਾਉਂਦੇ ਹਾਂ ਕਿ ਤੁਸੀਂ ਪ੍ਰਣਾਲੀ ਦੇ ਹਰ ਪੱਖ ਨੂੰ ਬਿਹਤਰ ਕਰਨ ਲਈ ਅਚਿ-ਅਗਾਹ ਹੋ।"),
        "unpaid": MessageLookupByLibrary.simpleMessage("ਬਕਾਇਆ"),
        "update": MessageLookupByLibrary.simpleMessage("ਅਪਡੇਟ ਕਰੋ"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("ਸੰਪਰਕ ਅੱਪਡੇਟ ਕਰੋ"),
        "updateNow": MessageLookupByLibrary.simpleMessage("ਹੁਣ ਅਪਡੇਟ ਕਰੋ"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("ਉਤਪਾਦ ਨੂੰ ਅਪਡੇਟ ਕਰੋ"),
        "updateYourPlanFirstYourLimitIsOver": MessageLookupByLibrary.simpleMessage(
            "ਸਭ ਤੋਂ ਪਹਿਲਾਂ ਆਪਣੀ ਯੋਜਨਾ ਅੱਪਡੇਟ ਕਰੋ,\\nਤੁਹਾਡੀ ਸੀਮਾ ਖਤਮ ਹੋ ਚੁੱਕੀ ਹੈ"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("ਆਪਣਾ ਪ੍ਰੋਫਾਈਲ ਅਪਡੇਟ ਕਰੋ"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "ਆਪਣੀ ਪ੍ਰੋਫਾਈਲ ਨੂੰ ਅਪਡੇਟ ਕਰੋ ਤਾਂ ਕਿ ਤੁਹਾਡਾ ਡਾਕਟਰ ਬਿਹਤਰ ਪ੍ਰਭਾਵ ਨਾਲ ਜੁੜ ਸਕੇ"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "ਸੰਪਰਕ ਬਣਾਉਣ ਲਈ ਆਪਣਾ ਪ੍ਰੋਫਾਈਲ ਅਪਡੇਟ ਕਰੋ"),
        "updated": MessageLookupByLibrary.simpleMessage("ਨਵੀਨਤਮ ਕੀਤਾ ਗਿਆ"),
        "upload": MessageLookupByLibrary.simpleMessage("ਅਪਲੋਡ ਕਰੋ"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("ਦਸਤਾਵੇਜ਼ ਅਪਲੋਡ ਕਰੋ"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("ਅਪਲੋਡ ਹੋ ਗਿਆ"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("ਫਾਈਲ ਅਪਲੋਡ ਕਰੋ"),
        "upplier": MessageLookupByLibrary.simpleMessage("ਸਪਲਾਇਰ"),
        "usbC": MessageLookupByLibrary.simpleMessage("USB C"),
        "use": MessageLookupByLibrary.simpleMessage("ਉਪਯੋਗ ਕਰੋ"),
        "useMobiPos":
            MessageLookupByLibrary.simpleMessage("ਪੋਸ ਸਾਅਸ ਵਰਤੋਂ ਕਰੋ"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("ਸਿਸਟਮ ਦੀ ਵਰਤੋਂ"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("ਉਪਭੋਗਤਾ ਮਿਟਾਇਆ ਗਿਆ"),
        "userRole": MessageLookupByLibrary.simpleMessage("ਯੂਜ਼ਰ ਰੋਲ"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("ਉਪਭੋਗਤਾ ਭੂਮਿਕਾ ਵੇਰਵੇ"),
        "userTitle": MessageLookupByLibrary.simpleMessage("ਯੂਜ਼ਰ ਦਾ ਸਿਰਲੇਖ"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "ਉਪਭੋਗਤਾ ਸਿਰਲੇਖ ਖਾਲੀ ਨਹੀਂ ਹੋ ਸਕਦਾ"),
        "value": MessageLookupByLibrary.simpleMessage("ਮੁੱਲ"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("ਵੈਟ ਲਾਗੂ ਨਹੀਂ ਹੁੰਦਾ"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("OTP ਦੀ ਪੁਸ਼ਟੀ ਕਰਨਾ"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("ਫੋਨ ਨੰਬਰ ਦੀ ਪੁਸ਼ਟੀ ਕਰੋ"),
        "viewAll": MessageLookupByLibrary.simpleMessage("ਸਭ ਵੇਖੋ"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("ਵੇਰਵੇ ਦੇਖੋ"),
        "walkInCustomer": MessageLookupByLibrary.simpleMessage("ਵਾਕ-ਇਨ ਗਾਹਕ"),
        "warehouse": MessageLookupByLibrary.simpleMessage("ਗੋਦਾਮ"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("ਗੋਦਾਮ ਪਹਿਲਾਂ ਹੀ ਮੌਜੂਦ ਹੈ"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("ਗੋਦਾਮ ਦੀ ਸੂਚੀ"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("ਗੋਦਾਮ ਦਾ ਨਾਮ"),
        "warranty": MessageLookupByLibrary.simpleMessage("ਵਾਰੰਟੀ"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "ਅਸੀਂ ਤੁਹਾਡੇ ਲਈ ਪਾਸਵਰਡ ਰੀਸੈਟ ਕਰਨ ਲਈ ਹਦਾਇਤਾਂ ਦੇ ਨਾਲ ਇਕ ਇਮੇਲ ਭੇਜੀ ਹੈ:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "ਅਸੀਂ ਆਪਣੇ ਐਪ ਦੀ ਕਾਰਗੁਜ਼ਾਰੀ ਨੂੰ ਸਮਰਥਨ ਦੇਣ ਲਈ ਤੀਜੀ ਪੱਖੀ ਸੇਵਾਵਾਂ ਦੀ ਵਰਤੋਂ ਕਰ ਸਕਦੇ ਹਾਂ, ਜਿਵੇਂ ਕਿ ਵਿਸ਼ਲੇਸ਼ਣ ਪ੍ਰਦਾਤਾ ਅਤੇ ਭੁਗਤਾਨ ਪ੍ਰੋਸੈਸਰ। ਇਹ ਤੀਜੀ ਪੱਖੀ ਸੇਵਾਵਾਂ ਤੁਹਾਡੇ ਐਪ ਦੀ ਵਰਤੋਂ ਦੌਰਾਨ ਤੁਹਾਡੇ ਬਾਰੇ ਜਾਣਕਾਰੀ ਇਕੱਠੀ ਕਰ ਸਕਦੀ ਹਨ। ਕਿਰਪਾ ਕਰਕੇ ਨੋਟ ਕਰੋ ਕਿ ਅਸੀਂ ਇਨ੍ਹਾਂ ਤੀਜੀ ਪੱਖੀ ਸੇਵਾਵਾਂ ਦੇ ਗੋਪਨੀਅਤਾ ਅਭਿਆਸਾਂ ਲਈ ਜ਼ਿੰਮੇਵਾਰ ਨਹੀਂ ਹਾਂ।"),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "ਅਸੀਂ ਤੁਹਾਡੇ ਨਿੱਜੀ ਜਾਣਕਾਰੀ ਦੀ ਸੁਰੱਖਿਆ ਕਰਨ ਲਈ ਉਦਯੋਗ ਮਿਆਰੀ ਉਪਾਇਆ ਲੈਂਦੇ ਹਾਂ, ਜਿਸ ਵਿੱਚ ਇੰਕ੍ਰਿਪਸ਼ਨ ਅਤੇ ਸੁਰੱਖਿਅਤ ਸਟੋਰੇਜ ਸ਼ਾਮਲ ਹੈ। ਅਸੀਂ ਤੁਹਾਡੀ ਜਾਣਕਾਰੀ ਤੱਕ ਪਹੁੰਚ ਨੂੰ ਸਿਰਫ਼ ਅਧਿਕਾਰਤ ਕਰਮਚਾਰੀਆਂ ਤੱਕ ਸੀਮਿਤ ਕਰਦੇ ਹਾਂ।"),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "ਅਸੀਂ ਸਮਝਦੇ ਹਾਂ ਕਿ ਨਿਰੰਤਰ ਕਾਰਜ ਸਚਾਈ ਦੀ ਮਹੱਤਤਾ ਹੈ। ਇਸ ਲਈ ਸਾਡੀ 24/7 ਸਹਾਇਤਾ ਤੁਹਾਡੀ ਮਦਦ ਲਈ ਉਪਲਬਧ ਹੈ, ਚਾਹੇ ਉਹ ਕਿਸੇ ਤੇਜ਼ ਸਵਾਲ ਲਈ ਹੋਵੇ ਜਾਂ ਵਿਸਥਾਰਤ ਚਿੰਤਾ ਲਈ। ਸਾਡੇ ਨਾਲ ਕਦੇ ਵੀ, ਕਿਸੇ ਵੀ ਥਾਂ ਤੋਂ ਕਾਲ ਜਾਂ ਵਾਟਸਐਪ ਦੁਆਰਾ ਜੁੜੋ ਅਤੇ ਬੇਮਿਸਾਲ ਗਾਹਕ ਸੇਵਾ ਦਾ ਅਨੁਭਵ ਕਰੋ।"),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "ਅਸੀਂ ਤੁਹਾਨੂੰ ਸਾਡੇ ਐਪ \'ਤੇ ਸਭ ਤੋਂ ਵਧੀਆ ਅਨੁਭਵ ਪ੍ਰਦਾਨ ਕਰਨ ਲਈ ਤੁਹਾਡੇ ਨਿੱਜੀ ਜਾਣਕਾਰੀ ਦੀ ਵਰਤੋਂ ਕਰਦੇ ਹਾਂ, ਜਿਸ ਵਿੱਚ ਤੁਹਾਡੇ ਸਮੱਗਰੀ ਸੁਝਾਵਾਂ ਨੂੰ ਵਿਅਕਤੀਗਤ ਬਣਾਉਣਾ, ਤੁਹਾਨੂੰ ਮਾਹਿਰਾਂ ਨਾਲ ਜੋੜਨਾ ਅਤੇ ਸਾਡੇ ਐਪ ਦੀ ਕਾਰਗੁਜ਼ਾਰੀ ਵਿੱਚ ਸੁਧਾਰ ਲਿਆਉਣਾ ਸ਼ਾਮਲ ਹੈ। ਅਸੀਂ ਤੁਹਾਡੇ ਜਾਣਕਾਰੀ ਦੀ ਵਰਤੋਂ ਅਪਡੇਟਾਂ, ਪ੍ਰਮੋਸ਼ਨ ਜਾਂ ਸਾਡੇ ਐਪ ਨਾਲ ਸਬੰਧਿਤ ਹੋਰ ਜਾਣਕਾਰੀ ਬਾਰੇ ਤੁਸੀਂ ਨਾਲ ਗੱਲ ਕਰਨ ਲਈ ਵੀ ਕਰ ਸਕਦੇ ਹਾਂ।"),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "ਅਸੀਂ ਭੁਗਤਾਨ ਦੀ ਸਮੀਖਿਆ ਕਰਾਂਗੇ ਅਤੇ ਇਸਨੂੰ 1-2 ਘੰਟਿਆਂ ਵਿੱਚ ਮਨਜ਼ੂਰੀ ਦਿਆਂਗੇ"),
        "weekly": MessageLookupByLibrary.simpleMessage("ਸਾਪਤਾਹਿਕ"),
        "weight": MessageLookupByLibrary.simpleMessage("ਭਾਰ"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("ਨਵਾਂ ਕੀ ਹੈ"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("ਥੋਕ ਵਿੱਕਰੇਤਾ"),
        "wholeSalePrice": MessageLookupByLibrary.simpleMessage("ਹੋਲਸੇਲ ਕੀਮਤ"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("ਹੋਲਸੇਲ ਮੁੱਲ"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("ਹੋਲਸੇਲਰ"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("ਜਲਦੀ ਜੋੜਿਆ ਜਾਵੇਗਾ"),
        "willExpireAt":
            MessageLookupByLibrary.simpleMessage("ਇਥੇ ਮਿਆਦ ਖਤਮ ਹੋਵੇਗੀ"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("ਇੱਥੇ ਆਪਣਾ ਸੁਨੇਹਾ ਲਿਖੋ"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("ਗਲਤ ਓਟੀਪੀ"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "ਉਸ ਉਪਭੋਗਤਾ ਲਈ ਗਲਤ ਪਾਸਵਰਡ ਦਿੱਤਾ ਗਿਆ।"),
        "yearly": MessageLookupByLibrary.simpleMessage("ਸਾਲਾਨਾ"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("ਹਾਂ, ਸਦਾ ਲਈ ਮਿਟਾਓ"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("ਤੁਸੀਂ ਵੈਧ ਉਪਭੋਗਤਾ ਨਹੀਂ ਹੋ"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("ਤੁਸੀਂ ਵਰਤ ਰਹੇ ਹੋ"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "ਤੁਸੀਂ ਮਿਆਦ ਤੋਂ ਵੱਧ ਨਹੀਂ ਭੁਗਤਾਨ ਕਰ ਸਕਦੇ"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("ਤੁਹਾਨੂੰ ਇੱਕ ਇਮੇਲ ਮਿਲੀ ਹੈ"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "ਤੁਸੀਂ ਆਪਣੇ ਖਾਤੇ ਵਿੱਚ ਸਫਲਤਾਪੂਰਕ ਲੌਗਇਨ ਕੀਤਾ ਹੈ। ਪੋਸ ਸਾਅਸ ਨਾਲ ਰਹੋ।"),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("ਤੁਸੀਂ ਆਗਿਆ ਦੇਣੀ ਪਏਗੀ"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "ਤੁਹਾਨੂੰ ਆਪਣੇ ਖਾਤੇ \'ਤੇ ਦੁਬਾਰਾ ਲਾਗਇਨ ਕਰਨਾ ਪਵੇਗਾ।"),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "ਤੁਹਾਨੂੰ ਐਸਐਮਐਸ ਖਰੀਦਣ ਤੋਂ ਪਹਿਲਾਂ ਆਪਣੀ ਪਹਚਾਣ ਪੁਸ਼ਟੀ ਕਰਨੀ ਹੋਵੇਗੀ"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("ਤੁਹਾਡਾ ਸੁਨੇਹਾ ਬਾਕੀ ਹੈ"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("ਤੁਹਾਡਾ ਪੈਕੇਜ"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "ਤੁਹਾਡਾ ਪੈਕੇਜ 5 ਦਿਨਾਂ ਵਿੱਚ ਸਮਾਪਤ ਹੋ ਜਾਵੇਗਾ")
      };
}
