// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a eu locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'eu';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Jarraituko"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("GST Zenbakia"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired": MessageLookupByLibrary.simpleMessage("MRP behar da"),
        "OK": MessageLookupByLibrary.simpleMessage("Ongi"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Ph.no"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT Kodea"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Snackak"),
        "TAX": MessageLookupByLibrary.simpleMessage("TAX"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Kargatzen"),
        "UserTitle":
            MessageLookupByLibrary.simpleMessage("Erabiltzaile Titulua"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Zure paketea gaur iraungitzen da\n\nMesedez, erosi berriro"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) Sistema salmenta puntuko transakzioak eta zure negozioan lotutako jarduerak errazteko helburuz bakarrik ematen da."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) Sistema erabiltzeko, kontu bat sortu beharko duzu. Erregistro prozesuan informazio zehatza, eguneratua eta osatua emateko ados zaude, eta informazio hori eguneratuta mantentzeko."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("Aplikazioari Buruz"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Guri buruz"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Baldintzen Onarpena"),
        "accountName": MessageLookupByLibrary.simpleMessage("Kontu Izena"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("Kontu Zenbakia"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Kontu Erregistroa"),
        "acton": MessageLookupByLibrary.simpleMessage("Ekintza"),
        "add": MessageLookupByLibrary.simpleMessage("Gehitu"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Gehitu Marka"),
        "addCategory": MessageLookupByLibrary.simpleMessage("Gehitu Kategoria"),
        "addContact": MessageLookupByLibrary.simpleMessage("Gehitu Harremana"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Gehitu Bezeroa"),
        "addDelivery":
            MessageLookupByLibrary.simpleMessage("Gehitu Eguneratze"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Gehitu Deskribapena"),
        "addDescription":
            MessageLookupByLibrary.simpleMessage("Gehitu oharrak"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Gehitu Deskontua"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Gehitu Dokumentu Id"),
        "addDucument":
            MessageLookupByLibrary.simpleMessage("Gehitu Dokumentua"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Gehitu Gastua"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Gehitu Gastu Kategoria"),
        "addItems": MessageLookupByLibrary.simpleMessage("Gehitu Elementuak"),
        "addNew": MessageLookupByLibrary.simpleMessage("Gehitu Berri Bat"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Gehitu Helbide Berria"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Gehitu Produktu Berri"),
        "addNewTax":
            MessageLookupByLibrary.simpleMessage("Gehitu Zerga Berri Bat"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Gehitu Zerga Berri Bat tipo bakar/multzoarekin"),
        "addNote": MessageLookupByLibrary.simpleMessage("Gehitu Oharra"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Gehitu produktua lehenik"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Gehitu Promo Kodea"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Gehitu Erosketa"),
        "addSales": MessageLookupByLibrary.simpleMessage("Gehitu Salmentak"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Onartutako Gehitu"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Gehitu Unitatea"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Gehitu Erabiltzaile Rol"),
        "addedSuccessfully": MessageLookupByLibrary.simpleMessage("Onartutako"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("Erosketa orga gehitu da"),
        "address": MessageLookupByLibrary.simpleMessage("Helbidea"),
        "admin": MessageLookupByLibrary.simpleMessage("Administratzailea"),
        "all": MessageLookupByLibrary.simpleMessage("Denak"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("Negozio Soluzio guztiak"),
        "alreadyAdded":
            MessageLookupByLibrary.simpleMessage("Dagoeneko gehituta"),
        "alreadyExists":
            MessageLookupByLibrary.simpleMessage("Jada Existitzen Da"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Jadanik Kontu Bat Dut"),
        "amount": MessageLookupByLibrary.simpleMessage("Kantitatea"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "Email bat bidali da\\nBegiratu zure sarreran"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Android eta iOS Aplikazio Laguntza"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Aplikatutako Zerga"),
        "apply": MessageLookupByLibrary.simpleMessage("Aplikatu"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Ziur zaude faktura hau ezabatu nahi duzula?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Ziur zaude salmenta hau ezabatu nahi duzula?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Ziur zaude erabiltzaile hau ezabatu nahi duzula?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Ziur al zara Zerga hau ezabatu nahi duzula?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Ziur al zara Zerga Talde hau ezabatu nahi duzula?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Biltegi hau ezabatu nahi al duzu?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Ziur al zaude erabiltzaile hau ezabatzeko?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Baimentutako Sinadura"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Zure kontuaren eta pasahitzaren konfidentzialtasuna mantentzeko eta zure kontuaren sarbidea murrizteko arduraduna zara. Zure kontuan gertatzen den guztia arduratzen zara."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Sistema erabiltzeko 18 urte edo zure jurisdikzioan adin nagusia izan behar duzu."),
        "backSide": MessageLookupByLibrary.simpleMessage("Atzeko Aldea"),
        "backToHome": MessageLookupByLibrary.simpleMessage("Itzuli Hasierara"),
        "balance": MessageLookupByLibrary.simpleMessage("Ongietorri"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladesh"),
        "bank": MessageLookupByLibrary.simpleMessage("Bankua"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Banku Kontuaren Moneta"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Banku Kontu Moneta"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Banku Informazioa"),
        "bankName": MessageLookupByLibrary.simpleMessage("Banku Izena"),
        "bankTransfer":
            MessageLookupByLibrary.simpleMessage("Banku Transferentzia"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Barkodea aurkitu da"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Faktura/Billeta"),
        "billTo": MessageLookupByLibrary.simpleMessage("Faktura"),
        "branchName": MessageLookupByLibrary.simpleMessage("Adar Izena"),
        "brand": MessageLookupByLibrary.simpleMessage("Marka"),
        "brandName": MessageLookupByLibrary.simpleMessage("Markaren Izena"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("Taldeko\nKargatu"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Negozio Kategoria"),
        "buy": MessageLookupByLibrary.simpleMessage("Erosi"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Erosi Premium Plana"),
        "buySms": MessageLookupByLibrary.simpleMessage("Erosi Sms"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Zure enpresarako [Zure Enpresaren Izena] (\"Enpresa\") emandako Salmenta Puntua (POS) Sistema (\"Sistema\") erabiliz, erabilera baldintza hauek onartzen dituzula adierazten duzu. Baldintza hauek onartzen ez badituzu, ez erabili Sistema."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Sistema erabiltzeko eta sarbidea izateko, lege eta arau guztiei jarraitzeko arduraduna zara."),
        "cacel": MessageLookupByLibrary.simpleMessage("Ezeztatu"),
        "call": MessageLookupByLibrary.simpleMessage("Deitu"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "Deitu Larrialdi Laguntza eskaintzeko"),
        "camera": MessageLookupByLibrary.simpleMessage("Kamera"),
        "cancel": MessageLookupByLibrary.simpleMessage("Ezeztatu"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Ezeztatu Produktu Guztiak"),
        "capacity": MessageLookupByLibrary.simpleMessage("Gaitasuna"),
        "card": MessageLookupByLibrary.simpleMessage("Txartela"),
        "cash": MessageLookupByLibrary.simpleMessage("Dirutan"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Kategorial"),
        "category": MessageLookupByLibrary.simpleMessage("Kategoria"),
        "categoryName": MessageLookupByLibrary.simpleMessage("Kategoria Izena"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "Kategoria Izena Jada Existitzen Da"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("Kategoria Izena"),
        "change": MessageLookupByLibrary.simpleMessage("Aldatu?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Aldatu Pasahitza"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("Egiaztatu Emaila"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Hautatu Bezeroa"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Aukeratu Hornitzaile Bat"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Hautatu zure ezaugarriak"),
        "clarence": MessageLookupByLibrary.simpleMessage("Clarence"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Klikatu konexioa egiteko"),
        "close": MessageLookupByLibrary.simpleMessage("Itxi"),
        "color": MessageLookupByLibrary.simpleMessage("Kolorea"),
        "combinationOfMultipleTaxes":
            MessageLookupByLibrary.simpleMessage("(Zerga anitzen konbinazioa)"),
        "comingSoon":
            MessageLookupByLibrary.simpleMessage("Laster etorriko da"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Enpresaren Helbidea"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Enpresa eta Denda Izena"),
        "companyBusinessName": MessageLookupByLibrary.simpleMessage(
            "Enpresaren eta Negozioaren Izena"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Transakzioa Osatu"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Pasahitza Berretsi"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Itzulketa baieztatu"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Zorionak"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Harremanetan Jarri"),
        "continu": MessageLookupByLibrary.simpleMessage("Jarraitzea"),
        "country": MessageLookupByLibrary.simpleMessage("Herrialdea"),
        "create": MessageLookupByLibrary.simpleMessage("Sortu"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Sortu Kontu Doakoa"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Sortu eta Gorde da"),
        "currency": MessageLookupByLibrary.simpleMessage("Moneta"),
        "currentStock": MessageLookupByLibrary.simpleMessage("Egoera Gaur"),
        "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
            "Pertsonalizatutako Faktura Marka"),
        "customer": MessageLookupByLibrary.simpleMessage("Bezeroa"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Bezeroaren Xehetasunak"),
        "customerGST": MessageLookupByLibrary.simpleMessage("Bezeroaren GST"),
        "customerName":
            MessageLookupByLibrary.simpleMessage("Bezeroaren Izena"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Eguneko Transakzioa"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Datuen Bulegoa"),
        "dataSavedSuccessfully": MessageLookupByLibrary.simpleMessage(
            "Datuak arrakastaz gorde dira"),
        "date": MessageLookupByLibrary.simpleMessage("Data"),
        "day": MessageLookupByLibrary.simpleMessage("Eguna"),
        "dealer": MessageLookupByLibrary.simpleMessage("Saltzaile"),
        "dealerPrice":
            MessageLookupByLibrary.simpleMessage("Saltzaile Prezioa"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("BEZaren ehuneko finkoa"),
        "delete": MessageLookupByLibrary.simpleMessage("Ezabatu"),
        "deleting": MessageLookupByLibrary.simpleMessage("Ezabatzen"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Eguneratze Helbidea"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Bidalketa Helbideak"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Bidalketa Kostua"),
        "describtion": MessageLookupByLibrary.simpleMessage("Deskribapena"),
        "description": MessageLookupByLibrary.simpleMessage("Deskribapena"),
        "descriptionCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Deskribapenak hutsik ezin du izan"),
        "details": MessageLookupByLibrary.simpleMessage("Xehetasunak"),
        "discount": MessageLookupByLibrary.simpleMessage("Deskontua"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Ez egin nahas"),
        "done": MessageLookupByLibrary.simpleMessage("Eginda"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Jaitsi Excel Formatua"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Jaitsi da, jaitsitako karpenean"),
        "due": MessageLookupByLibrary.simpleMessage("Ordaindu"),
        "dueAmount":
            MessageLookupByLibrary.simpleMessage("Ordaindu Kantitatea: "),
        "dueCollection":
            MessageLookupByLibrary.simpleMessage("Ordainduen Bilketa"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("Epeak Biltzeko Txostenak"),
        "dueList": MessageLookupByLibrary.simpleMessage("Ordainduen Zerrenda"),
        "dueReports": MessageLookupByLibrary.simpleMessage("Zorrak Txostena"),
        "duration": MessageLookupByLibrary.simpleMessage("Iraupena"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Iraupena: TIK"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "Erraz erabiltzeko mugikorreko pos"),
        "edit": MessageLookupByLibrary.simpleMessage("Editatu"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Editatu Erosketa Faktura"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Editatu Salmenta Faktura"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Editatu Sare Sozialak"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Arrakastaz Editatu Da"),
        "editTax": MessageLookupByLibrary.simpleMessage("Editatu Zerga"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Editatu Zerga Taldea"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("Editatu Biltegia"),
        "email": MessageLookupByLibrary.simpleMessage("Email"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("Email Helbidea"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("E-posta hutsik ezin da egon"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "Emaila Bidali da! Ikusi zure Posta Sarrera"),
        "endDate": MessageLookupByLibrary.simpleMessage("Amaiera Data"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Sartu kopuru baliozkoa"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Sartu deskontu baliodun bat"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Sartu telefono zenbaki baliozkoa"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Sartu prezio baliodun bat"),
        "enterAValidQuantity": MessageLookupByLibrary.simpleMessage(
            "Sartu kantitate baliodun bat"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("Sartu Helbidea"),
        "enterAmount":
            MessageLookupByLibrary.simpleMessage("Sartu Kantitatea."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Sartu Markaren Izena"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Sartu Gaitasuna"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Sartu Kategoriaren Izena"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Sartu Kolorea"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "Sartu bezeroaren GST zenbakia"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Sartu Saltzaile Prezioa"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Sartu Deskribapena"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("Sartu Deskontua."),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Sartu Gastuaren Data"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Sartu Helbide Osokoa"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Sartu Faktura Zenbakia"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Sartu Stock Txikien Alerta Kantidadia"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Sartu Ekoizlea"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("Sartu Mezua Edukia"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "Sartu MRP/Saltzaileen Prezioa"),
        "enterName": MessageLookupByLibrary.simpleMessage("Sartu Izena"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Sartu Oharra"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Sartu Partaide Izena"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Sartu Telefono Zenbakia"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Sartu Produktu Kodea Edo Eskaneatu"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Sartu Produktuaren Izena"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Sartu Erosketa Prezioa."),
        "enterReferenceNumber": MessageLookupByLibrary.simpleMessage(
            "Sartu Erreferentzia Zenbakia"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Sartu Tamaina"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("Sartu Stockak."),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Sartu Zerga Tasa"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("Sartu Transakzio IDa"),
        "enterType": MessageLookupByLibrary.simpleMessage("Sartu Mota"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("Sartu erabiltzaile titulua"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Sartu kopuru baliozkoa"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Sartu Biltegi Izena"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Sartu Pisua"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Sartu Hiru Salmenta Prezioa"),
        "enterYourDescriptionHere": MessageLookupByLibrary.simpleMessage(
            "Sartu zure deskribapena hemen"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("Sartu Zure Email Helbidea"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "Sartu zure Iruzkin Izenburua"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Sartu zure GST zenbakia"),
        "enterYourMobileNumber": MessageLookupByLibrary.simpleMessage(
            "Sartu zure telefono zenbakia"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Sartu Zure Izena"),
        "enterYourNumber": MessageLookupByLibrary.simpleMessage(
            "Sartu zure telefono zenbakia"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Sartu zure pasahitza"),
        "enterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Sartu Zure Telefono Zenbakia"),
        "enterYourTransactionId":
            MessageLookupByLibrary.simpleMessage("Sartu zure transakzio id"),
        "error": MessageLookupByLibrary.simpleMessage("Errorea"),
        "excTax": MessageLookupByLibrary.simpleMessage("Exc. zergatik"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("Excel Igolea"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Kanpo"),
        "expense": MessageLookupByLibrary.simpleMessage("Gastua"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Gastu Kategoria"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Gastua Data"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Gastua Honetarako"),
        "expenseReport": MessageLookupByLibrary.simpleMessage("Gastu Txostena"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Iraungitze Data"),
        "expired": MessageLookupByLibrary.simpleMessage("Iraungita"),
        "expiring": MessageLookupByLibrary.simpleMessage("Iraungitzen"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Errorearekin Ezin Izan"),
        "fashion": MessageLookupByLibrary.simpleMessage("Moda"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Ezaugarriak dira POS Saas tradizionalen irtenbideetatik desberdintzen duten garrantzitsuenak."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Iruzkinak"),
        "firstName": MessageLookupByLibrary.simpleMessage("Izena"),
        "followUsOnFacebook": MessageLookupByLibrary.simpleMessage(
            "Jarri gurekin harremanetan\\nFacebooken"),
        "followUsOnTwitter": MessageLookupByLibrary.simpleMessage(
            "Jarri gurekin harremanetan\\nTwitterren"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Aurrealdea"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("Erabilera mugagabeetarako"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Pasahitza Ahaztu Dut"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Pasahitza Ahaztu?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Data Hasiera"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("Doako Datuen Babeskopia"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "Doako Bizitza Osoko Eguneratzea"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Doako Paketea"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Doako Plana"),
        "from": MessageLookupByLibrary.simpleMessage("(Tik"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Osorik ordainduta"),
        "gallary": MessageLookupByLibrary.simpleMessage("Galeria"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("PDFa Sortzen"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Lortu OTPa"),
        "govermentId": MessageLookupByLibrary.simpleMessage("Gobernu ID"),
        "guest": MessageLookupByLibrary.simpleMessage("Bisitaria"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Ez duzu konturik?"),
        "history": MessageLookupByLibrary.simpleMessage("Historia"),
        "home": MessageLookupByLibrary.simpleMessage("Etxea"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Nola Babesten Dugun Zure Informazioa"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Nola Erabiltzen Dugu Zure Informazioa"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Identitate Berrespena"),
        "image": MessageLookupByLibrary.simpleMessage("Irudia"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("InHouse ezin da ezabatu"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("InHouse ezin da editatu"),
        "inWord": MessageLookupByLibrary.simpleMessage("Hitzetan"),
        "incTax": MessageLookupByLibrary.simpleMessage("Inc. zergarekin"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Barne"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("Handitu Stocka"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Tresna"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Inv No."),
        "invoice": MessageLookupByLibrary.simpleMessage("Faktura"),
        "invoiceNumber":
            MessageLookupByLibrary.simpleMessage("Faktura Zenbakia"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Faktura Ezarpenak"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Faktura Ikuslea"),
        "itemAdded":
            MessageLookupByLibrary.simpleMessage("Elementua Gehitu da"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("KYC Berrespena"),
        "language": MessageLookupByLibrary.simpleMessage("Hizkuntza"),
        "lastName": MessageLookupByLibrary.simpleMessage("Abizenak"),
        "ledger": MessageLookupByLibrary.simpleMessage("Liburuxka"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Bizitzako\nErosketa"),
        "link": MessageLookupByLibrary.simpleMessage("Lotura"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Bizi Txata Laguntza"),
        "loading": MessageLookupByLibrary.simpleMessage("Kargatzen"),
        "logIn": MessageLookupByLibrary.simpleMessage("Sartu"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Saioa Itxi"),
        "logOut": MessageLookupByLibrary.simpleMessage("Saioa Itxi"),
        "login": MessageLookupByLibrary.simpleMessage("Sartu"),
        "logo": MessageLookupByLibrary.simpleMessage("Logoa"),
        "loss": MessageLookupByLibrary.simpleMessage("Galera"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Galera/Irabazi"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Galera/Irabazi Xehetasunak"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Galera/Irabazi Txostena"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Galera/Irabazi Txostenak"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Stock Txikien Alerta"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Bezeroei inpresio iraunkorra sortu faktura markatuarekin. Gure Mugagabea eguneratzeak faktura pertsonalizatzeko aukera berezia eskaintzen du, zure marka identitatea indartzen duena eta bezeroaren leialtasuna sustatzen duena."),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("Kudeatu zure negozioa "),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Ekoizpen Data"),
        "margin": MessageLookupByLibrary.simpleMessage("Margea"),
        "masterCard": MessageLookupByLibrary.simpleMessage("Master Card"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Ekoizlea"),
        "message": MessageLookupByLibrary.simpleMessage("Mezua"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Mezua Historioa"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Pos Saas aplikazioa doakoa da, erraz erabiltzeko. Izan ere, munduan dauden POS sistemarik onenetako bat da."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas negozio soluzio osoa da, stock, kontu, salmenta, gastu eta irabazi/galera dituena."),
        "mobile": MessageLookupByLibrary.simpleMessage("Mugikorra"),
        "mobilePayment":
            MessageLookupByLibrary.simpleMessage("Mugikorreko ordainketa"),
        "monthly": MessageLookupByLibrary.simpleMessage("Hileko"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("Informazio Gehiago"),
        "name": MessageLookupByLibrary.simpleMessage("Sartu Zure Izena."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Izena Jada Existitzen Da"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("Izena ezin da hutsa izan"),
        "next": MessageLookupByLibrary.simpleMessage("Hurrengoa"),
        "noConnection": MessageLookupByLibrary.simpleMessage("Konexiorik Ez"),
        "noData": MessageLookupByLibrary.simpleMessage("Datuik ez"),
        "noDataAvailable": MessageLookupByLibrary.simpleMessage("Daturik Ez"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Datuak Aurkitu Ez Daude"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("Ez da Historia Aurkitu!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Ez da produkturik aurkitu"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("Ez da Sub Zerga aukeratu"),
        "noTransactionFound": MessageLookupByLibrary.simpleMessage(
            "Ez da Transakziorik Aurkitu!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Email horretarako erabiltzaile bat aurkitu ez da."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "Ez Da Erabiltzaile Rolik Aurkitu"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Ez Aktibo Erabiltzailea"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Ez da emandako"),
        "note": MessageLookupByLibrary.simpleMessage("Oharra"),
        "notes": MessageLookupByLibrary.simpleMessage("oharrak"),
        "notification": MessageLookupByLibrary.simpleMessage("Jakinarazpena"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP hau bidali da"),
        "office": MessageLookupByLibrary.simpleMessage("Bulegoa"),
        "ok": MessageLookupByLibrary.simpleMessage("Ados"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS sistemak funtzionalitate handia du, salmenten jarraipena eta inbentarioaren kudeaketa barne."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Sistema honek zure bezeroen operazioak hobetzen laguntzen du."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Gure POS sistema eguneroko operazioak sinplifikatzeko diseinatuta dago, nabigatzea erraza eginez."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("Irekiera Oinarria"),
        "order": MessageLookupByLibrary.simpleMessage("Aginduak"),
        "other": MessageLookupByLibrary.simpleMessage("Beste"),
        "otp": MessageLookupByLibrary.simpleMessage("Itxi"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Stock-ean ez"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Paketea"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Pakete Ezaugarriak"),
        "paid": MessageLookupByLibrary.simpleMessage("Ordainduta"),
        "paidAmount":
            MessageLookupByLibrary.simpleMessage("Ordaindutako Kantitatea"),
        "parties": MessageLookupByLibrary.simpleMessage("Partiak"),
        "partiesList":
            MessageLookupByLibrary.simpleMessage("Partaideen Zerrenda"),
        "partyGST": MessageLookupByLibrary.simpleMessage("Partiaren GST"),
        "partyName": MessageLookupByLibrary.simpleMessage("Partaide Izena"),
        "password": MessageLookupByLibrary.simpleMessage("Pasahitza"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Pasahitza eta berretsi pasahitza bat etorri ez dira"),
        "passwordCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Pasahitza hutsik ezin da egon"),
        "passwordNotMach": MessageLookupByLibrary.simpleMessage(
            "Pasahitzak ez dira bat etorri"),
        "payCash": MessageLookupByLibrary.simpleMessage("Ordaindu Dirutan"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("Ordaindu bkash-ekin"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("PayPal bidez ordaindu"),
        "payeeName": MessageLookupByLibrary.simpleMessage(
            "Ordainketa Hartzailearen Izena"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage(
            "Ordainketa Hartzailearen Zenbakia"),
        "payment": MessageLookupByLibrary.simpleMessage("Ordainketa"),
        "paymentAmount":
            MessageLookupByLibrary.simpleMessage("Ordainketa Kantitatea"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Ordainketa Osatua"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Ordainketa Argibideak:"),
        "paymentMethod":
            MessageLookupByLibrary.simpleMessage("Ordainketa Modua"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Ordainketa Mota"),
        "pdfView": MessageLookupByLibrary.simpleMessage("PDF Ikuspegia"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Informazio pertsonala"),
        "phone": MessageLookupByLibrary.simpleMessage("Telefonoa"),
        "phoneNumber":
            MessageLookupByLibrary.simpleMessage("Telefono Zenbakia"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Telefono zenbakia jada erabilita dago"),
        "phoneNumberIsNotValid": MessageLookupByLibrary.simpleMessage(
            "Telefono zenbakia ez da baliozkoa"),
        "phoneNumberIsRequired": MessageLookupByLibrary.simpleMessage(
            "Telefono zenbakia beharrezkoa da"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("Hautatu eta Igo Fitxategia"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("Hautatu Amaiera Data"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Hautatu Hasiera Data"),
        "plan": MessageLookupByLibrary.simpleMessage("Plana"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("Mesedez, gehitu kantitatea"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Mesedez, egiaztatu zure internet konexioa"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Mesedez, konektatu inprimagailua lehenik"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Mesedez, konexioa egin zure bluetooth inprimagailuarekin"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Mesedez, sartu pasahitz handiago bat"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Mesedez, sartu pasahitz bat berresteko"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("Mesedez, sartu pasahitz bat"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Mesedez, sartu e-posta baliozkoa"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Mesedez, sartu izena"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("Mesedez, sartu pasahitza"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Mesedez, sartu beheko email helbidea pasahitza berrezartzeko esteka jaso ahal izateko."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Mesedez, sartu Transakzio Zenbakia"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("Mesedez, sartu kopurua"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Mesedez, hautatu kategoria bat lehenik"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("Mesedez, aukeratu plana"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Mesedez, hautatu negozio kategoria"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Mesedez, erabili aplikazioa erabiltzeko baliozko erosketaren kodea"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("MobiPos-ek Hornitua"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Hornituta"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Premium Bezero Laguntza"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Premium plana"),
        "previousPayAmounts": MessageLookupByLibrary.simpleMessage(
            "Aurreko Ordainketa Zenbatekoak"),
        "price": MessageLookupByLibrary.simpleMessage("Prezioa"),
        "print": MessageLookupByLibrary.simpleMessage("Inprimatu"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Inprimatze Aukera"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Pribatasun Politika"),
        "product": MessageLookupByLibrary.simpleMessage("Produktu"),
        "productCode": MessageLookupByLibrary.simpleMessage("Produktuen Kodea"),
        "productCodeIsRequired": MessageLookupByLibrary.simpleMessage(
            "Produktu kodea beharrezkoa da"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Produktuen kodea/Izena"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Produktuen Deskribapena"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Produktuen Xehetasunak"),
        "productList":
            MessageLookupByLibrary.simpleMessage("Produktu Zerrenda"),
        "productName": MessageLookupByLibrary.simpleMessage("Produktuen Izena"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Produktu izena jada badago biltegi honetan"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Produktuen izena dagoeneko gehitu da"),
        "productNameIsRequired": MessageLookupByLibrary.simpleMessage(
            "Produktu izena beharrezkoa da"),
        "products": MessageLookupByLibrary.simpleMessage("Produktuak"),
        "profile": MessageLookupByLibrary.simpleMessage("Profila"),
        "profileEdit":
            MessageLookupByLibrary.simpleMessage("Profilaren Editatzea"),
        "profit": MessageLookupByLibrary.simpleMessage("Irabazi"),
        "promo": MessageLookupByLibrary.simpleMessage("Promozioa"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Promozio Kodea"),
        "purchase": MessageLookupByLibrary.simpleMessage("Erosketa"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("Erosketa Alarma"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Erosketa Berretsita"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Erosketa Xehetasunak"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Erosketa Faktura"),
        "purchaseList":
            MessageLookupByLibrary.simpleMessage("Erosketa Zerrenda"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Erosi Orain"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Erosi Premium Plana"),
        "purchasePrice":
            MessageLookupByLibrary.simpleMessage("Erosketa Prezioa"),
        "purchasePriceIsRequired": MessageLookupByLibrary.simpleMessage(
            "Erosketa Prezioa beharrezkoa da"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("Erosketa Txostena"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Erosketa Prezioa"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Erosketa Txostenak"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("Erosketa Itzulketa"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("Erosketa Itzulketa Txostena"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Erosketaren Trantsizioa"),
        "qty": MessageLookupByLibrary.simpleMessage("Kop."),
        "quantity": MessageLookupByLibrary.simpleMessage("Kantitatea"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Azken Transakzioak"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("Pin-a Jasotakoa"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Erreferentzia Zenbakia"),
        "register": MessageLookupByLibrary.simpleMessage("Iragan"),
        "registering": MessageLookupByLibrary.simpleMessage("Erregistratzen"),
        "remainingDue":
            MessageLookupByLibrary.simpleMessage("Gelditzen Den Ordaindu"),
        "remove": MessageLookupByLibrary.simpleMessage("Kendu"),
        "reports": MessageLookupByLibrary.simpleMessage("Txostenak"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Eskaera bidali da"),
        "resendCode":
            MessageLookupByLibrary.simpleMessage("Berriro Bidali Kodea"),
        "resendOtp":
            MessageLookupByLibrary.simpleMessage("Berriro Bidali OTP : "),
        "retailer": MessageLookupByLibrary.simpleMessage("Merkatari"),
        "retur": MessageLookupByLibrary.simpleMessage("Itzuli"),
        "returN": MessageLookupByLibrary.simpleMessage("Itzuli"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("Itzuli Kopurua"),
        "returnAmount":
            MessageLookupByLibrary.simpleMessage("Itzuliko Zenbatekoa"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("Itzuli KANTITATEA"),
        "revenue": MessageLookupByLibrary.simpleMessage("Sarrera"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Zure negozioaren datuak babestu erraz. Gure Pos SaaS POS Mugagabeak doako datu babeskopia barne hartzen du, zure informazio baliotsua gertakari unerako babesteko. Egin zaitezte garrantzitsua denarekin - zure negozioaren hazkundea."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Salmenta Kopurua"),
        "saleDetails":
            MessageLookupByLibrary.simpleMessage("Salmenta Xehetasunak"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Salmenta Prezioa"),
        "saleReports":
            MessageLookupByLibrary.simpleMessage("Salmenta Txostena"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Salmenta Txostenak"),
        "saleReturn":
            MessageLookupByLibrary.simpleMessage("Salmenta itzulketa"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Salmenta Itzulketa Txostena"),
        "saleSetting":
            MessageLookupByLibrary.simpleMessage("Salmenta Ezarpena"),
        "sales": MessageLookupByLibrary.simpleMessage("Salmentak"),
        "salesAndPurchaseReports": MessageLookupByLibrary.simpleMessage(
            "Salmenta eta Erosketa Txostenak"),
        "salesList": MessageLookupByLibrary.simpleMessage("Salmenta Zerrenda"),
        "salesReturn":
            MessageLookupByLibrary.simpleMessage("Salmenta Itzulketa"),
        "save": MessageLookupByLibrary.simpleMessage("Gorde"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Gorde eta Argitaratu"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("Gorde Aldaketak"),
        "saving": MessageLookupByLibrary.simpleMessage("Gordetzea"),
        "scanProductQRCode": MessageLookupByLibrary.simpleMessage(
            "Eskaneari produktuen QR kodea"),
        "search": MessageLookupByLibrary.simpleMessage("Bilatu"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Bilatu produktuen kodea edo izena"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("Ikusi promozio kode guztiak"),
        "select": MessageLookupByLibrary.simpleMessage("Aukeratu"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Aukeratu itzultzeko produktua"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Hautatu Marka"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Hautatu kategoria"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Hautatu Kontaktuak"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("Hautatu Produktu Kategoria"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("Hautatu denda kategoria"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Hautatu Zerga"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Hautatu Zerga mota"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("Hautatu Unitatea"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Aldaketak Aukeratu: "),
        "seller": MessageLookupByLibrary.simpleMessage("Saltzailea"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Salmenta"),
        "send": MessageLookupByLibrary.simpleMessage("Bidali"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("Bidali Emaila"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Bidali Mezua"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("Bidali Berrezartze Esteka"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Bidali SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Bidali sms?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Bidali WhatsApp mezu bat"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Bidali zure Emaila"),
        "sendingEmail":
            MessageLookupByLibrary.simpleMessage("Emaila bidaltzen"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Mezua bidaltzen"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Zerbitzua/Ordainketa"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Ezarri Zure Profila"),
        "setting": MessageLookupByLibrary.simpleMessage("Ezarpena"),
        "share": MessageLookupByLibrary.simpleMessage("Partekatu"),
        "shopGST": MessageLookupByLibrary.simpleMessage("Dendaren GST"),
        "signIn": MessageLookupByLibrary.simpleMessage("Sartu"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("Sartu e-posta bidez"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Bezeroaren Sinadura"),
        "size": MessageLookupByLibrary.simpleMessage("Tamaina"),
        "skip": MessageLookupByLibrary.simpleMessage("Salto"),
        "sms": MessageLookupByLibrary.simpleMessage("Sms"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Sare Sozialen Marketina"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Barkatu, ez duzu zerbitzu honetara sartzeko baimenik"),
        "startDate": MessageLookupByLibrary.simpleMessage("Hasiera Data"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Hasieratu Salmenta Berria"),
        "startTypingToSearch":
            MessageLookupByLibrary.simpleMessage("Hasi idazten bilatzeko"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Teknologia aurrerapenaren lehen lerroan egon, inolako kostu gehigarririk gabe. Gure POS SaaS POS Mugagabea eguneratze guztietan tresna eta funtzionalitate berriengana iristeko aukera ematen dizu, zure negozioa punta-puntan mantentzen duena."),
        "stillUnpaid":
            MessageLookupByLibrary.simpleMessage("Oraindik ordaindu gabe"),
        "stock": MessageLookupByLibrary.simpleMessage("Stock"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Stocka beharrezkoa da"),
        "stockList": MessageLookupByLibrary.simpleMessage("Stock Zerrenda"),
        "stocks": MessageLookupByLibrary.simpleMessage("Stockak"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Excel fitxategia sortzeko biltegiratze baimena behar da"),
        "subTaxList":
            MessageLookupByLibrary.simpleMessage("Sub Zerga Zerrenda"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Sub Zerga"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Azpitotal"),
        "submit": MessageLookupByLibrary.simpleMessage("Bidali"),
        "subscribeToOurYoutube":
            MessageLookupByLibrary.simpleMessage("Harpidetu gure\\nYoutube-n"),
        "subscription": MessageLookupByLibrary.simpleMessage("Harpidetzak"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Arrakastaz eginda"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Arrakastaz Saioa Itxi Da"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Arrakastaz Eguneratu Da"),
        "supplier": MessageLookupByLibrary.simpleMessage("Hornitzailea"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("Hornitzailearen Izena"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT Kodea"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Hartu gidari lizentzia, nazio identitate txartela edo pasaportea"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "Hartu identitate txartela zure informazioa egiaztatzeko"),
        "tap": MessageLookupByLibrary.simpleMessage("Tokatu"),
        "tax": MessageLookupByLibrary.simpleMessage("Zerga"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Zerga Taldea"),
        "taxPercentage":
            MessageLookupByLibrary.simpleMessage("Zerga Portzentajea"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Zerga tasa"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Zerga Tasa - Kudeatu zure Zerga Tasa"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Zerga Txostena"),
        "taxType": MessageLookupByLibrary.simpleMessage("Zerga Mota"),
        "taxes": MessageLookupByLibrary.simpleMessage("Zergen"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Baldintzak eta Baldintzak"),
        "termsOfUse":
            MessageLookupByLibrary.simpleMessage("Erabilera Baldintzak"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Baldintzak & Pribatutasuna"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Eskerrik Asko Zure Ordainketa Galdetzeko"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Eskerrik Asko"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Eskerrik asko zure erosketa"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "Kontua dagoeneko existitzen da email horretarako"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage("Excel fitxategia jaitsi da"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Izena berez esan nahi du. Pos SaaS POS Mugagabearekin, ez dago erabilera mugarik. Beharbada, transakzio gutxi bat prozesatzen ari zara edo bezeroen irteera masibo bat jasaten, seguru funtzionatu dezakezu, mugak gabe."),
        "thePasswordProvidedIsTooWeak":
            MessageLookupByLibrary.simpleMessage("Emandako pasahitza ahula da"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Salmenta ezabatuko da eta erosketa honi buruzko datu guztiak ezabatuko dira. Ziur zaude ezabatu nahi duzula?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Salmenta ezabatuko da eta salmenta honi buruzko datu guztiak ezabatuko dira. Ziur zaude ezabatu nahi duzula?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Erabiltzailea ezabatuko da eta datu guztiak zure kontutik ezabatuko dira. Ziur al zaude ezabatu nahi duzula?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Erabiltzailea ezabatuko da eta datu guztiak zure kontutik ezabatuko dira. Ziur zaude ezabatu nahi duzula?"),
        "thirdPartyServices": MessageLookupByLibrary.simpleMessage(
            "Hirugarren Alderdiaren Zerbitzuak"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Kategoria hau ezin da ezabatu"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Hilabete honetan)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Produktu hau dagoeneko gehituta dago"),
        "title": MessageLookupByLibrary.simpleMessage("Izenburua"),
        "titleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Izenburuak hutsik ezin du izan"),
        "to": MessageLookupByLibrary.simpleMessage("arte"),
        "toDate": MessageLookupByLibrary.simpleMessage("Data Amaiera"),
        "today": MessageLookupByLibrary.simpleMessage("Gaur"),
        "total": MessageLookupByLibrary.simpleMessage("Total"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Kantitate Osoa"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Bilketa Guztira"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Osoa Ordaindu"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("Gastu Osoa"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Galera Totala"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("Ordainketa Totala"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Total Prezioa"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("Produktu guztira"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Irabazi Totala"),
        "totalPurchase":
            MessageLookupByLibrary.simpleMessage("Erosketa Guztira"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Itzulketa Kopurua Guztira"),
        "totalReturns":
            MessageLookupByLibrary.simpleMessage("Itzulketa Guztira"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Salmenta Totala"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Guztira Egoera"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Balio Orokorra"),
        "totalVat": MessageLookupByLibrary.simpleMessage("BEZ Totala"),
        "totals": MessageLookupByLibrary.simpleMessage("Guztira: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Transakzioa"),
        "transactionId": MessageLookupByLibrary.simpleMessage("Transakzio Id"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Saiatu Berriro"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Mota"),
        "unitName": MessageLookupByLibrary.simpleMessage("Unitatearen Izena"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Unitate Prezioa"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Unitateko Prezioa"),
        "units": MessageLookupByLibrary.simpleMessage("Unitateak"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Mugagabea"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Erabilera Mugagabea"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Pos SaaS POS-en potentzial osoa askatu, gure adituekin zuzendutako prestakuntza saio pertsonalizatuen bidez. Oinarrizko kontzeptuetatik hasita, teknika aurreratuetaraino, sistemaren alderdi guztiak nola erabili irakasten dizugu, zure negozio prozesuak optimizatzeko."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Ordaindu gabe"),
        "update": MessageLookupByLibrary.simpleMessage("Eguneratu"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Eguneratu Harremana"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Eguneratu Orain"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("Eguneratu Produktua"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Eguneratu zure plana lehenik, zure muga gainditu da"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Eguneratu Zure Profila"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Eguneratu zure profila zure medikuarekin hobea izateko"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Eguneratu zure profila zure bezeroekin hobe konektatzeko"),
        "updated": MessageLookupByLibrary.simpleMessage("Eguneratuta"),
        "upload": MessageLookupByLibrary.simpleMessage("Igo"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Kargatu Dokumentua"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("Igo da"),
        "uploadFile":
            MessageLookupByLibrary.simpleMessage("Kargatu Fitxategia"),
        "upplier": MessageLookupByLibrary.simpleMessage("Hornitzailea"),
        "usbC": MessageLookupByLibrary.simpleMessage("Usb C"),
        "use": MessageLookupByLibrary.simpleMessage("Erabili"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("Erabili Pos Saas"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Sistemaren Erabilera"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Erabiltzailea ezabatu da"),
        "userRole": MessageLookupByLibrary.simpleMessage("Erabiltzaile Rol"),
        "userRoleDetails": MessageLookupByLibrary.simpleMessage(
            "Erabiltzaile Rolaren Xehetasunak"),
        "userTitle":
            MessageLookupByLibrary.simpleMessage("Erabiltzaile Titulua"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Erabiltzailearen titulua hutsik ezin da egon"),
        "value": MessageLookupByLibrary.simpleMessage("Balioa"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("IVA ez da aplikatzen"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("OTP Egiaztatzen"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Telefono Zenbakia Egiaztatu"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Ikusi Guztiak"),
        "viewDetails":
            MessageLookupByLibrary.simpleMessage("Ikusi xehetasunak"),
        "walkInCustomer": MessageLookupByLibrary.simpleMessage("Sartu Bezeroa"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Biltegia"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Biltegia Jada Existitzen Da"),
        "warehouseList":
            MessageLookupByLibrary.simpleMessage("Biltegi Zerrenda"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("Biltegi Izena"),
        "warranty": MessageLookupByLibrary.simpleMessage("Berme"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Pasahitza berrezartzeko argibideak dituzten email bat bidali dugu:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Aplikazioaren funtzionalitatea babesteko hirugarren alderdiaren zerbitzuak erabil ditzakegu, analitika hornitzaileak eta ordainketa prozesatzaileak bezalakoak. Hirugarren alderdi horiek zure informazioa bildu dezakete aplikazioa erabiltzen duzunean. Mesedez, kontuan hartu hirugarren alderdi horien pribatutasun praktiketan erantzukizunik ez dugula."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Zure informazio pertsonala babesteko industriako estandarretako neurriak hartzen ditugu, enkriptazioa eta segurtasun biltegiratzea barne. Era berean, zure informaziora sarbidea duten langileak murrizten ditugu."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Guretzat funtzionamendu jarraituaren garrantzia ulertzen dugu. Horregatik, egunean zehar laguntza eskuragarri dago, galdera azkar bat edo kezka sakonago bat izan. Gurekin harremanetan jar zaitezte, edozein lekutatik eta edozein momentutan, deituz edo WhatsApp bidez, bezero zerbitzu paregabea esperimentatzeko."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Zure informazio pertsonala aplikazioan esperientzia hoberena emateko erabiltzen dugu, zure edukia pertsonalizatzeko, adituekin lotzeko eta aplikazioaren funtzionalitatea hobetzeko. Zure informazioa aplikazioaren eguneratzeei, promozioei edo beste informazio bati buruzko komunikazioak egiteko ere erabil dezakegu."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Ordainketa aztertuko dugu eta 1-2 ordutan onartuko dugu"),
        "weekly": MessageLookupByLibrary.simpleMessage("Astero"),
        "weight": MessageLookupByLibrary.simpleMessage("Pisua"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Zer Da Berria"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Handizkari"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Hiru Salmenta Prezioa"),
        "wholesalePrice":
            MessageLookupByLibrary.simpleMessage("Ekoizpen Prezioa"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Handizkaria"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Laster gehituko da"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Iraungiko da"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Idatzi zure mezua hemen"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("OTP okerra"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Erabiltzaile horretarako emandako pasahitza okerra da."),
        "yearly": MessageLookupByLibrary.simpleMessage("Urtero"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Bai, Betirako Ezabatu"),
        "youAreNotAValidUser": MessageLookupByLibrary.simpleMessage(
            "Ez Zira Erabiltzaile Baliozko"),
        "youAreUsing":
            MessageLookupByLibrary.simpleMessage("Erabiltzen ari zara"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Ez duzu zor duzuna baino gehiago ordaindu dezakezu"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Email Bat Jaso Duzu"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Zure kontuan arrakastaz sartu zara. Mantendu Pos SaaS-ekin."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("Baieztapena eman behar duzu"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Zure kontuan berriro sartu beharko duzu."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Identitate berretsi behar duzu sms bat erosi aurretik"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Zure mezua geratzen da"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Zure Paketea"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Zure paketearen iraungitze data 5 egun barru da")
      };
}
