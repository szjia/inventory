// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a af locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'af';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Gaan voort"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("BTW Nommer"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired": MessageLookupByLibrary.simpleMessage("MRP is nodig"),
        "OK": MessageLookupByLibrary.simpleMessage("OK"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Tel.nr"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT-kode"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Happies"),
        "TAX": MessageLookupByLibrary.simpleMessage("BELASTING"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Laai op"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("Gebruiker Titel"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Jou Pakket sal Vandag Verval\nKoop asseblief weer"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) Die Stelsel word slegs verskaf vir die doel om pun van verkoop transaksies en verwante aktiwiteite in jou besigheid te fasiliteer."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) Om die Stelsel te gebruik, kan dit nodig wees om \'n rekening te skep. Jy stem in om akkurate, huidige, en volledige inligting tydens die registrasieproses te voorsien en om sodanige inligting op te dateer om dit akkuraat en volledig te hou."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("Oor Toep"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Oor ons"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Aanvaarding van Voorwaardes"),
        "accountName": MessageLookupByLibrary.simpleMessage("Rekeningnaam"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("Rekeningnommer"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Rekening Registrasie"),
        "acton": MessageLookupByLibrary.simpleMessage("Aksie"),
        "add": MessageLookupByLibrary.simpleMessage("Voeg by"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Voeg Handelsmerk By"),
        "addCategory":
            MessageLookupByLibrary.simpleMessage("Voeg Kategorie By"),
        "addContact": MessageLookupByLibrary.simpleMessage("Voeg Kontak By"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Voeg Kliënt By"),
        "addDelivery":
            MessageLookupByLibrary.simpleMessage("Voeg Aflewering By"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Voeg Beskrywing by"),
        "addDescription": MessageLookupByLibrary.simpleMessage("Voeg nota by"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Voeg Afslag by"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Voeg Identiteitsdokument By"),
        "addDucument": MessageLookupByLibrary.simpleMessage("Voeg Dokument By"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Voeg Uitgawe By"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Voeg Uitgawe Kategorie By"),
        "addItems": MessageLookupByLibrary.simpleMessage("Voeg Items By"),
        "addNew": MessageLookupByLibrary.simpleMessage("Voeg nuwe by"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Voeg Nuwe Adres By"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Voeg Nuwe Produk By"),
        "addNewTax":
            MessageLookupByLibrary.simpleMessage("Voeg nuwe belasting by"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Voeg nuwe belasting by met enkel/meervoudige belasting tipe"),
        "addNote": MessageLookupByLibrary.simpleMessage("Voeg Nota By"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Voeg eers produk by"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Voeg Promo Kode by"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Voeg Aankoop By"),
        "addSales": MessageLookupByLibrary.simpleMessage("Voeg Verkope By"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Suksesvol Toegevoeg"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Voeg Eenheid By"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Voeg Gebruikersrol Toê"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Suksesvol bygevoeg"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("By mandjie gevoeg"),
        "address": MessageLookupByLibrary.simpleMessage("Adres"),
        "admin": MessageLookupByLibrary.simpleMessage("Admin"),
        "all": MessageLookupByLibrary.simpleMessage("Almal"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("Alle besigheidsoplossings"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("Reeds bygevoeg"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Bestaan reeds"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Het reeds \'n Rekening"),
        "amount": MessageLookupByLibrary.simpleMessage("Bedrag"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "’n E-pos is gestuur. Kyk in jou inkassie"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Android & iOS App Ondersteuning"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Toepaslike Belasting"),
        "apply": MessageLookupByLibrary.simpleMessage("Aansoek"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Is jy seker jy wil hierdie faktuur uitvee"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Is jy seker jy wil hierdie verkoop uitvee"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Is u seker u wil hierdie gebruiker uitvee"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Is jy seker jy wil hierdie belasting verwyder"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Is jy seker jy wil hierdie belastinggroep verwyder"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Wil jy hierdie pakhuis verwyder"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Is jy seker jy wil hierdie gebruiker verwyder?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Gemagtigde Handtekening"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Jy is verantwoordelik vir die handhawing van die vertroulikheid van jou rekening en wagwoord en vir die beperking van toegang tot jou rekening. Jy aanvaar verantwoordelikheid vir alle aktiwiteite wat onder jou rekening plaasvind."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Jy moet ten minste 18 jaar oud wees of die wettige meerderjarigheidsouderdom in jou jurisdiksie om die Stelsel te gebruik."),
        "backSide": MessageLookupByLibrary.simpleMessage("Agterkant"),
        "backToHome": MessageLookupByLibrary.simpleMessage("Terug na Huis"),
        "balance": MessageLookupByLibrary.simpleMessage("Balans"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladesj"),
        "bank": MessageLookupByLibrary.simpleMessage("Bank"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Bankrekening Geldeenheid"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Bankrekening Valuta"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Bankinligting"),
        "bankName": MessageLookupByLibrary.simpleMessage("Banknaam"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("Bankoorplasing"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Strepieskode gevind"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Rekening/Faktuur"),
        "billTo": MessageLookupByLibrary.simpleMessage("Rekening Aan"),
        "branchName": MessageLookupByLibrary.simpleMessage("Taknaam"),
        "brand": MessageLookupByLibrary.simpleMessage("Handelsmerk"),
        "brandName": MessageLookupByLibrary.simpleMessage("Handelsmerk Naam"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("Massa \nOplaai"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Besigheidskategorie"),
        "buy": MessageLookupByLibrary.simpleMessage("Koop"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Koop Premium Plan"),
        "buySms": MessageLookupByLibrary.simpleMessage("Koop Sms"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Deur toegang tot of gebruik van die Punt van Verkoop (POS) Stelsel (die \"Stelsel\") wat deur [Jou Maatskappy Naam] (\"Maatskappy\") verskaf word, stem jy in om gebonde te wees aan hierdie Gebruiksvoorwaardes. As jy nie met hierdie Gebruiksvoorwaardes saamstem nie, moet jy nie die Stelsel gebruik nie."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Jy is verantwoordelik vir die versekering dat jou toegang tot en gebruik van die Stelsel in ooreenstemming met alle toepaslike wette en regulasies is."),
        "cacel": MessageLookupByLibrary.simpleMessage("Kanselleer"),
        "call": MessageLookupByLibrary.simpleMessage("Bel"),
        "callForEmergencySupport":
            MessageLookupByLibrary.simpleMessage("Bel vir noodondersteuning"),
        "camera": MessageLookupByLibrary.simpleMessage("Kamera"),
        "cancel": MessageLookupByLibrary.simpleMessage("Kanselleer"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Kanselleer Alle Produkte"),
        "capacity": MessageLookupByLibrary.simpleMessage("Kapasiteit"),
        "card": MessageLookupByLibrary.simpleMessage("Kaart"),
        "cash": MessageLookupByLibrary.simpleMessage("Kontant"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Kontant Vry"),
        "categories": MessageLookupByLibrary.simpleMessage("Kategorieë"),
        "category": MessageLookupByLibrary.simpleMessage("Kategorie"),
        "categoryName": MessageLookupByLibrary.simpleMessage("Kategorie Naam"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "Kategorie Naam bestaan reeds"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("Kategorie Naam"),
        "change": MessageLookupByLibrary.simpleMessage("Verander?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Verander Wagwoord"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("Kyk E-pos"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Kies \'n Kliënt"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Kies \'n Verskaffer"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Kies jou kenmerke"),
        "clarence": MessageLookupByLibrary.simpleMessage("Klaring"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Klik om te verbind"),
        "close": MessageLookupByLibrary.simpleMessage("Sluit"),
        "color": MessageLookupByLibrary.simpleMessage("Kleur"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(Kombinasie van verskeie belastings)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Kom binnekort"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Maatskappy Adres"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Maatskappy & Winkellnaam"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("Maatskappy & Besigheidsnaam"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Voltooi Transaksie"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Bevestig Wagwoord"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Bevestig teruggawe"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Gelukwensing"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Kontak Ons"),
        "continu": MessageLookupByLibrary.simpleMessage("Gaan Voort"),
        "country": MessageLookupByLibrary.simpleMessage("Land"),
        "create": MessageLookupByLibrary.simpleMessage("Skep"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Skep \'n Gratis Rekening"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Geskep en gestoor"),
        "currency": MessageLookupByLibrary.simpleMessage("Geldeenheid"),
        "currentStock":
            MessageLookupByLibrary.simpleMessage("Huidige Voorraad"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("Aangepaste Faktuur Branding"),
        "customer": MessageLookupByLibrary.simpleMessage("Kliënt"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Kliëntbesonderhede"),
        "customerGST": MessageLookupByLibrary.simpleMessage("Kliënt BTW"),
        "customerName": MessageLookupByLibrary.simpleMessage("Kliënt Naam"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Daaglikse Transaksie"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Dashboard Oorsig"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Data suksesvol gestoor"),
        "date": MessageLookupByLibrary.simpleMessage("Datum"),
        "day": MessageLookupByLibrary.simpleMessage("Dag"),
        "dealer": MessageLookupByLibrary.simpleMessage("Handelaar"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("Handelaarsprys"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("Standaard BTW persentasie"),
        "delete": MessageLookupByLibrary.simpleMessage("Vee uit"),
        "deleting": MessageLookupByLibrary.simpleMessage("Verwyder"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Afleweringsadres"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Afleweringsadresse"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Afleweringsfooi"),
        "describtion": MessageLookupByLibrary.simpleMessage("Beskrywing"),
        "description": MessageLookupByLibrary.simpleMessage("Beskrywing"),
        "descriptionCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Beskrywing kan nie leeg wees nie"),
        "details": MessageLookupByLibrary.simpleMessage("Besonderhede"),
        "discount": MessageLookupByLibrary.simpleMessage("Afslag"),
        "doNotDistrub":
            MessageLookupByLibrary.simpleMessage("Moes Nie Gesteur Word Nie"),
        "done": MessageLookupByLibrary.simpleMessage("Klaar"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Laai Excel-formaat af"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Suksesvol afgelaai in aflaai-lêergids"),
        "due": MessageLookupByLibrary.simpleMessage("Verskuldig"),
        "dueAmount":
            MessageLookupByLibrary.simpleMessage("Verskuldigde Bedrag: "),
        "dueCollection":
            MessageLookupByLibrary.simpleMessage("Verskuldigheidsversameling"),
        "dueCollectionReports": MessageLookupByLibrary.simpleMessage(
            "Verslae oor Verskuldigde Inbetalings"),
        "dueList":
            MessageLookupByLibrary.simpleMessage("Lys van Verskuldigheid"),
        "dueReports":
            MessageLookupByLibrary.simpleMessage("Verslag van Verskuldig"),
        "duration": MessageLookupByLibrary.simpleMessage("Duur"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Duur: Van"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "Maklik om te gebruik mobiele pos"),
        "edit": MessageLookupByLibrary.simpleMessage("Wysig"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Wysig Aankoop Faktuur"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Wysig Verkope Faktuur"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Wysig Sosiale Media"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Wysig suksesvol"),
        "editTax": MessageLookupByLibrary.simpleMessage("Wysig Belasting"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Wysig Belastinggroep"),
        "editWarehouse": MessageLookupByLibrary.simpleMessage("Wysig Pakhuis"),
        "email": MessageLookupByLibrary.simpleMessage("E-pos"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("E-posadres"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("E-pos kan nie leeg wees nie"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "E-pos gestuur! Gaan jou Inboks na"),
        "endDate": MessageLookupByLibrary.simpleMessage("Eind Datum"),
        "enterAValidAmount": MessageLookupByLibrary.simpleMessage(
            "Voer asseblief \'n geldige bedrag in"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Voer \'n geldige afslag in"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Voer asseblief \'n geldige telefoonnommer in"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Voer \'n geldige prys in"),
        "enterAValidQuantity": MessageLookupByLibrary.simpleMessage(
            "Voer \'n geldige hoeveelheid in"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("Voer Adres In"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("Voer Bedrag In"),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Voer Handelsmerk Naam in"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Voer Kapasiteit in"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Voer Kategorie Naam in"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Voer Kleur in"),
        "enterCustomerGstNumber":
            MessageLookupByLibrary.simpleMessage("Voer kliënt BTW-nommer in"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Voer Handelaarsprys in"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Voer beskrywing in"),
        "enterDiscount": MessageLookupByLibrary.simpleMessage("Voer Afslag in"),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Voer Uitgawedatum in"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Voer Volledige Adres In"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Voer Faktuur Nommer in"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Voer Lae Voorraad Waarskuwing Hoeveelheid in"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Voer Vervaardiger in"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("Voer Boodskapinhoud in"),
        "enterMrpOrRetailerPirce":
            MessageLookupByLibrary.simpleMessage("Voer MRP/Handelaarprys in"),
        "enterName": MessageLookupByLibrary.simpleMessage("Voer Naam in"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Voer Nota in"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Voer Partynaam In"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Voer Telefoonnommer In"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Voer Produk Kode in of Skandeer"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Voer Produk Naam in"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Voer Aankoopprijs in"),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("Voer Verwysingsnommer in"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Voer Grootte in"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("Voer Voorraad in"),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Voer belastingkoers in"),
        "enterTransactionId": MessageLookupByLibrary.simpleMessage(
            "Voer Transaksie-identifikasienommer in"),
        "enterType": MessageLookupByLibrary.simpleMessage("Voer Tipe in"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("Voer gebruiker titel in"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Voer \'n geldige bedrag in"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Voer Pakhuis Naam in"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Voer Gewig in"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Voer Groothandelsprys in"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("Voer jou beskrywing hier in"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("Voer Jou E-posadres In"),
        "enterYourFeedBackTitle":
            MessageLookupByLibrary.simpleMessage("Voer Jou Terugvoer Titel in"),
        "enterYourGSTNumber": MessageLookupByLibrary.simpleMessage(
            "Voer asseblief u BTW Nommer in"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("Voer jou selfoonnommer in"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Voer Jou Naam In"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("Voer jou telefoonnommer in"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Voer jou wagwoord in"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Voer Jou Telefoonnommer In"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "Voer jou transaksie-identifikasie in"),
        "error": MessageLookupByLibrary.simpleMessage("Fout"),
        "excTax": MessageLookupByLibrary.simpleMessage("Eksl. Belasting"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("Excel Oplaai"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Eksklusief"),
        "expense": MessageLookupByLibrary.simpleMessage("Uitgawe"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Uitgawe Kategorie"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Uitgawedatum"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Uitgawe Vir"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Uitgawe Verslag"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Vervaldatum"),
        "expired": MessageLookupByLibrary.simpleMessage("Verstryk"),
        "expiring": MessageLookupByLibrary.simpleMessage("Verstryk"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Misluk met fout"),
        "fashion": MessageLookupByLibrary.simpleMessage("Mode"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Kenmerke is die belangrike deel wat Pos Saas van tradisionele oplossings onderskei."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Terugvoer"),
        "firstName": MessageLookupByLibrary.simpleMessage("Voornaam"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Volg ons op\\nFacebook"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Volg ons op\\nTwitter"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Voorkant"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("Vir onbeperkte gebruik"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Wagwoord vergeet"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Wagwoord vergeet?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Van Datum"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("Gratis Data Rugsteun"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "Gratis Lewenslange Opdatering"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Gratis Pakket"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Gratis Plan"),
        "from": MessageLookupByLibrary.simpleMessage("Van"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Volledig betaal"),
        "gallary": MessageLookupByLibrary.simpleMessage("Galery"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("PDF genereer"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Kry OTP"),
        "govermentId": MessageLookupByLibrary.simpleMessage("Regerings ID"),
        "guest": MessageLookupByLibrary.simpleMessage("Gas"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Het geen rekening nie?"),
        "history": MessageLookupByLibrary.simpleMessage("Geskiedenis"),
        "home": MessageLookupByLibrary.simpleMessage("Huis"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Hoe Ons Jou Inligting Beskerm"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Hoe Ons Jou Inligting Gebruik"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Identiteit Verifieer"),
        "image": MessageLookupByLibrary.simpleMessage("Afbeelding"),
        "inHouseCantBeDelete": MessageLookupByLibrary.simpleMessage(
            "Interne items kan nie verwyder word nie"),
        "inHouseCantBeEdited": MessageLookupByLibrary.simpleMessage(
            "Interne items kan nie gewysig word nie"),
        "inWord": MessageLookupByLibrary.simpleMessage("In woorde"),
        "incTax": MessageLookupByLibrary.simpleMessage("Inkl. belasting"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Ingesluit"),
        "increaseStock":
            MessageLookupByLibrary.simpleMessage("Verhoog Voorraad"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Instrument"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Faktureer Nr."),
        "invoice": MessageLookupByLibrary.simpleMessage("Faktuur"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("Faktuur Nommer"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Faktuur Instelling"),
        "invoiceViewer": MessageLookupByLibrary.simpleMessage("Faktuur Kyk"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Item Bygevoeg"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("KYC Verifikasie"),
        "language": MessageLookupByLibrary.simpleMessage("Taal"),
        "lastName": MessageLookupByLibrary.simpleMessage("Van"),
        "ledger": MessageLookupByLibrary.simpleMessage("Grootboek"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Lewenslange\nAankoop"),
        "link": MessageLookupByLibrary.simpleMessage("Skakel"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport": MessageLookupByLibrary.simpleMessage(
            "Regstreekse klets ondersteuning"),
        "loading": MessageLookupByLibrary.simpleMessage("Laai"),
        "logIn": MessageLookupByLibrary.simpleMessage("Teken In"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Teken Uit"),
        "logOut": MessageLookupByLibrary.simpleMessage("Teken uit"),
        "login": MessageLookupByLibrary.simpleMessage("Meld Aan"),
        "logo": MessageLookupByLibrary.simpleMessage("Logo"),
        "loss": MessageLookupByLibrary.simpleMessage("Verlies"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Verlies/Wins"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Verlies/Wins Besonderhede"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Verlies/Wins Verslag"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Verlies/Wins Verslae"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Lae Voorraad Waarskuwing"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Maak \'n blywende indruk op jou kliënte met gebrandmerkte faktuur. Ons Onbeperkte Opgradering bied die unieke voordeel van die aanpassing van jou faktuur, wat \'n professionele aanraking byvoeg wat jou handelsnaam versterk en kliëntetrots bevorder."),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("Bestuur jou besigheid met"),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Vervaardigingsdatum"),
        "margin": MessageLookupByLibrary.simpleMessage("Marge"),
        "masterCard": MessageLookupByLibrary.simpleMessage("Meesterkaart"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Vervaardiger"),
        "message": MessageLookupByLibrary.simpleMessage("Boodskap"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Boodskap Geskiedenis"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Pos Saas-app is gratis, maklik om te gebruik. In werklikheid is dit een van die beste POS-stelsels wêreldwyd."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas is \'n volledige besigheidsoplossing met voorraad, rekening, verkope, uitgawes en verlies/wins."),
        "mobile": MessageLookupByLibrary.simpleMessage("Mobiel"),
        "mobilePayment":
            MessageLookupByLibrary.simpleMessage("Mobiele Betaling"),
        "monthly": MessageLookupByLibrary.simpleMessage("Maandeliks"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("Meer Inligting"),
        "name": MessageLookupByLibrary.simpleMessage("Voer Jou Naam In"),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Naam bestaan reeds"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("Naam kan nie leeg wees nie"),
        "next": MessageLookupByLibrary.simpleMessage("Volgende"),
        "noConnection": MessageLookupByLibrary.simpleMessage("Geen Verbinding"),
        "noData": MessageLookupByLibrary.simpleMessage("Geen Data"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Geen data beskikbaar nie"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Geen data gevind nie"),
        "noHistoryFound": MessageLookupByLibrary.simpleMessage(
            "Geen Geskiedenis Gevind nie!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Geen produk gevind nie"),
        "noSubTaxSelected": MessageLookupByLibrary.simpleMessage(
            "Geen subbelasting gekies nie"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("Geen Transaksie Gevind nie!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Geen gebruiker gevind vir daardie e-pos nie."),
        "noUserRoleFound":
            MessageLookupByLibrary.simpleMessage("Geen Gebruikersrol Gevind"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Nie aktiewe gebruiker nie"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Nie verskaf nie"),
        "note": MessageLookupByLibrary.simpleMessage("Nota"),
        "notes": MessageLookupByLibrary.simpleMessage("Notas"),
        "notification": MessageLookupByLibrary.simpleMessage("Kennisgewing"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP gestuur na"),
        "office": MessageLookupByLibrary.simpleMessage("Kantoor"),
        "ok": MessageLookupByLibrary.simpleMessage("Ok"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS wat \'n groot hoeveelheid funksionaliteit bevat, insluitende verkoopsopvolging en voorraadbestuur."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Hierdie stelsel help jou om jou operasies vir jou klante te verbeter."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Ons POS-stelsel behoort daagliks operasies outomaties te vereenvoudig, dit maklik maak om te navigeer."),
        "openingBalance": MessageLookupByLibrary.simpleMessage("Beginbalans"),
        "order": MessageLookupByLibrary.simpleMessage("Bestellings"),
        "other": MessageLookupByLibrary.simpleMessage("Ander"),
        "otp": MessageLookupByLibrary.simpleMessage("Sluit"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Uit voorraad"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Pakket"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Pakket Kenmerke"),
        "paid": MessageLookupByLibrary.simpleMessage("Betaal"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Betaalde Bedrag"),
        "parties": MessageLookupByLibrary.simpleMessage("Partytjies"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Lys van Partye"),
        "partyGST": MessageLookupByLibrary.simpleMessage("Partytjie BTW"),
        "partyName": MessageLookupByLibrary.simpleMessage("Partynaam"),
        "password": MessageLookupByLibrary.simpleMessage("Wagwoord"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Wagwoord en bevestig wagwoord stem nie ooreen nie"),
        "passwordCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Wagwoord kan nie leeg wees nie"),
        "passwordNotMach": MessageLookupByLibrary.simpleMessage(
            "Wagwoord stem nie ooreen nie"),
        "payCash": MessageLookupByLibrary.simpleMessage("Betaal Kontant"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("Betaal met bkash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Betaal met Paypal"),
        "payeeName": MessageLookupByLibrary.simpleMessage("Begunstigde Naam"),
        "payeeNumber":
            MessageLookupByLibrary.simpleMessage("Begunstigde Nommer"),
        "payment": MessageLookupByLibrary.simpleMessage("Betaling"),
        "paymentAmount":
            MessageLookupByLibrary.simpleMessage("Betalingsbedrag"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Betaling Voltooi"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Betaalinstruksies:"),
        "paymentMethod":
            MessageLookupByLibrary.simpleMessage("Betalingsmetode"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Betalingsmetode"),
        "pdfView": MessageLookupByLibrary.simpleMessage("PDF-oorsig"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Persoonlike Inligting"),
        "phone": MessageLookupByLibrary.simpleMessage("Telefoon"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Telefoonnommer"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Telefoonnommer reeds gebruik"),
        "phoneNumberIsNotValid": MessageLookupByLibrary.simpleMessage(
            "Telefoonnommer is nie geldig nie"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("Telefoonnommer is nodig"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("Kies en Laai Lêer op"),
        "pickEndDate": MessageLookupByLibrary.simpleMessage("Kies Eind Datum"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Kies Begin Datum"),
        "plan": MessageLookupByLibrary.simpleMessage("Plan"),
        "pleaseAddQuantity": MessageLookupByLibrary.simpleMessage(
            "Voeg asseblief hoeveelheid by"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Kyk asseblief jou internetkonnektiwiteit na"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Koppel asseblief eers die drukker"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Koppel asseblief jou Bluetooth-drukker"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Voer asseblief \'n langer wagwoord in"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Voer asseblief \'n Bevestig Wagwoord in"),
        "pleaseEnterAPassword": MessageLookupByLibrary.simpleMessage(
            "Voer asseblief \'n wagwoord in"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Voer asseblief \'n geldige e-pos in"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Voer asseblief \'n naam in"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("Voer asseblief wagwoord in"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Voer asseblief jou e-posadres hieronder in om \'n skakel vir wagwoordherstel te ontvang."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Voer asseblief transaksienommer in"),
        "pleaseInterAmount": MessageLookupByLibrary.simpleMessage(
            "Voer asseblief \'n bedrag in"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Kies asseblief eers \'n kategorie"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("Kies asseblief \'n plan"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Kies asseblief besigheidskategorie"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Gebruik asseblief die geldige aankoopkode om die app te gebruik"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Aangedryf deur Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Aangedryf deur"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Premium Kliëntondersteuning"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Premium-plan"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Vorige Betaal Bedrae"),
        "price": MessageLookupByLibrary.simpleMessage("prys"),
        "print": MessageLookupByLibrary.simpleMessage("Druk"),
        "printingOption": MessageLookupByLibrary.simpleMessage("Drukkies"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Privaatheidsbeleid"),
        "product": MessageLookupByLibrary.simpleMessage("Produk"),
        "productCode": MessageLookupByLibrary.simpleMessage("Produk Kode"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("Produk kode is nodig"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Produk kode/Naam"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Produk Beskrywing"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Produk Besonderhede"),
        "productList": MessageLookupByLibrary.simpleMessage("Produklys"),
        "productName": MessageLookupByLibrary.simpleMessage("Produk Naam"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Produknaam bestaan reeds in hierdie pakhuis"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Produknaam is reeds bygevoeg"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("Produknaam is nodig"),
        "products": MessageLookupByLibrary.simpleMessage("Produkte"),
        "profile": MessageLookupByLibrary.simpleMessage("Profiel"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("Profiel Wysig"),
        "profit": MessageLookupByLibrary.simpleMessage("Wins"),
        "promo": MessageLookupByLibrary.simpleMessage("Promo"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Promo Kode"),
        "purchase": MessageLookupByLibrary.simpleMessage("Aankoop"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage("Aankoop Alarm"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Aankoop Bevestig"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Aankoop Besonderhede"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Aankoop Faktuur"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("Aankooplys"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Koop Nou"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Koop Premium Plan"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("Aankoopprijs"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("Aankoopprys is nodig"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("Aankoop Verslag"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Aankoop Verslag"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Aankooptydskrifte"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("Teruggawe van aankoop"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("Aankoop Teruggawe Verslag"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Koop-oorgang"),
        "qty": MessageLookupByLibrary.simpleMessage("Hoeveelheid"),
        "quantity": MessageLookupByLibrary.simpleMessage("Hoeveelheid"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Onlangse Transaksies"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("Het die PIN ontvang"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Verwysingsnommer"),
        "register": MessageLookupByLibrary.simpleMessage("Registreer"),
        "registering": MessageLookupByLibrary.simpleMessage("Registrasie"),
        "remainingDue":
            MessageLookupByLibrary.simpleMessage("Resterende Verskuldig"),
        "remove": MessageLookupByLibrary.simpleMessage("Verwyder"),
        "reports": MessageLookupByLibrary.simpleMessage("Verslae"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Versoek is gestuur"),
        "resendCode": MessageLookupByLibrary.simpleMessage("Stuur Kode Weer"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("Stuur OTP weer: "),
        "retailer": MessageLookupByLibrary.simpleMessage("Kleinhandelaar"),
        "retur": MessageLookupByLibrary.simpleMessage("Terugkeer"),
        "returN": MessageLookupByLibrary.simpleMessage("Teruggawe"),
        "returnAMount":
            MessageLookupByLibrary.simpleMessage("Terugkeer Bedrag"),
        "returnAmount":
            MessageLookupByLibrary.simpleMessage("Terugkeer Bedrag"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("Teruggawe AANT"),
        "revenue": MessageLookupByLibrary.simpleMessage("Inkomste"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Beveilig jou besigheidsdata moeiteloos. Ons Pos Saas POS Unlimited Upgrade sluit gratis datarugsteun in, wat verseker dat jou waardevolle inligting teen enige onvoorsiene gebeurtenisse beskerm word. Fokus op wat werklik saak maak – jou besigheidsgroei."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Verkoop bedrag"),
        "saleDetails":
            MessageLookupByLibrary.simpleMessage("Verkoop Besonderhede"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Verkoopprys"),
        "saleReports": MessageLookupByLibrary.simpleMessage("Verkoop Verslag"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Verkooptydskrifte"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("Verkoop Teruggawe"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Verkoop Teruggawe Verslag"),
        "saleSetting":
            MessageLookupByLibrary.simpleMessage("Verkoop Instelling"),
        "sales": MessageLookupByLibrary.simpleMessage("Verkope"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("Verkoop- en Aankoopverslae"),
        "salesList": MessageLookupByLibrary.simpleMessage("Verkope Lys"),
        "salesReturn":
            MessageLookupByLibrary.simpleMessage("Verkope Teruggawe"),
        "save": MessageLookupByLibrary.simpleMessage("Stoor"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Stoor en Publiseer"),
        "saveChanges":
            MessageLookupByLibrary.simpleMessage("Stoor Veranderinge"),
        "saving": MessageLookupByLibrary.simpleMessage("Stoor"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("Skandeer produk QR-kode"),
        "search": MessageLookupByLibrary.simpleMessage("Soek"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Soek volgens produk kode of naam"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("Sien alle promokodes"),
        "select": MessageLookupByLibrary.simpleMessage("Kies"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Kies \'n produk vir teruggawe"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Kies Handelsmerk"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Kies kategorie"),
        "selectContacts": MessageLookupByLibrary.simpleMessage("Kies Kontakte"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("Kies Produk Kategorie"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("Kies winkelkategorie"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Kies Belasting"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Kies Belastingtipe"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("Kies Eenheid"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Kies Variasie:"),
        "seller": MessageLookupByLibrary.simpleMessage("Verkoper"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Verkoop deur"),
        "send": MessageLookupByLibrary.simpleMessage("Stuur"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("Stuur E-pos"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Stuur Boodskap"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("Stuur Herstelskakel"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Stuur Sms"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Stuur sms?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Stuur WhatsApp-boodskap"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Stuur Jou E-pos"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage("Stuur E-pos"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Stuur boodskap"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Diens/Vervoer"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Stel Jou Profiel Op"),
        "setting": MessageLookupByLibrary.simpleMessage("Instelling"),
        "share": MessageLookupByLibrary.simpleMessage("Deel"),
        "shopGST": MessageLookupByLibrary.simpleMessage("Winkel BTW"),
        "signIn": MessageLookupByLibrary.simpleMessage("Meld Aan"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("Meld aan met e-pos"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Handtekening van Kliënt"),
        "size": MessageLookupByLibrary.simpleMessage("Grootte"),
        "skip": MessageLookupByLibrary.simpleMessage("Slaan oor"),
        "sms": MessageLookupByLibrary.simpleMessage("Sms"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Sosiale Bemarking"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Jammer, u het geen toestemming om hierdie diens te gebruik nie"),
        "startDate": MessageLookupByLibrary.simpleMessage("Begin Datum"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Begin Nuwe Verkope"),
        "startTypingToSearch":
            MessageLookupByLibrary.simpleMessage("Begin tik om te soek"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Bly aan die voorpunt van tegnologiese vordering sonder enige ekstra koste. Ons Slim Biashara POS Onbeperkte Opgradering verseker dat jy altyd die nuutste gereedskap en funksies tot jou beskikking het, en verseker dat jou besigheid altyd voorpunt bly."),
        "stillUnpaid":
            MessageLookupByLibrary.simpleMessage("Nog steeds onbetaal"),
        "stock": MessageLookupByLibrary.simpleMessage("Voorraad"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Voorraad is nodig"),
        "stockList": MessageLookupByLibrary.simpleMessage("Voorraadlys"),
        "stocks": MessageLookupByLibrary.simpleMessage("Voorraad"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Stoor toestemming is nodig om Excel-lêer te skep"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("Subbelasting Lys"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Sub belastings"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Subtotaal"),
        "submit": MessageLookupByLibrary.simpleMessage("Indien"),
        "subscribeToOurYoutube":
            MessageLookupByLibrary.simpleMessage("Teken in op ons\\nYoutube"),
        "subscription": MessageLookupByLibrary.simpleMessage("Intekening"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Suksesvol gedoen"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Suksesvol uitgeteken"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Suksesvol opgedateer"),
        "supplier": MessageLookupByLibrary.simpleMessage("Verskaffer"),
        "supplierName": MessageLookupByLibrary.simpleMessage("Verskaffer Naam"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT-kode"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Neem \'n bestuurslisensie, nasionale identiteitskaart of paspoortfoto"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "Neem \'n identiteitskaart om jou inligting te kontroleer"),
        "tap": MessageLookupByLibrary.simpleMessage("Tik"),
        "tax": MessageLookupByLibrary.simpleMessage("Belasting"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Belastinggroep"),
        "taxPercentage":
            MessageLookupByLibrary.simpleMessage("Belasting Persentasie"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Belastingkoers"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Belastingkoerse - Bestuur jou belastingkoerse"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Belastingverslag"),
        "taxType": MessageLookupByLibrary.simpleMessage("Belastingtipe"),
        "taxes": MessageLookupByLibrary.simpleMessage("Belastings"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Terme en Voorwaardes"),
        "termsOfUse":
            MessageLookupByLibrary.simpleMessage("Gebruiksvoorwaardes"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Bepalings & Privaatheid"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Dankie vir Jou Verskuldig Betaling"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Dankie"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Dankie vir Jou Aankoop"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "Die rekening bestaan reeds vir daardie e-pos"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Die Excel-lêer is reeds afgelaai"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Die naam sê alles. Met Slim Biashara POS Onbeperkte is daar geen beperking op jou gebruik nie. Of jy nou \'n handvol transaksies verwerk of \'n stroom van kliënte ervaar, kan jy met selfvertroue bedryf, wetende dat jy nie beperk word deur grense nie."),
        "thePasswordProvidedIsTooWeak":
            MessageLookupByLibrary.simpleMessage("Die wagwoord is te swak"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Die verkoop sal verwyder word en al die data oor hierdie aankoop sal verwyder word. Is jy seker jy wil dit uitvee"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Die verkoop sal uitgewis word en al die data oor hierdie verkoop sal uitgewis word. Is jy seker jy wil dit uitvee"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Die gebruiker sal verwyder word en alle data sal van jou rekening verwyder word. Is jy seker jy wil dit verwyder?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Die gebruiker en alle data sal verwyder word uit u rekening. Is u seker u wil dit uitvee"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Derde-Party Dienste"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Hierdie kategorie kan nie verwyder word nie"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("Hierdie maand"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Hierdie produk is reeds bygevoeg"),
        "title": MessageLookupByLibrary.simpleMessage("Titel"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Titel kan nie leeg wees nie"),
        "to": MessageLookupByLibrary.simpleMessage("Tot"),
        "toDate": MessageLookupByLibrary.simpleMessage("Tot Datum"),
        "today": MessageLookupByLibrary.simpleMessage("Vandag"),
        "total": MessageLookupByLibrary.simpleMessage("Totaal"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Totale Bedrag"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Totale versamelde"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Totaal Verskuldig"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("Totale Uitgawe"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Totale Verlies"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("Totaal Verskuldig"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Totale Prys"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("Totale Produkte"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Totale Wins"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("Totale aankoop"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Totale teruggawe bedrag"),
        "totalReturns":
            MessageLookupByLibrary.simpleMessage("Totale teruggawes"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Totale Verkoop"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Totale Voorraad"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Totale waarde"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Totale BTW"),
        "totals": MessageLookupByLibrary.simpleMessage("Totaal: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Transaksie"),
        "transactionId":
            MessageLookupByLibrary.simpleMessage("Transaksie-identifikasie"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Probeer Weer"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Tipe"),
        "unitName": MessageLookupByLibrary.simpleMessage("Eenheid Naam"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Eenheidsprijs"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Eenheidsprys"),
        "units": MessageLookupByLibrary.simpleMessage("Eenhede"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Onbeperk"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Onbeperkte Gebruik"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Ontsluit die volle potensiaal van Slim Biashara POS met persoonlike opleidingsessies deur ons kundige span. Van die basiese beginsels tot gevorderde tegnieke verseker ons dat jy goed bedrewe is om elke aspek van die stelsel te gebruik om jou besigheidsprosesse te optimaliseer."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Onbetaald"),
        "update": MessageLookupByLibrary.simpleMessage("Opdateer"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Besoeker Bywerk"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Werk Nou By"),
        "updateProduct": MessageLookupByLibrary.simpleMessage("Werk Produk By"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Werk eers u plan op,\\nu limiet is bereik"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Werk Jou Profiel By"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Dateer jou profiel op om jou dokter beter in kontak te bring"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Werk jou profiel by om jou kliënt beter te verbind"),
        "updated": MessageLookupByLibrary.simpleMessage("Opgedateer"),
        "upload": MessageLookupByLibrary.simpleMessage("Oplaai"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Laai Dokument op"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("Oplaai Klaar"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Laai Lêer op"),
        "upplier": MessageLookupByLibrary.simpleMessage("Verskaffer"),
        "usbC": MessageLookupByLibrary.simpleMessage("USB C"),
        "use": MessageLookupByLibrary.simpleMessage("Gebruik"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("Gebruik Pos Saas"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Gebruik van die Stelsel"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Gebruiker is uitgewis"),
        "userRole": MessageLookupByLibrary.simpleMessage("Gebruikersrol"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("Gebruikersrolbesonderhede"),
        "userTitle": MessageLookupByLibrary.simpleMessage("Gebruiker Titel"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Gebruikerstitel kan nie leeg wees nie"),
        "value": MessageLookupByLibrary.simpleMessage("Waarde"),
        "vatDoesNotApply": MessageLookupByLibrary.simpleMessage(
            "BTW is nie van toepassing nie"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("Verifieer OTP"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Verifieer Telefoonnommer"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Sien Alles"),
        "viewDetails":
            MessageLookupByLibrary.simpleMessage("Sien besonderhede"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Loop-in kliënt"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Pakhuis"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Pakhuis bestaan reeds"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("Pakhuislys"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("Pakhuis Naam"),
        "warranty": MessageLookupByLibrary.simpleMessage("Waarborg"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Ons het \'n E-pos gestuur met instruksies oor hoe om wagwoord te herstel na:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Ons mag derde-party dienste gebruik om ons program se funksionaliteit te ondersteun, soos analiseverskaffers en betalingsverwerkers. Hierdie derde-party dienste mag inligting oor jou versamel wanneer jy ons program gebruik. Let daarop dat ons nie verantwoordelik is vir die privaatheidpraktyke van hierdie derde-party dienste nie."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Ons neem bedryfsstandaard maatreëls om jou persoonlike inligting te beskerm, insluitende versleuteling en veilige stoor. Ons beperk ook die toegang tot jou inligting tot gemagtigde personeel alleenlik."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Ons verstaan die belangrikheid van naadlose werksaamhede. Dit is hoekom ons 24/7 ondersteuning beskikbaar is om jou te help, of dit nou \'n vinnige navraag of \'n omvattende kommer is. Maak enige tyd en enige plek met ons kontak via oproep of WhatsApp om \'n ongeëwenaarde kliëntediens te ervaar."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Ons gebruik jou persoonlike inligting om jou die beste moontlike ervaring op ons program te bied, insluitende die aanpassing van jou inhoudaanbevelings, om jou met kundiges te koppel, en om die funksionaliteit van ons programme te verbeter. Ons mag ook jou inligting gebruik om met jou te kommunikeer oor opdaterings, promosies, of ander inligting wat met ons program verband hou."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Ons sal die betaling hersien en dit binne 1-2 uur goedkeur"),
        "weekly": MessageLookupByLibrary.simpleMessage("Weekliks"),
        "weight": MessageLookupByLibrary.simpleMessage("Gewig"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Wat is Nuut"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Grosier"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Groothandelsprys"),
        "wholesalePrice":
            MessageLookupByLibrary.simpleMessage("Groothandelprys"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Groothandelaar"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Sal binnekort bygevoeg word"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Sal verval op"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Skryf jou boodskap hier"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("Verkeerde OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Verkeerde wagwoord vir daardie gebruiker voorsien."),
        "yearly": MessageLookupByLibrary.simpleMessage("Jaarliks"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Ja, Verwyder Vir Goed"),
        "youAreNotAValidUser": MessageLookupByLibrary.simpleMessage(
            "Jy is nie \'n geldige gebruiker nie"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Jy gebruik"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "U kan nie meer betaal as wat verskuldig is nie"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Jy het \'n E-pos ontvang"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Jy het suksesvol ingeteken op jou rekening. Bly saam met Pos Saas."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("Jy moet toestemming gee"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Jy moet HER-LOGIN op jou rekening."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Jy moet jou identiteit verifieer voordat jy koop"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Jou boodskap bly"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Jou Pakket"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Jou Pakket sal oor 5 Dae verval")
      };
}
