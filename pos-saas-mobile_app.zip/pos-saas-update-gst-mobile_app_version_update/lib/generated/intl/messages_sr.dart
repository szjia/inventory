// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a sr locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'sr';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Nastavi"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("GST broj"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("MRP je obavezan"),
        "OK": MessageLookupByLibrary.simpleMessage("U redu"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Tel. br."),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT kod"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Grickalice"),
        "TAX": MessageLookupByLibrary.simpleMessage("POREZ"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Učitavanje"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("Naziv korisnika"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Vaš paket će isteći danas\n\nMolimo vas da ponovo kupite"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) Sistem je namenjen isključivo za olakšavanje transakcija na mestu prodaje i povezanih aktivnosti u vašem poslovanju."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) Da biste koristili Sistem, možda ćete morati da napravite nalog. Saglasni ste da pružite tačne, aktuelne i kompletne informacije tokom procesa registracije i da ažurirate te informacije kako biste ih održali tačnim i potpunim."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("O aplikaciji"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("O nama"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Prihvatanje uslova"),
        "accountName": MessageLookupByLibrary.simpleMessage("Ime naloga"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("Broj naloga"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Registracija naloga"),
        "acton": MessageLookupByLibrary.simpleMessage("Akcija"),
        "add": MessageLookupByLibrary.simpleMessage("Dodaj"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Dodaj brend"),
        "addCategory": MessageLookupByLibrary.simpleMessage("Dodaj kategoriju"),
        "addContact": MessageLookupByLibrary.simpleMessage("Dodaj kontakt"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Dodaj kupca"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("Dodaj dostavu"),
        "addDescriptioN": MessageLookupByLibrary.simpleMessage("Dodaj opis"),
        "addDescription": MessageLookupByLibrary.simpleMessage("Dodaj belešku"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Dodaj popust"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Dodaj ID dokumenta"),
        "addDucument": MessageLookupByLibrary.simpleMessage("Dodaj dokument"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Dodaj trošak"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Dodaj kategoriju troška"),
        "addItems": MessageLookupByLibrary.simpleMessage("Dodaj stavke"),
        "addNew": MessageLookupByLibrary.simpleMessage("Dodaj novo"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Dodaj novu adresu"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Dodaj novi proizvod"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("Dodajte novi porez"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Dodajte novi porez sa jednim/višestrukim tipom poreza"),
        "addNote": MessageLookupByLibrary.simpleMessage("Dodaj belešku"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Prvo dodajte proizvod"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Dodaj promotivni kod"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Dodaj kupovinu"),
        "addSales": MessageLookupByLibrary.simpleMessage("Dodaj prodaju"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Dodavanje uspešno"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Dodaj jedinicu"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Dodaj korisničku ulogu"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Uspešno dodato"),
        "addedToCart": MessageLookupByLibrary.simpleMessage("Dodato u korpu"),
        "address": MessageLookupByLibrary.simpleMessage("Adresa"),
        "admin": MessageLookupByLibrary.simpleMessage("Administrator"),
        "all": MessageLookupByLibrary.simpleMessage("Sve"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("Sva poslovna rešenja"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("Već dodato"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Već postoji"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Već imate nalog?"),
        "amount": MessageLookupByLibrary.simpleMessage("Iznos"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "Email je poslat. Proverite svoju pristiglu poštu."),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Podrška za Android i iOS aplikacije"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Primjenjivi porez"),
        "apply": MessageLookupByLibrary.simpleMessage("Primeni"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Da li ste sigurni da želite da obrišete ovu fakturu?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Da li ste sigurni da želite da obrišete ovu prodaju?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Da li ste sigurni da želite da obrišete ovog korisnika?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Da li ste sigurni da želite da obrišete ovaj porez?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Da li ste sigurni da želite da obrišete ovu poresku grupu?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Da li želite da obrišete ovo skladište?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Da li ste sigurni da želite da obrišete ovog korisnika?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Ovlašćeni potpis"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Odgovorni ste za održavanje tajnosti svog naloga i lozinke i za ograničavanje pristupa svom nalogu. Prihvatate odgovornost za sve aktivnosti koje se dešavaju pod vašim nalogom."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Morate imati najmanje 18 godina ili punoletstvo u vašem pravnom okruženju da biste koristili Sistem."),
        "backSide": MessageLookupByLibrary.simpleMessage("Zadnja strana"),
        "backToHome": MessageLookupByLibrary.simpleMessage("Nazad na početnu"),
        "balance": MessageLookupByLibrary.simpleMessage("Balans"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladeš"),
        "bank": MessageLookupByLibrary.simpleMessage("Banka"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Valuta bankovnog računa"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Valuta bankovnog računa"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Informacije o banci"),
        "bankName": MessageLookupByLibrary.simpleMessage("Ime banke"),
        "bankTransfer":
            MessageLookupByLibrary.simpleMessage("Bankovni transfer"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Barcode pronađen"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Račun/Faktura"),
        "billTo": MessageLookupByLibrary.simpleMessage("Račun na"),
        "branchName": MessageLookupByLibrary.simpleMessage("Ime grane"),
        "brand": MessageLookupByLibrary.simpleMessage("Brend"),
        "brandName": MessageLookupByLibrary.simpleMessage("Ime brenda"),
        "bulkUpload":
            MessageLookupByLibrary.simpleMessage("Masovno \nUčitavanje"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Kategorija poslovanja"),
        "buy": MessageLookupByLibrary.simpleMessage("Kupi"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Kupi Premium plan"),
        "buySms": MessageLookupByLibrary.simpleMessage("Kupi SMS"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Pristupanjem ili korišćenjem Sistema za prodaju (Point of Sale - POS) („Sistem“) koji pruža [Ime Vaše Kompanije] („Kompanija“), saglasni ste da ste obavezani ovim Uslovima korišćenja. Ako se ne slažete sa ovim Uslovima korišćenja, nemojte koristiti Sistem."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Vi ste odgovorni za obezbeđivanje da vaš pristup i korišćenje Sistema budu u skladu sa svim primenljivim zakonima i propisima."),
        "cacel": MessageLookupByLibrary.simpleMessage("Otkaži"),
        "call": MessageLookupByLibrary.simpleMessage("Poziv"),
        "callForEmergencySupport":
            MessageLookupByLibrary.simpleMessage("Pozovite za hitnu podršku"),
        "camera": MessageLookupByLibrary.simpleMessage("Kamera"),
        "cancel": MessageLookupByLibrary.simpleMessage("Otkaži"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Otkaži sve proizvode"),
        "capacity": MessageLookupByLibrary.simpleMessage("Kapacitet"),
        "card": MessageLookupByLibrary.simpleMessage("Kartica"),
        "cash": MessageLookupByLibrary.simpleMessage("Gotovina"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Kategorije"),
        "category": MessageLookupByLibrary.simpleMessage("Kategorija"),
        "categoryName": MessageLookupByLibrary.simpleMessage("Ime kategorije"),
        "categoryNameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Ime kategorije već postoji"),
        "cateogryName":
            MessageLookupByLibrary.simpleMessage("Naziv kategorije"),
        "change": MessageLookupByLibrary.simpleMessage("Promeni"),
        "changePassword": MessageLookupByLibrary.simpleMessage("Promeni šifru"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("Proverite email"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Izaberite kupca"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Izaberite dobavljača"),
        "choseYourFeature": MessageLookupByLibrary.simpleMessage(
            "Izaberite svoje funkcionalnosti"),
        "clarence": MessageLookupByLibrary.simpleMessage("Klerens"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Kliknite da se povežete"),
        "close": MessageLookupByLibrary.simpleMessage("Zatvori"),
        "color": MessageLookupByLibrary.simpleMessage("Boja"),
        "combinationOfMultipleTaxes":
            MessageLookupByLibrary.simpleMessage("(Kombinacija više poreza)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Uskoro"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Adresa kompanije"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Ime kompanije i prodavnice"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("Ime kompanije i biznisa"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Završi transakciju"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Potvrdi šifru"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Potvrdite povrat"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Čestitamo"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Kontaktirajte nas"),
        "continu": MessageLookupByLibrary.simpleMessage("Nastavi"),
        "country": MessageLookupByLibrary.simpleMessage("Zemlja"),
        "create": MessageLookupByLibrary.simpleMessage("Kreiraj"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Napravite besplatan nalog"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Kreirano i sačuvano"),
        "currency": MessageLookupByLibrary.simpleMessage("Valuta"),
        "currentStock": MessageLookupByLibrary.simpleMessage("Trenutne zalihe"),
        "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
            "Prilagođeno brendiranje fakture"),
        "customer": MessageLookupByLibrary.simpleMessage("Kupac"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Detalji kupca"),
        "customerGST": MessageLookupByLibrary.simpleMessage("Kupčev GST"),
        "customerName": MessageLookupByLibrary.simpleMessage("Ime kupca"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Dnevna transakcija"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Pregled kontrolne table"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Podaci su uspešno sačuvani"),
        "date": MessageLookupByLibrary.simpleMessage("Datum"),
        "day": MessageLookupByLibrary.simpleMessage("Dan"),
        "dealer": MessageLookupByLibrary.simpleMessage("Trgovac"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("Cena za trgovca"),
        "defaultVATPercentage": MessageLookupByLibrary.simpleMessage(
            "Podrazumevajući procenat PDV-a"),
        "delete": MessageLookupByLibrary.simpleMessage("Obriši"),
        "deleting": MessageLookupByLibrary.simpleMessage("Brisanje"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Adresa dostave"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Adrese za isporuku"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Trošak dostave"),
        "describtion": MessageLookupByLibrary.simpleMessage("Opis"),
        "description": MessageLookupByLibrary.simpleMessage("Opis"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Opis ne može biti prazan"),
        "details": MessageLookupByLibrary.simpleMessage("Detalji"),
        "discount": MessageLookupByLibrary.simpleMessage("Popust"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Ne smetaj"),
        "done": MessageLookupByLibrary.simpleMessage("Završeno"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Preuzmite Excel format"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Uspešno preuzeto u preuzimanje folder"),
        "due": MessageLookupByLibrary.simpleMessage("Dug"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Iznos duga:"),
        "dueCollection": MessageLookupByLibrary.simpleMessage("Naplati dug"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("Izveštaji o naplati duga"),
        "dueList": MessageLookupByLibrary.simpleMessage("Lista dugova"),
        "dueReports": MessageLookupByLibrary.simpleMessage("Izveštaji o dugu"),
        "duration": MessageLookupByLibrary.simpleMessage("Trajanje"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Trajanje: Od"),
        "easyToUseMobilePos":
            MessageLookupByLibrary.simpleMessage("Lako se koristi mobilna POS"),
        "edit": MessageLookupByLibrary.simpleMessage("Uredi"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Uredi fakturu kupovine"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Uredi fakturu prodaje"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Uredi društvene medije"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Uspešno izmenjeno"),
        "editTax": MessageLookupByLibrary.simpleMessage("Izmeni porez"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Izmeni poresku grupu"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("Izmeni skladište"),
        "email": MessageLookupByLibrary.simpleMessage("Email"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("Email Adresa"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Email ne može biti prazan"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "Email poslat! Proverite svoj inbox"),
        "endDate": MessageLookupByLibrary.simpleMessage("Krajnji datum"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Unesite važeći iznos"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Unesite validan popust"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Unesite važeći broj telefona"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Unesite validnu cenu"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("Unesite validnu količinu"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("Unesite adresu"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("Unesite iznos."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Unesite ime brenda"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Unesite kapacitet"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Unesite ime kategorije"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Unesite boju"),
        "enterCustomerGstNumber":
            MessageLookupByLibrary.simpleMessage("Unesite GST broj kupca"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Unesite cenu za trgovca"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Unesite opis"),
        "enterDiscount": MessageLookupByLibrary.simpleMessage("Unesite popust"),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Unesite datum troška"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Unesite punu adresu"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Unesite broj fakture"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Unesite količinu upozorenja na nisku zalihe"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Unesite proizvođača"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("Unesite sadržaj poruke"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "Unesite MRP/cenu za maloprodaju"),
        "enterName": MessageLookupByLibrary.simpleMessage("Unesite ime"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Unesite belešku"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Unesite naziv strane"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Unesite broj telefona"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Unesite šifru proizvoda ili skenirajte"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Unesite ime proizvoda"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Unesite cenu kupovine"),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("Unesite referentni broj"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Unesite veličinu"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("Unesite zalihe"),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Unesite poresku stopu"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("Unesite ID transakcije"),
        "enterType": MessageLookupByLibrary.simpleMessage("Unesite tip"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("Unesite naziv korisnika"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Unesite važeći iznos"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Unesite ime skladišta"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Unesite težinu"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Unesite cenu veleprodaje"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("Unesite opis ovde"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("Unesite vašu email adresu"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "Unesite naslov povratne informacije"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Unesite svoj GST broj"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("Unesite vaš broj mobilnog"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Unesite vaše ime"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("Unesite vaš broj telefona"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Unesite svoju lozinku"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Unesite vaš broj telefona"),
        "enterYourTransactionId":
            MessageLookupByLibrary.simpleMessage("Unesite ID transakcije"),
        "error": MessageLookupByLibrary.simpleMessage("Greška"),
        "excTax": MessageLookupByLibrary.simpleMessage("Bez poreza"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("Excel Uploader"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Isključivo"),
        "expense": MessageLookupByLibrary.simpleMessage("Trošak"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Kategorija troška"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Datum troška"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Trošak za"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Izveštaj o troškovima"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Datum isteka"),
        "expired": MessageLookupByLibrary.simpleMessage("Isteklo"),
        "expiring": MessageLookupByLibrary.simpleMessage("Istek"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Neuspeh sa greškom"),
        "fashion": MessageLookupByLibrary.simpleMessage("Moda"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Funkcionalnosti su važan deo koji čini Pos Saas drugačijim od tradicionalnih rešenja."),
        "feedBack":
            MessageLookupByLibrary.simpleMessage("Povratna informacija"),
        "firstName": MessageLookupByLibrary.simpleMessage("Ime"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Pratite nas na\\nFacebooku"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Pratite nas na\\nTwitteru"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Prednja strana"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("Za neograničenu upotrebu"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Zaboravljena šifra"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Zaboravili ste šifru?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Od datuma"),
        "freeDataBackup": MessageLookupByLibrary.simpleMessage(
            "Besplatno bekapovanje podataka"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "Besplatno doživotno ažuriranje"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Besplatan paket"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Besplatan plan"),
        "from": MessageLookupByLibrary.simpleMessage("(Od"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Potpuno plaćeno"),
        "gallary": MessageLookupByLibrary.simpleMessage("Galerija"),
        "generatingPDF":
            MessageLookupByLibrary.simpleMessage("Generisanje PDF-a"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Dobijte OTP"),
        "guest": MessageLookupByLibrary.simpleMessage("Gost"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Nemate nalog?"),
        "history": MessageLookupByLibrary.simpleMessage("Istorija"),
        "home": MessageLookupByLibrary.simpleMessage("Početna"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Kako štitimo vaše informacije"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Kako koristimo vaše informacije"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Verifikacija identiteta"),
        "image": MessageLookupByLibrary.simpleMessage("Slika"),
        "inHouseCantBeDelete": MessageLookupByLibrary.simpleMessage(
            "Interni podaci ne mogu biti obrisani"),
        "inHouseCantBeEdited": MessageLookupByLibrary.simpleMessage(
            "Interni podaci ne mogu biti uređivani"),
        "inWord": MessageLookupByLibrary.simpleMessage("Rečima"),
        "incTax": MessageLookupByLibrary.simpleMessage("Sa porezom"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Uključivo"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("Povećaj zalihe"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Instrument"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Br. fakture"),
        "invoice": MessageLookupByLibrary.simpleMessage("Faktura"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("Broj fakture"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Podešavanja fakture"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Pregledač faktura"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Stavka dodata"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("KYC Verifikacija"),
        "language": MessageLookupByLibrary.simpleMessage("Jezik"),
        "lastName": MessageLookupByLibrary.simpleMessage("Prezime"),
        "ledger": MessageLookupByLibrary.simpleMessage("Knjiga"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Doživotna\nkupovina"),
        "link": MessageLookupByLibrary.simpleMessage("Link"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Podrška putem chata"),
        "loading": MessageLookupByLibrary.simpleMessage("Učitavanje"),
        "logIn": MessageLookupByLibrary.simpleMessage("Prijavite se"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Odjava"),
        "logOut": MessageLookupByLibrary.simpleMessage("Odjava"),
        "login": MessageLookupByLibrary.simpleMessage("Prijavi se"),
        "logo": MessageLookupByLibrary.simpleMessage("Logo"),
        "loss": MessageLookupByLibrary.simpleMessage("Gubitak"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Gubitak/Profit"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Detalji gubitka/profita"),
        "lossProfitReport": MessageLookupByLibrary.simpleMessage(
            "Izveštaj o gubicima/ dobicima"),
        "lossProfitReports": MessageLookupByLibrary.simpleMessage(
            "Izveštaji o gubicima/dobicima"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Upozorenje na nisku zalihe"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Napravite trajan utisak na svoje kupce sa brendiranim fakturama. Naše Unlimited Upgrade nudi jedinstvenu prednost prilagođavanja vaših faktura, dodajući profesionalan dodir koji jača identitet vaše marke i podstiče lojalnost kupaca."),
        "manageYourBussinessWith": MessageLookupByLibrary.simpleMessage(
            "Upravljajte vašim poslovanjem sa "),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Datum proizvodnje"),
        "margin": MessageLookupByLibrary.simpleMessage("Marža"),
        "masterCard": MessageLookupByLibrary.simpleMessage("MasterCard"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Proizvođač"),
        "message": MessageLookupByLibrary.simpleMessage("Poruka"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Istorija poruka"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Pos Saas aplikacija je besplatna i jednostavna za korišćenje. U stvari, to je jedan od najboljih POS sistema širom sveta."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas je kompletno poslovno rešenje sa zalihama, računima, prodajom, troškovima i gubitkom/profitom."),
        "mobile": MessageLookupByLibrary.simpleMessage("Mobilni"),
        "mobilePayment":
            MessageLookupByLibrary.simpleMessage("Mobilno plaćanje"),
        "monthly": MessageLookupByLibrary.simpleMessage("Mesečno"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("Više informacija"),
        "name": MessageLookupByLibrary.simpleMessage("Unesite vaše ime."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Ime već postoji"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("Ime ne može biti prazno"),
        "next": MessageLookupByLibrary.simpleMessage("Dalje"),
        "noConnection": MessageLookupByLibrary.simpleMessage("Nema veze"),
        "noData": MessageLookupByLibrary.simpleMessage("Nema podataka"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Nema dostupnih podataka"),
        "noDataFound": MessageLookupByLibrary.simpleMessage("Nema podataka"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("Nema pronađene istorije!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Nema pronađenih proizvoda"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("Nema odabranog podporeza"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("Nema pronađene transakcije!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Nije pronađen korisnik sa tom email adresom."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "Nije pronađena korisnička uloga"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Nije aktivan korisnik"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Nije pruženo"),
        "note": MessageLookupByLibrary.simpleMessage("Beleška"),
        "notes": MessageLookupByLibrary.simpleMessage("beleške"),
        "notification": MessageLookupByLibrary.simpleMessage("Obaveštenje"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP poslat na"),
        "office": MessageLookupByLibrary.simpleMessage("Kancelarija"),
        "ok": MessageLookupByLibrary.simpleMessage("U redu"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS koji sadrži obilje funkcionalnosti, uključujući praćenje prodaje i upravljanje zalihama."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Ovaj sistem vam pomaže da unapredite svoje operacije za svoje kupce."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Naš POS sistem treba da pojednostavi svakodnevne operacije automatski, čineći navigaciju lakom."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("Početno stanje"),
        "order": MessageLookupByLibrary.simpleMessage("Narudžbine"),
        "other": MessageLookupByLibrary.simpleMessage("Ostalo"),
        "otp": MessageLookupByLibrary.simpleMessage("Zatvori"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Nema na skladištu"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Paket"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Funkcionalnosti paketa"),
        "paid": MessageLookupByLibrary.simpleMessage("Plaćeno"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Plaćeni iznos"),
        "parties": MessageLookupByLibrary.simpleMessage("Strane"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Lista strana"),
        "partyGST": MessageLookupByLibrary.simpleMessage("GST stranke"),
        "partyName": MessageLookupByLibrary.simpleMessage("Naziv strane"),
        "password": MessageLookupByLibrary.simpleMessage("Šifra"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Lozinka i potvrda lozinke se ne poklapaju"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Lozinka ne može biti prazna"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("Lozinke se ne poklapaju"),
        "payCash": MessageLookupByLibrary.simpleMessage("Platite gotovinom"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("Platite putem bkash-a"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Platite putem Paypala"),
        "payeeName": MessageLookupByLibrary.simpleMessage("Ime primaoca"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("Broj primaoca"),
        "payment": MessageLookupByLibrary.simpleMessage("Plaćanje"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("Iznos plaćanja"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Plaćanje završeno"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Uputstva za plaćanje:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("Metod plaćanja"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Vrsta plaćanja"),
        "pdfView": MessageLookupByLibrary.simpleMessage("PDF prikaz"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Lične informacije"),
        "phone": MessageLookupByLibrary.simpleMessage("Telefon"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Broj telefona"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Broj telefona je već u upotrebi"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("Broj telefona nije važeći"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("Broj telefona je obavezan"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("Izaberite i učitajte fajl"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("Izaberite krajnji datum"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Izaberite početni datum"),
        "plan": MessageLookupByLibrary.simpleMessage("Plan"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("Molimo dodajte količinu"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Molimo proverite vašu internet konekciju"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Molimo prvo povežite štampač"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Molimo povežite vaš Bluetooth štampač"),
        "pleaseEnterABiggerPassword":
            MessageLookupByLibrary.simpleMessage("Molimo unesite dužu lozinku"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Molimo unesite potvrdu šifre"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("Molimo unesite šifru"),
        "pleaseEnterAValidEmail":
            MessageLookupByLibrary.simpleMessage("Molimo unesite važeći email"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Molimo unesite ime"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("Molimo unesite lozinku"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Molimo unesite vašu email adresu ispod da biste primili link za resetovanje šifre."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Molimo unesite broj transakcije"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("Molimo unesite iznos"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Molimo prvo izaberite kategoriju"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("Molimo izaberite plan"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Molimo izaberite poslovnu kategoriju"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Molimo koristite validni kod za kupovinu da biste koristili aplikaciju"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Pokreće Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Pogonjeno od"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Premium korisnička podrška"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Premium plan"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Prethodni iznos plaćanja"),
        "price": MessageLookupByLibrary.simpleMessage("Cena"),
        "print": MessageLookupByLibrary.simpleMessage("Štampaj"),
        "printingOption": MessageLookupByLibrary.simpleMessage("Opcije štampe"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Politika privatnosti"),
        "product": MessageLookupByLibrary.simpleMessage("Proizvod"),
        "productCode": MessageLookupByLibrary.simpleMessage("Šifra proizvoda"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("Kod proizvoda je obavezan"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Kod/ime proizvoda"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Opis proizvoda"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Detalji proizvoda"),
        "productList": MessageLookupByLibrary.simpleMessage("Lista proizvoda"),
        "productName": MessageLookupByLibrary.simpleMessage("Ime proizvoda"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Ime proizvoda već postoji u ovom skladištu"),
        "productNameIsAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("Ime proizvoda je već dodato"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("Ime proizvoda je obavezno"),
        "products": MessageLookupByLibrary.simpleMessage("Proizvodi"),
        "profile": MessageLookupByLibrary.simpleMessage("Profil"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("Uredi profil"),
        "profit": MessageLookupByLibrary.simpleMessage("Profit"),
        "promo": MessageLookupByLibrary.simpleMessage("Promo"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Promotivni kod"),
        "purchase": MessageLookupByLibrary.simpleMessage("Kupovina"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("Alarm za kupovinu"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Kupovina potvrđena"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Detalji kupovine"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Faktura za kupovinu"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("Lista kupovina"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Kupite sada"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Kupi Premium plan"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("Cena kupovine"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("Cena kupovine je obavezna"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("Izveštaj o kupovini"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Izveštaji o kupovini"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Izveštaji o kupovini"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("Povrat kupovine"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("Izveštaj o povratu kupovine"),
        "purchaseTransition": MessageLookupByLibrary.simpleMessage("Kupovina"),
        "qty": MessageLookupByLibrary.simpleMessage("Količina"),
        "quantity": MessageLookupByLibrary.simpleMessage("Količina"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Skorašnje transakcije"),
        "recivedThePin": MessageLookupByLibrary.simpleMessage("Primljen PIN"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Referentni broj"),
        "register": MessageLookupByLibrary.simpleMessage("Registruj se"),
        "registering": MessageLookupByLibrary.simpleMessage("Registracija"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("Preostali dug"),
        "remove": MessageLookupByLibrary.simpleMessage("Ukloni"),
        "reports": MessageLookupByLibrary.simpleMessage("Izveštaji"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Zahtev je poslat"),
        "resendCode":
            MessageLookupByLibrary.simpleMessage("Ponovo pošalji kod"),
        "resendOtp":
            MessageLookupByLibrary.simpleMessage("Ponovo pošalji OTP: "),
        "retailer": MessageLookupByLibrary.simpleMessage("Maloprodavac"),
        "retur": MessageLookupByLibrary.simpleMessage("Povrat"),
        "returN": MessageLookupByLibrary.simpleMessage("Povrat"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("Iznos povrata"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("Iznos povrata"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("Količina povrata"),
        "revenue": MessageLookupByLibrary.simpleMessage("Prihod"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Čuvajte podatke o svom poslovanju bez napora. Naše Pos Saas POS Unlimited Upgrade uključuje besplatno bekapovanje podataka, čime se osigurava zaštita vaših dragocenih informacija od neočekivanih događaja. Fokusirajte se na ono što zaista važi - rast vašeg posla."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Iznos prodaje"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("Detalji prodaje"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Cena prodaje"),
        "saleReports":
            MessageLookupByLibrary.simpleMessage("Izveštaji o prodaji"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Izveštaji o prodaji"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("Povrat prodaje"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Izveštaj o povratu prodaje"),
        "saleSetting":
            MessageLookupByLibrary.simpleMessage("Podešavanje prodaje"),
        "sales": MessageLookupByLibrary.simpleMessage("Prodaja"),
        "salesAndPurchaseReports": MessageLookupByLibrary.simpleMessage(
            "Izveštaji o prodaji i kupovini"),
        "salesList": MessageLookupByLibrary.simpleMessage("Lista prodaje"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("Povrat prodaje"),
        "save": MessageLookupByLibrary.simpleMessage("Sačuvaj"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Sačuvaj i objavi"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("Sačuvaj promene"),
        "saving": MessageLookupByLibrary.simpleMessage("Čuvanje"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("Skener QR kod proizvoda"),
        "search": MessageLookupByLibrary.simpleMessage("Pretraga"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Pretraži po kodu ili imenu proizvoda"),
        "seeAllPromoCode": MessageLookupByLibrary.simpleMessage(
            "Pogledaj sve promotivne kodove"),
        "select": MessageLookupByLibrary.simpleMessage("Izaberi"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Izaberite proizvod za povrat"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Izaberite brend"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Izaberite kategoriju"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Izaberite kontakte"),
        "selectProductCategory": MessageLookupByLibrary.simpleMessage(
            "Izaberite kategoriju proizvoda"),
        "selectShopCategory": MessageLookupByLibrary.simpleMessage(
            "Izaberite kategoriju prodavnice"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Izaberite porez"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Izaberite vrstu poreza"),
        "selectUnit":
            MessageLookupByLibrary.simpleMessage("Izaberite jedinicu"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Izaberite varijaciju: "),
        "seller": MessageLookupByLibrary.simpleMessage("Prodavac"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Prodaje"),
        "send": MessageLookupByLibrary.simpleMessage("Pošalji"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("Pošalji email"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Pošalji poruku"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("Pošalji link za resetovanje"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Pošalji SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Poslati SMS?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Pošaljite WhatsApp poruku"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Pošalji vašu email adresu"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage("Slanje email-a"),
        "sendingMessage": MessageLookupByLibrary.simpleMessage("Šaljem poruku"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Usluga/Transport"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Postavite vaš profil"),
        "setting": MessageLookupByLibrary.simpleMessage("Podešavanja"),
        "share": MessageLookupByLibrary.simpleMessage("Deljenje"),
        "shopGST": MessageLookupByLibrary.simpleMessage("GST prodavnice"),
        "signIn": MessageLookupByLibrary.simpleMessage("Prijavi se"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("Prijavite se sa email-om"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Potpis kupca"),
        "size": MessageLookupByLibrary.simpleMessage("Veličina"),
        "skip": MessageLookupByLibrary.simpleMessage("Preskoči"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Društveni marketing"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Žao nam je, nemate dozvolu da pristupite ovoj usluzi"),
        "startDate": MessageLookupByLibrary.simpleMessage("Početni datum"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Započni novu prodaju"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage(
            "Počnite da kucate za pretragu"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Ostanite u samom vrhu tehnoloških dostignuća bez dodatnih troškova. Naš Pos Saas POS Unlimited Upgrade osigurava da uvek imate najnovije alate i funkcije na dohvat ruke, garantujući da vaš posao ostaje u vrhu."),
        "stillUnpaid":
            MessageLookupByLibrary.simpleMessage("Još uvek neplaćeno"),
        "stock": MessageLookupByLibrary.simpleMessage("Zalihe"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Zaliha je obavezna"),
        "stockList": MessageLookupByLibrary.simpleMessage("Lista Zaliha"),
        "stocks": MessageLookupByLibrary.simpleMessage("Zalihe"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Dozvola za skladište je obavezna za kreiranje Excel fajla"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("Lista podporeza"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Podporezi"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Međuzbir"),
        "submit": MessageLookupByLibrary.simpleMessage("Potvrdi"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "Pretplatite se na naš\\nYoutube"),
        "subscription": MessageLookupByLibrary.simpleMessage("Pretplata"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Uspešno završeno"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Uspešno ste se odjavili"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Uspešno ažurirano"),
        "supplier": MessageLookupByLibrary.simpleMessage("Dobavljač"),
        "supplierName": MessageLookupByLibrary.simpleMessage("Ime dobavljača"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT Kod"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Uzmite vozačku dozvolu, ličnu kartu ili sliku pasoša"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "Uzmite ličnu kartu kako biste proverili vaše informacije"),
        "tap": MessageLookupByLibrary.simpleMessage("Dodirnite"),
        "tax": MessageLookupByLibrary.simpleMessage("Porez"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Poreska grupa"),
        "taxPercentage":
            MessageLookupByLibrary.simpleMessage("Procenat poreza"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Poreska stopa"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Poreske stope - Upravljač svojim poreskim stopama"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Izveštaj o porezu"),
        "taxType": MessageLookupByLibrary.simpleMessage("Vrsta poreza"),
        "taxes": MessageLookupByLibrary.simpleMessage("Porezi"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Uslovi i odredbe"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("Uslovi korišćenja"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Uslovi i privatnost"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Hvala vam na vašem plaćanju duga"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Hvala vam"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Hvala vam na kupovini"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "Račun već postoji za tu email adresu"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage("Excel fajl je već preuzet"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Sve je u imenu. Sa Pos Saas POS Unlimited, nema ograničenja za vašu upotrebu. Bez obzira da li obrađujete samo nekoliko transakcija ili imate navalu kupaca, možete raditi sa samopouzdanjem, znajući da niste ograničeni limitima."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "Unesena lozinka je previše slaba"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Prodaja će biti obrisana i svi podaci o ovoj kupovini će biti obrisani. Da li ste sigurni da želite da obrišete?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Prodaja će biti obrisana i svi podaci o ovoj prodaji će biti obrisani. Da li ste sigurni da želite da obrišete?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Korisnik će biti obrisan i svi podaci će biti izbrisani sa vašeg naloga. Da li ste sigurni da želite da obrišete?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Korisnik će biti obrisan i svi podaci će biti obrisani iz vašeg naloga. Da li ste sigurni da želite da obrišete ovo?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Usluge trećih strana"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Ova kategorija ne može biti obrisana"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Ovaj mesec)"),
        "thisProductAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("Ovaj proizvod je već dodat"),
        "title": MessageLookupByLibrary.simpleMessage("Naslov"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Naslov ne može biti prazan"),
        "to": MessageLookupByLibrary.simpleMessage("do"),
        "toDate": MessageLookupByLibrary.simpleMessage("Do datuma"),
        "today": MessageLookupByLibrary.simpleMessage("Danas"),
        "total": MessageLookupByLibrary.simpleMessage("Ukupno"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Ukupan iznos"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Ukupno prikupljeno"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Ukupni dug"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("Ukupni trošak"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Ukupni gubitak"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("Ukupno za plaćanje"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Ukupna cena"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("Ukupno proizvoda"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Ukupna dobit"),
        "totalPurchase":
            MessageLookupByLibrary.simpleMessage("Ukupna kupovina"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Ukupan iznos povrata"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("Ukupni povrati"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Ukupna prodaja"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Ukupne zalihe"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Ukupna vrednost"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Ukupni PDV"),
        "totals": MessageLookupByLibrary.simpleMessage("Ukupno: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Transakcija"),
        "transactionId": MessageLookupByLibrary.simpleMessage("ID transakcije"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Pokušajte ponovo"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Tip"),
        "unitName": MessageLookupByLibrary.simpleMessage("Ime jedinice"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Jedinična cena"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Jedinična cena"),
        "units": MessageLookupByLibrary.simpleMessage("Jedinice"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Neograničeno"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Neograničena upotreba"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Otključajte puni potencijal Pos Saas POS-a sa personalizovanim treninzima vođenim od strane našeg stručnog tima. Od osnovnih do naprednih tehnika, mi se pobrinemo da ste dobro upućeni u korišćenje svakog aspekta sistema radi optimizacije vaših poslovnih procesa."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Nepodmireno"),
        "update": MessageLookupByLibrary.simpleMessage("Ažuriraj"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Ažuriraj kontakt"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Ažuriraj sad"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("Ažuriraj proizvod"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Ažurirajte svoj plan prvo, vaša granica je istekla"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Ažurirajte svoj profil"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Ažurirajte vaš profil kako biste se bolje povezali sa vašim doktorom"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Ažurirajte svoj profil da biste se bolje povezali sa kupcima"),
        "updated": MessageLookupByLibrary.simpleMessage("Ažurirano"),
        "upload": MessageLookupByLibrary.simpleMessage("Učitajte"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Otpremi dokument"),
        "uploadDone":
            MessageLookupByLibrary.simpleMessage("Učitavanje završeno"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Otpremi datoteku"),
        "upplier": MessageLookupByLibrary.simpleMessage("Dobavljač"),
        "usbC": MessageLookupByLibrary.simpleMessage("USB C"),
        "use": MessageLookupByLibrary.simpleMessage("Koristite"),
        "useMobiPos":
            MessageLookupByLibrary.simpleMessage("Koristite Pos Saas"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Korišćenje sistema"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Korisnik je obrisan"),
        "userRole": MessageLookupByLibrary.simpleMessage("Korisnička uloga"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("Detalji korisničke uloge"),
        "userTitle": MessageLookupByLibrary.simpleMessage("Naziv korisnika"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Naziv korisnika ne može biti prazan"),
        "value": MessageLookupByLibrary.simpleMessage("Vrednost"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("PDV se ne primenjuje"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("Verifikacija OTP"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Verifikuj broj telefona"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Pogledaj sve"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("Pogledaj detalje"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Kupac na licu mesta"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Skladište"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Skladište već postoji"),
        "warehouseList":
            MessageLookupByLibrary.simpleMessage("Lista skladišta"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("Ime skladišta"),
        "warranty": MessageLookupByLibrary.simpleMessage("Garancija"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Poslali smo vam email sa uputstvima kako da resetujete šifru na:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Možemo koristiti usluge trećih strana kako bismo podržali funkcionalnost naše aplikacije, kao što su pružaoci analitike i procesori plaćanja. Ove usluge trećih strana mogu prikupljati informacije o vama prilikom korišćenja naše aplikacije. Imajte na umu da nismo odgovorni za prakse privatnosti ovih usluga trećih strana."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Preduzimamo mere u skladu sa standardima industrije kako bismo zaštitili vaše lične informacije, uključujući šifrovanje i sigurno skladištenje. Takođe ograničavamo pristup vašim informacijama samo ovlašćenom osoblju."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Mi razumemo važnost bezbrižnog poslovanja. Zato je naša podrška dostupna non-stop da vam pomogne, bilo da se radi o brzom upitu ili sveobuhvatnom problemu. Povežite se s nama bilo kad i bilo gde putem poziva ili WhatsApp-a kako biste doživeli neprevaziđenu korisničku podršku."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Koristimo vaše lične informacije kako bismo vam pružili najbolje moguće iskustvo na našoj aplikaciji, uključujući personalizaciju preporuka sadržaja, povezivanje sa stručnjacima i poboljšanje funkcionalnosti naših aplikacija. Takođe možemo koristiti vaše informacije kako bismo vas obaveštavali o ažuriranjima, promocijama ili drugim informacijama u vezi sa našom aplikacijom."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Pregledaćemo uplatu i odobriti je u roku od 1-2 sata"),
        "weekly": MessageLookupByLibrary.simpleMessage("Nedeljno"),
        "weight": MessageLookupByLibrary.simpleMessage("Težina"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Šta je novo"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Veletrgovac"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Cena veleprodaje"),
        "wholesalePrice":
            MessageLookupByLibrary.simpleMessage("Veleprodajna cena"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Veletrgovac"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Biće uskoro dodato"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Isteklo u"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Napišite vašu poruku ovde"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("Pogrešan OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Pogrešna šifra za tog korisnika."),
        "yearly": MessageLookupByLibrary.simpleMessage("Godišnje"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Da, trajno izbriši"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("Niste validan korisnik"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Koristite"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Ne možete platiti više od duga"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Dobili ste email"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Uspešno ste se prijavili na svoj nalog. Ostanite uz Pos Saas."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("Morate dati dozvolu"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Morate PONOVO SE PRIJAVITI na svoj nalog."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Morate verifikovati identitet pre nego što kupite SMS"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Vaša poruka ostaje"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Vaš paket"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Vaš paket će isteći za 5 dana")
      };
}
