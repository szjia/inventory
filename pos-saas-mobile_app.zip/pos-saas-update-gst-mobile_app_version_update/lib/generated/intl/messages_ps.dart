// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a ps locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'ps';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("دوام ورکړئ"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("GST نمبر"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("MRP"),
        "MRPIsRequired": MessageLookupByLibrary.simpleMessage("MRP اړتیا لري"),
        "OK": MessageLookupByLibrary.simpleMessage("ښه"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("پیپل"),
        "PhNo": MessageLookupByLibrary.simpleMessage("د ټیلفون شمېره"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT کوډ"),
        "Snacks": MessageLookupByLibrary.simpleMessage("خوراکونه"),
        "TAX": MessageLookupByLibrary.simpleMessage("مالیه"),
        "Uploading": MessageLookupByLibrary.simpleMessage("پورته کول"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("د کارونکي سرلیک"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "ستاسو بسته به نن پای ته ورسیږي\n\nمهرباني وکړئ بیا واخلي"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(الف) سیسټم یوازې د دې لپاره چمتو شوی\nچې د خرڅلاو د\nمعاملو او اړوندو فعالیتونو\nپه برخه کې مرسته وکړي."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(الف) د سیسټم د کارولو لپاره، تاسو ممکن اړتیا ولرئ چې یو حساب جوړ کړئ. تاسو موافق یاست چې د ثبت پروسې په جریان کې دقیق، اوسنی او بشپړ معلومات وړاندې کړئ او د دې معلوماتو دقت او بشپړتیا ساتلو لپاره یې تازه کړئ."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("د غوښتنلیک په اړه"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("زموږ په اړه"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("د شرایطو منل"),
        "accountName": MessageLookupByLibrary.simpleMessage("د حساب نوم"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("د حساب شمیره"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("د حساب ثبتول"),
        "acton": MessageLookupByLibrary.simpleMessage("عمل"),
        "add": MessageLookupByLibrary.simpleMessage("اضافه کړئ"),
        "addBrand": MessageLookupByLibrary.simpleMessage("نښه اضافه کړئ"),
        "addCategory": MessageLookupByLibrary.simpleMessage("کتګورۍ اضافه کړئ"),
        "addContact": MessageLookupByLibrary.simpleMessage("اړیکه اضافه کړئ"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("مشتري اضافه کړئ"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("تحویلي اضافه کړئ"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("تشریح اضافه کړئ"),
        "addDescription":
            MessageLookupByLibrary.simpleMessage("یادښت اضافه کړئ"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("کموالی اضافه کړئ"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("د سند ID اضافه کړئ"),
        "addDucument": MessageLookupByLibrary.simpleMessage("مدرک اضافه کړئ"),
        "addExpense": MessageLookupByLibrary.simpleMessage("خرڅ اضافه کړئ"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("د خرڅ کټګوري اضافه کړئ"),
        "addItems": MessageLookupByLibrary.simpleMessage("شيان اضافه کړئ"),
        "addNew": MessageLookupByLibrary.simpleMessage("نوې اضافه کړئ"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("نوې پته اضافه کړئ"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("نوې محصول اضافه کړئ"),
        "addNewTax":
            MessageLookupByLibrary.simpleMessage("نوی مالیه اضافه کړئ"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "د واحد/متعدد مالیه ډول سره نوې مالیه اضافه کړئ"),
        "addNote": MessageLookupByLibrary.simpleMessage("یادښت اضافه کړئ"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("لومړی محصول اضافه کړئ"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("پرومو کوډ اضافه کړئ"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("پیرود اضافه کړئ"),
        "addSales": MessageLookupByLibrary.simpleMessage("خرڅلاو اضافه کړئ"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("د اضافه کولو بریالیتوب"),
        "addUnit": MessageLookupByLibrary.simpleMessage("واحد اضافه کړئ"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("د کارونکي رول اضافه کړئ"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("په بریالیتوب سره اضافه شو"),
        "addedToCart": MessageLookupByLibrary.simpleMessage("سویچ ته اضافه شو"),
        "address": MessageLookupByLibrary.simpleMessage("پته"),
        "admin": MessageLookupByLibrary.simpleMessage("اداره"),
        "all": MessageLookupByLibrary.simpleMessage("ټول"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("ټول سوداګریز حلونه"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("دمخه اضافه شوی"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("لا دمخه شته"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("مخکې له دې چې حساب ولرئ"),
        "amount": MessageLookupByLibrary.simpleMessage("مقدار"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "یو ایمیل لیږل شوی دی\\nخپل انباکس چیک کړئ"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "د Android او iOS اپلیکیشن ملاتړ"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("پلي کیدونکې مالیه"),
        "apply": MessageLookupByLibrary.simpleMessage("لګول"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "ایا تاسو پدې فاکتور حذف کولو یقین لرئ؟"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "ایا تاسو پدې پلور حذف کولو یقین لرئ؟"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "آیا تاسو باوري یاست چې دا کاروونکی حذف کړئ؟"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "ایا تاسو ډاډه یاست چې دا مالیه حذف کړئ؟"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "ایا تاسو ډاډه یاست چې دا د مالیاتو ډله حذف کړئ؟"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "ایا تاسو غواړئ دا ګودام حذف کړئ؟"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "آیا تاسو د دې کارونکي د حذف کولو په اړه ډاډه یاست؟"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("اجازه لرونکی لاسلیک"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(ب) تاسو مسؤل یاست چې د خپل حساب او رمز راز ساتلو او د خپل حساب ته د لاسرسي محدودولو لپاره. تاسو د ټولو فعالیتونو لپاره چې د خپل حساب لاندې واقع کیږي مسؤل یاست."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(ب) تاسو باید لږ تر لږه ۱۸ کاله عمر ولرئ یا په خپل قانوني سیمه کې د اکثریت قانوني عمر ته ورسیږئ تر څو د سیسټم څخه کار واخلئ."),
        "backSide": MessageLookupByLibrary.simpleMessage("شاتنۍ لور"),
        "backToHome": MessageLookupByLibrary.simpleMessage("کور ته ستانه شئ"),
        "balance": MessageLookupByLibrary.simpleMessage("توازن"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("بنګله دیش"),
        "bank": MessageLookupByLibrary.simpleMessage("بانک"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("د بانک حساب پیسې"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("د بانک حساب پیسې"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("د بانک معلومات"),
        "bankName": MessageLookupByLibrary.simpleMessage("د بانک نوم"),
        "bankTransfer":
            MessageLookupByLibrary.simpleMessage("د بانک له لارې انتقال"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("بارکوډ موندل شوی"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("بیل / فاکتور"),
        "billTo": MessageLookupByLibrary.simpleMessage("بل ته"),
        "branchName": MessageLookupByLibrary.simpleMessage("د څانګې نوم"),
        "brand": MessageLookupByLibrary.simpleMessage("نښه"),
        "brandName": MessageLookupByLibrary.simpleMessage("د نښې نوم"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("کثافتي\nپورته کول"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("د سوداګرۍ کټګورۍ"),
        "buy": MessageLookupByLibrary.simpleMessage("پېرودل"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("پرمیوم پلان واخلئ"),
        "buySms": MessageLookupByLibrary.simpleMessage("SMS واخلئ"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "د [ستاسو د شرکت نوم] (\"شرکت\") لخوا چمتو شوي د خرڅلاو (POS) سیسټم ته د لاسرسي یا کارولو سره (\"سیسټم\"), تاسو موافق یاست چې د دې کارولو شرایطو سره مل وي. که تاسو د دې شرایطو سره موافق نه یاست، نو مهرباني وکړئ د سیسټم څخه استفاده مه کوئ."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(ج) تاسو مسؤل یاست چې د سیسټم ته لاسرسی او کارول مو د ټولو پلي قوانینو او مقرراتو سره سمون ولري."),
        "cacel": MessageLookupByLibrary.simpleMessage("لغو"),
        "call": MessageLookupByLibrary.simpleMessage("تلیفون"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "د بیړني ملاتړ لپاره زنګ ووهئ"),
        "camera": MessageLookupByLibrary.simpleMessage("کمره"),
        "cancel": MessageLookupByLibrary.simpleMessage("لغوه"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("ټول محصولات لغوه کړئ"),
        "capacity": MessageLookupByLibrary.simpleMessage("توانایی"),
        "card": MessageLookupByLibrary.simpleMessage("کارت"),
        "cash": MessageLookupByLibrary.simpleMessage("نقد"),
        "cashFree": MessageLookupByLibrary.simpleMessage("نقده وړیا"),
        "categories": MessageLookupByLibrary.simpleMessage("کتګورۍ"),
        "category": MessageLookupByLibrary.simpleMessage("کتګوري"),
        "categoryName": MessageLookupByLibrary.simpleMessage("د کټګورۍ نوم"),
        "categoryNameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("د کټګورۍ نوم لا دمخه شته"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("د کټګورۍ نوم"),
        "change": MessageLookupByLibrary.simpleMessage("تبدیل؟"),
        "changePassword": MessageLookupByLibrary.simpleMessage("پټنوم بدل کړئ"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("بریښنالیک وګورئ"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("یو مشتری وټاکئ"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("یو عرضه کوونکی غوره کړئ"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("خپلي ځانګړتیاوې وټاکئ"),
        "clarence": MessageLookupByLibrary.simpleMessage("تخفیف"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("د وصل کولو لپاره کلیک وکړئ"),
        "close": MessageLookupByLibrary.simpleMessage("بندول"),
        "color": MessageLookupByLibrary.simpleMessage("رنګ"),
        "combinationOfMultipleTaxes":
            MessageLookupByLibrary.simpleMessage("(د څو مالیاتو ترکیب)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("ژر به راشي"),
        "companyAddress": MessageLookupByLibrary.simpleMessage("د شرکت پته"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("د شرکت او دوکان نوم"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("د شرکت او سوداګرۍ نوم"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("معامله بشپړه کړئ"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("پاسورډ تایید کړئ"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("د راستنېدنې تصدیق"),
        "congratulations": MessageLookupByLibrary.simpleMessage("مبارک وي"),
        "contactUs":
            MessageLookupByLibrary.simpleMessage("موږ سره اړیکه ونیسئ"),
        "continu": MessageLookupByLibrary.simpleMessage("ادامه"),
        "country": MessageLookupByLibrary.simpleMessage("هیواد"),
        "create": MessageLookupByLibrary.simpleMessage("جوړول"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("د وړیا حساب جوړول"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("جوړ شوی او زیرمه شوی"),
        "currency": MessageLookupByLibrary.simpleMessage("پیسې"),
        "currentStock": MessageLookupByLibrary.simpleMessage("اوسنی سټاک"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("د برانډ انوائس تخصیص"),
        "customer": MessageLookupByLibrary.simpleMessage("مشتری"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("د پیرودونکي تفصیلات"),
        "customerGST": MessageLookupByLibrary.simpleMessage("د پیرودونکي GST"),
        "customerName": MessageLookupByLibrary.simpleMessage("د پیرودونکي نوم"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("ورزنی معاملې"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("د ډشبورډ عمومي کتنه"),
        "dataSavedSuccessfully": MessageLookupByLibrary.simpleMessage(
            "ډاډمن معلومات په بریالیتوب سره خوندي شوي"),
        "date": MessageLookupByLibrary.simpleMessage("نیټه"),
        "day": MessageLookupByLibrary.simpleMessage("ورځ"),
        "dealer": MessageLookupByLibrary.simpleMessage("مشتري"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("د فروش قیمت"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("د VAT لومړنی سلنه"),
        "delete": MessageLookupByLibrary.simpleMessage("حذف"),
        "deleting": MessageLookupByLibrary.simpleMessage("لیرې کول"),
        "deliveryAddress": MessageLookupByLibrary.simpleMessage("د تحویلۍ پته"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("د تحویلي پته"),
        "deliveryCharge": MessageLookupByLibrary.simpleMessage("د تحویلۍ فیس"),
        "describtion": MessageLookupByLibrary.simpleMessage("تفصیل"),
        "description": MessageLookupByLibrary.simpleMessage("تفصیل"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("تفصیل نشي خالي کېدی"),
        "details": MessageLookupByLibrary.simpleMessage("تفصیلات"),
        "discount": MessageLookupByLibrary.simpleMessage("تخفیف"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("مداخله مه کوئ"),
        "done": MessageLookupByLibrary.simpleMessage("بشپړ شو"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("د ایکسل بڼه ډاونلوډ کړئ"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "په ډاونلوډ فولډر کې په بریالیتوب سره ډاونلوډ شو"),
        "due": MessageLookupByLibrary.simpleMessage("باقي"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("باقي مقدار: "),
        "dueCollection": MessageLookupByLibrary.simpleMessage("باقي راټولول"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("د ورکړې راټولولو راپورونه"),
        "dueList": MessageLookupByLibrary.simpleMessage("باقي لیست"),
        "dueReports": MessageLookupByLibrary.simpleMessage("د پور راپور"),
        "duration": MessageLookupByLibrary.simpleMessage("مدت"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("مدت: له"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "د کارولو لپاره اسانه موبایل POS"),
        "edit": MessageLookupByLibrary.simpleMessage("ترمیم"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("د پېرودلو رسید سمول"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("د خرڅلاو رسید سمول"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("اجتماعي رسنیو ترمیم"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("په بریالیتوب سره سمول"),
        "editTax": MessageLookupByLibrary.simpleMessage("مالیه سمول"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("د مالیاتو ډله سمول"),
        "editWarehouse": MessageLookupByLibrary.simpleMessage("د ګودام سمول"),
        "email": MessageLookupByLibrary.simpleMessage("بریښنالیک"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("بریښنالیک آدرس"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("برېښنالیک نشي خالي کیدلی"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "برېښنالیک لیږل شوی! خپل انباکس چیک کړئ"),
        "endDate": MessageLookupByLibrary.simpleMessage("د پای نېټه"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("معتبر مقدار ولیکئ"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("یو معتبر تخفیف داخل کړئ"),
        "enterAValidPhoneNumber":
            MessageLookupByLibrary.simpleMessage("یو معتبر تلیفون شمېره ولیکئ"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("یو معتبر قیمت داخل کړئ"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("یو معتبر مقدار داخل کړئ"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("پته داخل کړئ"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("مقدار داخل کړئ."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("د نښې نوم داخل کړئ"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("توانایی داخل کړئ"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("د کتګورۍ نوم داخل کړئ"),
        "enterColor": MessageLookupByLibrary.simpleMessage("رنګ داخل کړئ"),
        "enterCustomerGstNumber":
            MessageLookupByLibrary.simpleMessage("د پیرودونکي GST نمبر ولیکئ"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("د فروش قیمت داخل کړئ"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("تفصیل داخل کړئ"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("تخفیف داخل کړئ."),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("د خرڅ نیټه داخل کړئ"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("مکمل پته داخل کړئ"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("د رسید شمېره ولیکئ"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "د ټیټې زیرمې خبرتیا مقدار داخل کړئ"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("تولیدونکی داخل کړئ"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("د پیغام محتوا ولیکئ"),
        "enterMrpOrRetailerPirce":
            MessageLookupByLibrary.simpleMessage("MRP/پرچون قیمت داخل کړئ"),
        "enterName": MessageLookupByLibrary.simpleMessage("نوم داخل کړئ"),
        "enterNote": MessageLookupByLibrary.simpleMessage("یادښت داخل کړئ"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("د طرف نوم داخل کړئ"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("د تلیفون شمیره داخل کړئ"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "د محصول کوډ داخل کړئ یا سکن کړئ"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("د محصول نوم داخل کړئ"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("د پیرود قیمت داخل کړئ."),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("د حوالې شمیره داخل کړئ"),
        "enterSize": MessageLookupByLibrary.simpleMessage("حجم داخل کړئ"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("زېرمه داخل کړئ."),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("د مالیې کچه داخل کړئ"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("د معامله ID ولیکئ"),
        "enterType": MessageLookupByLibrary.simpleMessage("ډول داخل کړئ"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("د کارونکي سرلیک داخل کړئ"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("معتبر مقدار ولیکئ"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("د ګودام نوم داخل کړئ"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("وزن داخل کړئ"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("تخفیفي قیمت داخل کړئ"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("دلته خپل تفصیل ولیکئ"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("خپل بریښنالیک آدرس ولیکئ"),
        "enterYourFeedBackTitle":
            MessageLookupByLibrary.simpleMessage("د خپل بازخورد سرلیک ولیکئ"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("خپل GST نمبر ولیکئ"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("خپل ګرځنده شمېره ولیکئ"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("خپل نوم داخل کړئ"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("خپل تلیفون شمیره ولیکئ"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("خپل رمز داخل کړئ"),
        "enterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "خپله د تلیفون شمیره داخل کړئ"),
        "enterYourTransactionId":
            MessageLookupByLibrary.simpleMessage("خپل معاملې ID ولیکئ"),
        "error": MessageLookupByLibrary.simpleMessage("غلطی"),
        "excTax": MessageLookupByLibrary.simpleMessage("بیرته مالیه"),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("ایکسلس پورته کوونکی"),
        "exclusive": MessageLookupByLibrary.simpleMessage("بیرته"),
        "expense": MessageLookupByLibrary.simpleMessage("لګښت"),
        "expenseCategory": MessageLookupByLibrary.simpleMessage("د خرڅ کټګوري"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("د خرڅ نیټه"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("د خرڅ لپاره"),
        "expenseReport": MessageLookupByLibrary.simpleMessage("د خرڅ راپور"),
        "expireDate": MessageLookupByLibrary.simpleMessage("د ختمیدو نیټه"),
        "expired": MessageLookupByLibrary.simpleMessage("ختم شوی"),
        "expiring": MessageLookupByLibrary.simpleMessage("ختمیدونکی"),
        "facebok": MessageLookupByLibrary.simpleMessage("فیسبوک"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("د خطا سره ناکام شو"),
        "fashion": MessageLookupByLibrary.simpleMessage("فیشن"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "ځانګړتیاوې مهمې برخې دي چې POS SaaS د دودیزو حلونو څخه جلا کوي."),
        "feedBack": MessageLookupByLibrary.simpleMessage("بازخورد"),
        "firstName": MessageLookupByLibrary.simpleMessage("لومړی نوم"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("موږ په فیس بک کې تعقیب کړئ"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("موږ په ټویټر کې تعقیب کړئ"),
        "fontSide": MessageLookupByLibrary.simpleMessage("د لیکنې لور"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("د محدودو کارونې لپاره"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("پټ نوم هیر شوی"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("پټ نوم هیر کړی؟"),
        "formDate": MessageLookupByLibrary.simpleMessage("د نیټې څخه"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("وړیا معلوماتو بیک اپ"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "د عمر لپاره وړیا تازه معلومات"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("وړیا بسته"),
        "freePlan": MessageLookupByLibrary.simpleMessage("وړیا پلان"),
        "from": MessageLookupByLibrary.simpleMessage("(له"),
        "fullyPaid":
            MessageLookupByLibrary.simpleMessage("په بشپړ ډول تادیه شوی"),
        "gallary": MessageLookupByLibrary.simpleMessage("ګیلري"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("PDF تولید کول"),
        "getOtp": MessageLookupByLibrary.simpleMessage("OTP ترلاسه کړئ"),
        "govermentId": MessageLookupByLibrary.simpleMessage("د حکومت ID"),
        "guest": MessageLookupByLibrary.simpleMessage("میلمه"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("هیڅ حساب نلرئ؟"),
        "history": MessageLookupByLibrary.simpleMessage("تاریخ"),
        "home": MessageLookupByLibrary.simpleMessage("کور"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "موږ ستاسو معلومات څنګه خوندي کوو"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "موږ ستاسو معلومات څنګه کاروو"),
        "identityVerify": MessageLookupByLibrary.simpleMessage("هویت تصدیق"),
        "image": MessageLookupByLibrary.simpleMessage("انځور"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("په کور کې نشي حذف کیدلی"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("په کور کې نشي سمول"),
        "inWord": MessageLookupByLibrary.simpleMessage("په کلمو کې"),
        "incTax": MessageLookupByLibrary.simpleMessage("شامل مالیه"),
        "inclusive": MessageLookupByLibrary.simpleMessage("شامل"),
        "increaseStock":
            MessageLookupByLibrary.simpleMessage("ذخیره زیاته کړئ"),
        "inistrument": MessageLookupByLibrary.simpleMessage("آله"),
        "instragram": MessageLookupByLibrary.simpleMessage("انسټاګرام"),
        "invNo": MessageLookupByLibrary.simpleMessage("د بل نمبر."),
        "invoice": MessageLookupByLibrary.simpleMessage("فاکتور"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("د رسید شمېره"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("د رسید تنظیمات"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("د فاکتور نندارې"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("شي اضافه شو"),
        "kg": MessageLookupByLibrary.simpleMessage("کیلو"),
        "kycVerification": MessageLookupByLibrary.simpleMessage("KYC تصدیق"),
        "language": MessageLookupByLibrary.simpleMessage("ژبه"),
        "lastName": MessageLookupByLibrary.simpleMessage("آخر نوم"),
        "ledger": MessageLookupByLibrary.simpleMessage("کتاب"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("د ژوندنۍ\nپېرود"),
        "link": MessageLookupByLibrary.simpleMessage("لینک"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("لینکډین"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("مستقیم چت ملاتړ"),
        "loading": MessageLookupByLibrary.simpleMessage("چالان دی"),
        "logIn": MessageLookupByLibrary.simpleMessage("ننوتل"),
        "logOUt": MessageLookupByLibrary.simpleMessage("له حسابه وتل"),
        "logOut": MessageLookupByLibrary.simpleMessage("ووتل"),
        "login": MessageLookupByLibrary.simpleMessage("وړاندې کېدل"),
        "logo": MessageLookupByLibrary.simpleMessage("لوګو"),
        "loss": MessageLookupByLibrary.simpleMessage("زیان"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("زیان/ګټه"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("د زیان/ګټې تفصیلات"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("د زیان / ګټې راپور"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("د زیان / ګټې راپورونه"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("د ټیټې زیرمې خبرتیا"),
        "maan": MessageLookupByLibrary.simpleMessage("مان"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "پر خپلو مشتریانو باندې د برانډ انوائسونو سره د تل پاتې تاثیر په جوړولو. زموږ د بې حده تازه کولو سره د انوائسونو شخصي کولو ځانګړې ګټه وړاندې کوي، چې مسلکي خوی لري چې ستاسو د برانډ پیژندنې تقویه کوي او د مشتری وفاداري ته وده ورکوي."),
        "manageYourBussinessWith": MessageLookupByLibrary.simpleMessage(
            "خپله سوداګري د سره اداره کړئ "),
        "manufactureDate": MessageLookupByLibrary.simpleMessage("د تولید نیټه"),
        "margin": MessageLookupByLibrary.simpleMessage("مارجن"),
        "masterCard": MessageLookupByLibrary.simpleMessage("ماسټر کارډ"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("تولیدونکی"),
        "message": MessageLookupByLibrary.simpleMessage("پیغام"),
        "messageHistory": MessageLookupByLibrary.simpleMessage("د پیغام تاریخ"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "POS SaaS اپلیکیشن وړیا، د کارولو لپاره اسانه دی. په حقیقت کې، دا د نړۍ په کچه تر ټولو غوره POS سیسټمونو څخه دی."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "POS SaaS د بشپړ سوداګریز حل دی چې د سټاک، حساب، خرڅلاو، لګښت او ګټه/زیان سره."),
        "mobile": MessageLookupByLibrary.simpleMessage("موبایل"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("موبایل تادیه"),
        "monthly": MessageLookupByLibrary.simpleMessage("میاشتنی"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("نوره معلومات"),
        "name": MessageLookupByLibrary.simpleMessage("خپل نوم داخل کړئ."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("نوم لا دمخه شته"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("نوم نشي خالي کیدلی"),
        "next": MessageLookupByLibrary.simpleMessage("راتلونکی"),
        "noConnection": MessageLookupByLibrary.simpleMessage("هیڅ اړیکه نشته"),
        "noData": MessageLookupByLibrary.simpleMessage("هیڅ معلومات نه شته"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("هیڅ معلومات شتون نلري"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("هیڅ معلومات ونه موندل شول"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("هیڅ تاریخ نه دی موندل شوی!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("هیڅ محصول ونه موندل شو"),
        "noSubTaxSelected": MessageLookupByLibrary.simpleMessage(
            "هیڅ فرعي مالیه نه ده انتخاب شوې"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("هیڅ معامله نه ده موندل شوې!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "د دې بریښنالیک لپاره کوم کارونکی نه دی موندل شوی."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "هیڅ د کارونکي رول ونه موندل شو"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("غیر فعاله کارونکی"),
        "notProvided": MessageLookupByLibrary.simpleMessage("نه وړاندې شوی"),
        "note": MessageLookupByLibrary.simpleMessage("یادښت"),
        "notes": MessageLookupByLibrary.simpleMessage("یادداشتونه"),
        "notification": MessageLookupByLibrary.simpleMessage("خبرتیا"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP لیږل شوی"),
        "office": MessageLookupByLibrary.simpleMessage("دفتر"),
        "ok": MessageLookupByLibrary.simpleMessage("سم دی"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS چې د پلور تعقیب، د موجوداتو مدیریت په ګډون د پراخ فعالیتونو یوه لویه مجموعه لري."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "دا سیسټم تاسو سره مرسته کوي چې د خپلو مشتریانو لپاره خپل عملیات ښه کړئ."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "زموږ POS سیسټم باید ورځني عملیات په اتوماتيکه توګه ساده کړي، چې د لټون لپاره اسانه وي."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("د پرانستلو بیلانس"),
        "order": MessageLookupByLibrary.simpleMessage("حکمونه"),
        "other": MessageLookupByLibrary.simpleMessage("نور"),
        "otp": MessageLookupByLibrary.simpleMessage("بند"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("زیرمه ختمه ده"),
        "pacakge": MessageLookupByLibrary.simpleMessage("پیکج"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("د بسته ځانګړتیاوې"),
        "paid": MessageLookupByLibrary.simpleMessage("ادا شوی"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("تادیه شوې مقدار"),
        "parties": MessageLookupByLibrary.simpleMessage("ګوندونه"),
        "partiesList": MessageLookupByLibrary.simpleMessage("د طرفونو لیست"),
        "partyGST": MessageLookupByLibrary.simpleMessage("د خوا GST"),
        "partyName": MessageLookupByLibrary.simpleMessage("د طرف نوم"),
        "password": MessageLookupByLibrary.simpleMessage("پټ نوم"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "پاسورډ او د تصدیق پاسورډ سره برابري نه لري"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("پټنوم نشي خالي کیدلی"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("پټنوم برابر نه دی"),
        "payCash": MessageLookupByLibrary.simpleMessage("نقد ورکړه"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("د bkash سره تادیه وکړئ"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("د پی پال سره تادیه وکړئ"),
        "payeeName":
            MessageLookupByLibrary.simpleMessage("د تادیې اخیستونکي نوم"),
        "payeeNumber":
            MessageLookupByLibrary.simpleMessage("د تادیې اخیستونکي شمېر"),
        "payment": MessageLookupByLibrary.simpleMessage("تادیه"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("د تادیې مقدار"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("د پیسو پروسه بشپړه"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("د تادیې لارښوونې:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("د تادیې طریقه"),
        "paymentType": MessageLookupByLibrary.simpleMessage("د تادیې ډول"),
        "pdfView": MessageLookupByLibrary.simpleMessage("PDF لید"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("شخصي معلومات"),
        "phone": MessageLookupByLibrary.simpleMessage("ټیلیفون"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("د تلیفون شمیره"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "د تلیفون شمېره دمخه کارول شوې"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("د تلیفون شمېره معتبره نه ده"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("د تلیفون شمېره اړینه ده"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("فایل وټاکئ او پورته کړئ"),
        "pickEndDate": MessageLookupByLibrary.simpleMessage("د پای نېټه وټاکئ"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("د پیل نېټه وټاکئ"),
        "plan": MessageLookupByLibrary.simpleMessage("پلان"),
        "pleaseAddQuantity": MessageLookupByLibrary.simpleMessage(
            "مهرباني وکړئ مقدار اضافه کړئ"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "لطفاً د انټرنیټ اړیکه چک کړئ"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "مهرباني وکړئ لومړی پرنټر ونښلئ"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "مهرباني وکړئ خپل بلوتوث پرنټر سره وصل کړئ"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "مهرباني وکړئ یو لوی پټنوم ولیکئ"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "مهرباني وکړئ یو تایید شوی پاسورډ داخل کړئ"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("لطفاً یوه پټ نوم داخل کړئ"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "مهرباني وکړئ یو معتبر برېښنالیک ولیکئ"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("مهرباني وکړئ نوم ولیکئ"),
        "pleaseEnterPassword": MessageLookupByLibrary.simpleMessage(
            "مهرباني وکړئ پاسورډ داخل کړئ"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "لطفا لاندې د بریښنالیک آدرس داخل کړئ ترڅو د پټ نوم بیا تنظیم کولو لینک ترلاسه کړئ."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "مهرباني وکړئ د تراکنش شمیره داخل کړئ"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("مهرباني وکړئ مقدار ولیکئ"),
        "pleaseSelectACategoryFirst":
            MessageLookupByLibrary.simpleMessage("لومړی یوه کټګوري انتخاب کړئ"),
        "pleaseSelectAPlan": MessageLookupByLibrary.simpleMessage(
            "مهرباني وکړئ یو پلان انتخاب کړئ"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "مهرباني وکړئ د سوداګرۍ کټګوري انتخاب کړئ"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "مهرباني وکړئ د اپلیکیشن کارولو لپاره اعتبار لرونکی پیرود کوډ وکاروئ"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("د MobiPos له خوا تمویل شوی"),
        "poweredBy":
            MessageLookupByLibrary.simpleMessage("د دې لخوا تمویل شوی"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("د پریمیم مشتری ملاتړ"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("پرمیوم پلان"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("مخکېني تادیاتي مقدارونه"),
        "price": MessageLookupByLibrary.simpleMessage("قیمت"),
        "print": MessageLookupByLibrary.simpleMessage("چاپ"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("د چاپ کولو انتخاب"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("د محرمیت پالیسي"),
        "product": MessageLookupByLibrary.simpleMessage("محصول"),
        "productCode": MessageLookupByLibrary.simpleMessage("د محصول کوډ"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("د محصول کوډ اړین دی"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("د محصول کوډ / نوم"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("د محصول تفصیل"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("د محصول تفصیلات"),
        "productList": MessageLookupByLibrary.simpleMessage("د محصول لیست"),
        "productName": MessageLookupByLibrary.simpleMessage("د محصول نوم"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "د محصول نوم په دې ګودام کې دمخه شتون لري"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "د محصول نوم لا دمخه اضافه شوی دی"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("د محصول نوم اړین دی"),
        "products": MessageLookupByLibrary.simpleMessage("محصولات"),
        "profile": MessageLookupByLibrary.simpleMessage("پروفایل"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("د پروفایل سمون"),
        "profit": MessageLookupByLibrary.simpleMessage("ګټه"),
        "promo": MessageLookupByLibrary.simpleMessage("پرومو"),
        "promoCode": MessageLookupByLibrary.simpleMessage("پرومو کوډ"),
        "purchase": MessageLookupByLibrary.simpleMessage("پېرود"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage("د پیرود الرښود"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("پیرود تایید شوی"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("د پېرودلو تفصیلات"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("د پیرود فاکتور"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("د پېرودلو لیست"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("اوس یې واخلئ"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("پرمیوم پلان واخلئ"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("د پیرود قیمت"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("د پیرود قیمت اړین دی"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("د پېرودلو راپور"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("د پېرودلو راپور"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("د پیرود راپورونه"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("د پیرود راستنیدل"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("د پیرود راستنېدنې راپور"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("د پیرود لیږد"),
        "qty": MessageLookupByLibrary.simpleMessage("مقدار"),
        "quantity": MessageLookupByLibrary.simpleMessage("مقدار"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("تازه معاملې"),
        "recivedThePin": MessageLookupByLibrary.simpleMessage("PIN ترلاسه شو"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("د حوالې شمیره"),
        "register": MessageLookupByLibrary.simpleMessage("ثبت نوم"),
        "registering": MessageLookupByLibrary.simpleMessage("ثبت کول"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("باقي پاتې"),
        "remove": MessageLookupByLibrary.simpleMessage("لیرې کول"),
        "reports": MessageLookupByLibrary.simpleMessage("راپورونه"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("غوښتنه لیږل شوې"),
        "resendCode": MessageLookupByLibrary.simpleMessage("کوډ بیا واستوئ"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("OTP بیا واستوئ:"),
        "retailer": MessageLookupByLibrary.simpleMessage("پرچون فروش"),
        "retur": MessageLookupByLibrary.simpleMessage("بېرته راستنیدل"),
        "returN": MessageLookupByLibrary.simpleMessage("راستنېدل"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("بېرته راستنیدل"),
        "returnAmount":
            MessageLookupByLibrary.simpleMessage("د راستنولو مقدار"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("د راستنېدنې مقدار"),
        "revenue": MessageLookupByLibrary.simpleMessage("عایدات"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "خپل کاروبار معلومات په اسانۍ سره خوندي کړئ. زموږ د Pos Saas POS بې حده تازه کولو سره وړیا معلوماتو بیک اپ شامل دی، چې ستاسو قیمتي معلومات د هر ډول ناڅاپي پیښو څخه خوندي کوي. د هغه څه باندې تمرکز وکړئ چې واقعاً مهم دی - د خپل کاروبار وده."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("د پلور مقدار"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("د خرڅلاو تفصیلات"),
        "salePrice": MessageLookupByLibrary.simpleMessage("د خرڅلاو قیمت"),
        "saleReports": MessageLookupByLibrary.simpleMessage("د خرڅلاو راپور"),
        "saleReportss": MessageLookupByLibrary.simpleMessage("د پلور راپورونه"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("د پلور راستنېدنه"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("د پلور راستنېدنې راپور"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("د پلور ترتیب"),
        "sales": MessageLookupByLibrary.simpleMessage("خرڅلاو"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("د پلور او پېرود راپورونه"),
        "salesList": MessageLookupByLibrary.simpleMessage("د خرڅلاو لیست"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("د پلور راستنېدل"),
        "save": MessageLookupByLibrary.simpleMessage("ژغورل"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("ذخیره او خپره کړئ"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("تغیرات خوندي کړئ"),
        "saving": MessageLookupByLibrary.simpleMessage("زېرمه کول"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("د محصول QR کوډ سکین کړئ"),
        "search": MessageLookupByLibrary.simpleMessage("لټون"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "د محصول کوډ یا نوم له مخې پلټنه"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("ټول پرومو کوډونه وګورئ"),
        "select": MessageLookupByLibrary.simpleMessage("ټاکل"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "د راستنیدو لپاره محصول انتخاب کړئ"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("برنډ انتخاب کړئ"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("کټګوري انتخاب کړئ"),
        "selectContacts": MessageLookupByLibrary.simpleMessage("اړيکې وټاکئ"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("د محصول کټګوري انتخاب کړئ"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("د دوکان کټګوري انتخاب کړئ"),
        "selectTax": MessageLookupByLibrary.simpleMessage("مالیه انتخاب کړئ"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("د مالیې ډول انتخاب کړئ"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("یونټ انتخاب کړئ"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("تغییرات غوره کړئ: "),
        "seller": MessageLookupByLibrary.simpleMessage("پلورونکی"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("د پلورونکی لخوا"),
        "send": MessageLookupByLibrary.simpleMessage("استول"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("برېښنالیک واستوئ"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("پیغام ولېږئ"),
        "sendResetLink": MessageLookupByLibrary.simpleMessage(
            "د بیا تنظیم کولو لینک واستوئ"),
        "sendSms": MessageLookupByLibrary.simpleMessage("SMS واستوئ"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("SMS ولېږئ؟"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("د وټس اپ پیغام واستوئ"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("خپلې ایمیل ولېږئ"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage("برېښنالیک لیږل"),
        "sendingMessage": MessageLookupByLibrary.simpleMessage("پیغام لیږل"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("خدمت / بار وړل"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("خپله پروفایل ترتیب کړئ"),
        "setting": MessageLookupByLibrary.simpleMessage("تنظیمات"),
        "share": MessageLookupByLibrary.simpleMessage("شریک کړئ"),
        "shopGST": MessageLookupByLibrary.simpleMessage("د دوکان GST"),
        "signIn": MessageLookupByLibrary.simpleMessage("ننوتل"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("د برېښنالیک سره ننوتل"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("د پیرودونکي لاسلیک"),
        "size": MessageLookupByLibrary.simpleMessage("حجم"),
        "skip": MessageLookupByLibrary.simpleMessage("پرته کړئ"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("اجتماعي بازارموندنه"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "بښنه غواړم، تاسو دې خدمت ته د لاسرسي اجازه نه لرئ"),
        "startDate": MessageLookupByLibrary.simpleMessage("د پیل نېټه"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("نوې پلور شروع کړئ"),
        "startTypingToSearch":
            MessageLookupByLibrary.simpleMessage("د لټون لپاره لیکل پیل کړئ"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "د اضافي لګښت پرته د ټیکنالوژۍ د پرمختګونو په لومړۍ کرښه کې اوسئ. زموږ د Pos Saas POS بې حده تازه کولو سره، تاسو تل د دې لپاره چې تازه وسايل او ځانګړتیاوې ولرئ، چې ستاسو کاروبار د پرمختللې په توګه پاتې شي، دا تضمین کیږي."),
        "stillUnpaid":
            MessageLookupByLibrary.simpleMessage("لا هم نه تادیه شوی"),
        "stock": MessageLookupByLibrary.simpleMessage("زېرمه"),
        "stockIsRequired": MessageLookupByLibrary.simpleMessage("مخزن اړین دی"),
        "stockList": MessageLookupByLibrary.simpleMessage("د سټاک لیست"),
        "stocks": MessageLookupByLibrary.simpleMessage("زېرمه"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "د ایکسل فایل جوړولو لپاره د ذخیرې اجازه لازمي ده"),
        "subTaxList":
            MessageLookupByLibrary.simpleMessage("د فرعي مالیاتو لیست"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("فرعي مالیات"),
        "subTotal": MessageLookupByLibrary.simpleMessage("فرعي مجموع"),
        "submit": MessageLookupByLibrary.simpleMessage("لېږل"),
        "subscribeToOurYoutube":
            MessageLookupByLibrary.simpleMessage("زموږ یوټیوب ته ګډون وکړئ"),
        "subscription": MessageLookupByLibrary.simpleMessage("د ګډون"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("په بریالیتوب سره بشپړ شو"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("په بریالیتوب سره وتلی"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("په بریالیتوب سره تازه شو"),
        "supplier": MessageLookupByLibrary.simpleMessage("چمتو کونکی"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("د عرضه کوونکي نوم"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("SWIFT کوډ"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "د موټر چلونکي اجازه لیک، ملي شناختي کارت یا د پاسپورټ عکس واخلئ"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "د معلوماتو د تایید لپاره د شناختي کارت واخلئ"),
        "tap": MessageLookupByLibrary.simpleMessage("تاپ"),
        "tax": MessageLookupByLibrary.simpleMessage("مالیه"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("د مالیاتو ډله"),
        "taxPercentage":
            MessageLookupByLibrary.simpleMessage("د مالیاتو فیصدي"),
        "taxRate": MessageLookupByLibrary.simpleMessage("د مالیې کچه"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "د مالیاتو کچې - د مالیاتو کچې اداره کړئ"),
        "taxReport": MessageLookupByLibrary.simpleMessage("د مالیاتو راپور"),
        "taxType": MessageLookupByLibrary.simpleMessage("د مالیې ډول"),
        "taxes": MessageLookupByLibrary.simpleMessage("مالیات"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("شرطونه او شرایط"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("د کار شرایط"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("شرطونه او د پټتیا تګلاره"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "ستاسو د پاتې تادیې لپاره مننه"),
        "thankYou": MessageLookupByLibrary.simpleMessage("مننه"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("ستاسو د پیرود لپاره مننه"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "د دې ایمیل لپاره حساب لا دمخه شته"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "ایکسلس فایل لا دمخه ډاونلوډ شوی دی"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "د نوم سیسټم دا ټول وايي. د Pos Saas POS بې حده سره، ستاسو د کارولو په اړه هیڅ بندیز نشته. که تاسو څو معاملې ترسره کوئ یا د مشتریانو له خوا یوه هجوم تجربه کوئ، تاسو کولی شئ په باور سره عملیات وکړئ، پوهیږئ چې تاسو د محدودیتونو له مخې نه یاست."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "ورکړل شوی پاسورډ ډیر ضعیف دی"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "پلور به حذف شي او د دې پیرود په اړه ټول معلومات به حذف شي. آیا تاسو پدې یقین لرئ؟"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "پلور به حذف شي او د دې پلور په اړه ټول معلومات به حذف شي. آیا تاسو پدې یقین لرئ؟"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "کارونکی حذف شي او ټول معلومات به له خپل حساب څخه حذف شي. آیا تاسو د حذف کولو په اړه ډاډه یاست؟"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "کاروونکی به حذف شي او ټول معلومات به ستاسو له حسابه حذف شي. آیا تاسو باوري یاست چې حذف کړئ؟"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("د دریمې ډلې خدمات"),
        "thisCategoryCannotBeDeleted":
            MessageLookupByLibrary.simpleMessage("دا کټګوري نشي حذف کیدلی"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(دا میاشت)"),
        "thisProductAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("دا محصول دمخه اضافه شوی"),
        "title": MessageLookupByLibrary.simpleMessage("سرلیک"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("سرلیک نشي خالي کېدی"),
        "to": MessageLookupByLibrary.simpleMessage("تر"),
        "toDate": MessageLookupByLibrary.simpleMessage("تر نیټې"),
        "today": MessageLookupByLibrary.simpleMessage("نن"),
        "total": MessageLookupByLibrary.simpleMessage("مجموع"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("ټول مقدار"),
        "totalCollected": MessageLookupByLibrary.simpleMessage("ټول راټول شوی"),
        "totalDue": MessageLookupByLibrary.simpleMessage("ټول پاتې"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("ټول خرڅ"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("ټول زیان"),
        "totalPayable": MessageLookupByLibrary.simpleMessage("مجموع ادا کول"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("مجموع قیمت"),
        "totalProducts": MessageLookupByLibrary.simpleMessage("ټول محصولات"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("ټول ګټه"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("ټول پیرود"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("د ټول راستنیدنې مقدار"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("ټول راستنېدنې"),
        "totalSale": MessageLookupByLibrary.simpleMessage("مجموعه پلور"),
        "totalStock": MessageLookupByLibrary.simpleMessage("ټول سټاک"),
        "totalValue": MessageLookupByLibrary.simpleMessage("مجموعي ارزښت"),
        "totalVat": MessageLookupByLibrary.simpleMessage("مجموع VAT"),
        "totals": MessageLookupByLibrary.simpleMessage("ټول: "),
        "transaction": MessageLookupByLibrary.simpleMessage("معامله"),
        "transactionId": MessageLookupByLibrary.simpleMessage("د معاملې ID"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("بیا هڅه وکړئ"),
        "twitter": MessageLookupByLibrary.simpleMessage("توئیټر"),
        "type": MessageLookupByLibrary.simpleMessage("ډول"),
        "unitName": MessageLookupByLibrary.simpleMessage("د واحد نوم"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("د واحد قیمت"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("یونیټ قیمت"),
        "units": MessageLookupByLibrary.simpleMessage("واحدونه"),
        "unlimited": MessageLookupByLibrary.simpleMessage("نامحدود"),
        "unlimitedUsage": MessageLookupByLibrary.simpleMessage("بې حده کارول"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "د Pos Saas POS بشپړ ظرفیت قفل کړئ د شخصي روزنې غونډو سره چې زموږ د متخصص ټیم لخوا ترسره کیږي. له بنسټیزو څخه تر پرمختللو تخنیکونو پورې، موږ تضمین کوو چې تاسو د سیسټم هر اړخ ته ښه پوهه لرئ ترڅو د خپل کاروبار پروسې اصلاح کړئ."),
        "unpaid": MessageLookupByLibrary.simpleMessage("بې پیسو"),
        "update": MessageLookupByLibrary.simpleMessage("تازه کړئ"),
        "updateContact": MessageLookupByLibrary.simpleMessage("اړیکه تازه کړئ"),
        "updateNow": MessageLookupByLibrary.simpleMessage("اوس تازه کړئ"),
        "updateProduct": MessageLookupByLibrary.simpleMessage("محصول تازه کړئ"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "خپل پلان لومړی تازه کړئ، ستاسو حد پای ته رسېدلی دی"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("ستاسو پروفایل تازه کړئ"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "خپله پروفایل تازه کړئ ترڅو خپل ډاکټر سره ښه اړیکه ونیسئ"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "ستاسو پروفایل تازه کړئ ترڅو د خپلو پیرودونکو سره ښه اړیکه ولرئ"),
        "updated": MessageLookupByLibrary.simpleMessage("تازه شوی"),
        "upload": MessageLookupByLibrary.simpleMessage("پورته کړئ"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("مدرک پورته کړئ"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("پورته کول بشپړ شو"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("فایل پورته کړئ"),
        "upplier": MessageLookupByLibrary.simpleMessage("چمتو کونکی"),
        "usbC": MessageLookupByLibrary.simpleMessage("یو اس بی C"),
        "use": MessageLookupByLibrary.simpleMessage("استفاده"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("POS SaaS وکاروئ"),
        "useOfTheSystem": MessageLookupByLibrary.simpleMessage("د سیسټم کارول"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("کاروونکی حذف شوی"),
        "userRole": MessageLookupByLibrary.simpleMessage("د کارونکي رول"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("د کارونکي د رول تفصیلات"),
        "userTitle": MessageLookupByLibrary.simpleMessage("د کارونکي سرلیک"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "د کارونکي عنوان نشي خالي کیدلی"),
        "value": MessageLookupByLibrary.simpleMessage("ارزښت"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("VAT نه پلي کیږي"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("OTP تایید کول"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("د تلیفون شمیره تایید کړئ"),
        "viewAll": MessageLookupByLibrary.simpleMessage("ټول وګورئ"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("تفصیلات وګورئ"),
        "walkInCustomer": MessageLookupByLibrary.simpleMessage("پیاده مشتری"),
        "warehouse": MessageLookupByLibrary.simpleMessage("ګودام"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("ګودام لا دمخه شته"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("د ګودام لیست"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("د ګودام نوم"),
        "warranty": MessageLookupByLibrary.simpleMessage("تضمین"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "موږ یوه بریښنالیک د پخواني تڼۍ د بیا جوړولو لپاره د لارښوونو سره واستوه:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "موږ ممکن د اپلیکیشن د فعالیت ملاتړ لپاره د دریمې ډلې خدمات وکاروو، لکه د تحلیل چمتو کونکي او د تادیاتو پروسسرونه. دا دریمې ډلې خدمات ممکن هغه وخت ستاسو په اړه معلومات ټول کړي کله چې تاسو زموږ اپلیکیشن کاروئ. مهرباني وکړئ په یاد ولرئ چې موږ د دې دریمې ډلې خدماتو د حریم ساتنې کړنلاره کې مسؤل نه یو."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "موږ د صنعت معیارونو سره سم د خپلو شخصي معلوماتو د ساتنې لپاره تدابیر نیسو، پشمول کوډونه او خوندي ذخیره. موږ همداراز د دې معلوماتو ته د لاسرسي محدودیت یوازې مجاز کارمندانو ته ټاکلی دی."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "موږ د روانو عملیاتو اهمیت پوهیږو. له همدې امله زموږ ۲۴ ساعته ملاتړ د دې لپاره شتون لري چې تاسو سره مرسته وکړي، که دا چټک پوښتنه وي یا پراخې اندیښنې. هر وخت او هر ځای موږ سره د اړیکه نیولو لپاره د تلیفون یا WhatsApp له لارې اړیکه ونیسئ ترڅو بې ساری مشتری خدمت تجربه کړئ."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "موږ ستاسو شخصي معلومات د دې لپاره کاروو چې تاسو ته زموږ په اپلیکیشن کې تر ټولو غوره تجربه وړاندې کړو، پشمول ستاسو د محتوا وړاندیزونه شخصي کول، تاسو له متخصصینو سره اړیکه نیول، او د زموږ اپلیکیشن فعالیت ښه کول. موږ ممکن ستاسو معلومات د تازه معلوماتو، ترویجونو، یا زموږ اپلیکیشن سره تړاو لرونکو نورو معلوماتو په اړه ستاسو سره د اړیکو لپاره هم وکاروو."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "موږ به پیسې وڅیړو او په ۱-۲ ساعتونو کې به یې تصویب کړو"),
        "weekly": MessageLookupByLibrary.simpleMessage("اوړي"),
        "weight": MessageLookupByLibrary.simpleMessage("وزن"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("نوې څه دي"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("د عمده پلورونکی"),
        "wholeSalePrice": MessageLookupByLibrary.simpleMessage("تخفیفي قیمت"),
        "wholesalePrice":
            MessageLookupByLibrary.simpleMessage("د عمده پلور قیمت"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("هول سیلر"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("ژر به اضافه شي"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("دلته به ختم شي"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("دلته خپل پیغام ولیکئ"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("غلط OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "د دې کارونکي لپاره ناسم پټ نوم ورکړل شوی."),
        "yearly": MessageLookupByLibrary.simpleMessage("سالیانه"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("هو، تل لپاره حذف کړئ"),
        "youAreNotAValidUser": MessageLookupByLibrary.simpleMessage(
            "تاسو اعتبار لرونکی کارونکی نه یاست"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("تاسو کاروئ"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "تاسو نشئ کولی له مستحقې زیاتې پیسې ورکړئ"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("تاسو ته یوه بریښنالیک راغلی"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "تاسو په بریالیتوب سره خپل حساب ته ننووتل. د Pos SaaS سره پاتې شئ."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("تاسو باید اجازه ورکړئ"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "تاسو باید په خپل حساب کې بیا ننوتل وکړئ."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "تاسو اړتیا لرئ چې د SMS پیرودلو دمخه خپل هویت تصدیق کړئ"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("ستاسو پیغام پاتې دی"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("ستاسو بسته"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "ستاسو بسته به د ۵ ورځو وروسته پای ته ورسیږي")
      };
}
