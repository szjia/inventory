// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a sk locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'sk';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Pokračovať"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("Číslo GST"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("Maloobchodná cena"),
        "MRPIsRequired": MessageLookupByLibrary.simpleMessage("MRP je povinné"),
        "OK": MessageLookupByLibrary.simpleMessage("OK"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Tel. č."),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT kód"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Svačiny"),
        "TAX": MessageLookupByLibrary.simpleMessage("DAŇ"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Nahráva sa"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("Názov používateľa"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Váš balíček vyprší dnes.\n\nProsím, zakúpte si ho znova."),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) Systém sa poskytuje výlučne na účely zjednodušenia transakcií v mieste predaja a súvisiacich činností vo vašom podnikaní."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) Pre používanie Systému môže byť vyžadovaná registrácia účtu. Súhlasíte s poskytovaním presných, aktuálnych a úplných informácií počas procesu registrácie a s ich aktualizáciou, aby zostali presné a úplné."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("O aplikácii"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("O nás"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Akceptácia podmienok"),
        "accountName": MessageLookupByLibrary.simpleMessage("Názov účtu"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("Číslo účtu"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Registrácia účtu"),
        "acton": MessageLookupByLibrary.simpleMessage("Akcia"),
        "add": MessageLookupByLibrary.simpleMessage("Pridať"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Pridať značku"),
        "addCategory": MessageLookupByLibrary.simpleMessage("Pridať kategóriu"),
        "addContact": MessageLookupByLibrary.simpleMessage("Pridať kontakt"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Pridať zákazníka"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("Pridať doručenie"),
        "addDescriptioN": MessageLookupByLibrary.simpleMessage("Pridať popis"),
        "addDescription":
            MessageLookupByLibrary.simpleMessage("Pridať poznámku"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Pridať zľavu"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Pridať identifikačné číslo"),
        "addDucument": MessageLookupByLibrary.simpleMessage("Pridať dokument"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Pridať výdavok"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Pridať kategóriu výdavkov"),
        "addItems": MessageLookupByLibrary.simpleMessage("Pridať položky"),
        "addNew": MessageLookupByLibrary.simpleMessage("Pridať nové"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Pridať novú adresu"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Pridať nový produkt"),
        "addNewTax": MessageLookupByLibrary.simpleMessage("Pridať novú daň"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Pridať novú daň s jedným/multidruhom dane"),
        "addNote": MessageLookupByLibrary.simpleMessage("Pridať poznámku"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Najprv pridajte produkt"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Pridať promo kód"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Pridať nákup"),
        "addSales": MessageLookupByLibrary.simpleMessage("Pridať predaj"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Úspešne pridané"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Pridať jednotku"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Pridať používateľskú rolu"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Úspešne pridané"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("Pridané do košíka"),
        "address": MessageLookupByLibrary.simpleMessage("Adresa"),
        "admin": MessageLookupByLibrary.simpleMessage("Admin"),
        "all": MessageLookupByLibrary.simpleMessage("Všetko"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("Všetky obchodné riešenia"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("Už pridané"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Už existuje"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Už máte účet"),
        "amount": MessageLookupByLibrary.simpleMessage("Čiastka"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "Bol zaslaný e-mail. Skontrolujte svoju doručenú poštu."),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Podpora pre Android a iOS aplikácie"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Uplatniteľná daň"),
        "apply": MessageLookupByLibrary.simpleMessage("Použiť"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Ste si istý, že chcete odstrániť túto faktúru?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Ste si istý, že chcete odstrániť tento predaj?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Ste si istý, že chcete odstrániť tohto používateľa?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Ste si istý, že chcete odstrániť túto daň?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Ste si istý, že chcete odstrániť túto skupinu daní?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Chcete odstrániť tento sklad?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Ste si istí, že chcete vymazať tohto používateľa?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Podpis oprávnenej osoby"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Ste zodpovední za zachovanie dôvernosti vášho účtu a hesla a za obmedzenie prístupu k vášmu účtu. Vezmete na seba zodpovednosť za všetky aktivity, ktoré sa vyskytnú v rámci vášho účtu."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Na používanie Systému musíte mať aspoň 18 rokov alebo dosiahnuť zákonný vek väčšiny vo vašej jurisdikcii."),
        "backSide": MessageLookupByLibrary.simpleMessage("Zadná strana"),
        "backToHome": MessageLookupByLibrary.simpleMessage("Späť na domov"),
        "balance": MessageLookupByLibrary.simpleMessage("Zostatok"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladéš"),
        "bank": MessageLookupByLibrary.simpleMessage("Banka"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Mena bankového účtu"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Mena bankového účtu"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Informácie o banke"),
        "bankName": MessageLookupByLibrary.simpleMessage("Názov banky"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("Bankový prevod"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Čiarový kód nájdený"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Faktúra"),
        "billTo": MessageLookupByLibrary.simpleMessage("Účtovať"),
        "branchName": MessageLookupByLibrary.simpleMessage("Názov pobočky"),
        "brand": MessageLookupByLibrary.simpleMessage("Značka"),
        "brandName": MessageLookupByLibrary.simpleMessage("Názov značky"),
        "bulkUpload":
            MessageLookupByLibrary.simpleMessage("Hromadné \nNahrávanie"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Kategória podniku"),
        "buy": MessageLookupByLibrary.simpleMessage("Kúpiť"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Kúpiť prémiový plán"),
        "buySms": MessageLookupByLibrary.simpleMessage("Kúpiť SMS"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Používaním alebo prístupom k systému predaja (POS) (ďalej len „Systém“) poskytnutého spoločnosťou [Názov vašej spoločnosti] („Spoločnosť“) súhlasíte s týmito podmienkami používania. Ak nesúhlasíte s týmito podmienkami používania, nezakazujte Systém."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Zodpovedáte za zabezpečenie, aby váš prístup a používanie Systému boli v súlade so všetkými príslušnými zákonmi a predpismi."),
        "cacel": MessageLookupByLibrary.simpleMessage("Zrušiť"),
        "call": MessageLookupByLibrary.simpleMessage("Volanie"),
        "callForEmergencySupport":
            MessageLookupByLibrary.simpleMessage("Zavolajte pre núdzovú pomoc"),
        "camera": MessageLookupByLibrary.simpleMessage("Fotoaparát"),
        "cancel": MessageLookupByLibrary.simpleMessage("Zrušiť"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Zrušiť všetky produkty"),
        "capacity": MessageLookupByLibrary.simpleMessage("Kapacita"),
        "card": MessageLookupByLibrary.simpleMessage("Karta"),
        "cash": MessageLookupByLibrary.simpleMessage("Hotovosť"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Bezhotovostne"),
        "categories": MessageLookupByLibrary.simpleMessage("Kategórie"),
        "category": MessageLookupByLibrary.simpleMessage("Kategória"),
        "categoryName": MessageLookupByLibrary.simpleMessage("Názov kategórie"),
        "categoryNameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Názov kategórie už existuje"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("Názov kategórie"),
        "change": MessageLookupByLibrary.simpleMessage("Zmeniť?"),
        "changePassword": MessageLookupByLibrary.simpleMessage("Zmeniť heslo"),
        "checkEmail":
            MessageLookupByLibrary.simpleMessage("Skontrolovať e-mail"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Vyberte zákazníka"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Vyberte dodávateľa"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Vyberte si svoje funkcie"),
        "clarence": MessageLookupByLibrary.simpleMessage("Clarence"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Kliknite pre pripojenie"),
        "close": MessageLookupByLibrary.simpleMessage("Zavrieť"),
        "color": MessageLookupByLibrary.simpleMessage("Farba"),
        "combinationOfMultipleTaxes":
            MessageLookupByLibrary.simpleMessage("(Kombinácia viacerých daní)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Čoskoro"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Adresa spoločnosti"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Názov spoločnosti a obchodu"),
        "companyBusinessName": MessageLookupByLibrary.simpleMessage(
            "Názov spoločnosti a podnikania"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Dokončiť transakciu"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Potvrďte heslo"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Potvrdiť vrátenie"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Gratulujeme"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Kontaktujte nás"),
        "continu": MessageLookupByLibrary.simpleMessage("Pokračovať"),
        "country": MessageLookupByLibrary.simpleMessage("Krajina"),
        "create": MessageLookupByLibrary.simpleMessage("Vytvoriť"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Vytvoriť bezplatný účet"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Vytvorené a uložené"),
        "currency": MessageLookupByLibrary.simpleMessage("Mena"),
        "currentStock": MessageLookupByLibrary.simpleMessage("Aktuálna zásoba"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("Prispôsobenie faktúr značke"),
        "customer": MessageLookupByLibrary.simpleMessage("Zákazník"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Detaily zákazníka"),
        "customerGST": MessageLookupByLibrary.simpleMessage("GST zákazníka"),
        "customerName": MessageLookupByLibrary.simpleMessage("Meno zákazníka"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Denná transakcia"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Prehľad nástenky"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Údaje úspešne uložené"),
        "date": MessageLookupByLibrary.simpleMessage("Dátum"),
        "day": MessageLookupByLibrary.simpleMessage("Deň"),
        "dealer": MessageLookupByLibrary.simpleMessage("Distribútor"),
        "dealerPrice":
            MessageLookupByLibrary.simpleMessage("Cena pre predajcov"),
        "defaultVATPercentage": MessageLookupByLibrary.simpleMessage(
            "Predvolený percentuálny podiel DPH"),
        "delete": MessageLookupByLibrary.simpleMessage("Vymazať"),
        "deleting": MessageLookupByLibrary.simpleMessage("Odstraňovanie"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Dodacia adresa"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Dodacie adresy"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Poplatok za doručenie"),
        "describtion": MessageLookupByLibrary.simpleMessage("Popis"),
        "description": MessageLookupByLibrary.simpleMessage("Popis"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Popis nesmie byť prázdny"),
        "details": MessageLookupByLibrary.simpleMessage("Podrobnosti"),
        "discount": MessageLookupByLibrary.simpleMessage("Zľava"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Nerušiť"),
        "done": MessageLookupByLibrary.simpleMessage("Hotovo"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Stiahnuť formát Excel"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Úspešne stiahnuté do priečinka na stiahnutie"),
        "due": MessageLookupByLibrary.simpleMessage("Dlh"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Suma dlhu: "),
        "dueCollection": MessageLookupByLibrary.simpleMessage("Zbierka dlhov"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("Správy o splatných zálohách"),
        "dueList": MessageLookupByLibrary.simpleMessage("Zoznam dlhov"),
        "dueReports":
            MessageLookupByLibrary.simpleMessage("Správa o záväzkoch"),
        "duration": MessageLookupByLibrary.simpleMessage("Trvanie"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Trvanie: Od"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "Jednoduchý mobilný bod predaja"),
        "edit": MessageLookupByLibrary.simpleMessage("Upraviť"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Upraviť faktúru nákupu"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Upraviť faktúru predaja"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Upraviť sociálne média"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Úprava úspešná"),
        "editTax": MessageLookupByLibrary.simpleMessage("Upraviť daň"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Upraviť skupinu daní"),
        "editWarehouse": MessageLookupByLibrary.simpleMessage("Upraviť sklad"),
        "email": MessageLookupByLibrary.simpleMessage("E-mail"),
        "emailAddress":
            MessageLookupByLibrary.simpleMessage("E-mailová adresa"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Email nemôže byť prázdny"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "E-mail bol odoslaný! Skontrolujte svoju doručenú poštu"),
        "endDate": MessageLookupByLibrary.simpleMessage("Dátum ukončenia"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Zadajte platnú sumu"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Zadajte platnú zľavu"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Zadajte platné telefónne číslo"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Zadajte platnú cenu"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("Zadajte platné množstvo"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("Zadajte adresu"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("Zadajte sumu."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Zadajte názov značky"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Zadajte kapacitu"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Zadajte názov kategórie"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Zadajte farbu"),
        "enterCustomerGstNumber":
            MessageLookupByLibrary.simpleMessage("Zadajte číslo GST zákazníka"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Zadajte cenu pre predajcov"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Zadajte popis"),
        "enterDiscount": MessageLookupByLibrary.simpleMessage("Zadajte zľavu"),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Zadajte dátum výdavku"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Zadajte úplnú adresu"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Zadajte číslo faktúry"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Zadajte množstvo upozornenia na nízky stav"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Zadajte výrobcu"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("Zadajte obsah správy"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "Zadajte maloobchodnú cenu / cenu pre maloobchodníkov"),
        "enterName": MessageLookupByLibrary.simpleMessage("Zadajte meno"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Zadajte poznámku"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Zadajte názov strany"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Zadajte telefónne číslo"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Zadajte kód produktu alebo skenujte"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Zadajte názov produktu"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Zadajte nákupnú cenu"),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("Zadajte referenčné číslo"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Zadajte veľkosť"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("Zadajte zásoby"),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Zadajte sadzbu dane"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("Zadajte ID transakcie"),
        "enterType": MessageLookupByLibrary.simpleMessage("Zadajte typ"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("Zadajte názov používateľa"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Zadajte platnú sumu"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Zadajte názov skladu"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Zadajte hmotnosť"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Zadajte veľkoobchodnú cenu"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("Sem zadajte svoj popis"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "Zadajte svoju e-mailovú adresu"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "Zadajte názov vašej spätnej väzby"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Zadajte svoje číslo GST"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("Zadajte svoje mobilné číslo"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Zadajte svoje meno"),
        "enterYourNumber": MessageLookupByLibrary.simpleMessage(
            "Zadajte svoje telefónne číslo"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Zadajte svoje heslo"),
        "enterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Zadajte svoje telefónne číslo"),
        "enterYourTransactionId":
            MessageLookupByLibrary.simpleMessage("Zadajte ID transakcie"),
        "error": MessageLookupByLibrary.simpleMessage("Chyba"),
        "excTax": MessageLookupByLibrary.simpleMessage("Bez dane"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("Nahrávač Excel"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Exkluzívny"),
        "expense": MessageLookupByLibrary.simpleMessage("Výdavok"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Kategória výdavkov"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Dátum výdavku"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Výdavok pre"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Správa o výdavkoch"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Dátum expirácie"),
        "expired": MessageLookupByLibrary.simpleMessage("Expirované"),
        "expiring": MessageLookupByLibrary.simpleMessage("Expirujúce"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Zlyhalo s chybou"),
        "fashion": MessageLookupByLibrary.simpleMessage("Móda"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Funkcie sú dôležitou časťou, ktorá robí Pos Saas odlišným od tradičných riešení."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Spätná väzba"),
        "firstName": MessageLookupByLibrary.simpleMessage("Krstné meno"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Sledujte nás na\\nFacebooku"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Sledujte nás na\\nTwitteri"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Predná strana"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("Na neobmedzené použitie"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Zabudli ste heslo"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Zabudli ste heslo?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Od dátumu"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("Zálohovanie dát zdarma"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "Aktualizácia na celý život zdarma"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Zadarmo balíček"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Zadarmo"),
        "from": MessageLookupByLibrary.simpleMessage("(Od"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Úplne zaplatené"),
        "gallary": MessageLookupByLibrary.simpleMessage("Galéria"),
        "generatingPDF":
            MessageLookupByLibrary.simpleMessage("Generovanie PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Získať kód OTP"),
        "govermentId":
            MessageLookupByLibrary.simpleMessage("Doklad totožnosti"),
        "guest": MessageLookupByLibrary.simpleMessage("Host"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Nemáte účet?"),
        "history": MessageLookupByLibrary.simpleMessage("História"),
        "home": MessageLookupByLibrary.simpleMessage("Domov"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Ako chránime vaše informácie"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Ako využívame vaše informácie"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Overenie identity"),
        "image": MessageLookupByLibrary.simpleMessage("Obrázok"),
        "inHouseCantBeDelete": MessageLookupByLibrary.simpleMessage(
            "Interné nemôže byť odstránené"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("Interné nemôže byť upravené"),
        "inWord": MessageLookupByLibrary.simpleMessage("Slovom"),
        "incTax": MessageLookupByLibrary.simpleMessage("Vrátane dane"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Zahŕňajúci"),
        "increaseStock": MessageLookupByLibrary.simpleMessage("Zvýšiť zásoby"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Inštrument"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Č. faktúry"),
        "invoice": MessageLookupByLibrary.simpleMessage("Faktúra"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("Číslo faktúry"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Nastavenie faktúry"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Zobrazenie faktúry"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Položka pridaná"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification": MessageLookupByLibrary.simpleMessage("Overenie KYC"),
        "language": MessageLookupByLibrary.simpleMessage("Jazyk"),
        "lastName": MessageLookupByLibrary.simpleMessage("Priezvisko"),
        "ledger": MessageLookupByLibrary.simpleMessage("Účtovník"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Nákup na celý život"),
        "link": MessageLookupByLibrary.simpleMessage("Odkaz"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Podpora cez živý chat"),
        "loading": MessageLookupByLibrary.simpleMessage("Načítava sa"),
        "logIn": MessageLookupByLibrary.simpleMessage("Prihlásiť sa"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Odhlásiť sa"),
        "logOut": MessageLookupByLibrary.simpleMessage("Odhlásiť sa"),
        "login": MessageLookupByLibrary.simpleMessage("Prihlásiť sa"),
        "logo": MessageLookupByLibrary.simpleMessage("Logo"),
        "loss": MessageLookupByLibrary.simpleMessage("Strata"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Strata/Zisk"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Podrobnosti o strate/zisku"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Správa o zisku a strate"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Správy o zisku a strate"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Upozornenie na nízky stav"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Urobte trvalý dojem na svojich zákazníkov s faktúrami so značkou. Naša aktualizácia na neobmedzené používanie ponúka jedinečnú výhodu prispôsobenia faktúr, čím pridá profesionálny dotyk, ktorý posilňuje identitu vašej značky a podporuje vernosť zákazníkov."),
        "manageYourBussinessWith": MessageLookupByLibrary.simpleMessage(
            "Spravujte svoje podnikanie pomocou"),
        "manufactureDate": MessageLookupByLibrary.simpleMessage("Dátum výroby"),
        "margin": MessageLookupByLibrary.simpleMessage("Marža"),
        "masterCard": MessageLookupByLibrary.simpleMessage("MasterCard"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Výrobca"),
        "message": MessageLookupByLibrary.simpleMessage("Správa"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("História správ"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Pos Saas  app je zadarmo a jednoduchá na používanie. Je to vlastne jedno z najlepších POS systémov na svete."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas je kompletné obchodné riešenie s evidenciou zásob, účtami, predajmi, nákladmi a ziskom/stratom."),
        "mobile": MessageLookupByLibrary.simpleMessage("Mobil"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("Mobilná platba"),
        "monthly": MessageLookupByLibrary.simpleMessage("Mesačne"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("Viac informácií"),
        "name": MessageLookupByLibrary.simpleMessage("Zadajte svoje meno."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Názov už existuje"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("Názov nemôže byť prázdny"),
        "next": MessageLookupByLibrary.simpleMessage("Ďalšie"),
        "noConnection":
            MessageLookupByLibrary.simpleMessage("Žiadne pripojenie"),
        "noData": MessageLookupByLibrary.simpleMessage("Žiadne údaje"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Žiadne dostupné údaje"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Nenašli sa žiadne údaje"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("Nenašla sa žiadna história!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Žiadny produkt nenájdený"),
        "noSubTaxSelected": MessageLookupByLibrary.simpleMessage(
            "Žiadna poddaň nie je vybraná"),
        "noTransactionFound": MessageLookupByLibrary.simpleMessage(
            "Nenašla sa žiadna transakcia!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Pre túto e-mailovú adresu sa nenašiel žiadny používateľ."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "Nebola nájdená žiadna používateľská rola"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Nie je aktívny používateľ"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Nebol poskytnutý"),
        "note": MessageLookupByLibrary.simpleMessage("Poznámka"),
        "notes": MessageLookupByLibrary.simpleMessage("Poznámky"),
        "notification": MessageLookupByLibrary.simpleMessage("Oznámenie"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP odoslané na"),
        "office": MessageLookupByLibrary.simpleMessage("Kancelária"),
        "ok": MessageLookupByLibrary.simpleMessage("Ok"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS, ktorý obsahuje mnoho funkcií, vrátane sledovania predaja a riadenia zásob."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Tento systém vám pomáha zlepšiť vaše operácie pre vašich zákazníkov."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Náš POS systém by mal automaticky zjednodušiť denné operácie a uľahčiť navigáciu."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("Počiatočný zostatok"),
        "order": MessageLookupByLibrary.simpleMessage("Objednávky"),
        "other": MessageLookupByLibrary.simpleMessage("Iné"),
        "otp": MessageLookupByLibrary.simpleMessage("Zatvoriť"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Nie je na sklade"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Balenie"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Funkcie balíčka"),
        "paid": MessageLookupByLibrary.simpleMessage("Zaplatené"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Zaplatená suma"),
        "parties": MessageLookupByLibrary.simpleMessage("Strany"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Zoznam strán"),
        "partyGST": MessageLookupByLibrary.simpleMessage("GST strany"),
        "partyName": MessageLookupByLibrary.simpleMessage("Názov strany"),
        "password": MessageLookupByLibrary.simpleMessage("Heslo"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Heslo a potvrdenie hesla sa nezhodujú"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Heslo nemôže byť prázdne"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("Heslo sa nezhoduje"),
        "payCash": MessageLookupByLibrary.simpleMessage("Zaplatiť v hotovosti"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("Zaplatiť cez bkash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Zaplatiť cez PayPal"),
        "payeeName": MessageLookupByLibrary.simpleMessage("Meno príjemcu"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("Číslo príjemcu"),
        "payment": MessageLookupByLibrary.simpleMessage("Platba"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("Čiastka platby"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Platba dokončená"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Inštrukcie na platbu:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("Spôsob platby"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Typ platby"),
        "pdfView": MessageLookupByLibrary.simpleMessage("Zobrazenie PDF"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Osobné informácie"),
        "phone": MessageLookupByLibrary.simpleMessage("Telefón"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Telefónne číslo"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Telefónne číslo už je použité"),
        "phoneNumberIsNotValid": MessageLookupByLibrary.simpleMessage(
            "Telefónne číslo nie je platné"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("Telefónne číslo je povinné"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("Vyberte a nahrajte súbor"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("Vybrať dátum ukončenia"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Vybrať dátum začiatku"),
        "plan": MessageLookupByLibrary.simpleMessage("Plán"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("Prosím, pridajte množstvo"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Skontrolujte svoje pripojenie k internetu"),
        "pleaseConnectThePrinterFirst":
            MessageLookupByLibrary.simpleMessage("Najprv pripojte tlačiareň"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Prosím, pripojte svoju bluetooth tlačiareň"),
        "pleaseEnterABiggerPassword":
            MessageLookupByLibrary.simpleMessage("Zadajte dlhšie heslo"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Prosím, zadajte potvrdenie hesla"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("Prosím, zadajte heslo"),
        "pleaseEnterAValidEmail":
            MessageLookupByLibrary.simpleMessage("Zadajte platný email"),
        "pleaseEnterName": MessageLookupByLibrary.simpleMessage("Zadajte meno"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("Zadajte prosím heslo"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Prosím, zadajte nižšie svoju e-mailovú adresu, aby ste dostali odkaz na obnovenie hesla."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Prosím, zadajte číslo transakcie"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("Zadajte sumu"),
        "pleaseSelectACategoryFirst":
            MessageLookupByLibrary.simpleMessage("Najprv vyberte kategóriu"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("Prosím, vyberte plán"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Vyberte kategóriu podnikania"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Prosím, použite platný nákupný kód na použitie aplikácie"),
        "powerdedByMobiPos": MessageLookupByLibrary.simpleMessage(
            "Používa technológiu Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Poháňa"),
        "premiumCustomerSupport": MessageLookupByLibrary.simpleMessage(
            "Podpora pre prémiových zákazníkov"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Prémiový plán"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Predchádzajúce platby"),
        "price": MessageLookupByLibrary.simpleMessage("cena"),
        "print": MessageLookupByLibrary.simpleMessage("Tlačiť"),
        "printingOption": MessageLookupByLibrary.simpleMessage("Možnosť tlače"),
        "privacyPolicy": MessageLookupByLibrary.simpleMessage(
            "Zásady ochrany osobných údajov"),
        "product": MessageLookupByLibrary.simpleMessage("Produkt"),
        "productCode": MessageLookupByLibrary.simpleMessage("Kód produktu"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("Kód produktu je povinný"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Kód/Názov produktu"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Popis produktu"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Podrobnosti o produkte"),
        "productList": MessageLookupByLibrary.simpleMessage("Zoznam produktov"),
        "productName": MessageLookupByLibrary.simpleMessage("Názov produktu"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Názov produktu už existuje v tomto sklade"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Názov produktu je už pridaný"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("Názov produktu je povinný"),
        "products": MessageLookupByLibrary.simpleMessage("Produkty"),
        "profile": MessageLookupByLibrary.simpleMessage("Profil"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("Upraviť profil"),
        "profit": MessageLookupByLibrary.simpleMessage("Zisk"),
        "promo": MessageLookupByLibrary.simpleMessage("promo"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Kód promo akcie"),
        "purchase": MessageLookupByLibrary.simpleMessage("Nákup"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage("Alarm nákupu"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Nákup potvrdený"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Detaily nákupu"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Faktúra za nákup"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("Zoznam nákupov"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Zakúpte teraz"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Zakúpiť prémiový plán"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("Nákupná cena"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("Nákupná cena je povinná"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("Správa o nákupoch"),
        "purchaseReports": MessageLookupByLibrary.simpleMessage("Cena nákupu"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Správy o nákupoch"),
        "purchaseReturn": MessageLookupByLibrary.simpleMessage("Návrat nákupu"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("Správa o vrátení nákupu"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Prechod na nákup"),
        "qty": MessageLookupByLibrary.simpleMessage("Množstvo"),
        "quantity": MessageLookupByLibrary.simpleMessage("Množstvo"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Nedávne transakcie"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("Dostali ste PIN"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Referenčné číslo"),
        "register": MessageLookupByLibrary.simpleMessage("Registrovať sa"),
        "registering": MessageLookupByLibrary.simpleMessage("Registrujem sa"),
        "remainingDue":
            MessageLookupByLibrary.simpleMessage("Zostávajúca suma"),
        "remove": MessageLookupByLibrary.simpleMessage("Odstrániť"),
        "reports": MessageLookupByLibrary.simpleMessage("Správy"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Žiadosť bola odoslaná"),
        "resendCode": MessageLookupByLibrary.simpleMessage("Znova zaslať kód"),
        "resendOtp":
            MessageLookupByLibrary.simpleMessage("Znovu zaslať kód OTP: "),
        "retailer": MessageLookupByLibrary.simpleMessage("Malý predajca"),
        "retur": MessageLookupByLibrary.simpleMessage("Vrátenie"),
        "returN": MessageLookupByLibrary.simpleMessage("Návrat"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("Vrátiť sumu"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("Vrátiť sumu"),
        "returnQTY":
            MessageLookupByLibrary.simpleMessage("Množstvo na vrátenie"),
        "revenue": MessageLookupByLibrary.simpleMessage("Príjmy"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Ochráňte dáta svojho podniku bez námahy. Naša aktualizácia na neobmedzené používanie Pos Saas POS obsahuje bezplatné zálohovanie dát, čím sa zabezpečí ochrana vašich cenných informácií pred nepredvídateľnými udalosťami. Zamerajte sa na to, čo je skutočne dôležité - rast vášho podniku."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Čiastka predaja"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("Detaily predaja"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Predajná cena"),
        "saleReports": MessageLookupByLibrary.simpleMessage("Správa o predaji"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Správy o predaji"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("Vrátenie predaja"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Správa o vrátení predaja"),
        "saleSetting":
            MessageLookupByLibrary.simpleMessage("Nastavenie predaja"),
        "sales": MessageLookupByLibrary.simpleMessage("Predaj"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("Správy o predaji a nákupe"),
        "salesList": MessageLookupByLibrary.simpleMessage("Zoznam predajov"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("Vrátenie predaja"),
        "save": MessageLookupByLibrary.simpleMessage("Uložiť"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Uložiť a publikovať"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("Uložiť zmeny"),
        "saving": MessageLookupByLibrary.simpleMessage("Ukladanie"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("Naskenujte QR kód produktu"),
        "search": MessageLookupByLibrary.simpleMessage("Hľadať"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Hľadať podľa kódu alebo názvu produktu"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("Zobraziť všetky promo kódy"),
        "select": MessageLookupByLibrary.simpleMessage("Vybrať"),
        "selectAProductForReturn":
            MessageLookupByLibrary.simpleMessage("Vyberte produkt na vrátenie"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Vyberte značku"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Vyberte kategóriu"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Vybrať kontakty"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("Vyberte kategóriu produktu"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("Vyberte kategóriu obchodu"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Vyberte daň"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Vyberte typ dane"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("Vyberte jednotku"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Vyberte variantu:"),
        "seller": MessageLookupByLibrary.simpleMessage("Predávajúci"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Predáva"),
        "send": MessageLookupByLibrary.simpleMessage("Poslať"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("Odoslať email"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Odoslať správu"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("Poslať odkaz na obnovenie"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Odoslať SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Poslať SMS?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Odoslať správu na WhatsApp"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Odoslať svoj email"),
        "sendingEmail":
            MessageLookupByLibrary.simpleMessage("Posielanie e-mailu"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Odosielanie správy"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Služba/Doprava"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Nastavte si svoj profil"),
        "setting": MessageLookupByLibrary.simpleMessage("Nastavenia"),
        "share": MessageLookupByLibrary.simpleMessage("Zdieľať"),
        "shopGST": MessageLookupByLibrary.simpleMessage("GST obchodu"),
        "signIn": MessageLookupByLibrary.simpleMessage("Prihlásiť sa"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("Prihlásiť sa pomocou emailu"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Podpis zákazníka"),
        "size": MessageLookupByLibrary.simpleMessage("Veľkosť"),
        "skip": MessageLookupByLibrary.simpleMessage("Preskočiť"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Sociálny marketing"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Prepáčte, nemáte oprávnenie na prístup k tejto službe"),
        "startDate": MessageLookupByLibrary.simpleMessage("Dátum začiatku"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Začať nový predaj"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage(
            "Začnite písať pre vyhľadávanie"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Buďte na čele technologických inovácií bez dodatočných nákladov. Naša aktualizácia na neobmedzené používanie systému Pos Saas POS zabezpečuje, že vždy máte k dispozícii najnovšie nástroje a funkcie, čo zaručuje, že vaša firma zostane v prednej časti."),
        "stillUnpaid":
            MessageLookupByLibrary.simpleMessage("Stále nezaplatené"),
        "stock": MessageLookupByLibrary.simpleMessage("Sklad"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Sklad je povinný"),
        "stockList": MessageLookupByLibrary.simpleMessage("Zoznam tovaru"),
        "stocks": MessageLookupByLibrary.simpleMessage("Zásoby"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Na vytvorenie Excel súboru je potrebné povolenie na úložisko"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("Zoznam poddani"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Poddaně"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Medzisúčet"),
        "submit": MessageLookupByLibrary.simpleMessage("Odoslať"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "Prihláste sa na odber\\nnašej YouTube"),
        "subscription": MessageLookupByLibrary.simpleMessage("Predplatné"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Úspešne vykonané"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Úspešne ste sa odhlásili"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Úspešne aktualizované"),
        "supplier": MessageLookupByLibrary.simpleMessage("Dodávateľ"),
        "supplierName": MessageLookupByLibrary.simpleMessage("Meno dodávateľa"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("Kód SWIFT"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Použite vodičský preukaz, občiansky preukaz alebo pasovú fotografiu"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "Vezmite si občiansky preukaz na overenie vašich údajov"),
        "tap": MessageLookupByLibrary.simpleMessage("Klepnutím"),
        "tax": MessageLookupByLibrary.simpleMessage("Daň"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Skupina daní"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("Percento dane"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Sadzba dane"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Sadzby daní - Spravujte svoje sadzby daní"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Správa o daniach"),
        "taxType": MessageLookupByLibrary.simpleMessage("Typ dane"),
        "taxes": MessageLookupByLibrary.simpleMessage("Daně"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Podmienky a pravidlá"),
        "termsOfUse":
            MessageLookupByLibrary.simpleMessage("Podmienky používania"),
        "termsPrivacy": MessageLookupByLibrary.simpleMessage(
            "Podmienky a ochrana osobných údajov"),
        "thankYOuForYourDuePayment":
            MessageLookupByLibrary.simpleMessage("Ďakujeme za Vašu platbu"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Ďakujeme"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Ďakujeme za nákup"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "Účet už existuje pre tento e-mail"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Excel súbor bol už stiahnutý"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Názov hovorí za všetko. S Pos Saas POS Unlimited neexistuje obmedzenie vašeho používania. Či už spracovávate len niekoľko transakcií alebo zažívate nápor zákazníkov, môžete prevádzkovať s istotou, že nie ste obmedzení žiadnymi limity."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "Poskytnuté heslo je príliš slabé"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Predaj bude odstránený a všetky dáta budú vymazané. Ste si istý, že chcete pokračovať v odstránení?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Predaj bude odstránený a všetky dáta budú vymazané. Ste si istý, že chcete pokračovať v odstránení?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Používateľ bude vymazaný a všetky údaje budú z vášho účtu odstránené. Ste si istí, že chcete toto vymazať?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Používateľ bude odstránený a všetky údaje budú odstránené z vášho účtu. Ste si istý, že chcete odstrániť toto?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Služby tretích strán"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Túto kategóriu nie je možné odstrániť"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Tento mesiac)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Tento produkt už bol pridaný"),
        "title": MessageLookupByLibrary.simpleMessage("Názov"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Názov nesmie byť prázdny"),
        "to": MessageLookupByLibrary.simpleMessage("do"),
        "toDate": MessageLookupByLibrary.simpleMessage("Do dátumu"),
        "today": MessageLookupByLibrary.simpleMessage("Dnes"),
        "total": MessageLookupByLibrary.simpleMessage("Celkovo"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Celková suma"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Celková vybraná suma"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Celkom k úhrade"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("Celkové výdavky"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Celková strata"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("Celková suma na úhradu"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Celková cena"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("Celkový počet produktov"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Celkový zisk"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("Celkový nákup"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Celková suma na vrátenie"),
        "totalReturns":
            MessageLookupByLibrary.simpleMessage("Celkový počet vrátení"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Celkový predaj"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Celková zásoba"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Celková hodnota"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Celková DPH"),
        "totals": MessageLookupByLibrary.simpleMessage("Celkom: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Transakcia"),
        "transactionId": MessageLookupByLibrary.simpleMessage("ID transakcie"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Skúste to znova"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Typ"),
        "unitName": MessageLookupByLibrary.simpleMessage("Názov jednotky"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Jednotková cena"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Jednotková cena"),
        "units": MessageLookupByLibrary.simpleMessage("Jednotky"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Neobmedzené"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Neobmedzené používanie"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Odomknite plný potenciál systému Pos Saas POS prostredníctvom personalizovaných školení vedených naším expertným tímom. Od základov po pokročilé techniky vás naučíme, ako využívať každý aspekt systému na optimalizáciu vašich podnikových procesov."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Nezaplatené"),
        "update": MessageLookupByLibrary.simpleMessage("Aktualizovať"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Aktualizovať kontakt"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Aktualizovať teraz"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("Aktualizovať produkt"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Najprv aktualizujte svoj plán,\\nváš limit bol prekročený"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Aktualizujte svoj profil"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Aktualizujte svoj profil pre lepšie pripojenie k vášmu doktorovi"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Aktualizujte svoj profil, aby ste mohli lepšie pripojiť zákazníka"),
        "updated": MessageLookupByLibrary.simpleMessage("Aktualizované"),
        "upload": MessageLookupByLibrary.simpleMessage("Nahrať"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Nahrať dokument"),
        "uploadDone":
            MessageLookupByLibrary.simpleMessage("Nahratie dokončené"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Nahrať súbor"),
        "upplier": MessageLookupByLibrary.simpleMessage("Dodávateľ"),
        "usbC": MessageLookupByLibrary.simpleMessage("Usb C"),
        "use": MessageLookupByLibrary.simpleMessage("Použiť"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("Použite Pos Saas"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Používanie systému"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Používateľ bol odstránený"),
        "userRole": MessageLookupByLibrary.simpleMessage("Používateľská rola"),
        "userRoleDetails": MessageLookupByLibrary.simpleMessage(
            "Podrobnosti o používateľskej roli"),
        "userTitle": MessageLookupByLibrary.simpleMessage("Názov používateľa"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Názov používateľa nemôže byť prázdny"),
        "value": MessageLookupByLibrary.simpleMessage("Hodnota"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("DPH sa neuplatňuje"),
        "verifyOtp":
            MessageLookupByLibrary.simpleMessage("Overovanie kódu OTP"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Overte telefónne číslo"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Zobraziť všetko"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("Zobraziť detaily"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Zákazník na mieste"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Sklad"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Sklad už existuje"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("Zoznam skladov"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("Názov skladu"),
        "warranty": MessageLookupByLibrary.simpleMessage("Záruka"),
        "weHaveSendAnEmailwithInstructions":
            MessageLookupByLibrary.simpleMessage(
                "Poslali sme vám e-mail s pokynmi, ako obnoviť heslo na:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Pre podporu funkcionality našej aplikácie môžeme používať služby tretích strán, ako sú poskytovatelia analýzy a platobné spracovatele. Tieto služby tretích strán môžu zbierať informácie o vás pri používaní našej aplikácie. Upozorňujeme, že nie sme zodpovední za postupy ochrany súkromia týchto služieb tretích strán."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Používame štandardné opatrenia odvetvia na ochranu vašich osobných údajov, vrátane šifrovania a bezpečného uchovávania. Prístup k vašim informáciám obmedzujeme len na oprávnený personál."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Rozumieme dôležitosti bezproblémového prevádzkovania. Preto je naša nepretržitá podpora k dispozícii na pomoc, či už ide o rýchlu otázku alebo komplexné obavy. Spojte sa s nami kedykoľvek a kdekoľvek prostredníctvom hovoru alebo WhatsApp a zažite neprekonateľnú zákaznícku službu."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Vaše osobné údaje používame na to, aby sme vám poskytli čo najlepší zážitok z našej aplikácie, vrátane personalizácie odporúčaného obsahu, pripojenia k odborníkom a zlepšenia funkčnosti našej aplikácie. Vaše údaje môžeme tiež použiť na komunikáciu s vami ohľadom aktualizácií, akcií alebo iných informácií týkajúcich sa našej aplikácie."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Preveríme platbu a schválime ju do 1-2 hodín"),
        "weekly": MessageLookupByLibrary.simpleMessage("Týždenne"),
        "weight": MessageLookupByLibrary.simpleMessage("Hmotnosť"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Čo je nové"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Veľkoobchodník"),
        "wholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Veľkoobchodná cena"),
        "wholesalePrice":
            MessageLookupByLibrary.simpleMessage("Veľkoobchodná cena"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Veľkoobchodník"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Čoskoro bude pridané"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Expirovať v"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Sem napíšte svoju správu"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("Nesprávne OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Poskytnuté nesprávne heslo pre tohto používateľa."),
        "yearly": MessageLookupByLibrary.simpleMessage("Ročne"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Áno, odstrániť navždy"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("Nie ste platný používateľ"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Používate"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Nemôžete zaplatiť viac ako je dlh"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Dostali ste e-mail"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Úspešne ste sa prihlásili do vášho účtu. Zostaňte s Pos Saas."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("Musíte udeliť povolenie"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Musíte sa znovu PRIHLÁSIŤ do vášho účtu."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Pred nákupom SMS musíte prejsť overením identity"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Vaša správa zostáva"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Vaša balíček"),
        "yourPackageWillExpireinDay":
            MessageLookupByLibrary.simpleMessage("Váš balíček vyprší o 5 dní")
      };
}
