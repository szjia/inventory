// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a ru locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'ru';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Продолжить"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("GST номер"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("Розничная цена"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("РРЦ обязательна"),
        "OK": MessageLookupByLibrary.simpleMessage("ОК"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Телефон"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("СЛ"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT код"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Закуски"),
        "TAX": MessageLookupByLibrary.simpleMessage("НАЛОГ"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Загрузка"),
        "UserTitle":
            MessageLookupByLibrary.simpleMessage("Заголовок пользователя"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Ваш пакет истекает сегодня\n\nПожалуйста, приобретите его снова"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) Система предоставляется исключительно с целью облегчения торговли и связанных с ней операций в вашем бизнесе."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) Для использования Системы вам может потребоваться создать учетную запись. Вы соглашаетесь предоставлять точные, актуальные и полные сведения в процессе регистрации и обновлять такие сведения, чтобы они оставались точными и полными."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("О приложении"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("О нас"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Принятие условий"),
        "accountName": MessageLookupByLibrary.simpleMessage("Название счета"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("Номер счета"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Регистрация учетной записи"),
        "acton": MessageLookupByLibrary.simpleMessage("Действие"),
        "add": MessageLookupByLibrary.simpleMessage("Добавить"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Добавить бренд"),
        "addCategory":
            MessageLookupByLibrary.simpleMessage("Добавить категорию"),
        "addContact": MessageLookupByLibrary.simpleMessage("Добавить контакт"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Добавить клиента"),
        "addDelivery":
            MessageLookupByLibrary.simpleMessage("Добавить доставку"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Добавить описание"),
        "addDescription":
            MessageLookupByLibrary.simpleMessage("Добавить заметку"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Добавить скидку"),
        "addDocumentId": MessageLookupByLibrary.simpleMessage(
            "Добавить идентификатор документа"),
        "addDucument":
            MessageLookupByLibrary.simpleMessage("Добавить документ"),
        "addExpense": MessageLookupByLibrary.simpleMessage("Добавить расход"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Добавить категорию расходов"),
        "addItems": MessageLookupByLibrary.simpleMessage("Добавить товары"),
        "addNew": MessageLookupByLibrary.simpleMessage("Добавить новый"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Добавить новый адрес"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Добавить новый продукт"),
        "addNewTax":
            MessageLookupByLibrary.simpleMessage("Добавить новый налог"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Добавить новый налог с одним/несколькими типами налогов"),
        "addNote": MessageLookupByLibrary.simpleMessage("Добавить заметку"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Сначала добавьте продукт"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Добавить промокод"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Добавить покупку"),
        "addSales": MessageLookupByLibrary.simpleMessage("Добавить продажу"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Успешно добавлено"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Добавить единицу"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Добавить роль пользователя"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Успешно добавлено"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("Добавлено в корзину"),
        "address": MessageLookupByLibrary.simpleMessage("Адрес"),
        "admin": MessageLookupByLibrary.simpleMessage("Админ"),
        "all": MessageLookupByLibrary.simpleMessage("Все"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("Все бизнес-решения"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("Уже добавлено"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Уже существует"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Уже есть аккаунт"),
        "amount": MessageLookupByLibrary.simpleMessage("Сумма"),
        "anEmailHasBeenSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "На электронную почту отправлено письмо. Проверьте свой почтовый ящик."),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Поддержка приложений Android и iOS"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Применимый налог"),
        "apply": MessageLookupByLibrary.simpleMessage("Применить"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Вы уверены, что хотите удалить этот счет?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Вы уверены, что хотите удалить эту продажу?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Вы уверены, что хотите удалить этого пользователя?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Вы уверены, что хотите удалить этот налог?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Вы уверены, что хотите удалить эту группу налогов?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Вы хотите удалить этот склад?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Вы уверены, что хотите удалить этого пользователя?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Уполномоченная подпись"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Вы несете ответственность за обеспечение конфиденциальности вашей учетной записи и пароля и ограничение доступа к вашей учетной записи. Вы несете ответственность за все действия, совершаемые в рамках вашей учетной записи."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Вам должно быть как минимум 18 лет или совершеннолетие по закону вашей юрисдикции для использования Системы."),
        "backSide": MessageLookupByLibrary.simpleMessage("Обратная сторона"),
        "backToHome":
            MessageLookupByLibrary.simpleMessage("Вернуться на главную"),
        "balance": MessageLookupByLibrary.simpleMessage("Баланс"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Бангладеш"),
        "bank": MessageLookupByLibrary.simpleMessage("Банк"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Валюта банковского счета"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Валюта банковского счета"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Банковская информация"),
        "bankName": MessageLookupByLibrary.simpleMessage("Название банка"),
        "bankTransfer":
            MessageLookupByLibrary.simpleMessage("Банковский перевод"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Штрих-код найден"),
        "billInvoice":
            MessageLookupByLibrary.simpleMessage("Счет/Счет-фактура"),
        "billTo": MessageLookupByLibrary.simpleMessage("Счет на оплату"),
        "branchName":
            MessageLookupByLibrary.simpleMessage("Название отделения"),
        "brand": MessageLookupByLibrary.simpleMessage("Бренд"),
        "brandName": MessageLookupByLibrary.simpleMessage("Название бренда"),
        "bulkUpload":
            MessageLookupByLibrary.simpleMessage("Массовая \nЗагрузка"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Категория бизнеса"),
        "buy": MessageLookupByLibrary.simpleMessage("Купить"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Купить премиум-план"),
        "buySms": MessageLookupByLibrary.simpleMessage("Купить SMS"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Путем доступа или использования Системы точки продаж (POS) (далее - \"Система\"), предоставленной [Название вашей компании] (\"Компания\"), вы соглашаетесь быть связанными этими Правилами использования. Если вы не согласны с этими Правилами использования, не используйте Систему."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Вы несете ответственность за обеспечение соблюдения ваших действий в рамках доступа и использования Системы всех применимых законов и нормативных актов."),
        "call": MessageLookupByLibrary.simpleMessage("Позвонить"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "Позвоните для экстренной поддержки"),
        "camera": MessageLookupByLibrary.simpleMessage("Камера"),
        "cancel": MessageLookupByLibrary.simpleMessage("Отмена"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Отменить все продукты"),
        "capacity": MessageLookupByLibrary.simpleMessage("Вместимость"),
        "card": MessageLookupByLibrary.simpleMessage("Карта"),
        "cash": MessageLookupByLibrary.simpleMessage("Наличные"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Категории"),
        "category": MessageLookupByLibrary.simpleMessage("Категория"),
        "categoryName":
            MessageLookupByLibrary.simpleMessage("Название категории"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "Название категории уже существует"),
        "cateogryName":
            MessageLookupByLibrary.simpleMessage("Название категории"),
        "change": MessageLookupByLibrary.simpleMessage("Изменить?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Изменить пароль"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("Проверьте почту"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Выберите клиента"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Выберите поставщика"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Выберите свои функции"),
        "clarence": MessageLookupByLibrary.simpleMessage("Кларенс"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Нажмите, чтобы подключиться"),
        "close": MessageLookupByLibrary.simpleMessage("Закрыть"),
        "color": MessageLookupByLibrary.simpleMessage("Цвет"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(Комбинация нескольких налогов)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Скоро"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Адрес компании"),
        "companyAndShopName": MessageLookupByLibrary.simpleMessage(
            "Название компании и магазина"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("Название компании и бизнеса"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Завершить транзакцию"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Подтвердите пароль"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Подтвердите возврат"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Поздравляем"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Свяжитесь с нами"),
        "continu": MessageLookupByLibrary.simpleMessage("Продолжить"),
        "country": MessageLookupByLibrary.simpleMessage("Страна"),
        "create": MessageLookupByLibrary.simpleMessage("Создать"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Создать бесплатный аккаунт"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Создано и сохранено"),
        "currency": MessageLookupByLibrary.simpleMessage("Валюта"),
        "currentStock": MessageLookupByLibrary.simpleMessage("Текущие запасы"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("Настройка маркировки счетов"),
        "customer": MessageLookupByLibrary.simpleMessage("Клиент"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Данные клиента"),
        "customerGST": MessageLookupByLibrary.simpleMessage("GST клиента"),
        "customerName": MessageLookupByLibrary.simpleMessage("Имя клиента"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Ежедневная транзакция"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Обзор панели управления"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Данные успешно сохранены"),
        "date": MessageLookupByLibrary.simpleMessage("Дата"),
        "day": MessageLookupByLibrary.simpleMessage("День"),
        "dealer": MessageLookupByLibrary.simpleMessage("Дилер"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("Цена для дилеров"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("Процент НДС по умолчанию"),
        "delete": MessageLookupByLibrary.simpleMessage("Удалить"),
        "deleting": MessageLookupByLibrary.simpleMessage("Удаление"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Адрес доставки"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Адреса доставки"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Стоимость доставки"),
        "describtion": MessageLookupByLibrary.simpleMessage("Описание"),
        "description": MessageLookupByLibrary.simpleMessage("Описание"),
        "descriptionCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Описание не может быть пустым"),
        "details": MessageLookupByLibrary.simpleMessage("Детали"),
        "discount": MessageLookupByLibrary.simpleMessage("Скидка"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Не беспокоить"),
        "done": MessageLookupByLibrary.simpleMessage("Готово"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Скачать формат Excel"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Успешно загружено в папку загрузок"),
        "due": MessageLookupByLibrary.simpleMessage("Долг"),
        "dueAmount":
            MessageLookupByLibrary.simpleMessage("Сумма задолженности: "),
        "dueCollection":
            MessageLookupByLibrary.simpleMessage("Сбор задолженностей"),
        "dueCollectionReports": MessageLookupByLibrary.simpleMessage(
            "Отчеты о задолженных платежах"),
        "dueList":
            MessageLookupByLibrary.simpleMessage("Список задолженностей"),
        "dueReports":
            MessageLookupByLibrary.simpleMessage("Отчет о задолженностях"),
        "duration": MessageLookupByLibrary.simpleMessage("Длительность"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Период: С"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "Простое использование мобильной POS-системы"),
        "edit": MessageLookupByLibrary.simpleMessage("Изменить"),
        "editPurchaseInvoice": MessageLookupByLibrary.simpleMessage(
            "Редактировать счет на покупку"),
        "editSalesInvoice": MessageLookupByLibrary.simpleMessage(
            "Редактировать счет на продажу"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Изменить социальные медиа"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Успешное редактирование"),
        "editTax": MessageLookupByLibrary.simpleMessage("Редактировать налог"),
        "editTaxGroup": MessageLookupByLibrary.simpleMessage(
            "Редактировать группу налогов"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("Редактировать склад"),
        "email": MessageLookupByLibrary.simpleMessage("Электронная почта"),
        "emailAddress":
            MessageLookupByLibrary.simpleMessage("Адрес электронной почты"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Email не может быть пустым"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "Электронная почта отправлена! Проверьте ваш почтовый ящик"),
        "endDate": MessageLookupByLibrary.simpleMessage("Дата окончания"),
        "enterAValidAmount": MessageLookupByLibrary.simpleMessage(
            "Введите действительную сумму"),
        "enterAValidDiscount": MessageLookupByLibrary.simpleMessage(
            "Введите действительную скидку"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Введите действительный номер телефона"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Введите действительную цену"),
        "enterAValidQuantity": MessageLookupByLibrary.simpleMessage(
            "Введите действительное количество"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("Введите адрес"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("Введите сумму."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Введите название бренда"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Введите вместимость"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Введите название категории"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Введите цвет"),
        "enterCustomerGstNumber":
            MessageLookupByLibrary.simpleMessage("Введите GST номер клиента"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Введите цену для дилеров"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Введите описание"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("Введите скидку."),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("Введите дату расхода"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Введите полный адрес"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Введите номер счета"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Введите количество для оповещения о низком запасе"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Введите производителя"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("Введите текст сообщения"),
        "enterMrpOrRetailerPirce":
            MessageLookupByLibrary.simpleMessage("Введите розничную цену"),
        "enterName": MessageLookupByLibrary.simpleMessage("Введите имя"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Введите заметку"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Введите имя участника"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Введите номер телефона"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Введите код продукта или отсканируйте"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Введите название продукта"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Введите цену закупки."),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("Введите номер счета"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Введите размер"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("Введите запасы."),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Введите налоговую ставку"),
        "enterTransactionId": MessageLookupByLibrary.simpleMessage(
            "Введите идентификатор транзакции"),
        "enterType": MessageLookupByLibrary.simpleMessage("Введите тип"),
        "enterUserTitle": MessageLookupByLibrary.simpleMessage(
            "Введите заголовок пользователя"),
        "enterValidAmount": MessageLookupByLibrary.simpleMessage(
            "Введите действительную сумму"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Введите название склада"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Введите вес"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Введите оптовую цену"),
        "enterYourDescriptionHere":
            MessageLookupByLibrary.simpleMessage("Введите ваше описание здесь"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "Введите ваш адрес электронной почты"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "Введите заголовок обратной связи"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Введите ваш GST номер"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("Введите ваш мобильный номер"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Введите ваше имя"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("Введите ваш номер телефона"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Введите ваш пароль"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Введите ваш номер телефона"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "Введите идентификатор вашей транзакции"),
        "error": MessageLookupByLibrary.simpleMessage("Ошибка"),
        "excTax": MessageLookupByLibrary.simpleMessage("Без НДС"),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("Загрузчик Excel"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Исключительно"),
        "expense": MessageLookupByLibrary.simpleMessage("Расходы"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Категория расходов"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("Дата расхода"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Расход для"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Отчет о расходах"),
        "expireDate": MessageLookupByLibrary.simpleMessage("Дата окончания"),
        "expired": MessageLookupByLibrary.simpleMessage("Истек"),
        "expiring": MessageLookupByLibrary.simpleMessage("Истекает"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Не удалось с ошибкой"),
        "fashion": MessageLookupByLibrary.simpleMessage("Мода"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Функции являются важной частью, которая делает Pos Saas отличной от традиционных решений."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Обратная связь"),
        "firstName": MessageLookupByLibrary.simpleMessage("Имя"),
        "followUsOnFacebook": MessageLookupByLibrary.simpleMessage(
            "Подписывайтесь на нас в Facebook"),
        "followUsOnTwitter": MessageLookupByLibrary.simpleMessage(
            "Подписывайтесь на нас в Twitter"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Лицевая сторона"),
        "forUnlimitedUses": MessageLookupByLibrary.simpleMessage(
            "Для неограниченного использования"),
        "forgotPassword": MessageLookupByLibrary.simpleMessage("Забыли пароль"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Забыли пароль?"),
        "formDate": MessageLookupByLibrary.simpleMessage("С даты"),
        "freeDataBackup": MessageLookupByLibrary.simpleMessage(
            "Бесплатное резервное копирование данных"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "Бесплатное пожизненное обновление"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Бесплатный пакет"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Бесплатный план"),
        "from": MessageLookupByLibrary.simpleMessage("(От"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Полностью оплачено"),
        "gallary": MessageLookupByLibrary.simpleMessage("Галерея"),
        "generatingPDF": MessageLookupByLibrary.simpleMessage("Генерация PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Получить ОТП"),
        "govermentId":
            MessageLookupByLibrary.simpleMessage("Удостоверение личности"),
        "guest": MessageLookupByLibrary.simpleMessage("Гость"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("У вас нет аккаунта?"),
        "history": MessageLookupByLibrary.simpleMessage("История"),
        "home": MessageLookupByLibrary.simpleMessage("Главная"),
        "howWeProtectYourInformation":
            MessageLookupByLibrary.simpleMessage("Как мы защищаем ваши данные"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Как мы используем ваши данные"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Проверка личности"),
        "image": MessageLookupByLibrary.simpleMessage("Изображение"),
        "inHouseCantBeDelete": MessageLookupByLibrary.simpleMessage(
            "Внутренний не может быть удален"),
        "inHouseCantBeEdited": MessageLookupByLibrary.simpleMessage(
            "Внутренний не может быть отредактирован"),
        "inWord": MessageLookupByLibrary.simpleMessage("В словах"),
        "incTax": MessageLookupByLibrary.simpleMessage("С НДС"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Включительно"),
        "increaseStock":
            MessageLookupByLibrary.simpleMessage("Увеличить запас"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Инструмент"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("Номер счета"),
        "invoice": MessageLookupByLibrary.simpleMessage("Счет"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("Номер счета"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Настройки счета"),
        "invoiceViewer": MessageLookupByLibrary.simpleMessage("Просмотр счета"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Товар добавлен"),
        "kg": MessageLookupByLibrary.simpleMessage("кг"),
        "kycVerification": MessageLookupByLibrary.simpleMessage("Проверка KYC"),
        "language": MessageLookupByLibrary.simpleMessage("Язык"),
        "lastName": MessageLookupByLibrary.simpleMessage("Фамилия"),
        "ledger": MessageLookupByLibrary.simpleMessage("Журнал"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Пожизненная покупка"),
        "link": MessageLookupByLibrary.simpleMessage("Ссылка"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport": MessageLookupByLibrary.simpleMessage(
            "Поддержка в режиме реального времени"),
        "loading": MessageLookupByLibrary.simpleMessage("Загрузка"),
        "logIn": MessageLookupByLibrary.simpleMessage("Войти"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Выйти"),
        "logOut": MessageLookupByLibrary.simpleMessage("Выйти"),
        "login": MessageLookupByLibrary.simpleMessage("Войти"),
        "logo": MessageLookupByLibrary.simpleMessage("Логотип"),
        "loss": MessageLookupByLibrary.simpleMessage("Убыток"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Убыток/Прибыль"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Детали убытка/прибыли"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Отчет о прибыли и убытках"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Отчеты о прибыли и убытках"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Оповещение о низком запасе"),
        "maan": MessageLookupByLibrary.simpleMessage("Маан"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Произведите неизгладимое впечатление на ваших клиентов с помощью брендированных счетов. Наше неограниченное обновление предоставляет уникальное преимущество настройки счетов, добавляя профессиональное качество, которое укрепляет вашу корпоративную идентичность и способствует лояльности клиентов."),
        "manageYourBussinessWith": MessageLookupByLibrary.simpleMessage(
            "Управляйте своим бизнесом с помощью"),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Дата производства"),
        "margin": MessageLookupByLibrary.simpleMessage("Маржа"),
        "masterCard": MessageLookupByLibrary.simpleMessage("MasterCard"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Производитель"),
        "message": MessageLookupByLibrary.simpleMessage("Сообщение"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("История сообщений"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Приложение Pos Saas бесплатно и просто в использовании. Фактически, это одна из лучших POS-систем во всем мире."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas - это полное бизнес-решение с учетом товаров, учетом, продажами, расходами и прибылью/убытками."),
        "mobile": MessageLookupByLibrary.simpleMessage("Мобильный"),
        "mobilePayment":
            MessageLookupByLibrary.simpleMessage("Мобильный платеж"),
        "monthly": MessageLookupByLibrary.simpleMessage("Ежемесячно"),
        "moreInfo":
            MessageLookupByLibrary.simpleMessage("Дополнительная информация"),
        "name": MessageLookupByLibrary.simpleMessage("Введите ваше имя."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Имя уже существует"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("Имя не может быть пустым"),
        "next": MessageLookupByLibrary.simpleMessage("Далее"),
        "noConnection": MessageLookupByLibrary.simpleMessage("Нет соединения"),
        "noData": MessageLookupByLibrary.simpleMessage("Нет данных"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Нет доступных данных"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Данные не найдены"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("История не найдена!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Продукт не найден"),
        "noSubTaxSelected":
            MessageLookupByLibrary.simpleMessage("Не выбран ни один подналог"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("Транзакции не найдены!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Пользователь с таким адресом не найден."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "Роль пользователя не найдена"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Неактивный пользователь"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Не предоставлено"),
        "note": MessageLookupByLibrary.simpleMessage("Заметка"),
        "notes": MessageLookupByLibrary.simpleMessage("Заметки"),
        "notification": MessageLookupByLibrary.simpleMessage("Уведомление"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP отправлен на"),
        "office": MessageLookupByLibrary.simpleMessage("Офис"),
        "ok": MessageLookupByLibrary.simpleMessage("OK"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS, который содержит множество функций, включая отслеживание продаж и управление инвентарем."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Эта система помогает вам улучшить ваши операции для ваших клиентов."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Наша POS-система должна автоматически упростить повседневные операции, облегчая навигацию."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("Начальный баланс"),
        "order": MessageLookupByLibrary.simpleMessage("Заказы"),
        "other": MessageLookupByLibrary.simpleMessage("Другое"),
        "otp": MessageLookupByLibrary.simpleMessage("Закрыть"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Нет в наличии"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Пакет"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Особенности пакета"),
        "paid": MessageLookupByLibrary.simpleMessage("Оплачено"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Уплаченная сумма"),
        "parties": MessageLookupByLibrary.simpleMessage("Участники"),
        "partiesList":
            MessageLookupByLibrary.simpleMessage("Список участников"),
        "partyGST": MessageLookupByLibrary.simpleMessage("GST стороны"),
        "partyName": MessageLookupByLibrary.simpleMessage("Имя участника"),
        "password": MessageLookupByLibrary.simpleMessage("Пароль"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Пароль и подтверждение пароля не совпадают"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Пароль не может быть пустым"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("Пароль не совпадает"),
        "payCash": MessageLookupByLibrary.simpleMessage("Оплатить наличными"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("Оплатить через bkash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Оплатить через Paypal"),
        "payeeName": MessageLookupByLibrary.simpleMessage("Имя получателя"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("Номер получателя"),
        "payment": MessageLookupByLibrary.simpleMessage("Оплата"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("Сумма оплаты"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Оплата завершена"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Инструкции по оплате:"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("Метод оплаты"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Тип оплаты"),
        "pdfView": MessageLookupByLibrary.simpleMessage("Просмотр PDF"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Личная информация"),
        "phone": MessageLookupByLibrary.simpleMessage("Телефон"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Номер телефона"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Номер телефона уже используется"),
        "phoneNumberIsNotValid": MessageLookupByLibrary.simpleMessage(
            "Номер телефона недействителен"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("Номер телефона обязателен"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("Выберите и загрузите файл"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("Выберите дату окончания"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Выберите дату начала"),
        "plan": MessageLookupByLibrary.simpleMessage("План"),
        "pleaseAddQuantity": MessageLookupByLibrary.simpleMessage(
            "Пожалуйста, добавьте количество"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Пожалуйста, проверьте подключение к интернету"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Пожалуйста, сначала подключите принтер"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Пожалуйста, подключите ваш Bluetooth-принтер"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Пожалуйста, введите более длинный пароль"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Пожалуйста, введите подтверждение пароля"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("Пожалуйста, введите пароль"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Пожалуйста, введите действительный email"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Пожалуйста, введите имя"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("Пожалуйста, введите пароль"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Пожалуйста, введите ваш адрес электронной почты ниже, чтобы получить ссылку для сброса пароля."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Пожалуйста, введите номер транзакции"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("Пожалуйста, введите сумму"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Пожалуйста, сначала выберите категорию"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("Пожалуйста, выберите план"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Пожалуйста, выберите категорию бизнеса"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Пожалуйста, используйте действительный код покупки для использования приложения"),
        "powerdedByMobiPos": MessageLookupByLibrary.simpleMessage(
            "Работает на платформе Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("С поддержкой"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Премиум поддержка клиентов"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Премиум план"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("Предыдущие суммы оплаты"),
        "price": MessageLookupByLibrary.simpleMessage("Цена"),
        "print": MessageLookupByLibrary.simpleMessage("Печать"),
        "printingOption": MessageLookupByLibrary.simpleMessage("Опции печати"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Политика конфиденциальности"),
        "product": MessageLookupByLibrary.simpleMessage("Продукт"),
        "productCode": MessageLookupByLibrary.simpleMessage("Код продукта"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("Код продукта обязателен"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Код/Название продукта"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Описание продукта"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Детали продукта"),
        "productList": MessageLookupByLibrary.simpleMessage("Список продуктов"),
        "productName":
            MessageLookupByLibrary.simpleMessage("Название продукта"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Название продукта уже существует на этом складе"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Название продукта уже добавлено"),
        "productNameIsRequired": MessageLookupByLibrary.simpleMessage(
            "Название продукта обязательно"),
        "products": MessageLookupByLibrary.simpleMessage("Продукты"),
        "profile": MessageLookupByLibrary.simpleMessage("Профиль"),
        "profileEdit":
            MessageLookupByLibrary.simpleMessage("Редактировать профиль"),
        "profit": MessageLookupByLibrary.simpleMessage("Прибыль"),
        "promo": MessageLookupByLibrary.simpleMessage("Промо"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Промо-код"),
        "purchase": MessageLookupByLibrary.simpleMessage("Покупка"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("Сигнал о покупке"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Покупка подтверждена"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Детали покупки"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Счет-фактура покупки"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("Список покупок"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Купить сейчас"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Приобрести премиум-план"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("Цена закупки"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("Цена покупки обязательна"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("Отчет о покупках"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Отчет о покупках"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Отчеты о покупках"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("Возврат покупки"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("Отчет о возврате покупки"),
        "purchaseTransition": MessageLookupByLibrary.simpleMessage("Покупка"),
        "qty": MessageLookupByLibrary.simpleMessage("Кол-во"),
        "quantity": MessageLookupByLibrary.simpleMessage("Количество"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Последние транзакции"),
        "recivedThePin":
            MessageLookupByLibrary.simpleMessage("Получен пин-код"),
        "referenceNumber": MessageLookupByLibrary.simpleMessage("Номер счета"),
        "register": MessageLookupByLibrary.simpleMessage("Зарегистрироваться"),
        "registering": MessageLookupByLibrary.simpleMessage("Регистрация"),
        "remainingDue":
            MessageLookupByLibrary.simpleMessage("Остаток задолженности"),
        "remove": MessageLookupByLibrary.simpleMessage("Удалить"),
        "reports": MessageLookupByLibrary.simpleMessage("Отчеты"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Запрос отправлен"),
        "resendCode":
            MessageLookupByLibrary.simpleMessage("Повторно отправить код"),
        "resendOtp":
            MessageLookupByLibrary.simpleMessage("Повторная отправка ОТП: "),
        "retailer": MessageLookupByLibrary.simpleMessage("Розничный продавец"),
        "retur": MessageLookupByLibrary.simpleMessage("Возврат"),
        "returN": MessageLookupByLibrary.simpleMessage("Возврат"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("Сумма возврата"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("Сумма возврата"),
        "returnQTY":
            MessageLookupByLibrary.simpleMessage("Количество возврата"),
        "revenue": MessageLookupByLibrary.simpleMessage("Доход"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Защитите данные вашего бизнеса без лишних усилий. Наше бесплатное резервное копирование данных включает в себя обеспечение безопасности ваших ценных данных от непредвиденных событий. Сосредоточьтесь на том, что по-настоящему важно - на росте вашего бизнеса."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Сумма продажи"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("Детали продажи"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Цена продажи"),
        "saleReports": MessageLookupByLibrary.simpleMessage("Отчет о продажах"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Отчеты о продажах"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("Возврат продажи"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Отчет о возврате продаж"),
        "saleSetting": MessageLookupByLibrary.simpleMessage("Настройки продаж"),
        "sales": MessageLookupByLibrary.simpleMessage("Продажи"),
        "salesAndPurchaseReports": MessageLookupByLibrary.simpleMessage(
            "Отчеты о продажах и закупках"),
        "salesList": MessageLookupByLibrary.simpleMessage("Список продаж"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("Возврат продаж"),
        "save": MessageLookupByLibrary.simpleMessage("Сохранить"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Сохранить и опубликовать"),
        "saveChanges":
            MessageLookupByLibrary.simpleMessage("Сохранить изменения"),
        "saving": MessageLookupByLibrary.simpleMessage("Сохранение"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("Сканируйте QR-код продукта"),
        "search": MessageLookupByLibrary.simpleMessage("Поиск"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Поиск по коду или названию продукта"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("Просмотреть все промокоды"),
        "select": MessageLookupByLibrary.simpleMessage("Выбрать"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Выберите продукт для возврата"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Выберите бренд"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Выберите категорию"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Выберите контакты"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("Выберите категорию продукта"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("Выберите категорию магазина"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Выберите налог"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Выберите тип налога"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("Выберите единицу"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Выберите вариацию:"),
        "seller": MessageLookupByLibrary.simpleMessage("Продавец"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Продается"),
        "send": MessageLookupByLibrary.simpleMessage("Отправить"),
        "sendEmail": MessageLookupByLibrary.simpleMessage(
            "Отправить электронное письмо"),
        "sendMessage":
            MessageLookupByLibrary.simpleMessage("Отправить сообщение"),
        "sendResetLink":
            MessageLookupByLibrary.simpleMessage("Отправить ссылку для сброса"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Отправить СМС"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Отправить СМС?"),
        "sendWhatsappMessage": MessageLookupByLibrary.simpleMessage(
            "Отправить сообщение в WhatsApp"),
        "sendYOurEmail": MessageLookupByLibrary.simpleMessage(
            "Отправьте вашу электронную почту"),
        "sendingEmail":
            MessageLookupByLibrary.simpleMessage("Отправка электронной почты"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Отправка сообщения"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Служба/Доставка"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Настройте ваш профиль"),
        "setting": MessageLookupByLibrary.simpleMessage("Настройки"),
        "share": MessageLookupByLibrary.simpleMessage("Поделиться"),
        "shopGST": MessageLookupByLibrary.simpleMessage("GST магазина"),
        "signIn": MessageLookupByLibrary.simpleMessage("Войти"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("Войти с помощью email"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Подпись клиента"),
        "size": MessageLookupByLibrary.simpleMessage("Размер"),
        "skip": MessageLookupByLibrary.simpleMessage("Пропустить"),
        "sms": MessageLookupByLibrary.simpleMessage("СМС"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Социальный маркетинг"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Извините, у вас нет разрешения на доступ к этой услуге"),
        "startDate": MessageLookupByLibrary.simpleMessage("Дата начала"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Начать новую продажу"),
        "startTypingToSearch":
            MessageLookupByLibrary.simpleMessage("Начните вводить для поиска"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Оставайтесь на переднем крае технологических достижений без дополнительных затрат. Наше бесплатное обновление Pos Saas POS гарантирует, что у вас всегда есть доступ к последним инструментам и функциям, обеспечивая актуальность вашего бизнеса."),
        "stillUnpaid":
            MessageLookupByLibrary.simpleMessage("Все еще неоплачено"),
        "stock": MessageLookupByLibrary.simpleMessage("Запас"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Запас обязателен"),
        "stockList": MessageLookupByLibrary.simpleMessage("Список товаров"),
        "stocks": MessageLookupByLibrary.simpleMessage("Запасы"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Требуется разрешение на хранилище для создания файла Excel"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("Список подналогов"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Подналоги"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Итого"),
        "submit": MessageLookupByLibrary.simpleMessage("Подтвердить"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "Подписывайтесь на наш YouTube"),
        "subscription": MessageLookupByLibrary.simpleMessage("Подписка"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Успешно выполнено"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Успешно вышли из системы"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Успешно обновлено"),
        "supplier": MessageLookupByLibrary.simpleMessage("Поставщик"),
        "supplierName": MessageLookupByLibrary.simpleMessage("Имя поставщика"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("Код SWIFT"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Возьмите с собой водительское удостоверение, удостоверение личности или паспорт"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "Возьмите удостоверение личности для проверки ваших данных"),
        "tap": MessageLookupByLibrary.simpleMessage("Нажмите"),
        "tax": MessageLookupByLibrary.simpleMessage("Налог"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Налоговая группа"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("Процент налога"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Налоговая ставка"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Налоговые ставки - управляйте своими налоговыми ставками"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Налоговый отчет"),
        "taxType": MessageLookupByLibrary.simpleMessage("Тип налога"),
        "taxes": MessageLookupByLibrary.simpleMessage("Налоги"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Условия и положения"),
        "termsOfUse":
            MessageLookupByLibrary.simpleMessage("Условия использования"),
        "termsPrivacy": MessageLookupByLibrary.simpleMessage(
            "Условия и конфиденциальность"),
        "thankYOuForYourDuePayment":
            MessageLookupByLibrary.simpleMessage("Спасибо за вашу оплату"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Спасибо"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Спасибо за вашу покупку"),
        "theAccountAlreadyExistsForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Учетная запись уже существует для этого адреса электронной почты"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage("Файл Excel уже был загружен"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Название говорит само за себя. С Pos Saas POS Unlimited у вас нет ограничений в использовании. Независимо от того, обрабатываете ли вы небольшое количество транзакций или сталкиваетесь с резким увеличением клиентов, вы можете работать с уверенностью, зная, что вас не ограничивают никакие рамки."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "Предоставленный пароль слишком слабый"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Продажа будет удалена, и все данные об этой покупке будут удалены. Вы уверены, что хотите удалить это?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Продажа будет удалена, и все данные об этой продаже будут удалены. Вы уверены, что хотите удалить это?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Пользователь будет удален, и все данные будут удалены из вашего аккаунта. Вы уверены, что хотите удалить это?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Пользователь будет удален, и все данные будут удалены из вашего аккаунта. Вы уверены, что хотите удалить это?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Услуги третьих сторон"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Эту категорию нельзя удалить"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Этот месяц)"),
        "thisProductAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("Этот продукт уже добавлен"),
        "title": MessageLookupByLibrary.simpleMessage("Заголовок"),
        "titleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Заголовок не может быть пустым"),
        "to": MessageLookupByLibrary.simpleMessage("до"),
        "toDate": MessageLookupByLibrary.simpleMessage("По дату"),
        "today": MessageLookupByLibrary.simpleMessage("Сегодня"),
        "total": MessageLookupByLibrary.simpleMessage("Всего"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Общая сумма"),
        "totalCollected": MessageLookupByLibrary.simpleMessage("Всего собрано"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Всего задолженности"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("Общий расход"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Общий убыток"),
        "totalPayable": MessageLookupByLibrary.simpleMessage("Всего к оплате"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Итоговая цена"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("Всего продуктов"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Общая прибыль"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("Общая покупка"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Общая сумма возврата"),
        "totalReturns":
            MessageLookupByLibrary.simpleMessage("Общее количество возвратов"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Общая продажа"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Общие запасы"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Общая стоимость"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Итого НДС"),
        "totals": MessageLookupByLibrary.simpleMessage("Итого: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Транзакция"),
        "transactionId":
            MessageLookupByLibrary.simpleMessage("Идентификатор транзакции"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Попробуйте снова"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Тип"),
        "unitName": MessageLookupByLibrary.simpleMessage("Название единицы"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Цена за единицу"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Цена за единицу"),
        "units": MessageLookupByLibrary.simpleMessage("Единицы"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Неограниченно"),
        "unlimitedUsage": MessageLookupByLibrary.simpleMessage(
            "Неограниченное использование"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Разблокируйте полный потенциал Pos Saas POS с персонализированными тренировочными сессиями, проводимыми нашей командой экспертов. Мы обучим вас от основ до продвинутых техник, чтобы вы могли оптимизировать свои бизнес-процессы."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Неоплачено"),
        "update": MessageLookupByLibrary.simpleMessage("Обновить"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Обновить контакт"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Обновить сейчас"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("Обновить продукт"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Сначала обновите свой план,\\nваш лимит исчерпан"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Обновите свой профиль"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Обновите свой профиль, чтобы связать вас с врачом с лучшим впечатлением"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Обновите свой профиль для лучшей связи с вашими клиентами"),
        "updated": MessageLookupByLibrary.simpleMessage("Обновлено"),
        "upload": MessageLookupByLibrary.simpleMessage("Загрузить"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Загрузить документ"),
        "uploadDone":
            MessageLookupByLibrary.simpleMessage("Загрузка завершена"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Загрузить файл"),
        "usbC": MessageLookupByLibrary.simpleMessage("USB C"),
        "use": MessageLookupByLibrary.simpleMessage("Использовать"),
        "useMobiPos":
            MessageLookupByLibrary.simpleMessage("Используйте Pos Saas"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Использование системы"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Пользователь удален"),
        "userRole": MessageLookupByLibrary.simpleMessage("Роль пользователя"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("Детали роли пользователя"),
        "userTitle":
            MessageLookupByLibrary.simpleMessage("Заголовок пользователя"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Название пользователя не может быть пустым"),
        "value": MessageLookupByLibrary.simpleMessage("Стоимость"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("НДС не применяется"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("Проверка ОТП"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Подтвердите номер телефона"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Посмотреть все"),
        "viewDetails":
            MessageLookupByLibrary.simpleMessage("Просмотреть детали"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Покупатель без записи"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Склад"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Склад уже существует"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("Список складов"),
        "warehouseName":
            MessageLookupByLibrary.simpleMessage("Название склада"),
        "warranty": MessageLookupByLibrary.simpleMessage("Гарантия"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Мы отправили вам электронное письмо с инструкциями по сбросу пароля:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Мы можем использовать услуги третьих сторон для поддержки функциональности нашего приложения, такие как поставщики аналитики и платежные обработчики. Эти услуги третьих сторон могут собирать информацию о вас при использовании нашего приложения. Обратите внимание, что мы не несем ответственности за практику конфиденциальности этих услуг третьих сторон."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Мы применяем стандартные меры безопасности отрасли для защиты ваших персональных данных, включая шифрование и безопасное хранение. Мы также ограничиваем доступ к вашей информации только для уполномоченного персонала."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Мы понимаем важность бесперебойной работы. Поэтому наша круглосуточная поддержка доступна, чтобы помочь вам независимо от того, является ли ваш запрос быстрым или касается сложных проблем. Свяжитесь с нами в любое время и в любом месте по телефону или WhatsApp, чтобы ощутить непревзойденное обслуживание клиентов."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Мы используем ваши персональные данные, чтобы предоставить вам наилучший опыт использования нашего приложения, включая персонализацию рекомендаций контента, подключение вас к экспертам и улучшение функциональности нашего приложения. Мы также можем использовать ваши данные для связи с вами относительно обновлений, акций или другой информации, связанной с нашим приложением."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Мы рассмотрим платеж и одобрим его в течение 1-2 часов"),
        "weekly": MessageLookupByLibrary.simpleMessage("Еженедельно"),
        "weight": MessageLookupByLibrary.simpleMessage("Вес"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Что нового"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Оптовик"),
        "wholeSalePrice": MessageLookupByLibrary.simpleMessage("Оптовая цена"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("Оптовая цена"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Оптовик"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Будет добавлено скоро"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Истечет в"),
        "writeYourMessageHere": MessageLookupByLibrary.simpleMessage(
            "Напишите ваше сообщение здесь"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("Неверный OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Неправильный пароль для данного пользователя."),
        "yearly": MessageLookupByLibrary.simpleMessage("Ежегодно"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Да, удалить навсегда"),
        "youAreNotAValidUser": MessageLookupByLibrary.simpleMessage(
            "Вы не являетесь действительным пользователем"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Вы используете"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Вы не можете заплатить больше, чем задолженность"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("У вас есть письмо"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Вы успешно вошли в свой аккаунт. Оставайтесь с Pos Saas."),
        "youHaveToGivePermission": MessageLookupByLibrary.simpleMessage(
            "Вы должны предоставить разрешение"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Вы должны ПЕРЕВОЙТИ в свою учетную запись."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Перед покупкой SMS вам нужно пройти проверку личности"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Ваше сообщение остается"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Ваш пакет"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Ваш пакет истекает через 5 дней")
      };
}
