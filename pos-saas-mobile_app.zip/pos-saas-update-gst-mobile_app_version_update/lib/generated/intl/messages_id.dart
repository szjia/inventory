// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a id locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'id';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Lanjutkan"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("Nomor GST"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("Harga Jual Eceran (MRP)"),
        "MRPIsRequired": MessageLookupByLibrary.simpleMessage("MRP diperlukan"),
        "OK": MessageLookupByLibrary.simpleMessage("OK"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("No.Telp"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("Kode SWIFT"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Camilan"),
        "TAX": MessageLookupByLibrary.simpleMessage("PAJAK"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Mengunggah"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("Judul Pengguna"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Paket Anda Akan Kedaluwarsa Hari Ini\nSilakan Beli lagi"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) Sistem ini disediakan semata-mata untuk\nmemfasilitasi transaksi penjualan\ndan kegiatan terkait dalam bisnis Anda."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) Untuk menggunakan Sistem ini, Anda mungkin\ndiwajibkan membuat akun. Anda menyetujui untuk\nmemberikan informasi yang akurat, terkini, dan lengkap\nselama proses pendaftaran, dan untuk memperbarui\ninformasi tersebut agar tetap akurat dan lengkap."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("Tentang Aplikasi"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("Tentang kami"),
        "acceptanceOfTerms": MessageLookupByLibrary.simpleMessage(
            "Penerimaan Syarat dan Ketentuan"),
        "accountName": MessageLookupByLibrary.simpleMessage("Nama Akun"),
        "accountNumber": MessageLookupByLibrary.simpleMessage("Nomor Akun"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Pendaftaran Akun"),
        "acton": MessageLookupByLibrary.simpleMessage("Aksi"),
        "add": MessageLookupByLibrary.simpleMessage("Tambah"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Tambah Merek"),
        "addCategory": MessageLookupByLibrary.simpleMessage("Tambah Kategori"),
        "addContact": MessageLookupByLibrary.simpleMessage("Tambah Kontak"),
        "addCustomer": MessageLookupByLibrary.simpleMessage("Tambah Pelanggan"),
        "addDelivery":
            MessageLookupByLibrary.simpleMessage("Tambah Pengiriman"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Tambahkan Deskripsi"),
        "addDescription":
            MessageLookupByLibrary.simpleMessage("Tambahkan catatan"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("Tambahkan Diskon"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Tambahkan ID Dokumen"),
        "addDucument": MessageLookupByLibrary.simpleMessage("Tambah Dokumen"),
        "addExpense":
            MessageLookupByLibrary.simpleMessage("Tambah Pengeluaran"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("Tambah Kategori Pengeluaran"),
        "addItems": MessageLookupByLibrary.simpleMessage("Tambahkan Item"),
        "addNew": MessageLookupByLibrary.simpleMessage("Tambah Baru"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("Tambahkan Alamat Baru"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Tambah Produk Baru"),
        "addNewTax":
            MessageLookupByLibrary.simpleMessage("Tambahkan Pajak Baru"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Tambahkan Pajak Baru dengan jenis pajak tunggal/multiple"),
        "addNote": MessageLookupByLibrary.simpleMessage("Tambahkan Catatan"),
        "addProductFirst": MessageLookupByLibrary.simpleMessage(
            "Tambahkan produk terlebih dahulu"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Tambahkan Kode Promo"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Tambah Pembelian"),
        "addSales": MessageLookupByLibrary.simpleMessage("Tambah Penjualan"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("Berhasil Ditambahkan"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Tambah Unit"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("Tambahkan Peran Pengguna"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Berhasil ditambahkan"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("Ditambahkan ke Keranjang"),
        "address": MessageLookupByLibrary.simpleMessage("Alamat"),
        "admin": MessageLookupByLibrary.simpleMessage("Admin"),
        "all": MessageLookupByLibrary.simpleMessage("Semua"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("Semua solusi bisnis"),
        "alreadyAdded":
            MessageLookupByLibrary.simpleMessage("Sudah ditambahkan"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Sudah Ada"),
        "amount": MessageLookupByLibrary.simpleMessage("Jumlah"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "Sebuah Email telah dikirim\\nPeriksa kotak masuk Anda"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Dukungan Aplikasi Android & iOS"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Pajak yang berlaku"),
        "apply": MessageLookupByLibrary.simpleMessage("Terapkan"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Apakah Anda yakin ingin menghapus faktur ini?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Apakah Anda yakin ingin menghapus penjualan ini?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Apakah Anda yakin ingin menghapus pengguna ini?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Apakah Anda yakin ingin menghapus Pajak ini?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Apakah Anda yakin ingin menghapus Grup Pajak ini?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Apakah Anda ingin menghapus gudang ini?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Apakah Anda yakin ingin menghapus pengguna ini?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Tanda Tangan Terotorisasi"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Anda bertanggung jawab untuk\nmenjaga kerahasiaan akun dan kata sandi Anda serta\nmembatasi akses ke akun Anda. Anda menerima\ntanggung jawab atas semua aktivitas yang terjadi di\nbawah akun Anda."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Anda harus berusia minimal 18 tahun atau mencapai\nusia mayoritas yang sah di yurisdiksi Anda untuk\nmenggunakan Sistem ini."),
        "backSide": MessageLookupByLibrary.simpleMessage("Sisi Belakang"),
        "backToHome":
            MessageLookupByLibrary.simpleMessage("Kembali ke Beranda"),
        "balance": MessageLookupByLibrary.simpleMessage("Saldo"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladesh"),
        "bank": MessageLookupByLibrary.simpleMessage("Bank"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Mata Uang Rekening Bank"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("Mata Uang Akun Bank"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Informasi Bank"),
        "bankName": MessageLookupByLibrary.simpleMessage("Nama Bank"),
        "bankTransfer": MessageLookupByLibrary.simpleMessage("Transfer Bank"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Barcode ditemukan"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Tagihan/Faktur"),
        "billTo": MessageLookupByLibrary.simpleMessage("Tagih ke"),
        "branchName": MessageLookupByLibrary.simpleMessage("Nama Cabang"),
        "brand": MessageLookupByLibrary.simpleMessage("Merek"),
        "brandName": MessageLookupByLibrary.simpleMessage("Nama Merek"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("Unggah Massal"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Kategori Bisnis"),
        "buy": MessageLookupByLibrary.simpleMessage("Beli"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Beli Paket Premium"),
        "buySms": MessageLookupByLibrary.simpleMessage("Beli SMS"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Dengan mengakses atau menggunakan Sistem Point of Sale (POS) (selanjutnya disebut \"Sistem\") yang disediakan oleh [Nama Perusahaan Anda] (selanjutnya disebut \"Perusahaan\"), Anda menyetujui untuk terikat oleh Syarat Penggunaan ini. Jika Anda tidak setuju dengan Syarat Penggunaan ini, jangan gunakan Sistem."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Anda bertanggung jawab untuk memastikan bahwa hak akses dan penggunaan Sistem ini sesuai dengan semua hukum dan peraturan yang berlaku."),
        "call": MessageLookupByLibrary.simpleMessage("Telepon"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "Hubungi Untuk Dukungan Darurat"),
        "camera": MessageLookupByLibrary.simpleMessage("Kamera"),
        "cancel": MessageLookupByLibrary.simpleMessage("Batal"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Batalkan Semua Produk"),
        "capacity": MessageLookupByLibrary.simpleMessage("Kapasitas"),
        "card": MessageLookupByLibrary.simpleMessage("Kartu"),
        "cash": MessageLookupByLibrary.simpleMessage("Tunai"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Kategori"),
        "category": MessageLookupByLibrary.simpleMessage("Kategori"),
        "categoryName": MessageLookupByLibrary.simpleMessage("Nama Kategori"),
        "categoryNameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Nama Kategori Sudah Ada"),
        "cateogryName": MessageLookupByLibrary.simpleMessage("Nama Kategori"),
        "change": MessageLookupByLibrary.simpleMessage("Ubah?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Ubah Kata Sandi"),
        "checkEmail": MessageLookupByLibrary.simpleMessage("Periksa Email"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Pilih Pelanggan"),
        "choseASupplier": MessageLookupByLibrary.simpleMessage("Pilih Pemasok"),
        "choseYourFeature":
            MessageLookupByLibrary.simpleMessage("Pilih fitur Anda"),
        "clarence": MessageLookupByLibrary.simpleMessage("Klarifikasi"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Klik untuk terhubung"),
        "close": MessageLookupByLibrary.simpleMessage("Tutup"),
        "color": MessageLookupByLibrary.simpleMessage("Warna"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(Kombinasi dari beberapa pajak)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("Segera Hadir"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Alamat Perusahaan"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("Nama Perusahaan & Toko"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("Nama Perusahaan & Bisnis"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Selesaikan Transaksi"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Konfirmasi Kata Sandi"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Konfirmasi pengembalian"),
        "congratulations": MessageLookupByLibrary.simpleMessage("Selamat"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Hubungi Kami"),
        "continu": MessageLookupByLibrary.simpleMessage("Lanjutkan"),
        "country": MessageLookupByLibrary.simpleMessage("Negara"),
        "create": MessageLookupByLibrary.simpleMessage("Buat"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Buat Akun Gratis"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Dibuat dan Disimpan"),
        "currency": MessageLookupByLibrary.simpleMessage("Mata Uang"),
        "currentStock": MessageLookupByLibrary.simpleMessage("Stok Saat Ini"),
        "customInvoiceBranding":
            MessageLookupByLibrary.simpleMessage("Pembranding Faktur Kustom"),
        "customer": MessageLookupByLibrary.simpleMessage("Pelanggan"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Detail Pelanggan"),
        "customerGST": MessageLookupByLibrary.simpleMessage("GST Pelanggan"),
        "customerName": MessageLookupByLibrary.simpleMessage("Nama Pelanggan"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Transaksi Harian"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Gambaran Dasbor"),
        "dataSavedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Data berhasil disimpan"),
        "date": MessageLookupByLibrary.simpleMessage("Tanggal"),
        "day": MessageLookupByLibrary.simpleMessage("Hari"),
        "dealer": MessageLookupByLibrary.simpleMessage("Penjual"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("Harga Dealer"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("Persentase PPN Default"),
        "delete": MessageLookupByLibrary.simpleMessage("Hapus"),
        "deleting": MessageLookupByLibrary.simpleMessage("Menghapus"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Alamat Pengiriman"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Alamat Pengiriman"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Biaya Pengiriman"),
        "description": MessageLookupByLibrary.simpleMessage("Deskripsi"),
        "descriptionCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Deskripsi tidak boleh kosong"),
        "details": MessageLookupByLibrary.simpleMessage("Detail"),
        "discount": MessageLookupByLibrary.simpleMessage("Diskon"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Jangan Ganggu"),
        "done": MessageLookupByLibrary.simpleMessage("Selesai"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Unduh Format Excel"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Berhasil diunduh di folder unduhan"),
        "due": MessageLookupByLibrary.simpleMessage("Hutang"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Jumlah Hutang: "),
        "dueCollection":
            MessageLookupByLibrary.simpleMessage("Pengumpulan Hutang"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("Laporan Pemungutan Kredit"),
        "dueList": MessageLookupByLibrary.simpleMessage("Daftar Hutang"),
        "dueReports": MessageLookupByLibrary.simpleMessage("Laporan Hutang"),
        "duration": MessageLookupByLibrary.simpleMessage("Durasi"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Durasi: Dari"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "Mobile POS yang mudah digunakan"),
        "edit": MessageLookupByLibrary.simpleMessage("Edit"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Edit Faktur Pembelian"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("Edit Faktur Penjualan"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Edit Media Sosial"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Berhasil Diedit"),
        "editTax": MessageLookupByLibrary.simpleMessage("Edit Pajak"),
        "editTaxGroup": MessageLookupByLibrary.simpleMessage("Edit Grup Pajak"),
        "editWarehouse": MessageLookupByLibrary.simpleMessage("Edit Gudang"),
        "email": MessageLookupByLibrary.simpleMessage("Surel"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("Alamat Email"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Email tidak boleh kosong"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "Email Dikirim! Periksa Kotak Masuk Anda"),
        "endDate": MessageLookupByLibrary.simpleMessage("Tanggal Akhir"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Masukkan jumlah yang valid"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Masukkan Diskon yang Valid"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Masukkan nomor telepon yang valid"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Masukkan harga yang valid"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("Masukkan jumlah yang valid"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("Masukkan Alamat"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("Masukkan Jumlah."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Masukkan Nama Merek"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Masukkan Kapasitas"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("Masukkan Nama Kategori"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Masukkan Warna"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "Masukkan nomor GST pelanggan"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Masukkan Harga Dealer"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Masukkan Deskripsi"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("Masukkan Diskon."),
        "enterExpenseDate": MessageLookupByLibrary.simpleMessage(
            "Masukkan Tanggal Pengeluaran"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Masukkan Alamat Lengkap"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Masukkan Nomor Faktur"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Masukkan Jumlah Peringatan Stok Rendah"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Masukkan Nama Pabrikan"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("Masukkan Isi Pesan"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "Masukkan Harga Jual Eceran (MRP)/Harga Retailer"),
        "enterName": MessageLookupByLibrary.simpleMessage("Masukkan Nama"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Masukkan Catatan"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Masukkan Nama Pihak"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Masukkan Nomor Telepon"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Masukkan Kode Produk atau Pindai"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Masukkan Nama Produk"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Masukkan Harga Beli."),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("Masukkan Nomor Referensi"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Masukkan Ukuran"),
        "enterStocks": MessageLookupByLibrary.simpleMessage("Masukkan Stok."),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Masukkan Tarif Pajak"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("Masukkan ID Transaksi"),
        "enterType": MessageLookupByLibrary.simpleMessage("Masukkan Tipe"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("Masukkan judul pengguna"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Masukkan jumlah yang valid"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("Masukkan Nama Gudang"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Masukkan Berat"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Masukkan Harga Grosir"),
        "enterYourDescriptionHere": MessageLookupByLibrary.simpleMessage(
            "Masukkan deskripsi Anda di sini"),
        "enterYourEmailAddress":
            MessageLookupByLibrary.simpleMessage("Masukkan Alamat Surel Anda"),
        "enterYourFeedBackTitle":
            MessageLookupByLibrary.simpleMessage("Masukkan Judul Masukan Anda"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Masukkan nomor GST Anda"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("Masukkan nomor ponsel Anda"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Masukkan Nama Anda"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("Masukkan nomor telepon Anda"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Masukkan kata sandi Anda"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Masukkan Nomor Telepon Anda"),
        "enterYourTransactionId":
            MessageLookupByLibrary.simpleMessage("Masukkan ID transaksi Anda"),
        "error": MessageLookupByLibrary.simpleMessage("Kesalahan"),
        "excTax": MessageLookupByLibrary.simpleMessage("Pajak Tidak Termasuk"),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("Pengunggah Excel"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Eksklusif"),
        "expense": MessageLookupByLibrary.simpleMessage("Pengeluaran"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Kategori Pengeluaran"),
        "expenseDate":
            MessageLookupByLibrary.simpleMessage("Tanggal Pengeluaran"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Pengeluaran Untuk"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Laporan Pengeluaran"),
        "expireDate":
            MessageLookupByLibrary.simpleMessage("Tanggal Kedaluwarsa"),
        "expired": MessageLookupByLibrary.simpleMessage("Kedaluwarsa"),
        "expiring": MessageLookupByLibrary.simpleMessage("Akan Kedaluwarsa"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Gagal dengan Kesalahan"),
        "fashion": MessageLookupByLibrary.simpleMessage("Fashion"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Fitur-fitur merupakan bagian penting yang membuat Pos Saas berbeda dari solusi tradisional."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Masukan"),
        "firstName": MessageLookupByLibrary.simpleMessage("Nama Depan"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Ikuti Kami di\\nFacebook"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Ikuti Kami di\\nTwitter"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Sisi Depan"),
        "forUnlimitedUses": MessageLookupByLibrary.simpleMessage(
            "Untuk penggunaan tak terbatas"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Lupa kata sandi"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Lupa Kata Sandi?"),
        "formDate": MessageLookupByLibrary.simpleMessage("Dari Tanggal"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("Pencadangan Data Gratis"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "Pembaruan Seumur Hidup Gratis"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Paket Gratis"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Paket Gratis"),
        "from": MessageLookupByLibrary.simpleMessage("(Dari"),
        "fullyPaid":
            MessageLookupByLibrary.simpleMessage("Sudah Dibayar Penuh"),
        "gallary": MessageLookupByLibrary.simpleMessage("Galeri"),
        "generatingPDF":
            MessageLookupByLibrary.simpleMessage("Menghasilkan PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Dapatkan OTP"),
        "guest": MessageLookupByLibrary.simpleMessage("Tamu"),
        "havenotAnAccounts":
            MessageLookupByLibrary.simpleMessage("Belum memiliki akun?"),
        "history": MessageLookupByLibrary.simpleMessage("Riwayat"),
        "home": MessageLookupByLibrary.simpleMessage("Beranda"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "Bagaimana Kami Melindungi Informasi Anda"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "Bagaimana Kami Menggunakan Informasi Anda"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Verifikasi Identitas"),
        "image": MessageLookupByLibrary.simpleMessage("Gambar"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("InHouse tidak dapat dihapus"),
        "inHouseCantBeEdited":
            MessageLookupByLibrary.simpleMessage("InHouse tidak dapat diedit"),
        "inWord": MessageLookupByLibrary.simpleMessage("Dalam Kata"),
        "incTax": MessageLookupByLibrary.simpleMessage("Pajak Termasuk"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Termasuk"),
        "increaseStock":
            MessageLookupByLibrary.simpleMessage("Tingkatkan Stok"),
        "invNo": MessageLookupByLibrary.simpleMessage("No. Inv."),
        "invoice": MessageLookupByLibrary.simpleMessage("Faktur"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("Nomor Faktur"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Pengaturan Faktur"),
        "invoiceViewer": MessageLookupByLibrary.simpleMessage("Pemandu Faktur"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Item Ditambahkan"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("Verifikasi KYC"),
        "language": MessageLookupByLibrary.simpleMessage("Bahasa"),
        "lastName": MessageLookupByLibrary.simpleMessage("Nama Belakang"),
        "ledger": MessageLookupByLibrary.simpleMessage("Buku Besar"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("Pembelian Seumur Hidup"),
        "link": MessageLookupByLibrary.simpleMessage("Tautan"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Dukungan Obrolan Langsung"),
        "loading": MessageLookupByLibrary.simpleMessage("Memuat"),
        "logIn": MessageLookupByLibrary.simpleMessage("Masuk"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Keluar"),
        "logOut": MessageLookupByLibrary.simpleMessage("Keluar"),
        "login": MessageLookupByLibrary.simpleMessage("Masuk"),
        "logo": MessageLookupByLibrary.simpleMessage("Logo"),
        "loss": MessageLookupByLibrary.simpleMessage("Rugi"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Rugi/Keuntungan"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Rincian Rugi/Keuntungan"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Laporan Rugi/Laba"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Laporan Rugi/Laba"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Peringatan Stok Rendah"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Buat kesan yang abadi pada pelanggan Anda dengan faktur bermerk. Upgrade Tanpa Batas kami menawarkan keunggulan unik dalam menyesuaikan faktur Anda, menambahkan sentuhan profesional yang memperkuat identitas merek Anda dan memupuk loyalitas pelanggan."),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("Kelola bisnis Anda dengan "),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Tanggal Produksi"),
        "margin": MessageLookupByLibrary.simpleMessage("Margin"),
        "masterCard": MessageLookupByLibrary.simpleMessage("Kartu Master"),
        "message": MessageLookupByLibrary.simpleMessage("Pesan"),
        "messageHistory": MessageLookupByLibrary.simpleMessage("Riwayat Pesan"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "Aplikasi Pos Saas gratis dan mudah digunakan. Sebenarnya, ini adalah salah satu sistem POS terbaik di seluruh dunia."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas adalah solusi bisnis lengkap dengan stok, akun, penjualan, pengeluaran, dan rugi/laba."),
        "mobile": MessageLookupByLibrary.simpleMessage("Seluler"),
        "mobilePayment":
            MessageLookupByLibrary.simpleMessage("Pembayaran Seluler"),
        "monthly": MessageLookupByLibrary.simpleMessage("Bulanan"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("Info Lebih Lanjut"),
        "name": MessageLookupByLibrary.simpleMessage("Masukkan Nama Anda."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Nama Sudah Ada"),
        "nameCantBeEmpty":
            MessageLookupByLibrary.simpleMessage("Nama tidak boleh kosong"),
        "next": MessageLookupByLibrary.simpleMessage("Selanjutnya"),
        "noConnection":
            MessageLookupByLibrary.simpleMessage("Tidak Ada Koneksi"),
        "noData": MessageLookupByLibrary.simpleMessage("Tidak Ada Data"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Tidak ada data tersedia"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Tidak Ada Data Ditemukan"),
        "noHistoryFound": MessageLookupByLibrary.simpleMessage(
            "Tidak Ada Riwayat Ditemukan!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Tidak ada produk ditemukan"),
        "noSubTaxSelected": MessageLookupByLibrary.simpleMessage(
            "Tidak ada pajak tambahan yang dipilih"),
        "noTransactionFound": MessageLookupByLibrary.simpleMessage(
            "Tidak Ada Transaksi Ditemukan!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Tidak ada pengguna yang ditemukan untuk email tersebut."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "Tidak Ada Peran Pengguna Ditemukan"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Pengguna Tidak Aktif"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Tidak disediakan"),
        "note": MessageLookupByLibrary.simpleMessage("Catatan"),
        "notes": MessageLookupByLibrary.simpleMessage("Catatan"),
        "notification": MessageLookupByLibrary.simpleMessage("Notifikasi"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP terkirim ke"),
        "office": MessageLookupByLibrary.simpleMessage("Kantor"),
        "ok": MessageLookupByLibrary.simpleMessage("Oke"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS yang mengandung banyak fungsionalitas, termasuk pelacakan penjualan dan manajemen inventaris."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Sistem ini membantu Anda meningkatkan operasi untuk pelanggan Anda."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "Sistem POS kami seharusnya secara otomatis menyederhanakan operasi harian, sehingga mudah dinavigasi."),
        "openingBalance": MessageLookupByLibrary.simpleMessage("Saldo Awal"),
        "order": MessageLookupByLibrary.simpleMessage("Pesanan"),
        "other": MessageLookupByLibrary.simpleMessage("Lainnya"),
        "otp": MessageLookupByLibrary.simpleMessage("Tutup"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Habis Stok"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Paket"),
        "packageFeatures": MessageLookupByLibrary.simpleMessage("Fitur Paket"),
        "paid": MessageLookupByLibrary.simpleMessage("Dibayar"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Jumlah Dibayar"),
        "parties": MessageLookupByLibrary.simpleMessage("Pihak"),
        "partiesList": MessageLookupByLibrary.simpleMessage("Daftar Pihak"),
        "partyGST": MessageLookupByLibrary.simpleMessage("GST Pihak"),
        "partyName": MessageLookupByLibrary.simpleMessage("Nama Pihak"),
        "password": MessageLookupByLibrary.simpleMessage("Kata Sandi"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Kata sandi dan konfirmasi kata sandi tidak cocok"),
        "passwordCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Kata sandi tidak boleh kosong"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("Kata sandi tidak cocok"),
        "payCash": MessageLookupByLibrary.simpleMessage("Bayar Tunai"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("Bayar dengan bKash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Bayar dengan Paypal"),
        "payeeName": MessageLookupByLibrary.simpleMessage("Nama Penerima"),
        "payeeNumber": MessageLookupByLibrary.simpleMessage("Nomor Penerima"),
        "payment": MessageLookupByLibrary.simpleMessage("Pembayaran"),
        "paymentAmount":
            MessageLookupByLibrary.simpleMessage("Jumlah Pembayaran"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Pembayaran Selesai"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Instruksi Pembayaran:"),
        "paymentMethod":
            MessageLookupByLibrary.simpleMessage("Metode Pembayaran"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Jenis Pembayaran"),
        "pdfView": MessageLookupByLibrary.simpleMessage("Tampilan PDF"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Informasi Pribadi"),
        "phone": MessageLookupByLibrary.simpleMessage("Telepon"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Nomor Telepon"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Nomor telepon sudah digunakan"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("Nomor telepon tidak valid"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("Nomor telepon diperlukan"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("Pilih dan Unggah File"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("Pilih Tanggal Akhir"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("Pilih Tanggal Mulai"),
        "plan": MessageLookupByLibrary.simpleMessage("Rencana"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("Silakan tambahkan jumlah"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Harap periksa konektivitas internet Anda"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Silakan sambungkan printer terlebih dahulu"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Silakan hubungkan printer Bluetooth Anda"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Silakan masukkan kata sandi yang lebih panjang"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Silakan Masukkan Kata Sandi Konfirmasi"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("Silakan masukkan kata sandi"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Silakan masukkan email yang valid"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Silakan masukkan nama"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("Silakan Masukkan Kata Sandi"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Silakan masukkan alamat email Anda di bawah ini untuk menerima Tautan Pengaturan Ulang Kata Sandi."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Silakan Masukkan Nomor Transaksi"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("Silakan masukkan jumlah"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Silakan pilih kategori terlebih dahulu"),
        "pleaseSelectAPlan":
            MessageLookupByLibrary.simpleMessage("Silakan Pilih Rencana"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Silakan pilih kategori bisnis"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Silakan gunakan kode pembelian yang valid untuk menggunakan aplikasi"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Didukung oleh Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Ditenagai Oleh"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Dukungan Pelanggan Premium"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Paket Premium"),
        "previousPayAmounts": MessageLookupByLibrary.simpleMessage(
            "Jumlah Pembayaran Sebelumnya"),
        "price": MessageLookupByLibrary.simpleMessage("Harga"),
        "print": MessageLookupByLibrary.simpleMessage("Cetak"),
        "printingOption": MessageLookupByLibrary.simpleMessage("Opsi Cetakan"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Kebijakan Privasi"),
        "product": MessageLookupByLibrary.simpleMessage("Produk"),
        "productCode": MessageLookupByLibrary.simpleMessage("Kode Produk"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("Kode produk diperlukan"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Kode/Nama Produk"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Deskripsi Produk"),
        "productDetails": MessageLookupByLibrary.simpleMessage("Detail Produk"),
        "productList": MessageLookupByLibrary.simpleMessage("Daftar Produk"),
        "productName": MessageLookupByLibrary.simpleMessage("Nama Produk"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Nama produk sudah ada di gudang ini"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Nama produk sudah ditambahkan"),
        "productNameIsRequired":
            MessageLookupByLibrary.simpleMessage("Nama produk diperlukan"),
        "products": MessageLookupByLibrary.simpleMessage("Produk"),
        "profile": MessageLookupByLibrary.simpleMessage("Profil"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("Sunting Profil"),
        "profit": MessageLookupByLibrary.simpleMessage("Keuntungan"),
        "promo": MessageLookupByLibrary.simpleMessage("Promo"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Kode Promo"),
        "purchase": MessageLookupByLibrary.simpleMessage("Pembelian"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("Alarm Pembelian"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Pembelian Dikonfirmasi"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Detail Pembelian"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Faktur Pembelian"),
        "purchaseList":
            MessageLookupByLibrary.simpleMessage("Daftar Pembelian"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("Beli Sekarang"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Beli Paket Premium"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("Harga Beli"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("Harga beli diperlukan"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Laporan Pembelian"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Laporan Pembelian"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("Pengembalian Pembelian"),
        "purchaseReturnReport": MessageLookupByLibrary.simpleMessage(
            "Laporan Pengembalian Pembelian"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Transisi Pembelian"),
        "qty": MessageLookupByLibrary.simpleMessage("Kuantitas"),
        "quantity": MessageLookupByLibrary.simpleMessage("Kuantitas"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Transaksi Terbaru"),
        "recivedThePin": MessageLookupByLibrary.simpleMessage("Menerima PIN"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Nomor Referensi"),
        "register": MessageLookupByLibrary.simpleMessage("Daftar"),
        "registering": MessageLookupByLibrary.simpleMessage("Mendaftar"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("Hutang Tersisa"),
        "remove": MessageLookupByLibrary.simpleMessage("Hapus"),
        "reports": MessageLookupByLibrary.simpleMessage("Laporan"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("Permintaan telah dikirim"),
        "resendCode": MessageLookupByLibrary.simpleMessage("Kirim Ulang Kode"),
        "resendOtp": MessageLookupByLibrary.simpleMessage("Kirim Ulang OTP: "),
        "retailer": MessageLookupByLibrary.simpleMessage("Penjual Eceran"),
        "retur": MessageLookupByLibrary.simpleMessage("Retur"),
        "returN": MessageLookupByLibrary.simpleMessage("Pengembalian"),
        "returnAMount":
            MessageLookupByLibrary.simpleMessage("Jumlah Pengembalian"),
        "returnAmount":
            MessageLookupByLibrary.simpleMessage("Jumlah Pengembalian"),
        "returnQTY":
            MessageLookupByLibrary.simpleMessage("Jumlah Pengembalian"),
        "revenue": MessageLookupByLibrary.simpleMessage("Pendapatan"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "Lindungi data bisnis Anda dengan mudah. Upgrade Tanpa Batas Pos Saas POS kami termasuk pencadangan data gratis, menjamin perlindungan terhadap informasi berharga Anda terhadap peristiwa tak terduga. Fokus pada hal yang benar-benar penting - pertumbuhan bisnis Anda."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("Jumlah Penjualan"),
        "saleDetails": MessageLookupByLibrary.simpleMessage("Detail Penjualan"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Harga Jual"),
        "saleReports":
            MessageLookupByLibrary.simpleMessage("Laporan Penjualan"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Laporan Penjualan"),
        "saleReturn":
            MessageLookupByLibrary.simpleMessage("Pengembalian Penjualan"),
        "saleReturnReport": MessageLookupByLibrary.simpleMessage(
            "Laporan Pengembalian Penjualan"),
        "saleSetting":
            MessageLookupByLibrary.simpleMessage("Pengaturan Penjualan"),
        "sales": MessageLookupByLibrary.simpleMessage("Penjualan"),
        "salesAndPurchaseReports": MessageLookupByLibrary.simpleMessage(
            "Laporan Penjualan & Pembelian"),
        "salesList": MessageLookupByLibrary.simpleMessage("Daftar Penjualan"),
        "salesReturn":
            MessageLookupByLibrary.simpleMessage("Pengembalian Penjualan"),
        "save": MessageLookupByLibrary.simpleMessage("Simpan"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Simpan dan Terbitkan"),
        "saveChanges": MessageLookupByLibrary.simpleMessage("Simpan Perubahan"),
        "saving": MessageLookupByLibrary.simpleMessage("Menyimpan"),
        "scanProductQRCode":
            MessageLookupByLibrary.simpleMessage("Pindai kode QR produk"),
        "search": MessageLookupByLibrary.simpleMessage("Cari"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Cari berdasarkan kode atau nama produk"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("Lihat semua kode promo"),
        "select": MessageLookupByLibrary.simpleMessage("Pilih"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Pilih produk untuk dikembalikan"),
        "selectBrand": MessageLookupByLibrary.simpleMessage("Pilih Merek"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Pilih Kategori"),
        "selectContacts": MessageLookupByLibrary.simpleMessage("Pilih Kontak"),
        "selectProductCategory":
            MessageLookupByLibrary.simpleMessage("Pilih Kategori Produk"),
        "selectShopCategory":
            MessageLookupByLibrary.simpleMessage("Pilih kategori toko"),
        "selectTax": MessageLookupByLibrary.simpleMessage("Pilih Pajak"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("Pilih Jenis Pajak"),
        "selectUnit": MessageLookupByLibrary.simpleMessage("Pilih Satuan"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Pilih Variasi: "),
        "seller": MessageLookupByLibrary.simpleMessage("Penjual"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Dijual Oleh"),
        "send": MessageLookupByLibrary.simpleMessage("Kirim"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("Kirim Email"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Kirim Pesan"),
        "sendResetLink": MessageLookupByLibrary.simpleMessage(
            "Kirim Tautan Pengaturan Ulang"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Kirim SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Kirim SMS?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Kirim pesan whatsapp"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Kirim Email Anda"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage("Mengirim Email"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Mengirim pesan"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Layanan/Pengiriman"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Atur Profil Anda"),
        "setting": MessageLookupByLibrary.simpleMessage("Pengaturan"),
        "share": MessageLookupByLibrary.simpleMessage("Bagikan"),
        "shopGST": MessageLookupByLibrary.simpleMessage("GST Toko"),
        "signIn": MessageLookupByLibrary.simpleMessage("Masuk"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("Masuk dengan email"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Tanda Tangan Pelanggan"),
        "size": MessageLookupByLibrary.simpleMessage("Ukuran"),
        "skip": MessageLookupByLibrary.simpleMessage("Lewati"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Pemasaran Sosial"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Maaf, Anda tidak memiliki izin untuk mengakses layanan ini"),
        "startDate": MessageLookupByLibrary.simpleMessage("Tanggal Mulai"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("Mulai Penjualan Baru"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage(
            "Mulai mengetik untuk mencari"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "Tetap di garis depan perkembangan teknologi tanpa biaya tambahan. Saat Anda menggunakan Pos Saas POS Unlimited Upgrade kami, Anda selalu memiliki alat dan fitur terbaru di ujung jari Anda, menjamin bisnis Anda tetap mutakhir."),
        "stillUnpaid":
            MessageLookupByLibrary.simpleMessage("Masih Belum Dibayar"),
        "stock": MessageLookupByLibrary.simpleMessage("Stok"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Stok diperlukan"),
        "stockList": MessageLookupByLibrary.simpleMessage("Daftar Stok"),
        "stocks": MessageLookupByLibrary.simpleMessage("Stok"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "Izin penyimpanan diperlukan untuk membuat file Excel"),
        "subTaxList":
            MessageLookupByLibrary.simpleMessage("Daftar Pajak Tambahan"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Pajak Tambahan"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Subtotal"),
        "submit": MessageLookupByLibrary.simpleMessage("Kirim"),
        "subscribeToOurYoutube":
            MessageLookupByLibrary.simpleMessage("Berlangganan di\\nYoutube"),
        "subscription": MessageLookupByLibrary.simpleMessage("Langganan"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Berhasil Dilakukan"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Berhasil Keluar"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Berhasil Diperbarui"),
        "supplier": MessageLookupByLibrary.simpleMessage("Pemasok"),
        "supplierName": MessageLookupByLibrary.simpleMessage("Nama Pemasok"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("Kode SWIFT"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Ambil foto SIM, kartu identitas nasional, atau paspor"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "Bawa kartu identitas untuk memeriksa informasi Anda"),
        "tap": MessageLookupByLibrary.simpleMessage("Ketuk"),
        "tax": MessageLookupByLibrary.simpleMessage("Pajak"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Grup Pajak"),
        "taxPercentage":
            MessageLookupByLibrary.simpleMessage("Persentase Pajak"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Tarif Pajak"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Tarif Pajak - Kelola Tarif Pajak Anda"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Laporan Pajak"),
        "taxType": MessageLookupByLibrary.simpleMessage("Jenis Pajak"),
        "taxes": MessageLookupByLibrary.simpleMessage("Pajak"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Syarat dan Ketentuan"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("Syarat Penggunaan"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("Syarat & Privasi"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Terima Kasih atas Pembayaran Hutang Anda"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Terima Kasih"),
        "thankYouForYourPurchase": MessageLookupByLibrary.simpleMessage(
            "Terima Kasih atas Pembelian Anda"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "Akun sudah ada untuk email itu"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage("File Excel sudah diunduh"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "Namanya mengatakannya semua. Dengan Pos Saas POS Unlimited, tidak ada batasan penggunaan. Baik Anda memproses sejumlah transaksi atau mengalami lonjakan pelanggan, Anda dapat beroperasi dengan percaya diri, tanpa terbatas oleh batasan."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "Kata sandi yang diberikan terlalu lemah"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "Penjualan akan dihapus dan semua data tentang pembelian ini akan dihapus. Apakah Anda yakin ingin menghapus ini?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "Penjualan akan dihapus dan semua data tentang penjualan ini akan dihapus. Apakah Anda yakin ingin menghapus ini?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "Pengguna akan dihapus dan semua data akan dihapus dari akun Anda. Apakah Anda yakin ingin menghapus ini?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "Pengguna akan dihapus dan semua data akan dihapus dari akun Anda. Apakah Anda yakin ingin menghapus ini?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("Layanan Pihak Ketiga"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Kategori ini tidak dapat dihapus"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Bulan Ini)"),
        "thisProductAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Produk ini sudah ditambahkan"),
        "title": MessageLookupByLibrary.simpleMessage("Judul"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("Judul tidak boleh kosong"),
        "to": MessageLookupByLibrary.simpleMessage("ke"),
        "toDate": MessageLookupByLibrary.simpleMessage("Hingga Tanggal"),
        "today": MessageLookupByLibrary.simpleMessage("Hari ini"),
        "total": MessageLookupByLibrary.simpleMessage("Total"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Jumlah Total"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Total Terkumpul"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Total Hutang"),
        "totalExpense":
            MessageLookupByLibrary.simpleMessage("Total Pengeluaran"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Total Kerugian"),
        "totalPayable":
            MessageLookupByLibrary.simpleMessage("Total yang Harus Dibayar"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Total Harga"),
        "totalProducts": MessageLookupByLibrary.simpleMessage("Total Produk"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Total Keuntungan"),
        "totalPurchase":
            MessageLookupByLibrary.simpleMessage("Total Pembelian"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Total Jumlah Pengembalian"),
        "totalReturns":
            MessageLookupByLibrary.simpleMessage("Total Pengembalian"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Total Penjualan"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Total Stok"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Total Nilai"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Total PPN"),
        "totals": MessageLookupByLibrary.simpleMessage("Total: "),
        "transaction": MessageLookupByLibrary.simpleMessage("Transaksi"),
        "transactionId": MessageLookupByLibrary.simpleMessage("ID Transaksi"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Coba Lagi"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Tipe"),
        "unitName": MessageLookupByLibrary.simpleMessage("Nama Unit"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Harga Satuan"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Harga Satuan"),
        "units": MessageLookupByLibrary.simpleMessage("Unit"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Tidak Terbatas"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Penggunaan Tanpa Batas"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Buka potensi penuh Pos Saas POS dengan sesi pelatihan yang dipersonalisasi yang dipimpin oleh tim ahli kami. Dari dasar hingga teknik lanjutan, kami memastikan Anda terampil dalam menggunakan setiap aspek sistem untuk mengoptimalkan proses bisnis Anda."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Belum dibayar"),
        "update": MessageLookupByLibrary.simpleMessage("Perbarui"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Perbarui Kontak"),
        "updateNow": MessageLookupByLibrary.simpleMessage("Perbarui Sekarang"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("Perbarui Produk"),
        "updateYourPlanFirstYourLimitIsOver": MessageLookupByLibrary.simpleMessage(
            "Perbarui rencana Anda terlebih dahulu,\\nbatas Anda telah habis"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Perbarui Profil Anda"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Perbarui profil Anda untuk menghubungkan dokter Anda dengan kesan yang lebih baik"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Perbarui profil Anda untuk terhubung dengan pelanggan Anda dengan kesan yang lebih baik"),
        "updated": MessageLookupByLibrary.simpleMessage("Diperbarui"),
        "upload": MessageLookupByLibrary.simpleMessage("Unggah"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Unggah Dokumen"),
        "uploadDone": MessageLookupByLibrary.simpleMessage("Unggahan Selesai"),
        "uploadFile": MessageLookupByLibrary.simpleMessage("Unggah Berkas"),
        "usbC": MessageLookupByLibrary.simpleMessage("USB C"),
        "use": MessageLookupByLibrary.simpleMessage("Gunakan"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("Gunakan Pos Saas"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Penggunaan Sistem"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("Pengguna dihapus"),
        "userRole": MessageLookupByLibrary.simpleMessage("Peran Pengguna"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("Detail Peran Pengguna"),
        "userTitle": MessageLookupByLibrary.simpleMessage("Judul Pengguna"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Judul pengguna tidak boleh kosong"),
        "value": MessageLookupByLibrary.simpleMessage("Nilai"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("Pajak tidak berlaku"),
        "verifyOtp": MessageLookupByLibrary.simpleMessage("Memverifikasi OTP"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Verifikasi Nomor Telepon"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Lihat Semua"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("Lihat rincian"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Pelanggan Datang Langsung"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Gudang"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Gudang Sudah Ada"),
        "warehouseList": MessageLookupByLibrary.simpleMessage("Daftar Gudang"),
        "warehouseName": MessageLookupByLibrary.simpleMessage("Nama Gudang"),
        "warranty": MessageLookupByLibrary.simpleMessage("Garansi"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Kami Telah Mengirim Email dengan instruksi tentang cara mengatur ulang kata sandi ke:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Kami dapat menggunakan layanan pihak ketiga untuk mendukung fungsionalitas aplikasi kami, seperti penyedia analitik dan pemroses pembayaran. Layanan pihak ketiga ini dapat mengumpulkan informasi tentang Anda saat Anda menggunakan aplikasi kami. Harap dicatat bahwa kami tidak bertanggung jawab atas praktik privasi layanan pihak ketiga ini."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Kami menerapkan langkah-langkah standar industri untuk melindungi informasi pribadi Anda, termasuk enkripsi dan penyimpanan yang aman. Kami juga membatasi akses ke informasi Anda hanya bagi personil yang berwenang."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "Kami memahami pentingnya operasi yang lancar. Itulah mengapa dukungan sepanjang waktu kami tersedia untuk membantu Anda, baik itu pertanyaan cepat atau perhatian komprehensif. Hubungi kami kapan saja, di mana saja melalui panggilan atau WhatsApp untuk merasakan layanan pelanggan yang tak tertandingi."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Kami menggunakan informasi pribadi Anda untuk memberikan pengalaman terbaik di aplikasi kami, termasuk personalisasi rekomendasi konten, menghubungkan Anda dengan ahli, dan meningkatkan fungsionalitas aplikasi kami. Kami juga dapat menggunakan informasi Anda untuk berkomunikasi dengan Anda tentang pembaruan, promosi, atau informasi lain yang terkait dengan aplikasi kami."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Kami akan meninjau pembayaran & menyetujuinya dalam 1-2 jam"),
        "weekly": MessageLookupByLibrary.simpleMessage("Mingguan"),
        "weight": MessageLookupByLibrary.simpleMessage("Berat"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Apa yang Baru"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Pedagang Besar"),
        "wholeSalePrice": MessageLookupByLibrary.simpleMessage("Harga Grosir"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("Harga Grosir"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Grosir"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Akan ditambahkan segera"),
        "willExpireAt":
            MessageLookupByLibrary.simpleMessage("Akan Kedaluwarsa pada"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Tulis pesan Anda di sini"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("OTP salah"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Kata sandi yang salah diberikan untuk pengguna tersebut."),
        "yearly": MessageLookupByLibrary.simpleMessage("Tahunan"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("Ya, Hapus Selamanya"),
        "youAreNotAValidUser": MessageLookupByLibrary.simpleMessage(
            "Anda Bukan Pengguna yang Valid"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Anda menggunakan"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Anda tidak bisa membayar lebih dari yang terutang"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Anda Telah Menerima Email"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Anda berhasil masuk ke akun Anda. Tetap bersama Pos Saas ."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("Anda Harus Memberikan Izin"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Anda harus LOGIN ULANG ke akun Anda."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Anda perlu melakukan verifikasi identitas sebelum membeli"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Pesan Anda tetap"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Paket Anda"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Paket Anda Akan Kedaluwarsa dalam 5 Hari")
      };
}
