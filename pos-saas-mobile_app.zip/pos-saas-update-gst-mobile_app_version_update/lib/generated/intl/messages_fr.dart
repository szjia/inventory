// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a fr locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'fr';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("Continuer"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("Numéro GST"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("Prix de détail"),
        "MRPIsRequired":
            MessageLookupByLibrary.simpleMessage("Le MRP est requis"),
        "OK": MessageLookupByLibrary.simpleMessage("OK"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("Paypal"),
        "PhNo": MessageLookupByLibrary.simpleMessage("Ph.no"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("Code SWIFT"),
        "Snacks": MessageLookupByLibrary.simpleMessage("Casse-croûte"),
        "TAX": MessageLookupByLibrary.simpleMessage("TAXE"),
        "Uploading": MessageLookupByLibrary.simpleMessage("Téléchargement"),
        "UserTitle":
            MessageLookupByLibrary.simpleMessage("Titre de l\'utilisateur"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "Votre forfait expirera aujourd\'hui,\n\nVeuillez acheter à nouveau"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(a) Järjestelmä on tarkoitettu ainoastaan myyntipisteen transaktioiden ja niihin liittyvien toimintojen helpottamiseen yrityksessäsi."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(a) Järjestelmän käyttämiseksi saatetaan edellyttää käyttäjätilin luomista. Hyväksyt antavasi tarkat, ajantasaiset ja täydelliset tiedot rekisteröitymisprosessin aikana ja päivittäväsi kyseiset tiedot pysyäksesi tarkkoina ja täydellisinä."),
        "aboutApp":
            MessageLookupByLibrary.simpleMessage("À propos de l\'application"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("À propos de nous"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("Käyttöehtojen hyväksyminen"),
        "accountName": MessageLookupByLibrary.simpleMessage("Nom du compte"),
        "accountNumber":
            MessageLookupByLibrary.simpleMessage("Numéro de compte"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("Käyttäjätilin rekisteröinti"),
        "acton": MessageLookupByLibrary.simpleMessage("Action"),
        "add": MessageLookupByLibrary.simpleMessage("Ajouter"),
        "addBrand": MessageLookupByLibrary.simpleMessage("Ajouter une marque"),
        "addCategory":
            MessageLookupByLibrary.simpleMessage("Ajouter une catégorie"),
        "addContact":
            MessageLookupByLibrary.simpleMessage("Ajouter un contact"),
        "addCustomer":
            MessageLookupByLibrary.simpleMessage("Ajouter un client"),
        "addDelivery":
            MessageLookupByLibrary.simpleMessage("Ajouter une livraison"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("Ajouter une description"),
        "addDescription":
            MessageLookupByLibrary.simpleMessage("Ajouter une note"),
        "addDiscount":
            MessageLookupByLibrary.simpleMessage("Ajouter une remise"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("Ajouter un ID de document"),
        "addDucument":
            MessageLookupByLibrary.simpleMessage("Ajouter un document"),
        "addExpense":
            MessageLookupByLibrary.simpleMessage("Ajouter une dépense"),
        "addExpenseCategory": MessageLookupByLibrary.simpleMessage(
            "Ajouter une catégorie de dépense"),
        "addItems":
            MessageLookupByLibrary.simpleMessage("Ajouter des articles"),
        "addNew": MessageLookupByLibrary.simpleMessage("Ajouter nouveau"),
        "addNewAddress": MessageLookupByLibrary.simpleMessage(
            "Ajouter une nouvelle adresse"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("Ajouter un nouveau produit"),
        "addNewTax":
            MessageLookupByLibrary.simpleMessage("Ajouter une nouvelle taxe"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "Ajouter une nouvelle taxe avec un type de taxe unique/multiple"),
        "addNote": MessageLookupByLibrary.simpleMessage("Ajouter une note"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("Ajoutez d\'abord un produit"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("Ajouter un code promo"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("Ajouter un achat"),
        "addSales": MessageLookupByLibrary.simpleMessage("Ajouter des ventes"),
        "addSuccessful": MessageLookupByLibrary.simpleMessage("Ajout réussi"),
        "addUnit": MessageLookupByLibrary.simpleMessage("Ajouter une unité"),
        "addUserRole": MessageLookupByLibrary.simpleMessage(
            "Ajouter un rôle d\'utilisateur"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("Ajouté avec succès"),
        "addedToCart": MessageLookupByLibrary.simpleMessage("Ajouté au panier"),
        "address": MessageLookupByLibrary.simpleMessage("Adresse"),
        "admin": MessageLookupByLibrary.simpleMessage("Admin"),
        "all": MessageLookupByLibrary.simpleMessage("Tous"),
        "allBusinessSolution": MessageLookupByLibrary.simpleMessage(
            "Toutes les solutions commerciales"),
        "alreadyAdded": MessageLookupByLibrary.simpleMessage("Déjà ajouté"),
        "alreadyExists": MessageLookupByLibrary.simpleMessage("Existe déjà"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("Déjà un compte ?"),
        "amount": MessageLookupByLibrary.simpleMessage("Montant"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "Un e-mail a été envoyé\\nVérifiez votre boîte de réception"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "Prise en charge de l\'application Android et iOS"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("Taxe applicable"),
        "apply": MessageLookupByLibrary.simpleMessage("Appliquer"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "Êtes-vous sûr de vouloir supprimer cette facture"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "Êtes-vous sûr de vouloir supprimer cette vente"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Êtes-vous sûr de vouloir supprimer cet utilisateur ?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "Êtes-vous sûr de vouloir supprimer cette taxe?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "Êtes-vous sûr de vouloir supprimer ce groupe de taxes?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "Voulez-vous supprimer cet entrepôt?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "Êtes-vous sûr de vouloir supprimer cet utilisateur ?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("Signature autorisée"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(b) Sinä olet vastuussa käyttäjätilisi ja salasanasi luottamuksellisuuden ylläpitämisestä sekä käyttöoikeuden rajoittamisesta käyttäjätilillesi. Hyväksyt vastuun kaikista toiminnoista, jotka tapahtuvat käyttäjätilisi alaisuudessa."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(b) Sinun tulee olla vähintään 18 vuotta täyttänyt tai laillisen enemmistöikäinen toimialueesi säännösten mukaan, jotta voit käyttää Järjestelmää."),
        "backSide": MessageLookupByLibrary.simpleMessage("Face arrière"),
        "backToHome":
            MessageLookupByLibrary.simpleMessage("Retour à l\'accueil"),
        "balance": MessageLookupByLibrary.simpleMessage("Solde"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("Bangladesh"),
        "bank": MessageLookupByLibrary.simpleMessage("Banque"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("Devise du compte bancaire"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("Informations bancaires"),
        "bankName": MessageLookupByLibrary.simpleMessage("Nom de la banque"),
        "bankTransfer":
            MessageLookupByLibrary.simpleMessage("Virement bancaire"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("Code-barres trouvé"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("Facture"),
        "billTo": MessageLookupByLibrary.simpleMessage("Facturer à"),
        "branchName":
            MessageLookupByLibrary.simpleMessage("Nom de la succursale"),
        "brand": MessageLookupByLibrary.simpleMessage("Marque"),
        "brandName": MessageLookupByLibrary.simpleMessage("Nom de la marque"),
        "bulkUpload":
            MessageLookupByLibrary.simpleMessage("Téléchargement en masse"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("Catégorie d\'entreprise"),
        "buy": MessageLookupByLibrary.simpleMessage("Acheter"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("Acheter un forfait Premium"),
        "buySms": MessageLookupByLibrary.simpleMessage("Acheter des SMS"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "Kun käytät myyntipisteen (POS) järjestelmää (\"Järjestelmä\"), joka on tarjottu [Yrityksesi Nimi] (\"Yritys\") toimesta, suostut noudattamaan näitä käyttöehtoja. Jos et hyväksy näitä käyttöehtoja, älä käytä Järjestelmää."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(c) Sinä olet vastuussa siitä, että Järjestelmän käyttösi ja pääsysi siihen noudattavat kaikkia soveltuvia lakeja ja säädöksiä."),
        "cacel": MessageLookupByLibrary.simpleMessage("Annuler"),
        "call": MessageLookupByLibrary.simpleMessage("Appeler"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "Appelez pour un support d\'urgence"),
        "camera": MessageLookupByLibrary.simpleMessage("Appareil photo"),
        "cancel": MessageLookupByLibrary.simpleMessage("Annuler"),
        "cancelAllProduct":
            MessageLookupByLibrary.simpleMessage("Annuler tous les produits"),
        "capacity": MessageLookupByLibrary.simpleMessage("Capacité"),
        "card": MessageLookupByLibrary.simpleMessage("Carte"),
        "cash": MessageLookupByLibrary.simpleMessage("Espèces"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("Catégories"),
        "category": MessageLookupByLibrary.simpleMessage("Catégorie"),
        "categoryName":
            MessageLookupByLibrary.simpleMessage("Nom de la catégorie"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "Le nom de la catégorie existe déjà"),
        "cateogryName":
            MessageLookupByLibrary.simpleMessage("Nom de la catégorie"),
        "change": MessageLookupByLibrary.simpleMessage("Modifier ?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Changer le mot de passe"),
        "checkEmail":
            MessageLookupByLibrary.simpleMessage("Vérifier le courriel"),
        "choseACustomer":
            MessageLookupByLibrary.simpleMessage("Choisissez un client"),
        "choseASupplier":
            MessageLookupByLibrary.simpleMessage("Choisissez un fournisseur"),
        "choseYourFeature": MessageLookupByLibrary.simpleMessage(
            "Choisissez vos fonctionnalités"),
        "clarence": MessageLookupByLibrary.simpleMessage("Clarence"),
        "clickToConnect":
            MessageLookupByLibrary.simpleMessage("Cliquez pour vous connecter"),
        "close": MessageLookupByLibrary.simpleMessage("Fermer"),
        "color": MessageLookupByLibrary.simpleMessage("Couleur"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(Combinaison de plusieurs taxes)"),
        "comingSoon":
            MessageLookupByLibrary.simpleMessage("Bientôt disponible"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("Adresse de l\'entreprise"),
        "companyAndShopName": MessageLookupByLibrary.simpleMessage(
            "Nom de la société et du magasin"),
        "companyBusinessName": MessageLookupByLibrary.simpleMessage(
            "Nom de l\'entreprise et du commerce"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("Terminer la transaction"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Confirmer le mot de passe"),
        "confirmReturn":
            MessageLookupByLibrary.simpleMessage("Confirmer le retour"),
        "congratulations":
            MessageLookupByLibrary.simpleMessage("Félicitations"),
        "contactUs": MessageLookupByLibrary.simpleMessage("Contactez-nous"),
        "continu": MessageLookupByLibrary.simpleMessage("Continuer"),
        "country": MessageLookupByLibrary.simpleMessage("Pays"),
        "create": MessageLookupByLibrary.simpleMessage("Créer"),
        "createAFreeAccounts":
            MessageLookupByLibrary.simpleMessage("Créer un compte gratuit"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("Créé et enregistré"),
        "currency": MessageLookupByLibrary.simpleMessage("Devise"),
        "currentStock": MessageLookupByLibrary.simpleMessage("Stock actuel"),
        "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
            "Personnalisation de la facturation"),
        "customer": MessageLookupByLibrary.simpleMessage("Client"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("Détails du client"),
        "customerGST": MessageLookupByLibrary.simpleMessage("GST du client"),
        "customerName": MessageLookupByLibrary.simpleMessage("Nom du client"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("Transaction quotidienne"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("Kojelautan yleiskatsaus"),
        "dataSavedSuccessfully": MessageLookupByLibrary.simpleMessage(
            "Données enregistrées avec succès"),
        "date": MessageLookupByLibrary.simpleMessage("Date"),
        "day": MessageLookupByLibrary.simpleMessage("Jour"),
        "dealer": MessageLookupByLibrary.simpleMessage("Revendeur"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("Prix revendeur"),
        "defaultVATPercentage": MessageLookupByLibrary.simpleMessage(
            "Pourcentage de TVA par défaut"),
        "delete": MessageLookupByLibrary.simpleMessage("Supprimer"),
        "deleting": MessageLookupByLibrary.simpleMessage("Suppression"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("Adresse de livraison"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("Adresses de livraison"),
        "deliveryCharge":
            MessageLookupByLibrary.simpleMessage("Frais de livraison"),
        "describtion": MessageLookupByLibrary.simpleMessage("Description"),
        "description": MessageLookupByLibrary.simpleMessage("Description"),
        "descriptionCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "La description ne peut pas être vide"),
        "details": MessageLookupByLibrary.simpleMessage("Détails"),
        "discount": MessageLookupByLibrary.simpleMessage("Remise"),
        "doNotDistrub": MessageLookupByLibrary.simpleMessage("Ne pas déranger"),
        "done": MessageLookupByLibrary.simpleMessage("Fait"),
        "downloadExcelFormat":
            MessageLookupByLibrary.simpleMessage("Télécharger le format Excel"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "Téléchargé avec succès dans le dossier de téléchargement"),
        "due": MessageLookupByLibrary.simpleMessage("Dû"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("Montant dû : "),
        "dueCollection":
            MessageLookupByLibrary.simpleMessage("Recouvrement des impayés"),
        "dueCollectionReports": MessageLookupByLibrary.simpleMessage(
            "Rapports de recouvrement dus"),
        "dueList": MessageLookupByLibrary.simpleMessage("Liste des impayés"),
        "dueReports": MessageLookupByLibrary.simpleMessage("Rapport dû"),
        "duration": MessageLookupByLibrary.simpleMessage("Durée"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("Durée : De"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "Terminal de paiement mobile facile à utiliser"),
        "edit": MessageLookupByLibrary.simpleMessage("Modifier"),
        "editPurchaseInvoice": MessageLookupByLibrary.simpleMessage(
            "Modifier la facture d\'achat"),
        "editSalesInvoice": MessageLookupByLibrary.simpleMessage(
            "Modifier la facture de vente"),
        "editSocailMedia":
            MessageLookupByLibrary.simpleMessage("Modifier les médias sociaux"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("Modifié avec succès"),
        "editTax": MessageLookupByLibrary.simpleMessage("Modifier la taxe"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("Modifier le groupe de taxes"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("Modifier l\'entrepôt"),
        "email": MessageLookupByLibrary.simpleMessage("Courriel"),
        "emailAddress":
            MessageLookupByLibrary.simpleMessage("Adresse courriel"),
        "emailCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "L\'email ne peut pas être vide"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "Email envoyé ! Vérifiez votre boîte de réception"),
        "endDate": MessageLookupByLibrary.simpleMessage("Date de fin"),
        "enterAValidAmount":
            MessageLookupByLibrary.simpleMessage("Entrez un montant valide"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("Entrez une remise valide"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Entrez un numéro de téléphone valide"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("Entrez un prix valide"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("Entrez une quantité valide"),
        "enterAddress":
            MessageLookupByLibrary.simpleMessage("Entrez l\'adresse"),
        "enterAmount":
            MessageLookupByLibrary.simpleMessage("Entrez le montant"),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("Entrez le nom de la marque"),
        "enterCapacity":
            MessageLookupByLibrary.simpleMessage("Entrez la capacité"),
        "enterCategoryName": MessageLookupByLibrary.simpleMessage(
            "Entrez le nom de la catégorie"),
        "enterColor": MessageLookupByLibrary.simpleMessage("Entrez la couleur"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "Entrez le numéro GST du client"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("Entrez le prix revendeur"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("Entrez la description"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("Entrez la remise."),
        "enterExpenseDate": MessageLookupByLibrary.simpleMessage(
            "Entrez la date de la dépense"),
        "enterFullAddress":
            MessageLookupByLibrary.simpleMessage("Entrez l\'adresse complète"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("Entrez le numéro de facture"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "Entrez la quantité d\'alerte de faible stock"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("Entrez le fabricant"),
        "enterMessageContent": MessageLookupByLibrary.simpleMessage(
            "Entrez le contenu du message"),
        "enterMrpOrRetailerPirce": MessageLookupByLibrary.simpleMessage(
            "Entrez le prix de détail/prix au détail"),
        "enterName": MessageLookupByLibrary.simpleMessage("Entrez un nom"),
        "enterNote": MessageLookupByLibrary.simpleMessage("Entrez une note"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("Entrez le nom de la partie"),
        "enterPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Entrez le numéro de téléphone"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "Entrez le code produit ou scannez"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("Entrez le nom du produit"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("Entrez le prix d\'achat."),
        "enterReferenceNumber": MessageLookupByLibrary.simpleMessage(
            "Entrez le numéro de référence"),
        "enterSize": MessageLookupByLibrary.simpleMessage("Entrez la taille"),
        "enterStocks":
            MessageLookupByLibrary.simpleMessage("Entrez les stocks."),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("Entrez le taux de taxe"),
        "enterTransactionId": MessageLookupByLibrary.simpleMessage(
            "Entrez l\'identifiant de la transaction"),
        "enterType": MessageLookupByLibrary.simpleMessage("Entrez le type"),
        "enterUserTitle": MessageLookupByLibrary.simpleMessage(
            "Entrez le titre de l\'utilisateur"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("Entrez un montant valide"),
        "enterWarehouseName": MessageLookupByLibrary.simpleMessage(
            "Entrez le nom de l\'entrepôt"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("Entrez le poids"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("Entrez le prix de gros"),
        "enterYourDescriptionHere": MessageLookupByLibrary.simpleMessage(
            "Entrez votre description ici"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "Entrez votre adresse courriel"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "Entrez le titre de vos commentaires"),
        "enterYourGSTNumber":
            MessageLookupByLibrary.simpleMessage("Entrez votre numéro GST"),
        "enterYourMobileNumber": MessageLookupByLibrary.simpleMessage(
            "Entrez votre numéro de téléphone mobile"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("Entrez votre nom"),
        "enterYourNumber": MessageLookupByLibrary.simpleMessage(
            "Entrez votre numéro de téléphone"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("Entrez votre mot de passe"),
        "enterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Entrez votre numéro de téléphone"),
        "enterYourTransactionId": MessageLookupByLibrary.simpleMessage(
            "Entrez votre ID de transaction"),
        "error": MessageLookupByLibrary.simpleMessage("Erreur"),
        "excTax": MessageLookupByLibrary.simpleMessage("TVA exclue"),
        "excelUploader":
            MessageLookupByLibrary.simpleMessage("Téléchargeur Excel"),
        "exclusive": MessageLookupByLibrary.simpleMessage("Exclusif"),
        "expense": MessageLookupByLibrary.simpleMessage("Dépense"),
        "expenseCategory":
            MessageLookupByLibrary.simpleMessage("Catégorie de dépense"),
        "expenseDate":
            MessageLookupByLibrary.simpleMessage("Date de la dépense"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("Dépense pour"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("Rapport de dépenses"),
        "expireDate":
            MessageLookupByLibrary.simpleMessage("Date d\'expiration"),
        "expired": MessageLookupByLibrary.simpleMessage("Expiré"),
        "expiring": MessageLookupByLibrary.simpleMessage("Expirant"),
        "facebok": MessageLookupByLibrary.simpleMessage("Facebook"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("Échec avec erreur"),
        "fashion": MessageLookupByLibrary.simpleMessage("Mode"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "Les fonctionnalités sont la partie importante qui rend Pos Saas différent des solutions traditionnelles."),
        "feedBack": MessageLookupByLibrary.simpleMessage("Commentaires"),
        "firstName": MessageLookupByLibrary.simpleMessage("Prénom"),
        "followUsOnFacebook":
            MessageLookupByLibrary.simpleMessage("Suivez-nous sur\nFacebook"),
        "followUsOnTwitter":
            MessageLookupByLibrary.simpleMessage("Suivez-nous sur\nTwitter"),
        "fontSide": MessageLookupByLibrary.simpleMessage("Face avant"),
        "forUnlimitedUses": MessageLookupByLibrary.simpleMessage(
            "Pour des utilisations illimitées"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Mot de passe oublié"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("Mot de passe oublié ?"),
        "formDate": MessageLookupByLibrary.simpleMessage("De la date"),
        "freeDataBackup": MessageLookupByLibrary.simpleMessage(
            "Sauvegarde des données gratuite"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("Forfait gratuit"),
        "freePlan": MessageLookupByLibrary.simpleMessage("Plan gratuit"),
        "from": MessageLookupByLibrary.simpleMessage("(De"),
        "fullyPaid": MessageLookupByLibrary.simpleMessage("Entièrement payé"),
        "gallary": MessageLookupByLibrary.simpleMessage("Galerie"),
        "generatingPDF":
            MessageLookupByLibrary.simpleMessage("Génération de PDF"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Obtenir le code OTP"),
        "govermentId":
            MessageLookupByLibrary.simpleMessage("Identifiant gouvernemental"),
        "guest": MessageLookupByLibrary.simpleMessage("Invité"),
        "havenotAnAccounts": MessageLookupByLibrary.simpleMessage(
            "Vous n\'avez pas de compte ?"),
        "history": MessageLookupByLibrary.simpleMessage("Historique"),
        "home": MessageLookupByLibrary.simpleMessage("Accueil"),
        "howWeProtectYourInformation":
            MessageLookupByLibrary.simpleMessage("Miten suojaamme tietojasi"),
        "howWeUseYourInformation":
            MessageLookupByLibrary.simpleMessage("Miten käytämme tietojasi"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("Vérification d\'identité"),
        "image": MessageLookupByLibrary.simpleMessage("Image"),
        "inHouseCantBeDelete": MessageLookupByLibrary.simpleMessage(
            "L\'interne ne peut pas être supprimé"),
        "inHouseCantBeEdited": MessageLookupByLibrary.simpleMessage(
            "L\'interne ne peut pas être modifié"),
        "inWord": MessageLookupByLibrary.simpleMessage("En mots"),
        "incTax": MessageLookupByLibrary.simpleMessage("TVA incluse"),
        "inclusive": MessageLookupByLibrary.simpleMessage("Inclusif"),
        "increaseStock":
            MessageLookupByLibrary.simpleMessage("Augmenter le stock"),
        "inistrument": MessageLookupByLibrary.simpleMessage("Instrument"),
        "instragram": MessageLookupByLibrary.simpleMessage("Instagram"),
        "invNo": MessageLookupByLibrary.simpleMessage("N° Inv."),
        "invoice": MessageLookupByLibrary.simpleMessage("Facture"),
        "invoiceNumber":
            MessageLookupByLibrary.simpleMessage("Numéro de facture"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("Paramètres de facturation"),
        "invoiceViewer":
            MessageLookupByLibrary.simpleMessage("Visionneuse de factures"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("Article ajouté"),
        "kg": MessageLookupByLibrary.simpleMessage("Kg"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("Vérification KYC"),
        "language": MessageLookupByLibrary.simpleMessage("Langue"),
        "lastName": MessageLookupByLibrary.simpleMessage("Nom de famille"),
        "ledger": MessageLookupByLibrary.simpleMessage("Grand livre"),
        "lifeTimePurchase": MessageLookupByLibrary.simpleMessage("Achat à vie"),
        "link": MessageLookupByLibrary.simpleMessage("Lien"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("LinkedIn"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("Support par chat en direct"),
        "loading": MessageLookupByLibrary.simpleMessage("Chargement"),
        "logIn": MessageLookupByLibrary.simpleMessage("Se connecter"),
        "logOUt": MessageLookupByLibrary.simpleMessage("Déconnexion"),
        "logOut": MessageLookupByLibrary.simpleMessage("Se déconnecter"),
        "login": MessageLookupByLibrary.simpleMessage("Se connecter"),
        "logo": MessageLookupByLibrary.simpleMessage("Logo"),
        "loss": MessageLookupByLibrary.simpleMessage("Perte"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("Perte/Profit"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("Détails de perte/profit"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("Rapport de pertes/profits"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("Rapports de pertes/profits"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("Alerte de faible stock"),
        "maan": MessageLookupByLibrary.simpleMessage("Maan"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "Faites une impression durable sur vos clients avec des factures personnalisées. Notre mise à niveau illimitée offre l\'avantage unique de personnaliser vos factures, ajoutant une touche professionnelle qui renforce votre identité de marque et favorise la fidélité des clients."),
        "manageYourBussinessWith":
            MessageLookupByLibrary.simpleMessage("Gérez votre entreprise avec"),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("Date de fabrication"),
        "margin": MessageLookupByLibrary.simpleMessage("Marge"),
        "masterCard": MessageLookupByLibrary.simpleMessage("Carte Master"),
        "menufeturer": MessageLookupByLibrary.simpleMessage("Fabricant"),
        "message": MessageLookupByLibrary.simpleMessage("Message"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("Historique des messages"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "L\'application Pos Saas est gratuite et facile à utiliser. En fait, c\'est l\'un des meilleurs systèmes de point de vente au monde."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "Pos Saas est une solution commerciale complète avec des fonctionnalités de stock, de comptabilité, de ventes, de dépenses et de pertes/profits."),
        "mobile": MessageLookupByLibrary.simpleMessage("Mobile"),
        "mobilePayment":
            MessageLookupByLibrary.simpleMessage("Paiement mobile"),
        "monthly": MessageLookupByLibrary.simpleMessage("Mensuel"),
        "moreInfo":
            MessageLookupByLibrary.simpleMessage("Plus d\'informations"),
        "name": MessageLookupByLibrary.simpleMessage("Entrez votre nom"),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("Le nom existe déjà"),
        "nameCantBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Le nom ne peut pas être vide"),
        "next": MessageLookupByLibrary.simpleMessage("Suivant"),
        "noConnection":
            MessageLookupByLibrary.simpleMessage("Pas de connexion"),
        "noData": MessageLookupByLibrary.simpleMessage("Aucune donnée"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("Aucune donnée disponible"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("Aucune donnée trouvée"),
        "noHistoryFound":
            MessageLookupByLibrary.simpleMessage("Aucun historique trouvé !"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("Aucun produit trouvé"),
        "noSubTaxSelected": MessageLookupByLibrary.simpleMessage(
            "Aucune sous-taxe sélectionnée"),
        "noTransactionFound": MessageLookupByLibrary.simpleMessage(
            "Aucune transaction trouvée !"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "Aucun utilisateur trouvé pour cette adresse courriel."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "Aucun rôle d\'utilisateur trouvé"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("Utilisateur non actif"),
        "notProvided": MessageLookupByLibrary.simpleMessage("Non fourni"),
        "note": MessageLookupByLibrary.simpleMessage("Note"),
        "notes": MessageLookupByLibrary.simpleMessage("Notes"),
        "notification": MessageLookupByLibrary.simpleMessage("Notification"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP envoyé à"),
        "office": MessageLookupByLibrary.simpleMessage("Bureau"),
        "ok": MessageLookupByLibrary.simpleMessage("OK"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "POS-järjestelmä, joka sisältää runsaasti toiminnallisuuksia, mukaan lukien myynnin seuranta ja varastonhallinta."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "Tämä järjestelmä auttaa sinua parantamaan toimintojasi asiakkaittesi hyväksi."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "POS-järjestelmämme tulisi automaattisesti yksinkertaistaa päivittäisiä toimintoja, tehdä niiden navigoinnista helppoa."),
        "openingBalance":
            MessageLookupByLibrary.simpleMessage("Solde d\'ouverture"),
        "order": MessageLookupByLibrary.simpleMessage("Commandes"),
        "other": MessageLookupByLibrary.simpleMessage("Autre"),
        "otp": MessageLookupByLibrary.simpleMessage("Fermer"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("Rupture de stock"),
        "pacakge": MessageLookupByLibrary.simpleMessage("Paquet"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("Fonctionnalités du forfait"),
        "paid": MessageLookupByLibrary.simpleMessage("Payé"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("Montant payé"),
        "parties": MessageLookupByLibrary.simpleMessage("Parties"),
        "partiesList":
            MessageLookupByLibrary.simpleMessage("Liste des parties"),
        "partyGST": MessageLookupByLibrary.simpleMessage("GST de la partie"),
        "partyName": MessageLookupByLibrary.simpleMessage("Nom de la partie"),
        "password": MessageLookupByLibrary.simpleMessage("Mot de passe"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Le mot de passe et la confirmation ne correspondent pas"),
        "passwordCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Le mot de passe ne peut pas être vide"),
        "passwordNotMach": MessageLookupByLibrary.simpleMessage(
            "Le mot de passe ne correspond pas"),
        "payCash": MessageLookupByLibrary.simpleMessage("Payer en espèces"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("Payer avec bkash"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("Payer avec Paypal"),
        "payeeName":
            MessageLookupByLibrary.simpleMessage("Nom du bénéficiaire"),
        "payeeNumber":
            MessageLookupByLibrary.simpleMessage("Numéro du bénéficiaire"),
        "payment": MessageLookupByLibrary.simpleMessage("Paiement"),
        "paymentAmount":
            MessageLookupByLibrary.simpleMessage("Montant du paiement"),
        "paymentComplete":
            MessageLookupByLibrary.simpleMessage("Paiement effectué"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("Instructions de paiement :"),
        "paymentMethod":
            MessageLookupByLibrary.simpleMessage("Méthode de paiement"),
        "paymentType": MessageLookupByLibrary.simpleMessage("Type de paiement"),
        "pdfView": MessageLookupByLibrary.simpleMessage("Vue PDF"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("Informations personnelles"),
        "phone": MessageLookupByLibrary.simpleMessage("Téléphone"),
        "phoneNumber":
            MessageLookupByLibrary.simpleMessage("Numéro de téléphone"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "Le numéro de téléphone est déjà utilisé"),
        "phoneNumberIsNotValid": MessageLookupByLibrary.simpleMessage(
            "Le numéro de téléphone n\'est pas valide"),
        "phoneNumberIsRequired": MessageLookupByLibrary.simpleMessage(
            "Le numéro de téléphone est requis"),
        "pickAndUploadFile": MessageLookupByLibrary.simpleMessage(
            "Choisir et télécharger le fichier"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("Choisissez une date de fin"),
        "pickStartDate": MessageLookupByLibrary.simpleMessage(
            "Choisissez une date de début"),
        "plan": MessageLookupByLibrary.simpleMessage("Plan"),
        "pleaseAddQuantity": MessageLookupByLibrary.simpleMessage(
            "Veuillez ajouter une quantité"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "Veuillez vérifier votre connectivité Internet"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "Veuillez d\'abord connecter l\'imprimante"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "Veuillez connecter votre imprimante Bluetooth"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "Veuillez entrer un mot de passe plus long"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Veuillez entrer un mot de passe de confirmation"),
        "pleaseEnterAPassword": MessageLookupByLibrary.simpleMessage(
            "Veuillez entrer un mot de passe"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "Veuillez entrer un email valide"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("Veuillez entrer le nom"),
        "pleaseEnterPassword": MessageLookupByLibrary.simpleMessage(
            "Veuillez entrer le mot de passe"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "Veuillez entrer votre adresse courriel ci-dessous pour recevoir le lien de réinitialisation du mot de passe."),
        "pleaseEnterTransactionNumber": MessageLookupByLibrary.simpleMessage(
            "Veuillez entrer le numéro de transaction"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("Veuillez entrer le montant"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "Veuillez sélectionner une catégorie d\'abord"),
        "pleaseSelectAPlan": MessageLookupByLibrary.simpleMessage(
            "Veuillez sélectionner un plan"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "Veuillez sélectionner une catégorie d\'entreprise"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "Veuillez utiliser le code d\'achat valide pour utiliser l\'application"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("Propulsé par Pos Saas"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("Propulsé par"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("Support client premium"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("Forfait Premium"),
        "previousPayAmounts": MessageLookupByLibrary.simpleMessage(
            "Montants de paiement précédents"),
        "price": MessageLookupByLibrary.simpleMessage("Prix"),
        "print": MessageLookupByLibrary.simpleMessage("Imprimer"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("Options d\'impression"),
        "privacyPolicy": MessageLookupByLibrary.simpleMessage(
            "Politique de confidentialité"),
        "product": MessageLookupByLibrary.simpleMessage("Produit"),
        "productCode": MessageLookupByLibrary.simpleMessage("Code produit"),
        "productCodeIsRequired": MessageLookupByLibrary.simpleMessage(
            "Le code du produit est requis"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("Code/Nom du produit"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("Description du produit"),
        "productDetails":
            MessageLookupByLibrary.simpleMessage("Détails du produit"),
        "productList":
            MessageLookupByLibrary.simpleMessage("Liste des produits"),
        "productName": MessageLookupByLibrary.simpleMessage("Nom du produit"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "Le nom du produit existe déjà dans cet entrepôt"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "Le nom du produit est déjà ajouté"),
        "productNameIsRequired": MessageLookupByLibrary.simpleMessage(
            "Le nom du produit est requis"),
        "products": MessageLookupByLibrary.simpleMessage("Produits"),
        "profile": MessageLookupByLibrary.simpleMessage("Profil"),
        "profileEdit":
            MessageLookupByLibrary.simpleMessage("Modifier le profil"),
        "profit": MessageLookupByLibrary.simpleMessage("Profit"),
        "promo": MessageLookupByLibrary.simpleMessage("promo"),
        "promoCode": MessageLookupByLibrary.simpleMessage("Code promo"),
        "purchase": MessageLookupByLibrary.simpleMessage("Achat"),
        "purchaseAlarm":
            MessageLookupByLibrary.simpleMessage("Alarme d\'achat"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("Achat confirmé"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("Détails de l\'achat"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("Facture d\'achat"),
        "purchaseList":
            MessageLookupByLibrary.simpleMessage("Liste des achats"),
        "purchaseNow":
            MessageLookupByLibrary.simpleMessage("Achetez maintenant"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("Acheter un forfait Premium"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("Prix d\'achat"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("Le prix d\'achat est requis"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("Rapport d\'achat"),
        "purchaseReports":
            MessageLookupByLibrary.simpleMessage("Rapport d\'achat"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("Rapports d\'achat"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("Retour d\'achat"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("Rapport de retour d\'achat"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("Transition d\'achat"),
        "qty": MessageLookupByLibrary.simpleMessage("Qté"),
        "quantity": MessageLookupByLibrary.simpleMessage("Quantité"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("Transactions récentes"),
        "recivedThePin": MessageLookupByLibrary.simpleMessage("PIN reçu"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("Numéro de référence"),
        "register": MessageLookupByLibrary.simpleMessage("S\'inscrire"),
        "registering": MessageLookupByLibrary.simpleMessage("Enregistrement"),
        "remainingDue": MessageLookupByLibrary.simpleMessage("Solde restant"),
        "remove": MessageLookupByLibrary.simpleMessage("Supprimer"),
        "reports": MessageLookupByLibrary.simpleMessage("Rapports"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("La demande a été envoyée"),
        "resendCode": MessageLookupByLibrary.simpleMessage("Renvoyer le code"),
        "resendOtp":
            MessageLookupByLibrary.simpleMessage("Renvoyer le code OTP : "),
        "retailer": MessageLookupByLibrary.simpleMessage("Détaillant"),
        "retur": MessageLookupByLibrary.simpleMessage("Retour"),
        "returN": MessageLookupByLibrary.simpleMessage("Retour"),
        "returnAMount":
            MessageLookupByLibrary.simpleMessage("Montant du retour"),
        "returnAmount":
            MessageLookupByLibrary.simpleMessage("Montant du retour"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("Quantité de retour"),
        "revenue": MessageLookupByLibrary.simpleMessage("Revenus"),
        "saleAmount":
            MessageLookupByLibrary.simpleMessage("Montant de la vente"),
        "saleDetails":
            MessageLookupByLibrary.simpleMessage("Détails de la vente"),
        "salePrice": MessageLookupByLibrary.simpleMessage("Prix de vente"),
        "saleReports": MessageLookupByLibrary.simpleMessage("Rapport de vente"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("Rapports de vente"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("Retour de vente"),
        "saleReturnReport":
            MessageLookupByLibrary.simpleMessage("Rapport de retour de vente"),
        "saleSetting":
            MessageLookupByLibrary.simpleMessage("Paramètres de vente"),
        "sales": MessageLookupByLibrary.simpleMessage("Ventes"),
        "salesAndPurchaseReports":
            MessageLookupByLibrary.simpleMessage("Myynti- ja ostoraportit"),
        "salesList": MessageLookupByLibrary.simpleMessage("Liste des ventes"),
        "salesReturn": MessageLookupByLibrary.simpleMessage("Retour de vente"),
        "save": MessageLookupByLibrary.simpleMessage("Enregistrer"),
        "saveAndPublish":
            MessageLookupByLibrary.simpleMessage("Enregistrer et publier"),
        "saveChanges": MessageLookupByLibrary.simpleMessage(
            "Enregistrer les modifications"),
        "saving": MessageLookupByLibrary.simpleMessage("Enregistrement"),
        "scanProductQRCode": MessageLookupByLibrary.simpleMessage(
            "Scanner le code QR du produit"),
        "search": MessageLookupByLibrary.simpleMessage("Rechercher"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "Recherchez par code ou nom de produit"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("Voir tous les codes promo"),
        "select": MessageLookupByLibrary.simpleMessage("Sélectionner"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "Sélectionnez un produit pour le retour"),
        "selectBrand":
            MessageLookupByLibrary.simpleMessage("Sélectionnez la marque"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("Sélectionner une catégorie"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("Sélectionner des contacts"),
        "selectProductCategory": MessageLookupByLibrary.simpleMessage(
            "Sélectionnez la catégorie de produit"),
        "selectShopCategory": MessageLookupByLibrary.simpleMessage(
            "Sélectionnez la catégorie de magasin"),
        "selectTax":
            MessageLookupByLibrary.simpleMessage("Sélectionnez la taxe"),
        "selectTaxType": MessageLookupByLibrary.simpleMessage(
            "Sélectionnez le type de taxe"),
        "selectUnit":
            MessageLookupByLibrary.simpleMessage("Sélectionnez l\'unité"),
        "selectvariations":
            MessageLookupByLibrary.simpleMessage("Sélectionner la variation :"),
        "seller": MessageLookupByLibrary.simpleMessage("Vendeur"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("Vendu par"),
        "send": MessageLookupByLibrary.simpleMessage("Envoyer"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("Envoyer un e-mail"),
        "sendMessage":
            MessageLookupByLibrary.simpleMessage("Envoyer le message"),
        "sendResetLink": MessageLookupByLibrary.simpleMessage(
            "Envoyer le lien de réinitialisation"),
        "sendSms": MessageLookupByLibrary.simpleMessage("Envoyer un SMS"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("Envoyer un SMS ?"),
        "sendWhatsappMessage":
            MessageLookupByLibrary.simpleMessage("Envoyer un message WhatsApp"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("Envoyez votre e-mail"),
        "sendingEmail": MessageLookupByLibrary.simpleMessage("Envoi d\'email"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("Envoi du message"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("Service/Expédition"),
        "setUpYourProfile":
            MessageLookupByLibrary.simpleMessage("Configurer votre profil"),
        "setting": MessageLookupByLibrary.simpleMessage("Paramètres"),
        "share": MessageLookupByLibrary.simpleMessage("Partager"),
        "shopGST": MessageLookupByLibrary.simpleMessage("GST du magasin"),
        "signIn": MessageLookupByLibrary.simpleMessage("Se connecter"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("Se connecter avec un email"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("Signature du client"),
        "size": MessageLookupByLibrary.simpleMessage("Taille"),
        "skip": MessageLookupByLibrary.simpleMessage("Passer"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("Marketing social"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "Désolé, vous n\'avez pas la permission d\'accéder à ce service"),
        "startDate": MessageLookupByLibrary.simpleMessage("Date de début"),
        "startNewSale": MessageLookupByLibrary.simpleMessage(
            "Commencer une nouvelle vente"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage(
            "Commencez à taper pour rechercher"),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("Encore impayé"),
        "stock": MessageLookupByLibrary.simpleMessage("Stock"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("Le stock est requis"),
        "stockList": MessageLookupByLibrary.simpleMessage("Liste des stocks"),
        "stocks": MessageLookupByLibrary.simpleMessage("Stocks"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "La permission de stockage est requise pour créer un fichier Excel"),
        "subTaxList":
            MessageLookupByLibrary.simpleMessage("Liste des sous-taxes"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("Sous-taxes"),
        "subTotal": MessageLookupByLibrary.simpleMessage("Sous-total"),
        "submit": MessageLookupByLibrary.simpleMessage("Soumettre"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "Abonnez-vous à notre\nYoutube"),
        "subscription": MessageLookupByLibrary.simpleMessage("Abonnement"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("Fait avec succès"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("Déconnexion réussie"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("Mis à jour avec succès"),
        "supplier": MessageLookupByLibrary.simpleMessage("Fournisseur"),
        "supplierName":
            MessageLookupByLibrary.simpleMessage("Nom du fournisseur"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("Code SWIFT"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "Prenez un permis de conduire, une carte d\'identité nationale ou une photo de passeport"),
        "takeaNidCardToCheckYourInformation": MessageLookupByLibrary.simpleMessage(
            "Prenez une carte d\'identité nationale pour vérifier vos informations"),
        "tap": MessageLookupByLibrary.simpleMessage("Tapez"),
        "tax": MessageLookupByLibrary.simpleMessage("Taxe"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("Groupe de taxe"),
        "taxPercentage":
            MessageLookupByLibrary.simpleMessage("Pourcentage de taxe"),
        "taxRate": MessageLookupByLibrary.simpleMessage("Taux de taxe"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "Taux de taxe - Gérez vos taux de taxe"),
        "taxReport": MessageLookupByLibrary.simpleMessage("Rapport fiscal"),
        "taxType": MessageLookupByLibrary.simpleMessage("Type de taxe"),
        "taxes": MessageLookupByLibrary.simpleMessage("Taxes"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Conditions générales"),
        "termsOfUse":
            MessageLookupByLibrary.simpleMessage("Conditions d\'utilisation"),
        "termsPrivacy": MessageLookupByLibrary.simpleMessage(
            "Conditions & Confidentialité"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "Merci pour votre paiement dû"),
        "thankYou": MessageLookupByLibrary.simpleMessage("Merci"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("Merci pour votre achat"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "Le compte existe déjà pour cet e-mail"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "Le fichier Excel a déjà été téléchargé"),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "Le mot de passe fourni est trop faible"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "La vente sera supprimée et toutes les données concernant cet achat seront supprimées. Êtes-vous sûr de vouloir supprimer cela ?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "La vente sera supprimée et toutes les données concernant cette vente seront supprimées. Êtes-vous sûr de vouloir supprimer cela ?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "L\'utilisateur sera supprimé et toutes les données seront supprimées de votre compte. Êtes-vous sûr de vouloir supprimer ceci ?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "L\'utilisateur sera supprimé et toutes les données seront supprimées de votre compte. Êtes-vous sûr de vouloir le supprimer ?"),
        "thirdPartyServices": MessageLookupByLibrary.simpleMessage(
            "Kolmannen osapuolen palvelut"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "Cette catégorie ne peut pas être supprimée"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(Ce mois-ci)"),
        "thisProductAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("Ce produit est déjà ajouté"),
        "title": MessageLookupByLibrary.simpleMessage("Titre"),
        "titleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Le titre ne peut pas être vide"),
        "to": MessageLookupByLibrary.simpleMessage("à"),
        "toDate": MessageLookupByLibrary.simpleMessage("À la date"),
        "today": MessageLookupByLibrary.simpleMessage("Aujourd\'hui"),
        "total": MessageLookupByLibrary.simpleMessage("Total"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("Montant total"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("Total collecté"),
        "totalDue": MessageLookupByLibrary.simpleMessage("Total dû"),
        "totalExpense":
            MessageLookupByLibrary.simpleMessage("Total des dépenses"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("Perte totale"),
        "totalPayable": MessageLookupByLibrary.simpleMessage("Total à payer"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("Prix total"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("Total des produits"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("Profit total"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("Achat total"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("Montant total du retour"),
        "totalReturns":
            MessageLookupByLibrary.simpleMessage("Total des retours"),
        "totalSale": MessageLookupByLibrary.simpleMessage("Total des ventes"),
        "totalStock": MessageLookupByLibrary.simpleMessage("Stock total"),
        "totalValue": MessageLookupByLibrary.simpleMessage("Valeur totale"),
        "totalVat": MessageLookupByLibrary.simpleMessage("Total TVA"),
        "totals": MessageLookupByLibrary.simpleMessage("Total :"),
        "transaction": MessageLookupByLibrary.simpleMessage("Transaction"),
        "transactionId":
            MessageLookupByLibrary.simpleMessage("ID de transaction"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("Réessayez"),
        "twitter": MessageLookupByLibrary.simpleMessage("Twitter"),
        "type": MessageLookupByLibrary.simpleMessage("Type"),
        "unitName": MessageLookupByLibrary.simpleMessage("Nom de l\'unité"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("Prix unitaire"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("Prix unitaire"),
        "units": MessageLookupByLibrary.simpleMessage("Unités"),
        "unlimited": MessageLookupByLibrary.simpleMessage("Illimité"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("Utilisation illimitée"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Débloquez le plein potentiel de Pos Saas POS avec des sessions de formation personnalisées dirigées par notre équipe d\'experts. Des bases aux techniques avancées, nous veillons à ce que vous maîtrisiez toutes les facettes du système pour optimiser vos processus commerciaux."),
        "unpaid": MessageLookupByLibrary.simpleMessage("Impayé"),
        "update": MessageLookupByLibrary.simpleMessage("Mettre à jour"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("Mettre à jour le contact"),
        "updateNow":
            MessageLookupByLibrary.simpleMessage("Mettre à jour maintenant"),
        "updateProduct":
            MessageLookupByLibrary.simpleMessage("Mettre à jour le produit"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "Mettez à jour votre plan d\'abord, votre limite est dépassée"),
        "updateYourProfile":
            MessageLookupByLibrary.simpleMessage("Mettez à jour votre profil"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "Mettez à jour votre profil pour connecter votre médecin avec une meilleure impression"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "Mettez à jour votre profil pour mieux connecter votre client"),
        "updated": MessageLookupByLibrary.simpleMessage("Mis à jour"),
        "upload": MessageLookupByLibrary.simpleMessage("Télécharger"),
        "uploadDocument":
            MessageLookupByLibrary.simpleMessage("Télécharger un document"),
        "uploadDone":
            MessageLookupByLibrary.simpleMessage("Téléchargement terminé"),
        "uploadFile":
            MessageLookupByLibrary.simpleMessage("Télécharger un fichier"),
        "upplier": MessageLookupByLibrary.simpleMessage("Fournisseur"),
        "usbC": MessageLookupByLibrary.simpleMessage("Usb C"),
        "use": MessageLookupByLibrary.simpleMessage("Utiliser"),
        "useMobiPos": MessageLookupByLibrary.simpleMessage("Utilisez Pos Saas"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("Järjestelmän käyttö"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("L\'utilisateur est supprimé"),
        "userRole":
            MessageLookupByLibrary.simpleMessage("Rôle de l\'utilisateur"),
        "userRoleDetails": MessageLookupByLibrary.simpleMessage(
            "Détails du rôle de l\'utilisateur"),
        "userTitle":
            MessageLookupByLibrary.simpleMessage("Titre de l\'utilisateur"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "Le titre de l\'utilisateur ne peut pas être vide"),
        "value": MessageLookupByLibrary.simpleMessage("Valeur"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("La TVA ne s\'applique pas"),
        "verifyOtp":
            MessageLookupByLibrary.simpleMessage("Vérification du code OTP"),
        "verifyPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Vérifier le numéro de téléphone"),
        "viewAll": MessageLookupByLibrary.simpleMessage("Voir tout"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("Voir les détails"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("Client sans rendez-vous"),
        "warehouse": MessageLookupByLibrary.simpleMessage("Entrepôt"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("L\'entrepôt existe déjà"),
        "warehouseList":
            MessageLookupByLibrary.simpleMessage("Liste des entrepôts"),
        "warehouseName":
            MessageLookupByLibrary.simpleMessage("Nom de l\'entrepôt"),
        "warranty": MessageLookupByLibrary.simpleMessage("Garantie"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "Nous avons envoyé un courriel avec des instructions sur la façon de réinitialiser le mot de passe à :"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "Voimme käyttää kolmannen osapuolen palveluita tukemaan sovelluksemme toiminnallisuutta, kuten analytiikkapalveluita ja maksunvälittäjiä. Nämä kolmannen osapuolen palvelut saattavat kerätä tietoja sinusta sovellustamme käyttäessäsi. Huomaa, että emme vastaa näiden kolmannen osapuolen palveluiden yksityisyyden suojaamisen käytännöistä."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "Noudatamme teollisuusstandardeja tietojesi suojaamiseksi, mukaan lukien salaus ja turvallinen tallennus. Rajoitamme myös tietojesi käyttöoikeuden vain valtuutettuihin henkilöihin."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "Käytämme henkilökohtaisia tietojasi tarjotaksemme sinulle parhaan mahdollisen kokemuksen sovelluksessamme, mukaan lukien sisältösuositusten räätälöimisen, yhteyden muodostamisen asiantuntijoihin ja sovelluksemme toiminnallisuuden parantamisen. Voimme myös käyttää tietojasi viestimiseen päivityksistä, tarjouksista tai muista sovellukseemme liittyvistä tiedoista."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "Nous examinerons le paiement et l\'approuverons dans 1 à 2 heures"),
        "weekly": MessageLookupByLibrary.simpleMessage("Hebdomadaire"),
        "weight": MessageLookupByLibrary.simpleMessage("Poids"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("Quoi de neuf"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("Grossiste"),
        "wholeSalePrice": MessageLookupByLibrary.simpleMessage("Prix de gros"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("Prix de gros"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("Grossiste"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("Sera ajouté bientôt"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("Expirera à"),
        "writeYourMessageHere":
            MessageLookupByLibrary.simpleMessage("Écrivez votre message ici"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("Mauvais OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "Mot de passe incorrect fourni pour cet utilisateur."),
        "yearly": MessageLookupByLibrary.simpleMessage("Annuel"),
        "yesDeleteForever": MessageLookupByLibrary.simpleMessage(
            "Oui, supprimer définitivement"),
        "youAreNotAValidUser": MessageLookupByLibrary.simpleMessage(
            "Vous n\'êtes pas un utilisateur valide"),
        "youAreUsing": MessageLookupByLibrary.simpleMessage("Vous utilisez"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "Vous ne pouvez pas payer plus que le dû"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("Vous avez reçu un courriel"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "Vous êtes connecté avec succès à votre compte. Restez avec Pos Saas ."),
        "youHaveToGivePermission": MessageLookupByLibrary.simpleMessage(
            "Vous devez donner la permission"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "Vous devez vous RECONNECTER à votre compte."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "Vous devez vérifier votre identité avant d\'acheter un SMS"),
        "yourMessageRemains":
            MessageLookupByLibrary.simpleMessage("Votre message reste"),
        "yourPackage": MessageLookupByLibrary.simpleMessage("Votre forfait"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "Votre forfait expirera dans 5 jours")
      };
}
