// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a ml locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'ml';

  final messages = _notInlinedMessages(_notInlinedMessages);

  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BillPlz": MessageLookupByLibrary.simpleMessage("BillPlz"),
        "ContinueE": MessageLookupByLibrary.simpleMessage("മുടങ്ങുക"),
        "GSTNumber": MessageLookupByLibrary.simpleMessage("GST നമ്പർ"),
        "Iyzico": MessageLookupByLibrary.simpleMessage("Iyzico"),
        "KKIPAY": MessageLookupByLibrary.simpleMessage("KKIPAY"),
        "MRP": MessageLookupByLibrary.simpleMessage("എംആർപി"),
        "MRPIsRequired": MessageLookupByLibrary.simpleMessage("MRP ആവശ്യമാണ്"),
        "OK": MessageLookupByLibrary.simpleMessage("ശരി"),
        "POSsAAS": MessageLookupByLibrary.simpleMessage("POS SAAS"),
        "Paypal": MessageLookupByLibrary.simpleMessage("പേപ്പാൽ"),
        "PhNo": MessageLookupByLibrary.simpleMessage("ഫോൺ നമ്പർ"),
        "Rezorpay": MessageLookupByLibrary.simpleMessage("Rezorpay"),
        "SL": MessageLookupByLibrary.simpleMessage("SL"),
        "SSLCommerz": MessageLookupByLibrary.simpleMessage("SSLCommerz"),
        "SWIFTCode": MessageLookupByLibrary.simpleMessage("SWIFT കോഡ്"),
        "Snacks": MessageLookupByLibrary.simpleMessage("സ്നാക്കുകൾ"),
        "TAX": MessageLookupByLibrary.simpleMessage("നികുതി"),
        "Uploading": MessageLookupByLibrary.simpleMessage("അപ്ലോഡ് ചെയ്യുന്നു"),
        "UserTitle": MessageLookupByLibrary.simpleMessage("ഉപയോക്തൃ തലശ്ശി"),
        "YourPackageWillExpireTodayPleasePurchaseagain":
            MessageLookupByLibrary.simpleMessage(
                "നിങ്ങളുടെ പാക്കേജ് ഇന്ന് കാലഹരണപ്പെടും\n\nദയവായി വീണ്ടും വാങ്ങുക"),
        "aTheSystemIsProvided": MessageLookupByLibrary.simpleMessage(
            "(ക) സിസ്റ്റം നിങ്ങളുടെ ബിസിനസിലെ പോയിന്റ് ഓഫ് സെൽസ് ഇടപാടുകളും ബന്ധപ്പെട്ട പ്രവർത്തനങ്ങളും എളുപ്പമാക്കുന്നതിനായി മാത്രം നൽകുന്നു."),
        "aToUseTheSystem": MessageLookupByLibrary.simpleMessage(
            "(ക) സിസ്റ്റം ഉപയോഗിക്കാൻ, നിങ്ങൾക്ക് ഒരു അക്കൗണ്ട് സൃഷ്ടിക്കാൻ ആവശ്യമായിരിക്കാം. രജിസ്ട്രേഷൻ പ്രക്രിയയിൽ നിങ്ങൾ ശരിയായ, നിലവിലെ, സമ്പൂർണമായ വിവരങ്ങൾ നൽകാൻ സമ്മതിക്കുന്നു, കൂടാതെ അവയെ പരിശോധിച്ച് അതിനെ ശരിയായും സമ്പൂർണമായും സൂക്ഷിക്കാൻ."),
        "aboutApp": MessageLookupByLibrary.simpleMessage("ആപ്പ് വിശദീകരണം"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("ഞങ്ങളെക്കുറിച്ച്"),
        "acceptanceOfTerms":
            MessageLookupByLibrary.simpleMessage("നിബന്ധനകളുടെ അംഗീകാരം"),
        "accountName": MessageLookupByLibrary.simpleMessage("അക്കൗണ്ട് പേര്"),
        "accountNumber":
            MessageLookupByLibrary.simpleMessage("അക്കൗണ്ട് നമ്പർ"),
        "accountRegistration":
            MessageLookupByLibrary.simpleMessage("അക്കൗണ്ട് രജിസ്ട്രേഷൻ"),
        "acton": MessageLookupByLibrary.simpleMessage("പ്രവർത്തനം"),
        "add": MessageLookupByLibrary.simpleMessage("ചേർക്കുക"),
        "addBrand": MessageLookupByLibrary.simpleMessage("ബ്രാൻഡ് ചേർക്കുക"),
        "addCategory": MessageLookupByLibrary.simpleMessage("വർഗ്ഗം ചേർക്കുക"),
        "addContact":
            MessageLookupByLibrary.simpleMessage("സമ്പർക്കം ചേർക്കുക"),
        "addCustomer":
            MessageLookupByLibrary.simpleMessage("ഉപഭോക്താവ് ചേർക്കുക"),
        "addDelivery": MessageLookupByLibrary.simpleMessage("ഡെലിവറി ചേർക്കുക"),
        "addDescriptioN":
            MessageLookupByLibrary.simpleMessage("വിവരണം ചേർക്കുക"),
        "addDescription":
            MessageLookupByLibrary.simpleMessage("കുറിപ്പ് ചേർക്കുക"),
        "addDiscount": MessageLookupByLibrary.simpleMessage("രവാലുകൾ ചേർക്കുക"),
        "addDocumentId":
            MessageLookupByLibrary.simpleMessage("ഡോക്യുമെന്റ് ID ചേർക്കുക"),
        "addDucument":
            MessageLookupByLibrary.simpleMessage("ഡോക്യുമെന്റ് ചേർക്കുക"),
        "addExpense": MessageLookupByLibrary.simpleMessage("ചെലവ് ചേർക്കുക"),
        "addExpenseCategory":
            MessageLookupByLibrary.simpleMessage("ചെലവ് വിഭാഗം ചേർക്കുക"),
        "addItems": MessageLookupByLibrary.simpleMessage("വസ്തുക്കൾ ചേർക്കുക"),
        "addNew": MessageLookupByLibrary.simpleMessage("പുതിയത് ചേർക്കുക"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("പുതിയ വിലാസം ചേർക്കുക"),
        "addNewProduct":
            MessageLookupByLibrary.simpleMessage("പുതിയ ഉൽപ്പന്നം ചേർക്കുക"),
        "addNewTax":
            MessageLookupByLibrary.simpleMessage("പുതിയ നികുതി ചേർക്കുക"),
        "addNewTaxWithSingleMultipleTaxType":
            MessageLookupByLibrary.simpleMessage(
                "ഒരു/അനവധി നികുതി തരം ചേർക്കുക"),
        "addNote": MessageLookupByLibrary.simpleMessage("കുറിപ്പ് ചേർക്കുക"),
        "addProductFirst":
            MessageLookupByLibrary.simpleMessage("ആദ്യത്തെ ഉൽപ്പന്നം ചേർക്കുക"),
        "addPromoCode":
            MessageLookupByLibrary.simpleMessage("പ്രൊമോ കോഡ് ചേർക്കുക"),
        "addPurchase": MessageLookupByLibrary.simpleMessage("വാങ്ങൽ ചേർക്കുക"),
        "addSales": MessageLookupByLibrary.simpleMessage("വില്പന ചേർക്കുക"),
        "addSuccessful":
            MessageLookupByLibrary.simpleMessage("സംയോജിതമായി ചേർത്തു"),
        "addUnit": MessageLookupByLibrary.simpleMessage("യൂണി  ചേർക്കുക"),
        "addUserRole":
            MessageLookupByLibrary.simpleMessage("ഉപയോക്തൃ റോളുകൾ ചേർക്കുക"),
        "addedSuccessfully":
            MessageLookupByLibrary.simpleMessage("വിജയകരമായി ചേർത്തു"),
        "addedToCart":
            MessageLookupByLibrary.simpleMessage("കാർട്ടിലേക്ക് ചേർത്തു"),
        "address": MessageLookupByLibrary.simpleMessage("വിലാസം"),
        "admin": MessageLookupByLibrary.simpleMessage("അഡ്മിൻ"),
        "all": MessageLookupByLibrary.simpleMessage("എല്ലാ"),
        "allBusinessSolution":
            MessageLookupByLibrary.simpleMessage("എല്ലാ ബിസിനസ് പരിഹാരങ്ങളും"),
        "alreadyAdded":
            MessageLookupByLibrary.simpleMessage("ഇതിന് മുമ്പേ ചേർത്തു"),
        "alreadyExists":
            MessageLookupByLibrary.simpleMessage("എന്തെങ്കിലും നിലവിലുണ്ട്"),
        "alreadyHaveAnAccounts":
            MessageLookupByLibrary.simpleMessage("അക്കൗണ്ടുകൾ ഇതിനകം ഉണ്ട്"),
        "amount": MessageLookupByLibrary.simpleMessage("തുക"),
        "anEmailHasBeenSentCheckYourInbox":
            MessageLookupByLibrary.simpleMessage(
                "ഒരു ഇമെയിൽ അയച്ചു. നിങ്ങളുടെ ഇൻബോക്സ് പരിശോധിക്കുക"),
        "androidIOSAppSupport": MessageLookupByLibrary.simpleMessage(
            "ആൻഡ്രോയിഡ് & ഐഒഎസ് ആപ്പ് പിന്തുണ"),
        "applicableTax":
            MessageLookupByLibrary.simpleMessage("പ്രയോഗയോഗ്യമായ നികുതി"),
        "apply": MessageLookupByLibrary.simpleMessage("അനുബന്ധിക്കുക"),
        "areYouSureToDeleteThisInvoice": MessageLookupByLibrary.simpleMessage(
            "ഈ ഇൻവോയ്സ് ഇല്ലാതാക്കാൻ നിങ്ങൾ ഉറപ്പാണോ?"),
        "areYouSureToDeleteThisSale": MessageLookupByLibrary.simpleMessage(
            "ഈ വിൽപ്പന ഇല്ലാതാക്കാൻ നിങ്ങൾ ഉറപ്പാണോ?"),
        "areYouSureToDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "ഈ ഉപയോക്താവിനെ മായ്ക്കാൻ നിങ്ങൾ ഉറപ്പാണോ?"),
        "areYouSureWantToDeleteThisTax": MessageLookupByLibrary.simpleMessage(
            "ഈ നികുതി നീക്കം ചെയ്യാൻ നിങ്ങൾക്ക് ഉറപ്പുണ്ടോ?"),
        "areYouSureWantToDeleteThisTaxGroup":
            MessageLookupByLibrary.simpleMessage(
                "ഈ നികുതി ഗ്രൂപ്പ് നീക്കം ചെയ്യാൻ നിങ്ങൾക്ക് ഉറപ്പുണ്ടോ?"),
        "areYouWantToDeleteThisWarehouse": MessageLookupByLibrary.simpleMessage(
            "ഈ ഗൊദാമം നീക്കാൻ നിങ്ങൾക്ക് ആഗ്രഹമുണ്ടോ?"),
        "areYourSureDeleteThisUser": MessageLookupByLibrary.simpleMessage(
            "ഈ ഉപയോക്താവിനെ മാച്ചുവാൻ നിങ്ങൾക്കുണ്ടോ?"),
        "authorizedSignature":
            MessageLookupByLibrary.simpleMessage("അനുമതിച്ച ഒപ്പ്"),
        "bYouHaveResponsiveFor": MessageLookupByLibrary.simpleMessage(
            "(ബി) നിങ്ങൾക്ക് നിങ്ങളുടെ അക്കൗണ്ട്, പാസ്വേഡിന്റെ രഹസ്യപരമായ കാര്യം പാലിക്കുന്നതും, നിങ്ങളുടെ അക്കൗണ്ടിലേക്ക് ആക്‌സസ് നിയന്ത്രിക്കുന്നതും പരിരക്ഷിക്കാൻ ഉത്തരവാദിത്വം വഹിക്കണം. നിങ്ങളുടെ അക്കൗണ്ടിനടത്തുന്ന എല്ലാ പ്രവർത്തനങ്ങൾക്കുമുള്ള ഉത്തരവാദിത്വം നിങ്ങൾ ഏറ്റുവാങ്ങുന്നു."),
        "bYouMustBeAtLeastYearsOld": MessageLookupByLibrary.simpleMessage(
            "(ബി) സിസ്റ്റം ഉപയോഗിക്കാൻ നിങ്ങൾ 18 വയസ്സായിരിക്കണം അല്ലെങ്കിൽ നിങ്ങളുടെ അതിക്രമത്തിനുള്ള നിയമപരമായ പ്രായം ഉണ്ടായിരിക്കണം."),
        "backSide": MessageLookupByLibrary.simpleMessage("പിന്നണി"),
        "backToHome":
            MessageLookupByLibrary.simpleMessage("വീട്ടിലേക്ക് തിരിച്ചുപോകുക"),
        "balance": MessageLookupByLibrary.simpleMessage("തുല്യത"),
        "bangladesh": MessageLookupByLibrary.simpleMessage("ബംഗ്ലാദേശ്"),
        "bank": MessageLookupByLibrary.simpleMessage("ബാങ്ക്"),
        "bankAccountCurrency":
            MessageLookupByLibrary.simpleMessage("ബാങ്ക് അക്കൗണ്ട് കറൻസി"),
        "bankAccountingCurrecny":
            MessageLookupByLibrary.simpleMessage("ബാങ്ക് അക്കൗണ്ട് കറൻസി"),
        "bankInformation":
            MessageLookupByLibrary.simpleMessage("ബാങ്ക് വിവരങ്ങൾ"),
        "bankName": MessageLookupByLibrary.simpleMessage("ബാങ്കിന്റെ പേര്"),
        "bankTransfer":
            MessageLookupByLibrary.simpleMessage("ബാങ്ക് ട്രാൻസ്ഫർ"),
        "barcodeFound":
            MessageLookupByLibrary.simpleMessage("ബാർക്കോഡ് കണ്ടെത്തി"),
        "billInvoice": MessageLookupByLibrary.simpleMessage("ബിൽ/ഇൻവോയ്സ്"),
        "billTo": MessageLookupByLibrary.simpleMessage("ബില്ല് ചെയ്യുക"),
        "branchName": MessageLookupByLibrary.simpleMessage("ബ്രാഞ്ചിന്റെ പേര്"),
        "brand": MessageLookupByLibrary.simpleMessage("ബ്രാൻഡ്"),
        "brandName": MessageLookupByLibrary.simpleMessage("ബ്രാൻഡ് നാമം"),
        "bulkUpload": MessageLookupByLibrary.simpleMessage("വലിയ\nഅപ്ലോഡ്"),
        "businessCategory":
            MessageLookupByLibrary.simpleMessage("വാണിജ്യ വിഭാഗം"),
        "buy": MessageLookupByLibrary.simpleMessage("വാങ്ങുക"),
        "buyPremiumPlan":
            MessageLookupByLibrary.simpleMessage("പ്രീമിയം പദ്ധതി വാങ്ങുക"),
        "buySms": MessageLookupByLibrary.simpleMessage("SMS വാങ്ങുക"),
        "byAccessingOrUsingThePointOfSales": MessageLookupByLibrary.simpleMessage(
            "[നിങ്ങളുടെ കമ്പനിയുടെ പേര്] (\"കമ്പനി\") നൽകുന്ന പോയിന്റ് ഓഫ് സെൽസ് (POS) സിസ്റ്റം (\"സിസ്റ്റം\") ആക്‌സസ് ചെയ്യുകയോ ഉപയോഗിക്കുകയോ ചെയ്താൽ, നിങ്ങൾ ഈ ഉപയോ​ഗ നിബന്ധനകളാൽ നിയന്ത്രിതമാകാൻ സമ്മതിക്കുന്നു. ഈ ഉപയോ​ഗ നിബന്ധനകളെ നിങ്ങൾ അംഗീകരിക്കുന്നില്ല എങ്കിൽ, സിസ്റ്റം ഉപയോഗിക്കരുത്."),
        "cYouHaveResponsiveForEnsuring": MessageLookupByLibrary.simpleMessage(
            "(സി) നിങ്ങൾക്കു സിസ്റ്റത്തിലേക്ക് ആക്‌സസ് ചെയ്യാനും ഉപയോഗിക്കാനും അനുബന്ധിച്ചിരിക്കുന്ന എല്ലാ നിയമങ്ങളും നിർദേശങ്ങളും പാലിക്കാൻ നിങ്ങൾ ഉത്തരവാദിത്വം വഹിക്കുന്നു."),
        "cacel": MessageLookupByLibrary.simpleMessage("റദ്ദാക്കുക"),
        "call": MessageLookupByLibrary.simpleMessage("কল"),
        "callForEmergencySupport": MessageLookupByLibrary.simpleMessage(
            "അത്യാവശ്യ സഹായത്തിനായി വിളിക്കുക"),
        "camera": MessageLookupByLibrary.simpleMessage("കാമറ"),
        "cancel": MessageLookupByLibrary.simpleMessage("റദ്ദാക്കുക"),
        "cancelAllProduct": MessageLookupByLibrary.simpleMessage(
            "എല്ലാ ഉത്പന്നങ്ങളും റദ്ദാക്കുക"),
        "capacity": MessageLookupByLibrary.simpleMessage("ക്ഷമത"),
        "card": MessageLookupByLibrary.simpleMessage("കാർഡ്"),
        "cash": MessageLookupByLibrary.simpleMessage("കാഷ്"),
        "cashFree": MessageLookupByLibrary.simpleMessage("Cash Free"),
        "categories": MessageLookupByLibrary.simpleMessage("വർഗ്ഗങ്ങൾ"),
        "category": MessageLookupByLibrary.simpleMessage("വർഗ്ഗം"),
        "categoryName":
            MessageLookupByLibrary.simpleMessage("വിഭാഗത്തിന്റെ പേര്"),
        "categoryNameAlreadyExists": MessageLookupByLibrary.simpleMessage(
            "വിഭാഗത്തിന്റെ പേര് നിലവിലുണ്ട്"),
        "cateogryName":
            MessageLookupByLibrary.simpleMessage("വിഭാഗത്തിന്റെ പേര്"),
        "change": MessageLookupByLibrary.simpleMessage("മാറ്റം?"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("പാസ്‌വേഡ് മാറ്റുക"),
        "checkEmail":
            MessageLookupByLibrary.simpleMessage("ഇമെയിൽ പരിശോധിക്കുക"),
        "choseACustomer": MessageLookupByLibrary.simpleMessage(
            "ഒരു ഉപഭോക്താവിനെ തിരഞ്ഞെടുക്കുക"),
        "choseASupplier": MessageLookupByLibrary.simpleMessage(
            "ഒരു വിതരണക്കാരനെ തിരഞ്ഞെടുക്കുക"),
        "choseYourFeature": MessageLookupByLibrary.simpleMessage(
            "നിങ്ങളുടെ സവിശേഷതകൾ തിരഞ്ഞെടുക്കുക"),
        "clarence": MessageLookupByLibrary.simpleMessage("ക്ലാരൻസ്"),
        "clickToConnect": MessageLookupByLibrary.simpleMessage(
            "കണക്റ്റ് ചെയ്യാൻ ക്ലിക്ക് ചെയ്യുക"),
        "close": MessageLookupByLibrary.simpleMessage("അടച്ചിടുക"),
        "color": MessageLookupByLibrary.simpleMessage("നിറം"),
        "combinationOfMultipleTaxes": MessageLookupByLibrary.simpleMessage(
            "(അനവധി നികുതികളുടെ സംയോജനമായ)"),
        "comingSoon": MessageLookupByLibrary.simpleMessage("വരാനുണ്ട്"),
        "companyAddress":
            MessageLookupByLibrary.simpleMessage("കമ്പനിയുടെ വിലാസം"),
        "companyAndShopName":
            MessageLookupByLibrary.simpleMessage("കമ്പനിയും കടയും"),
        "companyBusinessName":
            MessageLookupByLibrary.simpleMessage("കമ്പനി & ബിസിനസ് പേര്"),
        "completeTransaction":
            MessageLookupByLibrary.simpleMessage("ലേലങ്ങൾ പൂർത്തിയാക്കുക"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("പാസ്വേഡ് സ്ഥിരീകരിക്കുക"),
        "confirmReturn": MessageLookupByLibrary.simpleMessage(
            "തിരിച്ചുവിടാൻ സ്ഥിരീകരിക്കുക"),
        "congratulations": MessageLookupByLibrary.simpleMessage("അഭിനന്ദനങ്ങൾ"),
        "contactUs": MessageLookupByLibrary.simpleMessage("ഞങ്ങളെ ബന്ധപ്പെടുക"),
        "continu": MessageLookupByLibrary.simpleMessage("തുടരണം"),
        "country": MessageLookupByLibrary.simpleMessage("രാജ്യം"),
        "create": MessageLookupByLibrary.simpleMessage("സൃഷ്ടിക്കുക"),
        "createAFreeAccounts": MessageLookupByLibrary.simpleMessage(
            "മറ്റൊരു അക്കൗണ്ട് ഉണ്ടാക്കുക"),
        "createdAndSaved":
            MessageLookupByLibrary.simpleMessage("സൃഷ്ടിച്ചു, രക്ഷപ്പെട്ടു"),
        "currency": MessageLookupByLibrary.simpleMessage("നാണയം"),
        "currentStock":
            MessageLookupByLibrary.simpleMessage("നിലവിലെ സ്റ്റോക്ക്"),
        "customInvoiceBranding": MessageLookupByLibrary.simpleMessage(
            "അനുസൃതമായ ഇന്വോയിസ് ബ്രാൻഡിംഗ്"),
        "customer": MessageLookupByLibrary.simpleMessage("ഉപഭോക്താവ്"),
        "customerDetails":
            MessageLookupByLibrary.simpleMessage("ഉപഭോക്തൃ വിശദാംശങ്ങൾ"),
        "customerGST": MessageLookupByLibrary.simpleMessage("ഉപഭോക്തൃ GST"),
        "customerName": MessageLookupByLibrary.simpleMessage("ഉപഭോക്തൃ നാമം"),
        "dailyTransaciton":
            MessageLookupByLibrary.simpleMessage("ദൈനംദിന ഇടപാടുകൾ"),
        "dashBoardOverView":
            MessageLookupByLibrary.simpleMessage("ഡാഷ്‌ബോർഡ് അവലോകനം"),
        "dataSavedSuccessfully": MessageLookupByLibrary.simpleMessage(
            "വിവരം വിജയകരമായി സംരക്ഷിച്ചിരിക്കുന്നു"),
        "date": MessageLookupByLibrary.simpleMessage("തീയതി"),
        "day": MessageLookupByLibrary.simpleMessage("ദിവസം"),
        "dealer": MessageLookupByLibrary.simpleMessage("ഡീലർ"),
        "dealerPrice": MessageLookupByLibrary.simpleMessage("ഡീലർ വില"),
        "defaultVATPercentage":
            MessageLookupByLibrary.simpleMessage("മൂല്യവേദി ശതമാനം"),
        "delete": MessageLookupByLibrary.simpleMessage("കഴിവാക്കുക"),
        "deleting": MessageLookupByLibrary.simpleMessage("വലിച്ചുവിടുന്നു"),
        "deliveryAddress":
            MessageLookupByLibrary.simpleMessage("ഡെലിവറി വിലാസം"),
        "deliveryAddresses":
            MessageLookupByLibrary.simpleMessage("ഡെലിവറി വിലാസങ്ങൾ"),
        "deliveryCharge": MessageLookupByLibrary.simpleMessage("ഡെലിവറി ചാർജ്"),
        "describtion": MessageLookupByLibrary.simpleMessage("വിവരണം"),
        "description": MessageLookupByLibrary.simpleMessage("വിവരണം"),
        "descriptionCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("വിവരണം ശൂന്യമായിരിക്കും"),
        "details": MessageLookupByLibrary.simpleMessage("വിശദാംശങ്ങൾ"),
        "discount": MessageLookupByLibrary.simpleMessage("ഡിസ്‌കൗണ്ട്"),
        "doNotDistrub":
            MessageLookupByLibrary.simpleMessage("വിഘടിപ്പിക്കരുത്"),
        "done": MessageLookupByLibrary.simpleMessage("പൂർത്തിയായി"),
        "downloadExcelFormat": MessageLookupByLibrary.simpleMessage(
            "എക്സൽ ഫോർമാറ്റ് ഡൗൺലോഡ് ചെയ്യുക"),
        "downloadedSuccessfullyInDownloadFolder":
            MessageLookupByLibrary.simpleMessage(
                "ഡൗൺലോഡ് ഫോൾഡറിൽ വിജയകരമായി ഡൗൺലോഡ് ചെയ്യപ്പെട്ടു"),
        "due": MessageLookupByLibrary.simpleMessage("ബാക്കി"),
        "dueAmount": MessageLookupByLibrary.simpleMessage("ബാക്കി തുക: "),
        "dueCollection": MessageLookupByLibrary.simpleMessage("ബാക്കി ശേഖരണം"),
        "dueCollectionReports":
            MessageLookupByLibrary.simpleMessage("ദിയു ശേഖരണ റിപ്പോർട്ടുകൾ"),
        "dueList": MessageLookupByLibrary.simpleMessage("ബാക്കി പട്ടിക"),
        "dueReports": MessageLookupByLibrary.simpleMessage("വായ്പ റിപ്പോർട്ട്"),
        "duration": MessageLookupByLibrary.simpleMessage("കാലയളവ്"),
        "durationFrom": MessageLookupByLibrary.simpleMessage("അവധി: നിന്ന്"),
        "easyToUseMobilePos": MessageLookupByLibrary.simpleMessage(
            "ഉപയോക്താക്കൾക്കായി എളുപ്പമുള്ള മൊബൈൽ POS"),
        "edit": MessageLookupByLibrary.simpleMessage("എഡിറ്റ് ചെയ്യുക"),
        "editPurchaseInvoice":
            MessageLookupByLibrary.simpleMessage("വാങ്ങൽ ഇൻവോയിസ് തിരുത്തുക"),
        "editSalesInvoice":
            MessageLookupByLibrary.simpleMessage("വില്പന ഇൻവോയിസ് തിരുത്തുക"),
        "editSocailMedia": MessageLookupByLibrary.simpleMessage(
            "സോഷ്യൽ മീഡിയ എഡിറ്റ് ചെയ്യുക"),
        "editSuccessfully":
            MessageLookupByLibrary.simpleMessage("സഫലമായി തിരുത്തി"),
        "editTax": MessageLookupByLibrary.simpleMessage("നികുതി संपादിക്കുക"),
        "editTaxGroup":
            MessageLookupByLibrary.simpleMessage("നികുതി ഗ്രൂപ്പ് തിരുത്തുക"),
        "editWarehouse":
            MessageLookupByLibrary.simpleMessage("ഗൊദാമം തിരുത്തുക"),
        "email": MessageLookupByLibrary.simpleMessage("ഇമെയിൽ"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("ഇമെയിൽ വിലാസം"),
        "emailCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("ഇമെയിൽ ശൂന്യമാകരുത്"),
        "emailSentCheckYourInbox": MessageLookupByLibrary.simpleMessage(
            "ഇമെയിൽ അയച്ചത്! നിങ്ങളുടെ ഇൻബോക്സ് പരിശോധിക്കുക"),
        "endDate": MessageLookupByLibrary.simpleMessage("അവസാന തീയതി"),
        "enterAValidAmount": MessageLookupByLibrary.simpleMessage(
            "ഒരു സാധുവായ തുക രേഖപ്പെടുത്തുക"),
        "enterAValidDiscount":
            MessageLookupByLibrary.simpleMessage("വാലിഡ് കിഴിവ് നൽകുക"),
        "enterAValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "ഒരു സാധുവായ ഫോൺ നമ്പർ രേഖപ്പെടുത്തുക"),
        "enterAValidPrice":
            MessageLookupByLibrary.simpleMessage("വാലിഡ് വില നൽകുക"),
        "enterAValidQuantity":
            MessageLookupByLibrary.simpleMessage("വാലിഡ് അളവ് നൽകുക"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("വിലാസം നൽകുക"),
        "enterAmount": MessageLookupByLibrary.simpleMessage("രാശി നൽകുക."),
        "enterBrandName":
            MessageLookupByLibrary.simpleMessage("ബ്രാൻഡ് നാമം നൽകുക"),
        "enterCapacity": MessageLookupByLibrary.simpleMessage("ക്ഷമത നൽകുക"),
        "enterCategoryName":
            MessageLookupByLibrary.simpleMessage("വർഗ്ഗം നാമം നൽകുക"),
        "enterColor": MessageLookupByLibrary.simpleMessage("നിറം നൽകുക"),
        "enterCustomerGstNumber": MessageLookupByLibrary.simpleMessage(
            "ഉപഭോക്തൃ GST നമ്പർ രേഖപ്പെടുത്തുക"),
        "enterDealerPrice":
            MessageLookupByLibrary.simpleMessage("ഡീലർ വില നൽകുക"),
        "enterDescription":
            MessageLookupByLibrary.simpleMessage("വിവരണം നൽകുക"),
        "enterDiscount":
            MessageLookupByLibrary.simpleMessage("ഡിസ്‌കൗണ്ട് നൽകുക."),
        "enterExpenseDate":
            MessageLookupByLibrary.simpleMessage("ചെലവിന്റെ തീയതി നൽകുക"),
        "enterFullAddress": MessageLookupByLibrary.simpleMessage(
            "സമ്പൂർണ്ണ വിലാസം പ്രവേശിപ്പിക്കുക"),
        "enterInvoiceNumber":
            MessageLookupByLibrary.simpleMessage("ഇൻവോയിസ് നമ്പർ നൽകുക"),
        "enterLowStockAlertQuantity": MessageLookupByLibrary.simpleMessage(
            "കുറഞ്ഞ സ്റ്റോക്ക് എൽർട്ട് അളവ് പ്രവേശിപ്പിക്കുക"),
        "enterManufacturer":
            MessageLookupByLibrary.simpleMessage("നിർമ്മാതാവ് നൽകുക"),
        "enterMessageContent":
            MessageLookupByLibrary.simpleMessage("സന്ദേശ ഉള്ളടക്കം നൽകുക"),
        "enterMrpOrRetailerPirce":
            MessageLookupByLibrary.simpleMessage("എംആർപി/വിലക്കാർ വില നൽകുക"),
        "enterName": MessageLookupByLibrary.simpleMessage("പേര് നൽകുക"),
        "enterNote": MessageLookupByLibrary.simpleMessage("കുറിപ്പ് നൽകുക"),
        "enterPartyName":
            MessageLookupByLibrary.simpleMessage("പാർട്ടിയുടെ പേര് നൽകുക"),
        "enterPhoneNumber":
            MessageLookupByLibrary.simpleMessage("ഫോൺ നമ്പർ പ്രവേശിപ്പിക്കുക"),
        "enterProductCodeOrScan": MessageLookupByLibrary.simpleMessage(
            "ഉൽപ്പന്ന കോഡ് നൽകുക അല്ലെങ്കിൽ സ്‌കാൻ ചെയ്യുക"),
        "enterProductName":
            MessageLookupByLibrary.simpleMessage("ഉൽപ്പന്നത്തിന്റെ നാമം നൽകുക"),
        "enterPurchasePrice":
            MessageLookupByLibrary.simpleMessage("വാങ്ങൽ വില നൽകുക."),
        "enterReferenceNumber":
            MessageLookupByLibrary.simpleMessage("ഉയിർപ്പു നമ്പർ നൽകുക"),
        "enterSize": MessageLookupByLibrary.simpleMessage("വലിപ്പം നൽകുക"),
        "enterStocks":
            MessageLookupByLibrary.simpleMessage("സ്ടോക്കുകൾ നൽകുക."),
        "enterTaxRate":
            MessageLookupByLibrary.simpleMessage("നികുതി നിരക്ക് നൽകുക"),
        "enterTransactionId":
            MessageLookupByLibrary.simpleMessage("വ്യാപാരം ID നൽകുക"),
        "enterType": MessageLookupByLibrary.simpleMessage("തരം നൽകുക"),
        "enterUserTitle":
            MessageLookupByLibrary.simpleMessage("ഉപയോക്തൃ തലശ്ശി നൽകുക"),
        "enterValidAmount":
            MessageLookupByLibrary.simpleMessage("ശാസ്ത്രീയമായ തുകയുണ്ടാക്കുക"),
        "enterWarehouseName":
            MessageLookupByLibrary.simpleMessage("ഗൊദാമത്തിന്റെ പേര് നൽകുക"),
        "enterWeight": MessageLookupByLibrary.simpleMessage("ഭാരം നൽകുക"),
        "enterWholeSalePrice":
            MessageLookupByLibrary.simpleMessage("ഹോൾസെയിൽ വില നൽകുക"),
        "enterYourDescriptionHere": MessageLookupByLibrary.simpleMessage(
            "നിങ്ങളുടെ വിവരണം ഇവിടെ നൽകുക"),
        "enterYourEmailAddress": MessageLookupByLibrary.simpleMessage(
            "നിങ്ങളുടെ ഇമെയിൽ വിലാസം നൽകുക"),
        "enterYourFeedBackTitle": MessageLookupByLibrary.simpleMessage(
            "നിങ്ങളുടെ ഫീഡ് ബാക്ക് ശീർഷകം നൽകുക"),
        "enterYourGSTNumber": MessageLookupByLibrary.simpleMessage(
            "നിങ്ങളുടെ GST നമ്പർ രേഖപ്പെടുത്തുക"),
        "enterYourMobileNumber":
            MessageLookupByLibrary.simpleMessage("നിങ്ങളുടെ മൊബൈൽ നമ്പർ നൽകുക"),
        "enterYourName":
            MessageLookupByLibrary.simpleMessage("നിങ്ങളുടെ പേര് നൽകുക"),
        "enterYourNumber":
            MessageLookupByLibrary.simpleMessage("നിങ്ങളുടെ ഫോൺ നമ്പർ നൽകുക"),
        "enterYourPassword":
            MessageLookupByLibrary.simpleMessage("നിങ്ങളുടെ പാസ്വേഡ് നൽകുക"),
        "enterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "നിങ്ങളുടെ ഫോൺ നമ്പർ പ്രവേശിപ്പിക്കുക"),
        "enterYourTransactionId":
            MessageLookupByLibrary.simpleMessage("നിങ്ങളുടെ ലേലങ്ങൾ ID നൽകുക"),
        "error": MessageLookupByLibrary.simpleMessage("പിഴവ്"),
        "excTax": MessageLookupByLibrary.simpleMessage("നികുതി ഒഴിവാക്കിയ"),
        "excelUploader": MessageLookupByLibrary.simpleMessage("എക്സൽ അപ്‌ലോഡർ"),
        "exclusive": MessageLookupByLibrary.simpleMessage("വ്യത്യസ്ത"),
        "expense": MessageLookupByLibrary.simpleMessage("ചെലവ്"),
        "expenseCategory": MessageLookupByLibrary.simpleMessage("ചെലവ് വിഭാഗം"),
        "expenseDate": MessageLookupByLibrary.simpleMessage("ചെലവിന്റെ തീയതി"),
        "expenseFor": MessageLookupByLibrary.simpleMessage("ചെലവ് വേണ്ടി"),
        "expenseReport":
            MessageLookupByLibrary.simpleMessage("ചെലവ് റിപ്പോർട്ട്"),
        "expireDate":
            MessageLookupByLibrary.simpleMessage("കാലഹരണത്തിനുള്ള തീയതി"),
        "expired": MessageLookupByLibrary.simpleMessage("കാലഹരണമെത്തിയ"),
        "expiring": MessageLookupByLibrary.simpleMessage("കാലഹരണത്തിന്"),
        "facebok": MessageLookupByLibrary.simpleMessage("ഫേസ്ബുക്ക്"),
        "failedWithError":
            MessageLookupByLibrary.simpleMessage("പിഴവോടെ പരാജയപ്പെട്ടു"),
        "fashion": MessageLookupByLibrary.simpleMessage("ഫാഷൻ"),
        "featureAreTheImportant": MessageLookupByLibrary.simpleMessage(
            "സവിശേഷതകൾ POS SaaS-യെ പരമ്പരാഗത പരിഹാരങ്ങളിൽ നിന്ന് വ്യത്യസ്തമാക്കുന്ന പ്രധാന ഭാഗമാണ്."),
        "feedBack": MessageLookupByLibrary.simpleMessage("ഫീഡ് ബാക്ക്"),
        "firstName": MessageLookupByLibrary.simpleMessage("ആദ്യം നാമം"),
        "followUsOnFacebook": MessageLookupByLibrary.simpleMessage(
            "ഫേസ്ബുക്കിൽ ഞങ്ങളെ പിന്തുടരുക"),
        "followUsOnTwitter": MessageLookupByLibrary.simpleMessage(
            "ട്വിറ്ററിൽ ഞങ്ങളെ പിന്തുടരുക"),
        "fontSide": MessageLookupByLibrary.simpleMessage("മുന്നത്തെ ഭാഗം"),
        "forUnlimitedUses":
            MessageLookupByLibrary.simpleMessage("അപരിമിതമായ ഉപയോഗങ്ങൾക്കായി"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("പാസ്‌വേഡ് മറന്നുകഴിഞ്ഞോ?"),
        "forgotPasswords":
            MessageLookupByLibrary.simpleMessage("പാസ്‌വേഡ് മറന്നുവെന്ന്?"),
        "formDate": MessageLookupByLibrary.simpleMessage("തീയതിയിൽ നിന്ന്"),
        "freeDataBackup":
            MessageLookupByLibrary.simpleMessage("സൗജന്യ ഡാറ്റാ ബാക്കപ്പ്"),
        "freeLifeTimeUpdate": MessageLookupByLibrary.simpleMessage(
            "ഇരുത്തുള്ള കാലാവധി അപ്‌ഡേറ്റ്"),
        "freePacakge": MessageLookupByLibrary.simpleMessage("സൗജന്യ പാക്കേജ്"),
        "freePlan": MessageLookupByLibrary.simpleMessage("സൗജന്യ പദ്ധതി"),
        "from": MessageLookupByLibrary.simpleMessage("(നിന്നു"),
        "fullyPaid":
            MessageLookupByLibrary.simpleMessage("പൂർണ്ണമായും അടച്ചുകിട്ടിയത്"),
        "gallary": MessageLookupByLibrary.simpleMessage("ഗാലറി"),
        "generatingPDF":
            MessageLookupByLibrary.simpleMessage("PDF സൃഷ്ടിക്കുന്നു"),
        "getOtp": MessageLookupByLibrary.simpleMessage("OTP നേടുക"),
        "govermentId": MessageLookupByLibrary.simpleMessage("സർക്കാർ ഐഡി"),
        "guest": MessageLookupByLibrary.simpleMessage("ഗസ്റ്റ്"),
        "havenotAnAccounts": MessageLookupByLibrary.simpleMessage(
            "ലോകിൽ ഒരു അക്കൗണ്ടും ഇല്ലേ?"),
        "history": MessageLookupByLibrary.simpleMessage("ചരിത്രം"),
        "home": MessageLookupByLibrary.simpleMessage("ഗൃഹം"),
        "howWeProtectYourInformation": MessageLookupByLibrary.simpleMessage(
            "നിങ്ങളുടെ വിവരങ്ങൾ എങ്ങനെ സംരക്ഷിക്കുന്നു"),
        "howWeUseYourInformation": MessageLookupByLibrary.simpleMessage(
            "നിങ്ങളുടെ വിവരങ്ങൾ എങ്ങനെ ഉപയോഗിക്കുന്നു"),
        "identityVerify":
            MessageLookupByLibrary.simpleMessage("പ്രാഥമികത സ്ഥിരീകരണം"),
        "image": MessageLookupByLibrary.simpleMessage("ചിത്രം"),
        "inHouseCantBeDelete":
            MessageLookupByLibrary.simpleMessage("ഇൻഹൗസ് നീക്കം ചെയ്യാനാകില്ല"),
        "inHouseCantBeEdited": MessageLookupByLibrary.simpleMessage(
            "ഇൻഹൗസ് എഡിറ്റ് ചെയ്യാനാകില്ല"),
        "inWord": MessageLookupByLibrary.simpleMessage("വാക്കുകളിൽ"),
        "incTax": MessageLookupByLibrary.simpleMessage("നികുതി ഉൾപ്പെടുത്തിയ"),
        "inclusive": MessageLookupByLibrary.simpleMessage("സമാഹിത"),
        "increaseStock":
            MessageLookupByLibrary.simpleMessage("സ്റ്റോക്ക് വർധിപ്പിക്കുക"),
        "inistrument": MessageLookupByLibrary.simpleMessage("ഇൻസ്ട്രുമെന്റ്"),
        "instragram": MessageLookupByLibrary.simpleMessage("ഇൻസ്റ്റഗ്രാം"),
        "invNo": MessageLookupByLibrary.simpleMessage("ഇൻവോയ്സ് നമ്പർ"),
        "invoice": MessageLookupByLibrary.simpleMessage("ഇൻവോയ്സ്"),
        "invoiceNumber": MessageLookupByLibrary.simpleMessage("ഇൻവോയിസ് നമ്പർ"),
        "invoiceSetting":
            MessageLookupByLibrary.simpleMessage("ഇൻവോയിസ് ക്രമീകരണം"),
        "invoiceViewer": MessageLookupByLibrary.simpleMessage("ഇൻവോയ്സ് ദർശനം"),
        "itemAdded": MessageLookupByLibrary.simpleMessage("വസ്തു ചേർത്തു"),
        "kg": MessageLookupByLibrary.simpleMessage("കिलो"),
        "kycVerification":
            MessageLookupByLibrary.simpleMessage("KYC സ്ഥിരീകരണം"),
        "language": MessageLookupByLibrary.simpleMessage("ഭാഷ"),
        "lastName": MessageLookupByLibrary.simpleMessage("അവസാന നാമം"),
        "ledger": MessageLookupByLibrary.simpleMessage("ലെജർ"),
        "lifeTimePurchase":
            MessageLookupByLibrary.simpleMessage("ശാശ്വത\nവാങ്ങൽ"),
        "link": MessageLookupByLibrary.simpleMessage("ലിങ്ക്"),
        "linkedIn": MessageLookupByLibrary.simpleMessage("ലിങ്ക്ഡ് ഇൻ"),
        "liveChatSupport":
            MessageLookupByLibrary.simpleMessage("ലൈവ് ചാറ്റ് സഹായം"),
        "loading": MessageLookupByLibrary.simpleMessage("ചെയ്യുന്നു"),
        "logIn": MessageLookupByLibrary.simpleMessage("ലോഗിൻ"),
        "logOUt": MessageLookupByLibrary.simpleMessage("ലോഗ് ഔട്ട്"),
        "logOut": MessageLookupByLibrary.simpleMessage("പുറത്തേക്ക് പോകുക"),
        "login": MessageLookupByLibrary.simpleMessage("ലോഗിൻ ചെയ്യുക"),
        "logo": MessageLookupByLibrary.simpleMessage("ലോഗോ"),
        "loss": MessageLookupByLibrary.simpleMessage("നഷ്ടം"),
        "lossOrProfit": MessageLookupByLibrary.simpleMessage("നഷ്ടം/ലാഭം"),
        "lossOrProfitDetails":
            MessageLookupByLibrary.simpleMessage("നഷ്ടം/ലാഭം വിശദാംശങ്ങൾ"),
        "lossProfitReport":
            MessageLookupByLibrary.simpleMessage("നഷ്‌ട/ലാഭ റിപ്പോർട്ട്"),
        "lossProfitReports":
            MessageLookupByLibrary.simpleMessage("നഷ്‌ട/ലാഭ റിപ്പോർട്ടുകൾ"),
        "lowStockAlert":
            MessageLookupByLibrary.simpleMessage("കുറഞ്ഞ സ്റ്റോക്ക് എൽർട്ട്"),
        "maan": MessageLookupByLibrary.simpleMessage("മാൻ"),
        "makeALastingImpression": MessageLookupByLibrary.simpleMessage(
            "ഉപഭോക്താക്കൾക്കായുള്ള വ്യക്തമായ ഇന്വോയിസുകൾ കൊണ്ട് ഒരു lasting impression ഉണ്ടാക്കുക. ഞങ്ങളുടെ പരിമിതിയില്ലാത്ത അപ്ഡേറ്റ്, നിങ്ങളുടെ ഇൻവോയിസുകൾ എഡ്ജസ്ട്ട് ചെയ്യുന്നതിനുള്ള പ്രത്യേക പരിഗണന നൽകുന്നു, നിങ്ങളുടെ ബ്രാൻഡ് തിരിച്ചറിയലിനെ ശക്തമാക്കുകയും ഉപഭോക്തൃ നിഷ്ഠയെ വളർത്തുകയും ചെയ്യുന്നു."),
        "manageYourBussinessWith": MessageLookupByLibrary.simpleMessage(
            "നിങ്ങളുടെ ബിസിനസ്സ് കൈകാര്യം ചെയ്യുക"),
        "manufactureDate":
            MessageLookupByLibrary.simpleMessage("തയാറാക്കുന്ന തീയതി"),
        "margin": MessageLookupByLibrary.simpleMessage("മാർജിൻ"),
        "masterCard": MessageLookupByLibrary.simpleMessage("മാസ്റ്റർ കാർഡ്"),
        "menufeturer":
            MessageLookupByLibrary.simpleMessage("ഉൽപ്പന്നം നിർമ്മാതാവ്"),
        "message": MessageLookupByLibrary.simpleMessage("സന്ദേശം"),
        "messageHistory":
            MessageLookupByLibrary.simpleMessage("സന്ദേശ ചരിത്രം"),
        "mobiPosAppIsFree": MessageLookupByLibrary.simpleMessage(
            "POS SaaS ആപ്പ് സൗജന്യമാണ്, ഉപയോഗിക്കാൻ എളുപ്പമാണ്. യാഥാർത്ഥത്തിൽ, ഇത് ലോകമെമ്പാടുമുള്ള മികച്ച POS സിസ്റ്റങ്ങളിലൊന്നാണ്."),
        "mobiPosIsaCompleteBusinesSolution": MessageLookupByLibrary.simpleMessage(
            "POS SaaS ഒരു സമ്പൂർണ്ണ ബിസിനസ് പരിഹാരമാണ് സ്റ്റോക്ക്, അക്കൗണ്ട്, വില്പന, ചെലവ് & നഷ്ട/ലാഭ."),
        "mobile": MessageLookupByLibrary.simpleMessage("മൊബൈൽ"),
        "mobilePayment": MessageLookupByLibrary.simpleMessage("മൊബൈൽ പേമെന്റ്"),
        "monthly": MessageLookupByLibrary.simpleMessage("മാസിക"),
        "moreInfo": MessageLookupByLibrary.simpleMessage("കൂടുതൽ വിവരങ്ങൾ"),
        "name": MessageLookupByLibrary.simpleMessage("നിങ്ങളുടെ പേര് നൽകുക."),
        "nameAlreadyExists":
            MessageLookupByLibrary.simpleMessage("പേര് ഇതിനകം നിലവിലുണ്ട്"),
        "nameCantBeEmpty": MessageLookupByLibrary.simpleMessage(
            "പേര് തീർച്ചയായും ശൂന്യമായിരിക്കരുത്"),
        "next": MessageLookupByLibrary.simpleMessage("അടുത്തത്"),
        "noConnection": MessageLookupByLibrary.simpleMessage("ബന്ധമില്ല"),
        "noData": MessageLookupByLibrary.simpleMessage("ദത്തയില്ല"),
        "noDataAvailable":
            MessageLookupByLibrary.simpleMessage("ഡാറ്റ ലഭ്യമല്ല"),
        "noDataFound":
            MessageLookupByLibrary.simpleMessage("ഡാറ്റ കണ്ടെത്താനായില്ല"),
        "noHistoryFound": MessageLookupByLibrary.simpleMessage(
            "ഇതുവരെയുള്ള ചരിത്രം കണ്ടെത്തിയില്ല!"),
        "noProductFound":
            MessageLookupByLibrary.simpleMessage("ഉൽപ്പന്നം കണ്ടെത്തിയില്ല"),
        "noSubTaxSelected": MessageLookupByLibrary.simpleMessage(
            "ഉപ നികുതി തിരഞ്ഞെടുത്തിട്ടില്ല"),
        "noTransactionFound":
            MessageLookupByLibrary.simpleMessage("ലേലങ്ങൾ കണ്ടെത്തിയില്ല!"),
        "noUserFoundForThatEmail": MessageLookupByLibrary.simpleMessage(
            "ആ ഇമെയിലിന് ഉപയോക്താവ് കണ്ടെത്താനായില്ല."),
        "noUserRoleFound": MessageLookupByLibrary.simpleMessage(
            "ഉപയോക്തൃ റോളുകൾ കണ്ടെത്തിയില്ല"),
        "notActiveUser":
            MessageLookupByLibrary.simpleMessage("സജീവ ഉപയോക്താവല്ല"),
        "notProvided": MessageLookupByLibrary.simpleMessage("കൊടുത്തിട്ടില്ല"),
        "note": MessageLookupByLibrary.simpleMessage("കുറിപ്പ്"),
        "notes": MessageLookupByLibrary.simpleMessage("കുറിപ്പുകൾ"),
        "notification": MessageLookupByLibrary.simpleMessage("അറിയിപ്പ്"),
        "oTPSentTo": MessageLookupByLibrary.simpleMessage("OTP അയച്ചു"),
        "office": MessageLookupByLibrary.simpleMessage("ആഫീസ്"),
        "ok": MessageLookupByLibrary.simpleMessage("ശരി"),
        "onboardOne": MessageLookupByLibrary.simpleMessage(
            "വില്പനാ നിരീക്ഷണം, ഇൻവെന്ററി മാനേജ്‌മെന്റ് ഉൾപ്പെടുന്ന വിശാലമായ ഫംഗ്ഷനാലിറ്റി അടങ്ങിയ POS."),
        "onboardThree": MessageLookupByLibrary.simpleMessage(
            "ഈ സിസ്റ്റം നിങ്ങളുടെ ഉപഭോക്താക്കൾക്കായി നിങ്ങളുടെ പ്രവർത്തനങ്ങൾ മെച്ചപ്പെടുത്താൻ സഹായിക്കുന്നു."),
        "onboardTwo": MessageLookupByLibrary.simpleMessage(
            "നമ്മുടെ POS സിസ്റ്റം നിങ്ങളുടെ ദിവസം ദിവസത്തെ പ്രവർത്തനങ്ങൾ സ്വയം ലളിതമാക്കണം, അതിനാൽ എളുപ്പത്തിൽ നാവിഗേറ്റ് ചെയ്യാൻ കഴിയും."),
        "openingBalance": MessageLookupByLibrary.simpleMessage("തുടക്ക ബാലൻസ്"),
        "order": MessageLookupByLibrary.simpleMessage("ഓർഡറുകൾ"),
        "other": MessageLookupByLibrary.simpleMessage("മറ്റുള്ളവ"),
        "otp": MessageLookupByLibrary.simpleMessage("ഊർജ്ജം"),
        "outOfStock": MessageLookupByLibrary.simpleMessage("സ്റ്റോക്കിൽ ഇല്ല"),
        "pacakge": MessageLookupByLibrary.simpleMessage("പാക്കേജ്"),
        "packageFeatures":
            MessageLookupByLibrary.simpleMessage("പാക്കേജ് സവിശേഷതകൾ"),
        "paid": MessageLookupByLibrary.simpleMessage("അടച്ചിട്ടുണ്ട്"),
        "paidAmount": MessageLookupByLibrary.simpleMessage("കിട്ടിയ തുക"),
        "parties": MessageLookupByLibrary.simpleMessage("കക്ഷികൾ"),
        "partiesList":
            MessageLookupByLibrary.simpleMessage("പാർട്ടികളുടെ പട്ടിക"),
        "partyGST": MessageLookupByLibrary.simpleMessage("പാർട്ടി GST"),
        "partyName": MessageLookupByLibrary.simpleMessage("പാർട്ടി നാമം"),
        "password": MessageLookupByLibrary.simpleMessage("പാസ്‌വേഡ്"),
        "passwordAndConfirmPasswordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "പാസ്വേഡും സ്ഥിരീകരണ പാസ്വേഡും പൊരുത്തപ്പെടുന്നില്ല"),
        "passwordCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("പാസ്വേഡ് ശൂന്യമാകരുത്"),
        "passwordNotMach":
            MessageLookupByLibrary.simpleMessage("പാസ്വേഡ് കൃത്യമായില്ല"),
        "payCash": MessageLookupByLibrary.simpleMessage("നഗദ് പേയ്‌മെന്റ്"),
        "payStack": MessageLookupByLibrary.simpleMessage("PayStack"),
        "payWithBkash":
            MessageLookupByLibrary.simpleMessage("Bkash മുഖേന പണം നൽകുക"),
        "payWithPaypal":
            MessageLookupByLibrary.simpleMessage("പേയ്പാലോടെ പണം നൽകുക"),
        "payeeName":
            MessageLookupByLibrary.simpleMessage("പണമിടപാടുകാരന്റെ പേര്"),
        "payeeNumber":
            MessageLookupByLibrary.simpleMessage("പണമിടപാടുകാരന്റെ നമ്പർ"),
        "payment": MessageLookupByLibrary.simpleMessage("പേയ്മെന്റ്"),
        "paymentAmount": MessageLookupByLibrary.simpleMessage("ചെലവ് തുക"),
        "paymentComplete": MessageLookupByLibrary.simpleMessage(
            "പേയ്മെന്റ് പൂർത്തിയായിരിക്കുന്നു"),
        "paymentInstructions":
            MessageLookupByLibrary.simpleMessage("പണമിടപാട് നിർദ്ദേശങ്ങൾ:"),
        "paymentMethod":
            MessageLookupByLibrary.simpleMessage("പെയ്മെന്റ് മാർഗം"),
        "paymentType": MessageLookupByLibrary.simpleMessage("ചെലവ് തരം"),
        "pdfView": MessageLookupByLibrary.simpleMessage("PDF ദൃശ്യവല്‍ക്കരണം"),
        "personalInformation":
            MessageLookupByLibrary.simpleMessage("സ്വകാര്യ വിവരങ്ങൾ"),
        "phone": MessageLookupByLibrary.simpleMessage("ഫോൺ"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("ഫോൺ നമ്പർ"),
        "phoneNumberAlreadyUsed": MessageLookupByLibrary.simpleMessage(
            "ഫോൺ നമ്പർ ഇതിനകം ഉപയോഗിച്ചിരിക്കുന്നു"),
        "phoneNumberIsNotValid":
            MessageLookupByLibrary.simpleMessage("ഫോൺ നമ്പർ അസാധുവാണ്"),
        "phoneNumberIsRequired":
            MessageLookupByLibrary.simpleMessage("ഫോൺ നമ്പർ ആവശ്യമാണ്"),
        "pickAndUploadFile":
            MessageLookupByLibrary.simpleMessage("ഫയൽ തിരഞ്ഞെടുക്കുക  uploads"),
        "pickEndDate":
            MessageLookupByLibrary.simpleMessage("അവസാന തീയതി തിരഞ്ഞെടുക്കുക"),
        "pickStartDate":
            MessageLookupByLibrary.simpleMessage("ആരംഭ തീയതി തിരഞ്ഞെടുക്കുക"),
        "plan": MessageLookupByLibrary.simpleMessage("പ്ലാൻ"),
        "pleaseAddQuantity":
            MessageLookupByLibrary.simpleMessage("ദയവായി അളവ് ചേർക്കുക"),
        "pleaseCheckYourInternetConnectivity":
            MessageLookupByLibrary.simpleMessage(
                "ദയവായി നിങ്ങളുടെ ഇന്റർനെറ്റ് കണക്ഷൻ പരിശോധിക്കുക"),
        "pleaseConnectThePrinterFirst": MessageLookupByLibrary.simpleMessage(
            "ദയവായി ആദ്യം പ്രിന്റർ കണക്ടുചെയ്യുക"),
        "pleaseConnectYourBluttothPrinter":
            MessageLookupByLibrary.simpleMessage(
                "ദയവായി നിങ്ങളുടെ ബ്ലൂടൂത്ത് പ്രിന്റർ ബന്ധിപ്പിക്കുക"),
        "pleaseEnterABiggerPassword": MessageLookupByLibrary.simpleMessage(
            "കൂടുതല് വലിയ പാസ്വേഡ് രേഖപ്പെടുത്തുക"),
        "pleaseEnterAConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "ദയവായി ഒരു സ്ഥിരീകരണ പാസ്വേഡ് നൽകുക"),
        "pleaseEnterAPassword":
            MessageLookupByLibrary.simpleMessage("ദയവായി ഒരു പാസ്‌വേഡ് നൽകുക"),
        "pleaseEnterAValidEmail": MessageLookupByLibrary.simpleMessage(
            "ദയവായി ഒരു സാധുവായ ഇമെയിൽ രേഖപ്പെടുത്തുക"),
        "pleaseEnterName":
            MessageLookupByLibrary.simpleMessage("ദയവായി പേര് രേഖപ്പെടുത്തുക"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("ദയവായി പാസ്വേഡ് നൽകുക"),
        "pleaseEnterTheEmailAddressBelowToRecive":
            MessageLookupByLibrary.simpleMessage(
                "പാസ്‌വേഡ് പുനഃസജ്ജമാക്കാനുള്ള ലിങ്ക് ലഭിക്കാനുള്ള ഇമെയിൽ വിലാസം താഴെ നൽകുക."),
        "pleaseEnterTransactionNumber":
            MessageLookupByLibrary.simpleMessage("കൃപയായി ഇടപാട് നമ്പർ നൽകുക"),
        "pleaseInterAmount":
            MessageLookupByLibrary.simpleMessage("ദയവായി തുക രേഖപ്പെടുത്തുക"),
        "pleaseSelectACategoryFirst": MessageLookupByLibrary.simpleMessage(
            "ദയവായി ആദ്യം ഒരു കാറ്റഗറി തിരഞ്ഞെടുക്കുക"),
        "pleaseSelectAPlan": MessageLookupByLibrary.simpleMessage(
            "കൃപയായി ഒരു പദ്ധതി തിരഞ്ഞെടുക്കുക"),
        "pleaseSelectBusinessCategory": MessageLookupByLibrary.simpleMessage(
            "ദയവായി ബിസിനസ് കാറ്റഗറി തിരഞ്ഞെടുക്കുക"),
        "pleaseUseTheValidPurchaseCodeToUseTheApp":
            MessageLookupByLibrary.simpleMessage(
                "ആപ്പ് ഉപയോഗിക്കാൻ അസാധുവായ വാങ്ങൽ കോഡ് ഉപയോഗിക്കുക"),
        "powerdedByMobiPos":
            MessageLookupByLibrary.simpleMessage("MobiPos വഴി ശക്തിപ്പെടുത്തി"),
        "poweredBy": MessageLookupByLibrary.simpleMessage("ശക്തിയുള്ളവ"),
        "premiumCustomerSupport":
            MessageLookupByLibrary.simpleMessage("പ്രീമിയം ഉപഭോക്തൃ പിന്തുണ"),
        "premiumPlan": MessageLookupByLibrary.simpleMessage("പ്രീമിയം പദ്ധതി"),
        "previousPayAmounts":
            MessageLookupByLibrary.simpleMessage("മുമ്പത്തെ പണമിടപാട് തുകകൾ"),
        "price": MessageLookupByLibrary.simpleMessage("വില"),
        "print": MessageLookupByLibrary.simpleMessage("അച്ചടിക്കുക"),
        "printingOption":
            MessageLookupByLibrary.simpleMessage("അച്ചടിക്കുന്ന ഓപ്ഷൻ"),
        "privacyPolicy": MessageLookupByLibrary.simpleMessage("സ്വകാര്യതാ നയം"),
        "product": MessageLookupByLibrary.simpleMessage("ഉൽപ്പന്നം"),
        "productCode": MessageLookupByLibrary.simpleMessage("ഉൽപ്പന്ന കോഡ്"),
        "productCodeIsRequired":
            MessageLookupByLibrary.simpleMessage("ഉത്പന്ന കോഡ് ആവശ്യമാണ്"),
        "productCodeName":
            MessageLookupByLibrary.simpleMessage("ഉൽപ്പന്ന കോഡ്/നാമം"),
        "productDescription":
            MessageLookupByLibrary.simpleMessage("ഉൽപ്പന്നത്തിന്റെ വിവരണം"),
        "productDetails": MessageLookupByLibrary.simpleMessage(
            "ഉൽപ്പന്നത്തിന്റെ വിശദാംശങ്ങൾ"),
        "productList":
            MessageLookupByLibrary.simpleMessage("ഉൽപ്പന്നങ്ങളുടെ പട്ടിക"),
        "productName":
            MessageLookupByLibrary.simpleMessage("ഉൽപ്പന്നത്തിന്റെ നാമം"),
        "productNameAlreadyExistsInThisWarehouse":
            MessageLookupByLibrary.simpleMessage(
                "ഉത്പന്നത്തിന്റെ പേര് ഇതിനകം ഈ വെയർഹൗസിൽ ഉണ്ട്"),
        "productNameIsAlreadyAdded": MessageLookupByLibrary.simpleMessage(
            "ഉൽപ്പന്നത്തിന്റെ പേര് ഇതിനകം ചേർത്തു"),
        "productNameIsRequired": MessageLookupByLibrary.simpleMessage(
            "ഉത്പന്നത്തിന്റെ പേര് ആവശ്യമാണ്"),
        "products": MessageLookupByLibrary.simpleMessage("ഉൽപ്പന്നങ്ങൾ"),
        "profile": MessageLookupByLibrary.simpleMessage("പ്രൊഫൈൽ"),
        "profileEdit": MessageLookupByLibrary.simpleMessage("പ്രോഫൈൽ എഡിറ്റ്"),
        "profit": MessageLookupByLibrary.simpleMessage("ലാഭം"),
        "promo": MessageLookupByLibrary.simpleMessage("പ്രൊമോ"),
        "promoCode": MessageLookupByLibrary.simpleMessage("പ്രൊമോ കോഡ്"),
        "purchase": MessageLookupByLibrary.simpleMessage("വാങ്ങുക"),
        "purchaseAlarm": MessageLookupByLibrary.simpleMessage("വാങ്ങൽ അലാർം"),
        "purchaseConfirmed":
            MessageLookupByLibrary.simpleMessage("വാങ്ങൽ സ്ഥിരീകരിച്ചു"),
        "purchaseDetails":
            MessageLookupByLibrary.simpleMessage("വാങ്ങൽ വിശദാംശങ്ങൾ"),
        "purchaseInvoice":
            MessageLookupByLibrary.simpleMessage("വാങ്ങൽ ഇൻവോയ്സ്"),
        "purchaseList": MessageLookupByLibrary.simpleMessage("വാങ്ങൽ പട്ടിക"),
        "purchaseNow": MessageLookupByLibrary.simpleMessage("ഇപ്പോൾ വാങ്ങുക"),
        "purchasePremiumPlan":
            MessageLookupByLibrary.simpleMessage("പ്രീമിയം പദ്ധതി വാങ്ങുക"),
        "purchasePrice": MessageLookupByLibrary.simpleMessage("വാങ്ങൽ വില"),
        "purchasePriceIsRequired":
            MessageLookupByLibrary.simpleMessage("വാങ്ങൽ വില ആവശ്യമാണ്"),
        "purchaseRepoet":
            MessageLookupByLibrary.simpleMessage("വാങ്ങൽ റിപ്പോർട്ട്"),
        "purchaseReports": MessageLookupByLibrary.simpleMessage("വാങ്ങൽ വില"),
        "purchaseReportss":
            MessageLookupByLibrary.simpleMessage("വില്പന റിപ്പോർട്ടുകൾ"),
        "purchaseReturn":
            MessageLookupByLibrary.simpleMessage("വാങ്ങൽ തിരിച്ചു"),
        "purchaseReturnReport":
            MessageLookupByLibrary.simpleMessage("വാങ്ങൽ തിരിച്ചു റിപ്പോർട്ട്"),
        "purchaseTransition":
            MessageLookupByLibrary.simpleMessage("കൊള്ളലിന്റെ മാറ്റം"),
        "qty": MessageLookupByLibrary.simpleMessage("അളവ്"),
        "quantity": MessageLookupByLibrary.simpleMessage("അളവ്"),
        "recentTransactions":
            MessageLookupByLibrary.simpleMessage("സമീപകാല ഇടപാടുകൾ"),
        "recivedThePin": MessageLookupByLibrary.simpleMessage("പിന് ലഭിച്ചു"),
        "referenceNumber":
            MessageLookupByLibrary.simpleMessage("ഉയിർപ്പു നമ്പർ"),
        "register": MessageLookupByLibrary.simpleMessage("റജിസ്റ്റർ ചെയ്യുക"),
        "registering": MessageLookupByLibrary.simpleMessage("പതിവാക്കുന്നു"),
        "remainingDue":
            MessageLookupByLibrary.simpleMessage("ബാക്കിയുള്ള ബാക്കി"),
        "remove": MessageLookupByLibrary.simpleMessage("വലിച്ചുവിടുക"),
        "reports": MessageLookupByLibrary.simpleMessage("റിപോർട്ടുകൾ"),
        "requestHasBeenSend":
            MessageLookupByLibrary.simpleMessage("കവനയുണ്ടായിരിക്കുന്നു"),
        "resendCode":
            MessageLookupByLibrary.simpleMessage("കോടുകൾ വീണ്ടും അയയ്ക്കുക"),
        "resendOtp":
            MessageLookupByLibrary.simpleMessage("OTP വീണ്ടും അയയ്ക്കുക:"),
        "retailer": MessageLookupByLibrary.simpleMessage("രീട്ടെയ്ലർ"),
        "retur": MessageLookupByLibrary.simpleMessage("മടങ്ങുക"),
        "returN": MessageLookupByLibrary.simpleMessage("തിരിച്ചു"),
        "returnAMount": MessageLookupByLibrary.simpleMessage("മടങ്ങുന്ന തുക"),
        "returnAmount": MessageLookupByLibrary.simpleMessage("മടക്കം തുക"),
        "returnQTY": MessageLookupByLibrary.simpleMessage("തിരിച്ചുവരവ് അളവ്"),
        "revenue": MessageLookupByLibrary.simpleMessage("രജ്ജുവായി"),
        "safeGuardYourBusinessDate": MessageLookupByLibrary.simpleMessage(
            "നിങ്ങളുടെ ബിസിനസ് ഡാറ്റ സംരക്ഷിക്കാൻ എളുപ്പമാണ്. ഞങ്ങളുടെ Pos Saas POS Unlimited Upgrade സൗജന്യ ഡാറ്റാ ബാക്കപ്പ് ഉൾപ്പെടുന്നു, ഈ ഫലവശാലുകൾ കാത്തുസൂക്ഷിക്കാൻ, നിങ്ങൾക്ക് വല്ലതും സംഭവിച്ചാലും. നിങ്ങളുടെ ബിസിനസ്സ് വളർച്ചയെ മാത്രം ശ്രദ്ധിക്കുക."),
        "saleAmount": MessageLookupByLibrary.simpleMessage("വിൽപ്പന തുക"),
        "saleDetails":
            MessageLookupByLibrary.simpleMessage("വില്പന വിശദാംശങ്ങൾ"),
        "salePrice": MessageLookupByLibrary.simpleMessage("വില്പന വില"),
        "saleReports":
            MessageLookupByLibrary.simpleMessage("വില്പന റിപ്പോർട്ട്"),
        "saleReportss":
            MessageLookupByLibrary.simpleMessage("വില്പന റിപ്പോർട്ടുകൾ"),
        "saleReturn": MessageLookupByLibrary.simpleMessage("വിൽപ്പന തിരിച്ചു"),
        "saleReturnReport": MessageLookupByLibrary.simpleMessage(
            "വിൽപ്പന തിരിച്ചു റിപ്പോർട്ട്"),
        "saleSetting":
            MessageLookupByLibrary.simpleMessage("വിൽപ്പന ക്രമീകരണം"),
        "sales": MessageLookupByLibrary.simpleMessage("വിൽപ്പനകൾ"),
        "salesAndPurchaseReports": MessageLookupByLibrary.simpleMessage(
            "വില്പനയും വാങ്ങലും റിപ്പോർട്ടുകൾ"),
        "salesList": MessageLookupByLibrary.simpleMessage("വില്പന പട്ടിക"),
        "salesReturn":
            MessageLookupByLibrary.simpleMessage("വിൽപ്പന തിരിച്ചെടുക്കൽ"),
        "save": MessageLookupByLibrary.simpleMessage("സംരക്ഷിക്കുക"),
        "saveAndPublish": MessageLookupByLibrary.simpleMessage(
            "സംരക്ഷിക്കുക  & പ്രസിദ്ധീകരിക്കുക"),
        "saveChanges":
            MessageLookupByLibrary.simpleMessage("മാറ്റങ്ങൾ സംരക്ഷിക്കുക"),
        "saving": MessageLookupByLibrary.simpleMessage("സേവ് ചെയ്യുന്നു"),
        "scanProductQRCode": MessageLookupByLibrary.simpleMessage(
            "ഉൽപ്പന്നത്തിന്റെ QR കോഡ് സ്കാൻ ചെയ്യുക"),
        "search": MessageLookupByLibrary.simpleMessage("ശോധിക്കുക"),
        "searchByProductCodeOrName": MessageLookupByLibrary.simpleMessage(
            "ഉൽപ്പന്ന കോഡ് അല്ലെങ്കിൽ നാമം ഉപയോഗിച്ച് തിരയുക"),
        "seeAllPromoCode":
            MessageLookupByLibrary.simpleMessage("എല്ലാ പ്രൊമോ കോഡുകളും കാണുക"),
        "select": MessageLookupByLibrary.simpleMessage("തിരഞ്ഞെടുക്കുക"),
        "selectAProductForReturn": MessageLookupByLibrary.simpleMessage(
            "തിരിച്ചു നൽകാൻ ഒരു ഉൽപ്പന്നം തിരഞ്ഞെടുക്കുക"),
        "selectBrand":
            MessageLookupByLibrary.simpleMessage("ബ്രാൻഡ് തിരഞ്ഞെടുക്കുക"),
        "selectCategory":
            MessageLookupByLibrary.simpleMessage("കാറ്റഗറി തിരഞ്ഞെടുക്കുക"),
        "selectContacts":
            MessageLookupByLibrary.simpleMessage("ബന്ധങ്ങൾ തിരഞ്ഞെടുക്കുക"),
        "selectProductCategory": MessageLookupByLibrary.simpleMessage(
            "ഉത്പന്ന കാറ്റഗറി തിരഞ്ഞെടുക്കുക"),
        "selectShopCategory": MessageLookupByLibrary.simpleMessage(
            "ഷോപ്പ് കാറ്റഗറി തിരഞ്ഞെടുക്കുക"),
        "selectTax":
            MessageLookupByLibrary.simpleMessage("നികുതി തിരഞ്ഞെടുക്കുക"),
        "selectTaxType":
            MessageLookupByLibrary.simpleMessage("നികുതി തരം തിരഞ്ഞെടുക്കുക"),
        "selectUnit":
            MessageLookupByLibrary.simpleMessage("യൂണിറ്റ് തിരഞ്ഞെടുക്കുക"),
        "selectvariations": MessageLookupByLibrary.simpleMessage(
            "പരിവർത്തനങ്ങൾ തിരഞ്ഞെടുക്കുക: "),
        "seller": MessageLookupByLibrary.simpleMessage("വിൽപ്പനക്കാരൻ"),
        "sellsBy": MessageLookupByLibrary.simpleMessage("വിൽക്കുന്നവ"),
        "send": MessageLookupByLibrary.simpleMessage("അയക്കുക"),
        "sendEmail": MessageLookupByLibrary.simpleMessage("ഇമെയിൽ അയയ്ക്കുക"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("സന്ദേശം അയക്കുക"),
        "sendResetLink": MessageLookupByLibrary.simpleMessage(
            "പുനഃസജ്ജമാക്കൽ ലിങ്ക് അയയ്ക്കുക"),
        "sendSms": MessageLookupByLibrary.simpleMessage("എസ്എംഎസ് അയയ്ക്കുക"),
        "sendSmsw": MessageLookupByLibrary.simpleMessage("SMS അയക്കണമെന്ന്?"),
        "sendWhatsappMessage": MessageLookupByLibrary.simpleMessage(
            "വാട്‌സ്ആപ്പ് സന്ദേശം അയയ്ക്കുക"),
        "sendYOurEmail":
            MessageLookupByLibrary.simpleMessage("നിങ്ങളുടെ ഇമെയിൽ അയക്കുക"),
        "sendingEmail":
            MessageLookupByLibrary.simpleMessage("ഇമെയിൽ അയയ്ക്കുന്നു"),
        "sendingMessage":
            MessageLookupByLibrary.simpleMessage("സന്ദേശം അയയ്ക്കുന്നു"),
        "serviceShipping":
            MessageLookupByLibrary.simpleMessage("സേവന/ഷിപ്പിംഗ്"),
        "setUpYourProfile": MessageLookupByLibrary.simpleMessage(
            "നിങ്ങളുടെ പ്രൊഫൈൽ സജ്ജമാക്കുക"),
        "setting": MessageLookupByLibrary.simpleMessage("ക്രമീകരണം"),
        "share": MessageLookupByLibrary.simpleMessage("പങ്കിടുക"),
        "shopGST": MessageLookupByLibrary.simpleMessage("ഷോപ്പ് GST"),
        "signIn": MessageLookupByLibrary.simpleMessage("സൈൻ ഇൻ"),
        "signInWithEmail": MessageLookupByLibrary.simpleMessage(
            "ഇമെയിൽ ഉപയോഗിച്ച് സൈൻ ഇൻ ചെയ്യുക"),
        "signatureOfCustomer":
            MessageLookupByLibrary.simpleMessage("ഉപഭോക്താവിന്റെ ഒപ്പ്"),
        "size": MessageLookupByLibrary.simpleMessage("വലിപ്പം"),
        "skip": MessageLookupByLibrary.simpleMessage("ഒല്ലി"),
        "sms": MessageLookupByLibrary.simpleMessage("SMS"),
        "socailMarketing":
            MessageLookupByLibrary.simpleMessage("സോഷ്യൽ മാർക്കറ്റിംഗ്"),
        "sorryYouHaveNoPermissionToAccessThisService":
            MessageLookupByLibrary.simpleMessage(
                "ക്ഷമിക്കണം, ഈ സേവനം ഉപയോഗിക്കാൻ നിങ്ങൾക്ക് അനുമതിയില്ല"),
        "startDate": MessageLookupByLibrary.simpleMessage("ആരംഭ തീയതി"),
        "startNewSale":
            MessageLookupByLibrary.simpleMessage("പുതിയ വിൽപ്പന ആരംഭിക്കുക"),
        "startTypingToSearch": MessageLookupByLibrary.simpleMessage(
            "ശോധനയ്ക്ക് തവണകൾ ടൈപ്പ് ചെയ്യാൻ തുടങ്ങുക"),
        "stayAtTheForFront": MessageLookupByLibrary.simpleMessage(
            "കൂടുതൽ ചെലവ് ഇല്ലാതെ സാങ്കേതിക മുന്നേറ്റങ്ങളുടെ മുന്നിൽ ആകൂ. ഞങ്ങളുടെ Pos Saas POS അദ്വിതീയ അപ്ഗ്രേഡ് നിങ്ങളുടെ കൈയിൽ ഏറ്റവും പുതിയ ഉപകരണങ്ങളും വിശേഷണങ്ങളും ഉറപ്പാക്കുന്നു, നിങ്ങളുടെ ബിസിനസ്സ് എപ്പോഴും മുടിവരക്കാൻ ശ്രമിക്കുക."),
        "stillUnpaid": MessageLookupByLibrary.simpleMessage("ഇനിയും അടച്ചില്ല"),
        "stock": MessageLookupByLibrary.simpleMessage("സ്റ്റോക്ക്"),
        "stockIsRequired":
            MessageLookupByLibrary.simpleMessage("സ്റ്റോക്ക് ആവശ്യമാണ്"),
        "stockList": MessageLookupByLibrary.simpleMessage("സ്റ്റോക്ക് പട്ടിക"),
        "stocks": MessageLookupByLibrary.simpleMessage("സ്ടോക്കുകൾ"),
        "storagePermissionIsRequiredToCreateExcelFile":
            MessageLookupByLibrary.simpleMessage(
                "എക്സൽ ഫയൽ സൃഷ്ടിക്കാൻ സ്റ്റോറേജ് അനുമതി ആവശ്യമാണ്"),
        "subTaxList": MessageLookupByLibrary.simpleMessage("ഉപ നികുതി പട്ടിക"),
        "subTaxes": MessageLookupByLibrary.simpleMessage("ഉപ നികുതികൾ"),
        "subTotal": MessageLookupByLibrary.simpleMessage("ഉപത്തെ ആകെ"),
        "submit": MessageLookupByLibrary.simpleMessage("അയക്കുക"),
        "subscribeToOurYoutube": MessageLookupByLibrary.simpleMessage(
            "യൂട്യൂബിൽ ഞങ്ങളെ സബ്സ്ക്രൈബ് ചെയ്യുക"),
        "subscription": MessageLookupByLibrary.simpleMessage("അംഗീകാരം"),
        "successfullyDone":
            MessageLookupByLibrary.simpleMessage("വിജയകരമായി പൂർത്തിയായി"),
        "successfullyLoggedOut":
            MessageLookupByLibrary.simpleMessage("യഥാർത്ഥമായി പുറത്തിറങ്ങിയത്"),
        "successfullyUpdated":
            MessageLookupByLibrary.simpleMessage("സഫലമായി അപ്ഡേറ്റ് ചെയ്തു"),
        "supplier": MessageLookupByLibrary.simpleMessage("സപ്ലയർ"),
        "supplierName": MessageLookupByLibrary.simpleMessage("സപ്ലയർ നാമം"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("സ്വിഫ്റ്റ് കോഡ്"),
        "takeADriveruser": MessageLookupByLibrary.simpleMessage(
            "ഡ്രൈവർ ലൈസൻസ്, ദേശീയ തിരിച്ചറിയൽ കാർഡ് അല്ലെങ്കിൽ പാസ്പോർട്ട് ഫോട്ടോ എടുക്കുക"),
        "takeaNidCardToCheckYourInformation":
            MessageLookupByLibrary.simpleMessage(
                "നിങ്ങളുടെ വിവരങ്ങൾ പരിശോധിക്കാൻ തിരിച്ചറിയൽ കാർഡ് എടുത്തു"),
        "tap": MessageLookupByLibrary.simpleMessage("ടാപ്പ്"),
        "tax": MessageLookupByLibrary.simpleMessage("നികുതി"),
        "taxGroup": MessageLookupByLibrary.simpleMessage("നികുതി ഗ്രൂപ്പ്"),
        "taxPercentage": MessageLookupByLibrary.simpleMessage("നികുതി ശതമാനം"),
        "taxRate": MessageLookupByLibrary.simpleMessage("നികുതി നിരക്ക്"),
        "taxRatesManageYourTaxRates": MessageLookupByLibrary.simpleMessage(
            "നികുതി നിരക്കുകൾ - നിങ്ങളുടെ നികുതി നിരക്കുകൾ നിയന്ത്രിക്കുക"),
        "taxReport": MessageLookupByLibrary.simpleMessage("നികുതി റിപ്പോർട്ട്"),
        "taxType": MessageLookupByLibrary.simpleMessage("നികുതി തരം"),
        "taxes": MessageLookupByLibrary.simpleMessage("പമ്പനകൾ"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("നിബന്ധനകളും വ്യവസ്ഥകളും"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("ഉപയോചന നിബന്ധനകൾ"),
        "termsPrivacy":
            MessageLookupByLibrary.simpleMessage("നിബന്ധനകളും സ്വകാര്യതയും"),
        "thankYOuForYourDuePayment": MessageLookupByLibrary.simpleMessage(
            "നിങ്ങളുടെ ബാക്കി തുക പേയ്‌മെന്റിന് നന്ദി"),
        "thankYou": MessageLookupByLibrary.simpleMessage("നന്ദി"),
        "thankYouForYourPurchase":
            MessageLookupByLibrary.simpleMessage("നിങ്ങളുടെ വാങ്ങലിന് നന്ദി"),
        "theAccountAlreadyExistsForThatEmail":
            MessageLookupByLibrary.simpleMessage(
                "ആ ഇമെയിലിന് ഇതിനകം അക്കൗണ്ട് നിലവിലുണ്ട്"),
        "theExcelFileHasAlreadyBeenDownloaded":
            MessageLookupByLibrary.simpleMessage(
                "എക്സൽ ഫയൽ ഇതിനകം ഡൗൺലോഡ് ചെയ്തു"),
        "theNameSysIt": MessageLookupByLibrary.simpleMessage(
            "പേരിൽ തന്നെ എല്ലാം ഉണ്ട്. Pos Saas POS Unlimited ൽ, നിങ്ങളുടെ ഉപയോഗത്തിൽ ഏത് പരിധിയുമില്ല. നിങ്ങൾ ഒരു കുറച്ച് ഇടപാടുകൾ പ്രോസസ്സ് ചെയ്യുകയോ, അല്ലെങ്കിൽ ഉപഭോക്താക്കളുടെ rush നേരിടുകയോ ചെയ്യുമ്പോൾ, നിങ്ങൾക്ക് ആത്മവിശ്വാസത്തോടെ പ്രവർത്തിക്കാൻ കഴിയും, പരിധികളാൽ നിയന്ത്രിതമല്ലെന്ന് അറിയാൻ."),
        "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
            "നൽകിയ പാസ്വേഡ് വളരെ ബലഹീനമാണ്"),
        "theSaleWillBeDeletedAndAllTheDataWill":
            MessageLookupByLibrary.simpleMessage(
                "ഈ വിൽപ്പന ഇല്ലാതാക്കപ്പെടും, ഈ വാങ്ങലിനെ കുറിച്ചുള്ള എല്ലാ വിവരങ്ങളും ഇല്ലാതാക്കപ്പെടും. നിങ്ങള്‍ക്ക് ഈ ഇല്ലാതാക്കാൻ ഉറപ്പാണോ?"),
        "theSaleWillBeDeletedAndAllTheDataWillSale":
            MessageLookupByLibrary.simpleMessage(
                "ഈ വിൽപ്പന ഇല്ലാതാക്കപ്പെടും, ഈ വിൽപ്പനയെ കുറിച്ചുള്ള എല്ലാ വിവരങ്ങളും ഇല്ലാതാക്കപ്പെടും. നിങ്ങള്‍ക്ക് ഈ ഇല്ലാതാക്കാൻ ഉറപ്പാണോ?"),
        "theUserWillBe": MessageLookupByLibrary.simpleMessage(
            "ഉപയോക്താവ് മാച്ചപ്പെടും, കൂടാതെ നിങ്ങളുടെ അക്കൗണ്ടിൽ നിന്നുള്ള എല്ലാ വിവരങ്ങളും ഇല്ലാതാകും. നിങ്ങൾക്ക് ഇത് മാച്ചാൻ ഉറപ്പാണോ?"),
        "theUserWillBeDeletedAndAllTheData": MessageLookupByLibrary.simpleMessage(
            "ഉപയോക്താവ് മായ്ച്ചു, എല്ലാ വിവരങ്ങളും നിങ്ങളുടെ അക്കൗണ്ടിൽ നിന്നുമുള്ളത് മായ്ച്ചു. നിങ്ങൾ ഈ ഉപയോക്താവിനെ മായ്ക്കാൻ ഉറപ്പാണോ?"),
        "thirdPartyServices":
            MessageLookupByLibrary.simpleMessage("മൂന്നാം पक्ष സേവനങ്ങൾ"),
        "thisCategoryCannotBeDeleted": MessageLookupByLibrary.simpleMessage(
            "ഈ വിഭാഗം നീക്കം ചെയ്യാനാകില്ല"),
        "thisMonth": MessageLookupByLibrary.simpleMessage("(ഈ മാസം)"),
        "thisProductAlreadyAdded":
            MessageLookupByLibrary.simpleMessage("ഈ ഉത്പന്നം ഇതിനകം ചേർത്തു"),
        "title": MessageLookupByLibrary.simpleMessage("ശീർഷകം"),
        "titleCanNotBeEmpty":
            MessageLookupByLibrary.simpleMessage("തലക്കെട്ട് ശൂന്യമായിരിക്കും"),
        "to": MessageLookupByLibrary.simpleMessage("ലേക്ക്"),
        "toDate": MessageLookupByLibrary.simpleMessage("തീയതിയിൽ വരെ"),
        "today": MessageLookupByLibrary.simpleMessage("ഇന്ന്"),
        "total": MessageLookupByLibrary.simpleMessage("ആകെ"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("മൊത്തം തുക"),
        "totalCollected":
            MessageLookupByLibrary.simpleMessage("മൊത്തം ശേഖരിച്ചത്"),
        "totalDue": MessageLookupByLibrary.simpleMessage("മൊത്തം ബാക്കി"),
        "totalExpense": MessageLookupByLibrary.simpleMessage("മൊത്തം ചെലവ്"),
        "totalLoss": MessageLookupByLibrary.simpleMessage("ആകെ നഷ്ടം"),
        "totalPayable": MessageLookupByLibrary.simpleMessage("ആകെ അടക്കേണ്ടത്"),
        "totalPrice": MessageLookupByLibrary.simpleMessage("ആകെ വില"),
        "totalProducts":
            MessageLookupByLibrary.simpleMessage("ആകെ ഉത്പന്നങ്ങൾ"),
        "totalProfit": MessageLookupByLibrary.simpleMessage("ആകെ ലാഭം"),
        "totalPurchase": MessageLookupByLibrary.simpleMessage("മൊത്തം വാങ്ങൽ"),
        "totalReturnAmount":
            MessageLookupByLibrary.simpleMessage("മൊത്തം തിരിച്ചെടുക്കൽ തുക"),
        "totalReturns": MessageLookupByLibrary.simpleMessage("മൊത്തം തിരിച്ചു"),
        "totalSale": MessageLookupByLibrary.simpleMessage("ആകെ വിൽപ്പന"),
        "totalStock": MessageLookupByLibrary.simpleMessage("മൊത്തം സ്റ്റോക്ക്"),
        "totalValue": MessageLookupByLibrary.simpleMessage("ആകെ മൂല്യം"),
        "totalVat": MessageLookupByLibrary.simpleMessage("ആകെ വാറ്റ്"),
        "totals": MessageLookupByLibrary.simpleMessage("മൊത്തം: "),
        "transaction": MessageLookupByLibrary.simpleMessage("ലേലങ്ങൾ"),
        "transactionId": MessageLookupByLibrary.simpleMessage("ലേലങ്ങൾ ID"),
        "tryAgain": MessageLookupByLibrary.simpleMessage("മറുപടി നല്‍കുക"),
        "twitter": MessageLookupByLibrary.simpleMessage("ട്വിറ്റർ"),
        "type": MessageLookupByLibrary.simpleMessage("തരം"),
        "unitName": MessageLookupByLibrary.simpleMessage("യൂണിറ്റിന്റെ നാമം"),
        "unitPirce": MessageLookupByLibrary.simpleMessage("അഞ്ചു വില"),
        "unitPrice": MessageLookupByLibrary.simpleMessage("അളവ് വില"),
        "units": MessageLookupByLibrary.simpleMessage("അംഗങ്ങൾ"),
        "unlimited": MessageLookupByLibrary.simpleMessage("അവസ്ഥകളില്ല"),
        "unlimitedUsage":
            MessageLookupByLibrary.simpleMessage("പരിമിതിയില്ലാത്ത ഉപയോഗം"),
        "unlockTheFull": MessageLookupByLibrary.simpleMessage(
            "Pos Saas POS യുടെ മുഴുവൻ സാധ്യതകൾ അനാവരണം ചെയ്യുക, ഞങ്ങളുടെ വിദഗ്ധ ടീമിന്റെ നേതൃത്വത്തിലുള്ള വ്യക്തിഗത പരിശീലന സെഷനുകൾ വഴി. അടിസ്ഥാനങ്ങൾ മുതൽ പരിചയങ്ങളിലേക്കുള്ള ദിശാ നിർദ്ദേശങ്ങൾ വരെ, ഓരോ ഘടകവും എങ്ങനെ ഉപയോഗിക്കാമെന്ന് നിങ്ങളെ നന്നായി അറിയിച്ചുകൊണ്ട്, നിങ്ങളുടെ ബിസിനസ്സ് പ്രക്രിയകൾ വിപുലീകരിക്കുക."),
        "unpaid": MessageLookupByLibrary.simpleMessage("വാങ്ങാത്ത"),
        "update": MessageLookupByLibrary.simpleMessage("അപ്ഡേറ്റ് ചെയ്യുക"),
        "updateContact":
            MessageLookupByLibrary.simpleMessage("സമ്പർക്കം പുതുക്കുക"),
        "updateNow":
            MessageLookupByLibrary.simpleMessage("ഇപ്പോൾ അപ്‌ഡേറ്റ് ചെയ്യുക"),
        "updateProduct": MessageLookupByLibrary.simpleMessage(
            "ഉൽപ്പന്നം അപ്‌ഡേറ്റ് ചെയ്യുക"),
        "updateYourPlanFirstYourLimitIsOver":
            MessageLookupByLibrary.simpleMessage(
                "നിങ്ങളുടെ പരിധി തീർന്നതിനാൽ ആദ്യം നിങ്ങളുടെ പദ്ധതി പുതുക്കുക"),
        "updateYourProfile": MessageLookupByLibrary.simpleMessage(
            "നിങ്ങളുടെ പ്രൊഫൈൽ അപ്‌ഡേറ്റ് ചെയ്യുക"),
        "updateYourProfileToConnect": MessageLookupByLibrary.simpleMessage(
            "നിങ്ങളുടെ ഡോക്ടറെ മികച്ച ഇമോഷനോട് ബന്ധിപ്പിക്കാൻ നിങ്ങളുടെ പ്രൊഫൈൽ അപ്‌ഡേറ്റ് ചെയ്യുക"),
        "updateYourProfiletoConnectTOCusomter":
            MessageLookupByLibrary.simpleMessage(
                "നിങ്ങളുടെ ഉപഭോക്താവിനോടൊപ്പം മികച്ച ഇമേജ് ബന്ധിപ്പിക്കാൻ നിങ്ങളുടെ പ്രൊഫൈൽ അപ്‌ഡേറ്റ് ചെയ്യുക"),
        "updated": MessageLookupByLibrary.simpleMessage("പുതുക്കിയതായി"),
        "upload": MessageLookupByLibrary.simpleMessage("അപ്‌ലോഡ് ചെയ്യുക"),
        "uploadDocument": MessageLookupByLibrary.simpleMessage(
            "ഡോക്യുമെന്റ് അപ്‌ലോഡ് ചെയ്യുക"),
        "uploadDone":
            MessageLookupByLibrary.simpleMessage("അപ്‌ലോഡ് പൂർത്തിയായി"),
        "uploadFile":
            MessageLookupByLibrary.simpleMessage("ഫയല്‍ അപ്‌ലോഡ് ചെയ്യുക"),
        "upplier": MessageLookupByLibrary.simpleMessage("സപ്ലയർ"),
        "usbC": MessageLookupByLibrary.simpleMessage("USB C"),
        "use": MessageLookupByLibrary.simpleMessage("ഉപയോഗിക്കുക"),
        "useMobiPos":
            MessageLookupByLibrary.simpleMessage("POS SaaS ഉപയോഗിക്കുക"),
        "useOfTheSystem":
            MessageLookupByLibrary.simpleMessage("സിസ്റ്റത്തിന്റെ ഉപയോഗം"),
        "userIsDeleted":
            MessageLookupByLibrary.simpleMessage("ഉപയോക്താവ് മായ്ച്ചു"),
        "userRole": MessageLookupByLibrary.simpleMessage("ഉപയോക്തൃ റോളുകൾ"),
        "userRoleDetails":
            MessageLookupByLibrary.simpleMessage("ഉപയോക്തൃ വേഷ വിശദാംശങ്ങൾ"),
        "userTitle": MessageLookupByLibrary.simpleMessage("ഉപയോക്തൃ തലശ്ശി"),
        "userTitleCanNotBeEmpty": MessageLookupByLibrary.simpleMessage(
            "ഉപയോക്തൃ തലക്കെട്ട് ശൂന്യമായിരിക്കരുത്"),
        "value": MessageLookupByLibrary.simpleMessage("മൂല്യം"),
        "vatDoesNotApply":
            MessageLookupByLibrary.simpleMessage("വാറ്റ് പ്രയോഗിക്കില്ല"),
        "verifyOtp":
            MessageLookupByLibrary.simpleMessage("OTP സ്ഥിരീകരിക്കുന്നു"),
        "verifyPhoneNumber":
            MessageLookupByLibrary.simpleMessage("ഫോൺ നമ്പർ സ്ഥിരീകരിക്കുക"),
        "viewAll": MessageLookupByLibrary.simpleMessage("എല്ലാം കാണുക"),
        "viewDetails": MessageLookupByLibrary.simpleMessage("വിദ്യാസം കാണുക"),
        "walkInCustomer":
            MessageLookupByLibrary.simpleMessage("വേക്കാൻ വരുന്ന ഉപഭോക്താവ്"),
        "warehouse": MessageLookupByLibrary.simpleMessage("വെയർഹൗസ്"),
        "warehouseAlreadyExists":
            MessageLookupByLibrary.simpleMessage("ഗൊദാമം നിലവിലുണ്ട്"),
        "warehouseList":
            MessageLookupByLibrary.simpleMessage("ഗൊദാമുകളുടെ പട്ടിക"),
        "warehouseName":
            MessageLookupByLibrary.simpleMessage("ഗൊദാമത്തിന്റെ പേര്"),
        "warranty": MessageLookupByLibrary.simpleMessage("വാറന്റി"),
        "weHaveSendAnEmailwithInstructions": MessageLookupByLibrary.simpleMessage(
            "പാസ്‌വേഡ് പുനഃസജ്ജമാക്കുന്നതിനുള്ള നിർദ്ദേശങ്ങൾ ഉൾപ്പെടുന്ന ഒരു ഇമെയിൽ ഞങ്ങൾ അയച്ചു:"),
        "weMayUseThirdPartyServicesToSupport": MessageLookupByLibrary.simpleMessage(
            "ഞങ്ങളുടെ ആപ്പിന്റെ പ്രവർത്തനക്ഷമതയെ പിന്തുണയ്ക്കാൻ, അനാലിറ്റിക്സ് സേവനദാതാക്കൾക്കും പേയ്മെന്റ് പ്രോസസർമാർക്കും പോലുള്ള മൂന്നാം പാർട്ടി സേവനങ്ങൾ ഞങ്ങൾ ഉപയോഗിക്കാം. ഈ മൂന്നാം പാർട്ടി സേവനങ്ങൾ നിങ്ങളുടെ ആപ്പ് ഉപയോഗിക്കുന്നപ്പോൾ നിങ്ങളുടെ കുറച്ച് വിവരങ്ങൾ ശേഖരിച്ചേക്കാം. ഈ മൂന്നാം പാർട്ടി സേവനങ്ങളുടെ സ്വകാര്യതാ പ്രക്രിയകൾക്കായി ഞങ്ങൾ ഉത്തരവാദികളല്ല."),
        "weTakeIndustryStandard": MessageLookupByLibrary.simpleMessage(
            "നിങ്ങളുടെ വ്യക്തിഗത വിവരങ്ങൾ സംരക്ഷിക്കാൻ നാം വ്യവസായമാതൃകയായ നടപടികൾ സ്വീകരിക്കുന്നു, എൻക്രിപ്ഷനും സുരക്ഷിത സംഭരണവും ഉൾപ്പെടുന്നു. നിങ്ങളുടെ വിവരങ്ങൾ അധികാരമുള്ള ജീവനക്കാർക്കുള്ള ആക്‌സസ് പരിമിതപ്പെടുത്തുന്നു."),
        "weUnderStand": MessageLookupByLibrary.simpleMessage(
            "ഞങ്ങൾ കൃത്യമായ പ്രവർത്തനങ്ങളുടെ പ്രാധാന്യം മനസിലാക്കുന്നു. അതിനാൽ, ഒരു արագ ചോദ്യമോ വ്യാപകമായ ആശങ്കയോ ആണെങ്കിൽ, ഞങ്ങളുടെ 24-മണിക്കൂർ പിന്തുണ നിങ്ങൾക്കായി ലഭ്യമാക്കുന്നു. വിളിക്കുകയോ വാട്‌സാപ്പിലൂടെ ബന്ധപ്പെടുകയോ ചെയ്യുക, നിങ്ങൾക്ക് സമാനമായ ഉപഭോക്തൃ സേവനം അനുഭവപ്പെടാൻ."),
        "weUseYourPersonalInformation": MessageLookupByLibrary.simpleMessage(
            "നിങ്ങളുടെ വ്യക്തിഗത വിവരങ്ങൾ, നിങ്ങളുടെ അനുഭവം മെച്ചപ്പെടുത്തുന്നതിന്, ഉള്ളടക്കം ശുപാർശകൾ വ്യക്തിപരമായതാക്കുന്നതിന്, വിദഗ്ധരുമായി ബന്ധിപ്പിക്കുന്നതിന്, ഞങ്ങളുടെ ആപ്പിന്റെ പ്രവർത്തനക്ഷമത മെച്ചപ്പെടുത്തുന്നതിനും ഉപയോഗിക്കുന്നു. അപ്‌ഡേറ്റുകൾ, പ്രമോഷനുകൾ, അല്ലെങ്കിൽ ഞങ്ങളുടെ ആപ്പുമായി ബന്ധപ്പെട്ട മറ്റു വിവരങ്ങൾക്കായി ഞങ്ങൾ നിങ്ങളുമായി ബന്ധപ്പെടുന്നതിനും നിങ്ങളുടെ വിവരങ്ങൾ ഉപയോഗിക്കാം."),
        "weWillReviewThePaymentApproveItWithinHours":
            MessageLookupByLibrary.simpleMessage(
                "നാമിതത്തെ അവലോകനം ചെയ്യുകയും 1-2 മണിക്കൂറിനുള്ളിൽ അംഗീകരിക്കുകയും ചെയ്യും"),
        "weekly": MessageLookupByLibrary.simpleMessage("അവധിവാര"),
        "weight": MessageLookupByLibrary.simpleMessage("ഭാരം"),
        "whatsNew": MessageLookupByLibrary.simpleMessage("എന്താണ് പുതിയത?"),
        "wholSeller": MessageLookupByLibrary.simpleMessage("തൊഴിലാളി"),
        "wholeSalePrice": MessageLookupByLibrary.simpleMessage("ഹോൾസെയിൽ വില"),
        "wholesalePrice": MessageLookupByLibrary.simpleMessage("തുല്യവില"),
        "wholesaler": MessageLookupByLibrary.simpleMessage("വില്പനക്കാരൻ"),
        "willBeAddedSoon":
            MessageLookupByLibrary.simpleMessage("കൂടാതെ ചേർക്കാൻ വരുന്നു"),
        "willExpireAt": MessageLookupByLibrary.simpleMessage("കാലഹരണത്തെത്തി"),
        "writeYourMessageHere": MessageLookupByLibrary.simpleMessage(
            "നിങ്ങളുടെ സന്ദേശം ഇവിടെ എഴുതുക"),
        "wrongOTP": MessageLookupByLibrary.simpleMessage("തല്ലാത്ത OTP"),
        "wrongPasswordProvidedforThatUser":
            MessageLookupByLibrary.simpleMessage(
                "ആ ഉപയോക്താവിന് തെറ്റായ പാസ്‌വേഡ് നൽകുന്നു."),
        "yearly": MessageLookupByLibrary.simpleMessage("വാർഷികം"),
        "yesDeleteForever":
            MessageLookupByLibrary.simpleMessage("അതെ, എപ്പോഴും ഇല്ലാതാക്കുക"),
        "youAreNotAValidUser":
            MessageLookupByLibrary.simpleMessage("നിങ്ങൾ സാധുവായ ഉപയോക്താവല്ല"),
        "youAreUsing":
            MessageLookupByLibrary.simpleMessage("നിങ്ങൾ ഉപയോഗിക്കുന്നു"),
        "youCanNotPayMoreThenDue": MessageLookupByLibrary.simpleMessage(
            "നിങ്ങൾ_due_കാൾ അധികം പണം നൽകില്ല"),
        "youHaveGotAnEmail":
            MessageLookupByLibrary.simpleMessage("നിനക്കൊരു ഇമെയിൽ ലഭിച്ചു"),
        "youHaveSuccefulyLogin": MessageLookupByLibrary.simpleMessage(
            "നിങ്ങൾ വിജയകരമായി നിങ്ങളുടെ അക്കൗണ്ടിലേക്ക് ലോഗിൻ ചെയ്തു. പോസ് സാസ് എന്നതിൽ തുടരുക."),
        "youHaveToGivePermission":
            MessageLookupByLibrary.simpleMessage("നിങ്ങൾ അനുമതി നൽകണം"),
        "youHaveToReLogin": MessageLookupByLibrary.simpleMessage(
            "നിങ്ങളുടെ അക്കൗണ്ടിൽ വീണ്ടും ലോഗിൻ ചെയ്യണം."),
        "youNeedToIdentityVerifyBeforeYouBuying":
            MessageLookupByLibrary.simpleMessage(
                "നിങ്ങൾ SMS വാങ്ങുന്നതിന് മുമ്പ് പ്രാഥമികത സ്ഥിരീകരണം ചെയ്യേണ്ടതുണ്ട്"),
        "yourMessageRemains": MessageLookupByLibrary.simpleMessage(
            "നിങ്ങളുടെ സന്ദേശങ്ങൾ തുടരുന്നു"),
        "yourPackage":
            MessageLookupByLibrary.simpleMessage("നിങ്ങളുടെ പാക്കേജ്"),
        "yourPackageWillExpireinDay": MessageLookupByLibrary.simpleMessage(
            "നിങ്ങളുടെ പാക്കേജ് 5 ദിവസത്തിനുള്ളിൽ കാലഹരണപ്പെട്ടു പോകും")
      };
}
